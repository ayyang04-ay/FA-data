# MGAT1 programme: verification package (data cut 1 Nov 2026)

## Start here
| File | What it is |
|---|---|
| `MGAT1_recommendation_memo.md` | The recommendation and the case behind it. Every number carries an evidence ID, e.g. `[E24]`. |
| `MGAT1_recommendation_memo.html` | The same memo as one self-contained file, with all six figures embedded. |
| `evidence_ledger.xlsx` / `.csv` | 46 entries. Each evidence ID maps to: statement, value, source file and page/sheet, the script and output table that produced it, the evidence type, and caveats. |

## Evidence types used in the ledger
| Type | Meaning |
|---|---|
| client-reported | Read directly from the client's files. |
| re-analysis | Recomputed from the client's raw data files. |
| digitised | Read from client figure images. These values are approximate; the client supplied no underlying numbers, n, error-bar type or statistics for them. |
| inference | My interpretation, e.g. arm identities in the in vivo screen, where no key was supplied. |
| discrepancy | The records and the data disagree. |

## Figures (`figures/`)
| File | Content |
|---|---|
| `fig1_invivo_mgat1_by_arm.png` | Per-tumour Mgat1 score in each group of the in vivo screen |
| `fig2_invivo_stk11_selectivity.png` | Stk11-KO vs STK11-intact gene scores for all 795 library genes |
| `fig3_invivo_arm_inference.png` | Marker-gene z-scores used to infer the screen arms |
| `fig4_coculture_rank.png` | Genome-wide co-culture screen ranking |
| `fig5_glycan_composition.png` | Glycoproteomics: glycan-class shares, knockout vs control |
| `fig6_phenotype_digitised_summary.png` | Digitised client phenotype read-outs |

## Reproducing the numbers (`analysis/`)
The scripts read only `/tmp/world/filesystem/`. Run them in this order:

| Script | Run with | What it does |
|---|---|---|
| `00_extract_pdf_content.py` | `mm genomics python` | Extracts PDF text and embedded figure images into `analysis/extracted/` |
| `01_invivo_screen.py` | `mm singlecell python` | In vivo CRISPR screen: QC, gene scores, STK11 selectivity, arm inference, robustness |
| `02_coculture_screen.py` | `mm singlecell python` | Genome-wide co-culture screen re-analysis |
| `03_glycoproteomics.py` | `mm chem python` | Glycan-class composition and QC |
| `04_chemistry_biophysics_structure.py` | `mm core python` | Registry metrics, SPR and DSF checks, dose-response digitisation and fits, crystal-structure geometry |
| `05_phenotype_digitisation.py` | `mm core python` | Digitises tumour-volume and viability figures; immunoblot densitometry |
| `05b_phenotype_digitisation_p2_p5.py` | `mm core python` | Digitises the p2 and p5 bar charts |
| `06_build_evidence_ledger.py` | `mm chem python` | Builds the ledger |
| `07_phenotype_summary_figure.py` | `mm core python` | Builds figure 6 |
| `08_render_html.py` | `mm chem python` | Renders the HTML memo |

Every output table in `tables/` is referenced from the ledger.
