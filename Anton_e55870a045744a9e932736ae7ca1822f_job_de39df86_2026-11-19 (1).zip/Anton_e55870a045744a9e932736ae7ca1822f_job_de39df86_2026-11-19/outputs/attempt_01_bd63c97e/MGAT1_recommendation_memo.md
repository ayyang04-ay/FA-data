# MGAT1 inhibitor programme (Antera Therapeutics): independent verification and recommendation

**Data cut:** the client package current as of 1 Nov 2026 (16 files).
**What I used:** only the client's own data. That means two CRISPR screens (raw counts), the glycoproteomics workbook, the compound registry, the SPR and DSF tables, five crystal structures, and the three PDF record and figure sets. I re-analysed everything from raw files wherever raw files existed.
**How to trace a number:** each number has an evidence ID in brackets, e.g. [E24]. `evidence_ledger.xlsx` maps each ID to its source file and page, the script that produced it, and any caveats. A "≈" means I digitised the value from a client figure, because the client supplied no underlying numbers for it.

---

## 1. Recommendation: do not advance. Hold behind gates.

**Do not take this asset into scaled lead optimisation, an in vivo efficacy campaign, or candidate-enabling work.** Hold it where it is. Fund only a short proof-of-mechanism package with go/no-go gates (Section 5). Bring the advance decision back when the criteria in Section 6 are met, and stop if Gate 1 fails.

This is a hold, not a kill, for two reasons:

* **The biology is real.** Knocking out MGAT1 repeatedly makes human NSCLC cells easier for antigen-specific CD8⁺ T cells to kill. This shows up in a genome-wide screen, with four independent guides in two cell lines, and in vivo. The effect needs MGAT1's catalytic activity, so an enzyme inhibitor is the right kind of drug.
* **The chemistry is real.** ANT-4267 binds MGAT1 at 30–70 nM and inhibits it at 43 nM. The binding site is defined by crystal structures, and in vitro clearance and solubility are acceptable.

It is not ready to advance, for four reasons:

1. **No compound has been tested in cells or animals.** Every efficacy result comes from CRISPR knockouts confined to tumour cells. The programme's central premise, that a small molecule can reproduce the knockout, has never been tested.
2. **The data do not support the stated positioning (checkpoint-inhibitor-resistant, STK11-mutant NSCLC).**
   * All STK11 selectivity comes from one engineered mouse line, MC38.
   * The MGAT1 effect is the same with or without anti-PD-1.
   * About 60% of the effect is already present in the arm with no T-cell selection (arm identity inferred; no key was supplied).
   * The human NSCLC lines have no documented STK11 status.
   * In STK11-intact MC38, losing MGAT1 made tumours grow *faster* in the one experiment shown.
3. **Nobody has looked at systemic inhibition.** Every experiment removes MGAT1 from tumour cells only. A drug would also reach the T cells the efficacy depends on, and the rest of the host.
4. **Key records are missing or inconsistent.**
   * The in vivo screen has no group-to-arm key.
   * The mouse numbers do not reconcile.
   * The dose-response axes do not match the documented protocol.

**Confidence:** high that the asset should not advance now. Moderate on how to interpret the in vivo screen mechanistically, until the client supplies the group key.

---

## 2. Scorecard

| Question | What the client's data show | Verdict |
|---|---|---|
| Does MGAT1 loss sensitise NSCLC cells to CD8⁺ T-cell killing? | Genome-wide screen ranks MGAT1 #12 of 19,114 genes. Four arrayed guides work in two lines. The effect holds in vivo with TCR-T cells [E01–E03, E07, E09] | **Strong** |
| Is catalytic activity required? | Catalytic-dead cDNAs fail to rescue, in vitro and in vivo; the structures support the choice of mutants [E10–E12, E43] | **Strong** |
| Is the dependency STK11-selective? | #1 of 795 genes in one engineered mouse line (MC38). A large T-cell-independent share. No NSCLC model with defined STK11 status [E24–E31, E05] | **Moderate, one model** |
| Does it overcome checkpoint-inhibitor resistance? | Same effect ± anti-PD-1; single-gene combination is additive [E14, E30] | **Not shown** |
| Chemistry: potency, binding, mechanism, in vitro ADME | 43 nM lead; non-donor-competitive, crystallographically defined site; low clearance [E32–E35, E41] | **Good** |
| Compound activity in cells or animals | None | **Absent** |
| Tolerability of systemic MGAT1 inhibition | None | **Absent** |
| Records / data integrity | Missing screen key, unreconciled animal numbers, axis/protocol mismatch [E20, E36, E44, E45] | **Gaps to close** |

---

## 3. The case for keeping the asset alive: what the data support

**3.1 MGAT1 loss sensitises NSCLC cells to T-cell killing (strong)**

* **Genome-wide screen.** The screen used NCI-H1703 cells and NY-ESO-1 TCR T cells.
  * MGAT1 ranks 12th of 19,114 genes for depletion (median guide log2FC −0.85; 3 of 4 guides ≤ −0.5; z = −8.1 against non-targeting guides) [E01].
  * The hit holds when the UMI lineages are split into random halves [E03].
  * The screen behaves correctly: the TCR antigen itself (CTAG1B/CTAG1A) and the IFN-γ/MHC-I genes are the top resistance hits [E02].
* **Arrayed validation.** Four guides (none of them library guides) were tested in two lines. Viability after T-cell co-culture was ≈0.17–0.54, against ≈0.79–0.92 for the non-targeting guide. The B2M-knockout control sat at ≈1.8–2.0 [E07].
* **In vivo, with TCR-T transfer.** At day 19, MGAT1-knockout tumours were:
  * ≈53% smaller with 1×10⁶ antigen-specific T cells;
  * ≈75% smaller with 2×10⁶;
  * ≈14% smaller with control T cells [E09].

**3.2 Catalytic activity is required, so an enzyme inhibitor is the right modality (strong)**

* In knockout cells, wild-type cDNA restores complex glycans and T-cell resistance. D289A and D211A+D289A do not, even though they are expressed at least as well as wild type [E10, E11].
* In vivo, in Stk11-KO MC38 lacking endogenous MGAT1, tumours re-expressing catalytic-dead MGAT1 were ≈51% smaller than those re-expressing wild type [E12].
* The structures support the choice of mutants: D211 coordinates Mn²⁺ at 2.2 Å, and D289 sits 4.6 Å from the anomeric carbon of UDP-GlcNAc [E43].

**3.3 The knockout has a measurable biochemical signature, which gives ready-made benchmarks for compound PD**

* PHA-L staining falls by ≥94% and GNA staining rises ≈8–9× [E08].
* Glycoproteomics in A375 and NCI-H1703 (n = 4 per arm; p < 10⁻⁵) [E17]:
  * the Man5 share doubles (≈19–20% → ≈40% of glycopeptide signal);
  * the complex/hybrid share falls from ≈9–10% to ≈5%;
  * the sialylated share falls from ≈4–5% to ≈2%.

**3.4 In vivo, MGAT1 is the most STK11-selective dependency in the client's screen**

I re-analysed the pooled MC38 screen (141 tumours). In the immunocompetent-like arms:

* Mgat1-knockout cells were depleted ≈6.9-fold more in Stk11-KO tumours than in STK11-intact tumours (mean log2 −3.68 vs −0.90; Mann–Whitney p = 2×10⁻¹⁴) [E24].
* All 52 Stk11-KO tumours were depleted, against 47% of the 53 controls [E24].
* Mgat1 ranks #1 of 795 genes. #2 is B4galt1, a downstream enzyme in the same complex-N-glycan pathway, which makes the result biologically coherent [E25].
* The result survives every sensitivity check I ran (Δ −2.1 to −3.5 log2) [E26] and is driven by 3 of the 4 guides [E27].

**3.5 The chemistry is genuine and works by a useful mechanism**

* **ANT-4267:** IC50 43 nM; KD 70 nM (steady state) and 30 nM (kinetic); kinetic solubility 96 µM; hepatocyte Clint < 1.35 µl/min/10⁶ cells.
* **ANT-3744:** IC50 0.81 µM; KD 0.38 µM; ΔTm +6 °C; solubility 178 µM; Clint 3.2 [E32, E35].
* LipE (pIC50 minus the client's *calculated* logD) improves from 1.1 (the purchased hit; its value is solubility-limited) to 3.9 (ANT-3744) to 4.8 (ANT-4267) [E33].
* The reported IC50s match the plotted curves to within 1.4-fold [E46].
* **Binding does not compete with the nucleotide** [E34, E35, E41]:
  * saturating ANT-3744 leaves UDP affinity unchanged (20 vs 32 µM, against ≈1,600 µM expected if competitive);
  * the reverse also holds (0.2 vs 0.4 µM, against ≈63 µM expected);
  * the DSF shifts are roughly additive (+2 and +6 °C alone, +8 °C together);
  * the ternary crystal structure shows both ligands bound at once.
  * So high cellular UDP-GlcNAc should not erode potency. One caveat: the competition was run with UDP, not UDP-GlcNAc.
* ANT-3744 binds an induced pocket formed by the C-terminal segment (W437 and E438 move 5–8 Å). It does so identically in four copies across two crystal forms [E41].

---

## 4. The case against advancing now: what the data do not support

**4.1 No compound biology**

* Nothing connects the series to the phenotype. No compound has data for any of these:
  * cellular glycan PD or T-cell co-culture;
  * permeability or selectivity;
  * PK, in vivo PD, or tolerability.
* The current data cannot answer four specific questions:
  * **Will a compound reach the enzyme?** TPSA is 108–110 Å², and ANT-3744 carries a primary amine. Very low hepatocyte turnover is consistent with stability, but also with poor cell entry [E32, E33].
  * **How deep must inhibition be?** The genetic phenotype corresponds to ≥94% loss of PHA-L signal [E08]. In the biochemical assay the synthesised compounds plateau at ≈90% inhibition, leaving ≈8–10% residual activity [E46]. That plateau could be assay background rather than incomplete inhibition.
  * **How does the compound inhibit?** It binds ≈24 Å from the donor site and ≈16 Å from the catalytic base. There are no acceptor-competition data. The assay uses a free pentasaccharide acceptor, not a glycoprotein [E41].
  * **Is the crystal pocket the binding site in solution?** In every copy the ligand also touches a neighbouring molecule in the crystal (3.0–3.9 Å) [E42].
* Tumour-restricted genetics do not model systemic exposure. No experiment exposes T cells or host tissues to MGAT1 loss or to compound.

**4.2 STK11 selectivity rests on one engineered mouse line and is largely T-cell-independent**

* The only STK11 data come from MC38 with an Stk11 sgRNA [E13, E15, E24]. MC38 is a murine colon-derived line, not a lung model.¹
* Nothing links the effect to STK11 in human cells:
  * the human NSCLC lines have no documented STK11 status;
  * in the NCI-H1703 screen, knocking out STK11 did nothing (log2FC +0.07);
  * MGAT1 sensitisation happened there without any engineered STK11 loss [E05].
* The client did not supply a group-to-arm key. From guide-level signatures, groups G1 and G5 show no T-cell/IFN-γ-type selection, so they are presumably the nude arms [E28]. If that is right:
  * ≈60% of the Mgat1 depletion in Stk11-KO tumours (−2.23 of −3.68 log2; 57–72% across analysis variants) happens without T-cell selection;
  * only ≈−1.45 log2 depends on T cells [E29];
  * a smaller STK11-selective fitness cost also appears in vitro (−0.67 log2) [E31].
  * The T-cell-dependent share does appear to be specific to Stk11-KO tumours. There is none in STK11-intact tumours (+0.43, p = 0.07), although that estimate is fragile because G1 is heavily bottlenecked [E29].
* STK11 protein comes back to ≈13–20% of parental in three of the four MC38 rescue lines, compared with 4–7% in the parental knockouts [E16].

**4.3 No evidence of checkpoint-inhibitor sensitisation**

* **Screen:** Mgat1 depletion is indistinguishable across the three immunocompetent-like Stk11-KO arms (−3.77, −3.59, −3.69; Kruskal–Wallis p = 0.69), whichever of them received anti-PD-1 [E30].
* **Single-gene study** (Stk11-KO MC38, day 9) [E14]:

  | Arm | Tumour volume |
  |---|---|
  | IgG | ≈1,140 mm³ |
  | anti-PD-1 | ≈760 mm³ |
  | MGAT1 knockout | ≈620 mm³ |
  | both | ≈400 mm³ |

  * That matches independent (Bliss) action almost exactly (≈415 mm³), so the combination is additive, not synergistic.
  * Combination tumours still grew about 8-fold from ≈50 mm³.
  * No n, error-bar type or statistics are reported.

**4.4 A conflicting signal in STK11-intact tumours**

* In STK11-intact MC38, MGAT1-knockout tumours were ≈52% *larger* at day 25 [E13].
* Yet in the screen the same guide (Mgat1_4) is *depleted* in STK11-intact tumours (−1.4 to −2.7 log2) [E27].
* One possible explanation: the MGAT1-knockout line in the engineering schematic is a single clone (A-F5), and it is compared against a pool.
* Until this is resolved it is a potential liability, because a drug would also reach STK11-wild-type tumours.

¹ Tissue of origin for cell lines is standard reference information, not client data.

---

## 5. Next steps: what the next studies must establish

Run Gate 0 now. Run Gate 1 first; it is the go/no-go for the chemistry. The genetic arms of Gate 2 can run in parallel. Design-level only.

### Gate 0: Records (weeks, no new experiments)

Get the client to supply or fix the following:

* the group-to-arm key for the in vivo screen, and reconciled animal numbers;
* the raw plate data and protocol version behind the dose-response curves;
* the D211A, D289A and D211A/D289A enzyme activity data;
* the full compound list behind the IC50-versus-KD plot;
* structures for the hit and the synthesised analogues, including ANT-4267 (only ANT-3744's structure is in the package, via the crystal ligand definition);
* the hepatocyte species and the ADME methods (logD and TPSA are calculated values per the records);
* n, error-bar definition, statistics, cell line and host strain for every in vivo and co-culture figure;
* the STK11 status of NCI-H1703 and NCI-H1755;
* corrected figure captions.

With the key in hand, re-test two interactions in the existing screen: Mgat1 × anti-PD-1 and Mgat1 × host.

### Gate 1: Cellular proof of mechanism (go/no-go for the series)

**Must establish:**

* a compound reaches and inhibits MGAT1 in cells, deep enough to reproduce the knockout glycan state;
* it does so on target;
* it reproduces T-cell sensitisation without harming the T cells;
* the depth and duration of inhibition needed (establish the threshold by titration; until then, the knockout depth is the bar).

**Comparisons the data must include:**

* compound vs vehicle vs **MGAT1 knockout in the same line** vs non-targeting control (NCI-H1703 and NCI-H1755 at minimum);
* compound on **MGAT1-knockout cells** (should add nothing);
* knockout cells re-expressing a **catalytically competent, compound-insensitive pocket mutant** (should abolish the effect). Candidates come from the structure: Y388, W437, W444 [E41]. Confirm each one by SPR and enzyme assay first; this also validates the pocket in solution;
* an **inactive close analogue**, and **ANT-4267 vs ANT-3744** (does cell potency track biochemical potency?);
* tumour-only pre-treatment vs co-exposure of the **T cells themselves** (killing, activation, viability);
* benchmarks: PTPN2 knockout as a sensitiser (#3 in the screen) and B2M knockout as a resistance control [E02].

**Proposed success bar:**

| Readout | Target | Knockout benchmark |
|---|---|---|
| PHA-L | down ≥90% at ≤1 µM within 72 h | ≥94% [E08] |
| GNA | up ≥5× | 8–9× [E08] |
| Man5 share | ≥35% | ≈40% [E17] |
| Complex/hybrid share | ≤6% | ≈5% [E17] |
| Viability after co-culture | ≤0.5, vs ≥0.8 for vehicle | 0.17–0.54 [E07] |
| T cells exposed to the same concentration | keep ≥80% of their killing | — |
| On-target controls | effect absent in knockout cells and lost with the resistant mutant | — |

**Stop rule:** if the series cannot reach knockout-like glycan depth at concentrations that are not toxic to tumour cells or T cells, stop investing in it.

### Gate 2: The indication hypothesis (genetic arms can start now, then repeat with compound)

**Must establish:**

* whether STK11 loss increases MGAT1 dependence in NSCLC;
* how much of the in vivo benefit depends on T cells;
* whether the benefit adds to anti-PD-1;
* whether STK11-intact tumours are harmed.

**Comparisons the data must include:**

* **Isogenic STK11 pairs in human NSCLC lines**, in both directions (knock STK11 out of intact lines; re-express it in mutant lines) × MGAT1 knockout or compound × with/without T cells;
* a **2×2 design in vivo** (MGAT1 inhibition × anti-PD-1), run in an STK11-null, lung-relevant syngeneic model **and its isogenic STK11-intact twin**, with CD8-depletion and T-cell-deficient host arms;
* pooled knockouts with ≥2 guides, not single clones; WT vs catalytic-dead rescue;
* pre-specified endpoints, n ≥10 per arm, randomisation, blinded measurement, and a formal interaction test (synergy judged against Bliss);
* a repeat of the STK11-intact MC38 experiment with pooled knockouts, to settle the growth-acceleration signal [E13];
* *optional but informative:* benchmark MGAT1 against one or two glycosylation nodes that score as strongly in the human screen (e.g. CMAS, SLC35A1 [E04]) in the same STK11 isogenic systems, to confirm MGAT1 is the best node to drug.

**Success bar:**

* the STK11 × MGAT1 interaction is significant in human cells;
* in vivo, the combination beats anti-PD-1 alone;
* the benefit is lost when CD8 cells are depleted;
* the benefit is larger in STK11-null than in STK11-intact tumours;
* STK11-intact tumours are not accelerated.

### Gate 3: Developability and exposure

**Comparisons the data must include:**

* **Selectivity:** MGAT1 against related and pathway glycosyltransferases (at least MGAT2, MGAT3, MGAT4A/B, MGAT5, POMGNT1, B4GALT1). Proposed bar: ≥30-fold.
* **Readout check:** the coupled UDP-Glo readout against an orthogonal direct-product readout.
* **Mechanism:** free glycan vs glycopeptide acceptor, to define competition.
* **Pocket:** wild type vs pocket mutants in SPR (solution validation of the pocket).
* **Exposure and PD:** tumour PD vs PD in circulating immune cells at matched exposure; ANT-3744 vs ANT-4267 as a potency ladder for the exposure–PD–efficacy relationship.

**Success bar:** at a tolerated dose over ≥2 weeks:

* exposure stays at or above the cellular EC90 through the dosing interval;
* tumour PD meets the Gate 1 glycan criteria.

---

## 6. Bring-back criteria: what would turn this into an "advance"

Advance the asset if **all** of the following hold:

1. **Gate 1 is met.** Knockout-depth, on-target glycan PD in cells, plus T-cell sensitisation, with no T-cell impairment.
2. **In vivo efficacy, in at least one STK11-null NSCLC-relevant syngeneic model, that is:**
   * immune-dependent (lost with CD8 depletion);
   * better than anti-PD-1 alone when combined with it;
   * larger than in the isogenic STK11-intact model;
   * free of any acceleration of STK11-intact tumours.
3. **Gate 3 is met.** Target exposure is reached at a tolerated dose, with tumour PD.
4. **Gate 0 is closed.** The group key, raw plate data, mutant enzyme data and n/statistics are supplied and consistent.

**Partial outcomes:**

* **Reposition, don't kill,** if Gate 1 is met and the benefit is immune-dependent, but it is *not* STK11-selective. The asset becomes a broader immunotherapy-combination sensitiser, and needs a new patient-selection hypothesis.
* **Stop** if compounds cannot reach knockout-like glycan depth, or if T cells are impaired at active concentrations.

---

## 7. What I set aside or discounted, and why

| Item | Treatment | Why |
|---|---|---|
| NY-ESO-1 "expression in CCLE" plot (phenotype p9) | Set aside | Not client-generated data. It only justifies the choice of cell lines |
| ANT-1938, ANT-2214 (acquired) | Excluded from the series | No specific SPR binding. ANT-2214 gives a non-saturable, non-dissociating response and contains catechol and N-amino-imine motifs; probable assay interference. Partial inhibition appears only at top dose (n = 2) [E38] |
| ANT-0592 potency (hit) | Qualitative only | IC50 and KD were measured at 16.7× and 2.7× its kinetic solubility (flagged "*" by the client) [E37] |
| IC50-versus-KD correlation plot (~25 compounds) | Qualitative only | Only 3 plotted compounds are in the registry [E45] |
| In vivo screen tumour Group7_STK11_82431 | Excluded | 349 reads; 91% of guides at zero [E22] |
| Two bottlenecked tumours (82276, 82321) | Kept; sensitivity-tested | Excluding them changes nothing [E26] |
| UMI-lineage statistics in the co-culture screen | Not used | UMI-level agreement between arms is low (Spearman 0.37); 37% of lineages drop out. I used guide/gene sums and split-halves instead [E06] |
| Glycoproteomics absolute fold changes and individual compositions | Not used quantitatively | TMT ratio compression. KO channels carry 1.55–1.64× more total signal, so fold changes depend on normalisation; I used within-channel composition shares instead. The rise of "HexNAc(2)Hex(5)Fuc(1)" in knockouts is biochemically implausible (core fucosylation needs MGAT1's product), so it is probably misassigned. 23/910 sites sit on nuclear or cytosolic-type proteins [E18] |
| All tumour-volume and viability numbers from figures | Treated as approximate and directional | Digitised from images. The client reports no n, error-bar type or statistics [E07–E16] |
| The group labels of the in vivo screen | Inferred, not assumed | No key was supplied. Every arm-specific statement above is conditional on that inference [E28] |

---

## 8. Documentation issues to raise with the client

**High:**

* **In vivo screen records vs data.** The records describe three arms (nude, IgG2a, anti-PD-1) in 30 C57BL/6 and 15 nude mice: 45 mice, or 90 if read as per background. The count matrix has four groups per background, 141 tumours with 141 unique IDs, and no group-to-arm key [E19, E20]. Low coverage at implantation (≈28 cells per guide; ≈3 founders per guide per tumour) means per-tumour data are noisy [E21].
* **Dose-response axes vs protocol.** Five of six dose-response curves are plotted up to ≈1,000 µM, against a documented top concentration of 100 µM. With 10 mM stocks and a 0.5 µl dispense into 7 µl, the highest attainable concentration is ≈667 µM. ANT-4267's curve conforms to the protocol. The reported IC50s match the plotted curves, so either the protocol or the axes are wrong [E36].
* **Missing statistical and identity information.** No in vivo or co-culture figure states n, error-bar type or statistics. Figures p4 and p5 do not name the cell line; p4 does not name the host strain [E09, E10].

**Medium:**

* Enzyme data for the catalytic mutants are described but not supplied [E43].
* STK11 re-expression in the rescue lines [E16].
* The p1 and p8 captions appear to be swapped [E15].
* The IC50-versus-KD plot cannot be traced to the registry [E45].
* No structure is provided for the lead ANT-4267 (or the hit and the other analogues), and its binding mode is assumed from ANT-3744.
* The hepatocyte species is not stated. logD and TPSA are calculated, not measured [E32].

**Low** [E44]:

* DSF protein concentration is given as "18.6 nM" with 9.3 µM final (a unit error).
* The SPR association time is 60 s in the records but ≈100 s in several sensorgrams.
* Vinculin is used as a loading control but is not in the antibody list.
* The "ITC" control guide maps to POLB_2 in the client's own human library.
* The DSF legend calls ANT-3744 "HTS", but the registry says "synthesised".
* The PDF metadata is dated 18 Nov 2026, after the 1 Nov data cut.
* The D211A single mutant is described but never shown.

---

## Appendix: what I did and where the files are

**In vivo CRISPR screen** (`analysis/01_invivo_screen.py`):

* Guide counts were CPM-normalised and converted to log2 fold change of each tumour against its own background's baseline.
* Each tumour was centred on its non-targeting guides.
* The gene score is the median of four guides, compared against random non-targeting quartets.
* Sensitivity variants: sample exclusion, no centring, mean vs median, and leave-one-guide-out.
* QC checks: barcode collisions, essential-gene dropout (Cas9 editing confirmed [E23]), and a leave-one-out background classifier that recovers every tumour's NTC/STK11 label [E22]. None found a problem.

**Co-culture screen** (`02_coculture_screen.py`): guide-level sums, gene medians, a non-targeting null, and random split-halves of the UMI lineages.

**Glycoproteomics** (`03_glycoproteomics.py`): within-channel glycan-class shares, plus sequon compliance.

**Chemistry and structures** (`04_chemistry_biophysics_structure.py`):

* derived potency and efficiency metrics;
* SPR competition arithmetic and an Rmax check [E39];
* DSF figure-versus-CSV comparison (they agree: ΔTm 2.0, 5.9, 7.4 °C);
* dose-response digitisation and 4-parameter fits;
* crystal-structure contacts, distances, induced fit and crystal contacts (all five structures are well refined: 1.55–2.01 Å, Rfree 0.18–0.22 [E40]).

**Phenotype figures** (`05*_phenotype_digitisation*.py`, `07_phenotype_summary_figure.py`): digitisation and immunoblot densitometry.

**Outputs:**

* tables in `tables/`;
* figures in `figures/`:
  * `fig1_invivo_mgat1_by_arm.png`: per-tumour Mgat1 score by arm [E24, E29, E30]
  * `fig2_invivo_stk11_selectivity.png`: STK11-KO vs STK11-intact gene scores, all 795 genes [E25]
  * `fig3_invivo_arm_inference.png`: marker-gene z-scores used to infer the arms [E28]
  * `fig4_coculture_rank.png`: genome-wide co-culture ranking [E01, E02, E04]
  * `fig5_glycan_composition.png`: glycan-class shares, knockout vs control [E17]
  * `fig6_phenotype_digitised_summary.png`: digitised client phenotype read-outs, including the Bliss comparison [E07, E09, E13, E14]
* the full traceability map in `evidence_ledger.xlsx` (46 entries).
