"""Summary panel of digitised client phenotype read-outs (approximate; n/statistics not provided by client)."""
import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
OUT='/tmp/outputs/'
d = pd.read_csv(OUT+'tables/phenotype_digitised_values.csv')
def v(page, panel_start, arm):
    s = d[(d.figure_page==page)&(d.panel.str.startswith(panel_start))&(d.arm==arm)]
    return float(s.value.iloc[0])
plt.rcParams.update({'font.size':8})
fig, axes = plt.subplots(1,4, figsize=(12,3.3))
# (a) arrayed viability
ax=axes[0]
cond=[('NCI-H1703 E:T 0.2','H1703\nE:T 0.2'),('NCI-H1703 E:T 0.4','H1703\nE:T 0.4'),('NCI-H1755 E:T 0.2','H1755\nE:T 0.2')]
for i,(c,lab) in enumerate(cond):
    ntc=v('p3',c,'sgNTC'); b2m=v('p3',c,'sgB2M'); mg=[v('p3',c,'sgMGAT1_%d'%k) for k in range(1,5)]
    ax.bar(i*4,ntc,color='#9e9e9e'); ax.bar(i*4+1,b2m,color='#2166ac'); ax.bar(i*4+2,np.mean(mg),color='#b2182b')
    ax.scatter([i*4+2]*4,mg,color='k',s=8,zorder=3)
ax.set_xticks([1,5,9]); ax.set_xticklabels([l for _,l in cond]); ax.set_ylabel('relative viability after T cells')
ax.set_title('(a) Arrayed KO (p3)\ngrey sgNTC, blue sgB2M, red 4 sgMGAT1', fontsize=8)
# (b) adoptive transfer
ax=axes[1]
for i,c in enumerate(['Control T cells','NY-ESO-1 TCR T cells 1e6','NY-ESO-1 TCR T cells 2e6']):
    a=v('p4',c,'sgNTC'); b=v('p4',c,'sgMGAT1')
    ax.bar(i*3,a,color='#9e9e9e'); ax.bar(i*3+1,b,color='#b2182b'); ax.text(i*3+0.5,max(a,b)+60,'%+.0f%%'%(100*(b-a)/a),ha='center')
ax.set_ylim(0,2250); ax.set_xticks([0.5,3.5,6.5]); ax.set_xticklabels(['control T','1e6 TCR-T','2e6 TCR-T']); ax.set_ylabel('tumour volume day 19 (mm$^3$)')
ax.set_title('(b) T-cell transfer (p4)\ngrey sgNTC, red sgMGAT1', fontsize=8)
# (c) MC38 WT vs sgSTK11
ax=axes[2]
pairs=[('MC38 WT','p1 left','MC38 WT (STK11-intact), day 25'),('MC38 sgSTK11','p1 middle','MC38 sgSTK11, day 19')]
for i,(lab,pg,pn) in enumerate(pairs):
    a=v(pg,pn,'sgNTC'); b=v(pg,pn,'sgMGAT1')
    ax.bar(i*3,a,color='#9e9e9e'); ax.bar(i*3+1,b,color='#b2182b'); ax.text(i*3+0.5,max(a,b)+60,'%+.0f%%'%(100*(b-a)/a),ha='center')
ax.set_ylim(0,2050); ax.set_xticks([0.5,3.5]); ax.set_xticklabels(['STK11-intact\n(day 25)','Stk11-KO\n(day 19)']); ax.set_ylabel('tumour volume (mm$^3$)')
ax.set_title('(c) MC38 single-gene KO (p1)\nopposite direction by STK11 status', fontsize=8)
# (d) anti-PD-1 combination
ax=axes[3]
pn='MC38 sgSTK11, day 9'
vals=[v('p1 right',pn,'sgNTC + IgG2a'),v('p1 right',pn,'sgNTC + anti-PD-1'),v('p1 right',pn,'sgMGAT1 + IgG2a'),v('p1 right',pn,'sgMGAT1 + anti-PD-1')]
bliss = vals[0]*(vals[1]/vals[0])*(vals[2]/vals[0])
ax.bar(range(4),vals,color=['#9e9e9e','#636363','#ef8a62','#b2182b']); ax.axhline(bliss,ls='--',color='k',lw=0.8); ax.text(3.45,bliss+30,'Bliss\nexpectation',ha='right',fontsize=7)
ax.set_xticks(range(4)); ax.set_xticklabels(['NTC\nIgG','NTC\naPD-1','KO\nIgG','KO\naPD-1']); ax.set_ylabel('tumour volume day 9 (mm$^3$)')
ax.set_title('(d) Stk11-KO MC38 + anti-PD-1 (p1)\nadditive, not synergistic', fontsize=8)
fig.suptitle('Client phenotype figures, digitised (approximate; client did not report n, error-bar type or statistics)', fontsize=9)
plt.tight_layout(); plt.savefig(OUT+'figures/fig6_phenotype_digitised_summary.png', dpi=200); plt.close()
print('bliss expectation', round(bliss))
