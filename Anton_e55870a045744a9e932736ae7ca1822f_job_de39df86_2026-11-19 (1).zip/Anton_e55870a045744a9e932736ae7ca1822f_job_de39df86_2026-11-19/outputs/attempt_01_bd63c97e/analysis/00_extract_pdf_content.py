"""Extract text and embedded figure images from the three client PDFs (run in an env with pypdf, e.g. `mm genomics`)."""
import pypdf, os
IN='/tmp/world/filesystem/'; OUT='/tmp/outputs/analysis/extracted/'
os.makedirs(OUT, exist_ok=True)
for f in ['experimental_records.pdf','assay_figures.pdf','phenotype_figures.pdf']:
    r = pypdf.PdfReader(IN+f)
    with open(OUT+f.replace('.pdf','_text.txt'),'w') as fh:
        for i,p in enumerate(r.pages):
            fh.write('\n--- page %d\n' % (i+1)); fh.write(p.extract_text())
    for i,p in enumerate(r.pages):
        for j,im in enumerate(p.images):
            open(OUT+'%s_p%02d_%d.png' % (f.replace('.pdf',''), i+1, j),'wb').write(im.data)
print(sorted(os.listdir(OUT)))
