"""
TMT intact-glycopeptide data (A375, NCI-H1703; MGAT1-KO vs non-targeting; 4 replicates each).
Input : glycoproteomics_site_quant.xlsx (sheets Site_quant, IGP_quant, IGP_Pep_quant)
Output: tables/glyco_*.csv, figures/fig5_glycan_composition.png
Primary read-out is normalisation-free: for each TMT channel, the share of total glycopeptide intensity carried by each
glycan class (complex/hybrid = HexNAc>=3; sialylated = NeuAc>0; Man5 = HexNAc(2)Hex(5); Man6-9+ = HexNAc(2)Hex>=6).
"""
import pandas as pd, numpy as np, re
from scipy import stats
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
IN='/tmp/world/filesystem/'; OUT='/tmp/outputs/'
x = pd.ExcelFile(IN+'glycoproteomics_site_quant.xlsx')
igp = pd.read_excel(x,'IGP_quant'); site = pd.read_excel(x,'Site_quant'); pep = pd.read_excel(x,'IGP_Pep_quant')
def parse(c):
    d = {'HexNAc':0,'Hex':0,'Fuc':0,'NeuAc':0,'Phospho':0}
    for k,v in re.findall(r'([A-Za-z]+)\((\d+)\)', str(c)): d[k]=d.get(k,0)+int(v)
    return pd.Series(d)
igp = pd.concat([igp, igp['Observed Modification'].apply(parse)], axis=1)
ch = [c for c in igp.columns if c.startswith('Intensity')]
X = igp[ch].astype(float).fillna(0); tot = X.sum()
cls = {'complex/hybrid (HexNAc>=3)': igp.HexNAc>=3, 'sialylated (NeuAc>0)': igp.NeuAc>0,
       'Man5 (HexNAc2Hex5)': (igp.HexNAc==2)&(igp.Hex==5)&(igp.Fuc==0)&(igp.Phospho==0),
       'Man6-9+ (HexNAc2Hex>=6)': (igp.HexNAc==2)&(igp.Hex>=6)&(igp.Fuc==0), 'any fucose': igp.Fuc>0}
share = pd.DataFrame({k:(X[m].sum()/tot*100) for k,m in cls.items()}); share.index=[c.replace('Intensity ','') for c in share.index]
share.round(2).to_csv(OUT+'tables/glyco_class_share_per_channel.csv')
rows=[]
for k in cls:
    for ko,nt,lab in [('AM_KO','AM_N','A375'),('NH_M_KO','NH_N','NCI-H1703')]:
        a = share.loc[[i for i in share.index if i.startswith(ko)],k]; b = share.loc[[i for i in share.index if i.startswith(nt)],k]
        rows.append({'cell_line':lab,'glycan_class':k,'KO_mean_%':round(a.mean(),2),'KO_sd':round(a.std(),2),'NTC_mean_%':round(b.mean(),2),'NTC_sd':round(b.std(),2),
                     'KO/NTC':round(a.mean()/b.mean(),2),'welch_p':stats.ttest_ind(a,b,equal_var=False).pvalue})
summ = pd.DataFrame(rows); summ.to_csv(OUT+'tables/glyco_class_share_summary.csv', index=False); print(summ.to_string())
qc = {'n_sites':len(site),'n_proteins':site['Gene name'].nunique(),'n_intact_glycopeptides':len(igp),'n_PSM_rows':len(pep),
      'channel_total_KO_over_NTC_A375': round(tot[[c for c in ch if 'AM_KO' in c]].mean()/tot[[c for c in ch if 'AM_N' in c]].mean(),2),
      'channel_total_KO_over_NTC_H1703': round(tot[[c for c in ch if 'NH_M_KO' in c]].mean()/tot[[c for c in ch if 'NH_N' in c]].mean(),2)}
# sequon compliance of glyco-N in modified sequences
def seq_ok(m):
    s = re.sub(r'^n\[\d+\]','',m); aa=[]; mods=[]; i=0
    while i<len(s):
        c=s[i]; i+=1; mm=None
        if i<len(s) and s[i]=='[':
            j=s.index(']',i); mm=float(s[i+1:j]); i=j+1
        aa.append(c); mods.append(mm)
    out=[]
    for k,(c,mm) in enumerate(zip(aa,mods)):
        if c=='N' and mm is not None and mm>300:
            if k+2>=len(aa): out.append('undeterminable (C-terminal)')
            elif aa[k+1]!='P' and aa[k+2] in 'ST': out.append('NXS/T')
            else: out.append('non-sequon')
    return out
sq = pd.Series([v for m in pep['Modified Sequence'] for v in seq_ok(m)]).value_counts()
qc.update({'glycoN_at_NXS/T':int(sq.get('NXS/T',0)),'glycoN_non_sequon':int(sq.get('non-sequon',0)),'glycoN_undeterminable':int(sq.get('undeterminable (C-terminal)',0))})
kw = r'Transcription factor|Zinc finger|zinc finger|Histone|ribonucleoprotein|Homeobox|homeobox|Tubulin|Helicase|helicase|nuclear pre-mRNA'
qc['sites_on_nuclear/cytosolic-type_proteins'] = int(site['Protein description'].str.contains(kw, regex=True).sum())
pd.Series(qc).to_csv(OUT+'tables/glyco_QC.csv'); print(pd.Series(qc))
# example proteins
ex = igp[igp['Gene name'].isin(['CD276','TFRC','SLC3A2','BSG'])]
L = np.log2(X.replace(0,np.nan)); L = L - L.median() + L.median().mean()
def m(prefix): return [c for c in ch if c.replace('Intensity ','').startswith(prefix)]
ex = ex.assign(log2FC_A375=(L.loc[ex.index,m('AM_KO')].mean(1)-L.loc[ex.index,m('AM_N')].mean(1)).round(2),
               log2FC_H1703=(L.loc[ex.index,m('NH_M_KO')].mean(1)-L.loc[ex.index,m('NH_N')].mean(1)).round(2))
ex[['Gene name','Position','Observed Modification','log2FC_A375','log2FC_H1703']].to_csv(OUT+'tables/glyco_example_surface_proteins_log2FC_mediannorm.csv', index=False)
# figure
fig, axes = plt.subplots(1,3, figsize=(9,3.2))
for ax, k in zip(axes, ['Man5 (HexNAc2Hex5)','complex/hybrid (HexNAc>=3)','sialylated (NeuAc>0)']):
    for j,(ko,nt,lab) in enumerate([('AM_KO','AM_N','A375'),('NH_M_KO','NH_N','H1703')]):
        a = share.loc[[i for i in share.index if i.startswith(ko)],k]; b = share.loc[[i for i in share.index if i.startswith(nt)],k]
        ax.scatter([j*3]*4, b, color='#636363', s=16); ax.scatter([j*3+1]*4, a, color='#b2182b', s=16)
    ax.set_xticks([0,1,3,4]); ax.set_xticklabels(['NTC','KO','NTC','KO']); ax.set_title(k, fontsize=8)
    ax.text(0.5,-0.22,'A375',transform=ax.get_xaxis_transform(),ha='center',fontsize=7.5); ax.text(3.5,-0.22,'NCI-H1703',transform=ax.get_xaxis_transform(),ha='center',fontsize=7.5)
    ax.set_ylabel('% of channel glycopeptide intensity'); ax.set_ylim(bottom=0)
fig.suptitle('Glycoproteomics: MGAT1 KO doubles Man5 and halves complex/sialylated glycopeptide share (n=4 per arm)', fontsize=8.5)
plt.tight_layout(); plt.savefig(OUT+'figures/fig5_glycan_composition.png', dpi=200); plt.close()
