"""Addendum: bar-chart read-outs from phenotype_figures.pdf p2 (lectins) and p5 (construct panel). Approximate (bar tops incl. dots)."""
import numpy as np, pandas as pd
from PIL import Image
EX='/tmp/outputs/analysis/extracted/'; OUT='/tmp/outputs/'
rows=[]
im = np.array(Image.open(EX+'phenotype_figures_p02_0.png').convert('RGB')).astype(int); r,g,b=im[...,0],im[...,1],im[...,2]
red=(r>140)&(g<80)&(b<80)
def top(mask,x0,x1,y0,y1): ys,xs=np.where(mask[y0:y1,x0:x1]); return ys.min()+y0
# axis calibrations (tick rows found on the y axes): A375 PHA-L 0@449.5,1@266.5 ; A375 GNA 0@440.5,10@161.5 ; H1703 PHA-L 0@946.5,1@757.5 ; H1703 GNA 0@942,10@664.5
for lab,(x0,x1,y0,y1),z,one in [('A375 PHA-L (rel. to sgNTC)',(180,350,150,455),449.5,449.5-266.5),('A375 GNA (rel. to sgNTC)',(590,760,150,455),440.5,(440.5-161.5)/10),
                                 ('NCI-H1703 PHA-L (rel. to sgNTC)',(180,350,640,950),946.5,946.5-757.5),('NCI-H1703 GNA (rel. to sgNTC)',(590,760,640,950),942,(942-664.5)/10)]:
    rows.append(('p2',lab,'sgMGAT1', round((z-top(red,x0,x1,y0,y1))/one,2),'ratio (upper bound incl. replicate dots)'))
# p5 left: PHA-L MFI bar tops (y: 0@758 px, 1e7@350 px)
for lab,val in [('sgNTC Parental',6.79),('sgNTC Vector',6.76),('sgNTC WT cDNA',6.40),('sgNTC D289A cDNA',5.81),('sgNTC D211A+D289A cDNA',5.64),('sgMGAT1 WT cDNA',5.42),
                ('sgMGAT1 Vector',0.0),('sgMGAT1 D289A cDNA',0.0),('sgMGAT1 D211A+D289A cDNA',0.0)]:
    rows.append(('p5 left','PHA-L MFI (x1e6)',lab,val,'x1e6 MFI (bar top; ~0 = at baseline)'))
# p5 right: relative viability with T cells (bar tops; y: 0@772.5, 1@435.5)
for lab,val in [('sgNTC constructs (all 4), T cells','1.07-1.17'),('sgMGAT1 Vector, T cells','0.66-0.68 (dots ~0.72)'),('sgMGAT1 WT cDNA, T cells','1.10-1.11'),
                ('sgMGAT1 D289A cDNA, T cells','0.51-0.53'),('sgMGAT1 D211A+D289A cDNA, T cells','~0.47-0.55')]:
    rows.append(('p5 right','relative viability (no T cells = 1)',lab,val,'ratio'))
out = pd.DataFrame(rows, columns=['figure_page','panel','arm','value','unit']); out['source_file']='phenotype_figures.pdf'; out['method']='digitised from embedded image; approximate'
out.to_csv(OUT+'tables/phenotype_digitised_values_addendum.csv', index=False); print(out.to_string())
