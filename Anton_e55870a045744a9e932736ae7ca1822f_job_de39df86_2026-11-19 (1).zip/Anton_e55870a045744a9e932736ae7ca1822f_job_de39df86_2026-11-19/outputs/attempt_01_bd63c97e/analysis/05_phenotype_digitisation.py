"""
Digitise key read-outs from phenotype_figures.pdf (no underlying numeric files were supplied).
Values are approximate (pixel-level reading of marker centroids against the axis ticks; expect ~±3-5% of axis range).
n per group, error-bar type and statistics are NOT stated in the client figures.
Inputs: analysis/extracted/phenotype_figures_pXX_0.png (from 00_extract_pdf_content.py)
Output: tables/phenotype_digitised_values.csv, tables/stk11_blot_densitometry.csv
"""
import numpy as np, pandas as pd
from PIL import Image
from scipy import ndimage
EX='/tmp/outputs/analysis/extracted/'; OUT='/tmp/outputs/'
def load(p): return np.array(Image.open(EX+p).convert('RGB')).astype(int)
rows=[]
def blobs(mask, erode=7, min_px=4):
    er = ndimage.binary_erosion(mask, structure=np.ones((erode,erode)))
    lab,n = ndimage.label(er); out=[]
    for i in range(1,n+1):
        ys,xs = np.where(lab==i)
        if len(ys)>=min_px: out.append((xs.mean(), ys.mean()))
    return out
# ---------- p1: single-gene MC38 studies ----------
im = load('phenotype_figures_p01_0.png'); r,g,b = im[...,0],im[...,1],im[...,2]
black=(r<60)&(g<60)&(b<60); green=(g>100)&(r<110)&(b<120)&(g>r+40)
def last_point(mask, x0,x1,y0,y1, ypx0, ppu):
    pts = blobs(mask[y0:y1,x0:x1]); pts=[(x+x0,y+y0) for x,y in pts]
    x,y = max(pts); return (ypx0-y)/ppu
rows.append(('p1 left','MC38 WT (STK11-intact), day 25','sgNTC', round(last_point(black,245,840,200,625,628.5,130.17/1000)), 'mm3'))
rows.append(('p1 left','MC38 WT (STK11-intact), day 25','sgMGAT1', round(last_point(green,245,840,200,625,628.5,130.17/1000)), 'mm3'))
rows.append(('p1 middle','MC38 sgSTK11, day 19','sgNTC', round(last_point(black,1104,1700,200,625,628.5,112/500)), 'mm3'))
rows.append(('p1 middle','MC38 sgSTK11, day 19','sgMGAT1', round(last_point(green,1104,1700,200,625,628.5,112/500)), 'mm3'))
# p1 right: values at day 9 (x~2546-2568) read from marker colour bands
def band_center(im, x0,x1,y0,y1, cond):
    sub = im[y0:y1,x0:x1]; ys=[]
    for y in range(sub.shape[0]):
        row = sub[y]; 
        if any(cond(*px) for px in row): ys.append(y+y0)
    return ys
ppu3 = 95.4/500; y03 = 629.5
blk = blobs(black[200:626,2049:2570],5,3); blk=[(x+2049,y+200) for x,y in blk]
rows.append(('p1 right','MC38 sgSTK11, day 9 after treatment start','sgNTC + IgG2a', round((y03-max(blk)[1])/ppu3), 'mm3'))
grn = blobs(green[200:626,2049:2570],5,3); grn=[(x+2049,y+200) for x,y in grn]
rows.append(('p1 right','MC38 sgSTK11, day 9 after treatment start','sgMGAT1 + IgG2a', round((y03-max(grn)[1])/ppu3), 'mm3'))
# grey circle and blue triangle centroids (rows 479-490 and 549-558 at x 2546-2568, identified by colour scan)
rows.append(('p1 right','MC38 sgSTK11, day 9 after treatment start','sgNTC + anti-PD-1', round((y03-484.5)/ppu3), 'mm3'))
rows.append(('p1 right','MC38 sgSTK11, day 9 after treatment start','sgMGAT1 + anti-PD-1', round((y03-553.5)/ppu3), 'mm3'))
# ---------- p3: arrayed co-culture viability (dots) ----------
im = load('phenotype_figures_p03_0.png'); r,g,b = im[...,0],im[...,1],im[...,2]
lb=(b>190)&(r>80)&(r<150)&(g>130)&(g<190); pu=(b>120)&(r<110)&(g<110)&(b>r+40)
def dots(mask,y0,y1,yzero,ppu,minsize=20):
    sub=mask[y0:y1,230:640]; er=ndimage.binary_erosion(sub,structure=np.ones((3,3))); lab,n=ndimage.label(er); out=[]
    for i in range(1,n+1):
        ys,xs=np.where(lab==i)
        if minsize<=len(ys)<=250: out.append((xs.mean()+230,(yzero-(ys.mean()+y0))/ppu))
    return sorted(out)
labels=['sgNTC','sgB2M','sgMGAT1_1','sgMGAT1_2','sgMGAT1_3','sgMGAT1_4']
for title,mask,y0,y1,yz,ppu,xs in [('NCI-H1703 E:T 0.2',lb,100,484,485.5,147.6,[259,329,399,470,540,610]),('NCI-H1703 E:T 0.4',pu,100,484,485.5,147.6,[278,348,418,489,559,629]),('NCI-H1755 E:T 0.2',lb,790,1182,1183.5,186.75,[266,337,408,480,551,622])]:
    d = dots(mask,y0,y1,yz,ppu)
    for lab_,xc in zip(labels,xs):
        vals=[v for x,v in d if abs(x-xc)<12]
        if vals: rows.append(('p3',title+' (relative viability; tumour-only = 1)',lab_, round(float(np.mean(vals)),2),'ratio'))
# ---------- p4: adoptive transfer (day 19) ----------
im = load('phenotype_figures_p04_0.png'); r,g,b = im[...,0],im[...,1],im[...,2]
blue=(b>120)&(r<120)&(b>r+40); red=(r>170)&(g<90)&(b<90)
for title,y0,y1,yz in [('Control T cells',90,366,363.5),('NY-ESO-1 TCR T cells 1e6',520,798,795.5),('NY-ESO-1 TCR T cells 2e6',950,1230,1227.5)]:
    for lab_,mask in [('sgNTC',blue),('sgMGAT1',red)]:
        pts=[(x+150,y+y0) for x,y in blobs(mask[y0:y1,150:480],5,3)]
        d19=[(x,y) for x,y in pts if abs(x-456.8)<6]
        val = (yz-d19[0][1])/0.1024 if d19 else np.nan
        rows.append(('p4',title+', day 19',lab_, round(val) if val==val else 'see note','mm3'))
# red square for control T cells at day 19 overlaps error bars: centroid read manually at y=193.75 px
rows=[x if not (x[0]=='p4' and x[1].startswith('Control') and x[2]=='sgMGAT1') else ('p4','Control T cells, day 19','sgMGAT1', round((363.5-193.75)/0.1024),'mm3 (manual centroid)') for x in rows]
# ---------- p7: in vivo rescue ----------
im = load('phenotype_figures_p07_0.png'); r,g,b = im[...,0],im[...,1],im[...,2]
black=(r<60)&(g<60)&(b<60); blue=(b>100)&(r<110)&(b>r+40)
for title,x0,x1,yz,ppu,xz,ppd in [('sgSTK11 + sgNTC',372,820,638.0,(638-245)/1500,368,(803-368)/20),('sgSTK11 + sgMGAT1',1068,1510,642.0,(642-240)/1500,1064.5,(1499-1064.5)/20)]:
    for lab_,mask in [('MGAT1 WT cDNA',black),('MGAT1 D211A+D289A cDNA',blue)]:
        pts=[(x+x0,y+200) for x,y in blobs(mask[200:636,x0:x1],7,4)]
        if pts:
            x,y=max(pts); rows.append(('p7',title+', last time point (day %.0f)'%((x-xz)/ppd),lab_, round((yz-y)/ppu),'mm3'))
        else:
            rows.append(('p7',title,lab_,'overlaps WT marker (~800 by eye at day 12)','mm3'))
# ---------- p8: STK11 model validation ----------
im = load('phenotype_figures_p08_0.png'); r,g,b = im[...,0],im[...,1],im[...,2]
black=(r<60)&(g<60)&(b<60); grey=(np.abs(r-g)<14)&(np.abs(g-b)<14)&(r>100)&(r<170); green=(g>100)&(r<110)&(g>r+40)&(g>b+20)
for title,x0,x1,yz,ppu,xz,ppd in [('MC38 sgNTC',330,1100,756.5,(756.5-250.5)/1500,325.5,(1084.5-325.5)/10),('MC38 sgSTK11',1516,2280,755.5,(755.5-252.5)/2000,1512.5,(2268.5-1512.5)/10)]:
    for lab_,mask in [('nude',black),('C57BL/6',grey),('C57BL/6 + anti-PD-1',green)]:
        pts=[(x+x0,y+150) for x,y in blobs(mask[150:752,x0:x1],9,4)]
        x,y=max(pts); rows.append(('p8',title+', last time point (day %.0f)'%((x-xz)/ppd),lab_, round((yz-y)/ppu),'mm3'))
out = pd.DataFrame(rows, columns=['figure_page','panel','arm','value','unit'])
out['source_file']='phenotype_figures.pdf'; out['method']='digitised from embedded image; approximate'
out.to_csv(OUT+'tables/phenotype_digitised_values.csv', index=False); print(out.to_string())
# ---------- p6: STK11 immunoblot densitometry ----------
im = np.array(Image.open(EX+'phenotype_figures_p06_0.png').convert('L')).astype(float); inv=255-im
lanes=[377,462,547,632,717,800,885,967,1052]
labs=['Parental','sgNTC','MGAT1 KO','STK11 KO','MGAT1+STK11 KO','STK11 KO + MGAT1 WT cDNA','STK11 KO + MGAT1 mut cDNA','MGAT1+STK11 KO + WT cDNA','MGAT1+STK11 KO + mut cDNA']
def quant(c,ylo,yhi,halfw=32,hh=9):
    col=inv[ylo:yhi,c-halfw:c+halfw]; rr=np.argmax(col.sum(1))+ylo
    reg=inv[rr-hh:rr+hh+1,c-halfw:c+halfw]
    bg=np.median(np.vstack([inv[rr-hh-14:rr-hh-4,c-halfw:c+halfw],inv[rr+hh+4:rr+hh+14,c-halfw:c+halfw]]))
    return reg.sum()-bg*reg.size
vals=[(l,quant(c,395,445),quant(c,570,640,hh=11)) for c,l in zip(lanes,labs)]
p0=vals[0][1]/vals[0][2]
blot=pd.DataFrame([{'lane':l,'STK11/vinculin_relative_to_parental':round(s/v/p0,2)} for l,s,v in vals])
blot.to_csv(OUT+'tables/stk11_blot_densitometry.csv', index=False); print(blot)
