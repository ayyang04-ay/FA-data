"""Builds evidence_ledger.xlsx / .csv: every number cited in the memo -> source file/location -> derivation -> caveat."""
import pandas as pd
OUT='/tmp/outputs/'
T = 'tables/'
L = []
def add(id_, topic, statement, value, source, derivation, kind, caveat=''):
    L.append(dict(ID=id_, topic=topic, statement=statement, value=value, source_data=source, derivation=derivation, evidence_type=kind, caveat=caveat))
# ---------------- Co-culture screen ----------------
add('E01','Co-culture screen','MGAT1 is a top sensitiser to NY-ESO-1 TCR CD8+ T-cell killing in NCI-H1703',
    'rank 12 of 19,114 genes (most depleted); median guide log2FC -0.85; 3/4 guides < -0.5; z = -8.1 vs random non-targeting quartets',
    'coculture_screen_umi_counts.csv.gz (columns tumor_only_untreated, MSCV_TCR_high_24hr)', 'analysis/02_coculture_screen.py -> '+T+'coculture_gene_level.csv, coculture_selected_genes.csv','re-analysis',
    'One sample per condition (records s.3); significance is relative to non-targeting guides, not biological replicates')
add('E02','Co-culture screen','Assay validity: antigen, IFN-gamma and MHC-I genes are the top resistance hits',
    'CTAG1B #1 (+1.57), B2M #2 (+1.31), IFNGR2 #3, CTAG1A #4, TNFRSF1A #5, IFNGR1 #6, STAT1 #7, JAK1 #8 (ranks among 19,114 enriched)',
    'coculture_screen_umi_counts.csv.gz','analysis/02_coculture_screen.py -> '+T+'coculture_selected_genes.csv','re-analysis','CTAG1A/B encode NY-ESO-1 (the TCR antigen)')
add('E03','Co-culture screen','MGAT1 hit reproduces when UMI lineages are split into two random halves',
    'MGAT1 rank 66 and 58 of 19,114 in the two halves (varies slightly with the random split); gene-level split-half r = 0.20',
    'coculture_screen_umi_counts.csv.gz','analysis/02_coculture_screen.py -> '+T+'coculture_gene_level.csv (halfA/halfB columns), coculture_design_QC.csv','re-analysis',
    'Overall split-half correlation is modest (most genes null); strong hits are stable')
add('E04','Co-culture screen','Many other glycosylation genes are equal or stronger sensitisers than MGAT1',
    'SLC35A1 #2, GFPT1 #5, GALE #6, SLC35A2 #7, UGP2 #8, ALG2 #9, CMAS #13, MOGS #15 (MGAT1 #12)',
    'coculture_screen_umi_counts.csv.gz','analysis/02_coculture_screen.py -> '+T+'coculture_selected_genes.csv','re-analysis','Implies phenotype tracks loss of complex/sialylated glycans generally; MGAT1 is one node')
add('E05','Co-culture screen','STK11 knockout has no effect on T-cell killing in NCI-H1703',
    'STK11 median log2FC +0.07; z = +0.7; rank 14,388 of 19,114 (depleted)','coculture_screen_umi_counts.csv.gz','analysis/02_coculture_screen.py -> '+T+'coculture_selected_genes.csv','re-analysis',
    'STK11 status of NCI-H1703 / NCI-H1755 is not documented anywhere in the package')
add('E06','Co-culture screen','Screen design / QC',
    '77,079 guides (~78k per records); reads 56.3 M (tumour only) / 49.9 M (T cells); median 101 UMIs per guide; UMI-level Spearman between arms 0.37; 37% of UMIs detected in tumour-only are absent after T cells',
    'coculture_screen_umi_counts.csv.gz; experimental_records.pdf s.3','analysis/02_coculture_screen.py -> '+T+'coculture_design_QC.csv','re-analysis','UMI-level data too sparse for per-lineage statistics; guide/gene sums used')
# ---------------- Arrayed / phenotype figures ----------------
add('E07','Arrayed validation','Four independent MGAT1 guides (different from the library guides) sensitise two NSCLC lines to T-cell killing',
    'relative viability after co-culture: NCI-H1703 E:T 0.2 sgMGAT1 0.26-0.44 vs sgNTC 0.92, sgB2M 1.85; E:T 0.4 0.25-0.54 vs 0.86 (B2M 1.97); NCI-H1755 E:T 0.2 0.17-0.48 vs 0.79 (B2M 1.84)',
    'phenotype_figures.pdf p3; guide sequences experimental_records.pdf s.1','analysis/05_phenotype_digitisation.py -> '+T+'phenotype_digitised_values.csv','digitised',
    'Approximate (read from image); n and statistics not stated')
add('E08','Lectin phenotype','MGAT1 KO removes complex N-glycans (PHA-L) and raises high-mannose (GNA) in A375 and NCI-H1703',
    'PHA-L ~0.04-0.06 of sgNTC (>=94% loss); GNA ~8-9x sgNTC','phenotype_figures.pdf p2','analysis/05b_phenotype_digitisation_p2_p5.py -> '+T+'phenotype_digitised_values_addendum.csv','digitised','Upper-bound reading incl. replicate dots')
add('E09','In vivo T-cell transfer','MGAT1 KO tumours are controlled by antigen-specific T cells in a dose-dependent way',
    'day 19 (sgNTC vs sgMGAT1): control T cells ~1,930 vs ~1,660 mm3 (-14%); 1e6 NY-ESO-1 T cells ~1,300 vs ~620 (-53%); 2e6 ~600 vs ~150 (-75%)',
    'phenotype_figures.pdf p4','analysis/05_phenotype_digitisation.py -> '+T+'phenotype_digitised_values.csv','digitised',
    'Cell line, host strain, n, error-bar type and statistics not stated')
add('E10','Catalytic dependence (cells)','WT MGAT1 cDNA restores PHA-L and T-cell resistance in MGAT1-KO cells; catalytic mutants do not',
    'PHA-L MFI: sgMGAT1+WT 5.4e6 vs sgNTC parental 6.8e6; sgMGAT1 + vector/D289A/D211A+D289A ~0. Viability with T cells: sgMGAT1 vector ~0.7, +WT ~1.1, +D289A ~0.5, +D211A+D289A ~0.5; all sgNTC constructs 1.07-1.17',
    'phenotype_figures.pdf p5','analysis/05b_phenotype_digitisation_p2_p5.py -> '+T+'phenotype_digitised_values_addendum.csv','digitised',
    'Cell line not labelled on p5; the matching construct panel blot on p11 is NCI-H1703')
add('E11','Catalytic dependence (expression)','Catalytic mutants are expressed at least as well as WT (rules out loss-of-expression)',
    'MGAT1 immunoblot: WT, D289A, D211A+D289A bands strong in both sgNTC and sgMGAT1 backgrounds; sgMGAT1 vector band absent; endogenous band weak',
    'phenotype_figures.pdf p11 (NCI-H1703)','visual inspection','client-reported (figure)','Spliced panels (boxed); overexpression far above endogenous')
add('E12','Catalytic dependence (in vivo)','In Stk11-KO MC38 lacking MGAT1, catalytic activity is needed for tumour growth; no dominant-negative effect when endogenous MGAT1 present',
    'sgSTK11+sgMGAT1: WT cDNA ~860 vs D211A+D289A ~420 mm3 (day 18-19, -51%); sgSTK11+sgNTC: WT ~890 vs mutant ~800 (day 12, overlapping)',
    'phenotype_figures.pdf p7','analysis/05_phenotype_digitisation.py -> '+T+'phenotype_digitised_values.csv','digitised',
    'MGAT1-KO line is a single clone (A-F5) per p11 schematic; n/stats not stated')
add('E13','Single-gene MC38 studies','MGAT1 KO slows Stk11-KO MC38 but accelerates STK11-intact MC38',
    'MC38 WT day 25: sgNTC ~1,160 vs sgMGAT1 ~1,780 mm3 (+52%); MC38 sgSTK11 day 19: ~1,090 vs ~540 (-50%)',
    'phenotype_figures.pdf p1 (left, middle)','analysis/05_phenotype_digitisation.py -> '+T+'phenotype_digitised_values.csv','digitised',
    'Large overlapping error bars; n/stats not stated; possible clone-vs-pool confound')
add('E14','Single-gene anti-PD-1 combination','Combination is additive (Bliss), not synergistic',
    'day 9: sgNTC+IgG2a ~1,140; sgNTC+anti-PD-1 ~760 (0.67x); sgMGAT1+IgG2a ~620 (0.55x); sgMGAT1+anti-PD-1 ~400 (0.35x); Bliss-independence expectation 0.67x0.55 = 0.36x (~415 mm3)',
    'phenotype_figures.pdf p1 (right)','analysis/05_phenotype_digitisation.py -> '+T+'phenotype_digitised_values.csv; Bliss arithmetic in memo','digitised + calculation',
    'Error bars overlap; n/stats not stated; combination tumours still grew (~50 -> ~400 mm3)')
add('E15','STK11 model validity','Stk11 loss abolishes immune control of MC38 and blunts anti-PD-1',
    'sgNTC day 8: nude ~930, C57BL/6 ~380, +anti-PD-1 ~85 mm3; sgSTK11 day 7: nude ~965, C57BL/6 ~1,290, +anti-PD-1 ~630',
    'phenotype_figures.pdf p8','analysis/05_phenotype_digitisation.py -> '+T+'phenotype_digitised_values.csv','digitised','Caption says "additional cohorts"; p1 caption says "library-containing populations" - captions appear swapped')
add('E16','STK11 knockout integrity','STK11 protein re-emerges in the cDNA-rescue derivative lines',
    'STK11/vinculin vs parental: STK11-KO 0.04, double KO 0.07; rescue lines 0.13, 0.20, 0.06, 0.16',
    'phenotype_figures.pdf p6 (MC38 immunoblot)','analysis/05_phenotype_digitisation.py -> '+T+'stk11_blot_densitometry.csv','digitised (densitometry of figure image)',
    'Image densitometry is semi-quantitative; vinculin not in the records antibody list')
# ---------------- Glycoproteomics ----------------
add('E17','Glycoproteomics','MGAT1 KO doubles Man5 and halves complex/sialylated glycopeptide share in both lines',
    'Share of channel glycopeptide intensity (KO vs NTC, n=4 each): Man5 40.1 vs 19.9% (A375), 40.4 vs 18.8% (H1703); complex/hybrid 5.5 vs 9.9%, 5.1 vs 9.1%; sialylated 2.2 vs 4.9%, 1.9 vs 4.0%; all Welch p < 1e-5',
    'glycoproteomics_site_quant.xlsx sheet IGP_quant','analysis/03_glycoproteomics.py -> '+T+'glyco_class_share_summary.csv, glyco_class_share_per_channel.csv','re-analysis',
    'Residual ~5% complex share in KO likely reflects TMT ratio compression and/or incomplete KO pools')
add('E18','Glycoproteomics QC','Assignments are sequon-compliant; a few implausible proteins; KO channel totals higher',
    'glyco-N at N-X-S/T in 3,560/3,560 determinable PSM sites (220 undeterminable at C-terminus); 23 of 910 sites on nuclear/cytosolic-type proteins; KO/NTC channel total intensity 1.64 (A375), 1.55 (H1703)',
    'glycoproteomics_site_quant.xlsx (IGP_Pep_quant, Site_quant, IGP_quant)','analysis/03_glycoproteomics.py -> '+T+'glyco_QC.csv','re-analysis','Composition shares used because absolute fold changes depend on normalisation')
# ---------------- In vivo screen ----------------
add('E19','In vivo screen design','Library and sample structure',
    '3,580 guides = 795 genes x 4 + 400 non-targeting; 141 tumour samples with 141 unique animal IDs; 4 groups per background (NTC 18/17/15/21; STK11 17/17/18/18); 24 runs; no barcode collisions',
    'crispr_invivo_guide_counts.csv.gz; crispr_invivo_ngs_demux.csv.gz; experimental_records.pdf s.2-2.2','analysis/01_invivo_screen.py -> '+T+'invivo_design_summary.csv','re-analysis','')
add('E20','In vivo screen design','Records describe 3 arms and 45 mice (90 if read as per background); the matrix has 4 groups per background and 141 tumours; no group-to-arm key',
    'records: C57BL/6 n = 30, nude n = 15, arms nude / IgG2a / anti-PD-1 (+ in vitro); matrix: Group1-4 (NTC), Group5-8 (STK11)',
    'experimental_records.pdf s.2 and table 2.1','comparison of records vs file','discrepancy','Must be resolved by the client before any arm-specific claim')
add('E21','In vivo screen design','Low library coverage at implantation',
    '100,000 cells implanted / 3,580 guides = ~28 cells per guide; median 4.3% of guides at zero per tumour (implies ~3 founder cells per guide per tumour)',
    'experimental_records.pdf s.2; count matrix','analysis/01_invivo_screen.py -> '+T+'invivo_design_summary.csv','re-analysis / inference','Per-tumour guide counts are noisy; conclusions rest on aggregation across tumours')
add('E22','In vivo screen QC','One failed and two bottlenecked tumours; background labels internally consistent',
    'Group7_STK11_82431: 349 total reads, 91% guides at zero (excluded); Group3_NTC_82276 45% and Group4_NTC_82321 33% guides at zero (kept; sensitivity analysis); leave-one-out classifier recovers all 140 NTC/STK11 labels (0 mismatches)',
    'crispr_invivo_guide_counts.csv.gz','analysis/01_invivo_screen.py -> '+T+'invivo_sample_QC.csv, invivo_background_label_check.csv','re-analysis','Label check tests background (NTC vs STK11) only; group/arm labels cannot be checked without the key')
add('E23','In vivo screen QC','Cas9 editing is active before implantation (essential-gene guides already depleted at baseline)',
    'Baseline vs plasmid log2FC: Rpl3 -5.5, Pcna -5.3, Plk1 -5.1, Rps6 -4.7, Rpl5 -4.5, Kif11 -3.7, Metap2 -3.5, Lars -3.3, Mtor -3.2 (NTC background)',
    'crispr_invivo_guide_counts.csv.gz','analysis/01_invivo_screen.py -> '+T+'invivo_essential_gene_dropout_QC.csv','re-analysis','')
add('E24','In vivo screen: STK11 selectivity','Mgat1 KO is depleted far more in Stk11-KO than STK11-intact tumours in the immunocompetent-like arms',
    'mean Mgat1 score G6-G8 (Stk11-KO) -3.68 vs G2-G4 (NTC) -0.90 log2; delta -2.78 (~6.9-fold); Mann-Whitney p = 2.2e-14 (52 vs 53 tumours); 100% vs 47% of tumours below -1',
    'crispr_invivo_guide_counts.csv.gz','analysis/01_invivo_screen.py -> '+T+'invivo_Mgat1_statistics.csv','re-analysis',
    'Arm labels inferred (see E28); the comparison pools the three immunocompetent-like arms per background')
add('E25','In vivo screen: STK11 selectivity','Mgat1 is the #1 and B4galt1 the #2 most Stk11-selective depletion of 795 genes',
    'Mgat1 delta -2.78; B4galt1 delta -2.04 (next genes Itgb1 -1.32, Mtor -1.27)','crispr_invivo_guide_counts.csv.gz','analysis/01_invivo_screen.py -> '+T+'invivo_gene_scores_by_group.csv (rank_STK11_selective)','re-analysis','')
add('E26','In vivo screen: robustness','STK11-vs-NTC difference survives analysis variants',
    'delta -2.11 to -3.51 log2, all p <= 5e-10: excluding bottlenecked tumours, no non-targeting centring, mean instead of median, dropping any one guide',
    'crispr_invivo_guide_counts.csv.gz','analysis/01_invivo_screen.py -> '+T+'invivo_Mgat1_robustness.csv','re-analysis','')
add('E27','In vivo screen: guides','Three of four Mgat1 guides drive the signal; the validation guide is also depleted in STK11-intact tumours',
    'Stk11-KO immunocompetent-like arms: Mgat1_1 -4.3 to -4.4, Mgat1_2 -4.1 to -4.5, Mgat1_4 -4.2 to -4.7, Mgat1_3 -0.3 to -1.2; Mgat1_4 (= sgMGAT1_4 used for the single-gene MC38 lines) in NTC arms -1.4 to -2.7',
    'crispr_invivo_guide_counts.csv.gz; experimental_records.pdf s.1 (guide sequences)','analysis/01_invivo_screen.py -> '+T+'invivo_Mgat1_per_guide_by_group.csv','re-analysis','')
add('E28','In vivo screen: arm inference','G1/G5 lack T-cell/IFN-gamma-type selection (presumptive nude arms); G2/G6 show PD-L1-KO depletion (consistent with PD-1 axis intact)',
    'z-scores: Ptpn2 G1 -0.1 / G5 -1.0 vs -4.2 to -9.8 elsewhere; Jak1 G1 -2.1 / G5 -1.5 vs -7.2 to -13.7; Cd274 G2 -11.7, G6 -3.5, all others -1.8 to +1.4',
    'crispr_invivo_guide_counts.csv.gz','analysis/01_invivo_screen.py -> '+T+'invivo_arm_inference_markers_z.csv; figures/fig3','inference',
    'Inference only - the client has not supplied a group key')
add('E29','In vivo screen: immune dependence','About 60% of the Mgat1 depletion in Stk11-KO tumours is present in the arm without T-cell-type selection',
    'G5 -2.23 vs G6-G8 -3.68 (ratio 0.61; 0.57-0.72 across variants); T-cell-dependent share within Stk11-KO: -1.45 (p = 1.6e-4); no T-cell-dependent share in STK11-intact tumours (G2-G4 -0.90 vs G1 -1.33; +0.43, p = 0.07); G5 vs G1 -0.90 (p = 0.017)',
    'crispr_invivo_guide_counts.csv.gz','analysis/01_invivo_screen.py -> '+T+'invivo_Mgat1_statistics.csv, invivo_Mgat1_robustness.csv','re-analysis + inference','Depends on G5/G1 being the T-cell-deficient arms (E28); G1 is heavily bottlenecked (median Gini 0.79), so the NTC-side estimate is normalisation-sensitive')
add('E30','In vivo screen: anti-PD-1','No arm-to-arm difference in Mgat1 depletion among the immunocompetent-like arms',
    'Stk11-KO: G6 -3.77, G7 -3.59, G8 -3.69 (Kruskal-Wallis p = 0.69); NTC: G2 -1.28, G3 -0.89, G4 -0.61 (p = 0.14)',
    'crispr_invivo_guide_counts.csv.gz','analysis/01_invivo_screen.py -> '+T+'invivo_Mgat1_statistics.csv','re-analysis','Holds whichever of G6-G8 received anti-PD-1')
add('E31','In vivo screen: in vitro component','A small Stk11-selective Mgat1 fitness cost exists in vitro',
    'Endpoint STK11 vs Endpoint NTC -0.67 (z -2.2; rank 31/795); Endpoint STK11 vs plasmid -0.80 (z -3.2); Endpoint NTC vs plasmid -0.14 (z -0.5)',
    'crispr_invivo_guide_counts.csv.gz','analysis/01_invivo_screen.py -> '+T+'invivo_Mgat1_in_vitro_components.csv','re-analysis','')
# ---------------- Chemistry / biophysics ----------------
add('E32','Compound registry','Potency, binding and in vitro ADME as reported',
    'ANT-4267: IC50 0.043 uM; KD 0.07 (steady state) / 0.03 (kinetic) uM; solubility 96.4 uM; Clint <1.35 ul/min/1e6 cells; MW 478; logD 2.6; TPSA 108. ANT-3744: IC50 0.814 uM; KD 0.38/0.38 uM; solubility 178 uM; Clint 3.2; MW 419; logD 2.2; TPSA 110. ANT-0592 (purchased hit): IC50 197 uM; KD 32.2 uM*; solubility 11.8 uM; Clint 54.4',
    'compound_properties.csv; experimental_records.pdf s.8 (units)','read directly','client-reported','logD and TPSA are calculated values (records s.8); hepatocyte species and ADME methods not stated; no structure supplied for ANT-4267, ANT-0592 or other analogues (ANT-3744 structure from the CIF ligand definition)')
add('E33','Compound metrics','Derived efficiency metrics',
    'LipE (pIC50 - logD): ANT-0592 1.1, ANT-3744 3.9, ANT-4267 4.8; IC50/KD(ss): 6.1, 2.1, 0.6; ANT-3744 LE 0.28 kcal/mol/heavy atom (31 heavy atoms)',
    'compound_properties.csv; MGAT1_C3744.cif (formula C23H25N5O3)','analysis/04_chemistry_biophysics_structure.py -> '+T+'chem_compound_metrics.csv','re-analysis','LipE uses the client-calculated logD; ANT-0592 potency is solubility-limited')
add('E34','SPR competition','ANT-3744 does not compete with UDP (binds simultaneously)',
    'UDP KD 32 uM alone vs 20 uM with 20 uM ANT-3744 (1,632 uM expected if competitive); ANT-3744 KD 0.4 uM alone vs 0.2 uM with 5 mM UDP (63 uM expected if competitive)',
    'spr_competition.csv; spr_binding.csv; experimental_records.pdf s.6.4','analysis/04_chemistry_biophysics_structure.py -> '+T+'chem_spr_competition_logic.csv','re-analysis (calculation)','Tested with UDP, not UDP-GlcNAc; no competition data vs the acceptor')
add('E35','DSF','Thermal shifts are additive; CSV agrees with the figure',
    'CSV delta-Tm: UDP +2, ANT-3744 +6, both +8 C; figure-derived: Tm(DMSO) 49.4 C, +2.0, +5.9, +7.4 C',
    'dsf_thermal_shift.csv; assay_figures.pdf p4','analysis/04_chemistry_biophysics_structure.py -> '+T+'chem_dsf_figure_vs_csv.csv','re-analysis / digitised','')
add('E36','Enzyme assay documentation','Plotted concentration range for 5 of 6 dose-responses is 10x the documented top concentration',
    'ANT-0592, -1476, -3105, -3744 plotted 0.05-~1,020 uM (ANT-2118 >=335 uM; top point on axis); ANT-4267 0.005-101 uM; documented: 10-point 3-fold, top 100 uM, 10 mM DMSO stocks, 0.5 ul dispense into 7 ul (max attainable ~667 uM at 6.7% DMSO)',
    'assay_figures.pdf p1; experimental_records.pdf s.6.3','analysis/04_chemistry_biophysics_structure.py -> '+T+'chem_ic50_plotted_range_vs_protocol.csv','digitised + calculation',
    'Reported IC50s match the plotted curves; raw plate data needed to resolve')
add('E37','Hit quality','The purchased hit was measured above its solubility',
    'ANT-0592 IC50 = 16.7x and KD = 2.7x its kinetic solubility (11.8 uM); marked "*" in registry and plot',
    'compound_properties.csv; assay_figures.pdf p5','analysis/04_chemistry_biophysics_structure.py -> '+T+'chem_compound_metrics.csv','re-analysis','')
add('E38','Acquired compounds','ANT-1938 and ANT-2214 show no specific binding',
    'ANT-1938: IC50 >100 uM (40% inhibition, n=2), no SPR response; ANT-2214: IC50 74 uM (60% inhibition at top dose, n=2), non-saturable SPR response that does not dissociate; structure contains catechol and N-amino-imine motifs',
    'assay_figures.pdf p2; compound_properties.csv','visual inspection','client-reported (figure)','Set aside as non-binders / probable assay interference')
add('E39','SPR surface check','Rmax consistent with 1:1 binding on the competition surface; direct-binding surfaces differ',
    'theoretical 1:1 Rmax (~44 kDa ligand): ANT-3744 ~85 RU at 9,000 RU vs ~115-120 observed; UDP ~82 RU vs ~9-10 observed; ANT-3744 on 3,500 RU surface ~33 RU vs ~32-33 observed',
    'assay_figures.pdf p2-p3; experimental_records.pdf s.6.1, 6.4','analysis/04_chemistry_biophysics_structure.py -> '+T+'chem_spr_rmax_check.csv','calculation + digitised','Ligand MW approximated (crystal construct 41.6 kDa + Avi tag/linker); KD values, not Rmax, are relied on')
# ---------------- Structures ----------------
add('E40','Crystallography','Five well-refined structures',
    'resolution 1.55-2.01 A; Rwork/Rfree 0.15-0.17 / 0.18-0.22; C3744 modelled at full occupancy in all 4 copies (B 30-38 A^2; 60 A^2 in ternary chain B)',
    'MGAT1_*.cif headers','analysis/04_chemistry_biophysics_structure.py -> '+T+'struct_refinement_summary.csv, struct_ligands.csv','re-analysis','')
add('E41','Crystallography','ANT-3744 binds an induced pocket at the C-terminal segment, far from the donor site',
    'pocket residues Y388 T389 G390 F394 G410 P412 P434 W437 E438 G439 Y440 D441 (P442) W444 in all 4 copies; W437 moves 5.1-5.5 A and E438 8.1-8.4 A vs apo; ligand is 23.9-24.2 A from UDP, 25.8-26.2 A from Mn, ~16 A from D289',
    'MGAT1_C3744.cif, MGAT1_C3744_UDP.cif, MGAT1_apo.cif','analysis/04_chemistry_biophysics_structure.py -> '+T+'struct_C3744_contacts.csv, struct_key_distances.csv, struct_induced_fit.csv','re-analysis','No acceptor-bound structure, so the inhibition mechanism is not established')
add('E42','Crystallography','Each bound ligand also touches a symmetry-related molecule',
    'contacts 3.0-3.9 A to E274/E278 or E133 of a neighbouring molecule; ligand-bound crystals have a longer c axis (136.8-138.9 A vs 128.5-129.5 A)',
    'MGAT1_C3744.cif, MGAT1_C3744_UDP.cif','analysis/04_chemistry_biophysics_structure.py -> '+T+'struct_C3744_contacts.csv, struct_refinement_summary.csv','re-analysis','Pocket should be confirmed in solution (mutagenesis + SPR)')
add('E43','Crystallography','The rescue mutants target the right residues',
    'D211 coordinates Mn (2.15-2.25 A); D289 is 4.55 A from the GlcNAc anomeric carbon of UDP-GlcNAc',
    'MGAT1_C3744_UDP.cif; MGAT1_UDP_GlcNAc.cif','analysis/04_chemistry_biophysics_structure.py -> '+T+'struct_key_distances.csv','re-analysis','Mutant enzyme activity data described in records s.6.2 but not supplied')
add('E46','Enzyme assay','Reported IC50s agree with the plotted curves; maximal biochemical inhibition plateaus at ~90% for the synthesised series',
    'absolute IC50 from 4-parameter fits to digitised points vs reported: ANT-0592 199 vs 197, ANT-1476 1.8 vs 2.02, ANT-2118 21 vs 25.6, ANT-3105 0.43 vs 0.543, ANT-3744 0.60 vs 0.814, ANT-4267 0.037 vs 0.043 uM (within 1.4-fold); fitted bottom (residual activity): ANT-1476 8%, ANT-3105 9%, ANT-3744 8%, ANT-4267 10%',
    'assay_figures.pdf p1','analysis/04_chemistry_biophysics_structure.py -> tables/chem_ic50_digitised_fits.csv','digitised + fit',
    'May be assay background rather than incomplete inhibition - needs an orthogonal readout')
# ---------------- Records / documentation ----------------
add('E44','Documentation','Minor record inconsistencies',
    'DSF protein "18.6 nM ... (9.3 uM final)"; SPR association 60 s in records vs ~100 s in several sensorgrams; vinculin used on p6 but not in antibody list; "ITC" control guide ATTTGTAACATCTCTTCACG = POLB_2 in the client human library; DSF legend "HTS ANT-3744" vs registry "synthesised"; PDF creation dates 18 Nov 2026 vs 1 Nov 2026 data cut; D211A single mutant described but not shown',
    'experimental_records.pdf; assay_figures.pdf p2-p4; phenotype_figures.pdf p6; coculture_screen_umi_counts.csv.gz; PDF metadata','cross-checks (analysis/00_extract_pdf_content.py)','discrepancy','Low impact individually')
add('E45','Documentation','IC50-vs-KD correlation plot cannot be reproduced from the registry',
    '~25 compounds plotted; only 3 (ANT-0592, ANT-3744, ANT-4267) have both IC50 and KD in compound_properties.csv',
    'assay_figures.pdf p5; compound_properties.csv','comparison','discrepancy','Used qualitatively only')
led = pd.DataFrame(L)
led = led.sort_values('ID', key=lambda c: c.str[1:].astype(int)).reset_index(drop=True)
led.to_csv(OUT+'evidence_ledger.csv', index=False)
with pd.ExcelWriter(OUT+'evidence_ledger.xlsx', engine='openpyxl') as xw:
    led.to_excel(xw, sheet_name='ledger', index=False)
    ws = xw.sheets['ledger']
    widths = {'A':6,'B':24,'C':60,'D':80,'E':45,'F':55,'G':18,'H':50}
    for k,v in widths.items(): ws.column_dimensions[k].width = v
    from openpyxl.styles import Alignment, Font
    for row in ws.iter_rows(min_row=1):
        for c in row: c.alignment = Alignment(wrap_text=True, vertical='top')
    for c in ws[1]: c.font = Font(bold=True)
    ws.freeze_panes = 'A2'
print(len(led), 'ledger entries written')
