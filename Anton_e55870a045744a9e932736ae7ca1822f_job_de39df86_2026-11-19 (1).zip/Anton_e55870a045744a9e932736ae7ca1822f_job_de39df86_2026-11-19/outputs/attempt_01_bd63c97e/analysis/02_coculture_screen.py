"""
Genome-wide NCI-H1703 x NY-ESO-1 TCR CD8+ T-cell co-culture screen - independent re-analysis.
Input : coculture_screen_umi_counts.csv.gz (one sample per condition; rows = guide x UMI lineage)
Output: tables/coculture_*.csv, figures/fig4_coculture_rank.png
Approach: sum UMI counts per guide; CPM; log2((CPM_Tcell+0.5)/(CPM_tumour_only+0.5)); centre on non-targeting guides;
gene score = median of 4 guides; null = random quartets of non-targeting guides; split-half (random UMI halves) reproducibility.
"""
import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
IN='/tmp/world/filesystem/'; OUT='/tmp/outputs/'
df = pd.read_csv(IN+'coculture_screen_umi_counts.csv.gz', dtype={'umi_barcode':str})
design = {'umi_rows':len(df), 'guides':df.sgrna_id.nunique(), 'genes_incl_controls':df.gene_symbol.nunique(),
          'reads_tumour_only':int(df.tumor_only_untreated.sum()), 'reads_Tcell_24h':int(df.MSCV_TCR_high_24hr.sum()),
          'median_UMIs_per_guide':float(df.groupby('sgrna_id').size().median()),
          'frac_UMIs_lost_in_Tcell_arm':round(((df.tumor_only_untreated>0)&(df.MSCV_TCR_high_24hr==0)).mean(),3),
          'UMI_level_spearman_between_arms':round(df[['tumor_only_untreated','MSCV_TCR_high_24hr']].corr(method='spearman').iloc[0,1],3)}
g = df.groupby(['gene_symbol','sgrna_id','sgrna_sequence','genetype'], observed=True)[['tumor_only_untreated','MSCV_TCR_high_24hr']].sum().reset_index()
c0 = g.tumor_only_untreated/g.tumor_only_untreated.sum()*1e6; c1 = g.MSCV_TCR_high_24hr/g.MSCV_TCR_high_24hr.sum()*1e6
g['lfc'] = np.log2((c1+0.5)/(c0+0.5))
ctrl = g.genetype.isin(['NegCtrl','NegCtrlIntron'])
g['lfc'] -= g.loc[ctrl,'lfc'].median()
gene = g[~ctrl].groupby('gene_symbol').agg(n_guides=('lfc','size'), lfc_median=('lfc','median'), lfc_mean=('lfc','mean'),
        guides_below_m0p5=('lfc', lambda x:int((x<-0.5).sum())), guides_above_0p5=('lfc', lambda x:int((x>0.5).sum())), reads_tumour_only=('tumor_only_untreated','sum'))
gene['rank_depleted'] = gene.lfc_median.rank(method='min').astype(int)
gene['rank_enriched'] = (-gene.lfc_median).rank(method='min').astype(int)
rng = np.random.default_rng(0)
nt = g.loc[ctrl,'lfc'].values
null = np.array([np.median(rng.choice(nt,4,replace=False)) for _ in range(100000)])
gene['z_vs_nontargeting_quartets'] = (gene.lfc_median-null.mean())/null.std()
# split-half
df['half'] = rng.integers(0,2,len(df))
halves = {}
for h in [0,1]:
    s = df[df.half==h].groupby(['gene_symbol','sgrna_id','genetype'])[['tumor_only_untreated','MSCV_TCR_high_24hr']].sum().reset_index()
    a = s.tumor_only_untreated/s.tumor_only_untreated.sum()*1e6; b = s.MSCV_TCR_high_24hr/s.MSCV_TCR_high_24hr.sum()*1e6
    s['lfc'] = np.log2((b+0.5)/(a+0.5)); cc = s.genetype.isin(['NegCtrl','NegCtrlIntron']); s['lfc'] -= s.loc[cc,'lfc'].median()
    halves[h] = s[~cc].groupby('gene_symbol').lfc.median()
H = pd.DataFrame(halves)
gene['halfA_lfc'] = H[0]; gene['halfB_lfc'] = H[1]
gene['halfA_rank_depleted'] = H[0].rank(method='min').astype(int); gene['halfB_rank_depleted'] = H[1].rank(method='min').astype(int)
design['gene_level_split_half_pearson'] = round(H[0].corr(H[1]),3)
gene.sort_values('lfc_median').round(3).to_csv(OUT+'tables/coculture_gene_level.csv')
pd.Series(design).to_csv(OUT+'tables/coculture_design_QC.csv')
print(pd.Series(design))
show = ['CFLAR','SLC35A1','PTPN2','MEN1','GFPT1','GALE','SLC35A2','UGP2','ALG2','MGAT1','CMAS','MOGS','TMEM165','UAP1','GNPNAT1','COG4',
        'CTAG1B','B2M','IFNGR2','CTAG1A','TNFRSF1A','IFNGR1','STAT1','JAK1','IRF1','JAK2','CD58','TAP1','TAP2','CASP8','FAS',
        'STK11','CD274','MGAT2','MGAT5','B4GALT1','MAN2A1']
gene.loc[show, ['lfc_median','guides_below_m0p5','guides_above_0p5','rank_depleted','rank_enriched','z_vs_nontargeting_quartets','halfA_rank_depleted','halfB_rank_depleted']].round(2).to_csv(OUT+'tables/coculture_selected_genes.csv')
print(gene.loc[show, ['lfc_median','rank_depleted','rank_enriched','z_vs_nontargeting_quartets','halfA_rank_depleted','halfB_rank_depleted']].round(2).to_string())
# figure
plt.rcParams.update({'font.size':9})
srt = gene.sort_values('lfc_median').reset_index()
fig, ax = plt.subplots(figsize=(7,4))
ax.scatter(np.arange(len(srt)), srt.lfc_median, s=2, color='#bdbdbd', rasterized=True)
glyco = ['SLC35A1','GFPT1','GALE','SLC35A2','UGP2','ALG2','MGAT1','CMAS','MOGS','TMEM165','UAP1','GNPNAT1','COG4']
ctrls = ['CTAG1B','CTAG1A','B2M','IFNGR2','IFNGR1','STAT1','JAK1','JAK2','TNFRSF1A']
for nm, col in [(glyco,'#e08214'),(ctrls,'#2166ac'),(['PTPN2','CFLAR'],'#1b7837'),(['MGAT1'],'#b2182b'),(['STK11'],'k')]:
    sub = srt[srt.gene_symbol.isin(nm)]
    ax.scatter(sub.index, sub.lfc_median, s=18, color=col, zorder=3)
for nm in ['MGAT1','CFLAR','PTPN2','SLC35A1','CTAG1B','B2M','STK11']:
    r = srt[srt.gene_symbol==nm].iloc[0]
    ax.annotate(nm, (r.name, r.lfc_median), fontsize=7, xytext=(8 if r.name<10000 else -40, 6 if nm=='STK11' else 0), textcoords='offset points')
ax.axhline(0,color='k',lw=0.5)
ax.set_xlabel('genes ranked by median guide log2 FC (T cells vs tumour only)'); ax.set_ylabel('median guide log2 FC')
ax.set_title('Co-culture screen (NCI-H1703, NY-ESO-1 TCR T cells; n=1 per arm)\nMGAT1 #12/19,114 sensitiser; orange = other glycosylation genes; blue = antigen/IFN-γ/MHC controls', fontsize=8)
plt.tight_layout(); plt.savefig(OUT+'figures/fig4_coculture_rank.png', dpi=200); plt.close()
