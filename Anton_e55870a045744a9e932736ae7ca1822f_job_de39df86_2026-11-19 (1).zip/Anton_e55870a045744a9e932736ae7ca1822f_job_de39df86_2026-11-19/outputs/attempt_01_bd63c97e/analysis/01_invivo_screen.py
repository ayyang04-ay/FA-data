"""
In vivo pooled CRISPR screen (MC38, NTC vs Stk11-KO background) - independent re-analysis.
Input : crispr_invivo_guide_counts.csv.gz, crispr_invivo_ngs_demux.csv.gz
Output: tables/invivo_*.csv, figures/fig1_invivo_mgat1_by_arm.png, figures/fig2_invivo_stk11_selectivity.png
Approach (high level):
  * CPM normalisation per sample, log2(CPM+1)
  * per-guide log2 fold change of each tumour vs the mean of its own background's Baseline samples
  * each tumour centred on its median non-targeting-guide LFC (corrects bottleneck-driven skew)
  * gene score per tumour = median of the 4 guide LFCs
  * group statistics across tumours; null = random quartets of non-targeting guides
  * failed sample Group7_STK11_82431 (349 total reads) excluded
"""
import pandas as pd, numpy as np
from scipy import stats
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
IN = '/tmp/world/filesystem/'
OUT = '/tmp/outputs/'
df = pd.read_csv(IN+'crispr_invivo_guide_counts.csv.gz')
demux = pd.read_csv(IN+'crispr_invivo_ngs_demux.csv.gz')
cols = list(df.columns[3:])
cnt = df[cols].astype(float)
genes = df.gene_symbol.values
is_ntc = df.gene_sgrna_id.str.startswith('NegCtrl').values
def grp(c):
    if c.startswith('Group'): return c.rsplit('_',1)[0]
    if c.startswith('Plasmid'): return 'Plasmid'
    return '_'.join(c.split('_')[:2])
G = pd.Series({c:grp(c) for c in cols})

# ---------------- QC ----------------
def gini(x):
    x = np.sort(np.asarray(x, float)); n=len(x)
    if x.sum()==0: return np.nan
    cum = np.cumsum(x); return (n+1-2*np.sum(cum)/cum[-1])/n
qc = pd.DataFrame({'group':G, 'total_reads':cnt.sum(), 'guides_detected':(cnt>0).sum(),
                   'frac_guides_zero':(cnt==0).mean().round(4), 'gini':[round(gini(cnt[c]),3) for c in cols]})
qc['flag'] = ''
qc.loc[qc.total_reads<10000,'flag'] = 'FAILED (excluded)'
qc.loc[(qc.frac_guides_zero>0.25)&(qc.total_reads>=10000),'flag'] = 'bottlenecked (sensitivity analysis)'
qc.to_csv(OUT+'tables/invivo_sample_QC.csv')
summary = {
 'n_guides': len(df), 'n_genes_targeted': int(pd.Series(genes[~is_ntc]).nunique()), 'n_nontargeting': int(is_ntc.sum()),
 'n_tumour_samples': int(sum(G.str.startswith('Group'))), 'n_unique_animal_ids': int(len(set(c.split('_')[-1] for c in cols if c.startswith('Group')))),
 'n_runs': demux.ngs_sample_id.nunique(), 'barcode_collisions_within_run': int((demux.groupby(['ngs_sample_id','first_10nt_id']).size()>1).sum()),
 'cells_implanted_per_tumour': 100000, 'cells_per_guide_at_implant': round(100000/len(df),1),
 'median_frac_zero_guides_tumours': float(qc[qc.group.str.startswith('Group')&(qc.flag=='')].frac_guides_zero.median()),
}
summary['implied_founders_per_guide_per_tumour'] = round(-np.log(summary['median_frac_zero_guides_tumours']),1)
pd.Series(summary).to_csv(OUT+'tables/invivo_design_summary.csv')
print(pd.Series(summary))
print(qc.groupby('group')[['total_reads','frac_guides_zero','gini']].median().round(3))

# ---------------- gene scores ----------------
fail = list(qc.index[qc.flag.str.startswith('FAILED')])
use = [c for c in cols if c not in fail]
cpm = cnt[use]/cnt[use].sum()*1e6
lc = np.log2(cpm+1)
base = {'NTC': lc[[c for c in use if G[c]=='Baseline_NTC']].mean(1), 'STK11': lc[[c for c in use if G[c]=='Baseline_STK11']].mean(1)}
tum = [c for c in use if c.startswith('Group')]
L = pd.DataFrame({c: lc[c]-base['STK11' if 'STK11' in c else 'NTC'] for c in tum})
L = L - L[is_ntc].median()
gene = L.groupby(genes).median()
gene = gene.drop(index=[g for g in gene.index if g.startswith('BRDN')])
groups = ['Group1_NTC','Group2_NTC','Group3_NTC','Group4_NTC','Group5_STK11','Group6_STK11','Group7_STK11','Group8_STK11']
GC = {g:[c for c in tum if G[c]==g] for g in groups}
# null from NTC quartets
rng = np.random.default_rng(1)
ntc_idx = np.where(is_ntc)[0]
null = pd.DataFrame([L.iloc[rng.choice(ntc_idx,4,replace=False)].median().values for _ in range(2000)], columns=L.columns)
res = pd.DataFrame(index=gene.index)
for g,cs in GC.items():
    m = gene[cs].mean(1); nm = null[cs].mean(1)
    res[g+'_mean'] = m; res[g+'_z'] = (m-nm.mean())/nm.std(); res[g+'_rank_most_depleted'] = m.rank().astype(int)
res['STK11_B6like_mean'] = gene[GC['Group6_STK11']+GC['Group7_STK11']+GC['Group8_STK11']].mean(1)
res['NTC_B6like_mean'] = gene[GC['Group2_NTC']+GC['Group3_NTC']+GC['Group4_NTC']].mean(1)
res['STK11_minus_NTC_B6like'] = res.STK11_B6like_mean - res.NTC_B6like_mean
res['rank_STK11_selective'] = res.STK11_minus_NTC_B6like.rank().astype(int)
res.round(3).to_csv(OUT+'tables/invivo_gene_scores_by_group.csv')

# arm-inference markers
markers = ['Ptpn2','Socs1','Cd274','Jak1','Stat1','Ifngr2','B2m','H2-K1','Tap1','Adar','Mgat1','B4galt1']
mk = res.loc[markers, [g+'_z' for g in groups]].round(1); mk.columns = groups
mk.to_csv(OUT+'tables/invivo_arm_inference_markers_z.csv')
print(mk)

# Mgat1 statistics
s = gene.loc['Mgat1']
def pool(gs): return s[sum([GC[g] for g in gs],[])]
stk_b6 = pool(['Group6_STK11','Group7_STK11','Group8_STK11']); ntc_b6 = pool(['Group2_NTC','Group3_NTC','Group4_NTC'])
g5 = pool(['Group5_STK11']); g1 = pool(['Group1_NTC'])
stat = {
 'Mgat1_mean_'+g: round(pool([g]).mean(),3) for g in groups}
stat.update({
 'n_tumours_STK11_B6like': len(stk_b6), 'n_tumours_NTC_B6like': len(ntc_b6),
 'Mgat1_STK11_B6like_mean': round(stk_b6.mean(),3), 'Mgat1_NTC_B6like_mean': round(ntc_b6.mean(),3),
 'Mgat1_delta_STK11_vs_NTC_B6like': round(stk_b6.mean()-ntc_b6.mean(),3),
 'Mgat1_p_MWU_STK11_vs_NTC_B6like': stats.mannwhitneyu(stk_b6, ntc_b6).pvalue,
 'Mgat1_frac_tumours_below_-1_STK11_B6like': round((stk_b6<-1).mean(),3), 'Mgat1_frac_tumours_below_-1_NTC_B6like': round((ntc_b6<-1).mean(),3),
 'Mgat1_delta_STK11_B6like_vs_Group5': round(stk_b6.mean()-g5.mean(),3), 'Mgat1_p_MWU_STK11_B6like_vs_Group5': stats.mannwhitneyu(stk_b6,g5).pvalue,
 'Mgat1_fraction_of_logdepletion_present_in_Group5': round(g5.mean()/stk_b6.mean(),3),
 'Mgat1_delta_Group5_vs_Group1': round(g5.mean()-g1.mean(),3), 'Mgat1_p_MWU_Group5_vs_Group1': stats.mannwhitneyu(g5,g1).pvalue,
 'Mgat1_delta_NTC_B6like_vs_Group1': round(ntc_b6.mean()-g1.mean(),3), 'Mgat1_p_MWU_NTC_B6like_vs_Group1': stats.mannwhitneyu(ntc_b6,g1).pvalue,
 'Mgat1_KruskalWallis_p_G6_G7_G8': stats.kruskal(*[pool([g]) for g in ['Group6_STK11','Group7_STK11','Group8_STK11']]).pvalue,
 'Mgat1_KruskalWallis_p_G2_G3_G4': stats.kruskal(*[pool([g]) for g in ['Group2_NTC','Group3_NTC','Group4_NTC']]).pvalue,
 'Mgat1_rank_STK11_selective_of_795': int(res.loc['Mgat1','rank_STK11_selective']),
 'B4galt1_rank_STK11_selective_of_795': int(res.loc['B4galt1','rank_STK11_selective']),
 'B4galt1_delta_STK11_vs_NTC_B6like': round(res.loc['B4galt1','STK11_minus_NTC_B6like'],3),
})
# per-guide
gl = L[genes=='Mgat1'].copy(); gl.index = df.gene_sgrna_id[genes=='Mgat1']
pg = pd.DataFrame({g: gl[GC[g]].mean(1) for g in groups}).round(2)
pg.to_csv(OUT+'tables/invivo_Mgat1_per_guide_by_group.csv')
pd.Series(stat).to_csv(OUT+'tables/invivo_Mgat1_statistics.csv')
print(pd.Series(stat)); print(pg)

# in vitro components (plasmid -> baseline -> endpoint)
lcall = np.log2(cnt[use]/cnt[use].sum()*1e6+1)
def comp(a,b):
    x = lcall[a].mean(1)-lcall[b].mean(1); x = x - x[is_ntc].median(); return x.groupby(genes).median()
pl=[c for c in use if G[c]=='Plasmid']; bn=[c for c in use if G[c]=='Baseline_NTC']; bs=[c for c in use if G[c]=='Baseline_STK11']
en=[c for c in use if G[c]=='Endpoint_NTC']; es=[c for c in use if G[c]=='Endpoint_STK11']
iv = pd.DataFrame({'BaselineNTC_vs_Plasmid':comp(bn,pl),'BaselineSTK11_vs_Plasmid':comp(bs,pl),'EndpointNTC_vs_Plasmid':comp(en,pl),
                   'EndpointSTK11_vs_Plasmid':comp(es,pl),'EndpointSTK11_vs_EndpointNTC':comp(es,en)})
ivn = iv.drop(index=[g for g in iv.index if g.startswith('BRDN')])
nullsd = {}
for c in iv.columns:
    a = {'BaselineNTC_vs_Plasmid':(bn,pl),'BaselineSTK11_vs_Plasmid':(bs,pl),'EndpointNTC_vs_Plasmid':(en,pl),'EndpointSTK11_vs_Plasmid':(es,pl),'EndpointSTK11_vs_EndpointNTC':(es,en)}[c]
    x = lcall[a[0]].mean(1)-lcall[a[1]].mean(1); x = x - x[is_ntc].median()
    nullsd[c] = np.std([np.median(x.values[rng.choice(ntc_idx,4,replace=False)]) for _ in range(3000)])
ivt = pd.DataFrame({'Mgat1_gene_LFC':ivn.loc['Mgat1'], 'null_SD':pd.Series(nullsd)})
ivt['z'] = ivt.Mgat1_gene_LFC/ivt.null_SD
ivt['rank_most_depleted_of_795'] = [int(ivn[c].rank().loc['Mgat1']) for c in ivt.index]
ivt.round(3).to_csv(OUT+'tables/invivo_Mgat1_in_vitro_components.csv'); print(ivt.round(2))
ess = ['Rpl3','Rpl5','Rps6','Plk1','Pcna','Kif11','Lars','Metap2','Mtor']
ivn.loc[ess,['BaselineNTC_vs_Plasmid','BaselineSTK11_vs_Plasmid']].round(2).to_csv(OUT+'tables/invivo_essential_gene_dropout_QC.csv')

# robustness
def variant(norm=True, exclude=(), drop_guide=None, agg='median'):
    u = [c for c in use if c not in exclude]
    cp = cnt[u]/cnt[u].sum()*1e6; l2 = np.log2(cp+1)
    b = {'NTC': l2[[c for c in u if G[c]=='Baseline_NTC']].mean(1), 'STK11': l2[[c for c in u if G[c]=='Baseline_STK11']].mean(1)}
    t = [c for c in u if c.startswith('Group')]
    LL = pd.DataFrame({c: l2[c]-b['STK11' if 'STK11' in c else 'NTC'] for c in t})
    if norm: LL = LL - LL[is_ntc].median()
    sel = genes=='Mgat1'
    if drop_guide: sel = sel & (df.gene_sgrna_id.values!=drop_guide)
    sc = LL[sel].median() if agg=='median' else LL[sel].mean()
    a = sc[[c for c in t if G[c] in ['Group6_STK11','Group7_STK11','Group8_STK11']]]; bb = sc[[c for c in t if G[c] in ['Group2_NTC','Group3_NTC','Group4_NTC']]]
    g5_ = sc[[c for c in t if G[c]=='Group5_STK11']]
    return {'STK11_B6like':round(a.mean(),2),'NTC_B6like':round(bb.mean(),2),'delta':round(a.mean()-bb.mean(),2),'p_MWU':stats.mannwhitneyu(a,bb).pvalue,'Group5':round(g5_.mean(),2)}
rob = {'primary':variant(), 'exclude 2 bottlenecked tumours':variant(exclude=list(qc.index[qc.flag.str.startswith('bottleneck')])),
       'no non-targeting centring':variant(norm=False), 'mean of guides':variant(agg='mean')}
for gd in ['Mgat1_1','Mgat1_2','Mgat1_3','Mgat1_4']: rob['drop '+gd] = variant(drop_guide=gd)
rob = pd.DataFrame(rob).T; rob.to_csv(OUT+'tables/invivo_Mgat1_robustness.csv'); print(rob)

# ---------------- figures ----------------
plt.rcParams.update({'font.size':9})
fig, ax = plt.subplots(figsize=(8,4.2))
labels = ['G1 NTC\n(T-cell-free-like)','G2 NTC','G3 NTC','G4 NTC','G5 STK11\n(T-cell-free-like)','G6 STK11','G7 STK11','G8 STK11']
data = [pool([g]).values for g in groups]
colors = ['#9e9e9e','#616161','#616161','#616161','#f4a582','#b2182b','#b2182b','#b2182b']
bp = ax.boxplot(data, widths=0.55, patch_artist=True, showfliers=False)
for patch,c in zip(bp['boxes'],colors): patch.set_facecolor(c); patch.set_alpha(0.45)
for i,d in enumerate(data):
    ax.scatter(np.random.default_rng(i).normal(i+1,0.07,len(d)), d, s=10, color=colors[i], zorder=3)
ax.axhline(0,color='k',lw=0.6); ax.axhline(-1,color='k',lw=0.4,ls=':')
ax.set_xticks(range(1,9)); ax.set_xticklabels(labels, fontsize=7.5)
ax.set_ylabel('Mgat1 gene score per tumour\n(log2 FC vs baseline, non-targeting-centred)')
ax.set_title('In vivo screen: Mgat1 knockout is depleted far more in Stk11-KO tumours\n(no difference among the three immunocompetent-like arms G6-G8; ~60% of the effect persists in G5)', fontsize=8.5)
ax.set_ylim(-8.3, 1.9)
ax.text(0.6, -7.6, 'STK11 vs NTC (G6-8 vs G2-4): Δ = %.2f log2, MWU p = %.1e;  G6 vs G7 vs G8: Kruskal-Wallis p = %.2f' % (stat['Mgat1_delta_STK11_vs_NTC_B6like'], stat['Mgat1_p_MWU_STK11_vs_NTC_B6like'], stat['Mgat1_KruskalWallis_p_G6_G7_G8']), fontsize=7, ha='left')
plt.tight_layout(); plt.savefig(OUT+'figures/fig1_invivo_mgat1_by_arm.png', dpi=200); plt.close()

fig, ax = plt.subplots(figsize=(5.2,4.6))
ax.scatter(res.NTC_B6like_mean, res.STK11_B6like_mean, s=6, color='#bdbdbd')
for gname,c in [('Mgat1','#b2182b'),('B4galt1','#ef8a62'),('Ptpn2','#2166ac'),('Mapk7','#4d9221'),('B2m','k')]:
    ax.scatter(res.loc[gname,'NTC_B6like_mean'], res.loc[gname,'STK11_B6like_mean'], s=28, color=c)
    ax.annotate(gname, (res.loc[gname,'NTC_B6like_mean'], res.loc[gname,'STK11_B6like_mean']), fontsize=8, xytext=(4,4), textcoords='offset points')
lim = [-6,3]; ax.plot(lim,lim,'k--',lw=0.6); ax.set_xlim(lim); ax.set_ylim(lim)
ax.set_xlabel('NTC background, immunocompetent-like arms (G2-G4)\nmean gene score (log2)'); ax.set_ylabel('Stk11-KO background, immunocompetent-like arms (G6-G8)\nmean gene score (log2)')
ax.set_title('795 library genes: Mgat1 (#1) and B4galt1 (#2) are the most\nStk11-selective depletions', fontsize=8.5)
plt.tight_layout(); plt.savefig(OUT+'figures/fig2_invivo_stk11_selectivity.png', dpi=200); plt.close()

fig, ax = plt.subplots(figsize=(6.2,4.0))
im = ax.imshow(mk.values, cmap='RdBu', vmin=-15, vmax=15, aspect='auto')
ax.set_xticks(range(8)); ax.set_xticklabels([g.replace('Group','G').replace('_',' ') for g in groups], rotation=45, ha='right')
ax.set_yticks(range(len(markers))); ax.set_yticklabels(markers)
for i in range(mk.shape[0]):
    for j in range(mk.shape[1]):
        ax.text(j,i,'%.0f'%mk.values[i,j],ha='center',va='center',fontsize=6.5)
plt.colorbar(im, ax=ax, label='z vs non-targeting quartets')
ax.set_title('Arm inference (no group key supplied): G1/G5 lack T-cell/IFN-type selection\n(Ptpn2, Socs1, Jak1, Cd274); G2/G6 show PD-L1(Cd274)-KO depletion', fontsize=8)
plt.tight_layout(); plt.savefig(OUT+'figures/fig3_invivo_arm_inference.png', dpi=200); plt.close()
print('done')

# ---------------- label-consistency check: leave-one-out NTC/STK11 background classifier ----------------
bgl = pd.Series({c:('STK11' if 'STK11' in c else 'NTC') for c in tum})
rows=[]
for c in tum:
    others=[o for o in tum if o!=c]
    a=gene[[o for o in others if bgl[o]=='STK11']]; b=gene[[o for o in others if bgl[o]=='NTC']]
    t=(a.mean(1)-b.mean(1))/np.sqrt(a.var(1)/a.shape[1]+b.var(1)/b.shape[1])
    up=t.nlargest(15).index; dn=t.nsmallest(15).index
    sc=gene.loc[up,c].mean()-gene.loc[dn,c].mean()
    sa=a.loc[up].mean()-a.loc[dn].mean(); sb=b.loc[up].mean()-b.loc[dn].mean()
    pred='STK11' if abs(sc-sa.mean())/sa.std() < abs(sc-sb.mean())/sb.std() else 'NTC'
    rows.append({'sample':c,'label':bgl[c],'predicted':pred,'score':round(sc,2)})
loo=pd.DataFrame(rows); loo.to_csv(OUT+'tables/invivo_background_label_check.csv', index=False)
print('background label mismatches:', int((loo.label!=loo.predicted).sum()), 'of', len(loo))
