"""
Chemistry, biophysics and crystallography checks.
Inputs: compound_properties.csv, spr_binding.csv, spr_competition.csv, dsf_thermal_shift.csv, assay_figures.pdf (p1, p4 images),
        MGAT1_*.cif
Outputs: tables/chem_*.csv, tables/struct_*.csv
"""
import pandas as pd, numpy as np, math, io
from PIL import Image
import gemmi
IN='/tmp/world/filesystem/'; OUT='/tmp/outputs/'
cp = pd.read_csv(IN+'compound_properties.csv')
# ---- derived potency metrics
cp['pIC50'] = -np.log10(cp.udpglo_ic50_um*1e-6)
cp['LipE_pIC50_minus_logD'] = cp.pIC50 - cp.logd
cp['IC50_over_KDss'] = cp.udpglo_ic50_um/cp.spr_steady_state_kd_um
cp['IC50_over_kinetic_solubility'] = cp.udpglo_ic50_um/cp.kinetic_solubility_um
cp['KDss_over_kinetic_solubility'] = cp.spr_steady_state_kd_um/cp.kinetic_solubility_um
RT = 0.001987*298.15
cp.loc[cp.compound=='ANT-3744','heavy_atoms'] = 31   # from C3744 chemical component (C23H25N5O3; 31 atoms modelled)
cp['LE_kcal_per_HA_from_KDss'] = -RT*np.log(cp.spr_steady_state_kd_um*1e-6)/cp.heavy_atoms
cp.round(3).to_csv(OUT+'tables/chem_compound_metrics.csv', index=False)
print(cp[['compound','origin','udpglo_ic50_um','spr_steady_state_kd_um','spr_kinetic_kd_um','pIC50','LipE_pIC50_minus_logD','IC50_over_KDss','IC50_over_kinetic_solubility','KDss_over_kinetic_solubility','LE_kcal_per_HA_from_KDss']].round(2).to_string())
# ---- SPR competition logic
comp = pd.read_csv(IN+'spr_competition.csv')
KD_udp, KD_c = 32.0, 0.4
pred = pd.DataFrame([
  {'analyte':'UDP','competitor':'ANT-3744 20 uM','occupancy_of_competitor':20/(20+KD_c),'KD_alone_uM':KD_udp,'KD_pred_if_competitive_uM':KD_udp*(1+20/KD_c),'KD_observed_uM':20},
  {'analyte':'ANT-3744','competitor':'UDP 5000 uM','occupancy_of_competitor':5000/(5000+KD_udp),'KD_alone_uM':KD_c,'KD_pred_if_competitive_uM':KD_c*(1+5000/KD_udp),'KD_observed_uM':0.2}])
pred.round(3).to_csv(OUT+'tables/chem_spr_competition_logic.csv', index=False); print(pred.round(2))
# ---- SPR theoretical Rmax (approximate; SPR construct = His-TEV-A104-N445 (41,648 Da from CIF entity) + Avi tag + (GS)7 linker ~ +2.6 kDa)
mw_lig = 41648 + 2600
rmax = pd.DataFrame([
  {'surface':'direct binding (~9000 RU)','analyte':'ANT-3744','MW':419.5,'RL':9000,'obs_plateau_RU_read_from_fig':'~115-120'},
  {'surface':'direct binding (~9000 RU)','analyte':'UDP','MW':404.2,'RL':9000,'obs_plateau_RU_read_from_fig':'~9-10'},
  {'surface':'competition (~3500 RU, 5 mM UDP)','analyte':'ANT-3744','MW':419.5,'RL':3500,'obs_plateau_RU_read_from_fig':'~32-33'}])
rmax['theoretical_Rmax_1to1_RU'] = (rmax.MW/mw_lig*rmax.RL).round(1)
rmax.to_csv(OUT+'tables/chem_spr_rmax_check.csv', index=False); print(rmax)
# ---- DSF: digitise derivative peaks from assay_figures p4 image and compare with csv
EX='/tmp/outputs/analysis/extracted/'   # produced by 00_extract_pdf_content.py
im4 = np.array(Image.open(EX+'assay_figures_p04_0.png').convert('RGB')).astype(int)
sub = im4[595:960, 150:1090]
def peakx(mask):
    ys,xs = np.where(mask); top = ys.min(); return xs[ys<=top+3].mean()+150
rr,gg,bb = sub[:,:,0],sub[:,:,1],sub[:,:,2]
masks = {'5% DMSO':(rr>150)&(gg<90)&(bb>100),'UDP 5000 uM':(rr>200)&(gg>180)&(bb<120),'ANT-3744 100 uM':(gg>100)&(rr<120)&(bb<100)&(gg>rr+20),'ANT-3744 + UDP':(bb>130)&(rr<130)&(gg<140)&(bb>rr+30)}
x20, x100 = 151.5, 1087.5   # gridline pixel positions for 20 and 100 C (from image)
dsf = pd.read_csv(IN+'dsf_thermal_shift.csv')
rows=[]
for k,m in masks.items():
    T = 20 + (peakx(m)-x20)/((x100-x20)/80)
    rows.append({'sample':k,'Tm_from_figure_C':round(T,1)})
d = pd.DataFrame(rows); d['dTm_from_figure'] = (d.Tm_from_figure_C - d.Tm_from_figure_C.iloc[0]).round(1)
d['Tm_csv'] = [np.nan, 51, 55, 57]; d['dTm_csv'] = [0, 2, 6, 8]
d.to_csv(OUT+'tables/chem_dsf_figure_vs_csv.csv', index=False); print(d)
# ---- IC50 curves: concentration range plotted vs documented protocol (top 100 uM, 3-fold, 10 points)
im1 = np.array(Image.open(EX+'assay_figures_p01_0.png').convert('L')).astype(int)
panels = {'ANT-0592':(215.5,-2,'top'),'ANT-1476':(998.5,-2,'top'),'ANT-2118':(1782.5,-2,'top'),'ANT-3105':(215.5,-2,'bot'),'ANT-3744':(998.5,-2,'bot'),'ANT-4267':(1782.5,-3,'bot')}
from scipy import ndimage
rows=[]
for name,(t0,d0,row) in panels.items():
    x0 = int(t0)-10; y0,y1 = (120,525) if row=='top' else (760,1170)
    sub = im1[y0:y1, x0+15:x0+640] < 80
    er = ndimage.binary_erosion(sub, structure=np.ones((9,9)))
    lab,n = ndimage.label(er)
    xs = sorted([ndimage.center_of_mass(er, lab, i)[1]+x0+15 for i in range(1,n+1)])
    conc = [10**(d0+(x-t0)/101.0) for x in xs]
    rows.append({'compound':name,'n_points_detected':len(conc),'lowest_plotted_uM':round(min(conc),4),'highest_plotted_uM':round(max(conc),1),'documented_top_uM':100})
ic = pd.DataFrame(rows); ic.to_csv(OUT+'tables/chem_ic50_plotted_range_vs_protocol.csv', index=False); print(ic)
# ---- crystallography
def load(f): st = gemmi.read_structure(IN+f); st.setup_entities(); return st
S = {f:load(f) for f in ['MGAT1_apo.cif','MGAT1_UDP.cif','MGAT1_UDP_GlcNAc.cif','MGAT1_C3744.cif','MGAT1_C3744_UDP.cif']}
def hdr(f):
    doc = gemmi.cif.read(IN+f); b = doc.sole_block()
    g = lambda t: b.find_value(t)
    return {'file':f,'resolution_A':g('_refine.ls_d_res_high'),'Rwork':g('_refine.ls_R_factor_R_work'),'Rfree':g('_refine.ls_R_factor_R_free'),
            'space_group':g('_symmetry.space_group_name_H-M'),'cell_a_b_c':'%s %s %s'%(g('_cell.length_a'),g('_cell.length_b'),g('_cell.length_c'))}
H = pd.DataFrame([hdr(f) for f in S]); 
ligs=[]
for f,st in S.items():
    for ch in st[0]:
        for res in ch:
            if res.het_flag=='H' and res.name!='HOH':
                ligs.append({'file':f,'chain':ch.name,'ligand':res.name,'atoms':len(res),'mean_occ':round(np.mean([a.occ for a in res]),2),'mean_B':round(np.mean([a.b_iso for a in res]),1)})
H.to_csv(OUT+'tables/struct_refinement_summary.csv', index=False); pd.DataFrame(ligs).to_csv(OUT+'tables/struct_ligands.csv', index=False)
print(H.to_string()); 
def contacts(st, chain, lig, cutoff=4.0):
    model = st[0]; ns = gemmi.NeighborSearch(model, st.cell, 6).populate(); out={}
    for res in model[chain]:
        if res.name!=lig: continue
        for a in res:
            for m in ns.find_atoms(a.pos, '\0', radius=cutoff):
                cra = m.to_cra(model)
                if cra.residue.name=='HOH' or (cra.residue.name==lig and cra.chain.name==chain): continue
                im = st.cell.find_nearest_image(a.pos, cra.atom.pos, gemmi.Asu.Any)
                sym = im.sym_idx!=0 or any(v!=0 for v in im.pbc_shift)
                key=(cra.residue.name+str(cra.residue.seqid.num), 'symmetry-mate' if sym else 'same chain')
                out[key]=min(out.get(key,99), im.dist())
    return out
rows=[]
for f in ['MGAT1_C3744.cif','MGAT1_C3744_UDP.cif']:
    for chn in ['A','B']:
        for (resname,kind),d in sorted(contacts(S[f],chn,'C3744').items(), key=lambda x:(x[0][1], int(''.join(filter(str.isdigit,x[0][0]))))):
            rows.append({'file':f,'chain':chn,'residue':resname,'contact':kind,'min_dist_A':round(d,2)})
pd.DataFrame(rows).to_csv(OUT+'tables/struct_C3744_contacts.csv', index=False)
# key distances
cu = S['MGAT1_C3744_UDP.cif']; ug = S['MGAT1_UDP_GlcNAc.cif']
def resi(st,ch,n): return [r for r in st[0][ch] if r.seqid.num==n and r.het_flag!='H'][0]
def lig(st,ch,name): return [r for r in st[0][ch] if r.name==name][0]
dist=[]
for chn in ['A','B']:
    c = lig(cu,chn,'C3744'); u = lig(cu,chn,'UDP'); mn = lig(cu,chn,'MN')
    dist.append({'chain':chn,'C3744_to_UDP_min_A':round(min(a.pos.dist(b.pos) for a in c for b in u),1),
                 'C3744_to_Mn_min_A':round(min(a.pos.dist(b.pos) for a in c for b in mn),1),
                 'C3744_to_D289_min_A':round(min(a.pos.dist(b.pos) for a in c for b in resi(cu,chn,289)),1),
                 'D211_to_Mn_A':round(min(a.pos.dist(b.pos) for a in resi(cu,chn,211) for b in mn),2)})
ud1 = lig(ug,'A','UD1'); c1 = ud1.find_atom("C1'",'*')
dist.append({'chain':'A (UDP-GlcNAc complex)','D289_to_GlcNAc_C1_A':round(min(a.pos.dist(c1.pos) for a in resi(ug,'A',289)),2),
             'D211_to_UD1_min_A':round(min(a.pos.dist(b.pos) for a in resi(ug,'A',211) for b in ud1),2)})
pd.DataFrame(dist).to_csv(OUT+'tables/struct_key_distances.csv', index=False); print(pd.DataFrame(dist))
# induced fit: pocket residue displacement C3744-bound vs apo (chain A/B)
def ca(st,ch): return {r.seqid.num:r for r in st[0][ch] if r.het_flag!='H' and r.find_atom('CA','*')}
rows=[]
for ref_name in ['MGAT1_apo.cif','MGAT1_UDP.cif']:
    for chn in ['A','B']:
        A_ = ca(S['MGAT1_C3744.cif'],chn); B_ = ca(S[ref_name],chn); common = sorted(set(A_)&set(B_))
        sp = gemmi.superpose_positions([A_[i]['CA'][0].pos for i in common],[B_[i]['CA'][0].pos for i in common])
        for n in [388,437,438,444]:
            ds=[]
            for a in A_[n]:
                b = B_[n].find_atom(a.name,'*')
                if b: p = sp.transform.apply(b.pos); ds.append(a.pos.dist(gemmi.Position(p.x,p.y,p.z)))
            rows.append({'vs':ref_name,'chain':chn,'residue':A_[n].name+str(n),'max_atom_shift_A':round(max(ds),1),'global_CA_rmsd':round(sp.rmsd,2)})
pd.DataFrame(rows).to_csv(OUT+'tables/struct_induced_fit.csv', index=False); print(pd.DataFrame(rows))

# ---- 4-parameter fits to the digitised dose-response points (checks reported IC50s and maximal inhibition)
from scipy.optimize import curve_fit
def f4(x, top, bot, logic50, h): return bot + (top-bot)/(1+10**((x-logic50)*h))
reported = dict(zip(cp.compound, cp.udpglo_ic50_um))
rows=[]
for name,(t0,d0,row) in panels.items():
    x0 = int(t0)-10; y0,y1 = (120,525) if row=='top' else (760,1170); axis = 530 if row=='top' else 1175
    sub = im1[y0:y1, x0+15:x0+640] < 80
    er = ndimage.binary_erosion(sub, structure=np.ones((9,9)))
    lab,n = ndimage.label(er)
    pts = sorted([ndimage.center_of_mass(er, lab, i) for i in range(1,n+1)], key=lambda p:p[1])
    x = np.array([d0+((p[1]+x0+15)-t0)/101.0 for p in pts]); y = np.array([(axis-(p[0]+y0))/3.68 for p in pts])
    try:
        popt,_ = curve_fit(f4, x, y, p0=[100,5,np.median(x),1], maxfev=20000)
        # absolute IC50 = concentration at 50% activity on the fitted curve
        xs = np.linspace(x.min(), x.max(), 5000); ys = f4(xs,*popt); i50 = xs[np.argmin(np.abs(ys-50))]
        rows.append({'compound':name,'reported_IC50_uM':reported[name],'fit_relative_IC50_uM':round(10**popt[2],3),'fit_absolute_IC50_uM':round(10**i50,3),
                     'hill':round(popt[3],2),'fit_top_%':round(popt[0],0),'fit_bottom_%':round(popt[1],0),'n_points':len(x)})
    except Exception as e:
        rows.append({'compound':name,'reported_IC50_uM':reported[name],'note':str(e)})
fits = pd.DataFrame(rows); fits.to_csv(OUT+'tables/chem_ic50_digitised_fits.csv', index=False); print(fits.to_string())
