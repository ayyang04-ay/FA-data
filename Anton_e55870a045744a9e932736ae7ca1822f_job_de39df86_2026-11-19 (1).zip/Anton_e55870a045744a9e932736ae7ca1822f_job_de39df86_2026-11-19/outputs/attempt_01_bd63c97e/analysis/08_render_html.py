"""Render the memo to a self-contained HTML file (figures embedded)."""
import base64, os
from markdown_it import MarkdownIt
OUT='/tmp/outputs/'
md = open(OUT+'MGAT1_recommendation_memo.md').read()
figs = [('fig1_invivo_mgat1_by_arm.png','Figure 1. In vivo screen: per-tumour Mgat1 gene score by group [E24, E29, E30]'),
        ('fig2_invivo_stk11_selectivity.png','Figure 2. In vivo screen: Stk11-KO vs STK11-intact gene scores for all 795 genes [E25]'),
        ('fig3_invivo_arm_inference.png','Figure 3. Arm inference from marker genes (no key supplied) [E28]'),
        ('fig4_coculture_rank.png','Figure 4. Genome-wide co-culture screen ranking [E01, E02, E04]'),
        ('fig5_glycan_composition.png','Figure 5. Glycan-class shares, MGAT1-KO vs control (A375, NCI-H1703) [E17]'),
        ('fig6_phenotype_digitised_summary.png','Figure 6. Digitised client phenotype read-outs (approximate) [E07, E09, E13, E14]')]
md += '\n\n---\n\n## Figures\n\n'
for f,cap in figs:
    b64 = base64.b64encode(open(OUT+'figures/'+f,'rb').read()).decode()
    md += f'**{cap}**\n\n<img src="data:image/png;base64,{b64}" style="max-width:100%;"/>\n\n'
html = MarkdownIt('commonmark', {'html': True}).enable('table').render(md)
css = """body{font-family:Helvetica,Arial,sans-serif;max-width:1000px;margin:40px auto;line-height:1.45;font-size:14px;color:#222}
table{border-collapse:collapse;margin:10px 0;font-size:12.5px}th,td{border:1px solid #bbb;padding:5px 7px;vertical-align:top}th{background:#f0f0f0}
h1{font-size:22px}h2{font-size:18px;border-bottom:1px solid #ccc;padding-bottom:3px;margin-top:28px}h3{font-size:15px}code{background:#f5f5f5;padding:1px 3px}"""
open(OUT+'MGAT1_recommendation_memo.html','w').write(f'<html><head><meta charset="utf-8"><title>MGAT1 recommendation</title><style>{css}</style></head><body>{html}</body></html>')
print('written', os.path.getsize(OUT+'MGAT1_recommendation_memo.html'))
