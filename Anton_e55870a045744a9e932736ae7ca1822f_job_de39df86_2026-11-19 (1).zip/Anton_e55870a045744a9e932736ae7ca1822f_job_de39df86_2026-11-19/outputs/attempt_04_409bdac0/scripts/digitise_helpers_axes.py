import numpy as np
from PIL import Image
from scipy import ndimage as ndi
def load(path):
    return np.array(Image.open(path).convert('RGB')).astype(int)
def runs(mask_1d, minlen=1):
    idx = np.where(mask_1d)[0]
    if len(idx)==0: return []
    out=[]; s=idx[0]; p=idx[0]
    for i in idx[1:]:
        if i!=p+1:
            if p-s+1>=minlen: out.append((s,p))
            s=i
        p=i
    if p-s+1>=minlen: out.append((s,p))
    return out
def find_axes(im, box, dark_thr=90):
    """box=(r0,r1,c0,c1). returns y-axis col (longest vertical dark run), x-axis row (longest horizontal dark run)"""
    r0,r1,c0,c1 = box
    g = im[r0:r1,c0:c1].mean(axis=2) < dark_thr
    colsum = g.sum(axis=0); rowsum = g.sum(axis=1)
    ycol = np.argmax(colsum)+c0; xrow = np.argmax(rowsum)+r0
    return ycol, xrow, colsum.max(), rowsum.max()
def yticks(im, ycol, r0, r1, left=14, thr=90, minlen=6):
    """tick marks to the left of the y-axis line: rows with dark pixels over [ycol-left, ycol-3]"""
    g = im[r0:r1, ycol-left:ycol-4].mean(axis=2) < thr
    rr = runs(g.sum(axis=1) >= minlen)
    return [((a+b)/2 + r0, b-a+1) for a,b in rr]
def xticks(im, xrow, c0, c1, down=14, thr=90, minlen=6):
    g = im[xrow+4:xrow+down, c0:c1].mean(axis=2) < thr
    rr = runs(g.sum(axis=0) >= minlen)
    return [((a+b)/2 + c0, b-a+1) for a,b in rr]
def color_mask(im, rgb, tol=50):
    d = np.sqrt(((im - np.array(rgb))**2).sum(axis=2))
    return d < tol
def blobs(mask, open_r=4, min_size=30):
    y,x = np.ogrid[-open_r:open_r+1,-open_r:open_r+1]; st = x*x+y*y <= open_r*open_r
    op = ndi.binary_opening(mask, structure=st)
    lab, n = ndi.label(op)
    if n==0: return []
    cents = ndi.center_of_mass(op, lab, range(1,n+1)); sizes = ndi.sum(op, lab, range(1,n+1))
    return [(c[0], c[1], s) for c,s in zip(cents,sizes) if s>=min_size]
