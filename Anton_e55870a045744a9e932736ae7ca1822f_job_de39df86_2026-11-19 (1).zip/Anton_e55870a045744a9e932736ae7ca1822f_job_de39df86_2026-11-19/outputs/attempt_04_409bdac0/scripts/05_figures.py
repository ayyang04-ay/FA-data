import pandas as pd, numpy as np, matplotlib, re, warnings
matplotlib.use('Agg'); import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')
T='/tmp/outputs/analysis_tables/'; F='/tmp/outputs/figures/'
plt.rcParams.update({'font.size':9, 'axes.spines.top':False, 'axes.spines.right':False})
# ---------------- Figure 1: in vivo screen ----------------
G = pd.read_csv(T+'invivo_gene_scores_per_animal.csv', index_col=0)
inter = pd.read_csv(T+'invivo_STK11_vs_NTC_interaction_all_genes.csv', index_col=0)
groups = [f'Group{i}' for i in range(1,9)]+['Endpoint_NTC','Endpoint_STK11']
labels = ['G1','G2','G3','G4','G5','G6','G7','G8','in vitro\nNTC','in vitro\nSTK11']
fig, ax = plt.subplots(1,2, figsize=(11,4.2), gridspec_kw={'width_ratios':[1.4,1]})
pseudo = G[G.index.str.startswith('pseudo')]
for i,g in enumerate(groups):
    cc = [c for c in G.columns if c.startswith(g+'_')]
    v = G.loc['Mgat1', cc].values
    col = '#7f7f7f' if ('NTC' in g or (g.startswith('Group') and int(g[-1])<=4)) else '#c0392b'
    ax[0].scatter(np.full(len(v), i)+np.random.default_rng(i).uniform(-0.18,0.18,len(v)), v, s=12, color=col, alpha=0.7, lw=0)
    ax[0].plot([i-0.3,i+0.3],[np.median(v)]*2, color='k', lw=2)
    pm = pseudo[cc].median(axis=1)
    ax[0].fill_between([i-0.35,i+0.35], np.percentile(pm,2.5), np.percentile(pm,97.5), color='#3498db', alpha=0.25, lw=0)
ax[0].axhline(0, color='k', lw=0.5)
ax[0].set_xticks(range(len(groups))); ax[0].set_xticklabels(labels, fontsize=8)
ax[0].set_ylabel('Mgat1 gene score (log2 FC vs baseline,\nmean of 4 guides, centred on 400 NTC guides)')
ax[0].set_title('A. Mgat1 gene score per tumour (grey = sgNTC, red = sgStk11 background)\nblack bar = group median; blue band = 95% null range of the group median (NTC pseudo-genes)', fontsize=8.5)
r = inter.sort_values('diff_STK11_minus_NTC').reset_index()
ax[1].scatter(np.arange(len(r)), r.diff_STK11_minus_NTC, s=6, color='#bbbbbb', lw=0)
for gname,colr in [('Mgat1','#c0392b'),('B4galt1','#e67e22'),('Mgat2','#2980b9')]:
    j = r.index[r.iloc[:,0]==gname][0]
    ax[1].scatter(j, r.diff_STK11_minus_NTC[j], s=30, color=colr, zorder=3)
    ax[1].annotate(f'{gname} (rank {j+1}/795)', (j, r.diff_STK11_minus_NTC[j]), xytext=(25, -5 if gname!='Mgat2' else 10), textcoords='offset points', fontsize=8, color=colr)
ax[1].axhline(0, color='k', lw=0.5)
ax[1].set_xlabel('795 genes ranked by STK11-selective depletion'); ax[1].set_ylabel('median(sgStk11 animals) - median(sgNTC animals)')
ax[1].set_title('B. STK11-selective depletion, all 795 genes\n69 sgStk11 vs 70 sgNTC tumours; Mgat1 z = -8.1', fontsize=8.5)
plt.tight_layout(); plt.savefig(F+'Fig1_invivo_screen_Mgat1.png', dpi=200); plt.close()
# ---------------- Figure 2: co-culture screen ----------------
gg = pd.read_csv(T+'coculture_gene_level.csv', index_col=0)
gg = gg[gg.tumor_only_reads>200].sort_values('mean_lfc')
glyc = {'MGAT1','SLC35A1','SLC35A2','CMAS','GFPT1','UAP1','GALE','UGP2','MOGS','TMEM165','GNE','NANS'}
fig, ax = plt.subplots(1,2, figsize=(11,5.2), gridspec_kw={'width_ratios':[1.2,1]})
top = gg.head(30)
cols = ['#c0392b' if g=='MGAT1' else ('#8e44ad' if g in glyc else '#95a5a6') for g in top.index]
ax[0].barh(range(len(top)), top.mean_lfc, color=cols)
ax[0].set_yticks(range(len(top))); ax[0].set_yticklabels([f'{g} (#{int(r)})' for g,r in zip(top.index, top.rank_depleted)], fontsize=7); ax[0].invert_yaxis()
ax[0].set_xlabel('mean guide log2 FC (TCR-T 24 h vs tumour-only)')
ax[0].set_title('A. Top 30 sensitiser genes (rank among 19,114 genes; red = MGAT1; purple = glycan supply/processing)', fontsize=8.5)
sel = ['CTAG1B','B2M','CTAG1A','IFNGR2','STAT1','JAK2','JAK1','TAP1','TAP2','HLA-A','MGAT2','MGAT5','B4GALT1','FUT8','CD274','STK11']
v = gg.loc[sel]
cols2 = ['#2c3e50']*10 + ['#2980b9']*6
ax[1].barh(range(len(v)), v.mean_lfc, color=cols2)
ax[1].set_yticks(range(len(v))); ax[1].set_yticklabels(sel, fontsize=7); ax[1].invert_yaxis(); ax[1].axvline(0,color='k',lw=0.5)
ax[1].set_xlabel('mean guide log2 FC')
ax[1].set_title('B. Resistance controls (dark) behave as expected;\nother N-glycan genes incl. MGAT5 (PHA-L epitope) are not hits (blue)', fontsize=8.5)
plt.suptitle('Genome-wide co-culture screen, NCI-H1703 + NY-ESO-1 TCR CD8 T cells (one sample per arm; NTC guide SD = 0.19)', fontsize=9)
plt.tight_layout(); plt.savefig(F+'Fig2_coculture_screen.png', dpi=200); plt.close()
# ---------------- Figure 3: compounds ----------------
pts = pd.read_csv(T+'udpglo_points_digitised.csv'); ic = pd.read_csv(T+'udpglo_IC50_refit_vs_registry.csv').set_index('compound')
f4 = lambda c,b,t,i,h: b+(t-b)/(1+(c/i)**h)
fig, ax = plt.subplots(1,2, figsize=(11,4.6))
for nm,colr in [('ANT-3744','#c0392b'),('ANT-4267','#2c3e50'),('ANT-0592','#95a5a6')]:
    d = pts[pts.compound==nm]; ax[0].scatter(d.conc_uM, d.activity_pct, color=colr, s=18, label=f"{nm} (registry IC50 {ic.loc[nm,'registry_IC50_uM']} uM)")
    from scipy.optimize import curve_fit
    p,_ = curve_fit(f4, d.conc_uM, d.activity_pct, p0=[5,100,np.median(d.conc_uM),1], bounds=([-20,50,1e-4,0.2],[60,130,1e5,5]))
    xx = np.logspace(np.log10(d.conc_uM.min()), np.log10(d.conc_uM.max()), 200); ax[0].plot(xx, f4(xx,*p), color=colr, lw=1)
ax[0].axhspan(0,10,color='#f5b7b1',alpha=0.4); ax[0].text(0.006,2,'~8-10% residual activity at saturation (ANT-3744/-4267/-3105/-1476)',fontsize=7)
ax[0].set_xscale('log'); ax[0].set_xlabel('concentration (uM)'); ax[0].set_ylabel('MGAT1 activity (% of control)'); ax[0].set_ylim(-5,115)
ax[0].legend(fontsize=7, frameon=True, framealpha=0.9, loc='lower left', bbox_to_anchor=(0.0,0.14)); ax[0].set_title('A. UDP-Glo dose-response (points digitised from assay_figures.pdf p1)', fontsize=9)
S = pd.read_csv(T+'structure_C3744_site.csv')
import matplotlib.image as mpimg
img = mpimg.imread(F+'Fig3b_ternary_structure.png')[60:880, 250:1330]
ax[1].imshow(img); ax[1].axis('off')
bb = dict(boxstyle='round,pad=0.2', fc='white', ec='none', alpha=0.85)
ax[1].annotate('ANT-3744\nC-terminal pocket\n(Y388-G390, F394, G410,\nP434, W437-D441, W444)', xy=(215,450), xytext=(-10,760), color='#c0392b', fontsize=7, arrowprops=dict(arrowstyle='->', color='#c0392b'), bbox=bb, annotation_clip=False)
ax[1].annotate('UDP + Mn (donor site;\nD211 = Mn ligand)', xy=(700,355), xytext=(760,60), color='#1f3a93', fontsize=7, arrowprops=dict(arrowstyle='->', color='#1f3a93'), bbox=bb)
ax[1].annotate('D289 (catalytic base)', xy=(560,465), xytext=(520,790), color='#138d90', fontsize=7, arrowprops=dict(arrowstyle='->', color='#138d90'), bbox=bb, annotation_clip=False)
ax[1].text(300, 300, '33 A centroid-centroid\n24 A closest approach', fontsize=7, bbox=bb)
ax[1].set_title('B. Ternary complex (MGAT1_C3744_UDP.cif, chain A)', fontsize=9)
plt.tight_layout(); plt.savefig(F+'Fig3_compound_mechanism.png', dpi=200); plt.close()
# ---------------- Figure 4: in vivo genetic experiments (figure-digitised) ----------------
dat = pd.read_csv(T+'figure_digitised_tumour_endpoints.csv')
def cat(sname):
    if 'STK11-WT' in sname: return ('MGAT1 loss, STK11-WT', '#7f7f7f')
    if 'anti-PD-1' in sname and 'sgMGAT1+anti-PD-1' not in sname: return ('anti-PD-1 effect', '#2980b9')
    if 'sgMGAT1+anti-PD-1' in sname: return ('combination', '#8e44ad')
    if 'C57BL/6 vs nude' in sname: return ('host immunity', '#bdc3c7')
    if 'control T cells' in sname: return ('MGAT1 loss, no antigen-specific T cells', '#7f7f7f')
    if 'D211A/D289A' in sname: return ('catalytic-dead vs WT rescue', '#e67e22')
    return ('MGAT1 loss, STK11-null or TCR-T', '#c0392b')
fig, ax = plt.subplots(figsize=(11.5,4.8))
cs = [cat(x)[1] for x in dat.comparison]
j = dat.index[dat.comparison.str.contains('sgMGAT1\\+anti-PD-1')][0]
ax.barh(range(len(dat)), dat.ratio_vs_control, color=cs)
ax.axvline(1, color='k', lw=0.8)
ax.set_yticks(range(len(dat))); ax.set_yticklabels([f"{c}  [{s.replace('phenotype_figures ','')}, d{d}]" for c,s,d in zip(dat.comparison, dat.source, dat.day)], fontsize=7); ax.invert_yaxis()
for i,r in enumerate(dat.ratio_vs_control): ax.text(r+0.02, i, f'{r:.2f}', va='center', fontsize=7) if i!=j else ax.text(0.40, i, f'{r:.2f} (observed)  |  0.37 = Bliss-expected (0.55 x 0.67)', va='center', fontsize=6.5)
ax.plot([0.37,0.37],[j-0.4,j+0.4], color='k', lw=2)
from matplotlib.patches import Patch
seen = {}
for x in dat.comparison:
    k,c = cat(x); seen[k]=c
ax.legend(handles=[Patch(color=c,label=k) for k,c in seen.items()], fontsize=6.5, frameon=False, loc='upper left', bbox_to_anchor=(1.0,1.0))
ax.set_xlim(0,1.7)
ax.set_xlabel('ratio of mean tumour volumes (test / control) at last plotted time point')
ax.set_title('In vivo genetic experiments - effect sizes read from phenotype_figures.pdf\n(no n, error-bar definition or statistics provided by the client)', fontsize=8.5)
plt.tight_layout(); plt.savefig(F+'Fig4_invivo_genetic_effect_sizes.png', dpi=200); plt.close()
print('figures written')
