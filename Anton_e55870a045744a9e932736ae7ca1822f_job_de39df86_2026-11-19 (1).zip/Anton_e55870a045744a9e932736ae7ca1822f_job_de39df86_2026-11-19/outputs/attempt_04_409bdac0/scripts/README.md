Scripts used for the independent re-analysis (run order):
00_extract_pdf_figures.py            - pull page images/text out of the client PDFs (genomics env: pypdf)
01_invivo_screen_analysis.py         - MC38 in vivo pooled screen: QC, Mgat1 per group, STK11 interaction (core env)
02_coculture_screen_analysis.py      - NCI-H1703 genome-wide co-culture screen: gene ranks, UMI-level tests (core env)
03_glycoproteomics_analysis.py       - glycoform class shifts KO vs NTC, sequon and annotation QC (chem env)
04_compound_biophysics_structure.py  - IC50 re-fit from digitised points, DSF Tm re-read, structure contacts, ANT-3744 identity (core env)
05_figures.py                        - Figures 1-4 (core env); Fig3b rendered with PyMOL from MGAT1_C3744_UDP.cif
06_guide_sequence_check_hg38.R       - exact-match lookup of human guide sequences in hg38 (reagent identity only)
digitise_helpers_axes.py             - axis/tick/marker helpers used for reading values off figure images
Figure-read values (tumour volumes, bar heights, blot densitometry) were taken from zoomed crops with calibrated rulers;
they are approximations (typically +/-3-5% of axis range) and are labelled as such in every table.
