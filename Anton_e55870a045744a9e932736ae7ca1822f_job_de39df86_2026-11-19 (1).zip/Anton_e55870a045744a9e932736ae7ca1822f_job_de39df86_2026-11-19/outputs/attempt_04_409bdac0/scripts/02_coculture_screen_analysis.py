"""
In vitro genome-wide co-culture screen (NCI-H1703-Cas9 + NY-ESO-1 TCR CD8 T cells, 24 h, E:T 0.5; one sample per arm).
Input : /tmp/world/filesystem/coculture_screen_umi_counts.csv.gz (one row per UMI lineage per guide)
Method: guide counts = sum over UMIs; CPM; LFC = log2((CPM_T+1)/(CPM_0+1)); gene = mean of guides (ESG + 'other' genes);
        rank among all genes; UMI-level check: per-UMI LFC for UMIs with >=5 reads in tumour-only arm,
        gene UMIs vs non-targeting UMIs by Mann-Whitney.
"""
import pandas as pd, numpy as np, warnings
from scipy.stats import mannwhitneyu
warnings.filterwarnings('ignore')
IN = '/tmp/world/filesystem/'; OUT = '/tmp/outputs/analysis_tables/'
df = pd.read_csv(IN+'coculture_screen_umi_counts.csv.gz', dtype={'gene_symbol':'category','sgrna_id':'category','sgrna_sequence':'category','genetype':'category','umi_barcode':'str'})
g = df.groupby('sgrna_id', observed=True).agg(gene=('gene_symbol','first'), seq=('sgrna_sequence','first'), gtype=('genetype','first'),
        n_umi=('umi_barcode','size'), tumor_only=('tumor_only_untreated','sum'), tcr_24h=('MSCV_TCR_high_24hr','sum'))
g['lfc'] = np.log2((g.tcr_24h/g.tcr_24h.sum()*1e6+1)/(g.tumor_only/g.tumor_only.sum()*1e6+1))
ntc = g[g.gtype=='NegCtrl']
g['z_vs_NTC'] = (g.lfc-ntc.lfc.median())/ntc.lfc.std()
g.to_csv(OUT+'coculture_guide_level.csv')
gg = g[g.gtype.isin(['other','ESG'])].groupby('gene', observed=True).agg(n_guides=('lfc','size'), mean_lfc=('lfc','mean'), min_guide_lfc=('lfc','min'), max_guide_lfc=('lfc','max'), tumor_only_reads=('tumor_only','sum'))
gg['rank_depleted'] = gg.mean_lfc.rank().astype(int); gg['rank_enriched'] = (-gg.mean_lfc).rank().astype(int)
gg['z_gene_vs_NTC'] = (gg.mean_lfc-ntc.lfc.mean())/(ntc.lfc.std()/np.sqrt(gg.n_guides))
gg.sort_values('mean_lfc').to_csv(OUT+'coculture_gene_level.csv')
print('NTC guides: n=%d, LFC mean %.3f sd %.3f; genes ranked: %d' % (len(ntc), ntc.lfc.mean(), ntc.lfc.std(), len(gg)))
show = ['MGAT1','PTPN2','CFLAR','SLC35A1','SLC35A2','CMAS','GFPT1','UAP1','GALE','UGP2','MOGS','TMEM165','MGAT2','MGAT5','B4GALT1','FUT8','CD274','STK11','B2M','CTAG1B','JAK1','IFNGR2','TAP1','HLA-A']
print(gg.loc[show, ['n_guides','mean_lfc','min_guide_lfc','max_guide_lfc','rank_depleted','rank_enriched','z_gene_vs_NTC']].round(2).to_string())
# UMI-level
tot0, tot1 = df.tumor_only_untreated.sum(), df.MSCV_TCR_high_24hr.sum()
d = df[df.tumor_only_untreated>=5].copy()
d['lfc'] = np.log2((d.MSCV_TCR_high_24hr*tot0/tot1+0.5)/(d.tumor_only_untreated+0.5))
nt = d[d.genetype=='NegCtrl'].lfc
rows=[]
for x in ['MGAT1','PTPN2','SLC35A2','MGAT2','MGAT5','B2M','CD274']:
    v = d[d.gene_symbol==x].lfc
    rows.append(dict(gene=x, n_UMIs=len(v), median_UMI_lfc=round(v.median(),2), NTC_median_UMI_lfc=round(nt.median(),2), mwu_p=mannwhitneyu(v, nt).pvalue))
u = pd.DataFrame(rows); u.to_csv(OUT+'coculture_UMI_level_tests.csv', index=False); print(u.to_string(index=False))
