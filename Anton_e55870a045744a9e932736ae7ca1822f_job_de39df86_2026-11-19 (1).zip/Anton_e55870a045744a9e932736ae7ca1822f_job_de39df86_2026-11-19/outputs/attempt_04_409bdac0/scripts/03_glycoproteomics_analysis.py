"""
Glycoproteomics (TMTpro 16-plex; A375 and NCI-H1703, MGAT1-KO population vs non-targeting, n=4 each).
Input : /tmp/world/filesystem/glycoproteomics_site_quant.xlsx (IGP_quant, IGP_Pep_quant, Site_quant)
Method: glycan class from observed composition:
        HexNAc<=2, no Fuc/NeuAc: Hex>=5 'high-mannose', else 'paucimannose/truncated'  (MGAT1-independent)
        everything else (HexNAc>=3, or any Fuc/NeuAc)  -> 'MGAT1-dependent' (hybrid/complex/core-fucosylated)
        (a) intensity share of MGAT1-dependent glycoforms per channel;
        (b) per-site MGAT1-dependent fraction for sites observed with both classes, KO vs NTC, Wilcoxon.
        QC: sequon (N-X-S/T, X!=P) check of every glycosite; proteins annotated as nuclear/cytosolic.
Caveats: no global-proteome channel for normalisation; MS2-level TMT (ratio compression expected).
"""
import pandas as pd, numpy as np, re, warnings
from scipy import stats
warnings.filterwarnings('ignore')
IN='/tmp/world/filesystem/'; OUT='/tmp/outputs/analysis_tables/'
x = pd.ExcelFile(IN+'glycoproteomics_site_quant.xlsx')
igp = pd.read_excel(x,'IGP_quant'); pep = pd.read_excel(x,'IGP_Pep_quant'); site = pd.read_excel(x,'Site_quant')
ch = ['AM_KO1','AM_KO2','AM_KO3','AM_KO4','AM_N1','AM_N2','AM_N3','AM_N4','NH_M_KO1','NH_M_KO2','NH_M_KO3','NH_M_KO4','NH_N1','NH_N2','NH_N3','NH_N4']
I = igp[['Intensity '+c for c in ch]].copy(); I.columns = ch
def comp(s):
    d={'HexNAc':0,'Hex':0,'Fuc':0,'NeuAc':0}
    for k,v in re.findall(r'([A-Za-z]+)\((\d+)\)', str(s)): d[k]=d.get(k,0)+int(v)
    return d
C = igp['Observed Modification'].apply(comp).apply(pd.Series).fillna(0)
indep = (C.HexNAc<=2)&(C.Fuc==0)&(C.NeuAc==0)
igp['class'] = np.where(indep, np.where(C.Hex>=5,'high-mannose','paucimannose/truncated'), 'MGAT1-dependent')
share = I.groupby(igp['class']).sum()/I.sum()*100
share.round(2).to_csv(OUT+'glyco_class_share_by_channel.csv'); print(share.round(1).to_string())
igp['site'] = igp['Protein accession']+'_'+igp['Position'].astype(str)
dep = igp['class']=='MGAT1-dependent'
S_all = I.groupby(igp.site).sum(); S_dep = I[dep].groupby(igp.site[dep]).sum().reindex(S_all.index).fillna(0)
both = igp.groupby('site')['class'].agg(lambda v: (v=='MGAT1-dependent').any() and (v!='MGAT1-dependent').any())
F = (S_dep/S_all)[both.reindex(S_all.index).values]
rows=[]
for cl,ko,nt in [('A375',ch[0:4],ch[4:8]),('NCI-H1703',ch[8:12],ch[12:16])]:
    a=F[ko].mean(axis=1); b=F[nt].mean(axis=1); d=a-b
    rows.append(dict(cell_line=cl, n_sites=len(d), median_frac_NTC=round(b.median(),3), median_frac_KO=round(a.median(),3), sites_decreased=int((d<0).sum()), wilcoxon_p=stats.wilcoxon(d).pvalue,
                     pooled_share_NTC_pct=round(share.loc['MGAT1-dependent',nt].mean(),1), pooled_share_KO_pct=round(share.loc['MGAT1-dependent',ko].mean(),1)))
r = pd.DataFrame(rows); r.to_csv(OUT+'glyco_site_level_KO_vs_NTC.csv', index=False); print(r.to_string(index=False))
# channel totals & replicate correlation
tot = (I.sum()/1e9).round(3); tot.to_csv(OUT+'glyco_channel_totals_1e9.csv'); print('channel totals (x1e9):', tot.to_dict())
# QC: sequons
def sequon_ok(row):
    s = re.sub(r'^n\[\d+\]','',row['Modified Sequence']); seq=row['Peptide Sequence']; i=-1; k=0; out=[]
    while k < len(s):
        if s[k].isalpha():
            i+=1; k+=1
            if k<len(s) and s[k]=='[':
                j=s.index(']',k); m=float(s[k+1:j]); k=j+1
                if s[k-len(s[k-1:j+1])-1] if False else True:
                    pass
                if m>300 and seq[i]=='N':
                    nxt=seq[i+1:i+3]
                    out.append('undetermined' if len(nxt)<2 else ('sequon' if nxt[0]!='P' and nxt[1] in 'ST' else 'non-sequon'))
        else: k+=1
    return ';'.join(out)
pep['sequon_check'] = pep.apply(sequon_ok, axis=1)
print('PSM sequon check:', pep.sequon_check.value_counts().to_dict())
kw = r'(Transcription factor|homeobox|Zinc finger|zinc finger|Histone|ribonucleoprotein|Tubulin|RNA polymerase|Ribosom|ribosom)'
m = site['Protein description'].str.contains(kw, regex=True)
print('glycosites on proteins annotated as nuclear/cytosolic (keyword screen):', int(m.sum()), 'sites on', site.loc[m,'Gene name'].nunique(), 'proteins of', site['Gene name'].nunique())
site.loc[m, ['Gene name','Position','Protein description']].to_csv(OUT+'glyco_sites_on_nuclear_cytosolic_proteins.csv', index=False)
