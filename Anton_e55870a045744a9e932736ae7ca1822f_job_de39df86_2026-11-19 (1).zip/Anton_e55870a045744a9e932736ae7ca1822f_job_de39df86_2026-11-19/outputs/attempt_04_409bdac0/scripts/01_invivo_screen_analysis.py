"""
In vivo pooled CRISPR screen (MC38; sgNTC vs sgStk11 backgrounds) - independent re-analysis.
Input : /tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz, crispr_invivo_ngs_demux.csv.gz
Method: per-sample CPM -> log2(CPM+1); per-guide LFC vs mean of the 3 matched Baseline samples;
        each sample centred on the median of its 400 non-targeting guides; gene score = mean of 4 guides.
        Group statistic = median across animals; Wilcoxon signed-rank vs 0; rank among 795 genes;
        null = 100 random 4-guide sets drawn from non-targeting guides ("pseudo-genes").
        STK11-vs-NTC interaction = difference of medians across animals (pooled over groups), Mann-Whitney, BH-FDR.
QC    : Group7_STK11_82431 excluded (349 total reads). Group3_NTC_82364 excluded from pooled interaction test
        (near-duplicate of Group3_NTC_82346, Pearson r = 0.995 on raw counts).
"""
import pandas as pd, numpy as np, re, warnings
from scipy import stats
from statsmodels.stats.multitest import multipletests
warnings.filterwarnings('ignore')
IN = '/tmp/world/filesystem/'
OUT = '/tmp/outputs/analysis_tables/'
c = pd.read_csv(IN+'crispr_invivo_guide_counts.csv.gz')
demux = pd.read_csv(IN+'crispr_invivo_ngs_demux.csv.gz')
allcols = list(c.columns[3:])
X = c[allcols].astype(float)
isntc = c.gene_sgrna_id.str.startswith('NegCtrl').values

# ---------- QC ----------
def gini(x):
    x = np.sort(np.asarray(x, float)); n = len(x)
    return (2*np.arange(1, n+1)-n-1).dot(x)/(n*x.sum()) if x.sum() > 0 else np.nan
qc = pd.DataFrame({'total_reads': X.sum(), 'frac_guides_zero': (X == 0).mean(), 'gini': X.apply(gini)})
qc['run'] = qc.index.map(dict(zip(demux.sample_name, demux.ngs_sample_id)))
lcq = np.log2(X/X.sum()*1e6+1)
tum = [s for s in allcols if s.startswith('Group')]
C = lcq[tum].corr(); np.fill_diagonal(C.values, np.nan)
qc.loc[tum, 'max_r_to_other_tumour'] = C.max()
qc.loc[tum, 'most_similar_tumour'] = C.idxmax()
qc.round(4).to_csv(OUT+'invivo_screen_sample_QC.csv')

EXCLUDE = ['Group7_STK11_82431']
cols = [s for s in allcols if s not in EXCLUDE]
lc = np.log2(X[cols]/X[cols].sum()*1e6+1)
base = {bg: lc[[s for s in cols if s.startswith('Baseline_'+bg)]].mean(axis=1) for bg in ['NTC', 'STK11']}
L = {}
for s in cols:
    if s.startswith(('Plasmid', 'Baseline')): continue
    bg = 'NTC' if '_NTC' in s else 'STK11'
    l = lc[s]-base[bg]
    L[s] = l-np.median(l[isntc])
L = pd.DataFrame(L); L['gene'] = c.gene_symbol.values
Gs = L[~isntc].groupby('gene').mean()
rng = np.random.default_rng(0); ntc_idx = np.where(isntc)[0]
P = pd.DataFrame({f'pseudoNTC_{k}': L.iloc[rng.choice(ntc_idx, 4, replace=False)].drop(columns='gene').mean() for k in range(100)}).T
Gall = pd.concat([Gs, P])
Gall.to_csv(OUT+'invivo_gene_scores_per_animal.csv')

groups = [f'Group{i}' for i in range(1, 9)]+['Endpoint_NTC', 'Endpoint_STK11']
rows = []
for g in groups:
    cc = [s for s in Gs.columns if s.startswith(g+'_')]
    med = Gall[cc].median(axis=1)
    real = med[~med.index.str.startswith('pseudo')]
    mg = Gall.loc['Mgat1', cc]
    rows.append(dict(group=g, background=('NTC' if ('NTC' in g or int(g[-1]) <= 4) else 'STK11') if g.startswith('Group') else g.split('_')[1],
                     n_samples=len(cc), Mgat1_median_LFC=round(mg.median(), 2), frac_samples_Mgat1_below0=round((mg < 0).mean(), 2),
                     wilcoxon_p=(stats.wilcoxon(mg).pvalue if len(mg) > 5 else np.nan),
                     Mgat1_rank_of_795_most_depleted=int(real.rank()['Mgat1']),
                     pseudoNTC_median_sd=round(med[med.index.str.startswith('pseudo')].std(), 2)))
res = pd.DataFrame(rows)
res.to_csv(OUT+'invivo_Mgat1_by_group.csv', index=False)
print(res.to_string(index=False))

# per-guide
pg = {}
for g in groups:
    cc = [s for s in L.columns if s.startswith(g+'_')]
    pg[g] = L.loc[L.gene == 'Mgat1', cc].median(axis=1).values
pd.DataFrame(pg, index=['Mgat1_1', 'Mgat1_2', 'Mgat1_3', 'Mgat1_4']).round(2).to_csv(OUT+'invivo_Mgat1_per_guide_by_group.csv')

# interaction
genes = [g for g in Gs.index]
ntc_cols = [s for s in Gs.columns if re.match(r'Group[1-4]_', s) and s != 'Group3_NTC_82364']
stk_cols = [s for s in Gs.columns if re.match(r'Group[5-8]_', s)]
diff = Gs.loc[genes, stk_cols].median(axis=1)-Gs.loc[genes, ntc_cols].median(axis=1)
ps = pd.Series({g: stats.mannwhitneyu(Gs.loc[g, stk_cols], Gs.loc[g, ntc_cols]).pvalue for g in genes})
fdr = pd.Series(multipletests(ps.values, method='fdr_bh')[1], index=ps.index)
pdiff = P[stk_cols].median(axis=1)-P[ntc_cols].median(axis=1)
inter = pd.DataFrame({'median_STK11': Gs.loc[genes, stk_cols].median(axis=1), 'median_NTC': Gs.loc[genes, ntc_cols].median(axis=1),
                      'diff_STK11_minus_NTC': diff, 'z_vs_pseudoNTC': (diff-pdiff.mean())/pdiff.std(), 'mwu_p': ps, 'bh_fdr': fdr}).sort_values('diff_STK11_minus_NTC')
inter.to_csv(OUT+'invivo_STK11_vs_NTC_interaction_all_genes.csv')
print(inter.head(10).round(3).to_string())

# group diagnostics (used only to propose a tentative group->condition mapping)
panel = {'Cd274': ['Cd274'], 'MHC-I': ['B2m', 'H2-K1', 'H2-D1', 'Tap1'], 'IFNg_pathway': ['Jak1', 'Jak2', 'Stat1', 'Ifngr1', 'Ifngr2'], 'Ptpn2': ['Ptpn2'], 'Mgat1': ['Mgat1'], 'B4galt1': ['B4galt1']}
drows = []
for g in groups[:8]:
    cc = [s for s in Gs.columns if s.startswith(g+'_')]
    ids = [int(s.split('_')[-1]) for s in cc]
    r = dict(group=g, n=len(cc), animal_id_range=f'{min(ids)}-{max(ids)}', median_gini=round(qc.loc[[s for s in tum if s.startswith(g+'_')], 'gini'].median(), 2))
    for k, gl in panel.items():
        r[k+'_median_LFC'] = round(Gs.loc[gl, cc].mean(axis=0).median(), 2)
    drows.append(r)
pd.DataFrame(drows).to_csv(OUT+'invivo_group_diagnostics.csv', index=False)
