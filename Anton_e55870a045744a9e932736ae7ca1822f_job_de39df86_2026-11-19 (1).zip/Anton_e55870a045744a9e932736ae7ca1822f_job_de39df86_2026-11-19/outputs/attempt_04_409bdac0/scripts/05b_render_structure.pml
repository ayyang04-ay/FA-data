load /tmp/world/filesystem/MGAT1_C3744_UDP.cif, tern
remove solvent
remove chain B
hide everything
set ray_opaque_background, 0
bg_color white
show cartoon, tern and polymer
color grey80, tern and polymer
color lightorange, tern and polymer and resi 385-445
show sticks, resn UDP
color marine, resn UDP and elem C
show spheres, resn MN
set sphere_scale, 0.6
color purple, resn MN
show sticks, resn C3744
color red, resn C3744 and elem C
show sticks, (resi 289+211) and sidechain and polymer
color cyan, (resi 289+211) and elem C and polymer
hide sticks, resn EDO or resn GOL
pseudoatom p1, selection=resn C3744
pseudoatom p2, selection=resn UDP
distance d1, p1, p2
hide labels, d1
color black, d1
set dash_width, 2
orient resn C3744 or resn UDP
turn y, -20
zoom resn C3744 or resn UDP, 12
set ray_trace_mode, 1
set antialias, 2
png /tmp/outputs/figures/Fig3b_ternary_structure.png, width=1400, height=1000, dpi=200, ray=1
