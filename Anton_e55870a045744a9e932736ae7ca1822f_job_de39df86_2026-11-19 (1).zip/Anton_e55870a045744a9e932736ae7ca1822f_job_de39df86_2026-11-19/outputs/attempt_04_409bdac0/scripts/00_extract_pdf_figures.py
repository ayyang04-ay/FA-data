"""Extract the embedded raster figure from every page of the three client PDFs (pypdf; genomics env).
Each page of assay_figures.pdf / phenotype_figures.pdf carries one image; text captions extracted separately."""
import pypdf, os
os.makedirs('/tmp/work/img', exist_ok=True)
for f in ['assay_figures.pdf','phenotype_figures.pdf','experimental_records.pdf']:
    r = pypdf.PdfReader('/tmp/world/filesystem/'+f)
    with open('/tmp/work/'+f.replace('.pdf','.txt'),'w') as out:
        for i,p in enumerate(r.pages):
            out.write('\n----- PAGE %d\n' % (i+1)); out.write(p.extract_text())
            for j,im in enumerate(p.images):
                open('/tmp/work/img/%s_p%d.png' % (f.replace('.pdf',''), i+1),'wb').write(im.data)
