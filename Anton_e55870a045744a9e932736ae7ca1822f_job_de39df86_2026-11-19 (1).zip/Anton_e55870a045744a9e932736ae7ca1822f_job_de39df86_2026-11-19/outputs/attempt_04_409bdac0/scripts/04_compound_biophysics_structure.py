"""
Compound / biophysics / structure verification.
(a) Re-fit of UDP-Glo dose-response points digitised from assay_figures.pdf p1 (markers detected by morphological
    opening; axes calibrated from tick marks) -> 4-parameter logistic; compare to compound_properties.csv.
(b) DSF: derivative-peak positions digitised from assay_figures.pdf p4, calibrated two ways
    (plot gridlines vs printed axis labels) and compared with dsf_thermal_shift.csv.
(c) Crystal structures: ligand contacts, ligand-site distances, symmetry contacts, CA shifts (gemmi).
(d) ANT-3744 2D structure rebuilt from the CIF chem_comp bond table (RDKit) -> formula/MW/TPSA vs registry.
"""
import numpy as np, pandas as pd, gemmi, warnings, math
from PIL import Image
from scipy import ndimage as ndi
from scipy.optimize import curve_fit
warnings.filterwarnings('ignore')
IN='/tmp/world/filesystem/'; IMG='/tmp/work/img/'; OUT='/tmp/outputs/analysis_tables/'
# (a) ---------------------------------------------------------------
im = np.array(Image.open(IMG+'assay_figures_p1.png').convert('L')); dark = im < 110
y,x = np.ogrid[-6:7,-6:7]; op = ndi.binary_opening(dark, structure=(x*x+y*y<=36))
lab, n = ndi.label(op); cents = np.array(ndi.center_of_mass(op, lab, range(1,n+1)))
panels = {'ANT-0592':((200,840),(100,560),215.5,-2,161.5,529.5),'ANT-1476':((985,1620),(100,560),998.5,-2,161.5,529.5),
          'ANT-2118':((1770,2400),(100,560),1782.5,-2,161.5,529.5),'ANT-3105':((200,840),(745,1200),215.5,-2,807.5,1174.5),
          'ANT-3744':((985,1620),(745,1200),998.5,-2,807.5,1174.5),'ANT-4267':((1770,2400),(745,1200),1782.5,-3,807.5,1174.5)}
ppd = (822.5-215.5)/6
reg = pd.read_csv(IN+'compound_properties.csv').set_index('compound')
f4 = lambda c,b,t,ic,h: b+(t-b)/(1+(c/ic)**h)
rows=[]; pts=[]
for nm,(cr,rr,x0,l0,y100,y0) in panels.items():
    m=(cents[:,1]>=cr[0])&(cents[:,1]<cr[1])&(cents[:,0]>=rr[0])&(cents[:,0]<rr[1]); p=cents[m]; p=p[np.argsort(p[:,1])]
    conc=10**(l0+(p[:,1]-x0)/ppd); act=(y0-p[:,0])/(y0-y100)*100
    pts += [(nm,c,a) for c,a in zip(conc,act)]
    (b,t,ic,h),_=curve_fit(f4,conc,act,p0=[5,100,np.median(conc),1],bounds=([-20,50,1e-4,0.2],[60,130,1e5,5]),maxfev=20000)
    absic = ic*((t-b)/(50-b)-1)**(1/h)
    rows.append(dict(compound=nm, n_points=len(p), top_conc_plotted_uM=round(conc.max()), fitted_bottom_pct=round(b,1), fitted_top_pct=round(t,1),
                     hill=round(h,2), refit_abs_IC50_uM=round(absic,3), registry_IC50_uM=reg.loc[nm,'udpglo_ic50_um'], ratio_registry_over_refit=round(reg.loc[nm,'udpglo_ic50_um']/absic,2),
                     lowest_activity_plotted_pct=round(act.min(),1)))
pd.DataFrame(pts,columns=['compound','conc_uM','activity_pct']).round(4).to_csv(OUT+'udpglo_points_digitised.csv',index=False)
ic = pd.DataFrame(rows); ic.to_csv(OUT+'udpglo_IC50_refit_vs_registry.csv',index=False); print(ic.to_string(index=False))
# (b) ---------------------------------------------------------------
rgb = np.array(Image.open(IMG+'assay_figures_p4.png').convert('RGB')).astype(int)
ref = {'DMSO':(174,80,157),'UDP 5000 uM':(249,229,117),'ANT-3744 100 uM':(91,147,65),'ANT-3744 + UDP':(89,106,176)}
dsf = pd.read_csv(IN+'dsf_thermal_shift.csv').set_index('sample')
drow=[]
for nm,c in ref.items():
    mask = np.sqrt(((rgb-np.array(c))**2).sum(axis=2))<60; mask[:600,:]=False; mask[930:,:]=False; mask[:,:150]=False; mask[:,1090:]=False
    ys,xs=np.nonzero(mask); cols=np.unique(xs); top=np.array([ys[xs==cc].min() for cc in cols]); xpk=cols[top<=top.min()+2].mean()
    tg = 20+(xpk-151.5)/((1087.5-151.5)/80); tl = 20+(xpk-134.0)/((1047.0-134.0)/80)
    key = {'UDP 5000 uM':'UDP','ANT-3744 100 uM':'ANT-3744','ANT-3744 + UDP':'ANT-3744 + UDP'}.get(nm)
    drow.append(dict(condition=nm, peak_px=round(xpk,1), Tm_gridline_calibrated=round(tg,1), Tm_label_calibrated=round(tl,1), csv_Tm=(dsf.loc[key,'tm_mean_c'] if key else None), csv_dTm=(dsf.loc[key,'delta_tm_c'] if key else None)))
D = pd.DataFrame(drow); base_g = D.Tm_gridline_calibrated[0]; base_l = D.Tm_label_calibrated[0]
D['dTm_gridline'] = (D.Tm_gridline_calibrated-base_g).round(1); D['dTm_label']=(D.Tm_label_calibrated-base_l).round(1)
D.to_csv(OUT+'dsf_Tm_digitised_vs_csv.csv',index=False); print(D.to_string(index=False))
# (c) ---------------------------------------------------------------
def cen(r): return np.mean([a.pos.tolist() for a in r],axis=0)
srows=[]
for f in ['MGAT1_C3744.cif','MGAT1_C3744_UDP.cif']:
    st=gemmi.read_structure(IN+f); st.setup_entities(); mdl=st[0]
    ns=gemmi.NeighborSearch(mdl,st.cell,6).populate()
    for ch in mdl:
        lig=[r for r in ch if r.name=='C3744'][0]; udp=[r for r in ch if r.name=='UDP']; mn=[r for r in ch if r.name=='MN']
        cont=set(); sym=set()
        for a in lig:
            for mk in ns.find_atoms(a.pos,'\0',radius=4.0):
                cra=mk.to_cra(mdl)
                if cra.residue.name in ('C3744','HOH'): continue
                if mk.image_idx==0:
                    if cra.atom.pos.dist(a.pos)<=4.0: cont.add(f'{cra.residue.name}{cra.residue.seqid.num}')
                else:
                    im_pos = st.cell.find_nearest_pbc_image(a.pos, cra.atom.pos, mk.image_idx)
                    if im_pos.dist() <= 4.0: sym.add(f'{cra.residue.name}{cra.residue.seqid.num}')
        d289=min(a.pos.dist(b.pos) for a in lig for b in ch['289'][0]); d211=min(a.pos.dist(b.pos) for a in lig for b in ch['211'][0])
        srows.append(dict(structure=f, chain=ch.name, ligand_mean_B=round(np.mean([a.b_iso for a in lig]),1),
            contact_residues_4A=' '.join(sorted(cont,key=lambda s:int(''.join(c for c in s if c.isdigit())))),
            symmetry_mate_contacts_4A=' '.join(sorted(sym)), min_dist_to_UDP_A=(round(min(a.pos.dist(b.pos) for a in lig for b in udp[0]),1) if udp else None),
            centroid_dist_to_Mn_A=(round(float(np.linalg.norm(cen(lig)-cen(mn[0]))),1) if mn else None), min_dist_to_D289_A=round(d289,1), min_dist_to_D211_A=round(d211,1)))
S=pd.DataFrame(srows); S.to_csv(OUT+'structure_C3744_site.csv',index=False); print(S.to_string(index=False))
# refinement stats
ref_rows=[]
for f in ['MGAT1_apo.cif','MGAT1_UDP.cif','MGAT1_UDP_GlcNAc.cif','MGAT1_C3744.cif','MGAT1_C3744_UDP.cif']:
    b=gemmi.cif.read(IN+f).sole_block()
    ref_rows.append(dict(file=f, resolution_A=b.find_value('_refine.ls_d_res_high'), Rwork=b.find_value('_refine.ls_R_factor_R_work'), Rfree=b.find_value('_refine.ls_R_factor_R_free'),
        spacegroup=b.find_value('_symmetry.space_group_name_H-M'), CChalf_outer=b.find_value('_reflns_shell.pdbx_CC_half')))
R=pd.DataFrame(ref_rows); R.to_csv(OUT+'structure_refinement_stats.csv',index=False); print(R.to_string(index=False))
# (d) ---------------------------------------------------------------
from rdkit import Chem
from rdkit.Chem import Descriptors, rdMolDescriptors
blk=gemmi.cif.read(IN+'MGAT1_C3744.cif').sole_block()
at=[(r[1],r[2]) for r in blk.find('_chem_comp_atom.',['comp_id','atom_id','type_symbol']) if r[0]=='C3744']
bd=[(r[1],r[2],r[3].upper()) for r in blk.find('_chem_comp_bond.',['comp_id','atom_id_1','atom_id_2','value_order']) if r[0]=='C3744']
m=Chem.RWMol(); idx={}
for nme,el in at:
    a=Chem.Atom(el); a.SetNoImplicit(True); idx[nme]=m.AddAtom(a)
for a1,a2,o in bd: m.AddBond(idx[a1],idx[a2],{'SING':Chem.BondType.SINGLE,'DOUB':Chem.BondType.DOUBLE}[o])
mol=Chem.RemoveHs(m.GetMol()); Chem.SanitizeMol(mol)
kd=0.38e-6; le=-(1.987e-3*298.15*math.log(kd))/mol.GetNumHeavyAtoms()
out=dict(smiles=Chem.MolToSmiles(mol), formula=rdMolDescriptors.CalcMolFormula(mol), MW=round(Descriptors.MolWt(mol),2), TPSA=round(rdMolDescriptors.CalcTPSA(mol),1),
         HBD=rdMolDescriptors.CalcNumHBD(mol), heavy_atoms=mol.GetNumHeavyAtoms(), ligand_efficiency_kcal_per_HA=round(le,2), registry_MW=reg.loc['ANT-3744','mw'], registry_TPSA=reg.loc['ANT-3744','tpsa'])
pd.Series(out).to_csv(OUT+'ANT-3744_structure_check.csv'); print(out)
