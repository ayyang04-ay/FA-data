.libPaths(c("/opt/refdbs/rlib", .libPaths()))
suppressMessages({library(BSgenome.Hsapiens.UCSC.hg38); library(Biostrings); library(org.Hs.eg.db)})
guides <- c(MGAT1_1="GTTCCGAGAGCTGGCTACCG", MGAT1_2="ACTGGAAGGTGACAATACCC", MGAT1_3="GCCCGACCTGAGCAGCATTG", MGAT1_4="GGCCAGGGAAAAAGTCGGTG",
            B2M_sgRNA3="GGCCGAGATGTCTCGCTCCG", PDL1_sg1="GGTTCCCAAGGACCTATATG", PDL1_sg2="ACTGCTTGTCCAGATGACTT", sgPTPN2="CCATGACTATCCTCATAGAG",
            NTC1="AGTATGAGACTCATAGGGTG", NTC2="GAAGGCCTTAACACGTCGAC", NC77="ACCCATCGGGTGCGATATGG", ITC="ATTTGTAACATCTCTTCACG",
            lib_MGAT1_a="AAAGTACTCGAAGAAGTCCG", lib_MGAT1_b="AGTCCTGGCTAACGATGATG", lib_MGAT1_c="CCCTCAGTCAGCGCTCTCGA", lib_MGAT1_d="GATGCCCTGTCGAGCCAGCG")
genes <- c("MGAT1","B2M","CD274","PTPN2","POLB")
ids <- mapIds(org.Hs.eg.db, genes, "ENTREZID", "SYMBOL")
loc <- AnnotationDbi::select(org.Hs.eg.db, keys=ids, columns=c("SYMBOL","CHRLOC","CHRLOCEND"), keytype="ENTREZID")
print(loc)
chroms <- paste0("chr", c(1:22,"X","Y"))
res <- list()
for (ch in chroms) {
  s <- BSgenome.Hsapiens.UCSC.hg38[[ch]]
  for (g in names(guides)) {
    p <- DNAString(guides[[g]])
    f <- matchPattern(p, s, max.mismatch=0)
    r <- matchPattern(reverseComplement(p), s, max.mismatch=0)
    if (length(f) > 0) res[[length(res)+1]] <- data.frame(guide=g, chr=ch, start=start(f), strand="+", pam=as.character(subseq(s, end(f)+1, end(f)+3)))
    if (length(r) > 0) res[[length(res)+1]] <- data.frame(guide=g, chr=ch, start=start(r), strand="-", pam=as.character(reverseComplement(subseq(s, start(r)-3, start(r)-1))))
  }
}
out <- do.call(rbind, res)
print(out)
write.csv(out, "/tmp/work/guide_genome_hits.csv", row.names=FALSE)
