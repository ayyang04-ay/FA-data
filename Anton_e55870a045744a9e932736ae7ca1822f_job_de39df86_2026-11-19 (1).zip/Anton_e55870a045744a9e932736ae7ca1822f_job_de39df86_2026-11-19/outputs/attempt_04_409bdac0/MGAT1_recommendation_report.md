# MGAT1 small-molecule programme (Antera): independent verification and recommendation

**What this is based on.** The 16 files the client supplied, treated as ground truth, with a data cut-off of 1 Nov 2026. No external data supports any conclusion. Citation tags in brackets (N01–N58) point to rows in `number_provenance_ledger.csv`. Each row gives the client file and location plus the analysis output behind the number. Values marked **≈ (fig.)** were read off client figure images: they are approximate, and the client reported no n or statistics for them.

---

## 1. The call

**Do not advance. Hold the asset at late hit-to-lead. Fund one gated "proof-of-pharmacology" cycle with a stop rule agreed in advance.** Do not commit lead-optimisation chemistry, in vivo efficacy, or candidate-enabling budget until Gate 1 (Section 5) is passed.

**Why.**

1. **The genetic case is real.** In the client's own in vivo screen, Mgat1 is the most STK11-selective dependency of 795 genes. MGAT1 loss sensitises human tumour cells to antigen-specific CD8 T cells, and only catalytically active MGAT1 rescues that. In principle, an enzyme inhibitor is the right modality.
2. **No data show that any molecule in the series reproduces MGAT1 loss in a cell.** The package has no compound-treated cell, tumour or animal data. The series also has several features that make this the central risk:
   - maximum inhibition is about 90%;
   - the binding site is distal, 24–33 Å from the active site, and sits at a crystal contact;
   - all enzyme data are on human MGAT1;
   - there are no permeability, selectivity or PK data.
3. **The clinical framing runs ahead of the data.** The framing is "re-sensitise checkpoint-inhibitor-resistant, STK11-mutant NSCLC". But:
   - in the only combination experiment, MGAT1 loss and anti-PD-1 act independently (additive, not synergistic);
   - the screen dependency appears in every in vivo cohort, including (per the records) T-cell-deficient nude mice;
   - the STK11 link rests on one engineered mouse line (MC38, a colon-adenocarcinoma model), not NSCLC.

Gate 1 is cheap because the client already runs every assay it needs: PHA-L/GNA lectin flow, T-cell co-culture, glycoproteomics and MC38 models. Its outcome decides the asset. Partnering now would price the asset as a target hypothesis. The value-inflection point is Gate 1 and Gate 2.

**In one line for the client:** they have a well-supported *target hypothesis* and a good *biochemical tool series*, but not yet a drug programme.

| Programme claim | Status on the client's data | Where |
|---|---|---|
| MGAT1 loss is an STK11-selective in vivo vulnerability | **Supported**, but in one engineered mouse line | E1, G6 |
| Catalytic activity (not a scaffolding role) is what matters | **Supported** genetically, in cells and by in vivo rescue | E3 |
| The benefit is mediated by CD8 T cells | **Partly.** Yes in vitro and in the TCR-T xenograft; the screen implies a large T-cell-independent component | E2, E5, G5 |
| MGAT1 inhibition restores checkpoint-inhibitor response | **Not supported.** Effects are additive, with no synergy | G5 |
| Relevance to human STK11-mutant NSCLC | **Untested** | G6 |
| The series is a potent, structurally defined MGAT1 binder | **Supported** by biochemistry, SPR, DSF and crystallography (selectivity untested) | E6, G4 |
| The series inhibits MGAT1 in cells and phenocopies the knockout | **Untested**, with a partial-inhibition risk | G1–G3 |
| The series is usable in mouse models (mouse potency, PK) | **Untested** | G4 |
| Systemic inhibition is tolerated and spares T-cell function | **Untested** | G7 |

---

## 2. What the data establish: the case for the target

| # | Finding | Key numbers | Tags |
|---|---|---|---|
| E1 | **STK11-selective in vivo dependency** (MC38 pooled screen, druggable-genome library) | Mgat1 ranks **#1 of 795** genes for STK11-selective depletion.<br>• Difference in median gene score, sgStk11 vs sgNTC tumours: **−2.21 log2** (z = −8.1; Mann–Whitney p = 4×10⁻¹⁶; BH-FDR 1×10⁻¹³).<br>• Depleted in **68/69** sgStk11 tumours (group medians −2.4 to −3.5) vs 56/71 sgNTC tumours (−0.4 to −1.4).<br>• Not depleted in vitro (+0.20 / −0.30).<br>• Three of four guides concordant; the single-gene validation guide (Mgat1_4) is the most consistently strong.<br>• Downstream **B4galt1 ranks #3**, consistent with a complex-N-glycan pathway effect rather than a single-guide artefact.<br>• Robust to the normalisation choice and to excluding every flagged sample. | N01–N10 |
| E2 | **MGAT1 loss sensitises human tumour cells to antigen-specific CD8 killing** (genome-wide co-culture, NCI-H1703 + NY-ESO-1 TCR T cells) | MGAT1 ranks **#9 of 19,114** sensitiser genes (mean log2FC −0.78; all four guides −0.43 to −1.08; UMI-level p = 4×10⁻¹⁵).<br>• The screen behaves as expected: antigen (CTAG1B) #1 and B2M #2 enriched; IFNGR, JAK, STAT1 and TAP enriched.<br>• Arrayed validation (4 independent guides, 2 lines): relative viability **≈0.13–0.57 vs ≈0.75–0.92** for sgNTC (sgB2M ≈1.8–2.0) ≈ (fig.). | N17–N22 |
| E3 | **Catalytic activity is what matters** | In MGAT1-KO cells, WT cDNA restores PHA-L and T-cell resistance (viability ≈1.15). D289A and D211A/D289A do not (≈0.50–0.61; PHA-L ≈0) ≈ (fig.).<br>• In vivo (sgStk11/sgMGAT1 MC38), catalytic-dead vs WT re-expression gives **≈0.49×** tumour volume at d19, vs ≈0.89× where endogenous MGAT1 is intact ≈ (fig.).<br>• The client's structures place D211 on the Mn²⁺ and D289 at the donor site. | N24–N26 |
| E4 | **The KO produces the expected glycan phenotype** | PHA-L ≈0.03–0.05 of control; GNA ≈8–9× ≈ (fig.).<br>• Glycoproteomics, MGAT1-dependent glycoform share: 16.5%→9.6% (A375) and 19.1%→9.4% (H1703).<br>• Within-site fraction falls at 173/213 and 157/213 sites (p < 10⁻¹⁷). | N23, N27–N28 |
| E5 | **T-cell-dependent benefit in vivo** (xenograft + adoptive TCR-T) | sgMGAT1/sgNTC tumour-volume ratio at d19 ≈ (fig.):<br>• ≈0.85 with control T cells;<br>• **≈0.48** with 1×10⁶ NY-ESO-1 TCR-T cells;<br>• **≈0.30** with 2×10⁶ TCR-T cells.<br>The effect is dose-dependent and antigen-specific. | N29 |
| E6 | **The chemistry is real and tractable** | **ANT-4267:** IC50 0.043 µM; KD 0.03–0.07 µM.<br>**ANT-3744:** IC50 0.81 µM; KD 0.38 µM.<br>• IC50 tracks KD across ~25 analogues (log–log r ≈0.95) ≈ (fig.).<br>• Registry IC50s re-derive from the plotted points to within 1.0–1.4×.<br>• Co-crystals: 2.0 Å, R-free 0.20–0.21, one pose in 4/4 copies. ANT-3744 rebuilt from the CIF matches the registry (C23H25N5O3, MW 419.5, TPSA 110).<br>• **Binding is non-competitive with the donor:**<br>&nbsp;&nbsp;– SPR: KD 0.4→0.2 µM with 5 mM UDP; UDP KD 32→20 µM with ANT-3744;<br>&nbsp;&nbsp;– DSF ΔTm +2 (UDP), +6 (ANT-3744), +8 °C (both);<br>&nbsp;&nbsp;– both ligands are co-bound in the ternary structure.<br>&nbsp;&nbsp;This is a favourable feature given high Golgi UDP-GlcNAc.<br>• Kinetic solubility 178 / 96 µM; hepatocyte CLint 3.2 / <1.35 µL/min/10⁶ cells (species not stated).<br>• The two acquired "hits" were correctly triaged: ANT-1938 shows no binding; ANT-2214 shows non-saturable SPR and is a catechol-hydrazone. | N30–N45 |

![Fig. 1](figures/Fig1_invivo_screen_Mgat1.png)
*Fig. 1. In vivo screen re-analysis. (A) Mgat1 gene score per tumour by group. (B) STK11-selective depletion for all 795 genes.*

![Fig. 2](figures/Fig2_coculture_screen.png)
*Fig. 2. Co-culture screen. MGAT1 sits inside a glycan-supply/processing module. The PHA-L epitope enzyme (MGAT5) is not a hit.*

---

## 3. What the data do not establish: why not advance

**G1. No cellular or in vivo pharmacology. This is the decisive gap.** Across all 16 files there is no compound-treated cell, tumour or animal. That means no lectin shift, glycoproteomic shift, co-culture sensitisation, cytotoxicity, permeability or PK data.

- MGAT1 is a membrane-anchored Golgi enzyme; the assay constructs deliberately lack the transmembrane anchor. Cell entry and Golgi access are therefore prerequisites, and they are untested.
- ANT-3744 carries a basic primary amine and has TPSA 110. Only calculated logD is available.
- If cell data with the compounds exist and were not shared, they should be requested. Their absence is itself informative.

**G2. The inhibitors may be partial** (N33, N41, N43).

- ANT-3744, -4267, -3105 and -1476 all plateau at **≈8–10% residual activity** even at ≥100× KD. The MGAT1 knockout, by contrast, removes ≈95–97% of PHA-L signal.
- ANT-3744 binds 24 Å (closest atom) from UDP, 31 Å from Mn and 16 Å from the catalytic D289. The pocket is induced: loop 437–439 moves 2.0–4.9 Å on binding, versus ≤0.6 Å in the apo and UDP structures.
- The mechanism versus acceptor is unmeasured. The assay acceptor is a free oligosaccharide, not a Golgi glycoprotein.
- Whether a ~90% ceiling phenocopies KO is unknown. The floor may also be an uncorrected assay floor; this needs an orthogonal check.

**G3. The binding site is not validated in solution** (N42). In all four ligand copies the inhibitor is within 4 Å of a symmetry-related molecule (closest 3.0 Å, Glu278). There are no binding-site mutant data.

Such a mutant is also the key on-target control: a "drug-resistant MGAT1" that keeps catalytic activity. It is feasible precisely because the site is distal from the catalytic residues.

**G4. Human enzyme only; no selectivity.** Every biochemical, biophysical and structural datum is on human MGAT1, while all in vivo models are murine. There is no mouse Mgat1 potency, no panel against related glycosyltransferases (MGAT2/4/5, B4GALT1) and no broad off-target panel.

**G5. The checkpoint-inhibitor positioning is not supported as framed** (N48–N49, N05, N16).

In sgStk11 MC38 at d9 ≈ (fig.):

| Comparison | Tumour-volume ratio |
|---|---|
| sgMGAT1 vs control | ≈0.55× |
| anti-PD-1 vs IgG, in the NTC arm | ≈0.67× |
| anti-PD-1 vs IgG, in the sgMGAT1 arm | ≈0.63× |
| Combination vs control, observed | ≈0.34× |
| Combination vs control, Bliss-expected | ≈0.37× |

- The effects are independent/additive; there is no synergy.
- sgMGAT1 tumours were already half the size before treatment could act (d2: ≈80 vs ≈155 mm³).
- No n or statistics are given.

The screen dependency is present in **every** cohort. The four sgStk11 groups have medians of −2.4 to −3.5. The records list nude mice in the screen; unless that cohort was not sequenced, a large Mgat1 dependency exists without T cells.

- Marker-gene inference (Appendix C) places the nude cohorts at Groups 1 and 5. Under that mapping, about 70% of the sgStk11-background effect (−2.4 of ≈−3.3 log2) would be T-cell-independent, and anti-PD-1 would not deepen it.
- Under the alternative mapping the ICI conclusion is the same: anti-PD-1 does not deepen the dependency.
- The single-gene MC38 studies have no T-cell-deficient or CD8-depleted arm.

**G6. The STK11 link rests on one engineered mouse line (MC38), not an NSCLC model** (N46, N47).

- The screen compares one Stk11-KO population with one control population. The backgrounds differ at 266 genes (FDR < 0.05), and without a second independent Stk11 KO, STK11 biology cannot be separated from population idiosyncrasy.
- There is no NSCLC model. The human lines used (NCI-H1703, NCI-H1755, A375) carry no STK11 annotation in the package.
- In STK11-wild-type MC38, MGAT1-KO tumours were ≈1.5× *larger* ≈ (fig.).

**G7. A drug is not a tumour-restricted knockout.**

- Every genetic experiment deletes MGAT1 only in tumour cells. A systemic inhibitor will also act on T cells, NK cells, myeloid cells and normal tissue.
- The client's glycoproteomics show how pleiotropic MGAT1 loss is: 157–173 of 213 quantifiable sites shift.
- There are no data on T-cell function or tolerability under MGAT1 inhibition.

**G8. The in vivo evidence is weak in form** (N50–N53).

- No in vivo figure states n, error-bar type or statistics.
- Endpoint error bars (type not stated) are typically ≈30–90% of the mean (range ≈12–110%).
- The anti-PD-1 curves share their day 0–4 points with the IgG curves.
- In the engineering schematic (phenotype_figures p11), the sgMGAT1 MC38 lines descend from a single-cell clone (A-F5), whereas the control arm is a pool. Clonal effects are therefore not excluded, except in the WT-vs-dead cDNA comparison made within the clone.
- STK11 protein re-appears in the cDNA-rescue lines (≈6–15% of parental vs 3–5% in KO lines), and is highest in the catalytic-dead line. This confounds the rescue experiment in a model where STK11 status drives immune control.

![Fig. 3](figures/Fig3_compound_mechanism.png)
*Fig. 3. (A) Lead compounds plateau at ≈8–10% residual activity. (B) ANT-3744 binds a C-terminal pocket 24–33 Å from the donor site.*

![Fig. 4](figures/Fig4_invivo_genetic_effect_sizes.png)
*Fig. 4. Effect sizes from the single-gene in vivo figures. The combination is at Bliss additivity.*

---

## 4. Verification: what held up and what did not

**Held up on independent re-derivation.**

- **Registry values reproduce:**
  - IC50s re-derive from plotted points within 1.0–1.4×, or 1.0–1.15× with a 0–100-constrained fit;
  - SPR KDs agree with the sensorgram figures;
  - DSF ΔTm reproduces (2.0/5.9/7.5 vs 2/6/8 °C);
  - ANT-3744 identity, MW and TPSA match from the CIF.
- **Structures:**
  - resolution 1.55–2.01 Å, R-free 0.18–0.22;
  - D211 coordinates Mn²⁺;
  - the ligand pose is identical in all four copies.
- **Screen inventory:** matches the records table (8 groups; 6 plasmid, 6 baseline and 6 endpoint libraries).
- **Guide identities:**
  - the mouse validation guide is the library's Mgat1_4;
  - NC77 = NegCtrl_77;
  - PD-L1 and PTPN2 validation guides are library guides;
  - human MGAT1 guides map uniquely to MGAT1 in hg38. This is a reagent check only and is not used as evidence.
- **Glycoproteomics:** no glycosite violates the N-X-S/T sequon (848/910 confirmed; 62 undeterminable because the Asn sits at a peptide C-terminus); replicate r ≥ 0.99.

**Issues found.** Impact: **H** = changes what can be concluded; **M** = weakens a supporting claim; **L** = housekeeping.

| Impact | Issue | Evidence | Tag |
|---|---|---|---|
| H | The screen's group→condition map (nude / IgG / anti-PD-1) is not documented, so T-cell and anti-PD-1 dependence cannot be tested directly | records s2.1 lists Groups 1–8 with no condition | N16 |
| H | No n, error-bar definition or statistics on any in vivo figure | phenotype_figures p1, p4, p7, p8 | N50 |
| M | 141 tumour libraries vs 45 mice described (30 C57BL/6 + 15 nude) | records s2 vs count matrix | N14 |
| M | Duplicate library: Group3_NTC_82346 vs 82364 correlate at r = 0.98 on log-CPM (0.995 on raw counts). Other tumour pairs have a median of ~0.56, and the next-highest pair is 0.79. The IDs differ only by transposed digits, suggesting a labelling error | count matrix; demux | N12 |
| M | One failed library (Group7_STK11_82431, 349 reads); two heavily bottlenecked (Group3_NTC_82276, Group4_NTC_82321) | count matrix | N11, N13 |
| M | Low implant coverage (~28 cells/guide) explains the bottlenecks | records s2 | N15 |
| M | Anti-PD-1 arms share day 0–4 data points with the IgG arms | phenotype_figures p1 right | N48 |
| M | STK11 re-expression in rescue lines; sgMGAT1 clone vs control pool | phenotype_figures p6, p11 | N52, N53 |
| M | SPR: UDP reaches ≈12% of theoretical 1:1 Rmax while ANT-3744 reaches ≈133%, so the competition SPR is weak mechanistic evidence. Association time is 60 s in the records but ≈100 s in two panels | assay_figures p2–p3; records s6.4 | N37 |
| M | Screening hit ANT-0592: IC50 197 µM and KD 32 µM both exceed its kinetic solubility (11.8 µM). It was plotted to ~1000 µM; the "*" flag is undefined | compound_properties.csv; assay_figures p1 | N44 |
| L | Records state a top assay concentration of 100 µM, but 5 of 6 curves start at ≈1000 µM | records s6.3 vs assay_figures p1 | N34 |
| L | DSF figure axis labels are offset ≈2.3 °C from the plot's own gridlines; the CSV matches the gridlines (CSV right, labels wrong). Protein concentration typo ("18.6 nM" → 9.3 µM). Legend reads "HTS ANT-3744" although ANT-0592 is the HTS hit | assay_figures p4; dsf CSV; records s6.5 | N38 |
| L | Phenotype-figure housekeeping:<br>• captions of p1 and p8 appear swapped;<br>• vinculin loading control is not in the documented antibody list;<br>• no MGAT1 blot for the MC38 lines;<br>• mutant-enzyme activity data and PD-L1/CD276 blots are referenced but absent;<br>• the D211A single mutant is listed but not shown;<br>• the sgMGAT1 "Parental" bar is empty;<br>• PHA-L scales differ ~600× between p5 and p6 | phenotype_figures; records | N24 |
| L | Glycoproteomics:<br>• ~4% of glycoproteins (21/524) are nuclear/cytosolic (likely false site IDs);<br>• no proteome normalisation;<br>• KO channels carry ≈1.6× total signal;<br>• core-fucosylated Man5 rises in KO, which is biosynthetically unexpected | xlsx | N54 |
| L | The "ITC" guide is POLB_2 in the client's own genome-wide library | records s1; co-culture file | N55 |
| L | Records say "compiled 18 Aug 2026", but the PDF metadata creation date is 18 Nov 2026, later than the stated 1 Nov cut-off | PDF metadata | N57 |

None of these overturns the core genetic signal: the re-analysis reproduces it after excluding every flagged library. They must be fixed before any external use of the data, and the first issue (the missing group map) blocks the key mechanistic inference.

---

## 5. Next steps: a gated plan (design and comparisons, not protocols)

**Gate 0. Data housekeeping (immediate; no lab work).** Obtain or correct the following:

- the screen group→host/treatment map and animal numbers;
- resolution of the duplicate library;
- n, error-bar type and statistics plus individual-animal curves for every in vivo figure;
- SPR, DSF and assay-record corrections;
- the missing blots and mutant-enzyme activity data;
- hepatocyte species;
- **any compound-in-cell data that exist.**

Then re-run the screen contrasts that matter (nude vs C57BL/6+IgG; IgG vs anti-PD-1) for Mgat1 in each background.

**Gate 1. Cellular proof of pharmacology. This gate decides the asset.**

- *Question:* do the molecules inhibit MGAT1 in cells and reproduce the KO glycan phenotype?
- *Required comparisons:*
  - Compounds:
    - vehicle;
    - ANT-4267 and ANT-3744;
    - ≥8 series analogues spanning ≥2 logs of biochemical IC50;
    - a matched inactive analogue.
  - On-target controls:
    - genetic MGAT1-KO as the ceiling benchmark;
    - compound in KO cells (expect no further effect);
    - KO + WT cDNA;
    - KO + a **binding-site-mutant MGAT1 that keeps catalytic activity** (expect resistance).
  - Cell lines: NCI-H1703 plus ≥1 STK11-mutant NSCLC line.
- *Readouts:*
  - PHA-L loss and GNA gain (dose, time, washout);
  - a sialylation readout, since the co-culture screen points to galactosylation/sialylation (SLC35A1 #2, SLC35A2 #5, CMAS #11), not β1,6-branching (MGAT5 #2976);
  - viability without T cells.
- *Go:*
  - ≥80–90% of the KO effect on PHA-L at non-toxic concentrations;
  - cellular EC50 rank order tracks biochemical IC50;
  - inactive analogue, KO and resistant-mutant controls behave as predicted.
- *Stop:* maximal effect <50% of KO, or activity that does not track biochemical potency or is not reversed by the resistant mutant.

**Gate 1b. Mechanism, site and tool-readiness (in parallel).**

- Mechanism of inhibition versus donor and versus acceptor, using both the free oligosaccharide and a glycopeptide/glycoprotein acceptor.
- An orthogonal product-based assay to decide whether the ≈10% floor is real.
- Solution validation of the binding site with point mutants; this is also the source of the resistant allele.
- Mouse Mgat1 potency (needed before any MC38 work).
- Selectivity versus MGAT2/3/4/5, B4GALT1 and a broad panel; measured permeability.

**Gate 2. Functional phenocopy in human NSCLC models.**

- *Comparisons:*
  - compound:
    - tumour-only pre-treatment then washout, to isolate the tumour-intrinsic effect;
    - continuous exposure of tumour + T cells, which is what systemic dosing does;
  - benchmarks: genetic KO; sgB2M (resistance control); compound in KO cells;
  - an **isogenic STK11-null vs STK11-restored** NSCLC pair;
  - ≥2 T-cell donors and an E:T titration;
  - **T-cell fitness under compound**: activation, proliferation, cytotoxicity, cytokines.
- *Go:*
  - sensitisation ≥~70% of the KO benchmark (e.g. relative viability ≤~0.5 vs ~0.9 at E:T 0.2–0.4);
  - no effect in KO cells;
  - no loss of T-cell killing at the same exposure;
  - a larger effect in STK11-null than in STK11-restored cells.

**Gate 3. Mouse PK/PD, then efficacy.**

- **PK/PD:**
  - free exposure ≥ cellular EC80–90 across the dosing interval;
  - tumour PD (lectin/glycoform) dose–response;
  - tolerability.
  - If mouse potency is >3× weaker than human, use a surrogate tool or a humanised-target model.
- **Efficacy design:**
  - *Models:* sgStk11 MC38 and its STK11-WT counterpart; ideally also a Stk11-null lung model.
  - *Arms:* vehicle; compound at ≥2 doses; anti-PD-1; combination; genetic sgMGAT1 benchmark.
  - *Hosts:* immunocompetent vs T-cell-deficient or CD8-depleted.
  - *Conduct:* pre-specified n (if the client's error bars are SDs, their CVs imply ≈11–20 per arm to detect a 2-fold effect; synergy tests need several-fold more, N58); randomisation by size; blinded measurement; individual curves; time-to-endpoint.
  - *Analysis:* pre-declared Bliss/HSA synergy analysis.
- *Go:*
  - ≥50% of the genetic effect (KO ≈0.5× at d19) with a PD relationship;
  - STK11-selective.
  - To keep the ICI positioning: combination better than both monotherapies and above Bliss additivity.
  - If the effect persists in T-cell-deficient hosts, re-frame the thesis as STK11-selective tumour-intrinsic/innate vulnerability rather than "ICI re-sensitisation".

**Strategic comparison (low cost).** Confirm MGAT1 is the best node in its module before heavy chemistry spend.

- The co-culture screen ranks several glycan-module genes at or above MGAT1: SLC35A1 #2, SLC35A2 #5, UGP2 #6, GFPT1 #7, GALE #8.
- Most of these were not in the in vivo library.
- A small focused in vivo library (the glycan module ± Stk11) at much higher coverage than ~28 cells/guide would show whether MGAT1 is uniquely STK11-selective in vivo.

---

## 6. What would bring it back: criteria to move to "advance"

1. **Cellular target engagement.** At least one series compound delivers ≥80–90% of the KO glycan phenotype. On-target is shown by:
   - the KO and resistant-mutant controls;
   - an inactive analogue;
   - cellular/biochemical potency concordance.
2. **Functional phenocopy.** Compound-induced T-cell sensitisation close to the KO in ≥2 NSCLC models, including an STK11-null/restored pair, with no impairment of T-cell killing at effective exposure.
3. **Usable mouse tool.** Mouse Mgat1 potency and PK that give ≥EC80 free cover, with tumour PD demonstrated at a tolerated dose.
4. **In vivo efficacy.** A powered, pre-registered study in an STK11-null model reproducing the genetic effect, STK11-selective, with immune dependence resolved.
5. **For the ICI claim specifically.** Combination benefit beyond Bliss additivity, and screen contrasts (with the group map) showing T-cell/anti-PD-1 dependence.

---

## 7. What I set aside or discounted, and why

- **NY-ESO-1 expression across CCLE (phenotype_figures p9).** This is external data, not client-generated, so I set it aside. The antigen system is validated instead by the client's own p10 killing data.
- **ANT-0592 potency and KD.** Both were measured above solubility and carry an undefined flag. The hit-to-series origin is therefore not evidence; the series stands on its own SPR/structure data.
- **ANT-1938 and ANT-2214.** The client's own data show them to be a non-binder and a non-specific binder. I excluded them from the lead case.
- **Human co-culture lines as STK11 evidence.** Their STK11 status is undocumented. They are used only for the T-cell mechanism.
- **Screen libraries.** Group7_STK11_82431 (failed) was excluded throughout. Group3_NTC_82364 (duplicate) was excluded from pooled tests. The bottlenecked libraries were retained; conclusions are unchanged when they are removed.
- **Per-protein glycoproteomic changes** (e.g. HLA-C, CD276). These are not used, because there is no proteome normalisation and some composition assignments are questionable. Only class shares and within-site fractions are used.
- **SPR competition as proof of mechanism.** Down-weighted because of the UDP Rmax anomaly. I relied on the ternary structure and DSF additivity instead.
- **Figure-read tumour volumes, bars and blot densitometry.** Used only as approximate effect sizes. I make no significance claims, because none can be made without n.
- **Tentative screen-group mapping.** Used only as a hypothesis. Key conclusions are stated so that they hold under either mapping.
- **hg38 guide lookup.** A reagent-identity check only; it is not used as evidence for any biological claim.

---

## Appendix A. Key numbers and where they came from (condensed; full list in `number_provenance_ledger.csv`)

| Number | Client source | How derived |
|---|---|---|
| Mgat1 #1/795; Δ −2.21 log2; p 4×10⁻¹⁶ | crispr_invivo_guide_counts.csv.gz | Per-tumour log2(CPM+1) vs matched baseline mean, centred on 400 NTC guides; gene = mean of 4 guides; median sgStk11 − median sgNTC; Mann–Whitney, BH (script 01) |
| Group medians −2.4…−3.5 (Stk11), −0.4…−1.4 (NTC); ranks | same | Script 01 → invivo_Mgat1_by_group.csv |
| MGAT1 #9/19,114; −0.78 log2 | coculture_screen_umi_counts.csv.gz | UMI counts summed per guide; CPM; log2 ratio TCR-24 h / tumour-only; gene mean (script 02) |
| Glycoform share 16.5→9.6%, 19.1→9.4% | glycoproteomics_site_quant.xlsx (IGP_quant) | Composition classes (HexNAc≤2 without Fuc/NeuAc = MGAT1-independent); intensity shares (script 03) |
| IC50 0.043 / 0.814 µM; KD 0.03–0.07 / 0.38 µM | compound_properties.csv; spr_binding.csv | Registry values; re-derived from digitised points within 1.0–1.4× (script 04) |
| ≈8–10% residual activity | assay_figures.pdf p1 | 4-parameter fits to digitised points (script 04) |
| 24 Å / 31 Å / 16 Å distances; crystal contact | MGAT1_C3744.cif, MGAT1_C3744_UDP.cif | gemmi contact/symmetry analysis (script 04) |
| ΔTm 2/6/8 °C; label offset ≈2.3 °C | dsf_thermal_shift.csv; assay_figures.pdf p4 | Colour-traced derivative peaks, calibrated to gridlines vs labels (script 04) |
| Combination 0.34× vs Bliss 0.37× | phenotype_figures.pdf p1 (right) | Figure-read day-9 means (≈), ratio arithmetic |
| Adoptive transfer 0.85 / 0.48 / 0.30 | phenotype_figures.pdf p4 | Figure-read day-19 means (≈) |
| Rescue 0.49× vs 0.89× | phenotype_figures.pdf p7 | Figure-read endpoint means (≈) |

## Appendix B. Output files

- `MGAT1_recommendation_report.md` / `.docx`: this report.
- `number_provenance_ledger.csv`: 58 numbered claims with source and derivation.
- `figures/`: Fig1–Fig4, plus the structure render.
- `analysis_tables/` (26 CSVs):
  - in vivo screen: QC, per-animal gene scores, per-group Mgat1, per-guide, all-gene interaction, group diagnostics;
  - co-culture: guide, gene and UMI tests;
  - glycoproteomics: class shares, site-level test, QC;
  - compounds: IC50 re-fits and digitised points, IC50–KD, DSF, SPR Rmax;
  - structures: site, refinement statistics, loop shifts, ANT-3744 identity;
  - figure-read values: tumour endpoints, bars, blot densitometry;
  - guide check.
- `scripts/`: all code (run order in `scripts/README.md`).

## Appendix C. Tentative screen-group mapping (for the client to confirm; not used for any primary conclusion)

| Group | Background | Animal-ID block | Cd274 (PD-L1) KO | Ptpn2 KO | MHC-I KO | Inferred condition | Mgat1 median |
|---|---|---|---|---|---|---|---|
| 1 | NTC | 82498–82520 (contiguous) | +0.73 (no selection) | +0.39 | −2.56 (weakest) | nude? | −1.40 |
| 2 | NTC | interleaved | **−4.01** (PD-1 axis active) | −1.61 | −4.39 | C57BL/6 + IgG | −1.21 |
| 3 / 4 | NTC | interleaved | −0.70 / +0.13 | −2.68 / −3.08 (strongest) | −3.9 / −3.7 | C57BL/6 + anti-PD-1 | −0.83 / −0.37 |
| 5 | STK11 | 82523–82549 (contiguous) | +0.63 | −0.19 | −1.83 (weakest) | nude? | −2.39 |
| 6 | STK11 | interleaved | −0.80 | −1.04 | −3.29 | C57BL/6 + IgG? | −3.48 |
| 7 / 8 | STK11 | interleaved | −0.28 / +0.13 | −1.81 / −1.70 | −3.4 / −3.3 | C57BL/6 + anti-PD-1? | −3.32 / −3.16 |

This inference uses three signals: the contiguous animal-ID blocks (consistent with a separately sourced strain); weakest IFN-γ/PD-L1/Ptpn2 selection for no T cells; and strong Cd274-KO depletion only where the PD-1 axis is intact. It yields a nude / IgG / anti-PD-1 / anti-PD-1 structure in each background, which differs from the records' description (n = 30 + 15 mice). Either way:

- Mgat1 is depleted in all cohorts;
- anti-PD-1 does not deepen the dependency.
