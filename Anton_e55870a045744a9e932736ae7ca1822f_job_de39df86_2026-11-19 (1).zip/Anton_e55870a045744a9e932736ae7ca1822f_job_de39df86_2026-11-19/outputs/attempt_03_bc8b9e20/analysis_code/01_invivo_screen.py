"""
01_invivo_screen.py  --  MC38 in vivo pooled CRISPR screen (client files:
crispr_invivo_guide_counts.csv.gz, crispr_invivo_ngs_demux.csv.gz).

What it does (interpretation-level, not a protocol):
  1. Sample QC: library size, zero fraction, Gini; flags failed / duplicated libraries.
  2. Documents the evidence used to INFER the group -> arm key (no key was supplied).
  3. Per-tumour gene scores = median of guide log2FC vs same-background baseline,
     centred on the median of the 400 NegCtrl guides.
  4. Contrasts (Mann-Whitney across tumours, BH-FDR across 795 genes), interaction
     (OLS with HC3 SE), robustness to QC exclusions and guide aggregation.
Run:  micromamba run -n core python 01_invivo_screen.py   (writes ./out_invivo/)
"""
import os, numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
import statsmodels.formula.api as smf

SRC = '/tmp/world/filesystem'
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out_invivo'); os.makedirs(OUT, exist_ok=True)

c = pd.read_csv(f'{SRC}/crispr_invivo_guide_counts.csv.gz')
d = pd.read_csv(f'{SRC}/crispr_invivo_ngs_demux.csv.gz')
X = c.iloc[:, 3:].astype(float); X.index = c.gene_sgrna_id
genes = c.set_index('gene_sgrna_id').gene_symbol
neg = genes.index.str.startswith('NegCtrl')

def grp(s):
    p = s.split('_')
    return p[0] + '_' + p[1] if s.startswith('Group') else p[0] + ('_' + p[1] if len(p) > 2 else '')
groups = pd.Series({s: grp(s) for s in X.columns})

# ---------------- 1. QC ----------------
def gini(x):
    x = np.sort(np.asarray(x, float)); n = len(x)
    return (2 * np.arange(1, n + 1) - n - 1).dot(x) / (n * x.sum()) if x.sum() else np.nan
qc = pd.DataFrame({'group': groups, 'library_size': X.sum(), 'zero_fraction': (X == 0).mean(), 'gini': X.apply(gini)})
qc['run'] = d.set_index('sample_name').reindex(qc.index).ngs_sample_id
lc = np.log2(X / X.sum() * 1e6 + 1)
tum = [s for s in X.columns if s.startswith('Group')]
C = np.corrcoef(lc[tum].T.values); np.fill_diagonal(C, np.nan)
Cdf = pd.DataFrame(C, index=tum, columns=tum)
qc.loc[tum, 'max_corr_to_other_tumour'] = Cdf.max(axis=1)
qc.loc[tum, 'most_correlated_tumour'] = Cdf.idxmax(axis=1)
qc.to_csv(f'{OUT}/sample_qc.csv')
a, b = 'Group3_NTC_82346', 'Group3_NTC_82364'
dup_r = np.corrcoef(X[a], X[b])[0, 1]
print(f'Samples: {X.shape[1]}  guides: {X.shape[0]}  genes (non-control): {genes[~neg].nunique()}  NegCtrl: {neg.sum()}')
print('Tumour samples per group:', groups[tum].value_counts().sort_index().to_dict())
print(f'Failed library Group7_STK11_82431: reads={int(X["Group7_STK11_82431"].sum())}, zero fraction={qc.loc["Group7_STK11_82431","zero_fraction"]:.2f}')
print(f'Duplicate pair {a}/{b}: raw-count Pearson r={dup_r:.3f}; log-CPM r={Cdf.loc[a,b]:.3f}; '
      f'distribution of each tumour\'s max r to any other tumour: median={np.nanmedian(Cdf.max(axis=1)):.2f}, '
      f'95th pct={np.nanpercentile(Cdf.drop([a,b]).drop(columns=[a,b]).max(axis=1),95):.2f}')
for lab, mask in [('NTC tumours+baseline+endpoint', qc.index.str.contains('_NTC')), ('STK11 tumours+baseline+endpoint', qc.index.str.contains('_STK11')), ('Plasmid', qc.index.str.startswith('Plasmid'))]:
    runs = qc.loc[mask, 'run'].dropna()
    print(f'Sequencing batch for {lab}:', runs.str.split('-').str[1].value_counts().to_dict())

# plasmid concordance across the two sequencing batches (SG02: Plasmid_1-3; SG01: Plasmid_4-6)
_cpm = (X + 0.5).div(X.sum() + 0.5 * len(X), axis=1) * 1e6; _L2 = np.log2(_cpm)
_d = _L2[['Plasmid_4', 'Plasmid_5', 'Plasmid_6']].mean(axis=1) - _L2[['Plasmid_1', 'Plasmid_2', 'Plasmid_3']].mean(axis=1)
_d = _d - _d[neg].median(); _dg = _d.groupby(genes).median()
print(f'Plasmid SG01 vs SG02 (gene-level log2 difference): SD={_dg.std():.2f}; largest |diff| = {_dg.abs().max():.2f} '
      f'({_dg.abs().idxmax()} = guide NegCtrl_62); NegCtrl_62 baseline CPM NTC vs STK11: '
      f'{_cpm.loc["NegCtrl_62", ["Baseline_NTC_b1","Baseline_NTC_b2","Baseline_NTC_b3"]].mean():.0f} vs '
      f'{_cpm.loc["NegCtrl_62", ["Baseline_STK11_b1","Baseline_STK11_b2","Baseline_STK11_b3"]].mean():.0f}')

# ---------------- 2-3. gene scores ----------------
ARM = {'Group1_NTC': 'NTC_nude', 'Group2_NTC': 'NTC_IgG', 'Group3_NTC': 'NTC_aPD1', 'Group4_NTC': 'NTC_aPD1',
       'Group5_STK11': 'STK_nude', 'Group6_STK11': 'STK_IgG', 'Group7_STK11': 'STK_aPD1', 'Group8_STK11': 'STK_aPD1'}
FAILED = ['Group7_STK11_82431']; DUP = [a, b]
BOTTLENECK = ['Group3_NTC_82276', 'Group4_NTC_82321', 'Group1_NTC_82515']

def lfc_matrix(excl, pc=0.5):
    cpm = (X + pc).div(X.sum() + pc * len(X), axis=1) * 1e6
    L2 = np.log2(cpm)
    bn = L2[['Baseline_NTC_b1', 'Baseline_NTC_b2', 'Baseline_NTC_b3']].mean(axis=1)
    bs = L2[['Baseline_STK11_b1', 'Baseline_STK11_b2', 'Baseline_STK11_b3']].mean(axis=1)
    an = [s for s in tum if s not in excl]
    L = pd.DataFrame({s: L2[s] - (bn if '_NTC_' in s else bs) for s in an})
    return L - L[neg].median()

def gene_scores(excl, agg='median'):
    L = lfc_matrix(excl)
    G = L.groupby(genes).agg(agg)
    G = G.loc[[g for g in G.index if not g.startswith('BRDN')]]   # drop NegCtrl pseudo-genes
    return G, groups[G.columns].map(ARM), L

G, A, L = gene_scores(FAILED + DUP)

# arm-identity evidence (group medians of control genes)
ctrl = ['Cd274', 'Ptpn2', 'Jak1', 'Jak2', 'Stat1', 'Ifngr1', 'B2m', 'H2-K1', 'Tap1', 'Cd47', 'Adar', 'Mgat1']
gmed = G.loc[ctrl].T.groupby(groups[G.columns]).median().T
gmed.to_csv(f'{OUT}/arm_inference_control_genes_by_group.csv')
print('\nGroup medians of control genes (used to infer arms):\n', gmed.round(2).to_string())

def contrast(G, A, x, y):
    xa, xb = G.loc[:, A[A == x].index], G.loc[:, A[A == y].index]
    r = pd.DataFrame({'delta_log2': xa.median(axis=1) - xb.median(axis=1),
                      'p': stats.mannwhitneyu(xa, xb, axis=1, alternative='two-sided').pvalue,
                      'n_x': xa.shape[1], 'n_y': xb.shape[1]})
    r['fdr'] = multipletests(r.p, method='fdr_bh')[1]
    r['rank_most_depleted'] = r.delta_log2.rank().astype(int)
    return r

CONTRASTS = [('STK_IgG', 'NTC_IgG', 'B6 IgG2a: STK11 vs NTC'), ('STK_aPD1', 'NTC_aPD1', 'B6 anti-PD-1: STK11 vs NTC'),
             ('STK_nude', 'NTC_nude', 'nude: STK11 vs NTC'), ('STK_IgG', 'STK_nude', 'STK11: B6 IgG2a vs nude'),
             ('STK_aPD1', 'STK_nude', 'STK11: B6 anti-PD-1 vs nude'), ('NTC_IgG', 'NTC_nude', 'NTC: B6 IgG2a vs nude'),
             ('NTC_aPD1', 'NTC_nude', 'NTC: B6 anti-PD-1 vs nude'), ('STK_aPD1', 'STK_IgG', 'STK11: anti-PD-1 vs IgG2a'),
             ('NTC_aPD1', 'NTC_IgG', 'NTC: anti-PD-1 vs IgG2a')]
rows = []
for x, y, lab in CONTRASTS:
    r = contrast(G, A, x, y); r.to_csv(f'{OUT}/contrast_{x}_vs_{y}.csv')
    m = r.loc['Mgat1']
    rows.append(dict(contrast=lab, n=f"{int(m.n_x)} vs {int(m.n_y)}", Mgat1_delta_log2=round(m.delta_log2, 2),
                     p=f'{m.p:.2g}', FDR=f'{m.fdr:.2g}', Mgat1_rank_of_795=int(m.rank_most_depleted),
                     top5_depleted=', '.join(r.sort_values('delta_log2').index[:5])))
mg = pd.DataFrame(rows); mg.to_csv(f'{OUT}/mgat1_contrasts.csv', index=False)
print('\nMgat1 contrasts:\n', mg.to_string(index=False))

# interaction STK11 x immune host
def interaction(G, A, host):
    sel = A[A.isin(['NTC_nude', 'STK_nude', f'NTC_{host}', f'STK_{host}'])].index
    bg = [1 if A[s].startswith('STK') else 0 for s in sel]; im = [0 if A[s].endswith('nude') else 1 for s in sel]
    out = {}
    for g in G.index:
        dd = pd.DataFrame({'y': G.loc[g, sel].values, 'bg': bg, 'im': im})
        f = smf.ols('y ~ bg*im', dd).fit(cov_type='HC3'); out[g] = (f.params['bg:im'], f.pvalues['bg:im'])
    R = pd.DataFrame(out, index=['coef', 'p']).T; R['fdr'] = multipletests(R.p, method='fdr_bh')[1]
    R['rank_most_negative'] = R.coef.rank().astype(int); return R
for host in ['IgG', 'aPD1']:
    R = interaction(G, A, host); R.to_csv(f'{OUT}/interaction_STK11_x_{host}_vs_nude.csv')
    m = R.loc['Mgat1']
    print(f'\nInteraction STK11 x (B6-{host} vs nude): Mgat1 coef={m.coef:.2f}, p={m.p:.2g}, FDR={m.fdr:.2g}, rank {int(m.rank_most_negative)}/795; '
          f'top-10 most negative: {", ".join(R.sort_values("coef").index[:10])}')

# guide-level consistency for Mgat1
gl = []
for gid in ['Mgat1_1', 'Mgat1_2', 'Mgat1_3', 'Mgat1_4']:
    row = {'guide': gid, 'sequence': c.set_index('gene_sgrna_id').loc[gid, 'sgrna']}
    for arm in ['NTC_nude', 'NTC_IgG', 'NTC_aPD1', 'STK_nude', 'STK_IgG', 'STK_aPD1']:
        row[arm] = round(L.loc[gid, A[A == arm].index].median(), 2)
    for x, y in [('STK_IgG', 'NTC_IgG'), ('STK_aPD1', 'NTC_aPD1'), ('STK_nude', 'NTC_nude')]:
        row[f'p_{x}_vs_{y}'] = f"{stats.mannwhitneyu(L.loc[gid, A[A==x].index], L.loc[gid, A[A==y].index]).pvalue:.1e}"
    gl.append(row)
gl = pd.DataFrame(gl); gl.to_csv(f'{OUT}/mgat1_guides.csv', index=False)
print('\nMgat1 guide-level medians:\n', gl.to_string(index=False))

# in vitro endpoint (no immune pressure)
pc = 0.5; cpm = (X + pc).div(X.sum() + pc * len(X), axis=1) * 1e6; L2 = np.log2(cpm)
for bgname, bcols, ecols in [('NTC', ['Baseline_NTC_b1', 'Baseline_NTC_b2', 'Baseline_NTC_b3'], ['Endpoint_NTC_e1', 'Endpoint_NTC_e2', 'Endpoint_NTC_e3']),
                             ('STK11', ['Baseline_STK11_b1', 'Baseline_STK11_b2', 'Baseline_STK11_b3'], ['Endpoint_STK11_e1', 'Endpoint_STK11_e2', 'Endpoint_STK11_e3'])]:
    e = L2[ecols].mean(axis=1) - L2[bcols].mean(axis=1); e = e - e[neg].median()
    print(f'In vitro endpoint vs baseline ({bgname}): Mgat1 gene median = {e[genes == "Mgat1"].median():.2f} log2')

# robustness
rob = []
for name, ex in [('exclude failed only', FAILED), ('+ duplicate pair', FAILED + DUP), ('+ 3 bottlenecked tumours', FAILED + DUP + BOTTLENECK)]:
    for agg in ['median', 'mean']:
        Gr, Ar, _ = gene_scores(ex, agg)
        for x, y, lab in CONTRASTS[:5] + [CONTRASTS[7]]:
            m = contrast(Gr, Ar, x, y).loc['Mgat1']
            rob.append(dict(scenario=name, guide_aggregation=agg, contrast=lab, delta=round(m.delta_log2, 2), p=f'{m.p:.1e}', FDR=f'{m.fdr:.2g}', rank=int(m.rank_most_depleted)))
pd.DataFrame(rob).to_csv(f'{OUT}/robustness.csv', index=False)
print('\nRobustness table written:', f'{OUT}/robustness.csv')
