# Analysis code

Client files are read from `/tmp/world/filesystem` (read-only). Run the scripts in this order from this directory:

| Script | Environment | Input | Output |
|---|---|---|---|
| `00_extract_figure_images.py` | `mm genomics python` | assay_figures.pdf, phenotype_figures.pdf | `out_figure_images/` (embedded figure rasters) |
| `01_invivo_screen.py` | `mm core python` | crispr_invivo_guide_counts.csv.gz, crispr_invivo_ngs_demux.csv.gz | `out_invivo/` (sample QC, arm-inference table, all contrasts, interaction, Mgat1 guides, robustness) |
| `02_coculture_screen.py` | `mm core python` (about 3.5 min; `--skip-lineage` for a fast run) | coculture_screen_umi_counts.csv.gz | `out_coculture/` (guide and gene tables, genome-wide UMI-lineage tests) |
| `03_glycoproteomics.py` | `mm chem python` | glycoproteomics_site_quant.xlsx | `out_glyco/` (per-glycopeptide FC/FDR, class summary, immune-relevant glycoforms, sequon check) |
| `04_structures.py` | `mm core python` | MGAT1_*.cif | `out_structures/` (refinement stats, disorder, C3744 pocket, symmetry contacts, distances) |
| `05_biochem_biophys.py` | `mm core python` | compound_properties.csv, spr_*.csv, dsf_thermal_shift.csv, assay_figures.pdf images | `out_biochem/` (cooperativity, digitised IC50-vs-KD, dose-response floors, SPR Rmax check) |
| `06_figures.py` | `mm core python` (calls PyMOL) | outputs of 01–05 | `../figures/` |
| `07_build_ledger.py` | `mm chem python` | outputs of 01–05 + `out_figure_reads/phenotype_figure_reads.csv` | `../MGAT1_evidence_ledger.xlsx` |
| `08_render_memo.py` | `mm chem python` | `../MGAT1_recommendation_memo.md`, `../figures` | `.html` and `.pdf` versions of the memo |

`out_figure_reads/phenotype_figure_reads.csv` holds values read visually from `phenotype_figures.pdf`. These are approximate and marked "≈" in the memo.

Script 05 digitises figure images produced by script 00.

**Key analysis choices (interpretation-level)**

- **In vivo screen**
  - Per-tumour guide log2FC is computed against the mean of the three same-background baselines (CPM with 0.5 pseudocount), then centred on the median of the 400 NegCtrl guides.
  - The gene score is the median of the 4 guides.
  - Arms are compared with Mann–Whitney across tumours, with BH-FDR over 795 genes.
  - The STK11 × host interaction uses OLS with HC3 standard errors.
  - Excluded samples: one failed library and one duplicated pair. Robustness to these exclusions and to mean vs median guide aggregation is reported.
  - The arm labels (nude / isotype / anti-PD-1) are **inferred** from control genes because no key was supplied.
- **Co-culture screen**
  - There is a single sample per arm.
  - Guide-level log2 CPM ratio, centred on NegCtrl, with genes ranked by the median over guides that have ≥50 tumour-only reads.
  - UMI lineages with ≥5 tumour-only reads serve as pseudo-replicates, tested by Mann–Whitney against NegCtrl lineages with BH-FDR genome-wide.
- **Glycoproteomics:** log2 mean reporter-intensity difference KO vs NTC per intact glycopeptide, t-test, BH-FDR. Used directionally only, because the effect sizes are compressed relative to the lectin data.
