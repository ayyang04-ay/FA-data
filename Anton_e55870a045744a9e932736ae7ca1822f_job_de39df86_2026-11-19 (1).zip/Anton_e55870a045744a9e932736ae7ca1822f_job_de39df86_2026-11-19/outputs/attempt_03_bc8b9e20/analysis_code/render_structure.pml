load /tmp/world/filesystem/MGAT1_C3744_UDP.cif, tern
load /tmp/world/filesystem/MGAT1_UDP_GlcNAc.cif, donor
remove solvent
remove tern and chain B
remove donor and chain B
remove tern and resn EDO+GOL
super donor and name CA, tern and name CA
hide everything
bg_color white
show cartoon, tern and polymer
color grey80, tern and polymer
color lightorange, tern and polymer and resi 315-332
color aquamarine, tern and polymer and resi 430-445
show sticks, donor and resn UD1
color magenta, donor and resn UD1 and elem C
show sticks, tern and resn C3744
color green, tern and resn C3744 and elem C
show spheres, tern and resn MN
set sphere_scale, 0.5
color purple, tern and resn MN
pseudoatom pA, selection=donor and resn UD1
pseudoatom pB, selection=tern and resn C3744
distance dd, pA, pB
hide labels, dd
color black, dd
set dash_width, 4
hide everything, pA or pB
orient (tern and resn C3744) or (donor and resn UD1)
zoom tern and polymer, 1
set cartoon_transparency, 0.2
set ray_trace_mode, 1
png /tmp/struct_raw.png, width=1800, height=1400, dpi=300, ray=1
