"""
00_extract_figure_images.py -- extracts the embedded raster figure images from the client PDFs
(assay_figures.pdf, phenotype_figures.pdf) so that figure values can be digitised/read.
Run: micromamba run -n genomics python 00_extract_figure_images.py   (pypdf lives in the genomics env)
"""
import os, pypdf
SRC = '/tmp/world/filesystem'
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out_figure_images'); os.makedirs(OUT, exist_ok=True)
for pdf in ['assay_figures.pdf', 'phenotype_figures.pdf']:
    r = pypdf.PdfReader(f'{SRC}/{pdf}')
    for i, page in enumerate(r.pages, 1):
        for j, im in enumerate(page.images):
            fn = os.path.join(OUT, f'{pdf[:-4]}_p{i}_{j}.png'); open(fn, 'wb').write(im.data); print(fn)
