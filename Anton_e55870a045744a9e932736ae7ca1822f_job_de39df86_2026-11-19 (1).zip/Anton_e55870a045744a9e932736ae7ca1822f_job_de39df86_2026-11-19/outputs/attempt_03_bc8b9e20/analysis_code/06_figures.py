"""
06_figures.py -- regenerates figures in ../figures from the outputs of scripts 01-05.
Run after 01-05:  micromamba run -n core python 06_figures.py
(Structure figure additionally calls PyMOL: `pymol -c -q render_structure.pml` is run automatically.)
"""
import os, subprocess, textwrap, numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
from PIL import Image
H = os.path.dirname(os.path.abspath(__file__)); FIG = os.path.join(H, '..', 'figures'); os.makedirs(FIG, exist_ok=True)
SRC = '/tmp/world/filesystem'

# ---------- Fig 1: in vivo screen ----------
exec(open(os.path.join(H, '01_invivo_screen.py')).read().split('# ---------------- 2-3. gene scores ----------------')[0].split("# ---------------- 1. QC ----------------")[0])
ARM = {'Group1_NTC': 'NTC_nude', 'Group2_NTC': 'NTC_IgG', 'Group3_NTC': 'NTC_aPD1', 'Group4_NTC': 'NTC_aPD1',
       'Group5_STK11': 'STK_nude', 'Group6_STK11': 'STK_IgG', 'Group7_STK11': 'STK_aPD1', 'Group8_STK11': 'STK_aPD1'}
excl = ['Group7_STK11_82431', 'Group3_NTC_82346', 'Group3_NTC_82364']
pc = 0.5; cpm = (X + pc).div(X.sum() + pc * len(X), axis=1) * 1e6; L2 = np.log2(cpm)
bn = L2[['Baseline_NTC_b1', 'Baseline_NTC_b2', 'Baseline_NTC_b3']].mean(axis=1); bs = L2[['Baseline_STK11_b1', 'Baseline_STK11_b2', 'Baseline_STK11_b3']].mean(axis=1)
an = [s for s in X.columns if s.startswith('Group') and s not in excl]
L = pd.DataFrame({s: L2[s] - (bn if '_NTC_' in s else bs) for s in an}); L = L - L[neg].median()
Gs = L.groupby(genes).median(); A = groups[an].map(ARM)
mg = pd.read_csv(os.path.join(H, 'out_invivo', 'mgat1_contrasts.csv')).set_index('contrast')
order = ['NTC_nude', 'NTC_IgG', 'NTC_aPD1', 'STK_nude', 'STK_IgG', 'STK_aPD1']
labels = ['NTC\nnude\n(G1)', 'NTC\nB6 IgG2a\n(G2)', 'NTC\nB6 aPD-1\n(G3+G4)', 'STK11\nnude\n(G5)', 'STK11\nB6 IgG2a\n(G6)', 'STK11\nB6 aPD-1\n(G7+G8)']
cols = ['#9e9e9e'] * 3 + ['#c0392b'] * 3
fig, axes = plt.subplots(1, 3, figsize=(15, 4.8), gridspec_kw={'width_ratios': [1.4, 1, 1]})
for ax, gene, title in zip(axes, ['Mgat1', 'Cd274', 'Ptpn2'], ['Mgat1 (target)', 'Cd274 / PD-L1 (arm-identity control)', 'Ptpn2 (arm-identity control)']):
    data = [Gs.loc[gene, A[A == a].index].values for a in order]
    bp = ax.boxplot(data, widths=0.55, showfliers=False, patch_artist=True)
    for p, c in zip(bp['boxes'], cols): p.set_facecolor(c); p.set_alpha(0.25)
    for i, (dd, c) in enumerate(zip(data, cols)):
        ax.scatter(np.random.default_rng(1).normal(i + 1, 0.07, len(dd)), dd, s=10, color=c, alpha=0.8, zorder=3)
    ax.axhline(0, color='k', lw=0.8, ls='--'); ax.set_xticks(range(1, 7)); ax.set_xticklabels(labels, fontsize=7.5); ax.set_title(title, fontsize=10)
    ax.set_ylabel('Gene score per tumour\n(median guide log2FC vs baseline, NegCtrl-centred)', fontsize=8)
t = mg.loc
axes[0].text(0.02, 0.02, f"STK11 vs NTC (B6 IgG2a): Δ={t['B6 IgG2a: STK11 vs NTC','Mgat1_delta_log2']} log2, FDR={t['B6 IgG2a: STK11 vs NTC','FDR']}, rank 1/795\n"
             f"STK11 vs NTC (B6 aPD-1): Δ={t['B6 anti-PD-1: STK11 vs NTC','Mgat1_delta_log2']} log2, FDR={t['B6 anti-PD-1: STK11 vs NTC','FDR']}, rank 1/795\n"
             f"STK11 vs NTC (nude): Δ={t['nude: STK11 vs NTC','Mgat1_delta_log2']} log2, FDR={t['nude: STK11 vs NTC','FDR']}\n"
             f"STK11 aPD-1 vs IgG2a: Δ=+{t['STK11: anti-PD-1 vs IgG2a','Mgat1_delta_log2']}, p={t['STK11: anti-PD-1 vs IgG2a','p']} (no added effect)",
             transform=axes[0].transAxes, fontsize=7.2, va='bottom', bbox=dict(fc='white', ec='0.7'))
fig.suptitle('In vivo MC38 pooled screen (crispr_invivo_guide_counts.csv.gz): arm labels INFERRED from control genes (no key supplied)', fontsize=10)
plt.tight_layout(); plt.savefig(os.path.join(FIG, 'fig1_invivo_screen_mgat1.png'), dpi=200); plt.close()

# ---------- Fig 2: co-culture ----------
gg = pd.read_csv(os.path.join(H, 'out_coculture', 'gene_level_guide_summary.csv'), index_col=0)
g = pd.read_csv(os.path.join(H, 'out_coculture', 'guide_level.csv'), index_col=0)
s = gg.median_lfc.sort_values(); n = len(s); pos = {k: i for i, k in enumerate(s.index)}
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6), gridspec_kw={'width_ratios': [1.15, 1]})
ax1.scatter(np.arange(1, n + 1), s.values, s=3, color='0.75', rasterized=True)
for gname, c, xo, yo in [('MGAT1', '#c0392b', 1500, -0.25), ('PTPN2', 'k', 1500, -0.55), ('CFLAR', 'k', 1500, -0.2), ('B2M', 'k', -5000, 0.05),
                         ('CTAG1B', 'k', -5200, 0.0), ('STK11', '#16a085', -2500, -0.45), ('MGAT5', '#2980b9', 300, 0.45), ('MGAT2', '#2980b9', 800, 0.35)]:
    i = pos[gname]; y = s.iloc[i]; r = i + 1 if y < 0 else n - i
    ax1.scatter(i + 1, y, s=45, color=c, edgecolor='k', lw=0.4, zorder=3)
    ax1.annotate(f'{gname} (#{r} {"depleted" if y < 0 else "enriched"})', (i + 1, y), xytext=(i + 1 + xo, y + yo), fontsize=8, color=c, arrowprops=dict(arrowstyle='-', color=c, lw=0.6))
ax1.axhline(0, color='k', lw=0.6); ax1.set_xlabel('Gene rank (18,680 genes; most depleted → most enriched)')
ax1.set_ylabel('Median guide log2FC (TCR-T 24 h vs tumour-only)\nNegCtrl-centred'); ax1.set_title('A. Genome-wide ranking', fontsize=10)
sel = ['CFLAR', 'SLC35A1', 'GFPT1', 'PTPN2', 'GALE', 'UGP2', 'SLC35A2', 'MGAT1', 'MOGS', 'CMAS', 'MAN1A2', 'MGAT2', 'MGAT4B', 'MGAT5', 'STK11', 'CD274', 'JAK1', 'IFNGR1', 'B2M', 'CTAG1B']
colors = {'MGAT1': '#c0392b', 'MOGS': '#e67e22', 'MAN1A2': '#e67e22', 'MGAT2': '#2980b9', 'MGAT4B': '#2980b9', 'MGAT5': '#2980b9', 'STK11': '#16a085', 'CD274': '#16a085'}
colors.update({k: '#8e44ad' for k in ['SLC35A1', 'SLC35A2', 'GFPT1', 'GALE', 'UGP2', 'CMAS']})
for j, gname in enumerate(sel[::-1]):
    gl = g[(g.gene == gname) & (g.t0 >= 50)].lfc.values; c = colors.get(gname, 'k'); med = np.median(gl)
    ax2.scatter(gl, np.full(len(gl), j), s=14, color=c, alpha=0.7); ax2.plot([med, med], [j - 0.35, j + 0.35], color=c, lw=2.5)
    r = int(gg.loc[gname, 'rank_depleted']) if med < 0 else int(gg.loc[gname, 'rank_enriched'])
    ax2.text(2.45, j, f'#{r} {"dep" if med < 0 else "enr"}', fontsize=7.5, va='center', color=c)
ax2.set_yticks(range(len(sel))); ax2.set_yticklabels(sel[::-1], fontsize=8); ax2.axvline(0, color='k', lw=0.6); ax2.set_xlim(-4, 3.2)
ax2.set_xlabel('Guide log2FC (dots = individual guides; bar = median)'); ax2.set_title('B. Selected genes: glycosylation pathway vs controls', fontsize=10)
fig.suptitle('NCI-H1703 genome-wide TCR-T co-culture screen (coculture_screen_umi_counts.csv.gz; one sample per arm)', fontsize=10.5)
plt.tight_layout(); plt.savefig(os.path.join(FIG, 'fig2_coculture_screen.png'), dpi=200); plt.close()

# ---------- Fig 3: binding ----------
dig = pd.read_csv(os.path.join(H, 'out_biochem', 'ic50_vs_kd_digitised.csv'))
rho = stats.spearmanr(np.log10(dig.IC50_uM), np.log10(dig.KD_uM)).statistic
fig, axes = plt.subplots(1, 3, figsize=(15, 4.6), gridspec_kw={'width_ratios': [1.1, 1, 1]})
ax = axes[0]; ax.loglog(dig.IC50_uM, dig.KD_uM, 'o', color='0.3', ms=5)
for name, (x, y) in {'ANT-4267': (0.043, 0.07), 'ANT-3744': (0.814, 0.38), 'ANT-0592 (above solubility)': (197, 32.2)}.items():
    ax.loglog(x, y, 'o', color='#c0392b', ms=8); ax.annotate(name, (x, y), xytext=(x * 1.6, y * 0.45), fontsize=8, color='#c0392b')
xx = np.logspace(-2, 3, 10); ax.loglog(xx, xx, 'k--', lw=0.8); ax.set_xlabel('UDP-Glo IC50 (µM)'); ax.set_ylabel('SPR KD (µM)')
ax.set_title(f'A. Biochemical potency tracks binding\n(n={len(dig)} digitised from assay_figures p5; Spearman ρ={rho:.2f})', fontsize=9.5)
ax.text(0.03, 0.97, f'Registry values (compound_properties.csv) in red\nMedian IC50/KD ≈ {np.median(dig.IC50_uM/dig.KD_uM):.1f}-fold', transform=ax.transAxes, va='top', fontsize=8)
ax = axes[1]; vals = [32, 20, 0.4, 0.2]
ax.bar(range(4), vals, color=['#95a5a6', '#7f8c8d', '#27ae60', '#1e8449']); ax.set_yscale('log'); ax.set_ylim(0.1, 100)
ax.set_xticks(range(4)); ax.set_xticklabels(['UDP KD\nalone', 'UDP KD\n+20 µM\nANT-3744', 'ANT-3744 KD\nalone', 'ANT-3744 KD\n+5 mM UDP'], fontsize=8)
for i, v in enumerate(vals): ax.text(i, v * 1.15, f'{v} µM', ha='center', fontsize=8)
ax.set_ylabel('SPR KD (µM)'); ax.set_title('B. Not competitive with UDP: mutual ~1.6–2× affinity gain\n(spr_competition.csv)', fontsize=9.5)
ax = axes[2]; vals = [2, 6, 8]; ax.bar(range(3), vals, color=['#95a5a6', '#27ae60', '#1e8449'])
for i, v in enumerate(vals): ax.text(i, v + 0.15, f'+{v} °C', ha='center', fontsize=9)
ax.set_xticks(range(3)); ax.set_xticklabels(['UDP\n5 mM', 'ANT-3744\n100 µM', 'ANT-3744\n+ UDP'], fontsize=8.5); ax.set_ylim(0, 9.5)
ax.set_ylabel('ΔTm vs protein + 5% DMSO (°C)'); ax.set_title('C. Thermal shifts are additive (2 + 6 = 8 °C)\n(dsf_thermal_shift.csv)', fontsize=9.5)
plt.tight_layout(); plt.savefig(os.path.join(FIG, 'fig3_compound_binding.png'), dpi=200); plt.close()

# ---------- Fig 4: structure ----------
pml = os.path.join(H, 'render_structure.pml'); raw = '/tmp/struct_raw.png'
open(pml, 'w').write(f"""load {SRC}/MGAT1_C3744_UDP.cif, tern
load {SRC}/MGAT1_UDP_GlcNAc.cif, donor
remove solvent
remove tern and chain B
remove donor and chain B
remove tern and resn EDO+GOL
super donor and name CA, tern and name CA
hide everything
bg_color white
show cartoon, tern and polymer
color grey80, tern and polymer
color lightorange, tern and polymer and resi 315-332
color aquamarine, tern and polymer and resi 430-445
show sticks, donor and resn UD1
color magenta, donor and resn UD1 and elem C
show sticks, tern and resn C3744
color green, tern and resn C3744 and elem C
show spheres, tern and resn MN
set sphere_scale, 0.5
color purple, tern and resn MN
pseudoatom pA, selection=donor and resn UD1
pseudoatom pB, selection=tern and resn C3744
distance dd, pA, pB
hide labels, dd
color black, dd
set dash_width, 4
hide everything, pA or pB
orient (tern and resn C3744) or (donor and resn UD1)
zoom tern and polymer, 1
set cartoon_transparency, 0.2
set ray_trace_mode, 1
png {raw}, width=1800, height=1400, dpi=300, ray=1
""")
subprocess.run(['pymol', '-c', '-q', pml], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
site = pd.read_csv(os.path.join(H, 'out_structures', 'c3744_site.csv'))
im = Image.open(raw).convert('RGB'); a = np.array(im); nz = np.where(a.min(axis=2) < 245)
im = im.crop((max(0, nz[1].min() - 30), max(0, nz[0].min() - 30), min(a.shape[1], nz[1].max() + 30), min(a.shape[0], nz[0].max() + 30)))
fig = plt.figure(figsize=(12, 10.5)); ax = fig.add_axes([0.02, 0.22, 0.96, 0.70]); ax.imshow(im); ax.axis('off')
fig.suptitle('MGAT1 + ANT-3744 + UDP ternary complex (MGAT1_C3744_UDP.cif, chain A, 2.01 Å)\nsuperposed on the UDP-GlcNAc complex (MGAT1_UDP_GlcNAc.cif)', fontsize=11)
txt = [f'Green = ANT-3744 (C3744) in a C-terminal pocket: Y388 T389 G390 F394 G410 P412 P434 W437 E438 G439 Y440 D441 W444 (≤4 Å; same residues in all 4 ligand copies). Magenta = UDP-GlcNAc; purple = Mn; the DXD motif E209–D211 and D289 line the active site.',
       f'Dashed line: closest ANT-3744 ↔ UDP-GlcNAc atom distance {site.min_dist_to_UDPGlcNAc_A.min():.1f}–{site.min_dist_to_UDPGlcNAc_A.max():.1f} Å across copies (ligand centroids ~{site.centroid_dist_A.mean():.1f} Å). The compound does not occupy the donor/metal site; it binds ~20 Å from the GlcNAc that is transferred.',
       'Cyan = C-terminal segment 430–445 (E438 moves 4.4–5.1 Å on binding = induced fit). Orange = loop 315–332: disordered in apo and ANT-3744-only crystals; ordered with UDP-GlcNAc and in this ternary complex.',
       'Caveat: in every ligand copy the compound also contacts a symmetry-related protein molecule (3.0–3.9 Å) — part of the pose is lattice-supported.']
y = 0.205
for t_ in txt:
    lines = textwrap.wrap(t_, 160); fig.text(0.03, y, '\n'.join(lines), fontsize=8.8, va='top'); y -= 0.022 * len(lines) + 0.012
plt.savefig(os.path.join(FIG, 'fig4_structure_binding_site.png'), dpi=150); plt.close()

# ---------- Fig 5: glycoproteomics ----------
I = pd.read_csv(os.path.join(H, 'out_glyco', 'intact_glycopeptide_fc.csv'))
cats = [('Man5\n(HexNAc2Hex5)', I['Observed Modification'] == 'HexNAc(2)Hex(5)'),
        ('Man6–9', I['Observed Modification'].isin([f'HexNAc(2)Hex({k})' for k in (6, 7, 8, 9)])),
        ('HexNAc≥3\nnon-sialylated', I['class'] == 'HexNAc>=3 non-sialylated'), ('HexNAc≥3\nsialylated', I['class'] == 'HexNAc>=3 sialylated')]
fig, axes = plt.subplots(1, 2, figsize=(13, 4.8))
for ax, cl, title in zip(axes, ['A375', 'H1703'], ['A375 (melanoma)', 'NCI-H1703 (NSCLC)']):
    data = [I.loc[m, 'lfc_' + cl].dropna().values for _, m in cats]
    bp = ax.boxplot(data, showfliers=False, widths=0.5, patch_artist=True)
    for p, c in zip(bp['boxes'], ['#27ae60', '#95a5a6', '#2980b9', '#8e44ad']): p.set_facecolor(c); p.set_alpha(0.35)
    for i, dd in enumerate(data):
        ax.scatter(np.random.default_rng(0).normal(i + 1, 0.06, len(dd)), dd, s=3, alpha=0.35, color='k')
        ax.text(i + 1, 4.3, f'n={len(dd)}\nmedian {2 ** np.median(dd):.2f}×', ha='center', fontsize=8)
    ax.axhline(0, color='k', lw=0.7); ax.set_ylim(-5, 5); ax.set_xticks(range(1, 5)); ax.set_xticklabels([c for c, _ in cats], fontsize=8.5)
    ax.set_ylabel('log2 FC, MGAT1-KO vs NTC (intact glycopeptide, TMT)'); ax.set_title(title, fontsize=10)
fig.suptitle('Glycoproteomics (glycoproteomics_site_quant.xlsx, IGP_quant): direction is on-pathway (Man5 ↑, sialylated complex ↓) but magnitudes are compressed\n(HexNAc≥3 share of reporter intensity falls ~44%, whereas PHA-L lectin signal falls ~96%)', fontsize=9.5)
plt.tight_layout(); plt.savefig(os.path.join(FIG, 'fig5_glycoproteomics.png'), dpi=200); plt.close()
print('figures written to', os.path.abspath(FIG))
