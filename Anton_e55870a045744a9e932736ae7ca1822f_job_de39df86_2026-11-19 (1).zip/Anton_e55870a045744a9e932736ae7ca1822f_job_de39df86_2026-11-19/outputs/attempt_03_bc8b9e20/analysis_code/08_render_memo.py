"""
08_render_memo.py -- renders ../MGAT1_recommendation_memo.md to HTML (figures embedded) and PDF (ReportLab).
Run: micromamba run -n chem python 08_render_memo.py
"""
import os, re, base64, html
import markdown
import matplotlib
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping

H = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(H, '..')
MD = os.path.join(ROOT, 'MGAT1_recommendation_memo.md'); FIG = os.path.join(ROOT, 'figures')
FIGS = [('fig1_invivo_screen_mgat1.png', 'Figure 1. In vivo MC38 screen: per-tumour Mgat1 scores by background and (inferred) arm, with the two control genes used to infer arms [E10–E13].'),
        ('fig2_coculture_screen.png', 'Figure 2. NCI-H1703 TCR-T co-culture screen: genome-wide ranking and guide-level data for glycosylation-pathway genes and assay controls [E1–E3].'),
        ('fig3_compound_binding.png', 'Figure 3. Compound binding: IC50 vs KD across the series (digitised), SPR cooperativity with UDP, additive DSF shifts [E23–E25].'),
        ('fig4_structure_binding_site.png', 'Figure 4. ANT-3744 binds a C-terminal pocket ~20 Å from the active site; lattice contacts and induced fit [E26–E28].'),
        ('fig5_glycoproteomics.png', 'Figure 5. Glycoproteomics: on-pathway direction with compressed magnitudes [E21].')]
text = open(MD, encoding='utf-8').read()

# ---------------- HTML ----------------
body = markdown.markdown(text, extensions=['tables', 'sane_lists'])
figs_html = '<h2>Figures</h2>' + ''.join(
    f'<figure><img src="data:image/png;base64,{base64.b64encode(open(os.path.join(FIG, f), "rb").read()).decode()}" style="max-width:100%"/>'
    f'<figcaption>{html.escape(c)}</figcaption></figure>' for f, c in FIGS)
css = """body{font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;max-width:1100px;margin:30px auto;line-height:1.45;color:#222;font-size:14px}
table{border-collapse:collapse;margin:10px 0;font-size:12.5px}th,td{border:1px solid #bbb;padding:5px 7px;vertical-align:top}th{background:#eef2f5}
h1{font-size:22px}h2{font-size:18px;border-bottom:2px solid #ddd;padding-bottom:3px;margin-top:28px}code{background:#f3f3f3;padding:0 3px}
figure{margin:20px 0}figcaption{font-size:12.5px;color:#444}"""
open(os.path.join(ROOT, 'MGAT1_recommendation_memo.html'), 'w', encoding='utf-8').write(
    f'<!doctype html><html><head><meta charset="utf-8"><title>MGAT1 review</title><style>{css}</style></head><body>{body}{figs_html}</body></html>')

# ---------------- PDF ----------------
fd = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
pdfmetrics.registerFont(TTFont('DV', os.path.join(fd, 'DejaVuSans.ttf'))); pdfmetrics.registerFont(TTFont('DVB', os.path.join(fd, 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DVI', os.path.join(fd, 'DejaVuSans-Oblique.ttf'))); pdfmetrics.registerFont(TTFont('DVBI', os.path.join(fd, 'DejaVuSans-BoldOblique.ttf')))
pdfmetrics.registerFont(TTFont('DVM', os.path.join(fd, 'DejaVuSansMono.ttf')))
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DVB'); addMapping('DV', 0, 1, 'DVI'); addMapping('DV', 1, 1, 'DVBI')
base = ParagraphStyle('b', fontName='DV', fontSize=8.6, leading=11.4, spaceAfter=3)
h1 = ParagraphStyle('h1', parent=base, fontName='DVB', fontSize=13.5, leading=17, spaceAfter=6)
h2 = ParagraphStyle('h2', parent=base, fontName='DVB', fontSize=11, leading=14, spaceBefore=8, spaceAfter=4, textColor=colors.HexColor('#1f3b57'))
cell = ParagraphStyle('c', parent=base, fontSize=7.4, leading=9.2, spaceAfter=0)
cellh = ParagraphStyle('ch', parent=cell, fontName='DVB')
bul = ParagraphStyle('bl', parent=base, leftIndent=10, bulletIndent=2, bulletFontName='DV')
bul2 = ParagraphStyle('bl2', parent=base, leftIndent=22, bulletIndent=14, bulletFontName='DV')
cap = ParagraphStyle('cap', parent=base, fontSize=7.8, leading=10, textColor=colors.HexColor('#444444'))

def inline(s):
    s = html.escape(s, quote=False)
    s = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', s)
    s = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'<i>\1</i>', s)
    s = re.sub(r'`(.+?)`', r'<font face="DVM">\1</font>', s)
    return s

story = []; lines = text.split('\n'); i = 0
avail_w = A4[0] - 30 * mm
while i < len(lines):
    ln = lines[i]
    if ln.startswith('# '): story.append(Paragraph(inline(ln[2:]), h1)); i += 1; continue
    if ln.startswith('## '): story.append(Paragraph(inline(ln[3:]), h2)); i += 1; continue
    if ln.strip() == '---': story.append(Spacer(1, 4)); i += 1; continue
    if ln.startswith('|'):
        rows = []
        while i < len(lines) and lines[i].startswith('|'):
            cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r':?-+:?', c) for c in cells): rows.append(cells)
            i += 1
        ncol = len(rows[0])
        data = [[Paragraph(inline(c), cellh if r == 0 else cell) for c in row] for r, row in enumerate(rows)]
        import math
        plain = lambda c: re.sub(r'[*`]', '', c)
        longest_word = [max(len(wd) for r in range(len(rows)) for wd in (plain(rows[r][k]).split() or [''])) for k in range(ncol)]
        minw = [lw * (4.6 if k == 0 else 4.3) + 8 for k, lw in enumerate(longest_word)]          # points needed for longest word
        wt = [math.sqrt(sum(len(plain(rows[r][k])) for r in range(len(rows))) / len(rows)) for k in range(ncol)]
        w = [avail_w * x / sum(wt) for x in wt]
        for _ in range(20):                      # enforce minimum widths, take space from widest columns
            short = [k for k in range(ncol) if w[k] < minw[k]]
            if not short: break
            need = sum(minw[k] - w[k] for k in short)
            for k in short: w[k] = minw[k]
            donors = [k for k in range(ncol) if k not in short]
            tot = sum(w[k] for k in donors)
            for k in donors: w[k] -= need * w[k] / tot
        t = Table(data, colWidths=w, repeatRows=1)
        t.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#999999')), ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e8eef3')),
                               ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3)]))
        story.append(t); story.append(Spacer(1, 5)); continue
    m = re.match(r'^(\s*)- (.*)', ln)
    if m:
        story.append(Paragraph(inline(m.group(2)), bul2 if len(m.group(1)) >= 2 else bul, bulletText='–' if len(m.group(1)) >= 2 else '•')); i += 1; continue
    m = re.match(r'^(\d+)\. (.*)', ln)
    if m:
        story.append(Paragraph(inline(m.group(2)), bul, bulletText=m.group(1) + '.')); i += 1; continue
    if ln.strip() == '': i += 1; continue
    para = [ln]; i += 1
    while i < len(lines) and lines[i].strip() and not re.match(r'^(#|\||- |\s+- |\d+\. |---)', lines[i]):
        para.append(lines[i]); i += 1
    story.append(Paragraph(inline(' '.join(para)), base))
story.append(PageBreak()); story.append(Paragraph('Figures', h2))
from PIL import Image as PILImage
for f, c in FIGS:
    pth = os.path.join(FIG, f); wpx, hpx = PILImage.open(pth).size
    wd = avail_w; ht = wd * hpx / wpx
    if ht > 200 * mm: ht = 200 * mm; wd = ht * wpx / hpx
    story.append(KeepTogether([Image(pth, width=wd, height=ht), Paragraph(inline(c), cap), Spacer(1, 8)]))

def footer(canv, doc):
    canv.saveState(); canv.setFont('DV', 7); canv.setFillColor(colors.grey)
    canv.drawString(15 * mm, 8 * mm, 'MGAT1 programme — independent review (client data only). Numbers trace to MGAT1_evidence_ledger.xlsx.')
    canv.drawRightString(A4[0] - 15 * mm, 8 * mm, f'p. {doc.page}'); canv.restoreState()
doc = SimpleDocTemplate(os.path.join(ROOT, 'MGAT1_recommendation_memo.pdf'), pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=13 * mm, bottomMargin=14 * mm,
                        title='MGAT1 programme — independent review and recommendation')
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print('written HTML and PDF')
