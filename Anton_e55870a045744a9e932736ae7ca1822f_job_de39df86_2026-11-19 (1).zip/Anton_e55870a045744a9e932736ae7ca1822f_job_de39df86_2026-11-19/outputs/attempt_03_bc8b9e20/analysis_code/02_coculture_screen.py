"""
02_coculture_screen.py -- NCI-H1703 genome-wide NY-ESO-1 TCR-T co-culture screen
(client file: coculture_screen_umi_counts.csv.gz; one sample per arm per records section 3).

Two complementary summaries:
  (a) guide level: UMI counts summed per guide -> log2 CPM ratio (TCR-T / tumour-only),
      centred on NegCtrl median; gene score = median over guides with >=50 tumour-only counts.
  (b) lineage level: each UMI barcode (>=5 tumour-only counts) is an independent lineage;
      gene vs NegCtrl lineages by Mann-Whitney, BH-FDR genome-wide. Provides a
      significance estimate despite the absence of biological replicates.
Run: micromamba run -n core python 02_coculture_screen.py [--skip-lineage]
"""
import os, sys, numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

SRC = '/tmp/world/filesystem'
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out_coculture'); os.makedirs(OUT, exist_ok=True)
df = pd.read_csv(f'{SRC}/coculture_screen_umi_counts.csv.gz',
                 dtype={'gene_symbol': 'category', 'sgrna_id': 'category', 'sgrna_sequence': 'category', 'genetype': 'category',
                        'umi_barcode': 'str', 'tumor_only_untreated': 'int32', 'MSCV_TCR_high_24hr': 'int32'})
T0, TC = df.tumor_only_untreated.sum(), df.MSCV_TCR_high_24hr.sum()
print(f'UMI rows {len(df):,}; guides {df.sgrna_id.nunique():,}; symbols {df.gene_symbol.nunique():,}; '
      f'tumour-only counts {T0:,}; TCR-T counts {TC:,}')

# (a) guide level
g = df.groupby('sgrna_id', observed=True).agg(gene=('gene_symbol', 'first'), seq=('sgrna_sequence', 'first'), gtype=('genetype', 'first'),
                                              n_umi=('umi_barcode', 'size'), t0=('tumor_only_untreated', 'sum'), tc=('MSCV_TCR_high_24hr', 'sum'))
g['lfc'] = np.log2(((g.tc + 1) / TC) / ((g.t0 + 1) / T0))
g['lfc'] -= g.loc[g.gtype == 'NegCtrl', 'lfc'].median()
print('Guide types:', g.gtype.value_counts().to_dict(), '| median UMIs/guide', g.n_umi.median(), '| median tumour-only reads/guide', g.t0.median())
gg = g[(g.t0 >= 50) & (g.gtype == 'other')].groupby('gene', observed=True).agg(n_guides=('lfc', 'size'), median_lfc=('lfc', 'median'),
                                                                                 min_lfc=('lfc', 'min'), max_lfc=('lfc', 'max'))
gg['rank_depleted'] = gg.median_lfc.rank().astype(int); gg['rank_enriched'] = (-gg.median_lfc).rank().astype(int)
gg.to_csv(f'{OUT}/gene_level_guide_summary.csv'); g.to_csv(f'{OUT}/guide_level.csv')
print(f'Genes ranked: {len(gg):,}')
show = ['CFLAR', 'SLC35A1', 'GFPT1', 'PTPN2', 'GALE', 'UGP2', 'SLC35A2', 'MGAT1', 'MOGS', 'CMAS', 'MAN1A2', 'MGAT2', 'MGAT4B', 'MGAT5',
        'STK11', 'CD274', 'CD276', 'JAK1', 'IFNGR1', 'B2M', 'CTAG1A', 'CTAG1B']
print(gg.loc[show].round(2).to_string())
print('MGAT1 guides:', g[g.gene == 'MGAT1'][['seq', 't0', 'tc', 'lfc']].round(2).to_dict('index'))

# records' validation guides vs library
rec = {'MGAT1_1': 'GTTCCGAGAGCTGGCTACCG', 'MGAT1_2': 'ACTGGAAGGTGACAATACCC', 'MGAT1_3': 'GCCCGACCTGAGCAGCATTG', 'MGAT1_4': 'GGCCAGGGAAAAAGTCGGTG',
       'B2M sgRNA3': 'GGCCGAGATGTCTCGCTCCG', 'PD-L1_sg1': 'GGTTCCCAAGGACCTATATG', 'PD-L1_sg2': 'ACTGCTTGTCCAGATGACTT', 'sgPTPN2': 'CCATGACTATCCTCATAGAG',
       'NTC-1': 'AGTATGAGACTCATAGGGTG', 'NTC-2': 'GAAGGCCTTAACACGTCGAC', 'ITC': 'ATTTGTAACATCTCTTCACG'}
seq2id = {s: i for i, s in g.seq.items()}
print('Records guides found in library:', {k: seq2id.get(v, 'not in library') for k, v in rec.items()})

# (b) lineage level
if '--skip-lineage' not in sys.argv:
    u = df[df.tumor_only_untreated >= 5].copy()
    u['lr'] = np.log2((u.MSCV_TCR_high_24hr + 0.5) / TC) - np.log2((u.tumor_only_untreated + 0.5) / T0)
    negv = u.loc[u.genetype == 'NegCtrl', 'lr']; u['lr'] -= negv.median(); negv = u.loc[u.genetype == 'NegCtrl', 'lr'].values
    res = []
    for gene, v in u[u.genetype == 'other'].groupby('gene_symbol', observed=True).lr:
        v = v.values
        res.append((gene, len(v), np.median(v) if len(v) else np.nan,
                    stats.mannwhitneyu(v, negv).pvalue if len(v) >= 10 else np.nan))
    R = pd.DataFrame(res, columns=['gene', 'n_lineages', 'median_lineage_log2ratio', 'p']).set_index('gene')
    ok = R.p.notna(); R.loc[ok, 'fdr'] = multipletests(R.loc[ok, 'p'], method='fdr_bh')[1]
    R.to_csv(f'{OUT}/gene_level_lineage_tests.csv')
    sig = R[R.fdr < 0.05]
    print(f'\nLineage tests: {ok.sum():,} genes tested; FDR<0.05: {len(sig)} ({(sig.median_lineage_log2ratio<0).sum()} depleted, {(sig.median_lineage_log2ratio>0).sum()} enriched)')
    print(R.loc[['MGAT1', 'MOGS', 'SLC35A1', 'PTPN2', 'CFLAR', 'MGAT2', 'MGAT5', 'B2M', 'STK11', 'CD274']].to_string())
