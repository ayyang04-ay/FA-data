"""
04_structures.py -- MGAT1 crystal structures (client mmCIF files).
Reports: resolution / R factors; ligands (occupancy, B); disordered segments; ANT-3744 (C3744) contacts;
distance from C3744 to UDP-GlcNAc after CA superposition; crystal-lattice (symmetry-mate) contacts;
per-residue CA shifts at the C-terminus and the 315-332 loop.
Run: micromamba run -n core python 04_structures.py
"""
import os, gemmi, numpy as np, pandas as pd
SRC = '/tmp/world/filesystem'
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out_structures'); os.makedirs(OUT, exist_ok=True)
FILES = ['MGAT1_apo', 'MGAT1_UDP', 'MGAT1_UDP_GlcNAc', 'MGAT1_C3744', 'MGAT1_C3744_UDP']

def load(f):
    st = gemmi.read_structure(f'{SRC}/{f}.cif'); st.remove_hydrogens(); st.setup_entities(); return st
def refine_stats(f):
    doc = gemmi.cif.read(f'{SRC}/{f}.cif'); b = doc.sole_block()
    g = lambda t: b.find_value(t)
    return dict(file=f, resolution=g('_refine.ls_d_res_high'), R_work=g('_refine.ls_R_factor_R_work'), R_free=g('_refine.ls_R_factor_R_free'),
                space_group=g('_symmetry.space_group_name_H-M'), mean_B=g('_refine.B_iso_mean'))
print(pd.DataFrame([refine_stats(f) for f in FILES]).to_string(index=False))

rows = []
for f in FILES:
    st = load(f)
    for ch in st[0]:
        nums = [r.seqid.num for r in ch if r.het_flag != 'H']
        gaps = [f'{a+1}-{b-1}' for a, b in zip(nums, nums[1:]) if b - a > 1]
        ligs = [f'{r.name}(occ {np.mean([a.occ for a in r]):.2f}, B {np.mean([a.b_iso for a in r]):.1f})' for r in ch if r.het_flag == 'H' and r.name != 'HOH']
        rows.append(dict(file=f, chain=ch.name, first=nums[0], last=nums[-1], missing=';'.join(gaps) or 'none', ligands='; '.join(ligs)))
chains = pd.DataFrame(rows); chains.to_csv(f'{OUT}/chains_ligands_disorder.csv', index=False); print('\n', chains.to_string(index=False))

def cas(ch): return {r.seqid.num: r['CA'][0].pos for r in ch if r.het_flag != 'H' and r.find_atom('CA', '*')}
ref = load('MGAT1_UDP_GlcNAc'); R = cas(ref[0]['A'])
ud1 = np.array([a.pos.tolist() for r in ref[0]['A'] if r.name == 'UD1' for a in r])
out = []
for f in ['MGAT1_C3744', 'MGAT1_C3744_UDP']:
    st = load(f); model = st[0]
    ns = gemmi.NeighborSearch(model, st.cell, 6).populate()
    for ch in model:
        M = cas(ch); core = [i for i in R if i in M and not 310 <= i <= 335]
        sup = gemmi.superpose_positions([R[i] for i in core], [M[i] for i in core]); T = sup.transform
        lig = [r for r in ch if r.name == 'C3744'][0]
        lp = np.array([T.apply(a.pos).tolist() for a in lig])
        D = np.linalg.norm(ud1[:, None, :] - lp[None, :, :], axis=2)
        contacts, sym = {}, {}
        for a in lig:
            for m in ns.find_atoms(a.pos, '\0', radius=4.0):
                cra = m.to_cra(model)
                if cra.residue.name in ('C3744', 'HOH'): continue
                nim = st.cell.find_nearest_image(a.pos, cra.atom.pos, gemmi.Asu.Any); dd = nim.dist()
                if dd > 4.0: continue
                key = f'{cra.residue.name}{cra.residue.seqid.num}'
                if nim.same_asu(): contacts[key] = min(contacts.get(key, 9), dd)
                else: sym[key] = min(sym.get(key, 9), dd)
        sh = {i: np.linalg.norm(np.array(T.apply(M[i]).tolist()) - np.array(R[i].tolist())) for i in range(430, 446) if i in M and i in R}
        imax = max(sh, key=sh.get)
        out.append(dict(file=f, chain=ch.name, CA_rmsd_to_UDPGlcNAc_complex=round(sup.rmsd, 2),
                        min_dist_to_UDPGlcNAc_A=round(D.min(), 1), centroid_dist_A=round(np.linalg.norm(ud1.mean(0) - lp.mean(0)), 1),
                        pocket_residues_le4A=' '.join(sorted(contacts, key=lambda k: int(''.join(filter(str.isdigit, k))))),
                        symmetry_mate_contacts_le4A='; '.join(f'{k} {v:.2f}' for k, v in sorted(sym.items(), key=lambda kv: kv[1])),
                        largest_Cterm_CA_shift=f'res {imax}: {sh[imax]:.2f} A'))
lig = pd.DataFrame(out); lig.to_csv(f'{OUT}/c3744_site.csv', index=False)
print('\n', lig.to_string(index=False))
