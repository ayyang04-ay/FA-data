"""
05_biochem_biophys.py -- compound registry, SPR, DSF and figure digitisation.
 * Tabulates compound_properties.csv, spr_binding.csv, spr_competition.csv, dsf_thermal_shift.csv.
 * Cooperativity factors from SPR competition.
 * Digitises assay_figures.pdf p5 (IC50 vs KD, 26 series compounds) and p1 (dose-response floors)
   from the embedded raster images (pixel-calibrated against axis ticks; approx. +/-0.03 log units).
 * Theoretical SPR Rmax (1:1) vs observed plateaus.
Run: micromamba run -n core python 05_biochem_biophys.py   (after 00_extract_figure_images.py)
"""
import os, io, numpy as np, pandas as pd
from scipy import stats, ndimage
from PIL import Image
SRC = '/tmp/world/filesystem'
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out_biochem'); os.makedirs(OUT, exist_ok=True)

cp = pd.read_csv(f'{SRC}/compound_properties.csv'); print(cp.to_string(index=False))
spr = pd.read_csv(f'{SRC}/spr_binding.csv'); comp = pd.read_csv(f'{SRC}/spr_competition.csv'); dsf = pd.read_csv(f'{SRC}/dsf_thermal_shift.csv')
print('\n', spr.to_string(index=False), '\n', comp.to_string(index=False), '\n', dsf.to_string(index=False))
k = comp.set_index(['analyte', comp.co_incubated_species.fillna('none')]).kd_um
print(f"\nCooperativity: ANT-3744 KD alone/with 5 mM UDP = {k[('ANT-3744','none')]/k[('ANT-3744','UDP')]:.1f}x; "
      f"UDP KD alone/with 20 uM ANT-3744 = {k[('UDP','none')]/k[('UDP','ANT-3744')]:.1f}x")
print(f"DSF: reference Tm implied = {dsf.tm_mean_c[0]-dsf.delta_tm_c[0]} C; additivity UDP+3744 = {dsf.delta_tm_c[0]+dsf.delta_tm_c[1]} vs observed {dsf.delta_tm_c[2]} C")
r = cp.set_index('compound')
for c in ['ANT-0592', 'ANT-3744', 'ANT-4267']:
    print(f"{c}: IC50/KD(steady state) = {r.loc[c,'udpglo_ic50_um']/r.loc[c,'spr_steady_state_kd_um']:.2f}; "
          f"KD/solubility = {r.loc[c,'spr_steady_state_kd_um']/r.loc[c,'kinetic_solubility_um']:.3f}; IC50/solubility = {r.loc[c,'udpglo_ic50_um']/r.loc[c,'kinetic_solubility_um']:.2f}")

# ---- figure images
def page_image(pdf, page):
    # images extracted by 00_extract_figure_images.py (genomics env, pypdf)
    fn = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out_figure_images', f'{pdf.replace(".pdf","")}_p{page}_0.png')
    if not os.path.exists(fn):
        raise SystemExit('Run 00_extract_figure_images.py first (micromamba run -n genomics python 00_extract_figure_images.py)')
    return Image.open(fn)

# IC50 vs KD scatter (p5). Axis calibration from tick marks: x 0.01->233.5 px, 172.2 px/decade; y 0.01->806.5 px, 114.7 px/decade
im = np.array(page_image('assay_figures.pdf', 5).convert('L')).astype(float)
d = (im < 110).astype(float); mask = np.zeros_like(d); mask[225:800, 240:1100] = 1; d *= mask
rr = 8; yy, xx = np.ogrid[-rr:rr + 1, -rr:rr + 1]; disk = ((xx ** 2 + yy ** 2) <= rr * rr).astype(float); disk /= disk.sum()
sc = ndimage.correlate(d, disk, mode='constant'); mx = ndimage.maximum_filter(sc, size=9)
pk = []
for y, x in np.argwhere((sc == mx) & (sc > 0.93)):
    if all(abs(y - py) > 3 or abs(x - px) > 3 for py, px in pk): pk.append((y, x))
pts = [(x, y) for y, x in pk if not (545 <= x <= 555 and 620 <= y <= 630)] + [(548, 626), (554, 626)]  # one elongated blob = 2 overlapping dots
dig = pd.DataFrame([(10 ** (-2 + (x - 233.5) / 172.2), 10 ** (-2 + (806.5 - y) / 114.7)) for x, y in pts], columns=['IC50_uM', 'KD_uM']).sort_values('IC50_uM')
dig.to_csv(f'{OUT}/ic50_vs_kd_digitised.csv', index=False)
rho = stats.spearmanr(np.log10(dig.IC50_uM), np.log10(dig.KD_uM))
ratio = dig.IC50_uM / dig.KD_uM
print(f'\nDigitised IC50-vs-KD: n={len(dig)}, Spearman rho={rho.statistic:.2f} (p={rho.pvalue:.1e}); median IC50/KD={ratio.median():.2f} '
      f'(range {ratio.min():.2f}-{ratio.max():.2f}); KD<IC50 for {(ratio>1).mean():.0%}')

# dose-response floors (p1). y: 100% at 161.5/807.5 px, 0% at 529.5/1174.5 px (top/bottom rows)
im = np.array(page_image('assay_figures.pdf', 1).convert('L')).astype(float); dk = (im < 110).astype(float)
panels = {'ANT-0592': (215, 830, 120, 528, 161.5, 529.5), 'ANT-1476': (998, 1610, 120, 528, 161.5, 529.5), 'ANT-2118': (1782, 2395, 120, 528, 161.5, 529.5),
          'ANT-3105': (215, 830, 765, 1173, 807.5, 1174.5), 'ANT-3744': (998, 1610, 765, 1173, 807.5, 1174.5), 'ANT-4267': (1782, 2395, 765, 1173, 807.5, 1174.5)}
rr = 7; yy, xx = np.ogrid[-rr:rr + 1, -rr:rr + 1]; disk = ((xx ** 2 + yy ** 2) <= rr * rr).astype(float); disk /= disk.sum()
fl = []
for name, (x0, x1, y0, y1, y100, y0p) in panels.items():
    dd = np.zeros_like(dk); dd[y0:y1, x0:x1] = dk[y0:y1, x0:x1]
    s = ndimage.correlate(dd, disk, mode='constant'); m = ndimage.maximum_filter(s, size=11)
    p = []
    for y, x in np.argwhere((s == m) & (s > 0.97)):
        if all(abs(x - px) > 6 or abs(y - py) > 6 for py, px in p): p.append((y, x))
    p = sorted(p, key=lambda t: t[1])
    act = [round(100 * (y0p - y) / (y0p - y100), 1) for y, x in p]
    fl.append(dict(compound=name, n_points=len(act), activity_pct_lowest_to_highest_conc=act, last3_mean=round(np.mean(act[-3:]), 1)))
fl = pd.DataFrame(fl); fl.to_csv(f'{OUT}/dose_response_floors.csv', index=False)
print('\nDose-response points read from assay_figures p1 (% activity):'); print(fl.to_string(index=False))

# theoretical SPR Rmax (1:1): construct MW from CIF sequence (A104-N445) + His6/Avi/(GS)7 tag
core = ('AVIPILVIACDRSTVRRCLDKLLHYRPSAELFPIIVSQDCGHEETAQAIASYGSAVTHIRQPDLSSIAVPPDHRKFQGYYKIARHYRWALGQVFRQFRFPAAVVVEDDLEVAPDFFEYFRATYPLLKADPSLW'
        'CVSAWNDNGKEQMVDASRPELLYRTDFFPGLGWLLLAELWAELEPKWPKAFWDDWMRRPEQRQGRACIRPEISRTMTFGRKGVSHGQFFDQHLKFIKLNQQFVHFTQLDLSYLQREAYDRDFLARVYGAPQLQVEKVR'
        'TNDRKELGEVRVQYTGRDSFKAFAKALGVMDDLKSGVPRAGYRGIVTFQFRGRRVHLAPPLTWEGYDPSWN')
from Bio.SeqUtils.ProtParam import ProteinAnalysis
mw = ProteinAnalysis('M' + 'HHHHHH' + 'GLNDIFEAQKIEWHE' + 'GS' * 7 + core).molecular_weight() + 226
for lig, lmw, ru, obs in [('ANT-3744 (alone)', 419.5, 9000, 115), ('UDP (alone, 250 uM ~ 89% occupancy)', 404.2, 9000, 9), ('ANT-3744 (+5 mM UDP)', 419.5, 3500, 32)]:
    th = ru * lmw / mw
    exp = th * (0.89 if 'UDP (' in lig else 1)
    print(f'SPR {lig}: theoretical 1:1 Rmax {th:.0f} RU at ~{ru} RU immobilised; observed plateau ~{obs} RU (read from figure) = {obs/exp:.0%} of expected')
print(f'(construct MW used: {mw/1000:.1f} kDa)')
