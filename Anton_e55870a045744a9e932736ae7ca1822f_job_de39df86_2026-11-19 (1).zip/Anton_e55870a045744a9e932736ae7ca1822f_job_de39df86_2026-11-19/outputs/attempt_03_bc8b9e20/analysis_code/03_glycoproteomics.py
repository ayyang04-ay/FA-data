"""
03_glycoproteomics.py -- TMT intact-glycopeptide data (client file glycoproteomics_site_quant.xlsx).
A375 and NCI-H1703, MGAT1-KO vs non-targeting, 4 replicates each (records section 4.1).
Per intact glycopeptide (IGP_quant): log2 FC KO vs NTC on raw reporter intensities, Welch-free t-test,
BH-FDR; compositions grouped into classes. Also: share of reporter intensity in HexNAc>=3 classes,
sequon check on PSMs, and site-level view of selected immune-relevant glycoproteins.
Run: micromamba run -n chem python 03_glycoproteomics.py
"""
import os, re, numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

SRC = '/tmp/world/filesystem/glycoproteomics_site_quant.xlsx'
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out_glyco'); os.makedirs(OUT, exist_ok=True)
x = pd.ExcelFile(SRC)
S, I, P = (pd.read_excel(x, s) for s in ['Site_quant', 'IGP_quant', 'IGP_Pep_quant'])
print(f'Sites {len(S)}, intact glycopeptides {len(I)}, PSM rows {len(P)}, proteins {S["Gene name"].nunique()}')
ch = {'A375': (['AM_KO1', 'AM_KO2', 'AM_KO3', 'AM_KO4'], ['AM_N1', 'AM_N2', 'AM_N3', 'AM_N4']),
      'H1703': (['NH_M_KO1', 'NH_M_KO2', 'NH_M_KO3', 'NH_M_KO4'], ['NH_N1', 'NH_N2', 'NH_N3', 'NH_N4'])}

def parse(comp):
    d = {'HexNAc': 0, 'Hex': 0, 'Fuc': 0, 'NeuAc': 0, 'NeuGc': 0}
    for k, v in re.findall(r'([A-Za-z]+)\((\d+)\)', str(comp)): d[k] = d.get(k, 0) + int(v)
    return d
def klass(comp):
    d = parse(comp)
    if d['HexNAc'] <= 1: return 'truncated (HexNAc<=1)'
    if d['HexNAc'] == 2: return 'high-mannose Man5-9+' if d['Hex'] >= 5 else 'paucimannose (HexNAc2, Hex<5)'
    return 'HexNAc>=3 sialylated' if (d['NeuAc'] + d['NeuGc']) else 'HexNAc>=3 non-sialylated'
I['class'] = I['Observed Modification'].map(klass)
for cl, (ko, nt) in ch.items():
    a = np.log2(I[['Intensity ' + c for c in ko]].clip(lower=1)).values; b = np.log2(I[['Intensity ' + c for c in nt]].clip(lower=1)).values
    I[f'lfc_{cl}'] = a.mean(1) - b.mean(1); I[f'p_{cl}'] = stats.ttest_ind(a, b, axis=1).pvalue
    ok = I[f'p_{cl}'].notna(); I[f'fdr_{cl}'] = np.nan; I.loc[ok, f'fdr_{cl}'] = multipletests(I.loc[ok, f'p_{cl}'], method='fdr_bh')[1]
I.to_csv(f'{OUT}/intact_glycopeptide_fc.csv', index=False)

groups = {'Man5 (HexNAc2Hex5)': I['Observed Modification'] == 'HexNAc(2)Hex(5)',
          'Man6-9': I['Observed Modification'].isin([f'HexNAc(2)Hex({k})' for k in (6, 7, 8, 9)]),
          'HexNAc>=3 sialylated': I['class'] == 'HexNAc>=3 sialylated',
          'HexNAc>=3 non-sialylated': I['class'] == 'HexNAc>=3 non-sialylated'}
rows = []
for name, m in groups.items():
    for cl in ch:
        s = I[m]
        rows.append(dict(glycan_group=name, cell_line=cl, n=int(m.sum()), median_log2FC=round(s[f'lfc_{cl}'].median(), 2),
                         median_fold=round(2 ** s[f'lfc_{cl}'].median(), 2),
                         pct_sig_up=f"{((s[f'fdr_{cl}'] < .05) & (s[f'lfc_{cl}'] > 0)).mean():.0%}",
                         pct_sig_down=f"{((s[f'fdr_{cl}'] < .05) & (s[f'lfc_{cl}'] < 0)).mean():.0%}"))
summ = pd.DataFrame(rows); summ.to_csv(f'{OUT}/class_summary.csv', index=False); print(summ.to_string(index=False))

# share of total glycopeptide reporter intensity carried by HexNAc>=3 (complex/hybrid) glycoforms
ic = [c for c in I.columns if c.startswith('Intensity ')]
share = I[I['class'].str.startswith('HexNAc>=3')][ic].sum() / I[ic].sum() * 100
share.index = [c.replace('Intensity ', '') for c in share.index]
print('\nHexNAc>=3 share of reporter intensity (%):', share.round(1).to_dict())
for cl, (ko, nt) in ch.items():
    print(f'  {cl}: NTC mean {share[nt].mean():.1f}% -> KO mean {share[ko].mean():.1f}% (relative change {share[ko].mean()/share[nt].mean()-1:+.0%})')

# sequon check on PSMs
def sequon(ms):
    s = re.sub(r'^n\[\d+\]', '', ms); seq = ''; gly = []; i = 0
    while i < len(s):
        if s[i].isalpha():
            seq += s[i]; i += 1
            if i < len(s) and s[i] == '[':
                j = s.index(']', i); mass = float(s[i + 1:j])
                if seq[-1] == 'N' and mass > 300: gly.append(len(seq) - 1)
                i = j + 1
        else: i += 1
    out = []
    for k in gly:
        nx = seq[k + 1:k + 3]
        out.append('peptide C-term (unverifiable)' if len(nx) < 2 else ('N-X-S/T/C sequon' if nx[0] != 'P' and nx[1] in 'STC' else 'NON-SEQUON'))
    return ';'.join(out) or 'none'
P['sequon'] = P['Modified Sequence'].map(sequon)
print('\nPSM glycosite sequon check:', P['sequon'].value_counts().to_dict())

# immune-relevant glycoproteins
imm = ['CD276', 'HLA-B', 'HLA-C', 'HLA-E', 'ICAM1', 'IFNGR1', 'MICA', 'MICB', 'PVR', 'NECTIN1', 'CD47', 'FAS', 'TFRC']
sub = I[I['Gene name'].isin(imm)][['Gene name', 'Position', 'Observed Modification', 'class', 'lfc_A375', 'fdr_A375', 'lfc_H1703', 'fdr_H1703']]
sub.sort_values(['Gene name', 'Position']).to_csv(f'{OUT}/immune_relevant_glycoforms.csv', index=False)
print('\nCD276 glycoforms:\n', sub[sub['Gene name'] == 'CD276'].round(3).to_string(index=False))
print('CD274 (PD-L1) detected:', 'CD274' in set(S['Gene name']))
