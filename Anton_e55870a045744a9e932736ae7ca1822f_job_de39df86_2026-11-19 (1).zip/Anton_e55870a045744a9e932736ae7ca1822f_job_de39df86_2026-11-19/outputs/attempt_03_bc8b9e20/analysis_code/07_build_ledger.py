"""
07_build_ledger.py -- assembles MGAT1_evidence_ledger.xlsx (number provenance) from the
hand-verified evidence table below plus the machine outputs of scripts 01-05.
Run: micromamba run -n chem python 07_build_ledger.py
"""
import os, pandas as pd
H = os.path.dirname(os.path.abspath(__file__)); OUTX = os.path.join(H, '..', 'MGAT1_evidence_ledger.xlsx')
C = 'computed from raw data'; D = 'direct from client file'; G = 'digitised from figure (pixel-calibrated)'; V = 'visual read from figure (approx.)'
E = [
# id, topic, statement, value, source, location, derivation type, how, reproduce, caveat
('E1', 'Co-culture screen', 'MGAT1 is a top T-cell sensitiser in the genome-wide NCI-H1703 NY-ESO-1 TCR-T screen',
 'Median guide log2FC -0.89 (guides -1.20, -1.13, -0.65, -0.47); rank 28/18,680 genes; 198 UMI lineages, median lineage log2 ratio -1.50, Mann-Whitney vs 49,215 NegCtrl lineages p=3.7e-15, BH-FDR=4.0e-12; one of 342 depleted genes at FDR<0.05',
 'coculture_screen_umi_counts.csv.gz', 'columns tumor_only_untreated, MSCV_TCR_high_24hr; rows gene_symbol=MGAT1', C,
 'Guide counts = sum over UMIs; log2 CPM ratio TCR-T/tumour-only, centred on NegCtrl median; gene = median of guides with >=50 tumour-only counts. Lineage test: UMIs with >=5 tumour-only counts.',
 '02_coculture_screen.py -> out_coculture/gene_level_guide_summary.csv, gene_level_lineage_tests.csv', 'Single sample per arm (records s3); lineages are pseudo-replicates, not biological replicates'),
('E2', 'Co-culture screen', 'Screen controls behave as expected',
 'Enriched: CTAG1B #1 (+1.75), B2M #2 (+1.35), CTAG1A #4, IFNGR2 #3, IFNGR1 #8, JAK1 #10, STAT1, JAK2, TNFRSF1A. Depleted: CFLAR #1 (-1.88), PTPN2 #8 (-1.27)',
 'coculture_screen_umi_counts.csv.gz', 'gene rows as listed', C, 'as E1', '02_coculture_screen.py', ''),
('E3', 'Co-culture screen', 'Pathway coherence; MGAT2/MGAT5 weak; STK11 and CD274 neutral in vitro',
 'SLC35A1 #4 (-1.44), GFPT1 #5 (-1.42), GALE #10, UGP2 #14, SLC35A2 #16, MGAT1 #28, MOGS #29, CMAS #31, MAN1A2 #174; MGAT2 #941 (-0.29), MGAT4B #1056, MGAT5 #4346 (-0.12); STK11 +0.07 (lineage p=0.77), CD274 -0.14 (p=0.28)',
 'coculture_screen_umi_counts.csv.gz', 'gene rows as listed', C, 'as E1', '02_coculture_screen.py', 'Ranks by median guide log2FC among 18,680 genes'),
('E4', 'Arrayed validation', 'Four independent MGAT1 guides sensitise two NSCLC lines to TCR-T',
 'H1703 relative viability: sgNTC ~0.91 (E:T 0.2)/~0.86 (0.4); sgMGAT1_1-4 ~0.25-0.54; sgB2M ~1.85/~1.97. H1755: sgNTC ~0.79; sgMGAT1 ~0.17-0.48; sgB2M ~1.84. Validation guides (records s1) are absent from the screening library.',
 'phenotype_figures.pdf p3; experimental_records.pdf s1; coculture_screen_umi_counts.csv.gz', 'p3 both panels; guide sequences in records s1', V + ' + sequence match (computed)',
 'Values read from plotted points; guide sequences string-matched against library', 'out_figure_reads/phenotype_figure_reads.csv; 02_coculture_screen.py (records-guide match)', 'n~2 points per bar; NCI-H1755 not listed in records s1'),
('E5', 'Arrayed validation', 'Killing is antigen-specific', 'NY-ESO TCR-T: H1703 ~0.1, H1755 ~0.06 viable vs HEK293 ~1.15, A549 ~1.1; control CD8: ~0.9-1.3',
 'phenotype_figures.pdf p10', '48 h CTG panel', V, 'read from bars', 'out_figure_reads/phenotype_figure_reads.csv', ''),
('E6', 'Glycan PD (genetic)', 'MGAT1 KO removes complex glycans on the cell surface',
 'PHA-L ~0.03-0.04 of sgNTC; GNA ~8.2x (A375), ~8.7x (H1703)', 'phenotype_figures.pdf p2', 'both panels', V, 'read from bars', 'out_figure_reads/phenotype_figure_reads.csv', ''),
('E7', 'Catalytic requirement (in vitro)', 'Catalytic-dead MGAT1 fails to rescue glycans or T-cell resistance',
 'sgMGAT1 + WT cDNA: PHA-L ~5.3e6 MFI, viability with T cells ~1.15; + D289A / D211A+D289A: ~0 MFI, ~0.55 / ~0.53; + vector ~0.72. Mutants expressed at WT-like levels (NCI-H1703 blot). Histogram: double mutant ~1e3 vs WT ~1e4 vs unstained ~1e2.',
 'phenotype_figures.pdf p5, p6 (histograms), p11 (blot)', 'p5 left/right; p6 lower; p11 upper', V, 'read from bars/histograms', 'out_figure_reads/phenotype_figure_reads.csv', 'D211A single mutant (records s1) not shown; two donors, n~2'),
('E8', 'In vivo TCR-T xenograft', 'Effect is T-cell-dose-dependent in vivo',
 'Day 19: control T ~1,940 vs ~1,650 (-15%); 1e6 NY-ESO T ~1,300 vs ~620 (-52%); 2e6 ~600 vs ~180 (-70%)', 'phenotype_figures.pdf p4', 'three panels', V, 'read from curves', 'out_figure_reads/phenotype_figure_reads.csv', 'Tumour cell line, host strain, n, statistics not documented'),
('E9', 'In vivo screen QC', 'Failed library, duplicated library pair, sequencing batch = background',
 'Group7_STK11_82431: 349 reads, 91% zeros. Group3_NTC_82346/82364: log-CPM r=0.984, raw r=0.995 (other tumours: best-match r median 0.67, 95th pct 0.77). All STK11 samples on SG01 runs, all NTC on SG02; plasmids 3+3; plasmid SG01 vs SG02 gene-level SD 0.08 log2, except NegCtrl_62 (2.50 log2; baseline CPM 29 NTC vs 201 STK11)',
 'crispr_invivo_guide_counts.csv.gz; crispr_invivo_ngs_demux.csv.gz', 'sample columns; demux run IDs', C, 'library size, zero fraction, Gini, pairwise correlation', '01_invivo_screen.py -> out_invivo/sample_qc.csv', ''),
('E10', 'In vivo screen design', 'Arm labels inferred from control genes (no key supplied); sample count vs stated cohort sizes',
 'Cd274 group medians: G2 -3.99, G6 -0.85, others -0.63..+0.54 (PD-L1 dependence only in G2/G6). Ptpn2: G1 +0.24, G5 -0.21 vs G2-G4 -1.7..-3.5, G6-G8 -1.3..-2.0. Jak1/Stat1 depleted in G2/G6. -> G1/G5 nude; G2/G6 B6 isotype; G3/G4, G7/G8 B6 anti-PD-1. 141 tumour libraries vs records: 30 C57BL/6 + 15 nude.',
 'crispr_invivo_guide_counts.csv.gz; experimental_records.pdf s2, s2.1', 'control-gene rows; records text', C + ' + inference',
 'group medians of per-tumour gene scores (see E11)', '01_invivo_screen.py -> out_invivo/arm_inference_control_genes_by_group.csv', 'INFERENCE; client should confirm key. Animal-ID blocks also pair G1 with G5.'),
('E11', 'In vivo screen', 'Mgat1 is the #1 STK11-selective dependency in immunocompetent hosts',
 'B6 isotype: STK11 vs NTC delta -2.73 log2, p=3.6e-5, FDR 0.0041, rank 1/795 (n=17 vs 17). B6 anti-PD-1: -3.11, p=7.7e-10, FDR 2e-7, rank 1/795 (35 vs 34). Nude: -1.05, p=0.02, FDR 0.14, rank 28. Guides Mgat1_1/_2/_4 concordant, Mgat1_3 inactive; unchanged across QC scenarios and mean/median guide aggregation.',
 'crispr_invivo_guide_counts.csv.gz', 'Mgat1_1..4 rows; tumour columns', C,
 'per-tumour guide log2FC vs same-background baseline mean (pseudocount 0.5 CPM), centred on NegCtrl median; gene score = median of 4 guides; Mann-Whitney across tumours; BH over 795 genes',
 '01_invivo_screen.py -> out_invivo/mgat1_contrasts.csv, mgat1_guides.csv, robustness.csv', 'Depends only on group pairing across backgrounds'),
('E12', 'In vivo screen', 'Immune dependence of the STK11-selective Mgat1 effect',
 'Within STK11: B6 isotype vs nude -1.30 (p=0.0027, FDR 0.099). Interaction (STK11 x immune host, OLS/HC3): anti-PD-1 arms -2.31, p=6e-5, FDR 0.005, rank 3/795; isotype arms -1.81, p=0.005, FDR 0.16, rank 9/795. NTC: B6 isotype vs nude +0.38 (p=0.61); B6 anti-PD-1 vs nude +1.25 (p=0.024, i.e. less depleted in immunocompetent hosts).',
 'crispr_invivo_guide_counts.csv.gz', 'as E11', C, 'as E11 + interaction model', '01_invivo_screen.py -> out_invivo/interaction_*.csv', 'Depends on inferred nude labels (E10)'),
('E13', 'In vivo screen', 'No added Mgat1 effect with anti-PD-1', 'STK11: anti-PD-1 vs isotype +0.48 (p=0.58); NTC: +0.87 (p=0.09)',
 'crispr_invivo_guide_counts.csv.gz', 'as E11', C, 'as E11', '01_invivo_screen.py -> out_invivo/mgat1_contrasts.csv', 'Depends on inferred arm labels (E10)'),
('E14', 'In vivo screen', 'N-glycan pathway co-hits among STK11-selective dependencies',
 'B6 isotype STK11-vs-NTC ranks: Mgat1 1, B4galt1 3, Alg5 10; anti-PD-1: Mgat1 1, B4galt1 2, Rpn2 6; interaction top-10 (anti-PD-1) includes Alg5, Alg10b, B4galt1',
 'crispr_invivo_guide_counts.csv.gz', 'gene rows', C, 'as E11/E12', '01_invivo_screen.py -> out_invivo/contrast_*.csv', ''),
('E15', 'In vivo screen', 'No in vitro fitness cost of Mgat1 loss', 'In vitro endpoint vs baseline: NTC +0.04, STK11 -0.24 log2 (gene median)',
 'crispr_invivo_guide_counts.csv.gz', 'Endpoint_* and Baseline_* columns', C, 'NegCtrl-centred log2 CPM difference', '01_invivo_screen.py', ''),
('E16', 'MC38 model', 'Stk11 loss abolishes immune control and blunts anti-PD-1 in MC38',
 'sgNTC day 8: nude ~940, B6 ~390, B6+anti-PD-1 ~100 mm3; sgSTK11 day 7: ~970, ~1,270, ~650', 'phenotype_figures.pdf p8', 'both panels', V, 'read from curves', 'out_figure_reads/phenotype_figure_reads.csv', 'Caption says "additional cohorts"; content matches screen cohorts (p1 caption appears swapped)'),
('E17', 'MC38 single-gene', 'MGAT1 KO slows sgSTK11 tumours but not STK11-WT tumours (trend to faster growth)',
 'STK11-WT day 25: sgNTC ~1,170 vs sgMGAT1 ~1,780 (+52%); sgSTK11 day 19: ~1,090 vs ~550 (-50%)', 'phenotype_figures.pdf p1', 'left and middle panels', V, 'read from curves', 'out_figure_reads/phenotype_figure_reads.csv', 'No n/statistics; large SD bars'),
('E18', 'MC38 single-gene', 'MGAT1 KO and anti-PD-1 are additive, not synergistic',
 'Day 9: NTC isotype ~1,140; NTC anti-PD-1 ~760 (anti-PD-1 effect -33%); sgMGAT1 isotype ~620; sgMGAT1 anti-PD-1 ~390. Bliss expectation 760x620/1140 = ~413; observed/expected ~0.94. (Screen cohort p8: anti-PD-1 -49% in sgSTK11, ~1,270 -> ~650.)', 'phenotype_figures.pdf p1', 'right panel', V + ' + arithmetic',
 'Bliss independence on fractional volumes', 'out_figure_reads/phenotype_figure_reads.csv', 'anti-PD-1 arms share isotype points days 0-4; no n/statistics'),
('E19', 'MC38 rescue in vivo', 'Catalytic activity needed for growth of MGAT1-KO sgSTK11 tumours',
 'sgSTK11+sgMGAT1 clone: WT cDNA ~865 vs D211A+D289A ~425 mm3 (day 19, -51%); sgSTK11+sgNTC: ~900 vs ~795 (day 12, overlapping)', 'phenotype_figures.pdf p7; schematic p11', 'both panels', V, 'read from curves', 'out_figure_reads/phenotype_figure_reads.csv', 'KO is a single clone (A-F5); STK11 loss partial in these lines (E20)'),
('E20', 'MC38 rescue lines', 'STK11 protein only partly lost in cDNA rescue lines',
 'STK11/vinculin relative to (-/-) lane: STK11-KO pools 0.07, 0.11; rescue lines 0.20, 0.33, 0.18, 0.39', 'phenotype_figures.pdf p6', 'upper immunoblot', 'densitometry of figure image (approx.)',
 'mean band intensity minus local background, normalised to vinculin', 'out_figure_reads/phenotype_figure_reads.csv', 'JPEG-rendered blot; semi-quantitative. No MGAT1 blot for MC38 lines.'),
('E21', 'Glycoproteomics', 'KO shifts glycoforms in the expected direction, with compressed magnitudes',
 'Man5 glycopeptides (n=532): median 2.28x (A375), 2.03x (H1703); 86%/69% significantly up. Sialylated HexNAc>=3 (n=250): 0.77x/0.71x; 56%/52% down, 12%/7% up. Non-sialylated HexNAc>=3 (n=262): 24%/15% significantly up. HexNAc>=3 share of reporter intensity 9.9%->5.5% (A375), 9.1%->5.1% (H1703). CD276 N91: HexNAc4Hex5Fuc1NeuAc1 log2FC -2.39/-3.27; Man5 +2.36/+1.94. All 3,560 verifiable PSM glycosites in N-X-S/T/C sequons; PD-L1 not detected.',
 'glycoproteomics_site_quant.xlsx', 'IGP_quant and IGP_Pep_quant sheets', C, 'log2 mean reporter intensity KO - NTC, t-test, BH-FDR', '03_glycoproteomics.py -> out_glyco/*', 'TMT ratio compression / misassignment suspected; use qualitatively'),
('E22', 'Compound registry', 'Potency and properties of series compounds',
 'ANT-4267: IC50 0.043 uM; KD 0.07 (SS)/0.03 (kinetic) uM; MW 478; cLogD 2.6; cTPSA 108; sol 96.4 uM; Clint <1.35. ANT-3744: 0.814; 0.38/0.38; 419; 2.2; 110; 178; 3.2. ANT-3105 0.543; ANT-1476 2.02; ANT-2118 25.6. ANT-0592: 197; 32.2*; 335; 2.6; 82; 11.8; 54.4',
 'compound_properties.csv', 'all rows', D, 'read directly', '05_biochem_biophys.py', 'Clint species not stated; logD/TPSA calculated (records s8)'),
('E23', 'SAR', 'Biochemical potency tracks SPR binding across the series',
 'n=26 compounds; Spearman rho 0.94 (p=2e-12); median IC50/KD 1.8 (range 0.24-8.4); KD<IC50 for 85%', 'assay_figures.pdf p5', 'scatter', G,
 'dot centres by template matching; axes calibrated from tick marks', '05_biochem_biophys.py -> out_biochem/ic50_vs_kd_digitised.csv', '~+/-0.03 log units; only 8 compounds are in the registry'),
('E24', 'SPR', 'ANT-3744 and UDP bind simultaneously with mutual positive cooperativity',
 'UDP KD 31 (spr_binding) / 32 uM; with 20 uM ANT-3744: 20 uM (1.6x). ANT-3744 KD 0.4 uM; with 5 mM UDP 0.2 uM (2.0x)', 'spr_binding.csv; spr_competition.csv; assay_figures.pdf p3', 'all rows', D, 'ratios', '05_biochem_biophys.py', '10 uM point excluded from +UDP fit (marked x)'),
('E25', 'DSF', 'Thermal shifts are additive', 'UDP +2 C; ANT-3744 +6 C; both +8 C (implied reference Tm 49 C)', 'dsf_thermal_shift.csv; assay_figures.pdf p4', 'all rows', D, 'read directly', '05_biochem_biophys.py', 'Absolute Tm in CSV ~2.5-3 C below figure derivative peaks'),
('E26', 'Crystallography', 'Structures are of good quality',
 'apo 1.65 A (Rw/Rf 0.170/0.207); UDP 1.55 (0.152/0.177); UDP-GlcNAc 2.00 (0.170/0.220); C3744 2.00 (0.172/0.208); C3744+UDP 2.01 (0.165/0.203)', 'MGAT1_*.cif', '_refine / _reflns records', D, 'read from mmCIF', '04_structures.py', ''),
('E27', 'Crystallography', 'ANT-3744 binds a C-terminal pocket ~20 A from the active site',
 'Pocket residues (<=4 A, all 4 copies): Y388 T389 G390 F394 G410 P412 P434 W437 E438 G439 Y440 D441 (P442) W444. Closest atom to UDP-GlcNAc 19.7-19.8 A; centroids 30.6-30.7 A (after CA superposition, rmsd 0.54-0.65 A). UDP/UD1 contact E209-D211 (DXD/Mn); D289 3.5 A from GlcNAc.',
 'MGAT1_C3744.cif; MGAT1_C3744_UDP.cif; MGAT1_UDP_GlcNAc.cif', 'ligand C3744, UDP, UD1', C, 'NeighborSearch contacts; CA superposition', '04_structures.py -> out_structures/c3744_site.csv', ''),
('E28', 'Crystallography', 'Lattice contacts, induced fit, loop ordering, ligand B-factors',
 'Symmetry-mate contacts in every copy: E278/E274 3.03-3.18 A or E133 3.79-3.85 A. E438 CA shift 4.35-5.09 A vs UDP-GlcNAc complex. Loop 315-332 missing in apo (316-332/315-331) and C3744-only (315-331/316-331); partly in UDP (320-324/321-328); complete in UDP-GlcNAc and ternary. Ternary chain B C3744 mean B 60.3 vs UDP 32.3 A^2.',
 'MGAT1_*.cif', 'coordinates, occupancy, B-factors', C, 'nearest-image symmetry search; gap detection', '04_structures.py -> out_structures/*.csv', ''),
('E29', 'UDP-Glo', 'Inhibition plateaus at ~6-10% residual activity',
 'Last three points (% activity): ANT-1476 10.2/8.3/8.6; ANT-3105 8.9/9.1/8.6; ANT-3744 9.4/8.9/5.9; ANT-4267 9.7/9.1/10.2 (top 100 uM = ~2,300x IC50)', 'assay_figures.pdf p1', 'six dose-response panels', G,
 'dot centres by template matching; y calibrated from 0/50/100% ticks', '05_biochem_biophys.py -> out_biochem/dose_response_floors.csv', 'Cannot distinguish true partial inhibition from assay floor'),
('E30', 'Acquired compounds', 'ANT-1938 and ANT-2214 are artefacts', 'ANT-1938: IC50 >100 uM (40% at 100 uM), no SPR response. ANT-2214: IC50 74 uM (60% at 100 uM), flat, non-saturable SPR steady state with slow non-dissociating binding at top doses; catechol + hydrazone motifs',
 'assay_figures.pdf p2; compound_properties.csv', 'rows 1-2 of p2', V + ' + ' + D, 'inspection of sensorgrams/steady-state plots', '-', ''),
('E31', 'HTS hit', 'ANT-0592 values measured above its solubility', 'IC50 197 uM = 16.7x kinetic solubility (11.8 uM); KD 32.2 uM = 2.7x solubility, flagged "*" (undefined); records give 100 uM as top assay concentration',
 'compound_properties.csv; experimental_records.pdf s6.3; assay_figures.pdf p1', 'ANT-0592 row; p1 panel 1', D + ' + arithmetic', 'ratios', '05_biochem_biophys.py', ''),
('E32', 'SPR stoichiometry', 'Observed SPR plateaus vs theoretical 1:1 Rmax', 'ANT-3744 alone: ~115 RU vs 86 RU theoretical (~133%); UDP: ~9 RU vs ~74 RU expected at 89% occupancy (~12%); ANT-3744 + UDP: ~32 vs 34 RU (~95%)',
 'assay_figures.pdf p2-p3; experimental_records.pdf s6.1, s6.4; MGAT1_*.cif sequence', 'steady-state plots; immobilisation levels', V + ' + computed', 'Rmax = RU_immobilised x MW_ligand / MW_construct (43.8 kDa His-Avi-GS-MGAT1 104-445)', '05_biochem_biophys.py', 'Immobilisation levels are approximate'),
('E33', 'Constructs', 'Different constructs across assays', 'Enzyme assay and DSF: T30-N445 (Hi-5; lacks the N-terminal transmembrane helix). SPR: Avi-tagged A104-N445 (Sf9). Crystallography: A104-N445, His tag retained, additionally lacks an N-terminal helix. No full-length or membrane-anchored enzyme tested.',
 'experimental_records.pdf s6.1, s6.5, s7', 'text', D, 'read', '-', ''),
('E34', 'Package scope', 'No compound has been tested in cells or animals', 'No cellular, PD, selectivity, permeability, PK or in vivo data for any compound; all cell and in vivo data use genetic perturbation',
 'all 16 files; experimental_records.pdf', 'entire package', 'review of all files', 'exhaustive review of records sections 1-8 and all figures/tables', '-', 'Ask the client whether such data exist'),
]
cols = ['ID', 'Topic', 'Statement (as used in memo)', 'Value(s)', 'Source file(s)', 'Location in source', 'Derivation type', 'How derived', 'Reproduce with', 'Caveat']
ledger = pd.DataFrame(E, columns=cols)

issues = pd.DataFrame([
    (1, 'No compound cellular / in vivo data in the package', 'Whole package', 'Confirm whether such data exist'),
    (2, 'In vivo screen: no group->arm key; 141 tumour libraries vs 30 B6 + 15 nude stated; duplicated pair; failed library', 'crispr_invivo_*.csv.gz; records s2', 'Request key and sample manifest'),
    (3, 'Background confounded with sequencing batch (STK11=SG01, NTC=SG02)', 'crispr_invivo_ngs_demux.csv.gz', 'Mitigated by within-batch baselines; plasmid concordance SD 0.08 log2'),
    (4, 'No n / statistics for any in vivo figure; adoptive-transfer model undocumented; anti-PD-1 arms share isotype points to day 4', 'phenotype_figures p1, p4, p7, p8', 'Request animal-level data'),
    (5, 'Captions of phenotype_figures p1 and p8 appear swapped', 'phenotype_figures p1, p8', 'Confirm'),
    (6, 'Referenced but not provided: D211A single-mutant rescue; mutant enzyme activities; PD-L1/CD276 blots; MGAT1 blot in MC38 rescue lines; ~18 series compounds shown in p5 but absent from registry', 'records s1, s6.2, s8; assay_figures p5', 'Request'),
    (7, 'UDP-Glo: stated top 100 uM vs ~1,000 uM plotted for 5/6 compounds; ANT-0592 potency above solubility', 'records s6.3; assay_figures p1', 'Clarify'),
    (8, 'SPR: stated 60 s association vs ~100 s in competition sensorgrams; excluded 10 uM point; Rmax anomalies', 'records s6.4; assay_figures p3', 'Clarify; request surface activity data'),
    (9, 'DSF: "18.6 nM (9.3 uM final)" unit error; CSV absolute Tm offset vs figure; ANT-3744 labelled "HTS" vs synthesised', 'records s6.5; dsf_thermal_shift.csv; assay_figures p4', 'Clarify'),
    (10, 'Construct differences between enzyme assay (T30-N445) and SPR/crystallography (A104-N445)', 'records s6.1', 'Bridge in Gate 3'),
    (11, 'Clint species unspecified; logD/TPSA calculated; STK11 status of human lines undocumented', 'compound_properties.csv; records s8', 'Request'),
    (12, '"ITC" control guide equals POLB-targeting library guide POLB_2', 'records s1; coculture library', 'Clarify use'),
    (13, 'File metadata 18 Nov 2026 vs stated 1 Nov data cut; records "compiled 18 August 2026"', 'PDF/XLSX metadata', 'Confirm version'),
    (14, 'Glycoproteomics: some nucleo-cytoplasmic proteins reported N-glycosylated (e.g., SP9, PHOX2B, HNRNPA1L3); compressed KO effects', 'glycoproteomics_site_quant.xlsx', 'Use qualitatively; orthogonal glycan profiling'),
], columns=['#', 'Issue', 'Where', 'Action'])

reads = pd.read_csv(os.path.join(H, 'out_figure_reads', 'phenotype_figure_reads.csv'))
with pd.ExcelWriter(OUTX, engine='xlsxwriter') as xw:
    ledger.to_excel(xw, sheet_name='Evidence ledger', index=False)
    reads.to_excel(xw, sheet_name='Figure reads (approx)', index=False)
    pd.read_csv(os.path.join(H, 'out_invivo', 'mgat1_contrasts.csv')).to_excel(xw, sheet_name='InVivo Mgat1 contrasts', index=False)
    pd.read_csv(os.path.join(H, 'out_invivo', 'mgat1_guides.csv')).to_excel(xw, sheet_name='InVivo Mgat1 guides', index=False)
    pd.read_csv(os.path.join(H, 'out_invivo', 'robustness.csv')).to_excel(xw, sheet_name='InVivo robustness', index=False)
    pd.read_csv(os.path.join(H, 'out_invivo', 'arm_inference_control_genes_by_group.csv')).to_excel(xw, sheet_name='InVivo arm inference', index=False)
    pd.read_csv(os.path.join(H, 'out_invivo', 'sample_qc.csv')).to_excel(xw, sheet_name='InVivo sample QC', index=False)
    gg = pd.read_csv(os.path.join(H, 'out_coculture', 'gene_level_guide_summary.csv'))
    lt = pd.read_csv(os.path.join(H, 'out_coculture', 'gene_level_lineage_tests.csv'))
    gg.merge(lt, on='gene', how='left').sort_values('rank_depleted').to_excel(xw, sheet_name='Coculture gene table', index=False)
    pd.read_csv(os.path.join(H, 'out_glyco', 'class_summary.csv')).to_excel(xw, sheet_name='Glyco class summary', index=False)
    pd.read_csv(os.path.join(H, 'out_glyco', 'immune_relevant_glycoforms.csv')).to_excel(xw, sheet_name='Glyco immune proteins', index=False)
    pd.read_csv(os.path.join(H, 'out_structures', 'chains_ligands_disorder.csv')).to_excel(xw, sheet_name='Structures chains', index=False)
    pd.read_csv(os.path.join(H, 'out_structures', 'c3744_site.csv')).to_excel(xw, sheet_name='Structures C3744 site', index=False)
    pd.read_csv(os.path.join(H, 'out_biochem', 'ic50_vs_kd_digitised.csv')).to_excel(xw, sheet_name='IC50 vs KD digitised', index=False)
    pd.read_csv(os.path.join(H, 'out_biochem', 'dose_response_floors.csv')).to_excel(xw, sheet_name='Dose-response floors', index=False)
    issues.to_excel(xw, sheet_name='Data issues', index=False)
    for name, df in [('Evidence ledger', ledger), ('Data issues', issues)]:
        ws = xw.sheets[name]; wrap = xw.book.add_format({'text_wrap': True, 'valign': 'top'})
        for i, col in enumerate(df.columns):
            ws.set_column(i, i, min(60, max(12, int(df[col].astype(str).str.len().quantile(0.9) * 0.6))), wrap)
print('ledger written:', os.path.abspath(OUTX))
