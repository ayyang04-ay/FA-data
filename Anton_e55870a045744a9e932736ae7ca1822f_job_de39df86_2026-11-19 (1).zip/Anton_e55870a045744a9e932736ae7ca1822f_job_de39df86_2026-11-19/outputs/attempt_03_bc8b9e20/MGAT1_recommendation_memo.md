# MGAT1 small-molecule programme (Antera Therapeutics): independent review and recommendation

**Basis:** I used only the client's data package (16 files, stated as current on 1 Nov 2026). I re-analysed every raw dataset and read values off every figure. No outside data or literature was used as evidence.

**Traceability:** each bracketed ID [E#] points to a row in `MGAT1_evidence_ledger.xlsx`. That row gives the file, page or column, the derivation, and the script that reproduces the number (`analysis_code/`).

**Convention:** "≈" marks values I read off a figure (about ±5% of the axis). Values computed from raw files are given exactly.

---

## 1. Recommendation

**Do not advance the asset (the ANT-4267 / ANT-3744 series) into lead optimisation, in vivo pharmacology or development on the current data. Hold it, and fund one short, gated proof-of-pharmacology package. Keep MGAT1 as a target.**

| Question | Answer from the data | Confidence |
|---|---|---|
| Is MGAT1 a real, tumour-intrinsic immune-sensitisation target? | Yes, genetically. Two independent screens, 4-guide validation in two human NSCLC lines, catalytic-dead rescue in vitro and in vivo, and a T-cell-dose-dependent xenograft effect. | High (in the models tested) |
| Is the chemical series real? | Yes. It is a specific MGAT1 binder with SAR, co-crystal structures and a 43 nM lead. | High |
| Do the molecules do in cells what the knockout does? | **Unknown. The package contains no compound data from any cell or animal.** | n/a: the key gap |
| Does the data support the indication claim "checkpoint-inhibitor-resistant, STK11-mutant NSCLC"? | Only partly. STK11 selectivity comes only from a mouse colorectal line. MGAT1 loss *adds to* PD-1 blockade rather than reversing resistance to it. In STK11-wild-type tumours MGAT1 loss trended to *faster* growth. | Medium–low |

In one sentence: the target has earned the next experiment, but the asset has not yet earned advancement. That experiment is quick, the client already runs the assays and has the genetic benchmarks, and it decides the question either way.

**Why not stop:** the genetic case is unusually complete and internally consistent, the chemistry is real and structure-enabled, and the experiment that would change the call is cheap relative to what it decides.

---

## 2. The case for the target (what the data support)

**Human NSCLC, in vitro and in vivo**

- **Unbiased screen hit.** In the genome-wide NCI-H1703 TCR-T co-culture screen, MGAT1 is depleted under T-cell attack. Median guide log2FC is −0.89, rank 28 of 18,680 genes, with all 4 guides depleted (−0.47 to −1.20). A lineage-level test gives p = 3.7×10⁻¹⁵ and FDR = 4×10⁻¹² [E1].
- **The screen behaved correctly.** The antigen itself (CTAG1B, #1 enriched), B2M (#2) and the IFN-γ pathway (IFNGR1/2, JAK1/2, STAT1) score as resistance hits. PTPN2 scores as a sensitiser (#8) [E2].
- **The hit is a pathway, not a one-off.** Other glycosylation genes, mostly sugar-nucleotide supply and sialylation, co-score: SLC35A1 #4, GFPT1 #5, GALE #10, UGP2 #14, SLC35A2 #16, MOGS #29, CMAS #31. MGAT5 (#4,346) and MGAT2 (#941) are weak or neutral [E3]. STK11 and CD274 knockouts are neutral in vitro [E3].
- **Validation with independent guides.** The four arrayed validation guides are not in the screening library. With TCR-T cells, relative viability is 0.25–0.54 for sgMGAT1 versus 0.86–0.91 for sgNTC in H1703. In H1755 it is 0.17–0.48 versus 0.79. sgB2M goes the other way (1.84–1.97) [E4]. Killing is antigen-specific: antigen-negative HEK293 and A549 are spared [E5].
- **Catalytic activity is what matters.** In KO cells, wild-type MGAT1 cDNA restores PHA-L (≈5.3×10⁶ MFI) and T-cell resistance (≈1.15). D289A and D211A+D289A restore neither (≈0 MFI; ≈0.53–0.55), even though they are expressed at WT-like levels [E7]. So a catalytic inhibitor is, in principle, the right modality.
- **The effect holds in vivo and needs T cells.** In the TCR-T xenograft (model details not documented) at day 19, MGAT1 KO tumours were −52% with 1×10⁶ T cells (≈1,300→≈620 mm³) and −70% with 2×10⁶ (≈600→≈180). With control T cells the difference was only −15% [E8].

**STK11 context (mouse MC38 only)**

- **The model recapitulates STK11-linked immune escape.** In the STK11-WT background, immunocompetent hosts control tumours (day 8: nude ≈940, B6 ≈390, B6+anti-PD-1 ≈100 mm³). With Stk11 loss, tumours grow at least as fast in B6 as in nude mice, and anti-PD-1 is blunted (day 7: ≈970, ≈1,270, ≈650) [E16].
- **Mgat1 is the top STK11-selective dependency in immunocompetent hosts.** I re-analysed the screen's 141 tumour libraries (138 after QC). Mgat1 ranks #1 of 795 genes for STK11-over-NTC depletion in B6-isotype tumours (Δ −2.73 log2, FDR 0.004) and in B6-anti-PD-1 tumours (Δ −3.11, FDR 2×10⁻⁷) [E11].
    - The result holds in 3 of 4 guides. The validation guide sgMGAT1_4 is the library guide Mgat1_4.
    - It is unchanged by every QC-exclusion scenario I tested [E11].
    - It is smaller and not significant in nude hosts (Δ −1.05, FDR 0.14), so it is largely immune-dependent. The STK11 × immune interaction ranks #3 of 795 with anti-PD-1 (FDR 0.005) and #9 with isotype (FDR 0.16) [E12].
    - There is no in vitro fitness cost (endpoint vs baseline +0.04 NTC, −0.24 STK11) [E15].
    - Other N-glycan genes co-score as STK11-selective in B6 hosts: B4galt1 (#2–3), Alg5 (#10, isotype) and Rpn2 (#6, anti-PD-1) [E14].
- **Single-gene and rescue confirmation.** In MC38 sgSTK11, sgMGAT1 tumours were ≈550 vs ≈1,090 mm³ at day 19 [E17]. In the MGAT1-KO clone, catalytic-dead cDNA tumours were ≈425 vs ≈865 mm³ with WT cDNA [E19].

**Pharmacodynamic readouts already exist.** MGAT1 KO drops PHA-L to ≈0.03–0.04 of control and raises GNA ≈8.2–8.7× [E6]. Man5 glycopeptides rise a median 2.0–2.3× [E21]. These are ready-made PD markers for a compound.

**The chemistry is genuine**

- **Binding drives inhibition across the series.** Across 26 series compounds, IC50 tracks SPR KD (Spearman ρ = 0.94; median IC50/KD = 1.8) [E23].
- **Lead compounds.** ANT-4267: IC50 0.043 µM, KD 0.07 µM (steady state) / 0.03 µM (kinetic), solubility 96.4 µM, hepatocyte Clint <1.35. ANT-3744: 0.814 µM, 0.38/0.38 µM, 178 µM, 3.2 [E22].
- **Structural data.** ANT-3744 has 2.0 Å binary and ternary co-crystal structures with a consistent pose in all four copies. It shifts Tm by +6 °C [E25–E27].
- **Artefacts correctly rejected.** The two acquired "actives" were correctly identified as artefacts [E30].

---

## 3. Why not advance now

**A. No compound pharmacology exists outside a test tube [E34].** Every cellular and in vivo result is genetic: CRISPR knockout or cDNA. There is no experiment in which ANT-3744 or ANT-4267 is shown to:

- reach MGAT1 in cells (the native enzyme is membrane-anchored, and every construct tested had its transmembrane region removed [E33]; there is no permeability or cell-exposure data);
- change glycosylation;
- sensitise tumour cells to T cells;
- do any of the above in an animal.

The PD readouts to test this (PHA-L/GNA, Man5) are already in-house, so this absence is the single biggest issue. Ask the client directly whether such data exist and were left out.

**B. The mechanism is atypical and only shown with truncated enzyme and a surrogate substrate.**

- ANT-3744 binds a C-terminal pocket (Y388, T389, G390, F394, G410, P412, P434, W437–D441, W444). Its closest atom is 19.7 Å from UDP-GlcNAc (centroids 30.6 Å apart). It is not in the donor/metal site [E27].
- It binds together with UDP and cooperatively: each ligand raises the other's affinity 1.6–2×, and the DSF shifts add (2 + 6 = 8 °C) [E24, E25]. In the ternary complex the 315–332 loop is fully ordered, while it is disordered in apo and compound-only crystals [E28]. That fits an allosteric, product-complex-stabilising mechanism, but no mechanism-of-inhibition study was done.
- In every ligand copy the compound also touches a neighbouring molecule in the crystal (3.0–3.9 Å). Binding induces a ≈4.4–5.1 Å shift at E438 [E28]. Part of the pose is therefore lattice-supported.
- Inhibition was only measured on a truncated soluble enzyme (T30–N445) using a free pentasaccharide acceptor. Binding and structures used a shorter construct (A104–N445) [E33]. In cells the substrates are glycoproteins, as the client's own site-specific glycoproteomics shows [E21], so the translation is untested.

**C. The compounds may not inhibit completely enough.** Four analogues spanning 50-fold in potency all plateau at ≈6–10% residual activity. ANT-4267 still leaves ≈10% at ~2,300× its IC50 [E29]. This is either a genuine ~90% ceiling (plausible for an allosteric inhibitor) or an assay floor; the package cannot tell which. It matters because the benchmark that produces the phenotype is a near-complete loss (≈96% loss of PHA-L) [E6]. There is no hypomorph or titration data showing how much MGAT1 inhibition is enough.

**D. Developability is largely unmeasured.**

- No selectivity data against other UDP-GlcNAc glycosyltransferases.
- No permeability, PPB, CYP or hERG data.
- No PK.
- The species for the hepatocyte Clint is not stated, and logD/TPSA are calculated values [E22].

**E. The indication claim goes beyond the evidence.**

- **STK11 context:** every STK11-specific result comes from MC38, a mouse colorectal line, with engineered Stk11 loss. There is no NSCLC model with STK11 loss. The STK11 status of H1703/H1755 is not documented, and STK11 KO is neutral in the human screen [E3]. In the MC38 rescue lines, STK11 protein is only partly lost (≈20–40% of control vs ≈7–11% in the parental KO pools) [E20].
- **"Checkpoint-inhibitor resistant":** MGAT1 loss does not restore PD-1 response; it adds to it.
    - In the screen, Mgat1 depletion is no greater with anti-PD-1 than with isotype (Δ +0.48, p = 0.58) [E13].
    - In the single-gene study, the combination (≈390 mm³) matches the Bliss-independent expectation (≈413 mm³; ratio ≈0.94) [E18].
    - The MC38 sgSTK11 model is itself only partly PD-1-resistant: anti-PD-1 still cuts tumour volume by ≈33–49% [E16, E18]. It is not a model of refractory disease.
    - The defensible claim is *PD-1-independent T-cell sensitisation of STK11-null tumours*, not reversal of ICI resistance.
- **STK11-WT risk signal:** in STK11-WT MC38, MGAT1-KO tumours trended larger (≈1,780 vs ≈1,170 mm³ at day 25) [E17]. This is consistent with the screen, where the NTC background shows no immune-dependent Mgat1 depletion (B6 vs nude Δ +0.38 isotype, +1.25 anti-PD-1) [E12]. STK11 patient selection is therefore a requirement, not an option, and every efficacy study needs STK11-WT arms.
- **Host exposure is untested:** all data delete MGAT1 in tumour cells only. A systemic drug will also reach host cells, including the T cells it is meant to help, and no experiment tests MGAT1 loss or inhibition in T cells.

---

## 4. Next steps: what must be established, and the comparisons each study needs

The gates run in order. Don't spend on a later gate until the earlier one passes. The numeric thresholds are my proposed decision criteria, tied to the client's own knockout benchmarks. Gate 2's hypomorph work should replace the provisional Gate 1 threshold.

| Gate | Must establish | Comparisons that must be in the design | Go / no-go (proposed) |
|---|---|---|---|
| **1. Cellular target engagement and glycan PD** (decisive; first) | ANT-4267 and ANT-3744 lower complex N-glycans in intact NSCLC cells, with a dose response and time course that approach the knockout. | Vehicle; **MGAT1-KO (ceiling)**; catalytic-dead rescue line (zero-activity reference); a **matched inactive analogue** from the series; **compound on KO cells** (any effect = off-target); a **pocket-mutant MGAT1** (C-terminal site residues from the structure, made catalytically active but unable to bind) re-expressed in KO cells, where the compound's effect must disappear; cytotoxicity alongside. Report cellular EC50 next to biochemical IC50 and SPR KD. | **Go:** PHA-L/Man5 effect ≥80% of KO at a non-toxic concentration; EC50 ≤10× biochemical IC50; inactive analogue and pocket mutant behave as predicted. **Stop:** <50% of KO effect at any non-toxic concentration, or the effect persists in the pocket mutant. |
| **2. Functional phenocopy and how much inhibition is enough** | Compound-treated tumour cells become as T-cell-sensitive as KO cells. Define the MGAT1 activity threshold needed. | sgNTC / sgMGAT1 / sgB2M benchmarks as in phenotype_figures p3. Antigen-negative lines ± compound. Compound on KO cells (should add nothing). **Tumour pre-treatment + washout vs continuous exposure**. **T cells exposed to compound alone** (activation, cytotoxicity). **Graded genetic hypomorphs** to map residual activity → sensitisation and test whether a ~90% ceiling is enough. ≥2 NSCLC lines with documented STK11 status, ideally **isogenic STK11 WT/null pairs** (test the interaction). | **Go:** ≥50% of KO sensitisation in ≥2 lines; no loss of T-cell killing at ≥3× the PD-effective concentration. **Stop:** PD without function, or T-cell impairment at effective exposure. |
| **3. Mechanism and developability** (in parallel with 2) | The inhibition mechanism holds with physiological acceptors. Selectivity and basic drug properties. | MOI with varied UDP-GlcNAc and acceptor, and a **glycopeptide/glycoprotein acceptor** alongside the pentasaccharide. T30 vs A104 vs full-length enzyme. Solution confirmation of the C-terminal site (structure-guided mutants). UDP-Glo detection counter-screen. Panel of other UDP-GlcNAc glycosyltransferases. Permeability, PPB, species-defined clearance, CYP/hERG. | **Go:** ≥100-fold selectivity; consistent MOI with glycoprotein acceptor; properties compatible with sustained exposure. |
| **4. In vivo PK/PD, then efficacy** | Exposure that holds tumour glycan PD at the Gate-1 level through the dosing interval at a tolerated dose. Then efficacy. | PK/PD against the **KO tumour as PD ceiling**, plus host PD in T cells/blood. Efficacy in **STK11-null, anti-PD-1-refractory models including at least one lung model**. Factorial design: vehicle / compound / anti-PD-1 / combination. A **genetic MGAT1-KO arm** as benchmark. **Matched STK11-WT arms** to test selectivity and watch for the growth-acceleration signal. **Nude or CD8-depleted arm** to show immune dependence. Pre-specified n and power, randomisation, blinded calipers, individual-animal curves. Test the **interaction** (synergy vs additivity); don't just compare means. Tolerability (weight, blood counts, immune phenotype). | **Go to candidate work:** significant TGI vs vehicle in STK11-null, approaching the KO benchmark (≈50% in MC38 sgSTK11); no acceleration in STK11-WT; tolerated. |

Two secondary tasks run alongside the gates. First, use the glycoproteomic shifts already seen on immune-relevant proteins to identify the glycoproteins that mediate sensitisation. Examples: CD276 N91, where the main complex sialylated form falls ≈5–10× and Man5 rises ≈4–5×; MICA/B; PVR; NECTIN1; IFNGR1 [E21]. Second, build the PD and patient-selection biomarker plan around STK11 status plus a glycan readout.

## 5. What would bring it back (criteria to advance)

The asset moves to lead optimisation when Gates 1 and 2 are met, with minimum Gate 3 selectivity and MOI. Concretely, a compound must:

1. reproduce ≥80% of the knockout's glycan change in NSCLC cells at non-toxic concentrations, with on-target proof (pocket mutant, inactive analogue, no effect in KO cells);
2. reproduce ≥50% of the knockout's T-cell sensitisation without impairing T-cell killing;
3. act through a mechanism that holds with glycoprotein acceptors, with ≥100-fold selectivity over related glycosyltransferases.

Candidate nomination further requires Gate 4: tumour PD at tolerated exposure and STK11-selective efficacy in at least one lung model, with STK11-WT controls. The positioning should be reframed as PD-1-independent sensitisation unless a factorial study shows true synergy.

**If Gate 1 fails,** the target is still genetically supported, but this series is not the route. The client's own screens point to alternatives worth weighing as a new programme: an active-site chemotype, or another node in the same pathway (B4galt1, SLC35A1 and GFPT1 co-score in their screens) [E3, E14].

---

## 6. What I set aside or discounted, and why

| Item | Treatment | Reason |
|---|---|---|
| ANT-1938 and ANT-2214 (acquired) | Discarded as actives | ANT-1938 shows no SPR binding. ANT-2214 gives a concentration-independent, non-saturable SPR steady state with slow, non-dissociating binding at the top doses (aggregation-like), and its UDP-Glo "IC50 74 µM" is extrapolated from 60% inhibition at the top dose [E30]. |
| ANT-0592 (HTS hit) IC50 197 µM and KD 32.2 µM | Not used quantitatively | Both exceed its kinetic solubility (11.8 µM; IC50 ≈17× solubility). The IC50 is also above the stated 100 µM top concentration. The KD carries an undefined asterisk [E31]. The series' validity rests on later, soluble compounds. |
| In vivo screen sample Group7_STK11_82431 | Excluded | Failed library: 349 reads, 91% zero counts [E9]. |
| Group3_NTC_82346 / Group3_NTC_82364 | Excluded | Near-identical libraries (log-CPM r = 0.984, raw-count r = 0.995; every other tumour's best match is median 0.67, 95th percentile 0.77), so most likely the same tumour sequenced twice or a sample mix-up [E9]. Conclusions are unchanged with or without them [E11]. |
| Nude / isotype / anti-PD-1 labels for screen groups | Used, but flagged as *inferred* | No key was supplied. I assigned arms from control-gene behaviour [E10]. G1/G5 show no T-cell signature, so nude. G2/G6 show PD-L1 dependence, so isotype. G3/G4 and G7/G8 show PTPN2 dependence without PD-L1 dependence, so anti-PD-1. The STK11-vs-NTC conclusions only assume that groups pair across backgrounds. |
| Glycoproteomic effect sizes | Used for direction only | The HexNAc≥3 share of reporter signal falls only from ≈9–10% to ≈5% (a ≈44% relative drop), and 15–24% of non-sialylated HexNAc≥3 glycopeptides even *rise* significantly. This conflicts with the ≈96% PHA-L loss and fits TMT ratio compression or misassignment [E21]. |
| Single-gene in vivo growth curves (phenotype_figures p1, p4, p7) | Direction and approximate size only | No n, no statistics, overlapping SD bars. In p1 the anti-PD-1 arms share the isotype arms' day 0–4 points [E17, E18]. |
| MC38 "STK11-null" rescue lines (phenotype_figures p7) | Counted as evidence of the catalytic requirement, not of STK11 specificity | STK11 protein is only partly lost in these lines [E20]. |
| NY-ESO-1 CCLE plot (phenotype_figures p9) | Context only | External reference data; it only justifies model choice. |
| DSF absolute Tm values | ΔTm used; absolute Tm not used | The CSV Tm values sit about 2.5–3 °C below the figure's derivative peaks, but the ΔTm values agree. |
| SPR +UDP fit | Accepted | The 10 µM point is excluded (marked ×) without comment. The conclusion (KD 0.4→0.2 µM) is supported independently by DSF and the ternary structure. |

---

## 7. Data and documentation issues to raise with the client (priority order)

1. **Compound cell and in vivo data:** confirm whether any exist. If they do, the recommendation must be revisited.
2. **In vivo screen key and counts:** there is no group-to-arm key. The matrix holds 141 tumour libraries (71 NTC, 70 STK11), but the records describe 30 C57BL/6 + 15 nude mice. There is also the duplicated library pair and the failed library [E9, E10].
3. **Sequencing batch confound:** every STK11 sample was sequenced in SG01 runs and every NTC sample in SG02. This is mitigated because scores are relative to same-batch baselines, and plasmid profiles agree across batches (gene-level SD 0.08 log2). One control guide (NegCtrl_62) is the exception [E9].
4. **Missing in vivo design detail:** no n or statistics in any in vivo figure. The adoptive-transfer model (cell line, host) is not described. Captions of phenotype_figures p1 and p8 appear swapped.
5. **Data referenced but not provided:** the D211A single-mutant rescue; mutant enzyme activities (records §6.2); PD-L1 and CD276 immunoblots (records §8); an MGAT1 blot for the MC38 rescue lines. Also, the IC50–KD plot shows ~26 compounds while the registry lists only 8.
6. **Assay records vs figures:**
    - UDP-Glo top concentration is stated as 100 µM, but 5 of 6 curves extend to ≈1,000 µM.
    - SPR association is stated as 60 s, but competition sensorgrams show ≈100 s.
    - SPR stoichiometry is off: ANT-3744 reaches ≈133% of the theoretical 1:1 Rmax, while UDP reaches only ≈12% of expected [E32].
    - DSF protein concentration is given as "18.6 nM (9.3 µM final)".
    - ANT-3744 is labelled "HTS" in the DSF legend but "synthesised" in the registry.
7. **Constructs and units:** enzyme assay uses T30–N445, SPR and crystallography use A104–N445 [E33]. Clint species is not given; logD/TPSA are calculated. STK11 status of the human lines is undocumented.
8. **Minor:** the "ITC" control guide in the records matches a POLB-targeting library guide (POLB_2). File timestamps (18 Nov 2026) post-date the stated 1 Nov data cut, and the records say "compiled 18 August 2026", so confirm you have the final version.

---

## 8. How the numbers were generated

- **Raw data re-analysed:**
    - In vivo screen: per-tumour guide scores relative to the same-background baseline, centred on 400 non-targeting guides. Mann–Whitney across tumours with BH-FDR over 795 genes, an interaction model, and robustness checks.
    - Co-culture screen: guide- and gene-level log-ratios, plus UMI-lineage tests against 49,215 non-targeting lineages as a substitute for replicates.
    - Glycoproteomics: per-glycopeptide KO/NTC fold changes with BH-FDR, grouped by glycan class.
    - Structures: contacts, symmetry-mate contacts, distances after superposition, and disorder.
- **Figures digitised:** the IC50–KD plot (26 points) and dose-response floors were extracted by pixel calibration against axis ticks. Other figure values were read visually and are marked ≈.
- **Reproduction:** everything runs with `analysis_code/00–08_*.py` (run order in `analysis_code/README.md`); outputs are in `analysis_code/out_*`. Summary figures are in `figures/` (fig1 in vivo screen, fig2 co-culture screen, fig3 binding/cooperativity, fig4 binding site, fig5 glycoproteomics).

---

## Appendix: source key for each [E#]

Full values, derivations, scripts and caveats are in `MGAT1_evidence_ledger.xlsx` (sheet *Evidence ledger*).

| ID | Topic | Source file(s) and location | Derivation |
|---|---|---|---|
| E1 | Co-culture screen | coculture_screen_umi_counts.csv.gz (columns tumor_only_untreated, MSCV_TCR_high_24hr; rows gene_symbol=MGAT1) | computed from raw data |
| E2 | Co-culture screen | coculture_screen_umi_counts.csv.gz (gene rows as listed) | computed from raw data |
| E3 | Co-culture screen | coculture_screen_umi_counts.csv.gz (gene rows as listed) | computed from raw data |
| E4 | Arrayed validation | phenotype_figures.pdf p3; experimental_records.pdf s1; coculture_screen_umi_counts.csv.gz (p3 both panels; guide sequences in records s1) | visual read from figure (approx.) + sequence match (computed) |
| E5 | Arrayed validation | phenotype_figures.pdf p10 (48 h CTG panel) | visual read from figure (approx.) |
| E6 | Glycan PD (genetic) | phenotype_figures.pdf p2 (both panels) | visual read from figure (approx.) |
| E7 | Catalytic requirement (in vitro) | phenotype_figures.pdf p5, p6 (histograms), p11 (blot) (p5 left/right; p6 lower; p11 upper) | visual read from figure (approx.) |
| E8 | In vivo TCR-T xenograft | phenotype_figures.pdf p4 (three panels) | visual read from figure (approx.) |
| E9 | In vivo screen QC | crispr_invivo_guide_counts.csv.gz; crispr_invivo_ngs_demux.csv.gz (sample columns; demux run IDs) | computed from raw data |
| E10 | In vivo screen design | crispr_invivo_guide_counts.csv.gz; experimental_records.pdf s2, s2.1 (control-gene rows; records text) | computed from raw data + inference |
| E11 | In vivo screen | crispr_invivo_guide_counts.csv.gz (Mgat1_1..4 rows; tumour columns) | computed from raw data |
| E12 | In vivo screen | crispr_invivo_guide_counts.csv.gz (as E11) | computed from raw data |
| E13 | In vivo screen | crispr_invivo_guide_counts.csv.gz (as E11) | computed from raw data |
| E14 | In vivo screen | crispr_invivo_guide_counts.csv.gz (gene rows) | computed from raw data |
| E15 | In vivo screen | crispr_invivo_guide_counts.csv.gz (Endpoint_* and Baseline_* columns) | computed from raw data |
| E16 | MC38 model | phenotype_figures.pdf p8 (both panels) | visual read from figure (approx.) |
| E17 | MC38 single-gene | phenotype_figures.pdf p1 (left and middle panels) | visual read from figure (approx.) |
| E18 | MC38 single-gene | phenotype_figures.pdf p1 (right panel) | visual read from figure (approx.) + arithmetic |
| E19 | MC38 rescue in vivo | phenotype_figures.pdf p7; schematic p11 (both panels) | visual read from figure (approx.) |
| E20 | MC38 rescue lines | phenotype_figures.pdf p6 (upper immunoblot) | densitometry of figure image (approx.) |
| E21 | Glycoproteomics | glycoproteomics_site_quant.xlsx (IGP_quant and IGP_Pep_quant sheets) | computed from raw data |
| E22 | Compound registry | compound_properties.csv (all rows) | direct from client file |
| E23 | SAR | assay_figures.pdf p5 (scatter) | digitised from figure (pixel-calibrated) |
| E24 | SPR | spr_binding.csv; spr_competition.csv; assay_figures.pdf p3 (all rows) | direct from client file |
| E25 | DSF | dsf_thermal_shift.csv; assay_figures.pdf p4 (all rows) | direct from client file |
| E26 | Crystallography | MGAT1_*.cif (_refine / _reflns records) | direct from client file |
| E27 | Crystallography | MGAT1_C3744.cif; MGAT1_C3744_UDP.cif; MGAT1_UDP_GlcNAc.cif (ligand C3744, UDP, UD1) | computed from raw data |
| E28 | Crystallography | MGAT1_*.cif (coordinates, occupancy, B-factors) | computed from raw data |
| E29 | UDP-Glo | assay_figures.pdf p1 (six dose-response panels) | digitised from figure (pixel-calibrated) |
| E30 | Acquired compounds | assay_figures.pdf p2; compound_properties.csv (rows 1-2 of p2) | visual read from figure (approx.) + direct from client file |
| E31 | HTS hit | compound_properties.csv; experimental_records.pdf s6.3; assay_figures.pdf p1 (ANT-0592 row; p1 panel 1) | direct from client file + arithmetic |
| E32 | SPR stoichiometry | assay_figures.pdf p2-p3; experimental_records.pdf s6.1, s6.4; MGAT1_*.cif sequence (steady-state plots; immobilisation levels) | visual read from figure (approx.) + computed |
| E33 | Constructs | experimental_records.pdf s6.1, s6.5, s7 (text) | direct from client file |
| E34 | Package scope | all 16 files; experimental_records.pdf (entire package) | review of all files |
