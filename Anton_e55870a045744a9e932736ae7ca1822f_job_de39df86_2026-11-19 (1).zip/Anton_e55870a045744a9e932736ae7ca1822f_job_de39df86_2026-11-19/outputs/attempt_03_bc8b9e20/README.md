# MGAT1 programme review: deliverables

| File | What it is |
|---|---|
| `MGAT1_recommendation_memo.md` / `.pdf` / `.html` | The recommendation memo (same content in three formats; the HTML and PDF include the figures). |
| `MGAT1_evidence_ledger.xlsx` | Number provenance. Sheet **Evidence ledger** has one row per [E#] cited in the memo: value, source file and location, derivation type, how derived, script that reproduces it, and caveats. Other sheets hold the full supporting tables (in vivo screen contrasts/QC/arm inference, co-culture gene table, glycoproteomics summaries, structure analyses, digitised figure data, figure reads, and data issues to raise with the client). |
| `figures/` | fig1 in vivo screen (Mgat1 + arm-identity controls); fig2 co-culture screen; fig3 binding/cooperativity; fig4 ANT-3744 binding site; fig5 glycoproteomics. |
| `analysis_code/` | Scripts 01–08 that regenerate every computed number, table and figure from the client files (see `analysis_code/README.md`). Intermediate outputs are in `analysis_code/out_*`. |

**Derivation types used in the ledger**

- **Direct from client file:** the value is copied as reported.
- **Computed from raw data:** my re-analysis of the count, intensity or coordinate files.
- **Digitised from figure:** pixel-calibrated extraction from the embedded figure images (about ±0.03 log units).
- **Visual read from figure:** approximate, marked "≈" in the memo.
