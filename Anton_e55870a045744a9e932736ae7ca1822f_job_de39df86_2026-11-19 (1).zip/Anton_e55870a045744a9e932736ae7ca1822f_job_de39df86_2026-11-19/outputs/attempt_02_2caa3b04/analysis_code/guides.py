import pandas as pd, numpy as np
cc = pd.read_pickle('/tmp/work/cc.pkl')
lib_h = cc[['gene_symbol','sgrna_id','sgrna_sequence','genetype']].drop_duplicates().astype(str)
inv = pd.read_csv('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz', usecols=['sgrna','gene_sgrna_id','gene_symbol'])
guides = {'NC77':'ACCCATCGGGTGCGATATGG','sgSTK11_mouse':'CTCAAATGGGTACAGGCCCG','sgMGAT1_4_mouse':'CAGCCAACAGCAGCCATCCA',
'ITC':'ATTTGTAACATCTCTTCACG','B2M_sgRNA3':'GGCCGAGATGTCTCGCTCCG','MGAT1_1':'GTTCCGAGAGCTGGCTACCG','MGAT1_2':'ACTGGAAGGTGACAATACCC',
'MGAT1_3':'GCCCGACCTGAGCAGCATTG','MGAT1_4':'GGCCAGGGAAAAAGTCGGTG','NTC-1':'AGTATGAGACTCATAGGGTG','NTC-2':'GAAGGCCTTAACACGTCGAC',
'PD-L1_sg1':'GGTTCCCAAGGACCTATATG','PD-L1_sg2':'ACTGCTTGTCCAGATGACTT','sgPTPN2':'CCATGACTATCCTCATAGAG'}
def rc(s):
    return s[::-1].translate(str.maketrans('ACGT','TGCA'))
for k,s in guides.items():
    print(k, len(s), s)
    h = lib_h[lib_h.sgrna_sequence==s]
    hr = lib_h[lib_h.sgrna_sequence==rc(s)]
    m = inv[inv.sgrna==s]
    print('   human lib:', h.values.tolist(), 'rc:', hr.values.tolist())
    print('   mouse lib:', m.values.tolist())
print(lib_h[lib_h.gene_symbol.isin(['MGAT1','B2M','CD274','PTPN2','STK11','MGAT2','MGAT5','MAN1A1','MAN2A1'])].sort_values('sgrna_id'))
