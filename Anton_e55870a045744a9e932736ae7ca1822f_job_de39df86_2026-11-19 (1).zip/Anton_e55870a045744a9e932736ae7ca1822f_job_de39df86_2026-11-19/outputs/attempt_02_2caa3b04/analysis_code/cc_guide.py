import pandas as pd, numpy as np
cc = pd.read_pickle('/tmp/work/cc.pkl')
A='tumor_only_untreated'; B='MSCV_TCR_high_24hr'
tot = cc[[A,B]].sum()
print('totals', tot.to_dict())
# guide level
g = cc.groupby(['gene_symbol','sgrna_id','genetype'], observed=True)[[A,B]].sum().reset_index()
g['nUMI'] = cc.groupby(['gene_symbol','sgrna_id','genetype'], observed=True).size().values
cpmA = g[A]/tot[A]*1e6; cpmB = g[B]/tot[B]*1e6
g['lfc'] = np.log2((cpmB+0.5)/(cpmA+0.5))
ntmask = g.genetype.isin(['NegCtrl'])
med = g.loc[ntmask,'lfc'].median(); g['lfc_c'] = g.lfc - med
print('NT guide lfc median', round(med,3), 'sd', round(g.loc[ntmask,'lfc'].std(),3), 'n NT guides', ntmask.sum())
print(g.groupby('genetype').lfc_c.describe().round(3))
print('guides with 0 reads in control arm:', (g[A]==0).sum())
print(g[A].describe())
g.to_pickle('/tmp/work/cc_guide.pkl')
pd.set_option('display.width',200)
for gene in ['MGAT1','MGAT2','MAN1A1','MAN1A2','MAN1B1','MAN2A1','MAN2A2','MGAT4A','MGAT4B','MGAT5','B4GALT1','SLC35A2','SLC35A1','FUT8','ST6GAL1','B2M','HLA-A','TAP1','TAP2','TAPBP','JAK1','JAK2','STAT1','IFNGR1','IFNGR2','IRF1','PTPN2','ADAR','CD274','CASP8','FADD','TNFRSF1A','BID','STK11','NLRC5','CFLAR','TRAF2','RNF31','RBCK1','SHARPIN','TBK1','ICAM1']:
    sub = g[g.gene_symbol==gene]
    if len(sub): print(gene.ljust(9), ' '.join(f"{v:6.2f}" for v in sub.lfc_c.values), '| mean %.2f' % sub.lfc_c.mean(), '| nUMI', list(sub.nUMI.values))
    else: print(gene, 'absent')
