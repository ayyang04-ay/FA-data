import sys; sys.path.insert(0,'/tmp/work/py')
from digit_lib import *
im = load('/tmp/work/img/phenotype_figures_p4.png')
g = im.mean(axis=2); dark = g<80
H,W,_=im.shape; print(W,H)
# find y-axis columns and tick rows in each of 3 panels
for (y0,y1) in [(90,380),(520,810),(950,1240)]:
    sub = dark[y0:y1,:]
    cols = sub.sum(axis=0); yaxis = np.argmax(cols[:300])
    rows = sub.sum(axis=1); xaxis = np.argmax(rows)+y0
    seg = dark[y0:y1+20, yaxis-12:yaxis-2]
    r = np.where(seg.sum(axis=1)>=6)[0]+y0
    groups=[]
    for x in r:
        if groups and x-groups[-1][-1]<=2: groups[-1].append(x)
        else: groups.append([x])
    print('panel',y0,'yaxis col',yaxis,'xaxis row',xaxis,'yticks',[round(np.mean(g_),1) for g_ in groups])
    # x ticks
    for rr in range(xaxis+2, xaxis+14, 2):
        c = np.where(dark[rr, yaxis-5:480])[0]+yaxis-5
        groups=[]
        for cc in c:
            if groups and cc-groups[-1][-1]<=2: groups[-1].append(cc)
            else: groups.append([cc])
        if len(groups)>3: print('   xticks row',rr,[round(np.mean(x)) for x in groups]); break
