import json, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
d = json.load(open('/tmp/work/dr_digitized.json'))
rep = {'ANT-0592':197,'ANT-1476':2.02,'ANT-2118':25.6,'ANT-3105':0.543,'ANT-3744':0.814,'ANT-4267':0.043}
def f(x,bot,ic50,h): return bot+(100-bot)/(1+(x/ic50)**h)
fig, axes = plt.subplots(1,3, figsize=(16,4.8))
ax = axes[0]
cols = {'ANT-0592':'#7f7f7f','ANT-1476':'#9467bd','ANT-2118':'#8c564b','ANT-3105':'#17becf','ANT-3744':'#d62728','ANT-4267':'#1f77b4'}
rows=[]
for k,v in d.items():
    x=np.array([a for a,b in v]); y=np.array([b for a,b in v])
    p,cov=curve_fit(f,x,y,p0=[10,rep[k],1],bounds=([-20,1e-4,0.2],[80,1e5,5]))
    xx=np.logspace(np.log10(x.min()/2), np.log10(x.max()*2), 200)
    ax.plot(xx,f(xx,*p),color=cols[k],lw=1.3); ax.scatter(x,y,color=cols[k],s=14,label=f"{k}: floor {p[0]:.0f}%, IC50 {p[1]:.3g} uM (reg. {rep[k]})")
    rows.append((k,rep[k],p[1],p[2],p[0],np.sqrt(cov[0,0]),x.max()))
ax.set_xscale('log'); ax.set_xlabel('concentration (uM) [digitized from assay_figures p1]'); ax.set_ylabel('MGAT1 activity (%)')
ax.axhspan(8,10,color='orange',alpha=0.15); ax.text(0.0025,1.5,'shaded: ~9% residual-activity plateau (lead series, >=25x IC50)',fontsize=8,color='#b35900')
ax.legend(fontsize=6.3, loc='upper right', bbox_to_anchor=(1.0,0.99)); ax.set_title('UDP-Glo dose-response re-fit (top fixed 100%)', fontsize=10)
# IC50 vs Kd
import subprocess
ic = [0.0425,0.0485,0.0601,0.0669,0.205,0.252,0.43,0.439,0.502,2.01,2.92,4.25,20.6,25.5,124,220]
kd = [0.0736,0.0343,0.0831,0.283,0.127,0.175,0.11,0.189,0.283,2.98,1.35,1.08,15.2,7.36,14.7,32.6]
ax=axes[1]
ax.scatter(ic,kd,color='k',s=18,label='digitized (16 resolvable points)')
ax.scatter([0.814,0.043,197],[0.38,0.07,32.2],color=['#d62728','#1f77b4','#7f7f7f'],s=60,marker='D',label='registry values: ANT-3744, ANT-4267, ANT-0592')
lim=[0.01,1000]; ax.plot(lim,lim,'k--',lw=0.8)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(lim); ax.set_ylim([0.01,1000])
ax.set_xlabel('UDP-Glo IC50 (uM)'); ax.set_ylabel('SPR KD (uM)')
ax.set_title('Binding tracks inhibition across the series\n(log-log r = 0.96; median IC50/KD = 1.7)', fontsize=10)
ax.legend(fontsize=7)
# competition
ax=axes[2]
labels=['ANT-3744 KD\nalone','ANT-3744 KD\n+5 mM UDP','UDP KD\nalone','UDP KD\n+20 uM ANT-3744']
obs=[0.4,0.2,32,20]; exp=[0.4,0.4*(1+5000/32),32,32*(1+20/0.4)]
xpos=np.arange(4)
ax.bar(xpos-0.18,obs,width=0.36,color='#2c3e50',label='observed (spr_competition.csv)')
ax.bar(xpos+0.18,exp,width=0.36,color='#e74c3c',alpha=0.6,label='expected if competitive')
ax.set_yscale('log'); ax.set_xticks(xpos); ax.set_xticklabels(labels,fontsize=8); ax.set_ylabel('KD (uM)')
ax.set_title('ANT-3744 is NOT competitive with UDP\n(DSF dTm: UDP +2, ANT-3744 +6, both +8 C)', fontsize=10)
ax.legend(fontsize=7)
plt.tight_layout()
plt.savefig('/tmp/outputs/figures/Fig3_biochemistry_biophysics.png', dpi=160)
import pandas as pd
pd.DataFrame(rows, columns=['compound','registry_IC50_uM','refit_IC50_uM','refit_Hill','refit_floor_pct','floor_SE','top_conc_tested_uM']).round(4).to_csv('/tmp/outputs/derived_data/dose_response_refit_from_figure.csv', index=False)
json.dump(d, open('/tmp/outputs/derived_data/dose_response_digitized_points.json','w'), indent=1)
print('ok')
