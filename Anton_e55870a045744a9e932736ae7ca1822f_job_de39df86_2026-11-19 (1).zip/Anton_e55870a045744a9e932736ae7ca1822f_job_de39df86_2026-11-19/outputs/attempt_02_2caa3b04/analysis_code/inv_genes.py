import pandas as pd, numpy as np
df = pd.read_csv('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz', usecols=['gene_symbol'])
genes = set(df.gene_symbol)
cands = ['B2m','Jak1','Jak2','Ifngr1','Ifngr2','Stat1','Ptpn2','Adar','Cd274','Tap1','Tap2','Tapbp','H2-K1','H2-D1','Socs1','Irf1','Casp8','Tnfrsf1a','Traf2','Traf3','Ripk1','Ikbkb','Chuk','Map3k7','Tbk1','Ptpn1','Adam10','Mgat1','Mgat2','Mgat4a','Mgat4b','Man1a1','Man1a2','Man2a1','Fut8','St6gal1','B4galt1','Slc35a2','Stt3a','Stt3b','Alg1','Dpagt1','Gfpt1','Gale','Cd47','Pdcd1lg2','Cd276','Vtcn1','Lgals1','Lgals3','Lgals9','Tgfb1','Ptgs2','Ptges','Ido1','Cd73','Nt5e','Entpd1','Adora2a','Vegfa','Csf1','Cxcl9','Cxcl10','Pbrm1','Arid2','Brd7','Setdb1','Kdm5b','Ezh2','Eed','Suv39h1','Dnmt1','Hdac1','Lsd1','Kdm1a','Ppp2r2a','Mapk14','Mtor','Pik3cd','Pik3cg','Atg5','Atg7','Atg12','Ulk1','Prkaa1','Prkaa2','Mark2','Sik1','Sik2','Sik3','Crtc2','Keap1','Nfe2l2','Kras','Myc','Ctnnb1','Pten','Trp53','Cdk4','Cdk6','Ccnd1','Plk1','Rpa1','Polr2a','Psmb2','Psma1','Rps19','Rpl3','Cdk1','Pcna','Mcm2']
present = [g for g in cands if g in genes]
print('present:', present)
print('absent:', [g for g in cands if g not in genes])
