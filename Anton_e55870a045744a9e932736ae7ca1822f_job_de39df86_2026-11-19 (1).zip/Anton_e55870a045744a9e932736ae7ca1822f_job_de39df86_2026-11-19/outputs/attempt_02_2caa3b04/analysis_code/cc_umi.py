import pandas as pd, numpy as np
from scipy import stats
cc = pd.read_pickle('/tmp/work/cc.pkl')
A='tumor_only_untreated'; B='MSCV_TCR_high_24hr'
tot = cc[[A,B]].sum()
sf = tot[B]/tot[A]
# UMI-level: keep lineages with >=10 reads in control arm
u = cc[cc[A]>=10].copy()
u['lfc'] = np.log2((u[B]/sf + 0.5)/(u[A]+0.5))
ntm = u.genetype=='NegCtrl'
med = u.loc[ntm,'lfc'].median(); u['lfc'] -= med
print('UMI lineages >=10 reads ctrl:', len(u), ' NT lineages:', ntm.sum(), 'NT sd %.2f' % u.loc[ntm,'lfc'].std())
def gene_umi(gene):
    x = u[u.gene_symbol==gene]
    r = stats.mannwhitneyu(x.lfc, u.loc[ntm,'lfc'], alternative='two-sided')
    per_guide = x.groupby('sgrna_id', observed=True).lfc.agg(['median','size'])
    per_guide_p = {sg: stats.mannwhitneyu(xx.lfc, u.loc[ntm,'lfc']).pvalue for sg, xx in x.groupby('sgrna_id', observed=True)}
    return x.lfc.median(), len(x), r.pvalue, per_guide, per_guide_p
for gene in ['MGAT1','SLC35A1','CMAS','GALE','SLC35A2','GFPT1','UAP1','MGAT2','MGAT5','MAN2A1','B4GALT1','PTPN2','CFLAR','B2M','CTAG1B','JAK1']:
    m,n,p,pg,pgp = gene_umi(gene)
    print(f"{gene:8s} median UMI lfc={m:6.2f}  nUMI={n:4d}  MWU p={p:.1e}  per-guide medians: " + ', '.join(f"{k}:{v['median']:.2f}(n={int(v['size'])},p={pgp[k]:.0e})" for k,v in pg.iterrows()))
# fraction of UMI lineages depleted below NT 10th percentile
q10 = u.loc[ntm,'lfc'].quantile(0.10)
for gene in ['MGAT1','SLC35A1','PTPN2']:
    x = u[u.gene_symbol==gene]
    print(gene, 'frac lineages below NT 10th pct: %.2f (NT expectation 0.10)' % (x.lfc<q10).mean())
