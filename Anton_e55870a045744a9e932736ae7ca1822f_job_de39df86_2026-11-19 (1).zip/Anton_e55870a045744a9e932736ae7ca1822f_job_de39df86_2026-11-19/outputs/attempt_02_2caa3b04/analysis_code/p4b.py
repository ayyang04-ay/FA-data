import sys; sys.path.insert(0,'/tmp/work/py')
from digit_lib import *
im = load('/tmp/work/img/phenotype_figures_p4.png')
# sample colors
for (x,y) in [(472,165),(472,300)]:
    patch = im[y-10:y+10, x-10:x+10].reshape(-1,3)
    cols, counts = np.unique(patch//20*20, axis=0, return_counts=True)
    idx = np.argsort(-counts)[:5]; print((x,y), [(tuple(int(c) for c in cols[i]), int(counts[i])) for i in idx])
panels = [('Control T cells',(158,90,500,363),[(107.5,2500),(159,2000),(210,1500),(261.5,1000),(312.5,500),(363.5,0)],[(158,0),(238,5),(316,10),(394,15),(472,20)]),
          ('NYESO 1e6',(156,520,500,795),[(539.5,2500),(590.5,2000),(641.5,1500),(693.5,1000),(744.5,500),(795.5,0)],[(156,0),(236,5),(314,10),(394,15),(472,20)]),
          ('NYESO 2e6',(156,950,500,1227),[(971.5,2500),(1022.5,2000),(1073.5,1500),(1125,1000),(1176.5,500),(1227.5,0)],[(156,0),(236,5),(314,10),(394,15),(472,20)])]
for name,box,yt,xt in panels:
    ys=cal(yt); xs=cal(xt)
    for lab,rgb,tol in [('sgNTC(blue)',(50,60,150),60),('sgMGAT1(red)',(220,20,30),70)]:
        pts = markers(im, box, rgb, tol, rad=2, minarea=20, merge=8)
        print(name, lab, ', '.join(f'd{np.polyval(xs,px):.1f}:{np.polyval(ys,py):.0f}' for px,py,a in pts))
