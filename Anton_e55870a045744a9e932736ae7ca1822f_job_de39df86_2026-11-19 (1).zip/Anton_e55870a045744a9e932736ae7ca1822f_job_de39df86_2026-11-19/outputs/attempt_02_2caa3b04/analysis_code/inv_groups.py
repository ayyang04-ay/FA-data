import sys; sys.path.insert(0,'/tmp/work/py')
from inv_core import *
df, S, X, cpm, grp, bg, L, Lc, nt = load()
genes = df.gene_symbol.values
G = Lc.groupby(genes).mean()
G = G[~G.index.str.startswith('BRDN')]
tum = [c for c in S if c.startswith('Group')]
grps = sorted(set(grp[tum]))
GM = pd.DataFrame({g: G[[c for c in tum if grp[c]==g]].mean(axis=1) for g in grps})
EP = pd.DataFrame({g: G[[c for c in S if grp[c]==g]].mean(axis=1) for g in ['Endpoint_NTC','Endpoint_STK11']})
pd.set_option('display.width',250)
print('Correlation of group-mean gene scores (NT-centred):')
print(pd.concat([GM,EP],axis=1).corr(method='spearman').round(2).to_string())
# differences between groups within each background, top genes
def top(a,b,n=12):
    d = (GM[a]-GM[b]).sort_values()
    return pd.concat([d.head(n), d.tail(n)])
for a,b in [('Group2_NTC','Group1_NTC'),('Group2_NTC','Group3_NTC'),('Group3_NTC','Group4_NTC'),('Group6_STK11','Group5_STK11'),('Group7_STK11','Group8_STK11'),('Group6_STK11','Group7_STK11')]:
    print(a,'-',b); print(top(a,b).round(2).to_string())
