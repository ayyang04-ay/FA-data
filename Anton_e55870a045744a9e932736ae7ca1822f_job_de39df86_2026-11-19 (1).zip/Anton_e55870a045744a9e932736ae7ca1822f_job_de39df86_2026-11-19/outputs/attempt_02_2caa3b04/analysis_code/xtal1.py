import gemmi, glob, os
for f in sorted(glob.glob('/tmp/world/filesystem/MGAT1_*.cif')):
    doc = gemmi.cif.read(f); b = doc.sole_block()
    def g(tag):
        v = b.find_value(tag); return v
    print('===', os.path.basename(f))
    for tag in ['_refine.ls_d_res_high','_refine.ls_d_res_low','_refine.ls_R_factor_R_work','_refine.ls_R_factor_R_free','_refine.ls_R_factor_obs',
                '_refine.pdbx_ls_sigma_F','_refine.ls_number_reflns_obs','_refine.ls_percent_reflns_obs','_refine.B_iso_mean',
                '_reflns.d_resolution_high','_reflns.pdbx_Rmerge_I_obs','_reflns.pdbx_netI_over_sigmaI','_reflns.percent_possible_obs','_reflns.pdbx_redundancy','_reflns.pdbx_CC_half',
                '_cell.length_a','_cell.length_b','_cell.length_c','_cell.angle_alpha','_cell.angle_beta','_cell.angle_gamma','_symmetry.space_group_name_H-M',
                '_exptl_crystal_grow.pdbx_details','_exptl_crystal_grow.pH','_diffrn_source.pdbx_synchrotron_site','_diffrn_radiation_wavelength.wavelength',
                '_pdbx_entry_details.entry_id','_struct_ref.pdbx_db_accession','_struct_ref_seq.pdbx_auth_seq_align_beg','_struct_ref_seq.pdbx_auth_seq_align_end']:
        v = g(tag)
        if v is not None: print('  ', tag, '=', v)
