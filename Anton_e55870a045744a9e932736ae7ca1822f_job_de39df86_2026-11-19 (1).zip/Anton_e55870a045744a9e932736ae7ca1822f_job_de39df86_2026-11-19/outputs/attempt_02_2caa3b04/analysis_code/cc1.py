import pandas as pd, numpy as np, time
t=time.time()
cc = pd.read_csv('/tmp/world/filesystem/coculture_screen_umi_counts.csv.gz',
                 dtype={'gene_symbol':'category','sgrna_id':'category','sgrna_sequence':'category','genetype':'category','umi_barcode':'str','tumor_only_untreated':'int32','MSCV_TCR_high_24hr':'int32'})
print('load', time.time()-t, cc.shape)
cc.to_parquet('/tmp/work/cc.parquet') if False else None
print(cc.genetype.value_counts())
print('genes', cc.gene_symbol.nunique(), 'sgrnas', cc.sgrna_id.nunique(), 'seqs', cc.sgrna_sequence.nunique())
print(cc[['tumor_only_untreated','MSCV_TCR_high_24hr']].describe())
print('totals', cc.tumor_only_untreated.sum(), cc.MSCV_TCR_high_24hr.sum())
per_guide = cc.groupby('sgrna_id', observed=True).size()
print('UMIs per guide', per_guide.describe())
print('umi len', cc.umi_barcode.str.len().value_counts().head())
cc.to_pickle('/tmp/work/cc.pkl')
