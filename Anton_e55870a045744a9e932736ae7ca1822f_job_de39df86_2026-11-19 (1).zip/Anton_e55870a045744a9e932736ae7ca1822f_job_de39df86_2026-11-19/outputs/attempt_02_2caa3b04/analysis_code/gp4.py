import pandas as pd, numpy as np
igp = pd.read_pickle('/tmp/work/gp_igp.pkl')
ch = ['AM_N1','AM_N2','AM_N3','AM_N4','AM_KO1','AM_KO2','AM_KO3','AM_KO4','NH_N1','NH_N2','NH_N3','NH_N4','NH_M_KO1','NH_M_KO2','NH_M_KO3','NH_M_KO4']
I = igp[['Intensity '+c for c in ch]].copy(); I.columns = ch
L = np.log2(I+1)
# channel correlation (centered per glycopeptide)
Lc = L.sub(L.mean(axis=1), axis=0)
pd.set_option('display.width',250)
print('Pearson corr of per-glycopeptide centred log intensities across channels:')
print(Lc.corr().round(2).to_string())
for cl,nt,ko in [('A375',ch[0:4],ch[4:8]),('H1703',ch[8:12],ch[12:16])]:
    lr = np.log2((I[ko].mean(axis=1)+1)/(I[nt].mean(axis=1)+1))
    for c in ['Complex-type (HexNAc>=3)','Oligomannose (Man5-9)','HexNAc<=2 + Fuc/NeuAc (MGAT1-dependent)']:
        v = lr[igp['class']==c]
        h,edges = np.histogram(v, bins=[-10,-4,-3,-2,-1,-0.5,0.5,1,2,3,10])
        print(cl, c[:28].ljust(28), 'n=%d'%len(v), dict(zip([f'{edges[i]:.1f}..{edges[i+1]:.1f}' for i in range(len(h))], h)))
# zero counts
print('\nzeros per channel:', (I==0).sum().to_dict())
print('\nTotal intensity per channel:', (I.sum()/1e9).round(2).to_dict())
