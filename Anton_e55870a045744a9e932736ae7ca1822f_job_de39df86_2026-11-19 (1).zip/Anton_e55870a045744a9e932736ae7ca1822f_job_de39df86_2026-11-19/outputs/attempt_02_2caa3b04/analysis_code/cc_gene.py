import pandas as pd, numpy as np
from scipy import stats
g = pd.read_pickle('/tmp/work/cc_guide.pkl')
g = g[g[ 'tumor_only_untreated']>=50].copy()  # min representation filter
tg = g[g.genetype.isin(['other','ESG'])]
gene = tg.groupby('gene_symbol', observed=True).agg(mean_lfc=('lfc_c','mean'), median_lfc=('lfc_c','median'), n=('lfc_c','size'),
        n_neg=('lfc_c', lambda x: (x< -0.3).sum()), min_lfc=('lfc_c','min'), max_lfc=('lfc_c','max'))
gene = gene[gene.n>=3]
# null: NT guides resampled in groups of n
nt = g[g.genetype=='NegCtrl'].lfc_c.values
rng = np.random.default_rng(0)
null4 = np.array([rng.choice(nt,4,replace=False).mean() for _ in range(100000)])
gene['p_emp_dep'] = [ (np.sum(null4 <= m)+1)/(len(null4)+1) for m in gene.mean_lfc]
gene['z'] = (gene.mean_lfc - null4.mean())/null4.std()
gene['rank_dep'] = gene.mean_lfc.rank()
gene['rank_enr'] = (-gene.mean_lfc).rank()
N = len(gene)
print('genes scored', N)
print('MGAT1:', gene.loc['MGAT1'].round(3).to_dict(), ' rank_dep', int(gene.loc['MGAT1','rank_dep']), '/', N)
print('\nTop 30 depleted (sensitizers):')
print(gene.sort_values('mean_lfc').head(30)[['mean_lfc','median_lfc','n','n_neg','min_lfc','max_lfc','z']].round(2).to_string())
print('\nTop 20 enriched (resistance):')
print(gene.sort_values('mean_lfc', ascending=False).head(20)[['mean_lfc','median_lfc','n','z']].round(2).to_string())
# genes with all guides < -0.3
cons = gene[(gene.n_neg==gene.n)].sort_values('mean_lfc')
print('\n# genes with all guides < -0.3:', len(cons), '; MGAT1 rank among these', list(cons.index).index('MGAT1')+1 if 'MGAT1' in cons.index else None)
gene.to_csv('/tmp/work/cc_gene_scores.csv')
