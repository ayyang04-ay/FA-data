import sys; sys.path.insert(0,'/tmp/work/py')
from inv_core import *
from scipy import stats
df, S, X, cpm, grp, bg, L, Lc, nt = load()
genes = df.gene_symbol.values
tum = [c for c in S if c.startswith('Group')]
# per-tumour gene score = mean of NT-centred guide LFCs
G = Lc.groupby(genes).mean()
is_nt = G.index.str.startswith('BRDN')
# pseudo-genes from NT guides: 100 random sets of 4 NT guides
rng = np.random.default_rng(1)
ntidx = np.where(nt)[0]
pseudo = {}
for i in range(2000):
    pick = rng.choice(ntidx, 4, replace=False)
    pseudo['NTpseudo_%d'%i] = Lc.iloc[pick].mean()
P = pd.DataFrame(pseudo).T
Gt = G[~is_nt]
def contrast(A, B, name):
    a = [c for c in tum if grp[c] in A]; b = [c for c in tum if grp[c] in B]
    d = Gt[a].mean(axis=1) - Gt[b].mean(axis=1)
    t, p = stats.ttest_ind(Gt[a], Gt[b], axis=1, equal_var=False)
    dn = P[a].mean(axis=1) - P[b].mean(axis=1)
    tn, _ = stats.ttest_ind(P[a], P[b], axis=1, equal_var=False)
    # empirical p (two-sided) vs NT pseudo-genes for t statistic
    emp = pd.Series([(np.sum(np.abs(tn) >= abs(x))+1)/(len(tn)+1) for x in t], index=Gt.index)
    res = pd.DataFrame({'delta':d, 't':t, 'p_welch':p, 'p_emp':emp})
    res['rank_delta'] = res.delta.rank()  # 1 = most depleted in A vs B
    res['rank_t'] = res.t.rank()
    return res, len(a), len(b)
contrasts = {
 'NTC: G2 vs G1 (immune[IgG2a-like] vs nude-like)': (['Group2_NTC'],['Group1_NTC']),
 'STK11: G6 vs G5 (immune[IgG2a-like] vs nude-like)': (['Group6_STK11'],['Group5_STK11']),
 'NTC: G3+G4 vs G2 (aPD1-like vs IgG2a-like)': (['Group3_NTC','Group4_NTC'],['Group2_NTC']),
 'STK11: G7+G8 vs G6 (aPD1-like vs IgG2a-like)': (['Group7_STK11','Group8_STK11'],['Group6_STK11']),
 'NTC: G2+G3+G4 vs G1 (all B6-like vs nude-like)': (['Group2_NTC','Group3_NTC','Group4_NTC'],['Group1_NTC']),
 'STK11: G6+G7+G8 vs G5 (all B6-like vs nude-like)': (['Group6_STK11','Group7_STK11','Group8_STK11'],['Group5_STK11']),
}
allres = {}
for name,(A,B) in contrasts.items():
    res, na, nb = contrast(A,B,name)
    allres[name]=res
    n = len(res)
    r = res.loc['Mgat1']
    print(f"{name}  [n={na} vs {nb}]  Mgat1: delta={r.delta:.2f}  t={r.t:.2f}  p_welch={r.p_welch:.2g}  p_emp={r.p_emp:.3g}  rank(delta)={int(r.rank_delta)}/{n}  rank(t)={int(r.rank_t)}/{n}")
    print('   most depleted by t:', ', '.join(f"{g}({v:.1f})" for g,v in res.t.sort_values().head(10).items()))
    print('   most enriched by t:', ', '.join(f"{g}({v:.1f})" for g,v in res.t.sort_values().tail(6).items()))
pd.to_pickle(allres, '/tmp/work/inv_contrasts.pkl')
# per-group summary for Mgat1 & controls vs baseline (NT-centred gene score; one-sample vs NT pseudo)
print()
rows=[]
for g in sorted(set(grp[tum])) + ['Endpoint_NTC','Endpoint_STK11']:
    cols = [c for c in S if grp[c]==g]
    for gene in ['Mgat1','B4galt1','Mgat2','Cd274','Ptpn2','Jak1','B2m','Cd47']:
        v = G.loc[gene, cols]
        pn = P[cols].mean(axis=1)
        emp = (np.sum(pn <= v.mean())+1)/(len(pn)+1)
        rows.append((g, gene, len(cols), v.mean(), v.std()/np.sqrt(len(cols)), emp))
R = pd.DataFrame(rows, columns=['group','gene','n','mean','sem','p_emp_lower'])
pd.set_option('display.width',200)
print(R.pivot(index='gene', columns='group', values='mean').round(2).to_string())
print(R.pivot(index='gene', columns='group', values='sem').round(2).to_string())
print(R[R.gene=='Mgat1'].round(4).to_string())
