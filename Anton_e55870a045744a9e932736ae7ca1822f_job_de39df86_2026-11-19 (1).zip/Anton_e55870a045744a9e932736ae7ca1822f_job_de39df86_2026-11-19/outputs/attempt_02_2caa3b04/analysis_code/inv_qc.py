import pandas as pd, numpy as np
df = pd.read_csv('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz')
S = df.columns[3:]
X = df[S].astype(float)
nt = df.gene_symbol.str.startswith('BRDN').values
def gini(x):
    x = np.sort(x); n=len(x); 
    if x.sum()==0: return np.nan
    cum = np.cumsum(x); return (n+1-2*np.sum(cum)/cum[-1])/n
q = pd.DataFrame({'total':X.sum(), 'detected_frac':(X>0).mean(), 'det_ge10':(X>=10).mean(),
                  'gini':X.apply(gini), 'nt_frac':X[nt].sum()/X.sum()})
# correlation with mean plasmid
pl = X[[c for c in S if c.startswith('Plasmid')]]
plm = np.log2(pl.div(pl.sum())*1e6+1).mean(axis=1)
lx = np.log2(X.div(X.sum())*1e6+1)
q['r_plasmid'] = lx.apply(lambda c: np.corrcoef(c, plm)[0,1])
q['group'] = [c.rsplit('_',1)[0] for c in S]
pd.set_option('display.width',200); pd.set_option('display.max_rows',200)
print(q.groupby('group').agg(['median','min','max']).round(3).T.to_string())
print(q.sort_values('total').head(8).round(3))
q.to_csv('/tmp/work/invivo_sample_qc.csv')
