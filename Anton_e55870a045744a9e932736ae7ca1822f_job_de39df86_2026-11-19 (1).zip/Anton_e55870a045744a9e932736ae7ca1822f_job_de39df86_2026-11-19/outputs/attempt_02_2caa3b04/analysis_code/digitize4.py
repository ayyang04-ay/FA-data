from PIL import Image
import numpy as np, json
from scipy import ndimage
im = np.array(Image.open('/tmp/work/img/assay_figures_p1.png').convert('L'))
dark = im < 110
boxes = {'ANT-0592':(0,0,830,660),'ANT-1476':(800,0,1640,660),'ANT-2118':(1630,0,2480,660),
         'ANT-3105':(0,655,830,1315),'ANT-3744':(800,655,1640,1315),'ANT-4267':(1630,655,2480,1315)}
yinfo = {0:(161.5,529.5),655:(807.5,1174.5)}
ticks = {'ANT-0592':[216,316,418,518,620,722,822],'ANT-1476':[998,1100,1200,1302,1404,1504,1606],'ANT-2118':[1782,1884,1984,2086,2186,2288,2390],
         'ANT-3105':[216,316,418,518,620,722,822],'ANT-3744':[998,1100,1200,1302,1404,1504,1606],'ANT-4267':[1782,1884,1984,2086,2186,2288,2390]}
first = {'ANT-0592':-2,'ANT-1476':-2,'ANT-2118':-2,'ANT-3105':-2,'ANT-3744':-2,'ANT-4267':-3}
yy,xx = np.mgrid[-7:8,-7:8]; disk = (xx**2+yy**2)<=49
out={}
for k,(x0,y0,x1,y1) in boxes.items():
    sub = dark[y0:y1, x0:x1]
    rows = sub.sum(axis=1); cols = sub.sum(axis=0)
    xaxis_y = np.argmax(rows); yaxis_x = np.argmax(cols)
    op = ndimage.binary_opening(sub, structure=disk)
    lab, n = ndimage.label(op)
    pts=[]
    for sl in ndimage.find_objects(lab):
        cy=(sl[0].start+sl[0].stop-1)/2; cx=(sl[1].start+sl[1].stop-1)/2
        h=sl[0].stop-sl[0].start; w=sl[1].stop-sl[1].start
        if cx>yaxis_x+5 and cy<xaxis_y-2 and 12<=h<=30 and 12<=w<=30: pts.append((cx+x0,cy+y0))
    t = np.array(ticks[k]); slope, icpt = np.polyfit(t, np.arange(len(t))+first[k], 1)
    ytop,ybot = yinfo[y0]
    vals = [(10**(slope*px+icpt), (ybot-py)/(ybot-ytop)*100) for px,py in sorted(pts)]
    out[k]=vals
    print(k, len(vals), ', '.join(f'{c:.3g}:{a:.1f}' for c,a in vals))
json.dump(out, open('/tmp/work/dr_digitized.json','w'))
