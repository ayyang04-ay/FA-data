from PIL import Image
import numpy as np
from scipy import ndimage
im = np.array(Image.open('/tmp/work/img/assay_figures_p5.png').convert('RGB')).astype(int)
g = im.mean(axis=2)
dark = (g < 90) & (np.abs(im[:,:,0]-im[:,:,2])<40)
xaxis_y=806; yaxis_x=234
xt = np.array([234,406,578,750,922,1094]); yt=np.array([806,692,578,462,348,234])
xs, xi = np.polyfit(xt, np.arange(-2,4), 1); ys, yi = np.polyfit(yt, np.arange(-2,4), 1)
lab,n = ndimage.label(dark)
vals=[]
for i,sl in enumerate(ndimage.find_objects(lab)):
    h=sl[0].stop-sl[0].start; w=sl[1].stop-sl[1].start
    area = (lab[sl]==i+1).sum()
    cy=(sl[0].start+sl[0].stop-1)/2; cx=(sl[1].start+sl[1].stop-1)/2
    if cx>yaxis_x+8 and cy<xaxis_y-8 and 10<=h<=40 and 10<=w<=40:
        fill = area/(h*w)
        circ = abs(h-w)<=3 and 0.70<fill<0.85
        vals.append((cx,cy,h,w,round(fill,2),circ))
ok = [v for v in vals if v[5] and v[2]<=22]
big = [v for v in vals if v[5] and v[2]>22]
print('circular single markers:', len(ok), ' larger circular blobs (possible overlaps):', big)
res=[]
for cx,cy,h,w,f,c in sorted(ok):
    ic = 10**(xs*cx+xi); kd = 10**(ys*cy+yi); res.append((ic,kd))
    print(f'IC50={ic:.3g}  Kd={kd:.3g}  ratio={ic/kd:.2f}')
# merged blobs (two overlapping markers) - report raw
nonc = [v for v in vals if not v[5]]
print('non-circular blobs in plot area (text/overlaps):', [(round(10**(xs*v[0]+xi),3), round(10**(ys*v[1]+yi),3), v[2], v[3], v[4]) for v in nonc])
ic = np.log10([r[0] for r in res]); kd = np.log10([r[1] for r in res])
print('n=%d  Pearson r(log10 IC50 vs log10 Kd)=%.2f  median IC50/Kd=%.2f  range %.2f-%.2f' % (len(res), np.corrcoef(ic,kd)[0,1], np.median(10**(ic-kd)), np.min(10**(ic-kd)), np.max(10**(ic-kd))))
