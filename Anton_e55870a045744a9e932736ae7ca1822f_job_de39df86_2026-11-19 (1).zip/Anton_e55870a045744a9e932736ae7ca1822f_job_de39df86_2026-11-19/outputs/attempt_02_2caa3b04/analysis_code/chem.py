import gemmi
from rdkit import Chem
from rdkit.Chem import Descriptors, rdMolDescriptors, Crippen, AllChem
doc = gemmi.cif.read('/tmp/world/filesystem/MGAT1_C3744_UDP.cif'); b = doc.sole_block()
atoms = b.find('_chem_comp_atom.', ['comp_id','atom_id','type_symbol'])
bonds = b.find('_chem_comp_bond.', ['comp_id','atom_id_1','atom_id_2','value_order','pdbx_aromatic_flag'])
print('chem_comp ids:', set(r[0] for r in atoms))
rw = Chem.RWMol(); idx={}
for r in atoms:
    if r[0]=='C3744':
        a = Chem.Atom(r[2].capitalize() if len(r[2])>1 else r[2]); i = rw.AddAtom(a); idx[r[1].strip('"')]=i
bt = {'SING':Chem.BondType.SINGLE,'DOUB':Chem.BondType.DOUBLE,'TRIP':Chem.BondType.TRIPLE,'AROM':Chem.BondType.AROMATIC}
nb=0
for r in bonds:
    if r[0]=='C3744':
        rw.AddBond(idx[r[1].strip('"')], idx[r[2].strip('"')], bt[r[3].upper()]); nb+=1
m = rw.GetMol()
print('atoms', m.GetNumAtoms(), 'bonds', nb)
try:
    Chem.SanitizeMol(m)
    mh = Chem.RemoveHs(m)
    smi = Chem.MolToSmiles(mh)
    print('SMILES', smi)
    print('MW %.1f  formula %s  TPSA %.1f  cLogP(Crippen) %.2f  HBD %d  HBA %d  RotB %d  heavy atoms %d' % (Descriptors.MolWt(mh), rdMolDescriptors.CalcMolFormula(mh), rdMolDescriptors.CalcTPSA(mh), Crippen.MolLogP(mh), rdMolDescriptors.CalcNumHBD(mh), rdMolDescriptors.CalcNumHBA(mh), rdMolDescriptors.CalcNumRotatableBonds(mh), mh.GetNumHeavyAtoms()))
except Exception as e:
    print('sanitize error', e)
# from name: N-[2-(aminomethyl)-6-(N-methylacetamido)pyridin-4-yl]-2-(cyclobutyloxy)quinoline-4-carboxamide
smi2 = 'NCc1cc(NC(=O)c2cc(OC3CCC3)nc3ccccc23)cc(n1)N(C)C(C)=O'
m2 = Chem.MolFromSmiles(smi2)
print('From IUPAC name: MW %.1f formula %s TPSA %.1f cLogP %.2f heavy %d' % (Descriptors.MolWt(m2), rdMolDescriptors.CalcMolFormula(m2), rdMolDescriptors.CalcTPSA(m2), Crippen.MolLogP(m2), m2.GetNumHeavyAtoms()))
try:
    print('same molecule as CIF?', Chem.MolToSmiles(m2)==Chem.MolToSmiles(mh))
except: pass
