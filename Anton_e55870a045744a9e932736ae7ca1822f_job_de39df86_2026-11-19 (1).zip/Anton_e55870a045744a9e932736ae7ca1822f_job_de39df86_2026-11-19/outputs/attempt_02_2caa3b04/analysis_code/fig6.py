import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
igp = pd.read_pickle('/tmp/work/gp_igp.pkl')
ch = ['AM_N1','AM_N2','AM_N3','AM_N4','AM_KO1','AM_KO2','AM_KO3','AM_KO4','NH_N1','NH_N2','NH_N3','NH_N4','NH_M_KO1','NH_M_KO2','NH_M_KO3','NH_M_KO4']
I = igp[['Intensity '+c for c in ch]].copy(); I.columns = ch
man5 = (igp.HexNAc==2)&(igp.Hex==5)&(igp.get('Fuc',0)==0)&(igp.get('NeuAc',0)==0)
cls = igp['class'].copy(); cls[man5] = 'Man5 (HexNAc2Hex5)'
cls = cls.replace({'Oligomannose (Man5-9)':'Oligomannose Man6-9'})
order = ['Man5 (HexNAc2Hex5)','Oligomannose Man6-9','Paucimannose/truncated (no Fuc)','HexNAc<=2 + Fuc/NeuAc (MGAT1-dependent)','Hybrid-type (HexNAc3Hex>=5)','Complex-type (HexNAc>=3)']
frac = I.groupby(cls).sum().div(I.sum()).loc[order]*100
colors = ['#2980b9','#85c1e9','#d5dbdb','#f5b041','#e67e22','#c0392b']
fig, axes = plt.subplots(1,2, figsize=(16,6.2), gridspec_kw={'width_ratios':[1.3,1]})
ax = axes[0]; bottom = np.zeros(len(ch))
for k,c in zip(order, colors):
    ax.bar(range(len(ch)), frac.loc[k].values, bottom=bottom, color=c, label=k); bottom += frac.loc[k].values
ax.set_xticks(range(len(ch))); ax.set_xticklabels(ch, rotation=60, fontsize=8)
ax.set_ylabel('% of total glycopeptide reporter intensity (IGP_quant)')
ax.set_title('Glycan-class shares per TMT channel: Man5 doubles (~20% -> ~40%) in MGAT1 KO,\nbut MGAT1-dependent classes fall only ~17-20% -> ~9.5% (not to ~0)', fontsize=9.5)
ax.legend(fontsize=7, loc='upper center', bbox_to_anchor=(0.5,-0.2), ncol=3)
ax2 = axes[1]
for cl,nt,ko,col in [('A375',ch[0:4],ch[4:8],'#8e44ad'),('NCI-H1703',ch[8:12],ch[12:16],'#16a085')]:
    totn = I[nt].sum().mean(); totk = I[ko].sum().mean()
    lr = np.log2((I[ko].mean(axis=1)/totk+1e-12)/(I[nt].mean(axis=1)/totn+1e-12))
    for c_, ls in [('Complex-type (HexNAc>=3)','-'),('Man5 (HexNAc2Hex5)','--')]:
        v = lr[cls==c_]
        ax2.hist(v, bins=np.arange(-6,6.01,0.25), histtype='step', lw=1.5, color=col, ls=ls, label=f'{cl}: {c_.split(" (")[0]} (n={len(v)}, median {np.median(v):.2f})')
ax2.axvline(0,color='k',lw=0.5)
ax2.set_xlabel('log2(KO/NT), channel-total normalised'); ax2.set_ylabel('glycopeptides')
ax2.set_title('Per-glycopeptide change: most complex-type glycopeptides\nshift only modestly (compression? incomplete KO?)', fontsize=9.5)
ax2.legend(fontsize=7)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/Fig6_glycoproteomics_KO_vs_NT.png', dpi=150)
frac.round(2).to_csv('/tmp/outputs/derived_data/glycoproteomics_class_share_per_channel.csv')
# normalised intensity-weighted complex ratio
for cl,nt,ko in [('A375',ch[0:4],ch[4:8]),('NCI-H1703',ch[8:12],ch[12:16])]:
    cx = igp['class']=='Complex-type (HexNAc>=3)'
    raw = I[cx][ko].sum().mean()/I[cx][nt].sum().mean()
    norm = raw / (I[ko].sum().mean()/I[nt].sum().mean())
    print(cl, 'complex-type intensity KO/NT raw %.2f, normalised to channel totals %.2f' % (raw, norm))
