import sys; sys.path.insert(0,'/tmp/work/py')
from inv_core import *
from scipy import stats
df, S, X, cpm, grp, bg, L, Lc, nt = load()
genes = df.gene_symbol.values
tum = [c for c in S if c.startswith('Group')]
idx = np.where(genes=='Mgat1')[0]
pd.set_option('display.width',250)
gl = pd.DataFrame({g: Lc.iloc[idx][[c for c in S if grp[c]==g]].mean(axis=1) for g in sorted(set(grp))})
gl.index = df.gene_sgrna_id.values[idx]
print('Mgat1 guide-level NT-centred LFC by group (vs matched baseline):')
print(gl.round(2).to_string())
# guide-level contrast STK11 B6-like vs nude-like
a = [c for c in tum if grp[c] in ('Group6_STK11','Group7_STK11','Group8_STK11')]; b=[c for c in tum if grp[c]=='Group5_STK11']
a2 = [c for c in tum if grp[c] in ('Group2_NTC','Group3_NTC','Group4_NTC')]; b2=[c for c in tum if grp[c]=='Group1_NTC']
for i in idx:
    ta = stats.ttest_ind(Lc.iloc[i][a], Lc.iloc[i][b], equal_var=False)
    tb = stats.ttest_ind(Lc.iloc[i][a2], Lc.iloc[i][b2], equal_var=False)
    print(df.gene_sgrna_id[i], 'STK11 B6-vs-nude delta=%.2f p=%.2g' % (Lc.iloc[i][a].mean()-Lc.iloc[i][b].mean(), ta.pvalue), '| NTC B6-vs-nude delta=%.2f p=%.2g' % (Lc.iloc[i][a2].mean()-Lc.iloc[i][b2].mean(), tb.pvalue))
# baseline/plasmid counts for Mgat1 guides
print(df.iloc[idx][['gene_sgrna_id']+[c for c in S if c.split('_')[0] in ('Plasmid','Baseline')]].to_string())
# rank of Mgat1 per group (gene-level mean NT-centred score), among targeting genes
G = Lc.groupby(genes).mean(); G = G[~G.index.str.startswith('BRDN')]
for g in sorted(set(grp)):
    cols=[c for c in S if grp[c]==g]
    m = G[cols].mean(axis=1).sort_values()
    print(g, 'Mgat1 rank', list(m.index).index('Mgat1')+1, '/', len(m), 'value %.2f'%m['Mgat1'], '| top5:', ', '.join(f"{k}({v:.1f})" for k,v in m.head(5).items()))
