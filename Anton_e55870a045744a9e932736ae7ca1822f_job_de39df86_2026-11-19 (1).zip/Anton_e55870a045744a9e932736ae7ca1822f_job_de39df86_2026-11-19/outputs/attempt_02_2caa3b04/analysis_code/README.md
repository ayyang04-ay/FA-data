# Analysis code (independent verification of the Antera MGAT1 package)

These are the working scripts behind every derived number in `../evidence_register.csv`. They read the client files at
`/tmp/world/filesystem/` and write intermediates to `/tmp/work/` (pickles, extracted images). Change those paths if you rerun elsewhere.

Environments (micromamba): `singlecell` (pandas, scipy, statsmodels, openpyxl, matplotlib) for most scripts;
`core` (gemmi, RDKit) for the structure scripts (`xtal*.py`, `chem.py`, `fig5.py`).
Figure images were first extracted from the PDFs with pypdf (`genomics` env) into `/tmp/work/img/`.

## Run order by analysis

| Analysis | Scripts (in order) | Evidence IDs |
|---|---|---|
| A1 In vivo screen: load, QC, demux/batch check | load_invivo.py, demux.py, inv_qc.py, inv_qc2.py | E29–E31 |
| A2 In vivo screen: NT-centred gene scores, arm inference | inv_core.py (module), inv_genes.py, inv_groups.py | E14 |
| A3 In vivo screen: Mgat1 contrasts, interaction, guides, sensitivity | inv_stats.py, inv_guides.py, inv_interact.py, inv_sens.py, inv_check.py | E10–E13 |
| A4 Co-culture screen: guide/gene scores, UMI lineages, pathway table | cc1.py, cc_guide.py, cc_gene.py, cc_umi.py, cc_path.py | E1–E4 |
| A5 Guide-sequence cross-check | guides.py | E33 |
| A6 Glycoproteomics | gp1.py, gp2.py, gp3.py, gp4.py, gp5.py | E27–E28 |
| A7 Structures and ligand identity | xtal1.py … xtal5.py, chem.py | E26 |
| A8 Dose-response digitisation and refit | digitize4.py, fit_dr.py | E21 |
| A9 IC50 vs KD digitisation | dig_p5b.py | E22 |
| A10 SPR isotherm refit, stoichiometry, competition expectation | spr.py | E23, E25 |
| A11 DSF figure check | dsf.py | E24 |
| A12 Phenotype figure digitisation (tumour volumes etc.) | digit_lib.py, p1d.py, p4.py, p4b.py, p78.py (plus manual zoom reads documented in the register) | E5–E9, E15–E18 |
| A13 Immunoblot densitometry (semi-quantitative) | blot2.py | E32 |
| Derived metrics (LE, LipE, Bliss, CIs) | derived.py | E11, E16, E20 |
| Figures, register | fig1.py … fig6.py, register.py | – |

## Key analysis choices (in vivo pooled screen)

* Counts → CPM → guide log2((x+1)/(matched-baseline+1)), then centred on each sample's median non-targeting guide.
* Per-tumour gene score = mean of the 4 guides.
* Arms were inferred from internal controls, because the client did not supply an arm key:
  * G1/G5 are "nude-like": the least T-cell/IFN-γ-dependent depletion.
  * G2/G6 are "C57BL/6 IgG-like": strong Cd274 dependence.
  * G3+G4 and G7+G8 are "C57BL/6 anti-PD-1-like": Cd274 dependence lost, strongest Ptpn2 depletion.
* Sample Group7_STK11_82431 (349 reads) was excluded.
* Empirical p-values come from random 4-guide non-targeting pseudo-genes.

## Key analysis choices (co-culture screen)

* UMI counts are summed per guide → CPM → log2((T+0.5)/(C+0.5)), centred on 989 NegCtrl guides.
* Guides need ≥50 control reads; genes need ≥3 guides.
* Lineage-level analysis uses UMIs with ≥10 control reads.

## Digitised values

Values read from figures carry about ±5% reading error. Digitised values are labelled as such in the register and memo.
