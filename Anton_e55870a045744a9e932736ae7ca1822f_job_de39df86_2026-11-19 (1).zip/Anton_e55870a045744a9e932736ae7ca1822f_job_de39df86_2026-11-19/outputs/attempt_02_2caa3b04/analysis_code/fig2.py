import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
gs = pd.read_csv('/tmp/work/cc_gene_scores.csv', index_col=0).sort_values('mean_lfc')
gs['rank'] = np.arange(1, len(gs)+1)
fig = plt.figure(figsize=(15,5.2))
ax = fig.add_axes([0.07,0.12,0.54,0.76])
ax.scatter(gs['rank'], gs.mean_lfc, s=3, color='#bbbbbb', rasterized=True)
glyco = ['SLC35A1','GALE','GFPT1','SLC35A2','UGP2','UAP1','CMAS','DAD1','MOGS']
hi = {'MGAT1':'#c0392b','PTPN2':'#1f77b4','CFLAR':'#1f77b4','B2M':'#2ca02c','CTAG1B':'#2ca02c','CTAG1A':'#2ca02c','IFNGR2':'#2ca02c','STAT1':'#2ca02c','JAK1':'#2ca02c','MGAT5':'#8e44ad','MGAT2':'#8e44ad','MAN2A1':'#8e44ad'}
for g in glyco: hi[g] = '#e67e22'
for g,c in hi.items():
    if g in gs.index:
        r = gs.loc[g]
        ax.scatter(r['rank'], r.mean_lfc, s=28 if g!='MGAT1' else 60, color=c, zorder=5, edgecolor='k', lw=0.4)
        offs = {'MGAT1':(14,-12),'PTPN2':(10,-2),'CFLAR':(10,-4),'SLC35A1':(12,-8),'GALE':(12,-2),'GFPT1':(12,2),'B2M':(-30,0),'CTAG1B':(-42,0),'STAT1':(-34,0),'JAK1':(-30,-4),'MGAT5':(-10,8),'MGAT2':(-10,-14),'MAN2A1':(-52,6)}
        if g in offs:
            ax.annotate(g, (r['rank'], r.mean_lfc), xytext=offs[g], textcoords='offset points', fontsize=8, color=c, fontweight='bold' if g=='MGAT1' else None)
ax.set_xscale('symlog', linthresh=100)
ax.set_xlabel('gene rank (1 = most depleted in T-cell arm); symlog scale')
ax.set_ylabel('mean guide log2FC (TCR T-cell 24 h vs tumour-only)\ncentred on non-targeting guides')
ax.axhline(0,color='k',lw=0.5,ls=':')
ax.set_title('Genome-wide co-culture screen, NCI-H1703 (n=1 sample per arm)\nMGAT1 rank 16/18,860; orange = other glycosylation genes ranked above/near MGAT1; purple = downstream branching enzymes', fontsize=9)
# UMI-level panel
cc = pd.read_pickle('/tmp/work/cc.pkl')
A='tumor_only_untreated'; B='MSCV_TCR_high_24hr'
sf = cc[B].sum()/cc[A].sum()
u = cc[cc[A]>=10]
lfc = np.log2((u[B]/sf+0.5)/(u[A]+0.5)); lfc -= lfc[u.genetype=='NegCtrl'].median()
ax2 = fig.add_axes([0.69,0.12,0.30,0.76])
sets = [('non-targeting', u.genetype=='NegCtrl','#999999'),('MGAT1',u.gene_symbol=='MGAT1','#c0392b'),('PTPN2',u.gene_symbol=='PTPN2','#1f77b4'),('SLC35A1',u.gene_symbol=='SLC35A1','#e67e22'),('B2M',u.gene_symbol=='B2M','#2ca02c')]
data = [lfc[m].values for _,m,_ in sets]
bp = ax2.boxplot(data, showfliers=False, widths=0.6, patch_artist=True)
for patch,(_,_,c) in zip(bp['boxes'], sets): patch.set_facecolor(c); patch.set_alpha(0.5)
ax2.set_xticks(range(1,len(sets)+1)); ax2.set_xticklabels([f"{n}\n(n={len(d)})" for (n,_,_),d in zip(sets,data)], fontsize=8)
ax2.axhline(0,color='k',lw=0.5,ls=':')
ax2.set_ylabel('UMI-lineage log2FC (lineages with >=10 reads in tumour-only arm)')
ax2.set_title('UMI-lineage level: MGAT1 median -1.0\n(vs SLC35A1 -3.8, PTPN2 -1.9); MWU p=1e-8 vs NT', fontsize=9)
plt.savefig('/tmp/outputs/figures/Fig2_coculture_screen.png', dpi=160)
gs.to_csv('/tmp/outputs/derived_data/coculture_screen_gene_scores.csv')
print('ok')
