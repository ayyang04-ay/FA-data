import pandas as pd, numpy as np, re
x = pd.ExcelFile('/tmp/world/filesystem/glycoproteomics_site_quant.xlsx')
pep = x.parse('IGP_Pep_quant'); igp = x.parse('IGP_quant'); site = x.parse('Site_quant')
ch = ['AM_N1','AM_N2','AM_N3','AM_N4','AM_KO1','AM_KO2','AM_KO3','AM_KO4','NH_N1','NH_N2','NH_N3','NH_N4','NH_M_KO1','NH_M_KO2','NH_M_KO3','NH_M_KO4']
print('PSM-level rows', len(pep), 'unique peptides', pep['Peptide Sequence'].nunique(), 'unique sites', pep.groupby(['Protein accession','Position']).ngroups)
# sequon check: locate glycosylated N in modified sequence
def glyco_positions(modseq):
    # strip n-term tag
    s = re.sub(r'^n\[\d+\]','',modseq)
    pos=[]; seq=''; i=0
    while i < len(s):
        c = s[i]
        if c=='[':
            j = s.index(']', i); mass=float(s[i+1:j])
            if seq and seq[-1]=='N' and mass>500: pos.append(len(seq)-1)
            i=j+1; continue
        seq+=c; i+=1
    return seq, pos
res=[]
for _,r in pep.iterrows():
    seq,pos = glyco_positions(str(r['Modified Sequence']))
    for p in pos:
        nxt = seq[p+1:p+3]
        if len(nxt)<2: sequon='C-term(undetermined)'
        elif nxt[0]!='P' and nxt[1] in 'ST': sequon='N-X-S/T'
        elif nxt[0]!='P' and nxt[1]=='C': sequon='N-X-C'
        else: sequon='no sequon'
        res.append((r['Protein accession'], r['Position'], r['Gene name'], seq, p, nxt, sequon, r['Expectation'], r['Localization probability'], r['Observed Modification']))
R = pd.DataFrame(res, columns=['acc','pos','gene','seq','idx','next2','sequon','expect','locprob','glycan'])
print(R.sequon.value_counts())
sites = R.groupby(['acc','pos']).sequon.agg(lambda s: 'N-X-S/T' if (s=='N-X-S/T').any() else s.iloc[0])
print('site-level sequon status:\n', sites.value_counts())
print('Expectation by sequon class:\n', R.groupby('sequon').expect.describe().round(4))
print('Loc prob by sequon class:\n', R.groupby('sequon').locprob.describe().round(3))
R.to_pickle('/tmp/work/gp_psm_sequon.pkl')
# suspicious proteins by description keywords
desc = pep[['Protein accession','Protein description','Gene name']].drop_duplicates()
kw = r'Transcription factor|homeobox|Histone|ribonucleoprotein|Zinc finger|nuclear|Nuclear|Ribosom|ribosom|Splicing|splicing|DNA-binding|RNA-binding|Tubulin|Actin |Keratin'
sus = desc[desc['Protein description'].str.contains(kw, regex=True)]
print('proteins with nuclear/cytosolic-type descriptions:', len(sus), 'of', len(desc))
print(sus.head(25).to_string())
