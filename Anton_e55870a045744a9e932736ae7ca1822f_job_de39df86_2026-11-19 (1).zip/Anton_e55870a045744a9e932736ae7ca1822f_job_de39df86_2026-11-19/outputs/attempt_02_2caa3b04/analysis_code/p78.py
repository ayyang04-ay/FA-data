import sys; sys.path.insert(0,'/tmp/work/py')
from digit_lib import *
for f in ['phenotype_figures_p7.png','phenotype_figures_p8.png']:
    im = load('/tmp/work/img/'+f); g = im.mean(axis=2); dark=g<80
    H,W,_ = im.shape; print(f, W,H)
    # candidate y-axes: columns with long dark vertical runs
    colsum = dark.sum(axis=0)
    cand = [c for c in range(W) if colsum[c]>250]
    groups=[]
    for c in cand:
        if groups and c-groups[-1][-1]<=2: groups[-1].append(c)
        else: groups.append([c])
    yaxes = [int(np.mean(x)) for x in groups]
    print(' y-axis candidates', yaxes)
    rowsum = dark.sum(axis=1)
    candr = [r for r in range(H) if rowsum[r]>300]
    groups=[]
    for c in candr:
        if groups and c-groups[-1][-1]<=2: groups[-1].append(c)
        else: groups.append([c])
    print(' x-axis candidates', [int(np.mean(x)) for x in groups])
    for ya in yaxes:
        seg = dark[:, ya-16:ya-4]
        r = np.where(seg.sum(axis=1)>=9)[0]
        groups=[]
        for x in r:
            if groups and x-groups[-1][-1]<=2: groups[-1].append(x)
            else: groups.append([x])
        print('  yaxis',ya,'ticks',[round(np.mean(g_),1) for g_ in groups])
