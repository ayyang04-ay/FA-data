import sys; sys.path.insert(0,'/tmp/work/py')
import pandas as pd, numpy as np
allres = pd.read_pickle('/tmp/work/inv_contrasts.pkl')
short = {'NTC: G2 vs G1 (immune[IgG2a-like] vs nude-like)':'NTC_G2_vs_G1',
         'STK11: G6 vs G5 (immune[IgG2a-like] vs nude-like)':'STK11_G6_vs_G5',
         'NTC: G3+G4 vs G2 (aPD1-like vs IgG2a-like)':'NTC_G3G4_vs_G2',
         'STK11: G7+G8 vs G6 (aPD1-like vs IgG2a-like)':'STK11_G7G8_vs_G6',
         'NTC: G2+G3+G4 vs G1 (all B6-like vs nude-like)':'NTC_B6like_vs_nudelike',
         'STK11: G6+G7+G8 vs G5 (all B6-like vs nude-like)':'STK11_B6like_vs_nudelike'}
parts=[]
for k,v in allres.items():
    d = v[['delta','t','p_welch','p_emp','rank_delta']].copy(); d.columns=[f'{short[k]}__{c}' for c in d.columns]; parts.append(d)
out = pd.concat(parts, axis=1)
# interaction
exec(open('/tmp/work/py/inv_interact.py').read().split("# null from NT")[0])
out['interaction_STK11xImmune__beta'] = R['beta']; out['interaction_STK11xImmune__t'] = R['t']; out['interaction_STK11xImmune__p'] = R['p']
out.index.name='gene'
out.to_csv('/tmp/outputs/derived_data/invivo_screen_gene_contrasts.csv')
print(out.loc['Mgat1'].round(4).to_string())
