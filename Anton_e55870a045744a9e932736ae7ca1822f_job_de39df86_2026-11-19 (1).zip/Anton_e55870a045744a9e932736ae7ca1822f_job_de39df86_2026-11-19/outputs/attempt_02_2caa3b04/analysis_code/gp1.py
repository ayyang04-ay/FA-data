import pandas as pd, numpy as np
x = pd.ExcelFile('/tmp/world/filesystem/glycoproteomics_site_quant.xlsx')
print(x.sheet_names)
for s in x.sheet_names:
    d = x.parse(s)
    print('=====', s, d.shape)
    print(list(d.columns))
    print(d.head(3).T.to_string()[:3000])
