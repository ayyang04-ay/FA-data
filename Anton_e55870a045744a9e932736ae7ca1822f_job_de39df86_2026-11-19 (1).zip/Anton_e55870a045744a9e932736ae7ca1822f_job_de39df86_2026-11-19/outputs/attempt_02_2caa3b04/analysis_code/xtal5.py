import gemmi
for k in ['C3744','C3744_UDP','UDP','UDP_GlcNAc','apo']:
    b = gemmi.cif.read('/tmp/world/filesystem/MGAT1_%s.cif'%k).sole_block()
    print('===',k)
    for cat in ['_pdbx_validate_close_contact.','_pdbx_validate_torsion.']:
        t = b.find_mmcif_category(cat)
        if t:
            tags = list(t.tags)
            print(' ', cat, len(t), 'rows')
            for row in t:
                print('    ', ' '.join(row))
    # ligand-related struct_conn
    t = b.find_mmcif_category('_struct_conn.')
    if t:
        n = sum(1 for r in t)
        print('  struct_conn rows', n)
