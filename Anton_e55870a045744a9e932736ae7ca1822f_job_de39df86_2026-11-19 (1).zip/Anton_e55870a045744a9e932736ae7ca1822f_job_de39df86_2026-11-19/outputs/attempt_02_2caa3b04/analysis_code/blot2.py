import numpy as np
from PIL import Image
im = np.array(Image.open('/tmp/work/img/phenotype_figures_p6.png').convert('L')).astype(float)
inv = 255-im
lanes = [330+x/2 for x in [95,265,435,605,775,940,1115,1285,1455]]
def lane_profile(cx, ya, yb, half=28):
    return inv[ya:yb, int(cx-half):int(cx+half)].mean(axis=1)
res=[]
for i,cx in enumerate(lanes):
    # STK11 region rows 400-450; local background = median of rows 380-398 and 440-450 (between STK11 and lower band)
    p = lane_profile(cx, 395, 450)
    bg = np.median(np.r_[p[:5], p[-8:]])
    stk = np.clip(p - bg, 0, None).sum()
    pv = lane_profile(cx, 570, 640)
    bgv = np.median(np.r_[pv[:6], pv[-6:]])
    vin = np.clip(pv - bgv, 0, None).sum()
    res.append((stk, vin))
res = np.array(res); ratio = res[:,0]/res[:,1]
labels = ['L1 N/A','L2 sgNTC (MGAT1+,STK11+)','L3 MGAT1KO','L4 STK11KO','L5 MGAT1KO+STK11KO','L6 STK11KO +WT cDNA','L7 STK11KO +mut cDNA','L8 dKO +WT cDNA','L9 dKO +mut cDNA']
for l,(s,v),r in zip(labels,res,ratio):
    print(f'{l:28s} STK11 {s:7.1f}  vinculin {v:7.1f}  ratio {r:5.3f}  ({r/ratio[1]*100:5.1f}% of L2)')
