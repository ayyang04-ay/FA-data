import gemmi, glob, os, numpy as np
np.set_printoptions(precision=2, suppress=True)
for f in sorted(glob.glob('/tmp/world/filesystem/MGAT1_*.cif')):
    st = gemmi.read_structure(f); st.setup_entities()
    print('===', os.path.basename(f), 'models', len(st), 'chains', [ (c.name, len(c)) for c in st[0]])
    model = st[0]
    ns = gemmi.NeighborSearch(model, st.cell, 5).populate()
    for ch in model:
        for res in ch:
            if res.het_flag == 'H' and res.name not in ('HOH',):
                occ = np.array([a.occ for a in res]); bf = np.array([a.b_iso for a in res])
                # protein contacts within 4 A
                contacts=set(); sym_contacts=set()
                for a in res:
                    for m in ns.find_atoms(a.pos, '\0', radius=4.0):
                        cra = m.to_cra(model)
                        if cra.residue.het_flag!='H' and cra.residue.name!='HOH':
                            key=(cra.chain.name, cra.residue.name, cra.residue.seqid.num)
                            if m.image_idx==0: contacts.add(key)
                            else: sym_contacts.add(key)
                # local protein B-factor mean
                cb = []
                for c in contacts:
                    r = model[c[0]][str(c[2])][0]
                    cb += [a.b_iso for a in r]
                print(f"  {ch.name} {res.name} {res.seqid.num}: natoms={len(res)} occ={occ.min():.2f}-{occ.max():.2f} B mean={bf.mean():.1f} (min {bf.min():.1f}, max {bf.max():.1f}); contacting-protein B mean={np.mean(cb) if cb else float('nan'):.1f}; n_contacts={len(contacts)} symmetry-mate contacts={len(sym_contacts)}")
                if res.name in ('C3744','UDP','UD1') :
                    print('      contacts:', sorted(contacts, key=lambda x:(x[0],x[2])))
                    if sym_contacts: print('      SYMMETRY contacts:', sorted(sym_contacts, key=lambda x:(x[0],x[2])))
