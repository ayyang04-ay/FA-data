import json, numpy as np
from scipy.optimize import curve_fit
d = json.load(open('/tmp/work/dr_digitized.json'))
rep = {'ANT-0592':197,'ANT-1476':2.02,'ANT-2118':25.6,'ANT-3105':0.543,'ANT-3744':0.814,'ANT-4267':0.043}
sol = {'ANT-0592':11.8,'ANT-3744':178,'ANT-4267':96.4}
def f4(x, top, bot, ic50, h): return bot + (top-bot)/(1+(x/ic50)**h)
def f3(x, top, ic50, h): return f4(x, top, 0, ic50, h)
print('compound   reported | 4PL: IC50  Hill  bottom  top | 3PL(bottom=0): IC50  Hill | max inhibition observed')
for k,v in d.items():
    x = np.array([a for a,b in v]); y = np.array([b for a,b in v])
    try:
        p4,_ = curve_fit(f4, x, y, p0=[100,10,rep[k],1], bounds=([50,-20,1e-4,0.2],[130,80,1e5,5]), maxfev=20000)
    except Exception as e: p4=[np.nan]*4
    p3,_ = curve_fit(f3, x, y, p0=[100,rep[k],1], bounds=([50,1e-4,0.2],[130,1e5,5]), maxfev=20000)
    print(f"{k}  {rep[k]:8.3g} | {p4[2]:8.3g} {p4[3]:5.2f} {p4[1]:6.1f} {p4[0]:6.1f} | {p3[1]:8.3g} {p3[2]:5.2f} | {100-y.min():5.1f}% at {x[np.argmin(y)]:.3g} uM" + (f"   [kinetic solubility {sol[k]} uM]" if k in sol else ''))
print('\nTop fixed at 100 (bottom free):')
def f3b(x, bot, ic50, h): return f4(x, 100, bot, ic50, h)
for k,v in d.items():
    x = np.array([a for a,b in v]); y = np.array([b for a,b in v])
    p,cov = curve_fit(f3b, x, y, p0=[10,rep[k],1], bounds=([-20,1e-4,0.2],[80,1e5,5]), maxfev=20000)
    se = np.sqrt(np.diag(cov))
    print(f"{k}: IC50={p[1]:.3g} uM (reported {rep[k]}), Hill={p[2]:.2f}, bottom={p[0]:.1f}% +/- {se[0]:.1f}")
