import gemmi, numpy as np
exec(open('/tmp/work/py/xtal3.py').read().split("for ch in ['A','B']:")[0])
for ch in ['A','B']:
    # GlcNAc C1' distance
    R,Pc,Qc,rmsd,common,_,_ = superpose(S['UDP_GlcNAc'], S['C3744_UDP'], ch)
    ud1 = lig_coords(S['UDP_GlcNAc'], ch, 'UD1')
    c1 = (ud1["C1'"]-Pc)@R.T+Qc
    c37 = lig_coords(S['C3744_UDP'], ch, 'C3744'); X37=np.array(list(c37.values()))
    print(ch, "GlcNAc C1' (anomeric C, transfer centre) to nearest C3744 atom: %.1f A" % np.min(np.linalg.norm(X37-c1,axis=1)))
    # D289 (catalytic base) to C3744
    d289 = np.array([a.pos.tolist() for a in S['C3744_UDP'][0][ch]['289'][0]])
    print(ch, 'D289 side chain to nearest C3744 atom: %.1f A' % np.min(np.linalg.norm(X37[:,None,:]-d289[None],axis=2)))
# per-residue CA displacement apo -> C3744 (binary) and UDP -> C3744_UDP, chain A and B
for ref, mob in [('apo','C3744'),('UDP','C3744_UDP'),('apo','UDP'),('apo','UDP_GlcNAc')]:
    for ch in ['A','B']:
        R,Pc,Qc,rmsd,common,P,Q = superpose(S[ref], S[mob], ch)
        moved = ((P-Pc)@R.T+Qc) - Q
        d = np.linalg.norm(moved,axis=1)
        top = np.argsort(-d)[:12]
        print(f'{ref}->{mob} chain {ch}: n={len(common)}; residues with CA shift >1.0 A:', [ (common[i], round(float(d[i]),1)) for i in sorted(np.where(d>1.0)[0])])
# disordered residues
for k,st in S.items():
    doc = gemmi.cif.read(fs[k]); b = doc.sole_block()
    t = b.find('_pdbx_unobs_or_zero_occ_residues.', ['auth_asym_id','auth_seq_id','auth_comp_id'])
    miss = {}
    for row in t:
        miss.setdefault(row[0], []).append(int(row[1]))
    def ranges(l):
        l=sorted(l); out=[]; s=l[0]; p=l[0]
        for x in l[1:]:
            if x!=p+1: out.append((s,p)); s=x
            p=x
        out.append((s,p)); return out
    print(k, 'unobserved residues:', {c: ranges(v) for c,v in miss.items()})
    # observed range
    for ch in st[0]:
        nums=[r.seqid.num for r in ch if r.het_flag!='H']
        print('    chain', ch.name, 'observed polymer residues', min(nums), '-', max(nums), 'count', len(nums))
