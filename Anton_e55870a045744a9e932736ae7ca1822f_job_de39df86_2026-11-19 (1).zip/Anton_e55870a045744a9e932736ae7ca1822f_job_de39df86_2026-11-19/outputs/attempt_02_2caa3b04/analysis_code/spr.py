import numpy as np
from scipy.optimize import curve_fit
# values read from assay_figures p3 (upper right) and p2 (UDP) steady-state plots
c37 = np.array([0.0098,0.0195,0.0391,0.0781,0.1563,0.3125,0.625,1.25,2.5,5,10])
r37 = np.array([2,5,10,19,33,54,74,91,104,110,115])
cU = np.array([0.488,0.977,1.953,3.906,7.813,15.63,31.25,62.5,125,250])
rU = np.array([0.15,0.35,0.7,1.25,2.3,3.4,4.85,6.1,7.5,8.7])
c37u = np.array([0.0195,0.0391,0.0781,0.1563,0.3125,0.625,1.25,2.5,5])
r37u = np.array([2.8,5.4,9.1,14.5,20.3,26.2,30.1,32.1,32.3])
f = lambda c,Rmax,Kd: Rmax*c/(Kd+c)
for name,c,r,RL in [('ANT-3744 (9000 RU surface)',c37,r37,9000),('UDP (9000 RU surface)',cU,rU,9000),('ANT-3744 in 5 mM UDP (3500 RU surface)',c37u,r37u,3500)]:
    p,_ = curve_fit(f,c,r,p0=[max(r),1])
    mw = 404.16 if name.startswith('UDP') else 419.48
    for prot in [44700, 45900]:
        theo = RL*mw/prot
        print(f'{name}: fitted Rmax={p[0]:.1f} RU, Kd={p[1]:.3g} uM; theoretical 1:1 Rmax (protein {prot/1000:.1f} kDa)={theo:.1f} RU -> observed/theoretical={p[0]/theo:.2f}')
# competitive expectations
print('If purely competitive: ANT-3744 Kd,app in 5 mM UDP = %.0f uM (observed 0.2)' % (0.4*(1+5000/32)))
print('If purely competitive: UDP Kd,app in 20 uM ANT-3744 = %.0f uM (observed 20)' % (32*(1+20/0.4)))
