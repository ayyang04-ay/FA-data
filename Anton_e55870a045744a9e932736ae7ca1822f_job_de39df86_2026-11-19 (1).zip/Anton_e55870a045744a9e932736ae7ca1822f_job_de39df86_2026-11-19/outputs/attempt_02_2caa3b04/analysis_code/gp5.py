import pandas as pd, numpy as np
igp = pd.read_pickle('/tmp/work/gp_igp.pkl')
ch = ['AM_N1','AM_N2','AM_N3','AM_N4','AM_KO1','AM_KO2','AM_KO3','AM_KO4','NH_N1','NH_N2','NH_N3','NH_N4','NH_M_KO1','NH_M_KO2','NH_M_KO3','NH_M_KO4']
I = igp[['Intensity '+c for c in ch]].copy(); I.columns = ch
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',40)
cx = igp['class']=='Complex-type (HexNAc>=3)'
top = I[cx].sum(axis=1).sort_values(ascending=False).head(15).index
out = igp.loc[top, ['Gene name','Position','Observed Modification']].copy()
for cl,nt,ko in [('A375',ch[0:4],ch[4:8]),('H1703',ch[8:12],ch[12:16])]:
    out[cl+'_NT_mean(1e6)'] = (I.loc[top,nt].mean(axis=1)/1e6).round(2)
    out[cl+'_KO_mean(1e6)'] = (I.loc[top,ko].mean(axis=1)/1e6).round(2)
    out[cl+'_KO/NT'] = (I.loc[top,ko].mean(axis=1)/I.loc[top,nt].mean(axis=1)).round(2)
print(out.to_string())
# fraction of complex-type glycopeptides with KO/NT < 0.25 in each line
for cl,nt,ko in [('A375',ch[0:4],ch[4:8]),('H1703',ch[8:12],ch[12:16])]:
    r = I[cx][ko].mean(axis=1)/I[cx][nt].mean(axis=1)
    w = I[cx][nt].mean(axis=1)
    print(cl, 'complex glycopeptides KO/NT<0.25: %d/%d; intensity-weighted KO/NT for complex = %.2f' % ((r<0.25).sum(), len(r), I[cx][ko].mean(axis=1).sum()/I[cx][nt].mean(axis=1).sum()))
# Does the total (sum) of each channel normalise? Note KO channels have higher total intensity
