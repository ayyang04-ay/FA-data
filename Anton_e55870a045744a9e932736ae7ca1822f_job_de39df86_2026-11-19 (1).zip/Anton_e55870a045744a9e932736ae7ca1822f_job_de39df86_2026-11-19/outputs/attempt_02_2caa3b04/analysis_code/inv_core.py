import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
def load(drop_failed=True, pseudo=1.0):
    df = pd.read_csv('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz')
    S = [c for c in df.columns[3:] if not (drop_failed and c=='Group7_STK11_82431')]
    X = df[S].astype(float)
    cpm = X.div(X.sum())*1e6
    grp = pd.Series([c.rsplit('_',1)[0] for c in S], index=S)
    bg  = pd.Series(['STK11' if 'STK11' in c else ('NTC' if 'NTC' in c else 'none') for c in S], index=S)
    pl = cpm[[c for c in S if c.startswith('Plasmid')]].mean(axis=1)
    base = {b: cpm[[c for c in S if c.startswith('Baseline_'+b)]].mean(axis=1) for b in ['NTC','STK11']}
    cols = {}
    for c in S:
        ref = base[bg[c]] if bg[c] in base else pl
        cols[c] = np.log2((cpm[c]+pseudo)/(ref+pseudo))
    L = pd.DataFrame(cols)
    # center each sample on its non-targeting guides (median)
    nt = df.gene_symbol.str.startswith('BRDN').values
    Lc = L - L[nt].median()
    return df, S, X, cpm, grp, bg, L, Lc, nt
