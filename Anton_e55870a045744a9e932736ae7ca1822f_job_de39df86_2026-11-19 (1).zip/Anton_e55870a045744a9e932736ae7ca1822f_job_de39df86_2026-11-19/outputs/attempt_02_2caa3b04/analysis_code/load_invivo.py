import pandas as pd, numpy as np
df = pd.read_csv('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz')
print(df.shape)
print(df.iloc[:,:3].describe(include='all'))
meta = df.columns[3:]
groups = pd.Series([c.rsplit('_',1)[0] if c.startswith('Group') else c.rsplit('_',1)[0] for c in meta], index=meta)
print(groups.value_counts().sort_index())
# genes
print('n genes', df.gene_symbol.nunique())
vc = df.gene_symbol.value_counts()
print(vc.value_counts())
print(vc.head(10))
# non-targeting labels
print([g for g in df.gene_symbol.unique() if 'non' in g.lower() or 'ntc' in g.lower() or 'control' in g.lower()][:20])
# check duplicates
print('dup sgrna', df.sgrna.duplicated().sum(), 'dup id', df.gene_sgrna_id.duplicated().sum())
print('sgrna lengths', df.sgrna.str.len().value_counts())
# some genes
for g in ['Mgat1','Stk11','Cd274','Ptpn2','B2m','Jak1','Jak2','Ifngr1','Ifngr2','Stat1','Adar','Mgat5','Mgat2','Cd276','Pdcd1']:
    print(g, (df.gene_symbol==g).sum())
tot = df[meta].sum()
print(tot.describe())
print(tot.sort_values().head(15))
print(tot.sort_values().tail(10))
