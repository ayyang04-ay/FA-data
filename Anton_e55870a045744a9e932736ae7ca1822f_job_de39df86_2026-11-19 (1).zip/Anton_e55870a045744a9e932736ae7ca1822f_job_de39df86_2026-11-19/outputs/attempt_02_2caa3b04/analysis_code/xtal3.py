import gemmi, numpy as np
fs = {k:'/tmp/world/filesystem/MGAT1_%s.cif'%k for k in ['apo','UDP','UDP_GlcNAc','C3744','C3744_UDP']}
S = {k: gemmi.read_structure(v) for k,v in fs.items()}
for s in S.values(): s.setup_entities()
def ca_dict(st, ch):
    d={}
    for r in st[0][ch]:
        if r.het_flag!='H' and r.find_atom('CA','*'):
            d[r.seqid.num]=np.array(r.find_atom('CA','*').pos.tolist())
    return d
def superpose(stm, stf, ch='A'):
    a=ca_dict(stm,ch); b=ca_dict(stf,ch); common=sorted(set(a)&set(b))
    P=np.array([a[i] for i in common]); Q=np.array([b[i] for i in common])
    Pc=P.mean(0); Qc=Q.mean(0); H=(P-Pc).T@(Q-Qc); U,Sv,Vt=np.linalg.svd(H); d=np.sign(np.linalg.det(Vt.T@U.T))
    D=np.diag([1,1,d]); R=Vt.T@D@U.T
    rmsd=np.sqrt(((((P-Pc)@R.T)+Qc-Q)**2).sum(1).mean())
    return R,Pc,Qc,rmsd,common,P,Q
def lig_coords(st, ch, name):
    for r in st[0][ch]:
        if r.name==name: return {a.name: np.array(a.pos.tolist()) for a in r}
    return None
for ch in ['A','B']:
    print('--- chain', ch)
    c37 = lig_coords(S['C3744_UDP'], ch, 'C3744'); udp = lig_coords(S['C3744_UDP'], ch, 'UDP')
    X37=np.array(list(c37.values())); XU=np.array(list(udp.values()))
    dmin = np.min(np.linalg.norm(X37[:,None,:]-XU[None,:,:],axis=2))
    print('ternary: min C3744-UDP distance %.1f A; centroid distance %.1f A' % (dmin, np.linalg.norm(X37.mean(0)-XU.mean(0))))
    # superpose UDP_GlcNAc onto ternary, get GlcNAc C1 position
    R,Pc,Qc,rmsd,common,_,_ = superpose(S['UDP_GlcNAc'], S['C3744_UDP'], ch)
    ud1 = lig_coords(S['UDP_GlcNAc'], ch, 'UD1')
    print('UD1 atoms:', list(ud1.keys()))
    c1 = (ud1['C1']-Pc)@R.T+Qc if 'C1' in ud1 else None
    if c1 is not None:
        print('superposition RMSD(CA) UDP-GlcNAc->ternary %.2f A over %d CA; GlcNAc C1 to nearest C3744 atom: %.1f A' % (rmsd,len(common), np.min(np.linalg.norm(X37-c1,axis=1))))
    # Also C3744 binary onto ternary
    R2,Pc2,Qc2,rmsd2,common2,_,_ = superpose(S['C3744'], S['C3744_UDP'], ch)
    c37b = lig_coords(S['C3744'], ch, 'C3744')
    Xb = (np.array([c37b[k] for k in c37.keys()])-Pc2)@R2.T+Qc2
    print('C3744 binary vs ternary: CA RMSD %.2f; ligand pose RMSD (same atom names) %.2f A' % (rmsd2, np.sqrt(((Xb-X37)**2).sum(1).mean())))
# global CA RMSDs between all structures, chain A
keys=list(S.keys())
print('\nCA RMSD chain A (after superposition):')
for i in keys:
    print(i.ljust(11), ' '.join('%5.2f'%superpose(S[i],S[j],'A')[3] for j in keys))
