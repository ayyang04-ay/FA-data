import sys; sys.path.insert(0,'/tmp/work/py')
from digit_lib import *
im = load('/tmp/work/img/phenotype_figures_p1.png')
panels = {
 'MC38 WT':      dict(box=(245,200,900,625), y=[(238,3000),(368,2000),(498,1000),(628.5,0)], x=[(240,0),(358,5),(474,10),(592,15),(709,20),(826,25)]),
 'MC38 sgSTK11': dict(box=(1100,200,1720,625), y=[(292.5,1500),(404.5,1000),(516.5,500),(628.5,0)], x=[(1099,0),(1246,5),(1394,10),(1540,15),(1688,20)]),
}
for name,p in panels.items():
    ys = cal(p['y']); xs = cal(p['x'])
    for lab,rgb,tol,rad in [('sgNTC(black)',(0,0,0),90,6),('sgMGAT1(green)',(0,125,55),60,3)]:
        pts = markers(im, p['box'], rgb, tol, rad=rad)
        print(name, lab, ', '.join(f'd{np.polyval(xs,px):.1f}:{np.polyval(ys,py):.0f}' for px,py,a in pts))
