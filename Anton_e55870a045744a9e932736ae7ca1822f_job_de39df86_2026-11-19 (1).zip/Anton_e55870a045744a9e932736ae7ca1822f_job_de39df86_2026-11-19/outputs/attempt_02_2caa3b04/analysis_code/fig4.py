import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
rows = [
 # panel, label, mean, lo, hi, source
 ('A','MC38 WT sgNTC (d25)',1163,350,1980,'phenotype p1 left'),
 ('A','MC38 WT sgMGAT1 (d25)',1774,910,2640,'phenotype p1 left'),
 ('A','MC38 sgSTK11 sgNTC (d19)',1087,580,1600,'phenotype p1 middle'),
 ('A','MC38 sgSTK11 sgMGAT1 (d19)',542,110,1000,'phenotype p1 middle'),
 ('B','NTC + IgG2a',1145,468,1810,'phenotype p1 right (d9)'),
 ('B','NTC + anti-PD-1',763,87,1434,'phenotype p1 right (d9)'),
 ('B','sgMGAT1 + IgG2a',621,311,929,'phenotype p1 right (d9)'),
 ('B','sgMGAT1 + anti-PD-1',395,126,np.nan,'phenotype p1 right (d9)'),
 ('C','sgSTK11+sgNTC: WT cDNA (d12)',895,364,1424,'phenotype p7 left'),
 ('C','sgSTK11+sgNTC: D211A/D289A (d12)',790,504,1086,'phenotype p7 left'),
 ('C','sgSTK11+sgMGAT1: WT cDNA (d19)',862,619,1104,'phenotype p7 right'),
 ('C','sgSTK11+sgMGAT1: D211A/D289A (d19)',422,261,582,'phenotype p7 right'),
 ('D','control T: sgNTC',1930,1539,2320,'phenotype p4 top (d19)'),
 ('D','control T: sgMGAT1',1646,1466,1842,'phenotype p4 top (d19)'),
 ('D','NY-ESO T 1e6: sgNTC',1299,777,1822,'phenotype p4 middle (d19)'),
 ('D','NY-ESO T 1e6: sgMGAT1',616,239,992,'phenotype p4 middle (d19)'),
 ('D','NY-ESO T 2e6: sgNTC',601,np.nan,1001,'phenotype p4 bottom (d19)'),
 ('D','NY-ESO T 2e6: sgMGAT1',181,np.nan,376,'phenotype p4 bottom (d19)'),
 ('E','MC38 sgNTC: nude (d8)',929,605,1251,'phenotype p8 left'),
 ('E','MC38 sgNTC: C57BL/6 (d8)',382,250,509,'phenotype p8 left'),
 ('E','MC38 sgNTC: C57BL/6+aPD-1 (d8)',95,41,149,'phenotype p8 left'),
 ('E','MC38 sgSTK11: nude (d7)',964,666,1262,'phenotype p8 right'),
 ('E','MC38 sgSTK11: C57BL/6 (d7)',1264,773,1761,'phenotype p8 right'),
 ('E','MC38 sgSTK11: C57BL/6+aPD-1 (d7)',643,285,1021,'phenotype p8 right'),
]
T = pd.DataFrame(rows, columns=['panel','arm','mean_mm3','errbar_low','errbar_high','source'])
T.to_csv('/tmp/outputs/derived_data/invivo_tumour_volume_endpoints_digitized.csv', index=False)
titles = {'A':'MGAT1 KO: STK11-WT vs sgSTK11 MC38\n(p1; separate cohorts)','B':'sgSTK11 MC38, MGAT1 KO x anti-PD-1 (p1, d9)\nBliss-additive expectation shown','C':'Catalytic-dead rescue in vivo (p7)','D':'NY-ESO TCR adoptive transfer (p4, d19)','E':'Model check: STK11 loss abolishes immune\ncontrol, blunts anti-PD-1 (p8)'}
fig, axes = plt.subplots(1,5, figsize=(22,5.6))
for ax,(p,sub) in zip(axes, T.groupby('panel')):
    x = np.arange(len(sub))
    red = {'MC38 WT sgMGAT1 (d25)','MC38 sgSTK11 sgMGAT1 (d19)','sgMGAT1 + IgG2a','sgMGAT1 + anti-PD-1','sgSTK11+sgMGAT1: D211A/D289A (d19)','control T: sgMGAT1','NY-ESO T 1e6: sgMGAT1','NY-ESO T 2e6: sgMGAT1'}
    col = ['#c0392b' if a in red else '#555555' for a in sub.arm]
    yerr = np.array([sub.mean_mm3-sub.errbar_low.fillna(sub.mean_mm3), sub.errbar_high.fillna(sub.mean_mm3)-sub.mean_mm3])
    ax.bar(x, sub.mean_mm3, color=col, alpha=0.8)
    ax.errorbar(x, sub.mean_mm3, yerr=yerr, fmt='none', ecolor='k', capsize=3, lw=0.8)
    ax.set_xticks(x); ax.set_xticklabels(sub.arm, rotation=55, ha='right', fontsize=7.5)
    ax.set_title(titles[p], fontsize=9); ax.set_ylabel('tumour volume (mm3), digitized')
    if p=='B':
        bliss = 1145*(763/1145)*(621/1145)
        ax.axhline(bliss, ls='--', color='#1f77b4', lw=1); ax.text(1.6,1500,f'dashed = Bliss-additive\nexpectation {bliss:.0f} mm3\n(observed 395)',fontsize=7.5,color='#1f77b4')
fig.suptitle('Red = MGAT1 function absent. Client in vivo data, endpoints digitized from phenotype_figures.pdf (error-bar type and n not stated by client; values +/-~5%)', fontsize=10)
plt.tight_layout(rect=[0,0,1,0.95])
plt.savefig('/tmp/outputs/figures/Fig4_invivo_endpoints_digitized.png', dpi=150)
print('Bliss expected', 1145*(763/1145)*(621/1145))
