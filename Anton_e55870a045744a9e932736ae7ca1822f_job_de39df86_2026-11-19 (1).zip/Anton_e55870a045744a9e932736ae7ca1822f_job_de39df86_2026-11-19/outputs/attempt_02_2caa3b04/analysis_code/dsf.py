from PIL import Image
import numpy as np
im = np.array(Image.open('/tmp/work/img/assay_figures_p4.png').convert('RGB')).astype(int)
H,W,_ = im.shape
# derivative panel approx rows 590-970; x axis labels row ~985: find x positions of tick labels "20" and "100"
# locate gridlines: vertical light-grey lines in derivative panel
sub = im[600:960, 140:1100]
# define colors
cols = {'DMSO(magenta)':(175,75,160),'UDP(yellow)':(245,220,100),'C3744(green)':(90,145,65),'C3744+UDP(blue)':(90,100,175)}
# find gridline x positions: columns where many pixels are light grey (~220-235)
g = sub.mean(axis=2)
grey = (g>200)&(g<240)&(np.abs(sub[:,:,0]-sub[:,:,2])<10)
colscore = grey.sum(axis=0)
cand = np.where(colscore>150)[0]
groups=[]
for c in cand:
    if groups and c-groups[-1][-1]<=2: groups[-1].append(c)
    else: groups.append([c])
gl = [np.mean(x)+140 for x in groups]
print('vertical gridlines x:', [round(v) for v in gl])
for name,rgb in cols.items():
    d = np.sqrt(((sub-np.array(rgb))**2).sum(axis=2))
    m = d<45
    ys,xs = np.where(m)
    if len(ys)==0: print(name,'none'); continue
    # peak = min y (highest point) among matched pixels
    top = ys.min()
    xs_top = xs[ys<=top+3]
    print(name, 'n px', m.sum(), 'peak x ~', round(np.median(xs_top)+140,1), 'peak y', top+600)
