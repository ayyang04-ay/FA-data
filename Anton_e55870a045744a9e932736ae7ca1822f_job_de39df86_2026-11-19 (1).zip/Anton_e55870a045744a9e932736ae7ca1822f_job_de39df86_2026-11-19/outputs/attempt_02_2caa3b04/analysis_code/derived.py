import numpy as np
from scipy import stats
# CIs from t stats (approx normal/t with df from model)
beta, t, df = -1.7565, -4.0553, 140-4
se = beta/t; print('interaction beta %.2f SE %.2f 95%% CI %.2f to %.2f' % (beta, se, beta-stats.t.ppf(0.975,df)*se, beta+stats.t.ppf(0.975,df)*se))
d, t2 = -1.39, -5.01
se2 = d/t2; print('STK11 B6 vs nude %.2f SE %.2f approx 95%% CI %.2f to %.2f' % (d, se2, d-2.0*se2, d+2.0*se2))
# LE / LipE
for name, ic50, logd, ha in [('ANT-3744',0.814e-6,2.2,31),('ANT-4267',0.043e-6,2.6,478/ (419.48/31))]:
    p = -np.log10(ic50); print(name, 'pIC50 %.2f HA %.1f LE %.3f LipE %.2f' % (p, ha, 1.37*p/ha, p-logd))
print('ANT-3744 LE on Kd 0.38: %.3f' % (1.37*(-np.log10(0.38e-6))/31))
print('potency gain hit->3744 %.0f, hit->4267 %.0f' % (197/0.814, 197/0.043))
print('solubility/IC50: 0592 %.3f (IC50 %.1fx above sol), 3744 %.0f, 4267 %.0f' % (11.8/197, 197/11.8, 178/0.814, 96.4/0.043))
print('cells per guide %.1f' % (1e5/3580))
# anti-PD-1 effect sizes p8
print('p8 aPD1 effect NTC %.0f%%, STK11 %.0f%%' % ((1-95/382)*100, (1-643/1264)*100))
print('p1 right: aPD1 in NTC %.0f%%, in sgMGAT1 %.0f%%, MGAT1 KO under IgG %.0f%%, under aPD1 %.0f%%, combo vs NTC IgG %.0f%%' % ((1-763/1145)*100,(1-395/621)*100,(1-621/1145)*100,(1-395/763)*100,(1-395/1145)*100))
print('p4: %.0f%%, %.0f%%, %.0f%%' % ((1-1646/1930)*100,(1-616/1299)*100,(1-181/601)*100))
print('p7 right: %.0f%%; p7 left: %.0f%%' % ((1-422/862)*100,(1-790/895)*100))
print('p1: WT %+.0f%%, sgSTK11 %+.0f%%' % ((1774/1163-1)*100,(542/1087-1)*100))
