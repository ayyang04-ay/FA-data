import pandas as pd, numpy as np
q = pd.read_csv('/tmp/work/invivo_sample_qc.csv', index_col=0)
pd.set_option('display.width',200)
print(q[(q.detected_frac<0.92)|(q.gini>0.8)].round(3))
df = pd.read_csv('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz')
S = df.columns[3:]
X = df[S].astype(float)
lx = np.log2(X.div(X.sum())*1e6+1)
C = lx.corr()
ctrl = [c for c in S if c.split('_')[0] in ('Plasmid','Baseline','Endpoint')]
print(C.loc[ctrl,ctrl].round(3).to_string())
