import numpy as np
from PIL import Image
from scipy import ndimage
def load(path): return np.array(Image.open(path).convert('RGB')).astype(int)
def cal(ticks):
    r = np.array([t[0] for t in ticks],float); v = np.array([t[1] for t in ticks],float); return np.polyfit(r, v, 1)
def markers(im, box, rgb, tol, rad=3, minarea=60, merge=14, maxdim=60):
    x0,y0,x1,y1 = box; sub = im[y0:y1,x0:x1]
    d = np.sqrt(((sub-np.array(rgb))**2).sum(axis=2)); m = d<tol
    if rad>0:
        yy,xx = np.mgrid[-rad:rad+1,-rad:rad+1]; disk=(xx**2+yy**2)<=rad*rad
        m = ndimage.binary_opening(m, structure=disk)
    lab,n = ndimage.label(m); blobs=[]
    for i,sl in enumerate(ndimage.find_objects(lab)):
        area=(lab[sl]==i+1).sum(); h=sl[0].stop-sl[0].start; w=sl[1].stop-sl[1].start
        if area>=minarea//4 and h<=maxdim and w<=maxdim:
            ys,xs = np.where(lab[sl]==i+1)
            blobs.append([xs.mean()+sl[1].start+x0, ys.mean()+sl[0].start+y0, area])
    # merge nearby blobs (weighted)
    merged=[]
    for b in sorted(blobs):
        for mb in merged:
            if abs(mb[0]-b[0])<merge and abs(mb[1]-b[1])<merge:
                a=mb[2]+b[2]; mb[0]=(mb[0]*mb[2]+b[0]*b[2])/a; mb[1]=(mb[1]*mb[2]+b[1]*b[2])/a; mb[2]=a; break
        else: merged.append(list(b))
    return sorted([m for m in merged if m[2]>=minarea])
