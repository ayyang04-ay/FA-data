import sys; sys.path.insert(0,'/tmp/work/py')
import pandas as pd
df = pd.read_csv('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz', usecols=['gene_symbol'])
genes=set(df.gene_symbol)
for g in ['Slc35a1','Cmas','Gale','Gfpt1','Slc35a2','Ugp2','Uap1','Gne','Nans','Dad1','Mogs','Alg5','Alg10b','Mgat1','Mgat2','Mgat5','Man2a1','B4galt1','St3gal4','Fut8','Pgm3','Gnpnat1','Stt3a','Stt3b','Cflar','Ptpn2']:
    print(g, g in genes, end='; ')
print()
t = pd.read_csv('/tmp/outputs/derived_data/invivo_screen_gene_scores_by_group.csv', index_col=0)
sub = t.loc[[g for g in ['Mgat1','Mgat2','B4galt1','Alg5','Alg10b','Dad1','Mogs','Stt3a','Stt3b','Gfpt1','Uap1'] if g in t.index]]
print(sub.round(2).to_string())
