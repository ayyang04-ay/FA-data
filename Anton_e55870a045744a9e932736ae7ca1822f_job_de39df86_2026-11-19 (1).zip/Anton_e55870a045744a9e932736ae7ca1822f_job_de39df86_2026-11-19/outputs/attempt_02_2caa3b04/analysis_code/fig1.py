import sys; sys.path.insert(0,'/tmp/work/py')
from inv_core import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
df, S, X, cpm, grp, bg, L, Lc, nt = load()
genes = df.gene_symbol.values
tum = [c for c in S if c.startswith('Group')]
G = Lc.groupby(genes).mean()
host = {'Group1_NTC':'nude-like\n(G1)','Group5_STK11':'nude-like\n(G5)','Group2_NTC':'B6 IgG-like\n(G2)','Group6_STK11':'B6 IgG-like\n(G6)',
        'Group3_NTC':'B6 aPD-1-like\n(G3+G4)','Group4_NTC':'B6 aPD-1-like\n(G3+G4)','Group7_STK11':'B6 aPD-1-like\n(G7+G8)','Group8_STK11':'B6 aPD-1-like\n(G7+G8)'}
fig, axes = plt.subplots(1,4, figsize=(17,4.6), sharey=False)
rng = np.random.default_rng(0)
for ax, gene in zip(axes, ['Mgat1','Cd274','Ptpn2','Jak1']):
    pos=0; ticks=[]; labs=[]
    for b, grps, col in [('NTC',['Group1_NTC','Group2_NTC',('Group3_NTC','Group4_NTC')],'#7f7f7f'),('STK11',['Group5_STK11','Group6_STK11',('Group7_STK11','Group8_STK11')],'#c0392b')]:
        for gset in grps:
            gset = gset if isinstance(gset, tuple) else (gset,)
            cols = [c for c in tum if grp[c] in gset]
            v = G.loc[gene, cols].values
            ax.scatter(pos + rng.uniform(-0.18,0.18,len(v)), v, s=10, color=col, alpha=0.6)
            ax.errorbar(pos, v.mean(), yerr=v.std(ddof=1)/np.sqrt(len(v)), fmt='o', color='k', ms=6, capsize=4, zorder=5)
            ticks.append(pos); labs.append(f"{b}\n{host[gset[0]]}\nn={len(v)}")
            pos+=1
        pos+=0.6
    ax.axhline(0, color='k', lw=0.6, ls=':')
    ax.set_xticks(ticks); ax.set_xticklabels(labs, fontsize=6.5)
    ax.set_title(gene + (' (target)' if gene=='Mgat1' else ' (internal control)'), fontsize=11)
    ax.set_ylabel('gene score: mean guide log2FC vs matched baseline\n(centred on non-targeting guides)' if gene=='Mgat1' else '')
fig.suptitle('In vivo pooled screen (crispr_invivo_guide_counts.csv.gz): per-tumour gene scores by background and INFERRED arm (arm key not provided by client)', fontsize=10)
plt.tight_layout(rect=[0,0,1,0.94])
plt.savefig('/tmp/outputs/figures/Fig1_invivo_screen_Mgat1_and_arm_controls.png', dpi=160)
# derived data: per-gene contrasts
allres = pd.read_pickle('/tmp/work/inv_contrasts.pkl')
out = pd.concat({k: v[['delta','t','p_welch','p_emp','rank_delta']] for k,v in allres.items()}, axis=1)
out.to_csv('/tmp/outputs/derived_data/invivo_screen_gene_contrasts.csv')
# per-group means
tab = pd.DataFrame({g: G[[c for c in S if grp[c]==g]].mean(axis=1) for g in sorted(set(grp))})
tab = tab[~tab.index.str.startswith('BRDN')]
tab.to_csv('/tmp/outputs/derived_data/invivo_screen_gene_scores_by_group.csv')
print('ok')
