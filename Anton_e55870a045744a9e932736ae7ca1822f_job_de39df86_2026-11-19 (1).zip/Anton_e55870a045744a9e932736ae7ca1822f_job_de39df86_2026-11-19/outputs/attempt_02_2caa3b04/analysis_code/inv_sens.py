import sys; sys.path.insert(0,'/tmp/work/py')
import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
from scipy import stats
import statsmodels.formula.api as smf
df = pd.read_csv('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz')
q = pd.read_csv('/tmp/work/invivo_sample_qc.csv', index_col=0)
host = {'Group1_NTC':'nude','Group5_STK11':'nude','Group2_NTC':'B6_IgG','Group6_STK11':'B6_IgG','Group3_NTC':'B6_aPD1','Group4_NTC':'B6_aPD1','Group7_STK11':'B6_aPD1','Group8_STK11':'B6_aPD1'}
nt = df.gene_symbol.str.startswith('BRDN').values
def run(pseudo=1.0, agg='mean', min_det=0.0, drop_guide3=False):
    S = [c for c in df.columns[3:] if q.loc[c,'total']>1000 and (not c.startswith('Group') or q.loc[c,'detected_frac']>=min_det)]
    X = df[S].astype(float); cpm = X.div(X.sum())*1e6
    bg = {c:('STK11' if 'STK11' in c else 'NTC') for c in S}
    base = {b: cpm[[c for c in S if c.startswith('Baseline_'+b)]].mean(axis=1) for b in ['NTC','STK11']}
    tum = [c for c in S if c.startswith('Group')]
    L = pd.DataFrame({c: np.log2((cpm[c]+pseudo)/(base[bg[c]]+pseudo)) for c in tum})
    L = L - L[nt].median()
    rows = df.gene_symbol=='Mgat1'
    if drop_guide3: rows &= df.gene_sgrna_id!='Mgat1_3'
    v = L[rows.values].mean() if agg=='mean' else L[rows.values].median()
    meta = pd.DataFrame({'y':v.values,'stk':[int(bg[c]=='STK11') for c in tum],'imm':[int(host[c.rsplit('_',1)[0]]!='nude') for c in tum],
                         'apd1':[int(host[c.rsplit('_',1)[0]]=='B6_aPD1') for c in tum]})
    m = smf.ols('y ~ stk*imm', data=meta).fit()
    s = meta[meta.stk==1]; n_ = meta[meta.stk==0]
    d_stk = s[s.imm==1].y.mean()-s[s.imm==0].y.mean(); p_stk = stats.ttest_ind(s[s.imm==1].y, s[s.imm==0].y, equal_var=False).pvalue
    d_ntc = n_[n_.imm==1].y.mean()-n_[n_.imm==0].y.mean(); p_ntc = stats.ttest_ind(n_[n_.imm==1].y, n_[n_.imm==0].y, equal_var=False).pvalue
    sb6 = s[s.imm==1]; d_pd1 = sb6[sb6.apd1==1].y.mean()-sb6[sb6.apd1==0].y.mean(); p_pd1 = stats.ttest_ind(sb6[sb6.apd1==1].y, sb6[sb6.apd1==0].y, equal_var=False).pvalue
    return len(tum), d_stk, p_stk, d_ntc, p_ntc, m.params['stk:imm'], m.pvalues['stk:imm'], d_pd1, p_pd1
print('setting | n tumours | STK11: B6-nude (p) | NTC: B6-nude (p) | interaction (p) | STK11 aPD1-IgG (p)')
for label, kw in [('base (pc=1, mean, all QC-pass)',{}),('pseudocount 0.5',dict(pseudo=0.5)),('pseudocount 5',dict(pseudo=5)),
                  ('median of guides',dict(agg='median')),('exclude tumours detected<0.9',dict(min_det=0.9)),('drop inactive guide Mgat1_3',dict(drop_guide3=True))]:
    r = run(**kw)
    print(f'{label:34s} | {r[0]} | {r[1]:.2f} ({r[2]:.1g}) | {r[3]:.2f} ({r[4]:.2g}) | {r[5]:.2f} ({r[6]:.1g}) | {r[7]:.2f} ({r[8]:.2g})')
