import sys; sys.path.insert(0,'/tmp/work/py')
from inv_core import *
import statsmodels.formula.api as smf
from scipy import stats
df, S, X, cpm, grp, bg, L, Lc, nt = load()
genes = df.gene_symbol.values
tum = [c for c in S if c.startswith('Group')]
G = Lc.groupby(genes).mean()
host = {'Group1_NTC':'nude','Group5_STK11':'nude','Group2_NTC':'B6_IgG','Group6_STK11':'B6_IgG','Group3_NTC':'B6_aPD1','Group4_NTC':'B6_aPD1','Group7_STK11':'B6_aPD1','Group8_STK11':'B6_aPD1'}
meta = pd.DataFrame({'sample':tum, 'bg':[bg[c] for c in tum], 'host':[host[grp[c]] for c in tum]})
meta['immune'] = (meta.host!='nude').astype(int); meta['stk'] = (meta.bg=='STK11').astype(int)
def inter_t(vals):
    d = meta.copy(); d['y'] = vals
    m = smf.ols('y ~ stk*immune', data=d).fit()
    return m.params['stk:immune'], m.tvalues['stk:immune'], m.pvalues['stk:immune']
res = {}
for g_ in G.index:
    if g_.startswith('BRDN'): continue
    res[g_] = inter_t(G.loc[g_, tum].values)
R = pd.DataFrame(res, index=['beta','t','p']).T
# null from NT pseudo-genes
rng = np.random.default_rng(2); ntidx = np.where(nt)[0]
null_t = []
for i in range(1000):
    v = Lc.iloc[rng.choice(ntidx,4,replace=False)][tum].mean().values
    null_t.append(inter_t(v)[1])
null_t = np.array(null_t)
R['p_emp'] = [(np.sum(np.abs(null_t)>=abs(t))+1)/(len(null_t)+1) for t in R.t]
R = R.sort_values('t')
print('Mgat1 interaction (STK11 x immune-competent host):', R.loc['Mgat1'].round(4).to_dict(), 'rank', list(R.index).index('Mgat1')+1, '/', len(R))
print('Top 15 genes with most negative STK11-specific immune-dependent effect:')
print(R.head(15).round(4).to_string())
# simple means table
for g_ in ['Mgat1','B4galt1','Mgat2','Cd274','Ptpn2','Jak1','B2m']:
    v = G.loc[g_, tum]
    t = meta.assign(y=v.values).groupby(['bg','host']).y.agg(['mean','sem','count'])
    print(g_); print(t.round(2).T.to_string())
