import gemmi, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
exec(open('/tmp/work/py/xtal3.py').read().split("for ch in ['A','B']:")[0])
st = S['C3744_UDP']; ch='A'
ca = []; nums=[]
for r in st[0][ch]:
    if r.het_flag!='H' and r.find_atom('CA','*'):
        ca.append(np.array(r.find_atom('CA','*').pos.tolist())); nums.append(r.seqid.num)
ca=np.array(ca); nums=np.array(nums)
c37 = np.array(list(lig_coords(st,ch,'C3744').values())); udp=np.array(list(lig_coords(st,ch,'UDP').values()))
R,Pc,Qc,rmsd,common,_,_ = superpose(S['UDP_GlcNAc'], st, ch)
ud1 = lig_coords(S['UDP_GlcNAc'], ch, 'UD1'); glc = np.array([ (ud1[k]-Pc)@R.T+Qc for k in ud1 if k.endswith("'") and not k.startswith('O2')])
c1 = (ud1["C1'"]-Pc)@R.T+Qc
# frame: x along udp->c37 centroid; y = PCA of CA residual
x = c37.mean(0)-udp.mean(0); x/=np.linalg.norm(x)
cen = ca.mean(0); Xc = ca-cen; Xc_perp = Xc - np.outer(Xc@x, x)
u,s,vt = np.linalg.svd(Xc_perp, full_matrices=False); y = vt[0]; y -= (y@x)*x; y/=np.linalg.norm(y)
P = lambda A: np.c_[(A-cen)@x, (A-cen)@y]
fig, ax = plt.subplots(figsize=(9,6.5))
p = P(ca)
ax.plot(p[:,0], p[:,1], color='#bbbbbb', lw=1, zorder=1)
sel = (nums>=435)&(nums<=445)
ax.plot(p[sel,0], p[sel,1], color='#e67e22', lw=3, zorder=2, label='C-terminal segment 435-445 (moves up to ~4.5 A on ANT-3744 binding)')
site = [388,389,390,394,410,412,434,437,438,439,440,441,444]
for n in site:
    i = np.where(nums==n)[0]
    if len(i): ax.scatter(*p[i[0]], s=18, color='#d35400', zorder=3)
pc, pu, pg = P(c37), P(udp), P(glc)
ax.scatter(pc[:,0],pc[:,1], s=22, color='#c0392b', zorder=4, label='ANT-3744 (C3744), ternary complex')
ax.scatter(pu[:,0],pu[:,1], s=22, color='#2c3e50', zorder=4, label='UDP (donor site), ternary complex')
ax.scatter(pg[:,0],pg[:,1], s=18, color='#27ae60', zorder=4, label='GlcNAc of UDP-GlcNAc (superposed)')
for n,lab in [(289,'D289 (catalytic base)'),(211,'D211 (DXD, Mn)')]:
    i = np.where(nums==n)[0][0]; ax.scatter(*p[i], s=60, marker='*', color='k', zorder=5); ax.annotate(lab, p[i], xytext=(6,-12), textcoords='offset points', fontsize=8)
pc1 = P(c1[None])[0]
d1 = np.min(np.linalg.norm(c37-c1,axis=1)); d2 = np.min(np.linalg.norm(c37[:,None]-udp[None],axis=2))
ic = np.argmin(np.linalg.norm(c37-c1,axis=1)); pclose = P(c37[ic][None])[0]
ax.annotate('', xy=pclose, xytext=pc1, arrowprops=dict(arrowstyle='<->', color='#8e44ad', lw=1.2))
ax.text(*( (pclose+pc1)/2 + np.array([0,-4.5])), f'{d1:.1f} A: GlcNAc C1\' (transfer centre)\nto closest ANT-3744 atom', color='#8e44ad', fontsize=8, ha='center')
ax.set_aspect('equal'); ax.set_xlabel('A (projection along donor-site -> ANT-3744 axis)'); ax.set_ylabel('A')
ax.set_title('MGAT1_C3744_UDP.cif chain A (2.01 A; Rfree 0.203): ANT-3744 binds a C-terminal pocket\n~22 A from the sugar-transfer centre and ~24 A from UDP; non-competitive with donor', fontsize=9.5)
ax.legend(fontsize=7, loc='lower left')
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/Fig5_structure_binding_site_schematic.png', dpi=160)
print(d1, d2)
