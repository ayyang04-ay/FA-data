import pandas as pd, numpy as np, re
x = pd.ExcelFile('/tmp/world/filesystem/glycoproteomics_site_quant.xlsx')
igp = x.parse('IGP_quant')
ch = ['AM_N1','AM_N2','AM_N3','AM_N4','AM_KO1','AM_KO2','AM_KO3','AM_KO4','NH_N1','NH_N2','NH_N3','NH_N4','NH_M_KO1','NH_M_KO2','NH_M_KO3','NH_M_KO4']
I = igp[['Intensity '+c for c in ch]].copy(); I.columns = ch
def comp(s):
    d = dict(re.findall(r'(HexNAc|Hex|Fuc|NeuAc|NeuGc|Phospho|Sulfo)\((\d+)\)', s))
    return {k:int(v) for k,v in d.items()}
C = igp['Observed Modification'].apply(comp).apply(pd.Series).fillna(0).astype(int)
igp = pd.concat([igp, C], axis=1)
def cls(r):
    hn, h, f, na = r.get('HexNAc',0), r.get('Hex',0), r.get('Fuc',0), r.get('NeuAc',0)
    if hn<=2 and f==0 and na==0 and h>=5: return 'Oligomannose (Man5-9)'
    if hn<=2 and f==0 and na==0: return 'Paucimannose/truncated (no Fuc)'
    if hn<=2 and (f>0 or na>0): return 'HexNAc<=2 + Fuc/NeuAc (MGAT1-dependent)'
    if hn==3 and h>=5: return 'Hybrid-type (HexNAc3Hex>=5)'
    return 'Complex-type (HexNAc>=3)'
igp['class'] = igp.apply(cls, axis=1)
igp['dep'] = ~igp['class'].isin(['Oligomannose (Man5-9)','Paucimannose/truncated (no Fuc)'])
print(igp['class'].value_counts())
tot = I.sum()
frac = I.groupby(igp['class']).sum().div(tot)
pd.set_option('display.width',250)
print('\nFraction of total glycopeptide reporter intensity per class, per channel:')
print((frac*100).round(1).to_string())
depfrac = I[igp.dep].sum()/tot
print('\nMGAT1-dependent fraction per channel (%):'); print((depfrac*100).round(1).to_string())
# Man5 specifically
man5 = (igp.HexNAc==2)&(igp.Hex==5)&(igp.get('Fuc',0)==0)&(igp.get('NeuAc',0)==0)
print('\nMan5 fraction (%):'); print((I[man5].sum()/tot*100).round(1).to_string())
# per glycopeptide log2 KO/NT by cell line
for cl,nt,ko in [('A375',['AM_N1','AM_N2','AM_N3','AM_N4'],['AM_KO1','AM_KO2','AM_KO3','AM_KO4']),('H1703',['NH_N1','NH_N2','NH_N3','NH_N4'],['NH_M_KO1','NH_M_KO2','NH_M_KO3','NH_M_KO4'])]:
    lr = np.log2((I[ko].mean(axis=1)+1)/(I[nt].mean(axis=1)+1))
    print('\n',cl,'median log2(KO/NT) by class:'); print(lr.groupby(igp['class']).describe()[['count','25%','50%','75%']].round(2).to_string())
igp.to_pickle('/tmp/work/gp_igp.pkl')
