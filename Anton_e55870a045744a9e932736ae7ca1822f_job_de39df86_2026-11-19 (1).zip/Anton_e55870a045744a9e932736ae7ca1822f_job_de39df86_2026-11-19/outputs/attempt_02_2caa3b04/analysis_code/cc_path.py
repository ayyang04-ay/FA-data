import pandas as pd, numpy as np
gs = pd.read_csv('/tmp/work/cc_gene_scores.csv', index_col=0)
N = len(gs)
path = {'Hexosamine / UDP-GlcNAc supply':['GFPT1','GNPNAT1','PGM3','UAP1'],
        'UDP-Gal supply / transport':['UGP2','GALE','GALK1','GALT','SLC35A2'],
        'CMP-Sia supply / transport':['GNE','NANS','CMAS','SLC35A1'],
        'N-glycan precursor / OST / ER trimming':['ALG5','ALG10B','DPAGT1','STT3A','STT3B','DAD1','MOGS','GANAB'],
        'Golgi N-glycan branching':['MAN1A1','MAN1A2','MAN1C1','MGAT1','MAN2A1','MAN2A2','MGAT2','MGAT4A','MGAT4B','MGAT5','MGAT3'],
        'Galactosylation / sialylation / fucosylation':['B4GALT1','B4GALT3','ST3GAL4','ST6GAL1','FUT8'],
        'Benchmarks (non-glycan)':['PTPN2','CFLAR','B2M','JAK1','IFNGR1','CTAG1B']}
rows=[]
for p,gl in path.items():
    for g in gl:
        if g in gs.index:
            r = gs.loc[g]; rows.append((p,g,round(r.mean_lfc,2),int(r.n_neg),int(r.n),int(r.rank_dep)))
        else: rows.append((p,g,np.nan,np.nan,np.nan,np.nan))
T = pd.DataFrame(rows, columns=['pathway','gene','mean guide log2FC (T-cell vs tumour-only)','guides < -0.3','guides','rank (most depleted=1) of %d'%N])
pd.set_option('display.width',200)
print(T.to_string(index=False))
T.to_csv('/tmp/work/cc_pathway_table.csv', index=False)
