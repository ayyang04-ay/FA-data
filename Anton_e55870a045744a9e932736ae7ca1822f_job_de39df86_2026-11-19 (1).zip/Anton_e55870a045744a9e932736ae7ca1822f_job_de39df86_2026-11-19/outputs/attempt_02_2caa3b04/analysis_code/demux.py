import pandas as pd, numpy as np
dm = pd.read_csv('/tmp/world/filesystem/crispr_invivo_ngs_demux.csv.gz')
inv = pd.read_csv('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz', nrows=2)
samples = list(inv.columns[3:])
print('demux rows', len(dm), 'unique sample names', dm.sample_name.nunique(), 'runs', dm.ngs_sample_id.nunique())
print('matrix samples', len(samples))
s_dm = set(dm.sample_name); s_m = set(samples)
print('in matrix not in demux:', sorted(s_m - s_dm))
print('in demux not in matrix:', sorted(s_dm - s_m))
dup = dm[dm.sample_name.duplicated(keep=False)]
print('dup sample names in demux:\n', dup)
# barcode collisions within a run
coll = dm.groupby(['ngs_sample_id','first_10nt_id']).sample_name.apply(list)
print('collisions within run:\n', coll[coll.apply(len)>1])
# per run composition
dm['bg'] = dm.sample_name.str.extract(r'_(NTC|STK11)_')[0]
dm['type'] = dm.sample_name.str.extract(r'^(Group\d|Baseline|Endpoint|Plasmid)')[0]
print(pd.crosstab(dm.ngs_sample_id.str[:8], dm.bg.fillna('none')))
print(pd.crosstab(dm.ngs_sample_id.str[:8], dm.type))
print(dm.first_10nt_id.value_counts())
