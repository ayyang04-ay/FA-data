---
title: "Antera MGAT1 programme: independent verification and recommendation"
subtitle: "Small-molecule MGAT1 inhibitors (ANT-3744 / ANT-4267) for checkpoint-inhibitor-resistant, STK11-mutant NSCLC"
date: "Data cut: 1 November 2026. Basis: client-supplied files only."
---

# 1. Recommendation

**Do not advance ANT-4267 (or the ANT-3744 series) to development-candidate nomination or IND-enabling work.** Hold the asset at the lead stage. Fund one gated proof-of-pharmacology package whose first question is whether the compound reproduces the MGAT1 knockout in cells. If it doesn't, stop the series.

This is a "not yet", not a "no":

* **The target hypothesis is the strongest part of the package, and it is entirely genetic.** Tumour-cell loss of MGAT1 catalytic activity makes cancer cells more vulnerable to antigen-specific CD8 T cells. Five independent lines of the client's own data support this (Section 3).
* **The molecule has never been tested in a cell-based pharmacology assay or in an animal.** Every efficacy number in the package comes from complete genetic loss, in tumour cells only. No experiment shows that the compound engages MGAT1 in cells, reproduces the knockout's glycan or killing phenotype, or reaches tumour at useful exposure.
* **The compound's in-vitro profile is the kind most likely to fail to reproduce a knockout.** It is a partial inhibitor that plateaus at about 9% residual activity (roughly 91% maximum inhibition). It binds an allosteric pocket 22 Å from the sugar-transfer centre, and it does not compete with the donor substrate. Its potency was measured only against a small surrogate acceptor sugar.
* **The indication thesis is only partly supported:**
  * STK11 selectivity appears only in mouse MC38. It was never tested in human cells.
  * MGAT1 loss does not re-sensitise tumours to anti-PD-1. Its effect is independent of PD-1 and simply adds to anti-PD-1's effect.
  * Several documentation gaps undermine confidence in key datasets (Section 8).

**What brings it back:** four gates, each with explicit comparisons and go/no-go criteria (Sections 5–6). In short:

1. The compound gives a knockout-like glycan phenotype in cells, and the effect is on-target.
2. It reproduces the knockout's T-cell-killing phenotype without impairing T cells.
3. (Only if the STK11 positioning is kept) the effect is STK11-selective in human isogenic cells.
4. Tolerated exposure gives knockout-like tumour pharmacodynamics and T-cell-dependent efficacy in vivo, at least additive with anti-PD-1.

# 2. Scorecard: claims vs. evidence

| Programme claim | Verdict from client data | Key numbers (evidence ID) |
|---|---|---|
| Tumour MGAT1 loss sensitises to CD8 T-cell killing | **Supported (genetic)** | Genome-wide rank 16/18,860 (E1, E2); 4/4 guides in 2 lines (E5); dose-dependent in vivo (E9) |
| MGAT1 *catalytic* activity is what protects tumours | **Supported; one gap** | WT cDNA rescues, D289A and D211A/D289A do not, in vitro (E7) and in vivo (E17). No enzymology for the mutants is provided |
| Effect is STK11-selective | **Mouse-only; untested in human** | Screen interaction −1.76 log2 (E11); human lines' STK11 status not documented |
| MGAT1 loss restores anti-PD-1 response | **Not supported** | No anti-PD-1 × Mgat1 effect in the screen (E11). Single-gene study is additive: observed 395 vs 414 mm³ expected if additive (E16) |
| Compounds bind and inhibit MGAT1 on-target | **Supported (biochemical)** | IC50 tracks SPR KD (r = 0.96) (E22); co-crystal structures (E26) |
| Compound inhibits as completely as a KO | **Unresolved; risk** | ~9% residual-activity floor (E21); allosteric, non-competitive with UDP (E23–E26) |
| Compound works in cells / in vivo | **No data** | None: no lectin, co-culture, PK or efficacy data for any compound |
| Properties adequate to test the hypothesis | **Yes** | ANT-4267: IC50 43 nM, solubility 96 µM, hepatocyte CLint <1.35 µl/min/10^6 cells (E19, E20) |

Each E-number is a row in `evidence_register.xlsx/.csv` giving the source file, location and derivation.

# 3. What the data support (the case for the target)

**3.1 An unbiased, well-controlled human screen nominates MGAT1.**

* In the genome-wide NCI-H1703 × NY-ESO-1 TCR T-cell screen, MGAT1 ranks 16 of 18,860 genes for depletion in the T-cell arm. The mean guide log2 fold-change is −0.82, all four guides are negative, and z = −8.2 against a non-targeting null (E1).
* The result holds at the level of individual UMI lineages: median −1.0, p = 1e-8 (E2).
* The screen behaves as a valid T-cell screen:
  * The top resistance hit is the antigen itself (CTAG1B/NY-ESO-1, rank 1).
  * B2M and the IFN-γ pathway (IFNGR1/2, JAK1/2, STAT1, IRF1) and TAP1/2 also score as resistance hits.
  * PTPN2 and CFLAR are top sensitisers (E3).

**3.2 Independent validation is consistent.**

* Four separate MGAT1 guides, none of them from the library (E33), reduce tumour-cell viability after T-cell co-culture in two lines:
  * NCI-H1703: 0.24–0.54 vs 0.86–0.92 for non-targeting (NTC).
  * NCI-H1755: 0.17–0.48 vs 0.79 for NTC.
  * B2M knockout gives resistance (1.84–1.96) (E5).
* MGAT1 loss removes about 96–97% of PHA-L staining and increases GNA 8–9-fold (E6). In glycoproteomics, Man5 glycans double in both lines (E28).
* The T cells' killing is antigen-specific. Antigen-negative HEK293 and A549 are spared (1.09–1.16) while both NY-ESO⁺ lines are killed (0.07–0.12) (E8).

**3.3 Catalytic activity is required.** Re-expressing wild-type MGAT1 restores PHA-L staining and T-cell resistance: viability 1.14–1.15 vs 0.71–0.72 for empty vector. Catalytic mutants (D289A; D211A/D289A) restore neither (0.53–0.58) (E7). In vivo, sgSTK11/sgMGAT1 MC38 tumours grow 51% less with the catalytic-dead mutant than with wild-type MGAT1 (422 vs 862 mm³, error bars separated) (E17). Together this supports the premise that inhibiting the enzyme could reproduce the knockout.

**3.4 The effect is T-cell dependent and dose-dependent in vivo.** With control T cells, MGAT1 loss barely changes growth (−15%). With NY-ESO TCR T cells it reduces day-19 tumour volume by 53% at 1e6 cells and 70% at 2e6 cells (E9).

**3.5 In mouse, the dependency appears specific to the STK11-null context.** I re-analysed the in vivo pooled screen; the client did not supply the arm key, so I inferred arms from internal controls (E14).

* **Where it holds:**
  * Mgat1 knockout is neutral in vitro: +0.19 and −0.29 log2 (E10).
  * In STK11-null tumours, the knockout is depleted much more in immunocompetent-like arms (−3.5) than in the nude-like arm (−2.1). The difference is −1.39 log2 (p = 2e-5), and Mgat1 ranks 8th of 795 genes (E11, E13).
  * There is no such immune-dependent effect in the STK11-WT background: +0.37, not significant.
  * The background × host interaction is −1.76 log2 (95% CI −2.6 to −0.9).
  * The result holds for 3 of 4 guides and across every analysis variant I tried (E12).
* **Consistent single-gene data:** MGAT1 loss halves sgSTK11 MC38 growth (1,087 → 542 mm³) but not STK11-WT MC38 (1,163 → 1,774 mm³) (E15).

**3.6 The chemistry is tractable and on-target biochemically.**

* Potency improved about 4,600-fold, from the hit (197 µM) to ANT-4267 (43 nM) (E19, E20).
* Inhibition tracks binding across the plotted series: about 28 compounds, of which 16 points could be read reliably; log-log r = 0.96, median IC50/KD 1.7 (E22). That argues against assay interference.
* Co-crystal structures at 2.0 Å (R-free ≈ 0.20–0.21) show the same pose in two crystals grown under different conditions (binary and ternary complexes; four protein copies in total) (E26).
* Properties are a reasonable starting point for cell and in vivo work:
  * ANT-4267: LE ≈ 0.29, LipE ≈ 4.8, kinetic solubility 96 µM, hepatocyte CLint below quantification.
  * ANT-3744: solubility 178 µM, CLint 3.2 (E19, E20).

# 4. Why the asset is not ready to advance (the case against advancing now)

**4.1 There is no compound pharmacology in cells or animals.** The package has no:

* cellular target engagement (e.g., PHA-L/GNA shift with compound);
* compound co-culture;
* permeability or plasma protein binding;
* PK;
* in vivo pharmacodynamics or efficacy.

The only cell exposure is hepatocyte metabolic stability. MGAT1 is membrane-anchored (the assay constructs delete its N-terminal transmembrane helix). Biochemical potency on a soluble construct therefore does not show the compound reaches the enzyme where glycans are made.

**4.2 The mechanism is a poor fit to the "reproduce the knockout" requirement.**

* **Partial maximal effect.** The four most potent synthesised compounds (ANT-1476, ANT-3105, ANT-3744, ANT-4267) all flatten at 8.6–9.2% residual activity, a maximum inhibition of about 91% (E21). For ANT-4267 the floor is flat at 9–10% from about 4 µM to 100 µM, roughly 85–2,300× its IC50, so it is not an under-dosing artefact. The client has not shown whether this floor is true residual turnover or assay background. (ANT-2118 reaches about 1–4%, which hints the floor is real.) The genetic benchmark is complete loss (PHA-L 3–4% of control) (E6).
* **Allosteric site.** ANT-3744 binds a C-terminal pocket (Y388–W444), 22.3 Å from the anomeric carbon of UDP-GlcNAc and 16 Å from the catalytic base D289 (E26).
  * It does not compete with the donor. UDP *tightens* ANT-3744 binding (KD 0.4 → 0.2 µM), where pure competition would predict about 63 µM. Stabilisation in the thermal-shift assay is additive: +6 °C for ANT-3744, +2 °C for UDP, +8 °C for both (E23, E24).
  * The structures do not explain how binding there inhibits catalysis.
* **Surrogate acceptor.** Potency was measured only with a small free oligosaccharide (3α,6α-mannopentaose), not a glycoprotein acceptor. If inhibition acts through the acceptor, cellular potency cannot be predicted from the IC50.

**4.3 A drug will reach T cells; the genetics never tested that.** Every phenotype experiment deletes MGAT1 in tumour cells only. A systemic inhibitor will also act on T cells and other immune cells. Whether that helps, harms or is neutral for tumour killing is untested, and it could offset the tumour-intrinsic benefit.

**4.4 The "checkpoint-resistant" thesis rests on an effect that is independent of PD-1.**

* In the pooled screen, anti-PD-1 does not deepen Mgat1 depletion in either background (STK11: +0.02 log2, p = 0.95) (E11). No group assignment changes this: three STK11 groups are indistinguishable (−3.42 to −3.53) and the fourth is weaker (−2.09).
* In the single-gene study:
  * Anti-PD-1 reduces growth by 33% in control tumours and 36% in MGAT1-knockout tumours.
  * MGAT1 loss reduces growth by 46% under IgG2a and 48% under anti-PD-1.
  * The combination's 395 mm³ matches the additive expectation of 414 mm³ (E16). The error bars overlap heavily, and n is not stated.
* This supports "adds a PD-1-independent immune penalty that persists under anti-PD-1". It does not support "restores anti-PD-1 sensitivity".

**4.5 STK11 selectivity is a mouse-colorectal-line finding.**

* All STK11 evidence comes from MC38, a colorectal line, with CRISPR-pool STK11 knockout. There is no NSCLC in vivo model.
* The human co-culture screen and validation lines are not documented as STK11-mutant. The NY-ESO-1 TCR system only kills antigen-positive lines (E8), so an antigen-matched, STK11-deficient human system still has to be built (Gate 3).
* STK11 protein is not fully absent in the MC38 lines. By rough densitometry it is about 7–14% of control in the knockout pools and 12–25% in the rescue lines. In the background used in vivo, the mutant-rescue line (~25%) has about twice the wild-type-rescue line (~12%) (E32). That is a potential confounder of the E17 result.
* In the single-gene data, MGAT1 knockout in STK11-WT MC38 trended toward *faster* growth (+53%; E15).

**4.6 MGAT1 is one node among several, and not the strongest.**

* In the same human screen, five glycosylation genes outrank MGAT1 (E4):
  * nucleotide-sugar supply and transport genes: SLC35A1 (rank 2), GALE (4), GFPT1 (6), SLC35A2 (7) and UGP2 (8);
  * CMAS (22) and UAP1 (23) follow just behind.
* At lineage level, SLC35A1's effect is about 4 times larger in log space (−3.8 vs −1.0; E2).
* Downstream branching enzymes do not score: MGAT2 (rank 2,476), MGAT5 (3,121), MAN2A1 (enriched).
* So the screen does not tie the phenotype to branching as such. PHA-L, the client's chosen readout, should be treated as a *target-engagement* marker, not a *mechanism* marker, until the glycan feature that causes sensitisation is identified.
* None of the stronger nodes were in the in vivo library, so MGAT1 has not been compared with them in vivo.

**4.7 Quantitative gaps in supporting datasets (detail in Section 8).**

* The genome-wide screen is n = 1 per arm.
* The glycoproteomics shows only about a 40–45% fall in complex-type glycopeptide signal in MGAT1 knockout cells. This conflicts with the ~97% PHA-L loss, so it cannot yet serve as a quantitative PD reference (E28).
* In the in vivo screen, background is perfectly confounded with sequencing run (E29) and the arm key is missing (E30).

# 5. Recommended next steps: a gated plan (design level)

During the hold, pause potency-driven medicinal chemistry; potency is not the bottleneck. Redirect chemistry to:

* a matched inactive analogue (the series already contains compounds with IC50 >20 µM);
* resolving the ~9% efficacy floor;
* properties for cell access;
* an ANT-4267 co-crystal structure.

**Gate 0: close documentation gaps before interpreting anything new (no new biology).**

* Supply:
  * the group-to-arm key and animal numbers for the pooled screen;
  * per-animal tumour data, n and error-bar definitions for all in vivo studies;
  * enzyme activity of the D211A, D289A and D211A/D289A proteins (methods exist, no data);
  * the D211A single-mutant results;
  * STK11 genotype/protein status of NCI-H1703 and NCI-H1755;
  * SPR surface activity / stoichiometry controls;
  * raw dose-response data (including no-enzyme controls and the top concentration actually used).
* Re-run the screen analysis with the confirmed key.

**Gate 1: cellular target engagement (the decisive experiment).**

* *Question:* does the compound give a knockout-equivalent glycan phenotype in cells, on-target?
* *Arms:* vehicle; ANT-4267; ANT-3744; matched inactive analogue; MGAT1 knockout as the 100% benchmark; compound in MGAT1-knockout cells (should be inert); a compound-resistant MGAT1 built from the C3744 pocket residues (E26) that rescues the compound effect; time course plus washout to define exposure needs against glycan turnover.
* *Readouts:* PHA-L, GNA, and Man5/complex glycopeptide shares, using a quantitative method first validated to give near-complete loss in knockout cells.
* *Go:*
  * PHA-L ≤10% of vehicle, GNA ≥5× and Man5 about doubled, i.e. knockout-like (E6, E28);
  * achieved at non-cytotoxic concentrations, with cellular EC50 within about 10× of the biochemical IC50;
  * no effect in knockout cells;
  * reversal by the resistant allele.
* *No-go:* if the ~9% residual activity leaves substantial complex glycans, stop the series and pursue the target only with a chemotype that achieves complete inhibition.
* *Enzymology alongside:* confirm whether the floor is residual activity or background; mechanism of inhibition against donor and against a glycoprotein acceptor; selectivity against MGAT2, MGAT3, MGAT4A/B and MGAT5.

**Gate 2: functional phenocopy and T-cell liability.**

* *Question:* does the compound reproduce the knockout's T-cell sensitisation without harming T cells?
* *Design:* antigen-specific co-culture in NCI-H1703 and NCI-H1755, with three exposure arms: (a) tumour pre-treatment with washout; (b) continuous exposure of both compartments; (c) T-cell-only exposure.
* *Comparisons:*
  * MGAT1 knockout (benchmark; viability 0.17–0.54 vs 0.79–0.92 for NTC, E5);
  * compound in MGAT1-knockout cells (no added effect expected);
  * B2M knockout (resistance control);
  * PTPN2 knockout (in-screen sensitiser benchmark; sgPTPN2 is already in the client's guide list);
  * antigen-negative targets and non-transduced T cells.
* *Go:*
  * the compound achieves at least half the knockout effect;
  * the effect is antigen-dependent and absent in knockout cells;
  * T-cell killing, proliferation and cytokine output are preserved (e.g., ≥80% of vehicle) at effective concentrations in arms (b) and (c).

**Gate 3: human STK11 context (required only if the STK11 positioning is kept).**

* *Design:* at least two human NSCLC isogenic pairs (STK11 loss in an STK11-WT line; STK11 re-expression in an STK11-null line), each with an antigen-matched T-cell system. Test MGAT1 knockout and compound.
* *Go:* the effect is materially larger in STK11-deficient cells. If it isn't, drop STK11 as the selection biomarker and re-scope the population before any clinical planning.

**Gate 4: in vivo PK/PD, then efficacy.**

* *PK/PD:* define the exposure that maintains knockout-like tumour glycan pharmacodynamics (PHA-L/GNA, Man5) across the dosing interval. Also measure the immune-cell glycophenotype.
* *Efficacy design:* STK11-deficient immunocompetent tumours (ideally a lung model alongside sgSTK11 MC38), in a 2×2 factorial (vehicle, compound, anti-PD-1, combination). Include:
  * a nude or CD8-depleted arm (T-cell dependence);
  * an STK11-WT counterpart (selectivity);
  * a genetic sgMGAT1 arm as the efficacy benchmark;
  * pre-specified n, randomisation, statistics and per-animal data.
* *Go:*
  * tumour growth inhibition close to the genetic benchmark (about 50% at matched time points; E15, E17);
  * lost without T cells;
  * larger in STK11-deficient tumours;
  * combination at least additive with anti-PD-1;
  * no loss of peripheral T-cell function.

**If a repeat or confirmatory screen is run, change the design:**

* biological replicates;
* an STK11-deficient human NSCLC line;
* backgrounds and arms balanced across sequencing runs;
* a documented arm key;
* more cells per guide at implantation (currently ~28; E31);
* pathway comparators in the library (e.g., SLC35A1, CMAS).

# 6. What would bring the asset back to "advance"

Advance to candidate nomination only when all of the following are shown with the client's own data:

1. **On-target, knockout-equivalent cellular pharmacology.** ANT-4267, or a successor, reduces PHA-L to ≤10% of vehicle and doubles Man5 in NY-ESO⁺ NSCLC lines at non-toxic concentrations. The effect is absent in MGAT1-knockout cells and reversed by a compound-resistant MGAT1 allele.
2. **Functional phenocopy.** The compound reproduces at least half the knockout effect on antigen-specific T-cell killing, without impairing T-cell function when T cells are exposed.
3. **The right population.** STK11 selectivity is shown in human isogenic NSCLC cells, or the population is redefined to what the data support.
4. **In vivo translation.** A tolerated exposure gives knockout-like tumour pharmacodynamics and T-cell-dependent growth inhibition comparable to the genetic benchmark. It must be at least additive with anti-PD-1 in a powered factorial study, with per-animal data.
5. **Clean documentation** (Gate 0), especially the screen arm key and the catalytic-mutant enzymology behind the "catalytic activity is required" claim.

The positioning should also change. Until item 4 shows otherwise, describe the asset as **"a PD-1-independent sensitiser of STK11-deficient tumours to CD8 T-cell killing, combinable with anti-PD-1"**, not as "restoring checkpoint-inhibitor response".

# 7. What I set aside or discounted, and why

| Item | Treatment | Reason |
|---|---|---|
| NY-ESO-1 expression across CCLE lines (phenotype p9) | Excluded from claims | Public database, not client-generated; used only as context for model choice |
| ANT-1938 and ANT-2214 (acquired compounds) | Not used as comparators or tools | ANT-1938: no SPR binding, 40% inhibition at 100 µM. ANT-2214: non-saturable, concentration-independent SPR responses with little dissociation (aggregation-like), catechol/hydrazone motifs, 60% inhibition at 100 µM. Neither shows specific binding |
| ANT-0592 IC50/KD (197/32.2 µM) | Qualitative only | Both measured above its kinetic solubility (11.8 µM). The KD asterisk is undefined. The series' SAR (E22) makes the hit's artefacts largely moot for the lead |
| Absolute IC50s refit from displayed curves | Registry values used instead | My refits are 1.2–1.9× lower (within assay variability; displayed curves are probably single runs). I used the refits only for curve shape (floor, Hill) |
| Glycoproteomics per-glycopeptide ratios | Directional only | KO channels show only a partial fall in complex glycans (E28), and ~5% of proteins are implausible nuclear/cytosolic glycoproteins (E27) |
| Significance of tumour-growth differences | Descriptive only | No n, error-bar definition or statistics were supplied. All volumes were read from figures (±~5%) |
| Cross-cohort magnitude comparisons (p1 WT vs sgSTK11 panels; p7 left vs right) | Not compared directly | Separate cohorts, different end days, different lines (pool vs clone A-F5) |
| Pooled-screen sample Group7_STK11_82431 | Excluded | 349 total reads (failed library) |
| Guide Mgat1_3 | Retained, flagged | Weak in all conditions (likely inefficient); conclusions hold with or without it (E12) |
| Experiments mentioned in methods without data (PD-L1/CD276 blots, sgPTPN2, PD-L1 guides, D211A single mutant, mutant enzyme activity) | Cannot be used | No data supplied |
| Cell line behind the adoptive-transfer and in vitro rescue figures (p4, p5) | Assumed NCI-H1703, flagged | Not stated. The only immunoblot of the engineered panel (p11) is NCI-H1703 |

# 8. Data-integrity and documentation issues to raise with the client

**High impact (affect interpretation):**

1. **Screen arm key missing; animal numbers don't reconcile.** The records describe C57BL/6 n = 30 and nude n = 15 in three arms. The count matrix holds 141 tumours in eight groups of 15–21 (E30). I inferred the arms from Cd274/IFN-γ-pathway/Ptpn2 behaviour (E14); this must be confirmed.
2. **Background confounded with sequencing run.** Every STK11-background sample was sequenced in SG01 runs and every NTC sample in SG02 runs (E29). Within-background contrasts are valid, and the interaction test is robust to additive run effects. Absolute cross-background comparisons are not.
3. **Genome-wide co-culture screen n = 1 per arm.** There is no biological replicate. UMI lineages give internal, not biological, replication.
4. **No enzymology for the catalytic mutants.** The "catalytic-dead" label is asserted, not shown.
5. **STK11 knockout incomplete and uneven in the MC38 rescue lines** (E32). The human lines' STK11 status is undocumented.
6. **MC38 MGAT1-knockout arm built from a single clone (A-F5); the NTC arm is a pool** (p11 schematic). Any knockout-vs-NTC comparison in those lines carries clonal confounding. The within-clone WT-vs-mutant comparison (p7 right) does not.

**Medium impact:**

7. The dose-response methods state a 100 µM top concentration, but five of six curves extend to ~1,000 µM (E21).
8. SPR stoichiometry does not reconcile. ANT-3744 reaches ~1.4× the theoretical 1:1 maximum on the 9,000 RU surface, while UDP reaches ~0.12× on an equivalent surface (E25). Surface activity is not characterised.
9. Glycoproteomics is quantitatively discordant with lectin flow (E6 vs E28). Possible causes are ratio compression, an incomplete knockout population, or composition assignment.
10. The caption of phenotype p1 describes library populations but shows single-gene sgNTC/sgMGAT1 studies. p8 matches the library-screen design. The captions appear swapped.
11. The immunoblot loading control (vinculin) is not in the listed antibodies. The p11 MGAT1 blot is spliced across three panels, with boundaries that do not match the sample groups.
12. The C3744 pocket sits next to a crystal-lattice contact (1–3 neighbouring-molecule residues within 4 Å; E26). Solution binding is supported by SPR, but pocket mutants would confirm the site.

**Low impact (record-keeping):**

13. The thermal-shift legend labels ANT-3744 "HTS"; the registry says "synthesised".
14. The "ITC" control guide is the POLB_2 guide of the genome-wide library (E33). It would cut POLB if used as a control.
15. Unit typos in the records: thermal-shift protein "18.6 nM … 9.3 µM final"; "1 mM BSA".
16. Anti-PD-1 was dosed at 5 mg/kg in the screen vs 10 mg/kg in the single-gene studies.
17. PDF metadata timestamps (18 Nov 2026) post-date the stated 1 Nov 2026 data cut. The records text says "compiled 18 August 2026". Confirm the version.

# 9. Provenance and files

* `evidence_register.xlsx` / `.csv`: every number above, with source file, page/column, derivation and script.
* `figures/`:
  * Fig1: in vivo screen, Mgat1 plus the arm-inference controls;
  * Fig2: co-culture screen rank and UMI lineages;
  * Fig3: dose-response floor, IC50–KD, competition;
  * Fig4: digitised in vivo endpoints and additive (Bliss) expectation;
  * Fig5: structure schematic;
  * Fig6: glycoproteomics.
* `derived_data/`: gene-level scores for both screens, contrast tables, digitised figure values, glycan-class shares, dose-response refits.
* `analysis_code/`: scripts used, with a README giving run order.

**Method notes:**

* Screen counts and glycoproteomics were analysed from raw client files.
* Structures were analysed from the deposited coordinates.
* Figure-only data (dose-response, SPR isotherms, tumour volumes, bar charts, immunoblot) were digitised from the client PDFs. Those values carry ~±5% reading error and are labelled "digitised" throughout.
* No external data were used for any claim.

# Appendix: key figures

![Fig 1. In vivo pooled screen: per-tumour Mgat1 scores by background and inferred arm. Cd274/Ptpn2/Jak1 panels show the internal controls used to infer the arms. Source: crispr_invivo_guide_counts.csv.gz (E10–E14).](figures/Fig1_invivo_screen_Mgat1_and_arm_controls.png)

![Fig 2. Genome-wide co-culture screen: gene rank and UMI-lineage distributions. Source: coculture_screen_umi_counts.csv.gz (E1–E4).](figures/Fig2_coculture_screen.png)

![Fig 3. Biochemistry and biophysics: ~9% residual-activity floor; IC50 tracks KD; no competition with UDP. Sources: assay_figures.pdf p1 and p5 (digitised), spr_competition.csv, dsf_thermal_shift.csv (E21–E24).](figures/Fig3_biochemistry_biophysics.png)

![Fig 4. Client in vivo studies, endpoints digitised from phenotype_figures.pdf (E9, E15–E18). The dashed line is the additive (Bliss) expectation for MGAT1 KO plus anti-PD-1.](figures/Fig4_invivo_endpoints_digitized.png)

![Fig 5. ANT-3744 binds a C-terminal pocket ~22 Å from the transfer centre. Source: MGAT1_C3744_UDP.cif, with UDP-GlcNAc superposed from MGAT1_UDP_GlcNAc.cif (E26).](figures/Fig5_structure_binding_site_schematic.png)

![Fig 6. Glycoproteomics: Man5 doubles in KO, but MGAT1-dependent glycan classes fall only partially. Source: glycoproteomics_site_quant.xlsx, IGP_quant (E27–E28).](figures/Fig6_glycoproteomics_KO_vs_NT.png)
