# MGAT1 programme: independent verification deliverables (data cut 1 Nov 2026)

| File | What it is |
|---|---|
| `MGAT1_recommendation_memo.docx` / `.md` | The recommendation memo: call, case, gated next steps, bring-back criteria, set-asides, data-integrity issues, figures |
| `evidence_register.xlsx` / `.csv` | Every number cited (E1–E33), with source file, page/column, derivation and script |
| `figures/` | Fig1–Fig6 (in vivo screen; co-culture screen; biochemistry/biophysics; digitised in vivo endpoints; structure; glycoproteomics) |
| `derived_data/` | Gene-level screen scores and contrasts, digitised figure values, dose-response refits, glycan-class shares |
| `analysis_code/` | Scripts and a README giving run order and key analysis choices |

All claims rest on client-supplied files only. Values digitised from PDF figures are labelled as such (about ±5% reading error).
