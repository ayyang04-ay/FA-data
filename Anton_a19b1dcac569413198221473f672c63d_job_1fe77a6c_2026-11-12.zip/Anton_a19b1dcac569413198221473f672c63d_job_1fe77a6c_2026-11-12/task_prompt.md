We ran a study on exogenous creatine and metastasis, utilizing mouse models and a healthy-volunteer cohort. 



All raw data is uploaded. Treat it as the relevant ground truth for all recommendations and analyses. 



I'm taking a validation proposal to the portfolio committee. The in vivo slot for next quarter is allocated at that meeting. Based on the provided data, prepare a proposal for follow-up studies: the primary target recommendation, and strong backup(s).



Lead with the recommendation, on the first line, in your own words: what we take forward. Structure the rest as you see fit.



The proposal must include the evidence that supports this decision: all the relevant data, cited and analyzed, with how you derived it. The proposal should also detail the subsequent studies: endpoints, populations, indications, comparators, readouts. What information would elevate one choice over another?



Consider the provided data to be the most relevant, serving as ground truth. External data may appear similar but is not validated in our system, and so it is indeterminable if it's relevant/applicable. Keep this at the level of study design, specification and interpretation of the data package. Bench or assay protocol details are unnecessary.
