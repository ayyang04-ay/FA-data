#!/usr/bin/env python
"""
CRE-MK-01 re-analysis supporting the follow-up proposal.

Run:  micromamba run -n singlecell python cre_mk01_reanalysis.py
Inputs (read-only): /tmp/world/filesystem/CRE-MK-01_source_data.xlsx
                    /tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx
Outputs: ../tables/*.csv  and ../figures/*.png

Every number quoted in the proposal is produced here from the raw cells of the two workbooks.
No external data are used.
"""
import os, re, warnings, collections
import numpy as np, pandas as pd
import openpyxl
from openpyxl.utils import column_index_from_string as CI, get_column_letter as GL
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
from statsmodels.duration.hazard_regression import PHReg
warnings.filterwarnings('ignore')

SRC = '/tmp/world/filesystem/CRE-MK-01_source_data.xlsx'
PHO = '/tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx'
HERE = os.path.dirname(os.path.abspath(__file__))
TAB = os.path.join(HERE, '..', 'tables'); FIG = os.path.join(HERE, '..', 'figures')
os.makedirs(TAB, exist_ok=True); os.makedirs(FIG, exist_ok=True)
rng = np.random.default_rng(20240607)

WB = openpyxl.load_workbook(SRC, data_only=True)
def ws(name):
    for w in WB.worksheets:
        if w.title.strip() == name.strip():
            return w
    raise KeyError(name)
def col(sheet, c, r1, r2):
    w = ws(sheet); return np.array([float(w[f'{c}{r}'].value) for r in range(r1, r2+1) if w[f'{c}{r}'].value is not None])
def row(sheet, r, c1, c2):
    w = ws(sheet); return np.array([float(w.cell(row=r, column=ci).value) for ci in range(CI(c1), CI(c2)+1) if w.cell(row=r, column=ci).value is not None])
def cell(sheet, ref):
    return ws(sheet)[ref].value
def msd(a): return f'{np.mean(a):.4g} ± {np.std(a, ddof=1):.3g}'

# ----------------------------------------------------------------------------------------------
# 1. Re-computation of every embedded Prism test from the raw values
# ----------------------------------------------------------------------------------------------
EV = []   # evidence rows
def add(panel, source, readout, unit_n, groups, test, p_re, p_rep, note=''):
    EV.append(dict(panel=panel, source_cells=source, readout=readout, n_unit=unit_n,
                   groups=' | '.join(f'{k}: {msd(v)} (n={len(v)})' for k, v in groups.items()),
                   test=test, p_recomputed=p_re, p_reported_in_sheet=p_rep, note=note))
def ttest(panel, sheet, readout, a_ref, b_ref, names, p_cell, unit='animals', note=''):
    a = col(sheet, *a_ref) if len(a_ref) == 3 and isinstance(a_ref[0], str) and a_ref[0].isalpha() and isinstance(a_ref[1], int) and not isinstance(a_ref[2], str) else row(sheet, *a_ref)
    b = col(sheet, *b_ref) if len(b_ref) == 3 and isinstance(b_ref[0], str) and b_ref[0].isalpha() and isinstance(b_ref[1], int) and not isinstance(b_ref[2], str) else row(sheet, *b_ref)
    t, p = stats.ttest_ind(a, b)
    fmt = lambda r: f'{r[0]}{r[1]}:{r[0]}{r[2]}'
    add(panel, f"'{sheet}'!{fmt(a_ref)} vs {fmt(b_ref)}" + (f'; reported p in {p_cell}' if p_cell else ''), readout, unit, {names[0]: a, names[1]: b}, f'unpaired t (t={abs(t):.3f}, df={len(a)+len(b)-2})', p, cell(sheet, p_cell) if p_cell else None, note)
    return a, b, p
def tukey(panel, sheet, readout, groups, pairs, unit='animals', note=''):
    """groups: ordered dict name->array ; pairs: list of (name_i, name_j, reported_p_cell)"""
    names = list(groups); res = stats.tukey_hsd(*groups.values())
    for (i, j, pc) in pairs:
        add(panel, f"'{sheet}'" + (f'; reported p in {pc}' if pc else ''), readout, unit, {i: groups[i], j: groups[j]}, f'one-way ANOVA + Tukey ({len(names)} groups)', res.pvalue[names.index(i), names.index(j)], cell(sheet, pc) if pc else None, note)
    return res
def dunnett(panel, sheet, readout, groups, pcs, unit='volunteers', note=''):
    names = list(groups); ctrl = groups[names[0]]
    d = stats.dunnett(*[groups[n] for n in names[1:]], control=ctrl)
    for k, n in enumerate(names[1:]):
        add(panel, f"'{sheet}'" + (f'; reported p in {pcs[k]}' if pcs[k] else ''), readout, unit, {names[0]: ctrl, n: groups[n]}, 'one-way ANOVA + Dunnett vs day 0 (as in sheet; unpaired)', d.pvalue[k], cell(sheet, pcs[k]) if pcs[k] else None, note)

# --- Fig 1 -------------------------------------------------------------------------------------
ttest('Fig 1a', 'Fig. 1a', 'Lung weight (g)', ('B', 3, 8), ('C', 3, 8), ('Vehicle', 'Creatine'), 'F4')
ttest('Fig 1a', 'Fig. 1a', 'SUV-BW (PET)', ('B', 12, 17), ('C', 12, 17), ('Vehicle', 'Creatine'), 'F12')
ttest('Fig 1b', 'Fig. 1b', 'Metastatic burden (%)', ('B', 3, 8), ('C', 3, 8), ('Vehicle', 'Creatine'), 'F3')
ttest('Fig 1b', 'Fig. 1b', 'Metastatic foci (n)', ('B', 12, 17), ('C', 12, 17), ('Vehicle', 'Creatine'), 'F12')
for r, lab, pc in [(4, '0.25 h', 'B17'), (5, '6 h', 'E17'), (6, '12 h', 'H17'), (7, '24 h', 'K17')]:
    a, b = row('Fig. 1h', r, 'B', 'G'), row('Fig. 1h', r, 'H', 'M'); t, p = stats.ttest_ind(a, b)
    add('Fig 1h', f"'Fig. 1h'!B{r}:G{r} vs H{r}:M{r}", f'Lung tumour-cell signal at {lab} (metric not labelled in sheet)', 'animals', {'Vehicle': a, 'Creatine': b}, f'unpaired t (t={abs(t):.3f})', p, cell('Fig. 1h', pc))
ttest('Fig 1i', 'Fig. 1i', 'GFP+ cells per field', ('B', 4, 11), ('C', 4, 11), ('Vehicle', 'Creatine'), 'F4', unit='random fields (8/group), not animals')
ttest('Fig 1j', 'Fig. 1j', 'Lung weight (g)', ('B', 4, 9), ('C', 4, 9), ('Vehicle', 'Creatine'), 'F4')
ttest('Fig 1j', 'Fig. 1j', 'SUV-BW (PET)', ('B', 13, 18), ('C', 13, 18), ('Vehicle', 'Creatine'), 'F13')
ttest('Fig 1k', 'Fig. 1k', 'Metastatic burden (%)', ('B', 4, 9), ('C', 4, 9), ('Vehicle', 'Creatine'), 'F4')
ttest('Fig 1k', 'Fig. 1k', 'Metastatic foci (n)', ('B', 12, 17), ('C', 12, 17), ('Vehicle', 'Creatine'), 'F12')
for (r1, r2, lab, pcs) in [(4, 9, 'Lung weight (g)', ('L4', 'L5', 'L6')), (13, 18, 'SUV-BW', ('L13', 'L14', 'L15')), (22, 27, 'Metastatic burden (%)', ('L22', 'L23', 'L24')), (31, 36, 'Metastatic foci (n)', ('L31', 'L32', 'L33'))]:
    g = collections.OrderedDict(zip(['shScr-veh', 'shScr-cre', 'shSlc6a8-veh', 'shSlc6a8-cre'], [col('Fig. 1f', c, r1, r2) for c in 'BCDE']))
    tukey('Fig 1f', 'Fig. 1f', lab + ' - tumour-cell sh-Slc6a8', g, [('shScr-veh', 'shScr-cre', pcs[0]), ('shScr-cre', 'shSlc6a8-cre', pcs[1]), ('shSlc6a8-veh', 'shSlc6a8-cre', pcs[2])])

def logrank(t1, t2):
    times = np.unique(np.concatenate([t1, t2])); O = E = V = 0.0
    for t in times:
        n1, n2 = (t1 >= t).sum(), (t2 >= t).sum(); d1, d2 = (t1 == t).sum(), (t2 == t).sum(); n, d = n1+n2, d1+d2
        O += d1; E += d*n1/n
        if n > 1: V += d*(n1/n)*(n2/n)*(n-d)/(n-1)
    chi = (O-E)**2/V; return chi, stats.chi2.sf(chi, 1)
SURV = []
for panel, sheet, (v1, v2), (c1, c2), pc in [('Fig 1c', 'Fig. 1c', (4, 13), (14, 23), 'F8'), ('Fig 1l', 'Fig. 1l', (4, 23), (24, 41), 'F7')]:
    v = col(sheet, 'A', v1, v2); c = col(sheet, 'A', c1, c2); chi, p = logrank(v, c)
    d = pd.DataFrame({'t': np.r_[v, c], 'cre': np.r_[np.zeros(len(v)), np.ones(len(c))]})
    m = PHReg(d['t'], d[['cre']], status=np.ones(len(d)), ties='efron').fit()
    hr = float(np.exp(m.params[0])); lo, hi = np.exp(m.conf_int()[0])
    add(panel, f"'{sheet}'!A{v1}:A{v2} vs A{c1}:A{c2}", 'Survival (days); all animals reached endpoint (no censoring)', 'animals', {'Vehicle': v, 'Creatine': c}, f'log-rank (chi2={chi:.3f}); Cox HR={hr:.2f} [{lo:.2f}-{hi:.2f}]', p, cell(sheet, pc))
    SURV.append(dict(panel=panel, n_vehicle=len(v), n_creatine=len(c), median_vehicle_d=np.median(v), median_creatine_d=np.median(c), logrank_chi2=chi, logrank_p=p, cox_HR=hr, HR_lo=lo, HR_hi=hi))
pd.DataFrame(SURV).to_csv(os.path.join(TAB, 'survival.csv'), index=False)

# --- Fig 2 -------------------------------------------------------------------------------------
for (r1, r2, lab, pc) in [(4, 6, 'PLT (x10^9/L)', 'F4'), (12, 14, 'PCT (%)', 'F12'), (19, 21, 'PDW (fL)', 'F19'), (27, 29, 'MPV (fL)', 'F27')]:
    ttest('Fig 2a', 'Fig. 2a', lab, ('B', r1, r2), ('C', r1, r2), ('Vehicle', 'Creatine'), pc)
for r, lab, pc in [(4, 'ADP', 'B18'), (5, 'Collagen', 'B32'), (6, 'Thrombin', 'B45')]:
    a, b = row('Fig. 2b', r, 'B', 'D'), row('Fig. 2b', r, 'E', 'G'); t, p = stats.ttest_ind(a, b)
    add('Fig 2b', f"'Fig. 2b'!B{r}:D{r} vs E{r}:G{r}", f'Platelet aggregation to {lab} (%)', 'animals', {'Vehicle': a, 'Creatine': b}, f'unpaired t (t={abs(t):.2f})', p, cell('Fig. 2b', pc))
ttest('Fig 2c', 'Fig. 2c', 'alpha-granules per field', ('B', 4, 11), ('C', 4, 11), ('Vehicle', 'Creatine'), 'F5', unit='random fields (8/group), not animals')
for (r1, r2, lab, pc) in [(4, 8, 'TEG-R (min)', 'F4'), (12, 16, 'TEG-K (min)', 'F12'), (20, 24, 'TEG-alpha (deg)', 'F20'), (28, 32, 'TEG-MA (mm)', 'F28')]:
    ttest('Fig 2d', 'Fig. 2d', lab, ('B', r1, r2), ('C', r1, r2), ('Vehicle', 'Creatine'), pc)
ttest('Fig 2j', 'Fig. 2j', 'PKH-positive area (%)', ('B', 4, 11), ('C', 4, 11), ('Vehicle', 'Creatine'), 'F4', unit='random fields (8/group), not animals')

# --- Fig 3 (Pf4-Cre;Slc6a8) --------------------------------------------------------------------
G3 = ['WT-veh', 'WT-cre', 'Slc6a8cKO-veh', 'Slc6a8cKO-cre']
for r, lab, pc in [(4, 'Pf4-Cre;Slc6a8+/+', 'B17'), (5, 'Pf4-Cre;Slc6a8fl/fl', 'B31')]:
    a, b = row('Fig. 3b', r, 'B', 'F'), row('Fig. 3b', r, 'G', 'K'); t, p = stats.ttest_ind(a, b)
    add('Fig 3b', f"'Fig. 3b'!B{r}:F{r} vs G{r}:K{r}", f'Serum creatine (uM), {lab}', 'animals', {'Vehicle': a, 'Creatine': b}, f'unpaired t (t={abs(t):.2f})', p, cell('Fig. 3b', pc))
for r, lab, pc in [(4, 'Pf4-Cre;Slc6a8+/+', 'B15'), (5, 'Pf4-Cre;Slc6a8fl/fl', 'B30')]:
    a, b = row('Fig. 3c', r, 'B', 'D'), row('Fig. 3c', r, 'E', 'G'); t, p = stats.ttest_ind(a, b)
    add('Fig 3c', f"'Fig. 3c'!B{r}:D{r} vs E{r}:G{r}", f'MK intracellular creatine, {lab}', 'animals', {'Vehicle': a, 'Creatine': b}, f'unpaired t (t={abs(t):.2f})', p, cell('Fig. 3c', pc))
for r, lab, pcs in [(4, 'ADP', ('T4', 'T5')), (5, 'Collagen', ('T10', 'T11')), (6, 'Thrombin', ('T15', 'T16'))]:
    g = collections.OrderedDict(zip(G3, [row('Fig. 3d', r, 'B', 'D'), row('Fig. 3d', r, 'E', 'G'), row('Fig. 3d', r, 'H', 'J'), row('Fig. 3d', r, 'K', 'M')]))
    tukey('Fig 3d', 'Fig. 3d', f'Platelet aggregation to {lab} (%)', g, [('WT-veh', 'WT-cre', pcs[0]), ('Slc6a8cKO-veh', 'Slc6a8cKO-cre', pcs[1]), ('WT-veh', 'Slc6a8cKO-veh', None), ('WT-cre', 'Slc6a8cKO-cre', None)])
for (r1, r2, lab, pcs) in [(3, 6, 'Lung weight (g)', ('L3', 'L4', 'L5')), (10, 13, 'Metastatic burden (%)', ('L10', 'L11', 'L12')), (17, 20, 'Metastatic foci (n)', ('L17', 'L18', 'L19'))]:
    g = collections.OrderedDict(zip(G3, [col('Fig. 3i', c, r1, r2) for c in 'BCDE']))
    tukey('Fig 3i', 'Fig. 3i', lab + ' - MK-lineage Slc6a8 deletion', g, [('WT-veh', 'WT-cre', pcs[0]), ('WT-cre', 'Slc6a8cKO-cre', pcs[1]), ('Slc6a8cKO-veh', 'Slc6a8cKO-cre', pcs[2]), ('WT-veh', 'Slc6a8cKO-veh', None)])

# --- Fig 4 -------------------------------------------------------------------------------------
ttest('Fig 4a', 'Fig. 4a', 'Creatine (umol/g), MKs', ('B', 4, 6), ('C', 4, 6), ('Vehicle', 'Creatine'), 'H10')
ttest('Fig 4a', 'Fig. 4a', 'Creatine (umol/g), brain', ('D', 4, 6), ('E', 4, 6), ('Vehicle', 'Creatine'), 'H24')
ttest('Fig 4c', 'Fig. 4c', 'Phosphocreatine (ng/ug), MKs', ('B', 4, 6), ('C', 4, 6), ('Vehicle', 'Creatine'), 'H10')
ttest('Fig 4c', 'Fig. 4c', 'Phosphocreatine (ng/ug), brain', ('D', 4, 6), ('E', 4, 6), ('Vehicle', 'Creatine'), 'H24')
ttest('Fig 4d', 'Fig. 4d', "Intracellular creatine, MKs in vitro (sheet header says 'Creatinine'; creatine assay per study conventions)", ('C', 4, 6), ('D', 4, 6), ('Control', 'Creatine'), 'G10')
ttest('Fig 4f', 'Fig. 4f', 'Phosphocreatine (ng/ug), MKs in vitro', ('B', 4, 6), ('C', 4, 6), ('Control', 'Creatine'), 'F4')
d1, d2 = row('Fig. 4e', 5, 'I', 'K'), row('Fig. 4e', 6, 'I', 'K'); a = 2.0**d1/np.mean(2.0**d1); b = 2.0**(d2-d1); t, p = stats.ttest_ind(a, b)
add('Fig 4e', "'Fig. 4e'!I5:K6", 'Ckb mRNA (fold), MKs', 'samples', {'Vehicle': a, 'Creatine': b}, f'unpaired t (t={abs(t):.2f})', p, cell('Fig. 4e', 'O5'))

# --- Fig 5 -------------------------------------------------------------------------------------
MUT = ['WT', 'S127A', '3A', 'S127D']
for sheet, panel, cols, rveh, rcre, pv, pcx in [('Fig. 5e', 'Fig 5e', 'NOPQ', (4, 6), (17, 19), [('WT', '3A', 'R10'), ('WT', 'S127D', 'R11'), ('S127A', 'S127D', 'R12'), ('3A', 'S127D', 'R13')], [('WT', 'S127A', 'R22'), ('WT', 'S127D', 'R23'), ('S127A', '3A', 'R24')]),
                                               ('Fig. 5f', 'Fig 5f', 'NOPQ', (4, 6), (17, 19), [('WT', '3A', 'Q9'), ('WT', 'S127D', 'Q10'), ('S127A', 'S127D', 'Q11'), ('3A', 'S127D', 'Q12')], [('WT', 'S127A', 'Q22'), ('WT', 'S127D', 'Q23'), ('S127A', '3A', 'Q24')])]:
    gv = collections.OrderedDict(zip(MUT, [col(sheet, c, *rveh) for c in cols])); gc = collections.OrderedDict(zip(MUT, [col(sheet, c, *rcre) for c in cols]))
    tukey(panel, sheet, 'pan-phospho/FLAG of STAT5B-FLAG - vehicle', gv, pv, unit='blots')
    tukey(panel, sheet, 'pan-phospho/FLAG of STAT5B-FLAG - creatine', gc, pcx, unit='blots')
    t, p = stats.ttest_ind(gv['WT'], gc['WT'])
    add(panel, f"'{sheet}'", 'pan-phospho/FLAG, WT STAT5B: vehicle vs creatine (NOT tested in sheet; cross-blot comparison)', 'blots', {'Vehicle-WT': gv['WT'], 'Creatine-WT': gc['WT']}, 'unpaired t (exploratory)', p, None)
def sidak_twoway(panel, sheet, readout, r0, vc, cc, pcs):
    labs = ['Exon', '2K', '1K', '0.2K']; veh = {l: row(sheet, r0+i, *vc) for i, l in enumerate(labs)}; cre = {l: row(sheet, r0+i, *cc) for i, l in enumerate(labs)}
    sse = sum(((a-a.mean())**2).sum() for d in (veh, cre) for a in d.values()); dfe = sum(len(a)-1 for d in (veh, cre) for a in d.values()); mse = sse/dfe
    for l, pc in zip(labs, pcs):
        a, b = veh[l], cre[l]; t = (a.mean()-b.mean())/np.sqrt(mse*(1/len(a)+1/len(b))); p = 2*stats.t.sf(abs(t), dfe); padj = 1-(1-p)**4
        add(panel, f"'{sheet}'; reported p in {pc}", f'{readout} - {l} amplicon (% input)', 'ChIP replicates', {'Vehicle': a, 'Creatine': b}, 'two-way ANOVA + Sidak', padj, cell(sheet, pc))
sidak_twoway('Fig 5j', 'Fig. 5j', 'ChIP at P2ry12', 5, ('B', 'D'), ('E', 'G'), ['N7', 'N8', 'N9', 'N10'])
sidak_twoway('Fig 5j', 'Fig. 5j', 'ChIP at Gp6', 15, ('B', 'D'), ('E', 'G'), ['N17', 'N18', 'N19', 'N20'])
sidak_twoway('Supp 6i', 'Supplementary Fig  6i', 'ChIP at Rab4a', 7, ('C', 'E'), ('F', 'H'), ['O10', 'O11', 'O12', 'O13'])

# --- Fig 6 -------------------------------------------------------------------------------------
G6 = ['Veh', 'Cre', 'Veh+STAT5i', 'Cre+STAT5i']
for (r1, r2, lab, pcs) in [(4, 8, 'Metastatic burden (%)', ('L4', 'L5', 'L6', 'L7')), (13, 17, 'Metastatic foci (n)', ('L13', 'L14', 'L15', 'L16'))]:
    g = collections.OrderedDict(zip(G6, [col('Fig. 6b', c, r1, r2) for c in 'BCDE']))
    tukey('Fig 6b', 'Fig. 6b', lab + ' - STAT5-IN-1 (STAT5A+B)', g, [('Veh', 'Cre', pcs[0]), ('Veh', 'Veh+STAT5i', pcs[1]), ('Cre', 'Cre+STAT5i', pcs[2]), ('Veh+STAT5i', 'Cre+STAT5i', pcs[3])], note='3 vehicle + 3 creatine values identical to Supp Fig 2d')
g = collections.OrderedDict(zip(['WT-veh', 'WT-cre', 'Stat5bcKO-cre'], [col('Fig. 6e', c, 5, 7) for c in 'CDE']))
tukey('Fig 6e', 'Fig. 6e', 'MK intracellular creatine (umol/g)', g, [('WT-veh', 'WT-cre', 'L5'), ('WT-veh', 'Stat5bcKO-cre', 'L6'), ('WT-cre', 'Stat5bcKO-cre', 'L7')], note='no Stat5b-cKO vehicle arm')

# --- Fig 7 (human) -----------------------------------------------------------------------------
D7 = ['d0', 'd3', 'd7', 'd14']
g = collections.OrderedDict(zip(D7, [col('Fig. 7b', c, 4, 14) for c in 'BCDE']))
tukey('Fig 7b', 'Fig. 7b', 'Human fasting serum creatine (uM)', g, [('d0', 'd3', 'L5'), ('d0', 'd7', 'L6'), ('d0', 'd14', 'L7')], unit='volunteers (n=11)')
BLK7C = [('collagen', 'max aggregation', 4, ('L4', 'L5', 'L6')), ('collagen', 'avg aggregation', 18, ('L18', 'L19', 'L20')), ('collagen', 'adhesion', 32, ('L32', 'L33', 'L34')),
         ('EPI', 'max aggregation', 46, ('L47', 'L48', 'L49')), ('EPI', 'avg aggregation', 60, ('L61', 'L62', 'L63')), ('EPI', 'adhesion', 74, ('L75', 'L76', 'L77')),
         ('AA', 'max aggregation', 88, ('L88', 'L89', 'L90')), ('AA', 'avg aggregation', 102, ('L103', 'L104', 'L105')), ('AA', 'adhesion', 116, ('L117', 'L118', 'L119')),
         ('ADP', 'max aggregation', 130, ('L131', 'L132', 'L133')), ('ADP', 'avg aggregation', 144, ('L145', 'L146', 'L147')), ('ADP', 'adhesion', 157, ('L159', 'L160', 'L161'))]
H7C = {}
for ag, met, r1, pcs in BLK7C:
    g = collections.OrderedDict(zip(D7, [col('Fig. 7c', c, r1, r1+10) for c in 'BCDE'])); H7C[(ag, met)] = g
    dunnett('Fig 7c', 'Fig. 7c', f'Human platelets, {ag}: relative {met} (fold of day 0)', g, pcs, unit='volunteers (n=11)')
for r1, lab, pcs in [(4, 'GP6/b-ACTIN', ('L4', 'L5', 'L6')), (12, 'P2RY12/b-ACTIN', ('L12', 'L13', 'L14'))]:
    g = collections.OrderedDict(zip(D7, [col('Fig. 7e', c, r1, r1+3) for c in 'BCDE']))
    tukey('Fig 7e', 'Fig. 7e', f'Human platelet {lab} (immunoblot densitometry)', g, [('d0', 'd3', pcs[0]), ('d0', 'd7', pcs[1]), ('d0', 'd14', pcs[2])], unit='volunteers (n=4)')
for (r1, r2, lab, pc) in [(4, 8, 'Lung weight (g)', 'F4'), (12, 16, 'Metastatic burden (%)', 'F12'), (19, 23, 'Metastatic foci (n)', 'F19')]:
    ttest('Fig 7g', 'Fig. 7g', lab + ' - recipients of human platelets', ('B', r1, r2), ('C', r1, r2), ('d0 donor PLTs', 'd7 donor PLTs'), pc, unit='recipient mice (donor n not stated)')

# --- Supplementary -----------------------------------------------------------------------------
S = 'Supplementary Fig  '
a, b = row(S+'1a', 4, 'B', 'E'), row(S+'1a', 4, 'F', 'I'); add('Supp 1a', S+'1a', 'Body weight d0 (g)', 'animals', {'Vehicle': a, 'Creatine': b}, 'unpaired t', stats.ttest_ind(a, b)[1], cell(S+'1a', 'M11'))
a, b = row(S+'1a', 5, 'B', 'E'), row(S+'1a', 5, 'F', 'I'); add('Supp 1a', S+'1a', 'Body weight d7 (g)', 'animals', {'Vehicle': a, 'Creatine': b}, 'unpaired t', stats.ttest_ind(a, b)[1], cell(S+'1a', 'M25'))
ttest('Supp 1b', S+'1b', 'Food intake (g/day)', ('B', 4, 9), ('C', 4, 9), ('Vehicle', 'Creatine'), 'F4')
ttest('Supp 1c', S+'1c', 'Water intake (g/day)', ('B', 4, 9), ('C', 4, 9), ('Vehicle', 'Creatine'), 'F4')
ttest('Supp 1d', S+'1d', 'Serum creatine (uM), gavage', ('B', 4, 9), ('C', 4, 9), ('Vehicle', 'Creatine'), 'F4')
for sh, panel, blocks in [(S+'1e', 'Supp 1e', [(4, 9, 'Lung weight (g)', 'F4'), (13, 18, 'Metastatic burden (%)', 'F13'), (22, 27, 'Metastatic foci (n)', 'F22')]),
                          (S+'1f', 'Supp 1f', [(4, 7, 'Lung weight (g)', 'F4'), (12, 15, 'Metastatic burden (%)', 'F12'), (20, 23, 'Metastatic foci (n)', 'F20')]),
                          (S+'1g', 'Supp 1g', [(3, 12, 'Lung weight (g)', 'F3'), (15, 24, 'Metastatic burden (%)', 'F15'), (28, 37, 'Metastatic foci (n)', 'F28')]),
                          (S+'1i', 'Supp 1i', [(3, 6, 'Lung weight (g)', 'F3'), (11, 14, 'Metastatic burden (%)', 'F11'), (18, 21, 'Metastatic foci (n)', 'F18')])]:
    for (r1, r2, lab, pc) in blocks:
        ttest(panel, sh, lab, ('B', r1, r2), ('C', r1, r2), ('Vehicle' if panel != 'Supp 1i' else 'Control diet', 'Creatine' if panel != 'Supp 1i' else '5% creatine diet'), pc)
for (r1, r2, lab, pc) in [(4, 13, 'Lung weight (g)', 'G4'), (16, 25, 'Metastatic burden (%)', 'G16'), (29, 38, 'Metastatic foci (n)', 'G29')]:
    ttest('Supp 1k', S+'1k', lab, ('B', r1, r2), ('C', r1, r2), ('Vehicle', 'Creatine'), pc)
ttest('Supp 1h', S+'1h', 'Serum creatine (uM), 5% diet', ('C', 4, 7), ('D', 4, 7), ('Control diet', 'Creatine diet'), 'F4')
d1, d2 = row(S+'2a', 4, 'H', 'J'), row(S+'2a', 5, 'H', 'J'); a = 2.0**d1/np.mean(2.0**d1); b = 2.0**(d2-d1)
add('Supp 2a', S+'2a', 'Slc6a8 mRNA in tumour cells (fold)', 'samples', {'scrambled': a, 'Slc6a8 knock-down': b}, 'unpaired t', stats.ttest_ind(a, b)[1], cell(S+'2a', 'M4'), note='blot image in same sheet shows only a modest protein reduction')
for (r1, r2, lab, pcs) in [(5, 10, 'Metastatic burden (%)', ('L5', 'L6', 'L7')), (14, 19, 'Metastatic foci (n)', ('L14', 'L15', 'L16'))]:
    g = collections.OrderedDict(zip(['Veh-donor PLT', 'Cre-donor PLT', 'Cre+aspirin-donor PLT'], [col(S+'2d', c, r1, r2) for c in 'CDE']))
    tukey('Supp 2d', S+'2d', lab + ' - recipients of donor platelets', g, [('Veh-donor PLT', 'Cre-donor PLT', pcs[0]), ('Veh-donor PLT', 'Cre+aspirin-donor PLT', pcs[1]), ('Cre-donor PLT', 'Cre+aspirin-donor PLT', pcs[2])], note='3 vehicle + 3 creatine values identical to Fig 6b; no vehicle+aspirin arm')
for (r1, r2, lab, pc) in [(4, 8, 'WBC', 'F4'), (12, 16, 'Lymphocytes', 'F12'), (20, 24, 'Monocytes', 'F20'), (28, 32, 'RBC', 'F28')]:
    ttest('Supp 3a', S+'3a', lab, ('B', r1, r2), ('C', r1, r2), ('Vehicle', 'Creatine'), pc)
g = collections.OrderedDict(zip(G3, [col(S+'4b', c, 5, 7) for c in 'CDEF']))
tukey('Supp 4b', S+'4b', 'PLT (x10^9/L) - Pf4-Cre;Slc6a8', g, [('WT-veh', 'WT-cre', 'M5'), ('WT-veh', 'Slc6a8cKO-veh', 'M6'), ('WT-cre', 'Slc6a8cKO-cre', 'M7'), ('Slc6a8cKO-veh', 'Slc6a8cKO-cre', 'M8')])
g = collections.OrderedDict(zip(G3, [col(S+'4c', c, 6, 13) for c in 'CDEF']))
tukey('Supp 4c', S+'4c', 'alpha-granules per field - Pf4-Cre;Slc6a8', g, [('WT-veh', 'WT-cre', 'N7'), ('WT-cre', 'Slc6a8cKO-cre', 'N8'), ('Slc6a8cKO-veh', 'Slc6a8cKO-cre', 'N9')], unit='random fields (8/group), not animals')
for r, lab, pc in [(5, 'Gatm', 'N10'), (8, 'Gamt', 'N24')]:
    d1, d2 = row(S+'5a', r, 'C', 'E'), row(S+'5a', r, 'G', 'I'); m = np.mean(2.0**d1); a, b = 2.0**d1/m, 2.0**d2/m
    add('Supp 5a', S+'5a', f'{lab} mRNA in MKs (fold)', 'samples', {'Vehicle': a, 'Creatine': b}, 'unpaired t', stats.ttest_ind(a, b)[1], cell(S+'5a', pc))
ttest('Supp 5c', S+'5c', 'MK creatine (umol/g), CKB-EV vs CKB-OE', ('B', 5, 7), ('C', 5, 7), ('CKB-EV', 'CKB-OE'), 'F5')
ttest('Supp 5c', S+'5c', 'MK phosphocreatine (ng/ug), CKB-EV vs CKB-OE', ('B', 13, 15), ('C', 13, 15), ('CKB-EV', 'CKB-OE'), 'F13')
for (r1, r2, lab, pcs) in [(4, 6, 'PLT (x10^9/L)', ('L4', 'L5', 'L6')), (11, 13, 'PCT (%)', ('L11', 'L12', 'L13')), (17, 19, 'MPV (fL)', ('L17', 'L18', 'L19')), (23, 25, 'PDW (fL)', ('L23', 'L24', 'L25'))]:
    g = collections.OrderedDict(zip(G6, [col(S+'7a', c, r1, r2) for c in 'BCDE']))
    tukey('Supp 7a', S+'7a', lab + ' - STAT5-IN-1', g, [('Veh', 'Cre', pcs[0]), ('Veh', 'Veh+STAT5i', pcs[1]), ('Veh', 'Cre+STAT5i', pcs[2]), ('Cre', 'Cre+STAT5i', None)])
for (r1, r2, lab, pcs) in [(4, 6, 'PLT (x10^9/L)', ('K4', 'K5', 'K6')), (10, 12, 'PCT (%)', ('K10', 'K11', 'K12')), (16, 18, 'MPV (fL)', ('K16', 'K17', 'K18')), (22, 24, 'PDW (fL)', ('K22', 'K23', 'K24'))]:
    g = collections.OrderedDict(zip(['WT-veh', 'WT-cre', 'Stat5bcKO-cre'], [col(S+'7b', c, r1, r2) for c in 'BCD']))
    tukey('Supp 7b', S+'7b', lab + ' - Pf4-iCre;Stat5b', g, [('WT-veh', 'WT-cre', pcs[0]), ('WT-veh', 'Stat5bcKO-cre', pcs[1]), ('WT-cre', 'Stat5bcKO-cre', pcs[2])], note='no Stat5b-cKO vehicle arm')
ttest('Supp 8a', S+'8a', 'Human BMI (kg/m2), d0 vs d14', ('C', 4, 14), ('D', 4, 14), ('d0', 'd14'), 'G5', unit='volunteers (n=11)')
for (r1, lab, pcs) in [(4, 'PLT (x10^9/L)', ('L4', 'L5', 'L6')), (19, 'PCT (%)', ('L19', 'L20', 'L21')), (33, 'MPV (fL)', ('L33', 'L34', 'L35')), (48, 'PDW (fL)', ('L48', 'L49', 'L50'))]:
    g = collections.OrderedDict(zip(D7, [col(S+'8b', c, r1, r1+10) for c in 'BCDE']))
    dunnett('Supp 8b', S+'8b', 'Human ' + lab, g, pcs, unit='volunteers (n=11)')

d1, d2, d3 = row(S+'8c', 6, 'I', 'K'), row(S+'8c', 7, 'I', 'K'), row(S+'8c', 7, 'M', 'O')
g = collections.OrderedDict([('CD41+ cells', 2.0**d1/np.mean(2.0**d1)), ('Isolated monocytes', 2.0**(d2-d1)), ('MEG-01', 2.0**(d3-d1))])
tukey('Supp 8c', S+'8c', 'CD41 mRNA (fold) - purity control for human CD41+ cells', g, [('CD41+ cells', 'Isolated monocytes', 'I15')], unit='samples')

EVD = pd.DataFrame(EV)
def _num(x):
    try: return float(x)
    except Exception: return np.nan
EVD['p_reported_num'] = EVD.p_reported_in_sheet.map(_num)
def _agree(r):
    rep = r.p_reported_in_sheet
    if isinstance(rep, str) and rep.strip().startswith('>'): return 'consistent (reported as inequality)' if r.p_recomputed > float(rep.strip()[1:]) else 'CHECK'
    if isinstance(rep, str) and rep.strip().startswith('<'): return 'consistent (reported as inequality)' if r.p_recomputed < float(rep.strip()[1:]) else 'CHECK'
    if pd.isna(r.p_reported_num): return 'n/a (comparison added here; not tested in sheet)'
    a, b = r.p_recomputed, r.p_reported_num
    if (a < 1e-9 and b < 1e-9) or abs(a-b) <= max(6e-4, 0.06*b): return 'reproduced'
    return 'CHECK'
EVD['agreement'] = EVD.apply(_agree, axis=1)
EVD.to_csv(os.path.join(TAB, 'evidence_table_all_panels.csv'), index=False)
print('Rows:', len(EVD), '| embedded tests with numeric p reproduced:', (EVD.agreement == 'reproduced').sum(), '| reported as inequality and consistent:', EVD.agreement.str.startswith('consistent').sum(), '| CHECK:', (EVD.agreement == 'CHECK').sum(), '| added comparisons (not in sheet):', EVD.agreement.str.startswith('n/a').sum())
print(EVD[EVD.agreement == 'CHECK'][['panel', 'readout', 'p_recomputed', 'p_reported_in_sheet']].to_string())

# ----------------------------------------------------------------------------------------------
# 2. Creatine effect on lung metastasis across every vehicle-vs-creatine comparison (meta-analysis)
# ----------------------------------------------------------------------------------------------
COH = [
 ('Fig 1b', 'Fig. 1b', ('B', 3, 8), ('C', 3, 8), ('B', 12, 17), ('C', 12, 17), 'gavage'),
 ('Fig 1k', 'Fig. 1k', ('B', 4, 9), ('C', 4, 9), ('B', 12, 17), ('C', 12, 17), 'gavage'),
 ('Fig 1f, sh-scrambled tumour', 'Fig. 1f', ('B', 22, 27), ('C', 22, 27), ('B', 31, 36), ('C', 31, 36), 'gavage'),
 ('Fig 1f, sh-Slc6a8 tumour', 'Fig. 1f', ('D', 22, 27), ('E', 22, 27), ('D', 31, 36), ('E', 31, 36), 'gavage'),
 ('Fig 3i, Pf4-Cre;Slc6a8+/+', 'Fig. 3i', ('B', 10, 13), ('C', 10, 13), ('B', 17, 20), ('C', 17, 20), 'gavage'),
 ('Fig 6b, no inhibitor', 'Fig. 6b', ('B', 4, 8), ('C', 4, 8), ('B', 13, 17), ('C', 13, 17), 'gavage'),
 ('Supp 1e', S+'1e', ('B', 13, 18), ('C', 13, 18), ('B', 22, 27), ('C', 22, 27), 'gavage'),
 ('Supp 1f', S+'1f', ('B', 12, 15), ('C', 12, 15), ('B', 20, 23), ('C', 20, 23), 'gavage'),
 ('Supp 1g', S+'1g', ('B', 15, 24), ('C', 15, 24), ('B', 28, 37), ('C', 28, 37), 'gavage'),
 ('Supp 1i, 5% diet', S+'1i', ('B', 11, 14), ('C', 11, 14), ('B', 18, 21), ('C', 18, 21), 'diet'),
 ('Supp 1k', S+'1k', ('B', 16, 25), ('C', 16, 25), ('B', 29, 38), ('C', 29, 38), 'gavage'),
]
rows = []; ss_b = df_b = ss_f = 0.0
for name, sh, bv, bc, fv, fc, route in COH:
    bv, bc, fv, fc = col(sh, *bv), col(sh, *bc), col(sh, *fv), col(sh, *fc)
    lv, lc = np.log(bv), np.log(bc); d = lc.mean()-lv.mean(); se = np.sqrt(lv.var(ddof=1)/len(lv)+lc.var(ddof=1)/len(lc))
    lfv, lfc = np.log(fv), np.log(fc); dfo = lfc.mean()-lfv.mean(); sef = np.sqrt(lfv.var(ddof=1)/len(lfv)+lfc.var(ddof=1)/len(lfc))
    for a in (lv, lc): ss_b += ((a-a.mean())**2).sum(); df_b += len(a)-1
    for a in (lfv, lfc): ss_f += ((a-a.mean())**2).sum()
    rows.append(dict(cohort=name, route=route, n_vehicle=len(bv), n_creatine=len(bc), burden_vehicle_mean=bv.mean(), burden_creatine_mean=bc.mean(),
                     burden_ratio_of_means=bc.mean()/bv.mean(), burden_geo_ratio=np.exp(d), lo95=np.exp(d-1.96*se), hi95=np.exp(d+1.96*se), ln_ratio=d, se_ln=se,
                     foci_vehicle_mean=fv.mean(), foci_creatine_mean=fc.mean(), foci_geo_ratio=np.exp(dfo), foci_ln_ratio=dfo, foci_se_ln=sef))
META = pd.DataFrame(rows)
def dersimonian_laird(y, se):
    w = 1/se**2; yb = (w*y).sum()/w.sum(); Q = (w*(y-yb)**2).sum(); k = len(y); C = w.sum()-(w**2).sum()/w.sum(); tau2 = max(0, (Q-(k-1))/C)
    ws_ = 1/(se**2+tau2); mu = (ws_*y).sum()/ws_.sum(); semu = np.sqrt(1/ws_.sum()); I2 = max(0, (Q-(k-1))/Q)*100
    return mu, semu, tau2, I2
mu_b, se_b, tau_b, I2_b = dersimonian_laird(META.ln_ratio.values, META.se_ln.values)
mu_f, se_f, tau_f, I2_f = dersimonian_laird(META.foci_ln_ratio.values, META.foci_se_ln.values)
SD_LNB = np.sqrt(ss_b/df_b); SD_LNF = np.sqrt(ss_f/df_b)
META.to_csv(os.path.join(TAB, 'creatine_effect_by_cohort.csv'), index=False)
pooled = pd.DataFrame([dict(endpoint='metastatic burden', k=len(META), total_animals=int(META.n_vehicle.sum()+META.n_creatine.sum()), pooled_ratio=np.exp(mu_b), lo95=np.exp(mu_b-1.96*se_b), hi95=np.exp(mu_b+1.96*se_b), I2_pct=I2_b, pooled_within_group_SD_ln=SD_LNB),
                       dict(endpoint='metastatic foci', k=len(META), total_animals=int(META.n_vehicle.sum()+META.n_creatine.sum()), pooled_ratio=np.exp(mu_f), lo95=np.exp(mu_f-1.96*se_f), hi95=np.exp(mu_f+1.96*se_f), I2_pct=I2_f, pooled_within_group_SD_ln=SD_LNF)])
_m = META.cohort != 'Fig 6b, no inhibitor'; mu_x, se_x, _, I2_x = dersimonian_laird(META.ln_ratio.values[_m], META.se_ln.values[_m])
pooled = pd.concat([pooled, pd.DataFrame([dict(endpoint='metastatic burden, SENSITIVITY excluding Fig 6b (values shared with Supp 2d)', k=int(_m.sum()), total_animals=int((META.n_vehicle+META.n_creatine)[_m].sum()), pooled_ratio=np.exp(mu_x), lo95=np.exp(mu_x-1.96*se_x), hi95=np.exp(mu_x+1.96*se_x), I2_pct=I2_x, pooled_within_group_SD_ln=np.nan)])], ignore_index=True)
pooled.to_csv(os.path.join(TAB, 'creatine_effect_pooled.csv'), index=False)
print('\nCreatine effect, pooled (random effects):'); print(pooled.round(3).to_string(index=False))

# ----------------------------------------------------------------------------------------------
# 3. Does each perturbation remove the creatine effect?  2x2 interaction tests + % abrogation
# ----------------------------------------------------------------------------------------------
def twoway(label, source, readout, g, log=False, nboot=20000):
    """g = [intact-vehicle, intact-creatine, perturbed-vehicle, perturbed-creatine]"""
    d = pd.DataFrame([(a, b, v) for (a, b), arr in zip([(0, 0), (0, 1), (1, 0), (1, 1)], g) for v in arr], columns=['A', 'B', 'y'])
    if log: d['y'] = np.log(d['y'])
    m = smf.ols('y ~ A*B', d).fit()
    e0 = np.mean(g[1])-np.mean(g[0]); e1 = np.mean(g[3])-np.mean(g[2]); ab = []
    for _ in range(nboot):
        s = [rng.choice(x, len(x), replace=True) for x in g]; b0 = s[1].mean()-s[0].mean()
        if b0 != 0: ab.append(1-(s[3].mean()-s[2].mean())/b0)
    lo, hi = np.percentile(ab, [2.5, 97.5])
    return dict(experiment=label, source=source, readout=readout + (' [ln scale]' if log else ''), n_per_group='/'.join(str(len(x)) for x in g),
                creatine_effect_intact=e0, fold_intact=np.mean(g[1])/np.mean(g[0]), creatine_effect_perturbed=e1, fold_perturbed=np.mean(g[3])/np.mean(g[2]),
                interaction_p=m.pvalues['A:B'], pct_abrogation=100*(1-e1/e0), boot_lo95=100*lo, boot_hi95=100*hi,
                baseline_shift_perturbed_vs_intact_vehicle=np.mean(g[2])/np.mean(g[0]), baseline_p=stats.ttest_ind(g[0], g[2])[1])
INT = []
for (r1, r2, lab) in [(22, 27, 'Metastatic burden (%)'), (31, 36, 'Metastatic foci'), (4, 9, 'Lung weight (g)'), (13, 18, 'SUV-BW')]:
    g = [col('Fig. 1f', c, r1, r2) for c in 'BCDE']; INT.append(twoway('Tumour-cell sh-Slc6a8 x creatine', 'Fig 1f', lab, g))
    if 'burden' in lab: INT.append(twoway('Tumour-cell sh-Slc6a8 x creatine', 'Fig 1f', lab, g, log=True))
for (r1, r2, lab) in [(10, 13, 'Metastatic burden (%)'), (17, 20, 'Metastatic foci'), (3, 6, 'Lung weight (g)')]:
    g = [col('Fig. 3i', c, r1, r2) for c in 'BCDE']; INT.append(twoway('MK-lineage Slc6a8 deletion x creatine', 'Fig 3i', lab, g))
    if 'burden' in lab: INT.append(twoway('MK-lineage Slc6a8 deletion x creatine', 'Fig 3i', lab, g, log=True))
for (r1, r2, lab) in [(4, 8, 'Metastatic burden (%)'), (13, 17, 'Metastatic foci')]:
    g = [col('Fig. 6b', c, r1, r2) for c in 'BCDE']; INT.append(twoway('STAT5-IN-1 (STAT5A+B) x creatine', 'Fig 6b', lab, g))
    if 'burden' in lab: INT.append(twoway('STAT5-IN-1 (STAT5A+B) x creatine', 'Fig 6b', lab, g, log=True))
    g2 = [np.delete(g[0], [1, 2, 3]), np.delete(g[1], [1, 2, 3]), g[2], g[3]]
    INT.append(twoway('STAT5-IN-1 x creatine - SENSITIVITY: excluding the 3+3 values shared with Supp 2d', 'Fig 6b', lab, g2))
for r, lab in [(4, 'ADP'), (5, 'Collagen'), (6, 'Thrombin')]:
    g = [row('Fig. 3d', r, 'B', 'D'), row('Fig. 3d', r, 'E', 'G'), row('Fig. 3d', r, 'H', 'J'), row('Fig. 3d', r, 'K', 'M')]
    INT.append(twoway('MK-lineage Slc6a8 deletion x creatine', 'Fig 3d', f'Platelet aggregation to {lab} (%)', g))
g = [row('Fig. 3c', 4, 'B', 'D'), row('Fig. 3c', 4, 'E', 'G'), row('Fig. 3c', 5, 'B', 'D'), row('Fig. 3c', 5, 'E', 'G')]
INT.append(twoway('MK-lineage Slc6a8 deletion x creatine', 'Fig 3c', 'MK intracellular creatine', g))
g = [row('Fig. 3b', 4, 'B', 'F'), row('Fig. 3b', 4, 'G', 'K'), row('Fig. 3b', 5, 'B', 'F'), row('Fig. 3b', 5, 'G', 'K')]
INT.append(twoway('MK-lineage Slc6a8 deletion x creatine', 'Fig 3b', 'Serum creatine (uM)', g))
g = [col(S+'4c', c, 6, 13) for c in 'CDEF']; INT.append(twoway('MK-lineage Slc6a8 deletion x creatine', 'Supp 4c', 'alpha-granules per field (fields, not animals)', g))
INTD = pd.DataFrame(INT); INTD.to_csv(os.path.join(TAB, 'interaction_tests_2x2.csv'), index=False)
print('\n2x2 interaction tests:'); print(INTD[['experiment', 'source', 'readout', 'n_per_group', 'fold_intact', 'fold_perturbed', 'interaction_p', 'pct_abrogation', 'boot_lo95', 'boot_hi95', 'baseline_shift_perturbed_vs_intact_vehicle', 'baseline_p']].round(4).to_string(index=False))

# platelet-transfer experiments, incl. sensitivity to the duplicated values
h = [col(S+'2d', c, 5, 10) for c in 'CDE']; hf = [col(S+'2d', c, 14, 19) for c in 'CDE']
PT = []
for lab, gg in [('all values (n=6/6/6)', h), ('excluding the 3+3 values shared with Fig 6b (n=3/3/6)', [h[0][:3], h[1][:3], h[2]])]:
    r = stats.tukey_hsd(*gg)
    PT.append(dict(analysis='Supp 2d burden, ' + lab, veh=gg[0].mean(), cre=gg[1].mean(), cre_aspirin=gg[2].mean(), p_veh_vs_cre=r.pvalue[0, 1], p_cre_vs_cre_aspirin=r.pvalue[1, 2], p_veh_vs_cre_aspirin=r.pvalue[0, 2]))
a, b = col('Fig. 7g', 'B', 12, 16), col('Fig. 7g', 'C', 12, 16)
PT.append(dict(analysis='Fig 7g burden, human d0 vs d7 platelets (n=5/5 recipient mice)', veh=a.mean(), cre=b.mean(), cre_aspirin=np.nan, p_veh_vs_cre=stats.ttest_ind(a, b)[1], p_cre_vs_cre_aspirin=np.nan, p_veh_vs_cre_aspirin=np.nan))
pd.DataFrame(PT).to_csv(os.path.join(TAB, 'platelet_transfer.csv'), index=False)
print('\nPlatelet transfer:'); print(pd.DataFrame(PT).round(4).to_string(index=False))

# ----------------------------------------------------------------------------------------------
# 4. Megakaryocyte 'platelet-activation' gene programme (11 genes) across every node
# ----------------------------------------------------------------------------------------------
G11 = ['Itga2b', 'P2ry12', 'Gp6', 'Gp1ba', 'F2r', 'Adra2a', 'Fcgr2a', 'Runx1', 'Rab4a', 'Rab27b', 'Pitpnb']
def qget(sheet, r0, grpcols):
    out = {}
    for i, gname in enumerate(G11):
        r = r0+5*i; ctrl = row(sheet, r, *grpcols[0]); out[gname] = [ctrl] + [row(sheet, r+1, c1, c2) for (c1, c2) in grpcols]
    return out
QEXP = collections.OrderedDict([
 ('Fig 2f', (qget('Fig. 2f', 4, [('G', 'I')]), ['Vehicle', 'Creatine'], 'MKs from dosed mice')),
 ('Fig 3f', (qget('Fig. 3f', 8, [('G', 'I'), ('K', 'M'), ('O', 'Q')]), ['WT-veh', 'WT-cre', 'Slc6a8cKO-veh', 'Slc6a8cKO-cre'], 'MKs, Pf4-Cre;Slc6a8')),
 ('Fig 4h', (qget('Fig. 4h', 7, [('G', 'I'), ('K', 'M')]), ['Control', 'Creatine', 'Phosphocreatine'], 'MKs in vitro')),
 ('Fig 4j', (qget('Fig. 4j', 8, [('G', 'I'), ('K', 'M'), ('O', 'Q')]), ['Ctrl+siScr', 'Ctrl+siCkb', 'Cre+siScr', 'Cre+siCkb'], 'MKs in vitro, si-Ckb')),
 ('Fig 4l', (qget('Fig. 4l', 6, [('G', 'I')]), ['CKB-EV', 'CKB-OE'], 'MKs in vitro, CKB over-expression')),
 ('Fig 6a', (qget('Fig.6a', 7, [('G', 'I'), ('K', 'M'), ('O', 'Q')]), ['Veh', 'Cre', 'Veh+STAT5i', 'Cre+STAT5i'], 'MKs, STAT5-IN-1')),
 ('Fig 6g', (qget('Fig. 6g', 5, [('G', 'I'), ('K', 'M')]), ['WT-veh', 'WT-cre', 'Stat5bcKO-cre'], 'MKs, Pf4-iCre;Stat5b')),
 ('Supp 4e', (qget(S+'4e', 8, [('G', 'I'), ('K', 'M')]), ['Control', 'Creatine', 'Creatine@liposome'], 'Slc6a8-cKO MKs in vitro')),
])
QL = []; COMP = {}
for k, (d, names, desc) in QEXP.items():
    per = {nm: [] for nm in names}
    for gname in G11:
        arrs = d[gname]; mc = arrs[0].mean()
        for nm, a in zip(names, arrs): per[nm].append(a-mc)            # log2 fold vs mean control dCT (sheet dCT: higher = more transcript)
    for nm in names:
        M = np.array(per[nm]); COMP[(k, nm)] = M.mean(axis=0)
        for gi, gname in enumerate(G11):
            QL.append(dict(panel=k, system=desc, group=nm, gene=gname, n=M.shape[1], geo_mean_fold=2**M[gi].mean(), log2fc_mean=M[gi].mean(), log2fc_sd=M[gi].std(ddof=1)))
QLD = pd.DataFrame(QL); QLD.to_csv(os.path.join(TAB, 'mk_gene_panel_long.csv'), index=False)
QM = QLD.pivot_table(index=['panel', 'system', 'group'], columns='gene', values='geo_mean_fold', sort=False)[G11]
QM['COMPOSITE (geo-mean of 11 genes)'] = [2**COMP[(p, g)].mean() for (p, s, g) in QM.index]
QM.round(2).to_csv(os.path.join(TAB, 'mk_gene_panel_fold_matrix.csv'))
print('\nMK programme, geometric-mean fold vs own control:'); print(QM.round(2).to_string())
def block(k, base, cre, pbase, pcre):
    b, c, pc = COMP[(k, base)].mean(), COMP[(k, cre)].mean(), COMP[(k, pcre)].mean(); out = dict(panel=k, induction_fold=2**(c-b), perturbed_creatine_vs_control_fold=2**(pc-b), pct_block_vs_control=100*(1-(pc-b)/(c-b)))
    if pbase: pb = COMP[(k, pbase)].mean(); out.update(perturbed_baseline_fold=2**(pb-b), perturbed_creatine_vs_own_baseline_fold=2**(pc-pb), pct_block_vs_own_baseline=100*(1-(pc-pb)/(c-b)))
    return out
BLK = pd.DataFrame([dict(node='SLC6A8 (Pf4-Cre;Slc6a8 fl/fl)', **block('Fig 3f', 'WT-veh', 'WT-cre', 'Slc6a8cKO-veh', 'Slc6a8cKO-cre')),
                    dict(node='CKB (si-Ckb, in vitro)', **block('Fig 4j', 'Ctrl+siScr', 'Cre+siScr', 'Ctrl+siCkb', 'Cre+siCkb')),
                    dict(node='STAT5A+B (STAT5-IN-1)', **block('Fig 6a', 'Veh', 'Cre', 'Veh+STAT5i', 'Cre+STAT5i')),
                    dict(node='STAT5B (Pf4-iCre;Stat5b fl/fl; no cKO-vehicle arm)', **block('Fig 6g', 'WT-veh', 'WT-cre', None, 'Stat5bcKO-cre'))])
BLK.to_csv(os.path.join(TAB, 'mk_programme_block_by_node.csv'), index=False)
print('\nBlock of the creatine-induced MK programme by node:'); print(BLK.round(2).to_string(index=False))
# residual induction of the two effector genes in the Stat5b cKO
res = QLD[(QLD.panel == 'Fig 6g') & (QLD.gene.isin(['Gp6', 'P2ry12']))][['group', 'gene', 'geo_mean_fold']]
print(res.round(2).to_string(index=False))

# ----------------------------------------------------------------------------------------------
# 5. Human volunteers: exposure, paired platelet-function analysis, expression (n=4)
# ----------------------------------------------------------------------------------------------
cr = [col('Fig. 7b', c, 4, 14) for c in 'BCDE']
EXPO = [dict(system='Human, 20 g/day, fasting serum (Fig 7b)', baseline_uM=cr[0].mean(), on_creatine_uM=np.mean([cr[1].mean(), cr[2].mean(), cr[3].mean()]), fold=np.mean([cr[1].mean(), cr[2].mean(), cr[3].mean()])/cr[0].mean(), n=11)]
for lab, sh, a, b in [('Mouse gavage (Supp 1d)', S+'1d', ('B', 4, 9), ('C', 4, 9)), ('Mouse 5% diet (Supp 1h)', S+'1h', ('C', 4, 7), ('D', 4, 7))]:
    x, y = col(sh, *a), col(sh, *b); EXPO.append(dict(system=lab, baseline_uM=x.mean(), on_creatine_uM=y.mean(), fold=y.mean()/x.mean(), n=len(x)))
x, y = row('Fig. 3b', 4, 'B', 'F'), row('Fig. 3b', 4, 'G', 'K'); EXPO.append(dict(system='Mouse gavage, Pf4-Cre;Slc6a8+/+ (Fig 3b)', baseline_uM=x.mean(), on_creatine_uM=y.mean(), fold=y.mean()/x.mean(), n=5))
x, y = row('Fig. 3b', 5, 'B', 'F'), row('Fig. 3b', 5, 'G', 'K'); EXPO.append(dict(system='Mouse gavage, Pf4-Cre;Slc6a8fl/fl (Fig 3b)', baseline_uM=x.mean(), on_creatine_uM=y.mean(), fold=y.mean()/x.mean(), n=5))
pd.DataFrame(EXPO).to_csv(os.path.join(TAB, 'serum_creatine_exposure.csv'), index=False)
print('\nSerum creatine exposure:'); print(pd.DataFrame(EXPO).round(2).to_string(index=False))

HP = []
for (ag, met), g in H7C.items():
    d = stats.dunnett(g['d3'], g['d7'], g['d14'], control=g['d0'])
    for i, day in enumerate(['d3', 'd7', 'd14']):
        x = g[day]; lx = np.log2(np.clip(x, 1e-3, None))      # two zero values (AA) clipped for the log; Wilcoxon is on raw fold-1
        HP.append(dict(agonist=ag, metric=met, day=day, n=len(x), mean_fold=x.mean(), median_fold=np.median(x), geo_mean_fold=2**lx.mean(), n_increased=int((x > 1).sum()),
                       p_dunnett_unpaired_as_in_sheet=d.pvalue[i], p_one_sample_t_log2=stats.ttest_1samp(lx, 0)[1], p_wilcoxon_signed_rank=stats.wilcoxon(x-1).pvalue, sd_log2=lx.std(ddof=1)))
HPD = pd.DataFrame(HP); HPD.to_csv(os.path.join(TAB, 'human_platelet_function_paired.csv'), index=False)
print('\nHuman platelet function (paired re-analysis of Fig 7c):'); print(HPD[HPD.metric == 'max aggregation'].round(4).to_string(index=False))
c14, e14, a14, d14 = [H7C[(k, 'max aggregation')]['d14'] for k in ('collagen', 'EPI', 'AA', 'ADP')]
print('  d14 cross-agonist Spearman (rows of Fig 7c = volunteers): collagen~EPI rho=%.2f p=%.3f ; collagen~ADP rho=%.2f p=%.2f ; AA~ADP rho=%.2f p=%.3f' % (*stats.spearmanr(c14, e14), *stats.spearmanr(c14, d14), *stats.spearmanr(a14, d14)))
print('  volunteers with >=2-fold collagen max aggregation at d14: %d/11 ; >=1.5-fold EPI: %d/11' % ((c14 >= 2).sum(), (e14 >= 1.5).sum()))

HE = []
for r1, lab in [(4, 'GP6'), (12, 'P2RY12')]:
    g = [col('Fig. 7e', c, r1, r1+3) for c in 'BCDE']
    for i, day in [(1, 'd3'), (2, 'd7'), (3, 'd14')]:
        ratio = g[i]/g[0]; HE.append(dict(readout=f'{lab} protein / b-ACTIN, platelets (Fig 7e)', day=day, n=4, per_volunteer_fold=' '.join(f'{v:.2f}' for v in ratio), geo_mean_fold=np.exp(np.log(ratio).mean()), n_increased=int((ratio > 1).sum()), p_paired_t=stats.ttest_rel(g[i], g[0])[1]))
w7 = ws('Fig. 7d')
B7D = [('ITGA2B', 'C', 7), ('P2RY12', 'I', 7), ('GP6', 'C', 26), ('GP1BA', 'I', 26), ('F2R', 'C', 45), ('ADRA2A', 'I', 45), ('FCGR2A', 'C', 64), ('RUNX1', 'I', 64), ('RAB4A', 'C', 83), ('RAB27B', 'I', 83), ('PITPNB', 'C', 101)]
H7D_sheet = {}; MISM = []
for gene, c0, r0 in B7D:
    ci = CI(c0); dct = np.array([[[w7.cell(row=r0+t*3+rep, column=ci+v).value for v in range(4)] for rep in range(3)] for t in range(4)], float)
    m = dct.mean(axis=1); rec = 2.0**(m-m[0]); sh = np.array([[w7.cell(row=r0+12+t, column=ci+v).value for v in range(4)] for t in range(4)], float); H7D_sheet[gene] = sh
    for t, day in [(1, 'd3'), (2, 'd7'), (3, 'd14')]:
        HE.append(dict(readout=f'{gene} mRNA, circulating CD41+ cells (Fig 7d)', day=day, n=4, per_volunteer_fold=' '.join(f'{v:.2f}' for v in sh[t]), geo_mean_fold=np.exp(np.log(sh[t]).mean()), n_increased=int((sh[t] > 1).sum()), p_paired_t=stats.ttest_1samp(np.log2(sh[t]), 0)[1]))
        for v in range(4):
            if abs(np.log2(sh[t, v]/rec[t, v])) > np.log2(1.5):
                MISM.append(dict(gene=gene, volunteer=v+1, day=day, normalised_value_in_sheet=sh[t, v], recomputed_from_sheet_dCT=rec[t, v], technical_SD_dCT_baseline=dct[0, :, v].std(ddof=1), baseline_dCT_values=' '.join(f'{x:.2f}' for x in dct[0, :, v])))
HED = pd.DataFrame(HE); HED.to_csv(os.path.join(TAB, 'human_expression_n4.csv'), index=False)
pd.DataFrame(MISM).to_csv(os.path.join(TAB, 'qc_fig7d_normalisation_mismatches.csv'), index=False)
print('\nHuman expression (n=4):'); print(HED.round(3).to_string(index=False))
print('\nFig 7d cells where sheet normalised value differs >1.5x from value recomputed from the sheet dCT:'); print(pd.DataFrame(MISM).round(3).to_string(index=False))
comp7 = np.mean([np.log2(H7D_sheet[g]) for g, _, _ in B7D], axis=0)
print('  human 11-gene composite log2FC per volunteer: d3', np.round(comp7[1], 2), 'd7', np.round(comp7[2], 2), 'd14', np.round(comp7[3], 2))
print('  geo-mean fold d7 %.2f (p=%.3f), d14 %.2f (p=%.3f)' % (2**comp7[2].mean(), stats.ttest_1samp(comp7[2], 0)[1], 2**comp7[3].mean(), stats.ttest_1samp(comp7[3], 0)[1]))

# ----------------------------------------------------------------------------------------------
# 6. Phosphoproteomics (n=3 mice/group): multiplicity
# ----------------------------------------------------------------------------------------------
ph = pd.read_excel(PHO, sheet_name=0); ph.columns = ['gene', 'p', 'q', 'log_fc']; ph['excel_row'] = ph.index+2
tie = np.isclose(ph.p, 0.42265, atol=2e-5)
bh = multipletests(ph.p, method='fdr_bh')[1]; ph['bh_q_recomputed'] = bh; ph['rank_by_p'] = ph.p.rank(method='min').astype(int)
crit = ph[(ph.p < 0.05) & ((2**ph.log_fc >= 1.2) | (2**ph.log_fc <= 0.83))]
PS = dict(n_phosphopeptide_rows=len(ph), n_genes=ph.gene.nunique(), n_rows_without_gene=int(ph.gene.isna().sum()), n_p_lt_0_05=int((ph.p < 0.05).sum()), expected_p_lt_0_05_if_all_null=0.05*len(ph),
          n_rows_with_identical_p_0_42265=int(tie.sum()), n_p_lt_0_05_excluding_ties=int((ph.p[~tie] < 0.05).sum()), expected_excluding_ties=0.05*int((~tie).sum()),
          n_meeting_study_screen_criteria=len(crit), n_up=int((crit.log_fc > 0).sum()), n_down=int((crit.log_fc < 0).sum()),
          min_q_in_file=ph.q.min(), n_q_lt_0_05=int((ph.q < 0.05).sum()), n_q_lt_0_10=int((ph.q < 0.10).sum()), min_bh_q_recomputed=bh.min(), bonferroni_threshold=0.05/len(ph), min_p=ph.p.min())
pd.DataFrame([PS]).T.to_csv(os.path.join(TAB, 'phosphoproteomics_summary.csv'), header=['value'])
ph.sort_values('p').head(40).to_csv(os.path.join(TAB, 'phosphoproteomics_top40_by_p.csv'), index=False)
ph[ph.gene.isin(['Stat5b', 'Stat5a', 'Stat1', 'Stat4', 'Jak2', 'Nfkb2'])].sort_values(['gene', 'p']).to_csv(os.path.join(TAB, 'phosphoproteomics_stat_rows.csv'), index=False)
print('\nPhosphoproteomics summary:'); [print(f'  {k}: {v}') for k, v in PS.items()]
print(ph[ph.gene.isin(['Stat5b', 'Stat5a'])].round(4).to_string(index=False))

# ----------------------------------------------------------------------------------------------
# 7. Data-integrity checks
# ----------------------------------------------------------------------------------------------
QPCR = {'Fig. 2f', 'Fig. 3f', 'Fig. 4h', 'Fig. 4j', 'Fig. 4l', 'Fig.6a', 'Fig. 6g', 'Supplementary Fig  4e', 'Supplementary Fig  3c', 'Fig. 4e', 'Supplementary Fig  2a', 'Supplementary Fig  5a', 'Supplementary Fig  8c', 'Fig. 7d'}
occ = collections.defaultdict(list)
for w in WB.worksheets:
    if w.title.strip() in QPCR: continue                     # dCT values are rounded to 2 d.p. by the instrument -> coincidental repeats expected
    for rw in w.iter_rows():
        for c in rw:
            if isinstance(c.value, (int, float)) and not isinstance(c.value, bool):
                s = repr(float(c.value)); digits = re.sub(r'[^0-9]', '', s.split('e')[0]).strip('0')
                if len(digits) >= 5: occ[s].append((w.title.strip(), c.coordinate))
DUP = [dict(value=float(s), occurrences='; '.join(f"'{a}'!{b}" for a, b in lst)) for s, lst in occ.items() if len(set(a for a, _ in lst)) > 1]
pd.DataFrame(DUP).to_csv(os.path.join(TAB, 'qc_duplicate_values_across_panels.csv'), index=False)
print('\nValues (>=5 significant digits) that occur in more than one non-qPCR panel:'); print(pd.DataFrame(DUP).to_string(index=False))
print('  foci, Fig 6b vehicle/creatine:', col('Fig. 6b', 'B', 13, 17), col('Fig. 6b', 'C', 13, 17)); print('  foci, Supp 2d vehicle/creatine donors:', col(S+'2d', 'C', 14, 19), col(S+'2d', 'D', 14, 19))

# other consistency checks
a, b = row('Fig. 3c', 4, 'B', 'D'), row('Fig. 3c', 5, 'B', 'D')
agg3d = np.concatenate([row('Fig. 3d', r, 'B', 'M') for r in (4, 5, 6)])
QC = [dict(check='Fig 3c vehicle means, Slc6a8+/+ vs fl/fl', finding=f'{a.mean():.4f} vs {b.mean():.4f} (individual values {np.round(a, 2)} vs {np.round(b, 2)})', implication='near-identical means: confirm values were not normalised per genotype before reading this as "no baseline difference"'),
      dict(check='Fig 3d aggregation values', finding=f'all {len(agg3d)} values are even integers: {bool(np.all(agg3d % 2 == 0))}; within-group SD 1.15-2.0 points at n=3', implication='2-point read-out resolution; p-values overstate precision'),
      dict(check='Fig 7c human aggregation', finding='only fold-of-day-0 values are given (day 0 = 1 for all); max fold %.1f' % max(g['d14'].max() for g in H7C.values()), implication='raw % aggregation absent; ratios from low baselines are unstable; medians/geometric means and paired tests used'),
      dict(check='Fig 7d PITPNB volunteer 4', finding='"dCT" cells contain values of +26 to +28 (C101:F112, column F)', implication='raw Ct entered instead of dCT; sheet normalised values not reproducible for this volunteer'),
      dict(check='Fig 6b vs Supp 2d', finding='3 vehicle + 3 creatine burden values and the matching foci counts are identical in both panels', implication='two different experiments cannot share animals; trace to raw records before relying on either panel'),
      dict(check='Tumour-cell knock-down reagent', finding="labelled sh-Slc6a8 in Fig 1f headers and Supp 2a blot, but si-Slc6a8 in Fig 1f!G5 and in the Supp 2a qPCR header", implication='stable vs transient knock-down not documented; protein reduction on the blot is partial'),
      dict(check='Fig 4d header', finding="'Creatinine (umol/g)'", implication='study conventions state a creatine assay; treated as intracellular creatine'),
      dict(check='Phosphoproteomics file', finding='gene-level rows only; no phosphosite column; LOG_FOLDCHANGE base and sign not stated', implication='S127 assignment cannot be verified from the supplied table')]
pd.DataFrame(QC).to_csv(os.path.join(TAB, 'qc_flags.csv'), index=False)
print('\nQC flags:'); print(pd.DataFrame(QC).to_string(index=False))

# ----------------------------------------------------------------------------------------------
# 8. Power for the proposed in vivo study (uses only in-house variance and effect size)
# ----------------------------------------------------------------------------------------------
def power_interaction(n, delta, sd, alpha):
    se = np.sqrt(4*sd**2/n); df = 4*(n-1); tc = stats.t.ppf(1-alpha/2, df); return 1-stats.nct.cdf(tc, df, delta/se)+stats.nct.cdf(-tc, df, delta/se)
def power_two_group(n, delta, sd, alpha):
    se = np.sqrt(2*sd**2/n); df = 2*(n-1); tc = stats.t.ppf(1-alpha/2, df); return 1-stats.nct.cdf(tc, df, delta/se)+stats.nct.cdf(-tc, df, delta/se)
PW = []
for n in (6, 8, 10, 12, 15, 20):
    for frac in (1.0, 0.75, 0.5):
        PW.append(dict(n_per_cell=n, abrogation_to_detect_pct=int(100*frac), interaction_ln_units=frac*mu_b, sd_ln_burden=SD_LNB, power_alpha_0_05=power_interaction(n, frac*mu_b, SD_LNB, 0.05), power_alpha_0_025=power_interaction(n, frac*mu_b, SD_LNB, 0.025)))
PWD = pd.DataFrame(PW); PWD.to_csv(os.path.join(TAB, 'power_in_vivo_interaction.csv'), index=False)
print('\nPower, genotype x creatine interaction on ln(burden); creatine effect = x%.2f (ln %.3f), SD ln = %.3f' % (np.exp(mu_b), mu_b, SD_LNB)); print(PWD.round(3).to_string(index=False))
print('  n=12/group, two-group contrast: power to detect a 40%% lower baseline burden (ln 0.51) = %.2f ; 33%% lower (ln 0.405) = %.2f' % (power_two_group(12, np.log(1/0.6), SD_LNB, 0.05), power_two_group(12, np.log(1.5), SD_LNB, 0.05)))
# human: paired sample size for collagen / EPI d14 response vs placebo in a crossover (SD of within-subject log2 change from Fig 7c)
for ag in ('collagen', 'EPI'):
    x = np.log2(H7C[(ag, 'max aggregation')]['d14']); sdl = x.std(ddof=1)
    for ratio in (1.5, 1.3):
        dlt = np.log2(ratio); sd_diff = np.sqrt(2)*sdl          # crossover: difference of two within-subject changes, assumed independent
        n = ((stats.norm.ppf(0.975)+stats.norm.ppf(0.9))*sd_diff/dlt)**2
        print(f'  human crossover, {ag} max aggregation d14: observed geo-mean x{2**x.mean():.2f}, SD(log2)={sdl:.2f}; n to detect x{ratio} vs placebo at 90% power ~ {int(np.ceil(n))+2}')
HS = []
for ag in ('collagen', 'EPI'):
    x = np.log2(H7C[(ag, 'max aggregation')]['d14']); sdl = x.std(ddof=1); sd_diff = np.sqrt(2)*sdl
    for lab, dlt in [('observed in-house effect', x.mean()), ('half the observed effect (log scale)', x.mean()/2)]:
        for alpha in (0.05, 0.025):
            n = ((stats.norm.ppf(1-alpha/2)+stats.norm.ppf(0.9))*sd_diff/dlt)**2
            HS.append(dict(endpoint=f'{ag}-induced max aggregation, d14 vs baseline', effect=lab, fold_to_detect=2**dlt, sd_log2_within_subject=sdl, alpha_two_sided=alpha, power=0.9, n_crossover_completers=int(np.ceil(n))+2))
pd.DataFrame(HS).to_csv(os.path.join(TAB, 'power_human_crossover.csv'), index=False)
print('\nHuman crossover sample size (in-house variance):'); print(pd.DataFrame(HS).round(2).to_string(index=False))

# ----------------------------------------------------------------------------------------------
# 8b. Remaining qPCR panels without embedded statistics (maturation genes, CD41 purity)
# ----------------------------------------------------------------------------------------------
OT = []
for i, gname in enumerate(['Nfe2', 'Gata1', 'Zfpm1', 'Hsd3b1', 'Itgb3', 'Tubb1', 'Lims1', 'Myl9', 'Casp12']):
    r = 5+5*i; d1, d2 = row(S+'3c', r, 'G', 'I'), row(S+'3c', r+1, 'G', 'I'); a = 2.0**(d1-d1.mean()); b = 2.0**(d2-d1.mean())
    OT.append(dict(panel='Supp 3c', readout=f'{gname} mRNA in MKs, creatine vs vehicle (megakaryocyte maturation panel)', n='3/3', geo_mean_fold=2**(d2.mean()-d1.mean()), p_unpaired_t_on_dCT=stats.ttest_ind(d1, d2)[1]))
d1, d2, d3 = row(S+'8c', 6, 'I', 'K'), row(S+'8c', 7, 'I', 'K'), row(S+'8c', 7, 'M', 'O')
OT.append(dict(panel='Supp 8c', readout='CD41 mRNA: isolated monocytes vs human CD41+ cells (purity control)', n='3/3', geo_mean_fold=2**(d2.mean()-d1.mean()), p_unpaired_t_on_dCT=stats.ttest_ind(d1, d2)[1]))
OT.append(dict(panel='Supp 8c', readout='CD41 mRNA: MEG-01 line vs human CD41+ cells', n='3/3', geo_mean_fold=2**(d3.mean()-d1.mean()), p_unpaired_t_on_dCT=stats.ttest_ind(d1, d3)[1]))
for gname in G11:
    d = QEXP['Fig 2f'][0][gname]; OT.append(dict(panel='Fig 2f', readout=f'{gname} mRNA in MKs from creatine- vs vehicle-dosed mice', n='3/3', geo_mean_fold=2**(d[1].mean()-d[0].mean()), p_unpaired_t_on_dCT=stats.ttest_ind(d[0], d[1])[1]))
pd.DataFrame(OT).to_csv(os.path.join(TAB, 'qpcr_panels_without_embedded_stats.csv'), index=False)
print('\nqPCR panels without embedded statistics:'); print(pd.DataFrame(OT).round(4).to_string(index=False))

# ----------------------------------------------------------------------------------------------
# 9. Figures
# ----------------------------------------------------------------------------------------------
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 150, 'savefig.bbox': 'tight'})
CV, CC = '#6b7b8c', '#c0392b'
def strip(ax, groups, labels, colors, ylabel, title, log=False, annotate=None, mark=None, headroom=1.55):
    """individual values + mean bar; mark = {group_index: [value indices]} drawn with an open ring (same x as the point)"""
    top = 0
    for i, (g, c) in enumerate(zip(groups, colors)):
        x = i + np.linspace(-0.16, 0.16, len(g)); ax.scatter(x, g, s=16, color=c, alpha=0.9, zorder=3, edgecolor='white', linewidth=0.4)
        if mark and i in mark: ax.scatter(x[mark[i]], np.asarray(g)[mark[i]], s=52, facecolor='none', edgecolor='black', lw=0.9, zorder=5)
        m = np.exp(np.mean(np.log(g))) if log else np.mean(g); ax.hlines(m, i-0.3, i+0.3, color='black', lw=1.4, zorder=4); top = max(top, np.max(g))
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(labels, rotation=35, ha='right', fontsize=7.5); ax.set_ylabel(ylabel); ax.set_title(title, fontsize=8.5, loc='left')
    if log: ax.set_yscale('log')
    else: ax.set_ylim(0, top*headroom)
    if annotate: ax.text(0.03, 0.97, annotate, transform=ax.transAxes, va='top', ha='left', fontsize=7.2, bbox=dict(facecolor='white', edgecolor='0.7', boxstyle='round,pad=0.25'))

# Figure 1 - in vivo evidence
from matplotlib.ticker import NullFormatter
fig = plt.figure(figsize=(14.5, 8.2)); gs = fig.add_gridspec(2, 4, width_ratios=[1.5, 1, 1, 1], hspace=0.75, wspace=0.55)
ax = fig.add_subplot(gs[:, 0]); k = len(META); ypos = np.arange(k, 0, -1)
ax.errorbar(META.burden_geo_ratio, ypos, xerr=[META.burden_geo_ratio-META.lo95, META.hi95-META.burden_geo_ratio], fmt='s', color=CC, ecolor='0.35', capsize=2, ms=5)
ax.errorbar([np.exp(mu_b)], [0], xerr=[[np.exp(mu_b)-np.exp(mu_b-1.96*se_b)], [np.exp(mu_b+1.96*se_b)-np.exp(mu_b)]], fmt='D', color='black', capsize=3, ms=7)
ax.set_yticks(list(ypos)+[0]); ax.set_yticklabels([f'{c}  (n={a}/{b})' for c, a, b in zip(META.cohort, META.n_vehicle, META.n_creatine)]+[f'Pooled, random effects\n(k={k}, N={int(META.n_vehicle.sum()+META.n_creatine.sum())})'], fontsize=7.5)
ax.axvline(1, color='0.5', ls='--', lw=0.8); ax.set_xscale('log'); ax.set_xticks([1, 2, 3, 5, 8]); ax.set_xticklabels(['1', '2', '3', '5', '8']); ax.xaxis.set_minor_formatter(NullFormatter())
ax.set_xlabel('Lung metastatic burden, creatine / vehicle\n(geometric-mean ratio, 95% CI)'); ax.set_title(f'A  Creatine vs vehicle, every cohort\n    pooled x{np.exp(mu_b):.1f} (95% CI {np.exp(mu_b-1.96*se_b):.1f}-{np.exp(mu_b+1.96*se_b):.1f})', fontsize=8.5, loc='left')
def pi(exp_, src):
    return INTD[(INTD.experiment == exp_) & (INTD.source == src) & (INTD.readout == 'Metastatic burden (%)')].iloc[0]
r = pi('Tumour-cell sh-Slc6a8 x creatine', 'Fig 1f'); g = [col('Fig. 1f', c, 22, 27) for c in 'BCDE']
strip(fig.add_subplot(gs[0, 1]), g, ['sh-scr\nveh', 'sh-scr\ncreatine', 'sh-Slc6a8\nveh', 'sh-Slc6a8\ncreatine'], [CV, CC, CV, CC], 'Metastatic burden (%)', 'B  Tumour-cell Slc6a8\n    knock-down (Fig 1f), n=6', annotate=f'interaction p={r.interaction_p:.2f}\nabrogation {r.pct_abrogation:.0f}% [{r.boot_lo95:.0f}, {r.boot_hi95:.0f}]')
r = pi('MK-lineage Slc6a8 deletion x creatine', 'Fig 3i'); g = [col('Fig. 3i', c, 10, 13) for c in 'BCDE']
strip(fig.add_subplot(gs[0, 2]), g, ['Slc6a8+/+\nveh', 'Slc6a8+/+\ncreatine', 'Slc6a8 fl/fl\nveh', 'Slc6a8 fl/fl\ncreatine'], [CV, CC, CV, CC], 'Metastatic burden (%)', 'C  MK-lineage Slc6a8\n    deletion (Fig 3i), n=4', annotate=f'interaction p={r.interaction_p:.4f}\nabrogation {r.pct_abrogation:.0f}% [{r.boot_lo95:.0f}, {r.boot_hi95:.0f}]')
r = pi('STAT5-IN-1 (STAT5A+B) x creatine', 'Fig 6b'); g = [col('Fig. 6b', c, 4, 8) for c in 'BCDE']
strip(fig.add_subplot(gs[0, 3]), g, ['veh', 'creatine', 'veh +\nSTAT5-IN-1', 'creatine +\nSTAT5-IN-1'], [CV, CC, CV, CC], 'Metastatic burden (%)', 'D  STAT5-IN-1 (STAT5A+B,\n    systemic) (Fig 6b), n=5', annotate=f'interaction p={r.interaction_p:.0e}\nabrogation {r.pct_abrogation:.0f}% [{r.boot_lo95:.0f}, {r.boot_hi95:.0f}]\nrings: values also in Supp 2d', mark={0: [1, 2, 3], 1: [1, 2, 3]}, headroom=1.75)
g = [col(S+'2d', c, 5, 10) for c in 'CDE']
strip(fig.add_subplot(gs[1, 1]), g, ['veh-donor\nPLT', 'creatine-donor\nPLT', 'creatine+aspirin\ndonor PLT'], [CV, CC, '#2471a3'], 'Metastatic burden (%)', 'E  Platelet transfer +/- aspirin\n    (Supp 2d), n=6', annotate='no vehicle+aspirin arm\nrings: values also in Fig 6b', mark={0: [3, 4, 5], 1: [3, 4, 5]})
g = [col('Fig. 7g', c, 12, 16) for c in 'BC']
strip(fig.add_subplot(gs[1, 2]), g, ['human PLT\nday 0', 'human PLT\nday 7 of creatine'], [CV, CC], 'Metastatic burden (%)', 'F  Human platelets into mice\n    (Fig 7g), n=5 recipients', annotate=f'p={stats.ttest_ind(*g)[1]:.3f}')
axn = fig.add_subplot(gs[1, 3]); axn.axis('off')
axn.text(-0.12, 1, 'NOT IN THE PACKAGE\n\n- metastasis in Pf4-iCre;Stat5b fl/fl mice\n- any Stat5b-cKO vehicle arm\n- any in vivo CKB perturbation\n- any GP6 / P2RY12 blockade\n- platelet function under STAT5\n  inhibition or Stat5b deletion\n- any intervention that lowers\n  metastasis below vehicle baseline', va='top', fontsize=7.8, bbox=dict(facecolor='#fdf2e9', edgecolor='#e59866', boxstyle='round,pad=0.5'))
fig.savefig(os.path.join(FIG, 'fig1_in_vivo_evidence_by_node.png')); plt.close(fig)

# Figure 2 - MK programme by node
fig, ax = plt.subplots(figsize=(13.5, 4.6)); order = [('Fig 2f', 'Vehicle'), ('Fig 2f', 'Creatine'), None, ('Fig 3f', 'WT-veh'), ('Fig 3f', 'WT-cre'), ('Fig 3f', 'Slc6a8cKO-veh'), ('Fig 3f', 'Slc6a8cKO-cre'), None,
         ('Supp 4e', 'Control'), ('Supp 4e', 'Creatine'), ('Supp 4e', 'Creatine@liposome'), None, ('Fig 4h', 'Control'), ('Fig 4h', 'Creatine'), ('Fig 4h', 'Phosphocreatine'), None,
         ('Fig 4j', 'Ctrl+siScr'), ('Fig 4j', 'Cre+siScr'), ('Fig 4j', 'Ctrl+siCkb'), ('Fig 4j', 'Cre+siCkb'), None, ('Fig 4l', 'CKB-EV'), ('Fig 4l', 'CKB-OE'), None,
         ('Fig 6a', 'Veh'), ('Fig 6a', 'Cre'), ('Fig 6a', 'Veh+STAT5i'), ('Fig 6a', 'Cre+STAT5i'), None, ('Fig 6g', 'WT-veh'), ('Fig 6g', 'WT-cre'), ('Fig 6g', 'Stat5bcKO-cre')]
CRE_GROUPS = {'Creatine', 'WT-cre', 'Slc6a8cKO-cre', 'Creatine@liposome', 'Cre+siScr', 'Cre+siCkb', 'Cre', 'Cre+STAT5i', 'Stat5bcKO-cre'}
xt, xl = [], []
for i, key in enumerate(order):
    if key is None: continue
    v = COMP[key]; colr = CC if key[1] in CRE_GROUPS else ('#7d3c98' if key[1] in ('Phosphocreatine', 'CKB-OE') else CV)
    ax.bar(i, 2**v.mean()-1, bottom=1, color=colr, alpha=0.75, width=0.8); ax.scatter([i]*len(v), 2**v, s=12, color='black', zorder=3)
    xt.append(i); xl.append(key[1])
ax.set_xticks(xt); ax.set_xticklabels(xl, rotation=50, ha='right', fontsize=7.5); ax.set_yscale('log'); ax.set_yticks([0.5, 1, 2, 4, 8]); ax.set_yticklabels(['0.5', '1', '2', '4', '8']); ax.yaxis.set_minor_formatter(NullFormatter()); ax.axhline(1, color='0.3', lw=0.8)
ax.set_ylabel('MK platelet-activation programme\n(geo-mean fold of 11 genes vs own control)')
for x0, lab in [(0.5, 'creatine dosing\n(Fig 2f)'), (4.5, 'MK-lineage Slc6a8\ndeletion (Fig 3f)'), (9, 'Slc6a8-cKO MKs,\nliposome bypass\n(Supp 4e)'), (13, 'phospho-\ncreatine\n(Fig 4h)'), (17.5, 'si-Ckb\n(Fig 4j)'), (21.5, 'CKB over-\nexpression\n(Fig 4l)'), (25.5, 'STAT5-IN-1\n(STAT5A+B)\n(Fig 6a)'), (30, 'MK-lineage Stat5b\ndeletion (Fig 6g)\nno cKO-vehicle arm')]:
    ax.text(x0, 9.6, lab, ha='center', va='bottom', fontsize=7.3)
ax.set_ylim(0.4, 9.3); ax.set_title('Megakaryocyte gene programme at each node of the axis (n=3 per group; dots = replicates; red = creatine-exposed)', fontsize=9, loc='left', pad=46)
fig.savefig(os.path.join(FIG, 'fig2_mk_programme_by_node.png')); plt.close(fig)

# Figure 3 - human volunteers
fig, axs = plt.subplots(2, 3, figsize=(11.5, 6.6), gridspec_kw=dict(wspace=0.32, hspace=0.55)); axs = axs.ravel(); days = [0, 3, 7, 14]
for v in range(11): axs[0].plot(days, [c[v] for c in cr], color=CC, alpha=0.5, lw=0.9, marker='o', ms=2.5)
axs[0].set_title('A  Fasting serum creatine, n=11 (Fig 7b)\n    20 g/day: %.0f -> %.0f uM by day 3 (x%.1f)' % (cr[0].mean(), cr[1].mean(), cr[1].mean()/cr[0].mean()), fontsize=8.5, loc='left'); axs[0].set_xticks(days); axs[0].set_xlabel('day of creatine'); axs[0].set_ylabel('uM')
for ax, ag, let, nm in zip(axs[1:5], ['collagen', 'EPI', 'AA', 'ADP'], 'BCDE', ['Collagen', 'Epinephrine', 'Arachidonic acid', 'ADP']):
    g = H7C[(ag, 'max aggregation')]
    for v in range(11): ax.plot(days, [max(g[d][v], 0.1) for d in D7], color='0.45', alpha=0.6, lw=0.8, marker='o', ms=2.5)
    gm = [1]+[float(HPD[(HPD.agonist == ag) & (HPD.metric == 'max aggregation') & (HPD.day == d)].geo_mean_fold.iloc[0]) for d in ('d3', 'd7', 'd14')]; ax.plot(days, gm, color=CC, lw=2.2, marker='s', ms=4)
    r14 = HPD[(HPD.agonist == ag) & (HPD.metric == 'max aggregation') & (HPD.day == 'd14')].iloc[0]
    ax.set_yscale('log'); ax.set_yticks([0.125, 0.25, 0.5, 1, 2, 4, 8]); ax.set_yticklabels(['0.125', '0.25', '0.5', '1', '2', '4', '8']); ax.yaxis.set_minor_formatter(NullFormatter()); ax.set_ylim(0.09, 14); ax.axhline(1, color='0.5', ls='--', lw=0.7); ax.set_xticks(days); ax.set_xlabel('day of creatine'); ax.set_ylabel('max aggregation, fold of day 0')
    ax.set_title(f'{let}  {nm} (Fig 7c), n=11\n    day 14: x{r14.geo_mean_fold:.2f}, {r14.n_increased}/11 up, paired p={r14.p_wilcoxon_signed_rank:.3f}', fontsize=8.5, loc='left')
for r1, lab, c in [(4, 'GP6', CC), (12, 'P2RY12', '#2471a3')]:
    g = [col('Fig. 7e', cc_, r1, r1+3) for cc_ in 'BCDE']
    for v in range(4): axs[5].plot(days, [x[v]/g[0][v] for x in g], color=c, alpha=0.75, lw=1, marker='o', ms=3, label=lab if v == 0 else None)
axs[5].axhline(1, color='0.5', ls='--', lw=0.7); axs[5].set_yscale('log'); axs[5].set_yticks([0.5, 1, 2, 4]); axs[5].set_yticklabels(['0.5', '1', '2', '4']); axs[5].yaxis.set_minor_formatter(NullFormatter()); axs[5].set_xticks(days); axs[5].set_xlabel('day of creatine'); axs[5].set_ylabel('fold of day 0'); axs[5].legend(fontsize=7.5, frameon=False)
axs[5].set_title('F  Platelet protein / b-ACTIN (Fig 7e)\n    immunoblot densitometry, n=4 volunteers', fontsize=8.5, loc='left')
fig.text(0.125, 0.005, 'Grey = individual volunteers; red = geometric mean. Paired p = Wilcoxon signed-rank on fold-change vs 1 (single-arm, no placebo).', fontsize=7.5)
fig.savefig(os.path.join(FIG, 'fig3_human_volunteers.png')); plt.close(fig)

# Figure 4 - phosphoproteomics
fig, axs = plt.subplots(1, 3, figsize=(13.5, 4.1), gridspec_kw=dict(wspace=0.33))
axs[0].scatter(ph.log_fc[~tie], -np.log10(ph.p[~tie]), s=3, color='0.6', alpha=0.5, label='phosphopeptide rows'); axs[0].scatter(ph.log_fc[tie], -np.log10(ph.p[tie]), s=3, color='#d4ac0d', alpha=0.5, label=f'p = 0.42265 exactly (n={tie.sum()})')
sb = ph[ph.gene == 'Stat5b']; axs[0].scatter(sb.log_fc, -np.log10(sb.p), s=46, color=CC, zorder=5, label='Stat5b (2 rows)'); sa = ph[ph.gene == 'Stat5a']; axs[0].scatter(sa.log_fc, -np.log10(sa.p), s=46, color='#2471a3', zorder=5, label='Stat5a (1 row)')
axs[0].axhline(-np.log10(0.05), color='0.3', ls='--', lw=0.7); axs[0].text(-8.6, -np.log10(0.05)+0.06, 'p = 0.05', fontsize=7); axs[0].axhline(-np.log10(0.05/len(ph)), color='0.3', ls=':', lw=0.7); axs[0].text(-8.6, -np.log10(0.05/len(ph))+0.06, 'Bonferroni', fontsize=7)
axs[0].set_ylim(-0.1, 6.6); axs[0].set_xlabel('LOG_FOLDCHANGE column (sign convention not stated in file)'); axs[0].set_ylabel('-log10 nominal p'); axs[0].legend(fontsize=7, frameon=False, loc='upper right', ncol=1, markerscale=1.6, borderaxespad=0.2)
axs[0].set_title('A  Volcano: 5,812 rows, 2,033 genes\n    (no phosphosite annotation in the file)', fontsize=8.5, loc='left')
axs[1].hist(ph.p[~tie], bins=20, color='0.6'); axs[1].axhline((~tie).sum()/20, color=CC, ls='--', lw=1); axs[1].set_xlabel('nominal p (rows tied at 0.42265 removed)'); axs[1].set_ylabel('phosphopeptide rows')
axs[1].set_title(f'B  Nominal p<0.05: {int((ph.p < 0.05).sum())} rows observed;\n    {0.05*(~tie).sum():.0f}-{0.05*len(ph):.0f} expected if nothing changed', fontsize=8.5, loc='left')
axs[2].scatter(ph.p, ph.q, s=3, color='0.5'); axs[2].scatter(sb.p, sb.q, s=46, color=CC, zorder=5); axs[2].set_xscale('log'); axs[2].axhline(0.05, color='0.3', ls='--', lw=0.7); axs[2].text(1e-4, 0.06, 'FDR 5%', fontsize=7)
axs[2].set_ylim(0, 0.7); axs[2].set_xlabel('nominal p'); axs[2].set_ylabel('Q-VALUE column in file'); axs[2].set_title(f'C  No row passes FDR: minimum q = {ph.q.min():.2f};\n    best Stat5b row p = {sb.p.min():.4f}, q = {sb.q.min():.2f} (rank {int(sb.rank_by_p.min())})', fontsize=8.5, loc='left')
fig.savefig(os.path.join(FIG, 'fig4_phosphoproteomics_multiplicity.png')); plt.close(fig)
# Figure 5 - evidence matrix (summary of what has and has not been done at each node; text mirrors section 2.3 of the proposal)
rows_ = ['SLC6A8\n(MK creatine uptake)', 'STAT5B', 'CKB', 'GP6 / P2RY12\n(platelet effectors)', 'Platelet COX-1\n(aspirin)']
cols_ = ['Perturbation\nin package', 'MK gene\nprogramme', 'Platelet\nfunction', 'Metastasis\nin vivo', 'Attributable to\nthis target in\nthe MK lineage?', 'Human evidence\nfor the target']
G, A, R, N = '#c8e6c9', '#ffe0b2', '#eeeeee', '#ffffff'
cells = [
 [('MK-lineage deletion\n(Pf4-Cre;Slc6a8 fl/fl)', N), ('Blocked: x3.3 -> x0.84\nliposome bypass restores', G), ('Creatine gain reversed\n(n=3)', G), ('Abrogation 109%\n[83-132], n=4', G), ('Yes: lineage-restricted\ngene deletion', G), ('None', R)],
 [('STAT5-IN-1 (STAT5A+B,\nsystemic); MK-lineage\nStat5b deletion', N), ('Inhibitor: x5.3 -> x0.57\ncKO + creatine: x1.09\n(no cKO-vehicle arm)', A), ('Not tested', R), ('Inhibitor only:\nabrogation 92%\n[79-104], n=5\ncKO: not tested', A), ('Metastasis result: no\n(inhibitor hits A+B,\nall tissues)', A), ('None', R)],
 [('si-Ckb, over-expression\n(cultured MKs)', N), ('Knock-down blocks (73%)\nover-expression\ninduces x2.5', A), ('Not tested', R), ('Not tested', R), ('In culture only', A), ('None', R)],
 [('None (measured only)', N), ('Gp6 x5.6, P2ry12 x3.0\nwith creatine', A), ('Not tested', R), ('Not tested', R), ('Correlative', R), ('GP6 protein x2.6 (n=4)\ncollagen response x2.5\nADP response unchanged', A)],
 [('Aspirin to creatine-dosed\nplatelet donors', N), ('Not measured', R), ('Not measured', R), ('Transfer model:\n17.9% -> 4.4% burden\nno aspirin-alone arm', A), ('Platelet-level, by transfer', A), ('AA response x1.3\n(9/11 up)', A)],
]
fig, ax = plt.subplots(figsize=(14.5, 5.4)); ax.axis('off'); nr, nc = len(rows_), len(cols_); w0, w = 0.13, (1-0.13)/nc; h = 1/(nr+1)
for j, c in enumerate(cols_): ax.text(w0+(j+0.5)*w, 1-h/2, c, ha='center', va='center', fontsize=8.5, fontweight='bold')
for i, rname in enumerate(rows_):
    y = 1-(i+2)*h; ax.text(w0-0.008, y+h/2, rname, ha='right', va='center', fontsize=8.5, fontweight='bold')
    for j, (txt, colr) in enumerate(cells[i]):
        ax.add_patch(plt.Rectangle((w0+j*w, y), w, h, facecolor=colr, edgecolor='white', lw=2)); ax.text(w0+(j+0.5)*w, y+h/2, txt, ha='center', va='center', fontsize=7.4)
ax.set_xlim(0, 1); ax.set_ylim(0, 1)
ax.text(w0, -0.03, 'green = done, lineage-restricted and positive    amber = done but indirect, non-selective, in culture only, or missing a control    grey = not done', fontsize=8, va='top')
fig.savefig(os.path.join(FIG, 'fig5_evidence_matrix.png')); plt.close(fig)
print('\nFigures written to', os.path.abspath(FIG)); print('Tables written to', os.path.abspath(TAB))
