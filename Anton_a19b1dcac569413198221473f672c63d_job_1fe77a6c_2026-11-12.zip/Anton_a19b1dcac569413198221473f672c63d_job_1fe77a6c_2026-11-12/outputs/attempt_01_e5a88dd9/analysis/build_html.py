#!/usr/bin/env python
"""Render the proposal markdown to a single self-contained HTML file (figures embedded).
Run: micromamba run -n singlecell python build_html.py"""
import markdown, base64, re, os
here = os.path.dirname(os.path.abspath(__file__)); root = os.path.join(here, '..')
md = open(os.path.join(root, 'CRE-MK-01_followup_proposal.md'), encoding='utf-8').read()
html = markdown.markdown(md, extensions=['tables', 'sane_lists'])
def embed(m):
    path = os.path.join(root, m.group(2)); b64 = base64.b64encode(open(path, 'rb').read()).decode()
    return f'<img alt="{m.group(1)}" src="data:image/png;base64,{b64}"'
html = re.sub(r'<img alt="([^"]*)" src="([^"]+)"', embed, html)
css = """body{font-family:Helvetica,Arial,sans-serif;max-width:1080px;margin:28px auto;padding:0 18px;line-height:1.45;color:#1c1c1c;font-size:15px}
h1{font-size:24px;margin-top:26px}h2{font-size:19px;margin-top:30px;border-bottom:1px solid #ccc;padding-bottom:4px}h3{font-size:16px;margin-top:22px}
table{border-collapse:collapse;width:100%;margin:12px 0;font-size:13px}th,td{border:1px solid #c8c8c8;padding:5px 7px;vertical-align:top;text-align:left}th{background:#f0f2f4}
img{max-width:100%;margin:10px 0;border:1px solid #ddd}code{background:#f4f4f4;padding:1px 4px;border-radius:3px;font-size:12.5px}
body>p:first-child{font-size:17px;background:#eef5ee;border-left:5px solid #2e7d32;padding:12px 14px}"""
out = f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>CRE-MK-01 follow-up proposal</title><style>{css}</style></head><body>{html}</body></html>'
open(os.path.join(root, 'CRE-MK-01_followup_proposal.html'), 'w', encoding='utf-8').write(out)
print('written', len(out)//1024, 'kB')
