**Recommendation: take megakaryocyte SLC6A8 (creatine uptake into megakaryocytes) forward as the primary target, keep megakaryocyte STAT5B as first backup and CKB as second backup, and use next quarter's in vivo slot for one blinded genotype × creatine study that confirms SLC6A8 and, in the same run, performs the Stat5b-knockout metastasis test that is missing from the package.**

# CRE-MK-01 follow-up: target recommendation and validation plan

Prepared from `CRE-MK-01_source_data.xlsx` (87 sheets), `CRE-MK-01_phosphoproteomics.xlsx` and `study_conventions.pdf`. Every number below is computed from those files (script and tables listed in section 7). No external data were used for any number or ranking; the few outside facts mentioned are labelled "external" and treated as unvalidated.

Abbreviations: MK, megakaryocyte; cKO, conditional (Pf4-Cre lineage) knockout; "abrogation", share of the creatine effect removed by a perturbation.

## 1. The decision in brief

- **What creatine does.** Oral creatine raised lung metastatic burden in all 11 vehicle-versus-creatine comparisons in the package (134 mice): pooled 3.2-fold (95% CI 2.7 to 3.7). It shortened survival in both survival cohorts (hazard ratios 2.9 and 2.3).
- **Where it acts.** In the megakaryocyte lineage, not in the tumour cell. Deleting Slc6a8 in the MK lineage removed the whole creatine effect on burden (109%, 95% CI 83 to 132%; interaction p = 0.0003, the test of whether the creatine effect differs between genotypes). Knocking Slc6a8 down in the tumour cells removed none of it (−10%; interaction p = 0.68).
- **Why SLC6A8 leads.** It is the only node where a lineage-restricted genetic intervention was followed all the way to the metastasis endpoint, and every intermediate step moved with it: MK creatine, the MK gene programme, platelet reactivity.
- **Why STAT5B is a backup.** Metastasis was tested only with STAT5-IN-1, a systemic inhibitor of both STAT5A and STAT5B. The Stat5b-knockout mice were never taken to a metastasis or platelet-function readout and have no vehicle-treated knockout arm. The phosphoproteomic hit that nominated STAT5B does not survive multiple-testing correction (q = 0.25).
- **Why CKB is second backup.** All of its evidence is in cultured MKs. Nothing was done in vivo.
- **The caveat the committee should weigh.** No intervention in the package lowers metastasis below the untreated baseline. In these data the axis matters only when creatine is supplemented, so the addressable population is creatine-exposed patients, and stopping the supplement is the obvious competitor to any drug.

![Evidence at each node](figures/fig5_evidence_matrix.png)

## 2. What the package shows

### 2.1 The phenotype and the exposure

| Finding | Result | Source | How derived |
|---|---|---|---|
| Serum creatine, mouse gavage | 66 → 179 µM (2.7-fold), n = 6/group | Supp 1d | group means |
| Serum creatine, mouse 5% diet | 78 → 227 µM (2.9-fold), n = 4/group | Supp 1h | group means |
| Serum creatine, volunteers on 20 g/day | 45 → 153, 156, 159 µM on days 3, 7, 14 (3.4-fold), n = 11 | Fig 7b | paired, each volunteer vs own day 0 |
| Dose, per kg | mouse 17 mg three times a week ≈ 0.31–0.35 g/kg/day; volunteers 20 g/day ÷ 57.6 kg = 0.35 g/kg/day | conventions, Supp 1a | arithmetic on stated doses and body weights |
| Lung metastatic burden | 3.2-fold (2.7 to 3.7) pooled; every one of 11 comparisons p < 0.01 | Fig 1b, 1f, 1k, 3i, 6b; Supp 1e, 1f, 1g, 1i, 1k | log ratio per cohort, random-effects pooling |
| Metastatic foci | 2.0-fold (1.8 to 2.4) pooled | same panels | same |
| Survival | median 22 → 19 days, HR 2.9 (1.0 to 8.2), p = 0.032, n = 10/10; median 16 → 14 days, HR 2.3 (1.2 to 4.5), p = 0.011, n = 20/18 | Fig 1c, 1l | log-rank and Cox; no censoring |
| Early tumour-cell signal in lung | equal at 15 min (p = 0.31); 1.5-, 1.8-, 2.8-fold higher at 6, 12, 24 h; n = 6/group | Fig 1h | t-test per time point |
| Tolerability | food, water, body weight, white cells, red cells, platelet count and indices unchanged | Supp 1a–c, 3a; Fig 2a | t-tests, all p > 0.08 |

Mouse and human exposures match on both a per-kg dose and a serum-level basis, so the mouse model speaks to the volunteers' regimen. Only this one dose level was studied in either species; whether lower intakes have the effect is unknown.

The rise in lung tumour-cell signal within 6 to 24 hours places the effect at the seeding step. The package has no primary-tumour measurements.

### 2.2 The effect runs through megakaryocytes and platelets

- **Platelets from creatine-dosed donors carry the effect.** Recipients of creatine-donor platelets had 17.9% burden versus 5.9% with vehicle-donor platelets (p = 0.0004, n = 6/group; Supp 2d; see the duplication flag in section 4). Platelets taken from volunteers on day 7 of creatine gave 12.7% versus 4.6% with their day-0 platelets (p = 0.014, n = 5 recipient mice/group; Fig 7g). Transfer reproduced the full size of the effect: 3.1-fold with mouse platelets and 2.7-fold with human platelets, against 3.2-fold with direct dosing.
- **Platelet quality changes, not number.** Aggregation rose to ADP (42 → 57%), collagen (66 → 79%) and thrombin (25 → 56%), n = 3, all p < 0.002 (Fig 2b). Clot strength (TEG-MA) rose from 39.7 to 54.0 mm, p = 0.049, n = 5; the other three TEG measures did not change (Fig 2d). Platelet count did not change (Fig 2a).
- **The change is programmed in the MK.** An 11-gene platelet-activation panel rose 3.1-fold (geometric mean) in MKs from creatine-dosed mice (Fig 2f). In culture, creatine at 0.2 and 2 mM raised GP6 and P2RY12 protein in MKs but not in isolated platelets (Fig 2i, blot).
- **The tumour cell's own transporter is not needed.** Creatine raised burden 3.5-fold with control tumour cells and 3.2-fold with Slc6a8-knock-down tumour cells (interaction p = 0.68, n = 6/group; Fig 1f). Caveat: mRNA fell 81% (Supp 2a) but the protein band on the supplied blot is only modestly weaker.

![In vivo evidence by node](figures/fig1_in_vivo_evidence_by_node.png)

### 2.3 Evidence at each candidate node

"MK programme" is the geometric-mean fold change of the 11-gene panel against each experiment's own control (n = 3 per group throughout).

| Node | Perturbation in the package | MK programme | Platelet function | Metastasis in vivo | Main gaps |
|---|---|---|---|---|---|
| **SLC6A8** (creatine uptake) | MK-lineage deletion, Pf4-Cre;Slc6a8 fl/fl (Fig 3, Supp 4) | Creatine induction 3.3-fold in controls, 0.84-fold in cKO. MK creatine rise blocked (5.3-fold vs 1.5-fold; interaction p = 0.045) while serum creatine still rose 2.4-fold. Liposomal creatine, which bypasses the transporter, restored induction in cKO MKs (2.35-fold vs 0.89-fold for free creatine). | Creatine raised aggregation by 7–13 points in controls and lowered it by 10–23 points in cKO (interaction p < 10⁻⁶). Platelet count unchanged. | Burden 2.4 → 7.9% in controls, 3.4 → 2.9% in cKO. Abrogation 109% (83 to 132%), interaction p = 0.0003. Foci: abrogation 107% (67 to 148%), p = 0.004. n = 4/group (Fig 3i). | n = 4, one model, unblinded. Residual SLC6A8 band in cKO MKs. Deletion is lifelong, not therapeutic. No inhibitor tested. cKO platelets under creatine are hypo-reactive (see 4). |
| **CKB** | si-Ckb, CKB over-expression, phosphocreatine, all in cultured MKs (Fig 4, Supp 5) | Creatine raised Ckb mRNA 1.8-fold (p = 0.011). si-Ckb: induction 3.7-fold → 1.0-fold (73% block against its own baseline, which fell to 0.70). Over-expression alone: 2.5-fold, with no change in MK creatine (33.7 vs 32.7 µmol/g) or phosphocreatine. Phosphocreatine: 0.63-fold. | Not tested | Not tested | No in vivo evidence of any kind. The proposed kinase activity rests on single blots. |
| **STAT5B** | STAT5-IN-1 (STAT5A + STAT5B, oral, systemic); MK-lineage deletion, Pf4-iCre;Stat5b fl/fl (Fig 5, 6; Supp 6, 7) | Inhibitor: induction 5.3-fold → 0.57-fold, but it also halves the untreated programme (0.52-fold). Stat5b cKO plus creatine: 1.09-fold of wild-type vehicle, with Gp6 still 1.4-fold and P2ry12 1.9-fold. MK creatine unchanged by the cKO (95 vs 98 µmol/g). | Not tested | Inhibitor: burden 3.4 → 13.9% without, 3.6 → 4.5% with. Abrogation 92% (79 to 104%), interaction p = 7 × 10⁻⁶, n = 5/group (Fig 6b). **Stat5b cKO: not tested.** | The metastasis result cannot be assigned to STAT5B or to MKs. No vehicle-treated cKO arm anywhere. Discovery evidence not FDR-significant. Site evidence indirect (see 3). |
| **GP6, P2RY12** (platelet effectors) | None. Measured only. | Gp6 5.6-fold, P2ry12 3.0-fold in MKs of dosed mice (Fig 2f); protein up in MKs and platelets on blots (Fig 2e, 2g) | Not tested | Not tested | Correlative only. |
| **Platelet COX-1** (aspirin, 30 mg/kg/day) | Aspirin given to creatine-dosed platelet donors (Supp 2d) | Not measured | Not measured | Recipients: 4.4% burden vs 17.9% with creatine-donor platelets (p = 0.0001), equal to vehicle-donor platelets (5.9%) | No aspirin-alone arm. Not tested with direct creatine dosing. Shares six values with Fig 6b (see 4). |

![MK programme by node](figures/fig2_mk_programme_by_node.png)

### 2.4 Healthy volunteers (n = 11; expression sub-study n = 4)

The cohort is single-arm with no placebo: 11 healthy Asian volunteers aged 20–25, 20 g/day for 14 days. I re-analysed it as paired data, each volunteer against their own day 0. The sheet's unpaired ANOVA on fold-changes makes the same day-14 calls for collagen, epinephrine and ADP; the epinephrine rise on day 7 and the arachidonic-acid rise on day 14 are significant only in the paired analysis.

| Readout | Day 14 vs day 0 | Source |
|---|---|---|
| Collagen-induced maximal aggregation | 2.5-fold (geometric mean), 9/11 volunteers up, paired p = 0.005 | Fig 7c |
| Epinephrine-induced maximal aggregation | 1.6-fold, 10/11 up, p = 0.002; already 1.3-fold on day 7 (10/11 up, p = 0.005) | Fig 7c |
| Arachidonic-acid-induced | 1.3-fold, 9/11 up, p = 0.04 | Fig 7c |
| ADP-induced | 1.07-fold, 6/11 up, p = 0.46 | Fig 7c |
| Platelet count, MPV, PDW, BMI | unchanged | Supp 8a, 8b |
| Platelet GP6 protein (n = 4) | 2.0-fold on day 7, 2.6-fold on day 14; 4/4 up at both | Fig 7e |
| Platelet P2RY12 protein (n = 4) | 1.3- to 1.7-fold; 4/4 up at each time point | Fig 7e |
| 11-gene panel in circulating CD41+ cells (n = 4) | 4.0-fold on day 7, 2.5-fold on day 14; up in 3 of 4 volunteers | Fig 7d |
| ADRA2A mRNA, the epinephrine receptor (n = 4) | 21-fold on day 7, 4.1-fold on day 14; 4/4 up at both | Fig 7d |
| RAB4A mRNA (n = 4) | fell to 0.38-fold on day 14 in 4/4 volunteers | Fig 7d |

![Human volunteers](figures/fig3_human_volunteers.png)

What carries over from mouse to human: platelet count unchanged, platelet reactivity up, GP6 up, and platelets that promote metastasis on transfer. What does not: the ADP response did not change in volunteers, although it rose in mice, and RAB4A moved in the opposite direction. The human data sit entirely downstream of the three candidate targets. They contain no measurement of SLC6A8, CKB or STAT5B in human cells, so they support the phenomenon, not any one target.

Serum creatine plateaued by day 3 but platelet reactivity rose between days 7 and 14. That lag fits programming of newly made platelets in the MK, as in the mouse.

Collagen and epinephrine responses on day 14 moved together across volunteers (Spearman ρ = 0.82, p = 0.002); 6 of 11 volunteers at least doubled their collagen response. This is exploratory but suggests responders and non-responders.

## 3. Why this ranking

**SLC6A8 first.** The causal chain is complete and specific. Deleting the transporter in the MK lineage left serum creatine elevated but stopped MK creatine loading, the gene programme, the gain in platelet reactivity and the gain in metastasis. Bypassing the transporter with liposomal creatine restored the programme, which ties the phenotype to creatine entry and not to some other consequence of the deletion. It is also the most upstream node, so it does not depend on the downstream mechanism being right.

**STAT5B second.** The mechanistic story is coherent, and the inhibitor result in vivo is as large as the SLC6A8 result. Four things keep it from leading:

1. *Attribution.* STAT5-IN-1 inhibits STAT5A and STAT5B (study conventions) and was given systemically. It also halved the MK programme in the absence of creatine (0.52-fold; Fig 6a), so it is not selective for the creatine-induced component.
2. *The genetic experiment stops short.* Pf4-iCre;Stat5b fl/fl mice were read out only for MK creatine, MK transcripts, two blots and platelet count, only under creatine. There is no vehicle-treated cKO arm, so a creatine-specific effect cannot be separated from a shifted baseline, and there is no platelet-function or metastasis endpoint.
3. *Discovery statistics.* Of 5,812 phosphopeptide rows, 238 have nominal p < 0.05, against 206–291 expected if nothing changed. No row passes FDR (minimum q = 0.17). The Stat5b row ranks 17th (p = 0.0012, q = 0.25); a second Stat5b row and the Stat5a row are unchanged. The file carries no phosphosite column, so S127 cannot be checked from it.
4. *Site evidence is indirect.* The S127 work used FLAG-tagged STAT5B over-expressed in 293T cells and a pan-phospho antibody. The creatine-associated increase was 39% and 28% in the two quantified series (Fig 5e, 5f), absent in S127A; the sheets test mutants within each treatment, not creatine against vehicle. On the nuclear-fraction blot the signal rises with creatine in S127A as well as in wild type (Fig 5h, single image, read by eye), so site-specificity is not consistent across panels. Canonical Y694/699 phosphorylation was undetectable in MKs (Supp 6a).

Two further observations point the same way. Under creatine, Gp6 and P2ry12 in Stat5b-cKO MKs stayed 1.4- and 1.9-fold above wild-type vehicle (2.8- and 4.4-fold in wild type), whereas with the dual inhibitor they returned to baseline (0.6- and 1.2-fold). That leaves room for STAT5A redundancy. And platelet crit in Stat5b-cKO mice on creatine trended low (0.26 vs 0.36%, adjusted p = 0.055, n = 3; Supp 7b), so an effect on platelet production is not excluded.

![Phosphoproteomics](figures/fig4_phosphoproteomics_multiplicity.png)

**CKB third.** Knock-down and over-expression in cultured MKs are clean and point both ways, and over-expression acts without changing creatine or phosphocreatine. Blots place CKB between creatine entry and STAT5B: creatine still induces CKB in Stat5b-cKO MKs (Fig 6f), CKB knock-down removes the creatine-associated nuclear phospho-signal on STAT5B (Fig 5h), and recombinant CKB raises that signal in a cell-free reaction (Supp 6d). Each of those is a single image. There is no animal carrying a CKB perturbation, no platelet-function readout and no metastasis readout.

**Platelet effectors and aspirin are not target recommendations.** GP6 and P2RY12 were measured, never blocked. GP6 is the better supported of the two in humans (protein 2.6-fold; collagen response up), while the unchanged ADP response argues against P2RY12 as the dominant human effector. Aspirin normalised the effect in the transfer model and belongs in every follow-up as the benchmark a new agent must beat.

## 4. Limits that bear on the decision

**Strategic**

- *Conditional biology.* MK-lineage Slc6a8 deletion and STAT5-IN-1 each returned creatine-dosed mice to baseline, and neither changed burden in mice not given creatine (cKO vehicle 3.4% vs control vehicle 2.4%, p = 0.64; inhibitor alone 3.6% vs 3.4%, p = 1.0). The therapeutic hypothesis therefore holds only in creatine-exposed hosts.
- *Hypo-reactive platelets.* In Slc6a8-cKO mice creatine lowered aggregation well below the untreated control (ADP 31% vs 63%; thrombin 35% vs 61%; n = 3; Fig 3d). The cKO alone was also lower than control (ADP 54%, thrombin 45%). Several programme genes also fell below baseline in cKO MKs under creatine (Pitpnb 0.37-fold, Runx1 0.50-fold; Fig 3f). This is unexplained and could mean a bleeding liability for transporter blockade during creatine exposure. No bleeding readout exists.
- *Systemic transporter blockade.* Dosed creatine also enters brain (brain creatine +19%, phosphocreatine 2.0-fold; Fig 4a, 4c), so brain exposure of any SLC6A8 inhibitor is a safety question. (External, unvalidated here: inherited SLC6A8 deficiency is a neurological disorder.)
- *Human relevance of the targets is untested.* See 2.4.

**Design and statistics** (study conventions)

- Allocation was randomised but not masked, no sample-size calculation was made, and sex was not analysed. Males were C57BL/6J and females BALB/cJ, so sex and strain are confounded. Tumour line and cohort-to-strain assignment are not given in the files, apart from "melanoma" in Fig 1f.
- Four panels count microscope fields, not animals (Fig 1i, 2c, 2j; Supp 4c: 8 fields per group). I give them no weight as independent replication.
- Most mechanistic panels are n = 3. Blots are supplied as representative images without quantification, except Fig 5e, 5f and 7e, and loading controls were run on separate gels.
- The Pf4 promoter is active in the MK lineage, so the deletion is lineage-restricted, which includes platelets. Only the culture result in Fig 2i separates MK from platelet.

**Data quality** (details in Appendix B)

- *Duplicated values.* Three vehicle and three creatine burden values, with their matching foci counts, are identical in Fig 6b (inhibitor study) and Supp 2d (platelet-transfer study). Both results hold when the shared values are removed from either panel (Fig 6b interaction p = 0.0003; Supp 2d creatine vs vehicle p = 0.0002), but unique controls then fall to n = 2 and n = 3. These are the only in vivo panels for STAT5 and for aspirin, so this needs tracing to raw records before the meeting.
- *Human qPCR.* For PITPNB and RAB27B in volunteer 4, and GP6 in volunteer 2, the sheet's normalised values do not match values recomputed from its own ΔCT rows. Conclusions above do not rest on those cells.
- *Reproduction.* All 232 statistical tests embedded in the workbook reproduce from the raw cells (227 numeric p-values match; 5 reported as inequalities are consistent).

## 5. Proposed studies

### 5.1 In vivo slot, next quarter: CRE-MK-02

**Question.** Does MK-lineage Slc6a8 deletion remove creatine-driven metastasis under blinded, powered conditions, and does MK-lineage Stat5b deletion do the same?

| Element | Specification |
|---|---|
| Model | Same syngeneic lung-metastasis model and creatine regimen as Fig 3i (42.5 mg/mL, 400 µL by mouth, three times a week). Confirm the tumour line from study records. |
| Arms and comparators: Block A, primary target | Pf4-Cre;Slc6a8 +/+ and Pf4-Cre;Slc6a8 fl/fl, each with vehicle or creatine (4 arms) |
| Arms and comparators: Block B, first backup | Pf4-iCre;Stat5b +/+ and Pf4-iCre;Stat5b fl/fl, each with vehicle or creatine (4 arms). The vehicle-treated cKO arm has never been run. |
| Benchmark comparators | Block A control genotype, two arms. (1) Creatine plus aspirin 30 mg/kg/day by mouth, the in-house dose. (2) Creatine withdrawal: dosed as usual, then stopped one week before tumour-cell inoculation to allow platelet turnover. This tests the non-drug alternative directly. |
| Optional arms, in priority order | (1) Block B control genotype, creatine plus STAT5-IN-1 5 mg/kg/day: repeats Fig 6b inside the same experiment as the Stat5b cKO, so genetics and pharmacology can be compared directly. (2) Vehicle plus aspirin: does aspirin lower baseline? (3) Two lower creatine doses in the control genotype, titrated to about 1.5- and 2-fold baseline serum creatine: is there a threshold? |
| Population | Both sexes in every arm, sex as a blocking factor; littermate controls carrying the matching Cre. (External: Slc6a8 is X-linked, so cKO males are fl/Y.) |
| Size | 12 per arm for the primary endpoint (10 arms, 120 mice), plus 6 per arm without tumour for platelet and MK readouts (8 genotype arms, 48 mice) |
| Conduct | Randomised within litter and sex; coded dosing solutions and cage cards; readers blind to genotype and treatment; the animal is the unit of analysis; analysis plan fixed before unblinding |
| Primary endpoint | Lung metastatic burden (%), log-transformed. Primary test: genotype × creatine interaction, one per block, two-sided α = 0.025 each. |
| Secondary endpoints | Foci count; lung weight; burden in vehicle-treated cKO vs control (is there any effect without creatine?); aspirin arm and withdrawal arm, each vs creatine alone and vs vehicle |
| Mechanism readouts | Serum creatine (exposure check in every animal); MK creatine; 11-gene panel; platelet GP6 and P2RY12 per animal; aggregation to ADP, collagen, thrombin, and epinephrine (to bridge to the volunteers); nuclear STAT5B |
| Safety readouts | Platelet count and indices; bleeding time; TEG-MA; body weight |

*Power, from in-house numbers only.* The pooled creatine effect is 1.15 log units (3.2-fold) and the pooled within-group SD of log burden is 0.415 (11 cohorts). With 12 per arm, power at α = 0.025 is 99% to detect complete abrogation, 90% for 75% abrogation and 54% for 50% abrogation. The vehicle-arm comparison has 82% power to detect a 40% lower baseline burden.

*If the slot is capped.* Reduce to 10 per arm (82% power for 75% abrogation) before dropping any arm. Do not drop the vehicle-treated Stat5b cKO arm, the blinding, or the bleeding readout. If only one block can run, run Block A with the aspirin and withdrawal arms this quarter and Block B next; the ranking then stays provisional until Block B reads out.

### 5.2 Work that does not need the slot

| Study | Design | Readout | Purpose |
|---|---|---|---|
| Records check | Trace Fig 6b and Supp 2d to raw data; confirm tumour line and strain per cohort; re-derive Fig 7d | Corrected source tables | Should precede the committee meeting |
| Human MK bridge | Human MKs in culture (CD34+-derived; MEG-01, already in house, as a line control) with creatine from 0.05 to 2 mM, spanning the volunteers' 45 → 156 µM | Intracellular creatine, CKB, STAT5B S127 phosphorylation, GP6, P2RY12, ADRA2A; each with SLC6A8, CKB, STAT5B and STAT5A knock-down | First human evidence for any of the three targets; separates STAT5B from STAT5A |
| Site confirmation | Targeted, site-resolved mass spectrometry of STAT5B S127 in primary MKs from Block A satellites; repeat discovery run at n ≥ 6 per group with FDR control | S127 occupancy in control vs Slc6a8-cKO, ± creatine | Tests the SLC6A8 → STAT5B link in vivo with a site-specific measure |
| SLC6A8 tool qualification | Candidate inhibitors in the MK uptake assay of Fig 4d, then exposure in mice | MK creatine uptake; platelet function; brain creatine | Prepares a therapeutic-dosing study for the following quarter. External compounds exist but are unvalidated in our system. |
| CKB in vivo tool | Start an MK-lineage Ckb deletion or kinase-dead line | — | CKB cannot advance without it |

### 5.3 Human study: CRE-MK-03

| Element | Specification |
|---|---|
| Design | Randomised, double-blind, placebo-controlled crossover (parallel groups if washout proves impractical); washout of at least 4 weeks, with return to baseline confirmed before period 2 |
| Population | Healthy adults of both sexes, wider age range and ancestry than the first cohort; no antiplatelet drugs or NSAIDs; no history of cancer or thrombosis, given the mouse findings |
| Arms and comparators | Creatine 20 g/day for 14 days (the regimen already tested), then a reduced intake to day 28, vs matched placebo. A separate lower-dose-only group, to find whether lower intakes alone have the effect. |
| Sampling | Days 0, 3, 7, 14 and 28, then after stopping until values return to baseline. In the first cohort the CD41+ cell panel peaked on day 7 and had partly declined by day 14 (4.0- to 2.5-fold) while serum creatine stayed flat, so persistence with continued use is unknown. |
| Primary endpoints | Change from baseline to day 14 in collagen-induced and epinephrine-induced maximal aggregation, creatine vs placebo, with raw aggregation values recorded |
| Secondary endpoints | ADP and arachidonic-acid responses (unchanged or weak in the first cohort); platelet GP6, P2RY12 and ADRA2A protein in all participants; 11-gene panel in CD41+ cells; serum creatine; platelet count; coagulation tests; time to return to baseline after stopping |
| Size | 24 completers: 90% power for the effects seen in-house (collagen 2.5-fold, epinephrine 1.6-fold) at α = 0.025 each. Detecting half those effects would need 80 to 90. |

### 5.4 Indications and populations

- *Indication supported by the data.* Prevention of blood-borne metastatic seeding in patients exposed to supplemental creatine. The models show lung colonisation; melanoma is the only tumour type named in the files.
- *First patient-facing step.* An observational comparison of platelet reactivity and platelet GP6 in cancer patients or survivors who already take creatine against matched non-users. No study should give creatine to cancer patients.
- *Next preclinical indications.* A second tumour type on the cKO background, and a model in which metastases arise from a primary tumour with primary growth measured. The files do not state how tumour cells were delivered and contain no primary-tumour data.
- *Comparators for any future interventional study.* Stopping creatine, and aspirin.

### 5.5 Sequence

1. Before the meeting: records check (5.2), so that Fig 6b and Supp 2d can be cited with confidence.
2. Before the slot opens: lock the CRE-MK-02 analysis plan, randomisation and blinding scheme; confirm colony numbers for both lines.
3. During the slot: CRE-MK-02, with the human MK bridge, site confirmation and tool qualification running alongside.
4. At readout: apply the rules in section 6. The following quarter goes to inhibitor dosing for the confirmed lead, started after tumour-cell inoculation and repeated in a second tumour model.
5. CRE-MK-03 starts as soon as approvals allow; it does not depend on the slot.

## 6. What would change the ranking

| If we learn that… | Then |
|---|---|
| Block A: interaction p < 0.025, abrogation ≥ 75% with lower confidence bound above 50%, bleeding time within 2-fold of control | SLC6A8 is confirmed as lead. Commit the following quarter to inhibitor dosing. |
| Block B meets the same bar and platelet count stays within 20% of control | STAT5B becomes co-lead. |
| Block B meets the bar **and** Block A shows prolonged bleeding or fails to replicate | STAT5B replaces SLC6A8 as lead. |
| Block B gives partial abrogation (< 50%) although STAT5-IN-1 gave 92% | STAT5A redundancy or a non-MK site of inhibitor action. Drop a STAT5B-selective strategy. |
| S127 occupancy rises with creatine in control MKs, not in Slc6a8-cKO MKs, and an S127A allele blocks the programme in human MKs | STAT5B's mechanism is secured; strengthens it as backup or co-lead. |
| MK-lineage Ckb deletion or a kinase-dead allele blocks platelet hyper-reactivity and metastasis in vivo | CKB moves ahead of STAT5B if it also spares platelet count. |
| Aspirin with direct creatine dosing fully normalises burden, and the MK-directed arms add nothing beyond it | The case for a new target weakens. The programme becomes a repurposing and guidance question. |
| Burden returns to baseline one week after creatine is withdrawn | Stopping the supplement is an effective intervention. A drug is then justified only for patients who cannot stop, and priority falls. |
| Burden stays elevated after withdrawal | MK programming outlasts exposure. The case for an MK-directed agent strengthens, and advice to stop creatine is not enough on its own. |
| CRE-MK-03 confirms a collagen-selective gain against placebo, and GP6 blockade normalises creatine-driven metastasis in mice | GP6 opens as an effector-level option. |
| A vehicle-treated cKO arm lowers baseline burden, or lower creatine doses still drive the effect | The addressable population widens beyond high-dose supplement users; the whole programme rises in priority. |
| Neither block replicates, or CRE-MK-03 shows no effect against placebo | Stop. |

## 7. How the numbers were derived

All analysis is in `analysis/cre_mk01_reanalysis.py`; outputs are in `tables/` and `figures/`.

- **Reproduction check.** Every Prism test embedded in the workbook (t-tests, Tukey, Dunnett, Šidák, log-rank; 232 in all) was recomputed from the raw cells. The 227 numeric p-values match and the 5 reported as inequalities are consistent (`tables/evidence_table_all_panels.csv`). The workbook's own statistics can therefore be trusted as arithmetic; the issues are in design and coverage, not calculation.
- **Pooled creatine effect.** Per cohort, the difference in mean log burden (creatine minus vehicle) with its standard error; DerSimonian–Laird random-effects pooling; I² = 55% (`creatine_effect_by_cohort.csv`, `creatine_effect_pooled.csv`). Leaving out Fig 6b, because of the duplication flag, gives 3.0-fold (2.6 to 3.6).
- **Abrogation and interaction.** For each 2 × 2 experiment, a linear model with a perturbation × creatine term gives the interaction p. Abrogation is 1 − (creatine effect with perturbation ÷ creatine effect without), with a bootstrap 95% interval from 20,000 resamples within groups (`interaction_tests_2x2.csv`).
- **MK programme.** For each sample, the mean over 11 genes of log2 fold change against the mean control ΔCT of that experiment; reported as geometric-mean fold (`mk_gene_panel_fold_matrix.csv`, `mk_programme_block_by_node.csv`).
- **Human paired analysis.** Fold-of-day-0 values tested against 1 by Wilcoxon signed-rank, with geometric means and counts of volunteers increased (`human_platelet_function_paired.csv`, `human_expression_n4.csv`).
- **Phosphoproteomics.** Counts of nominal hits against chance expectation; the file's q-values and a recomputed Benjamini–Hochberg FDR (`phosphoproteomics_summary.csv`). 1,702 rows share p = 0.42265 exactly. That is what a t-test with 2 degrees of freedom returns when a single replicate differs from otherwise identical values (t = 1), the signature of imputed missing values. Chance expectation is given with and without those rows.
- **Survival.** Log-rank test and Cox hazard ratio (`survival.csv`).
- **Power.** Non-central t on the interaction contrast using the pooled effect and SD above (`power_in_vivo_interaction.csv`); human sample size from the within-volunteer SD of log2 change in Fig 7c (`power_human_crossover.csv`).

## Appendix A. Panel index: every sheet and how it was used

| Theme | Panels | What they show | Use in the decision |
|---|---|---|---|
| Exposure, tolerability | Supp 1a, 1b, 1c, 1d, 1h; Supp 3a; Fig 2a | Serum creatine 2.7- to 2.9-fold; intake, weight and blood counts unchanged | Exposure match to human; effect is not general toxicity |
| Metastasis phenotype | Fig 1a, 1b, 1j, 1k; Supp 1e, 1f, 1g, 1i, 1k | Lung weight, PET signal, burden and foci all higher with creatine | Pooled effect size; variance for power |
| Survival | Fig 1c, 1l | Shorter survival with creatine | Clinical relevance of the endpoint |
| Seeding | Fig 1h, 1i | More tumour-cell signal in lung from 6 h; more GFP+ cells per field (fields, n = 8) | Places the effect at seeding |
| Tumour-intrinsic test | Fig 1f; Supp 2a | Knock-down in tumour cells does not change the creatine effect | Host-directed target |
| Platelet phenotype | Fig 2b, 2c, 2d, 2e, 2j | Aggregation and TEG-MA up; α-granules and PKH area up (fields); GP6 and P2RY12 blots | Platelet quality changes |
| Platelet transfer | Supp 2d; Fig 7g | Creatine-conditioned platelets, mouse or human, raise burden; aspirin to donors prevents it | Platelets are sufficient; aspirin benchmark |
| MK programme | Fig 2f, 2g, 2i; Supp 3c | 11-gene panel 3.1-fold; GP6 and P2RY12 protein up in MKs, not in platelets treated directly; most maturation genes unchanged | Programming occurs in the MK |
| SLC6A8 | Fig 3b, 3c, 3d, 3f, 3g, 3i; Supp 4a, 4b, 4c, 4e | See 2.3 | Primary target |
| CKB | Fig 4a, 4b, 4c, 4d, 4e, 4f, 4g, 4h, 4i, 4j, 4k, 4l; Supp 5a, 5b, 5c | MK creatine 3.0-fold and phosphocreatine 3.9-fold with dosing (brain 1.2- and 2.0-fold); CKB induced; knock-down, over-expression, phosphocreatine as in 2.3; Gatm and Gamt unchanged | Second backup |
| STAT5B mechanism | Phosphoproteomics; Fig 5e, 5f, 5g, 5h, 5i, 5j; Supp 6a, 6d, 6e, 6f, 6g, 6h, 6i | Nominal phospho hit; S127-dependent pan-phospho signal in 293T; CKB-dependence on blots; promoter ChIP enrichment 2.7- to 12-fold at P2ry12, Gp6, Rab4a; no Y694/699 signal; more nuclear STAT5B | First backup, mechanism |
| STAT5 perturbation | Fig 6a, 6b, 6d, 6e, 6f, 6g; Supp 7a, 7b | See 2.3 | First backup, efficacy |
| Human | Fig 7b, 7c, 7d, 7e, 7g; Supp 8a, 8b, 8c, 8d | See 2.4; CD41+ cell purity control | Translation of the phenomenon |

## Appendix B. Data-quality flags

| Item | Finding | Handling |
|---|---|---|
| Fig 6b and Supp 2d | Burden values 3.29, 3.73, 2.89 (vehicle) and 11.13, 13.22, 14.13 (creatine), and foci 37, 25, 33 and 53, 62, 47, appear in both | Sensitivity analyses without them; trace to raw records |
| Fig 7d, volunteer 4, PITPNB | "ΔCT" cells hold values of +26 to +28 | Sheet-normalised values not reproducible; not relied on |
| Fig 7d, RAB27B volunteer 4; GP6 volunteer 2 | Normalised values differ more than 1.5-fold from recomputation; GP6 baseline triplicate spans 3.7 cycles | Not relied on |
| Fig 3c | Vehicle means in the two genotypes are 13.691 and 13.688 | Check whether values were normalised per genotype before reading this as "no baseline difference" |
| Fig 3d | All 36 values are even integers; SDs of 1.2 to 2.0 at n = 3 | p-values overstate precision |
| Fig 7c | Only fold-of-day-0 values; largest ratio 40-fold | Geometric means, medians and paired rank tests used; raw values to be recorded in CRE-MK-03 |
| Tumour-cell knock-down | Labelled sh- in Fig 1f headers and the blot, si- in one statistics row and the qPCR sheet | Durability of knock-down in vivo undocumented |
| Fig 4d | Header reads "Creatinine" | Treated as creatine, per the assay named in the study conventions |
| Fig 1h | Y-axis metric not labelled | Described as lung tumour-cell signal |
| Supp 1a | Y-axis not labelled; values 19–24 | Read as body weight in grams |
| ChIP panels | Antibody target not stated in the files | Read as STAT5B from context |
| Phosphoproteomics file | No phosphosite column; base and sign of LOG_FOLDCHANGE not stated; 29% of rows carry the imputation-signature p-value; header says unpaired Student's t-test but that p-value corresponds to 2 degrees of freedom | Used only to judge multiplicity; large fold-changes (the Stat5b row is 5.7 log units) treated as presence/absence calls |
| Human coagulation tests | Collected per the conventions; not in the workbook | Requested |

## Appendix C. Files

- `CRE-MK-01_followup_proposal.md`: this document (`.html` is the same text with figures embedded)
- `analysis/cre_mk01_reanalysis.py`: reproduces every number, table and figure
- `tables/`: 21 CSV files, including those named in section 7; `qc_flags.csv` and the two other `qc_*.csv` files back Appendix B
- `figures/`: fig1 (in vivo evidence by node), fig2 (MK programme by node), fig3 (volunteers), fig4 (phosphoproteomics), fig5 (evidence matrix)
- `analysis/run_log.txt`: console output of the last run; `analysis/build_html.py` renders the HTML
