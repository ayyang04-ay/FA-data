**Recommendation: take megakaryocyte creatine uptake through SLC6A8 forward as the primary target, with megakaryocyte STAT5B (creatine-induced phosphorylation at S127) as the strong backup and CKB as a second backup. Use next quarter's in vivo slot for one blinded, powered study that re-tests the megakaryocyte Slc6a8 deletion and gives the megakaryocyte Stat5b deletion its first metastasis test.**

*Validation proposal for the portfolio committee. Basis: the CRE-MK-01 package only (source-data workbook, 87 sheets; phosphoproteomics table; study conventions). Every statistic below was recomputed from the raw values; "derived" marks tests the source file did not report. Megakaryocyte is abbreviated MK in tables.*

---

## 1. The decision in brief

1. **Megakaryocyte SLC6A8 is the only candidate shown to be necessary for the metastasis phenotype in the right cell lineage.** With Pf4-Cre deletion of Slc6a8, creatine no longer raised lung metastatic burden (Cre controls 2.4 → 7.9%; deletion 3.4 → 2.9%; the creatine effect differs between genotypes, P = 0.0003; Fig 3i, 4 mice per arm). Platelet aggregation, megakaryocyte creatine content and the megakaryocyte activation transcripts followed. Serum creatine rose equally in both genotypes and platelet counts did not change, so the deletion acts at the megakaryocyte and not on systemic exposure.
2. **STAT5B has the most mechanistic detail, but its metastasis evidence cannot be assigned to STAT5B or to megakaryocytes.** The in vivo result (Fig 6b) used a systemic inhibitor that blocks both STAT5A and STAT5B. The megakaryocyte Stat5b deletion was read out on transcripts and blots only, had no deletion-plus-vehicle arm, and left five receptor transcripts 1.4–1.9× above baseline (Fig 6g).
3. **CKB is supported only in cultured megakaryocytes** (Fig 4j, 4l). It has never been tested in an animal.
4. **GP6 and P2RY12 are readouts, not targets.** Nothing in the package intervenes on either. In volunteers the ADP response did not change (Fig 7c), so P2RY12 has no functional support in humans; platelet GP6 protein is the most consistent human marker.
5. **The pathway is silent without creatine.** Neither the Slc6a8 deletion nor the STAT5 inhibitor changed metastasis in vehicle-treated mice. Any indication is limited to creatine-exposed hosts, and stopping the supplement is the comparator every option has to beat.

The proposed study is the same whichever of SLC6A8 or STAT5B is called primary. The order reflects what is proven today; Section 4 states what would reverse it.

![Evidence summary](supporting/evidence_summary.png)

---

## 2. Evidence

### 2.1 What any target has to explain

| Finding | Source (n per arm) | Result |
|---|---|---|
| Oral creatine raises lung metastatic burden | 11 creatine-vs-vehicle comparisons: Fig 1b, 1f (two tumour-cell variants), 1k, 3i, 6b; Supp 1e, 1f, 1g, 1i (diet), 1k (4–10 mice) | 2.1–4.0× in every cohort, each P < 0.01. Pooled 3.2× (95% CI 2.7–3.7; derived, random-effects on log ratios) |
| It shortens survival | Fig 1c (10 vs 10), Fig 1l (20 vs 18) | Median 22 → 19 days and 16 → 14 days; log-rank P = 0.032 and 0.011 |
| Exposure is similar in mice and volunteers | Supp 1d, 1h; Fig 7b | Serum creatine 66 → 178 µM (gavage), 78 → 227 µM (5% creatine diet); volunteers 45 → 153–159 µM from day 3 |
| It is not a general-health effect | Supp 1a–1c, 3a | Body weight, food and water intake, white- and red-cell counts unchanged |
| The tumour cell's own SLC6A8 is not needed | Fig 1f: melanoma cells with Slc6a8 knock-down (mRNA 0.18×, Supp 2a); 6 mice | Creatine raised burden 3.5× with control cells and 3.2× with knock-down cells; knock-down × creatine P = 0.68 (derived) |
| Platelets carry the effect | Supp 2d (6 recipient mice); Fig 7g (5 recipient mice) | Platelets from creatine-treated donors: burden 5.9 → 17.9% (adjusted P = 0.0004), and 4.4% when donors also received aspirin. Volunteer platelets taken at day 7 vs day 0: 4.6 → 12.7% (P = 0.014) |
| Platelet reactivity changes, not platelet number | Fig 2a, 2b (3 mice); Fig 2d (5 mice); Supp 3c, 8b | Counts unchanged in mice and volunteers; six of nine megakaryocyte differentiation transcripts unchanged. Aggregation: ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56% (P = 0.0003–0.0011). Clot strength (TEG-MA) 39.7 → 54.0 mm (P = 0.049) |
| The responding cell is the megakaryocyte | Fig 2f (n = 3); Fig 2i | Eleven platelet-activation transcripts up 1.6–5.6×. GP6 and P2RY12 protein rise in megakaryocytes exposed to 0.2–2 mM creatine, not in platelets exposed directly (single blots) |
| The effect is early | Fig 1h (6 per time point) | No difference at 15 min; creatine arm higher from 6 h (1.5×) to 24 h (2.8×). The y-axis is not labelled in the sheet |
| No creatine, no effect | Vehicle arms of Fig 3i and Fig 6b | Burden 2.4 vs 3.4% (deletion) and 3.4 vs 3.6% (inhibitor): neither intervention lowers baseline metastasis |

### 2.2 The candidate targets

| | **SLC6A8 in megakaryocytes** (primary) | **STAT5B in megakaryocytes** (strong backup) | **CKB** (second backup) |
|---|---|---|---|
| Metastasis in vivo | Lineage deletion, full factorial, 4 per arm. Creatine adds 5.5 points of burden in Cre controls and −0.5 in deletion mice. P for a genotype-dependent creatine effect: 0.0003 (burden), 0.004 (foci), 0.0002 (lung weight) (Fig 3i; derived) | Systemic STAT5-IN-1 only, which blocks STAT5A and STAT5B; 5 per arm. Creatine adds 10.4 points without inhibitor and 0.9 with; P = 7×10⁻⁶ (Fig 6b; derived). The Stat5b deletion line was never challenged with tumour cells | Not tested |
| Platelets and MKs in vivo | Creatine effect on aggregation reversed: ADP +7 points in controls, −23 in deletion mice (Fig 3d, n = 3). MK creatine 13.7 → 72 in controls, 13.7 → 21 in deletion (Fig 3c, n = 3; creatine × genotype P = 0.045, derived). None of the 11 transcripts is induced by creatine in deletion mice (median 1.0× vs deletion vehicle; Fig 3f, n = 3). Serum creatine rises equally in both genotypes and platelet count is unchanged (Fig 3b, Supp 4b) | Transcripts: median 4.0× in wild type, 1.3× in deletion; P2ry12, Adra2a, Gp1ba, F2r and Gp6 still 1.4–1.9× (Fig 6g, n = 3). GP6 and P2RY12 blots blunted (Fig 6f). Creatine uptake and CKB induction intact, so STAT5B sits downstream of both (Fig 6e, 6f). No aggregation assay, no deletion-plus-vehicle arm, wild-type rather than Cre controls | No model exists |
| Cultured MKs | Liposomal creatine bypasses the deletion: 9 of 11 transcripts 2.1–4.0× (Supp 4e). The defect is creatine entry | STAT5-IN-1 prevents induction but also lowers baseline expression (median 0.56×) (Fig 6a) | Knock-down lowers all 11 creatine-induced transcripts (P ≤ 0.009); over-expression raises them 1.7–6.0× (Fig 4j, 4l; n = 3). Creatine and phosphocreatine pools do not change (Supp 5c) and phosphocreatine itself is inactive (Fig 4h) |
| Mechanism | Entry step | Phosphoproteomics (3 mice per group): a Stat5b phosphopeptide is up (log2 fold 5.7, P = 0.0012), but Q = 0.25 and the site is not in the file; a Stat5a peptide is unchanged. S127A removes the creatine-induced rise in pan-phospho signal on FLAG-tagged STAT5B (1.4× and 1.3× in wild-type protein; construct × creatine P = 0.024 and 0.043, derived; Fig 5e, 5f; 3 blots each; cell system not stated). The S127D mimic is high with or without creatine. Nuclear STAT5B is higher in megakaryocytes from creatine-treated mice (Supp 6h, 2 lanes per arm). Promoter ChIP signal at P2ry12, Gp6 and Rab4a up 2.7–12× (Fig 5j, Supp 6i; n = 3). The canonical pY694/699 mark is undetectable in megakaryocytes (Supp 6a) | Ckb mRNA 1.8× and protein up with creatine (Fig 4e, 4b). One in vitro kinase blot (Supp 6d). CKB over-expression raises pan-phospho signal on wild-type but not S127A STAT5B (Fig 5g, single blot) |
| Human node-level data | None | None | None |
| Main weaknesses | 4 per arm, unblinded, one experiment. SLC6A8 band reduced but still present in deleted megakaryocytes (Supp 4a). Deletion lowers baseline aggregation and creatine lowers it further (Fig 3d): a haemostasis question. No pharmacological tool in the package | Isoform and cell of action unresolved in vivo. Three vehicle and three creatine animals in Fig 6b have values identical to Supp 2d. The discovery screen has no peptide below Q = 0.17 | No in vivo evidence. Mechanism rests on single blots. CKB is far more abundant in brain than in megakaryocytes on the same blot (Fig 4b) |

Candidates set aside:

- **Tumour-cell SLC6A8.** Knock-down left the creatine effect intact (Fig 1f).
- **P2RY12.** Raised in mouse megakaryocytes and platelets, but human ADP-induced aggregation did not change (geometric mean 1.07×, 6 of 11 volunteers above baseline).
- **RAB4A.** Induced in mouse megakaryocytes; fell in all four volunteers at day 14 (0.28–0.53×).
- **Phosphocreatine or energy buffering.** Phosphocreatine did not reproduce the effect and CKB over-expression did not change the pools.
- **Canonical JAK–STAT5 signalling.** pY694/699 was undetectable in megakaryocytes while the Jurkat + IL-2 control worked; the Jak2 phosphopeptide was unchanged.

### 2.3 The volunteer cohort

Eleven healthy Asian volunteers (6 women, 5 men, aged 20–25, no NSAIDs) took 20 g/day of creatine monohydrate for 14 days. Each was compared with their own day 0; there was no control arm.

- **Platelet function at day 14** (maximum aggregation, geometric mean fold; volunteers above baseline; signed-rank P; derived): collagen 2.5× (9 of 11; 0.005), epinephrine 1.6× (10 of 11; 0.002), arachidonic acid 1.3× (9 of 11; 0.04), ADP 1.07× (6 of 11; 0.46). Nothing changed at day 3 and only the epinephrine response at day 7. Platelet counts were unchanged (Supp 8b).
- **Four volunteers sampled for molecular readouts.** Platelet GP6 protein rose in all four (2.0× at day 7, 2.6× at day 14). P2RY12 protein rose 1.65× at day 14 (all four; paired P = 0.025). CD41+ cell transcripts were heterogeneous and one volunteer barely responded (Fig 7d, 7e).
- **Transfer into mice.** Volunteer platelets taken at day 7 raised burden in recipient mice (Fig 7g); the number of donors is not recorded. At day 7 platelet GP6 protein was already up while the collagen response had not yet changed, so the protein marker moved before the aggregation assay did.
- **What this does and does not show.** The downstream platelet phenotype appears in people at a serum exposure matching the mouse. None of SLC6A8, CKB or STAT5B was measured in human cells.

### 2.4 Limits of the package

- **Conduct.** Animals were randomised, but allocation was not masked during the work or at readout, group sizes were not calculated, and sex was not analysed (male C57BL/6J and female BALB/cJ, so sex is confounded with strain). Effect sizes are probably optimistic.
- **Unit of analysis.** Fig 1i, 2c, 2j and Supp 4c count 8 microscope fields per group as n. They are not used as evidence here.
- **Duplicate values.** Three vehicle and three creatine animals have identical burden and foci values in Fig 6b and Supp 2d, two experiments with different designs. Both conclusions hold without the shared values (Fig 6b creatine vs creatine + inhibitor, adjusted P = 9×10⁻⁵; Supp 2d on the first three animals per arm, adjusted P = 0.0015 and 0.0005), but the records must be reconciled.
- **Incomplete designs.** The Stat5b deletion panels lack a deletion-plus-vehicle arm. The aspirin experiment lacks an aspirin-only arm.
- **Dose.** One creatine regimen per species (plus one diet cohort in mice); no dose–response and no washout anywhere.
- **Aggregation is not a stand-in for metastasis.** In Slc6a8-deleted mice creatine pushed aggregation well below vehicle (ADP 54 → 31%) while burden stayed at vehicle level. Aggregation is a pharmacodynamic readout; metastatic burden has to be the efficacy endpoint.
- **Discovery screen.** 238 of 5,812 phosphopeptide rows reach P < 0.05, about what chance gives; none has Q < 0.05.
- **Volunteer transcripts.** Volunteer 4's RAB27B and PITPNB values cannot be reproduced from the listed ΔCt rows.
- **Blots.** The conventions say blots were repeated at least twice, but the file shows one to three lanes per condition and gives densitometry only for Fig 5e, 5f and 7e. I assessed the other images by eye.
- **Lineage restriction.** That Pf4-Cre acts in the megakaryocyte lineage is taken from the study conventions; the package has no reporter or off-lineage check.
- **Tumour type.** Only Fig 1f names one (melanoma). The strain list (male C57BL/6J, female BALB/cJ) implies at least one further setting, but the other metastasis panels do not say which.

---

## 3. Follow-up studies

**Indication the package supports:** preventing metastatic seeding in hosts exposed to supplemental creatine. It does not support use without creatine exposure (vehicle arms were unaffected) or treatment of established metastases (never tested).

**Sequence:** Study 1 takes the in vivo slot. Study 3 is cell-based (megakaryocytes from small donor groups, no tumour challenge) and runs alongside it, as do the record checks in Section 5. Study 2 takes the following slot. Study 4 does not depend on the mouse results and can be prepared now.

### Study 1 — megakaryocyte-lineage deletion head-to-head (the in vivo slot)

| Item | Specification |
|---|---|
| Question | Does megakaryocyte-lineage loss of Slc6a8, and separately of Stat5b, remove the creatine-attributable excess in lung metastasis? |
| Population | Pf4-Cre;Slc6a8 fl/fl with Pf4-Cre;Slc6a8 +/+ littermates. Pf4-iCre;Stat5b fl/fl with Pf4-iCre;Stat5b +/+ littermates (Cre-matched; the existing Stat5b panels used wild-type controls). Both sexes, balanced and analysed. Both lines were used in CRE-MK-01, so the limit is breeding, not model generation |
| Setting modelled | Lung metastasis in the tumour model used for Fig 3i. Melanoma is the only tumour type named in the file; confirm the model from study records |
| Core arms | For each line: genotype × (vehicle or creatine) = 8 arms. Creatine as in CRE-MK-01: 42.5 mg/mL, 400 µL by mouth, three times a week, with the same lead-in and timing as the Fig 3i experiment |
| Comparators | Water vehicle; Cre-positive wild-type littermates. If capacity allows, in creatine-treated mice and in this order: STAT5-IN-1 5 mg/kg/day (DMSO control) in Stat5b-deleted mice and their controls; aspirin 30 mg/kg/day in controls; creatine stopped before tumour challenge |
| Size | 12 per arm (6 per sex), 96 mice for the core arms. This gives 92% power to detect complete loss of a 2.5× creatine effect (deliberately below the 3.2× pooled estimate) with within-arm variability set slightly above the median seen so far, and 84% power for a 70% loss if the effect is as large as observed (two-sided α = 0.025 per line; simulation). Fallback if the colony cannot supply this: 8 per arm (75% and 93% power for complete loss under the two assumptions) |
| Primary endpoint | Lung metastatic burden (% of lung area), scored blind |
| Secondary endpoints | Number of metastatic foci; lung weight |
| Mechanistic readouts | Ex vivo platelet aggregation to ADP, collagen and thrombin. Megakaryocyte creatine. Megakaryocyte and platelet GP6 and P2RY12 protein with densitometry. The 11-transcript panel. CKB, SLC6A8, STAT5B and STAT5A protein in megakaryocytes (deletion efficiency, compensation). Serum creatine (exposure check) |
| Safety readouts | Blood count; bleeding time. Slc6a8-deleted platelets aggregated less at baseline, and STAT5-IN-1 lowered baseline receptor transcripts |
| Conduct | Randomised within litter and sex; allocation concealed; blinded scoring; the animal is the unit; animal identifiers carried into the data file |
| Analysis | Log burden. Creatine × genotype term for each line. Effect reported as the share of the control creatine effect that remains, with 95% CI. On this measure the existing data give −18% for the Slc6a8 deletion (approximate 95% interval −62 to +20), +18% for STAT5-IN-1 (−6 to +46) and 82% for tumour-cell knock-down (46 to 137). No field-level statistics |
| Decision | Interpretable only if creatine raises burden at least 2× in both control genotypes. SLC6A8 confirmed if the creatine × genotype term is significant and no more than 30% of the creatine effect remains in deletion mice. STAT5B promoted if it meets the same bar, aggregation normalises and the inhibitor adds nothing in deleted mice. 30–70% remaining keeps STAT5B as backup and points to STAT5A. More than 70% remaining retires it |

### Studies 2–4

| | Study 2 — platelet-transfer test | Study 3 — closing the mechanism on the backups | Study 4 — controlled volunteer study |
|---|---|---|---|
| Question | Is the genotype effect carried by the platelets themselves? | Is S127 on endogenous STAT5B the creatine-responsive site, and does CKB act through its catalytic activity? | Does the human platelet effect survive a placebo control, and at what dose and for how long? |
| Population | Wild-type tumour-bearing recipients; donors are creatine-treated control, Slc6a8-deleted and Stat5b-deleted mice | Primary megakaryocytes from vehicle- and creatine-treated mice of each genotype; cell-based only | Healthy adults of both sexes over a wider age and ancestry range than the 20–25-year-old Asian cohort; NSAID-free. Patients with cancer are studied observationally only (existing creatine users vs non-users); we do not propose dosing patients |
| Setting | Same lung-metastasis model as Study 1 | Not applicable | Not applicable |
| Comparators | Vehicle-donor platelets; creatine + aspirin donors; the missing aspirin-only donor arm | Slc6a8-deleted megakaryocytes as the negative control; wild-type vs S127A STAT5B re-expressed in Stat5b-deleted cells; wild-type vs catalytically inactive CKB; STAT5A knock-down in Stat5b-deleted cells | Placebo, randomised double-blind crossover with washout. 20 g/day for 14 days as in CRE-MK-01, plus a lower daily dose |
| Primary endpoint | Lung metastatic burden in recipients, scored blind | Phosphorylation of S127 on endogenous STAT5B, site-resolved and with false-discovery control (6 or more per group; the current screen had 3) | Change in collagen- and epinephrine-induced maximum aggregation at day 14 vs placebo |
| Other readouts | Foci; donor platelet aggregation and GP6 protein; donors per arm recorded | 11-transcript panel; GP6 protein; nuclear STAT5B | ADP and arachidonic-acid responses; platelet GP6 protein; serum creatine; CKB protein and STAT5B phosphorylation in CD41+ cells; time to return to baseline after stopping |
| Size | 10 recipients per arm (Supp 2d had 6) | Independent animals as replicates | About 32 completers: 90% power for 75% of the effect seen in CRE-MK-01 |
| What it decides | Separates platelets from any other Pf4-expressing cell; completes the aspirin benchmark | Whether STAT5B and CKB stand on endogenous-protein evidence rather than tagged-protein blots | Whether the finding translates, which node moves in human cells, and whether simply stopping creatine is enough |

**After Study 1 — breadth of indication.** Repeat the winning intervention in a second tumour type from the CRE-MK-01 set and in a model where metastases arise from a primary tumour. The package reports lung burden only, names melanoma once, and does not record how tumour cells were introduced, so breadth across tumour types and routes of spread is untested. Endpoints and conduct as in Study 1, plus primary-tumour growth as a control readout.

---

## 4. What would move one choice above another

| Result | Consequence |
|---|---|
| Stat5b deletion leaves no more than 30% of the creatine effect, and STAT5-IN-1 adds nothing in deleted mice | **STAT5B becomes primary.** It would then have lineage-specific proof plus an active compound, and unlike blocking uptake it could protect someone who keeps taking creatine |
| Stat5b deletion leaves 30–70% | STAT5B stays a backup; test STAT5A plus STAT5B together, since the inhibitor blocks both |
| Stat5b deletion leaves more than 70% | STAT5B retired; the Fig 6b result was not megakaryocyte STAT5B |
| Slc6a8 deletion fails to replicate under blinding | The axis itself is in doubt; stop before further target work |
| Slc6a8-deleted mice bleed longer, or residual SLC6A8 means the deletion cannot be interpreted | SLC6A8 demoted in favour of a downstream node |
| Catalytically inactive CKB loses the over-expression effect, and S127 phosphorylation of endogenous STAT5B tracks CKB | CKB moves above STAT5B as the enzymatic step; it then needs a megakaryocyte deletion model before an in vivo slot |
| Aspirin alone normalises metastasis in creatine-treated mice | Any new target has to beat an existing antiplatelet; the bar rises for all three |
| Platelet reactivity returns to baseline within days of stopping creatine | The case for a drug narrows to people who cannot or will not stop |
| The placebo-controlled volunteer study does not reproduce the collagen and epinephrine responses, or only at 20 g/day | Translational case weakens for every candidate |
| CKB protein or STAT5B phosphorylation changes in human CD41+ cells | Whichever node moves in human cells gains |

---

## 5. To settle before the committee meets

- Reconcile the animals shared between Fig 6b and Supp 2d against the study records.
- Record the tumour model for every metastasis panel and the y-axis of Fig 1h.
- Check volunteer 4's RAB27B and PITPNB rows in Fig 7d.
- Confirm the cell system and antibody for Fig 5e–5j and Supp 6i, and define the "3A" construct.

---

## 6. How the numbers were derived

- **Reproduction.** I recomputed every test in the workbook from the raw values: 71 two-group t tests, all one-way ANOVA/Tukey, Dunnett and Šidák comparisons, and both log-rank tests. All reported P values were reproduced; the smallest ones differ only in numerical precision.
- **Added tests.**
  - Factorial panels: a linear model with a creatine × intervention term, because the source reports pairwise comparisons only.
  - Transcripts: t tests on ΔCt, which is the log scale.
  - Volunteer data: one-sample tests on log fold change and signed-rank tests, because the source analysed paired data as unpaired.
  - Across cohorts: random-effects pooling of log ratios for the 11 creatine-vs-vehicle comparisons.
  - Small groups: the workbook gives Welch and Mann–Whitney P values beside every two-group t test, because groups of 3–6 are too small for the normality test named in the conventions.
  - Integrity: an exact-match scan for values repeated across sheets.
  - Sizing: simulation-based power.
- **Phosphoproteomics.** Summarised from the supplied table using the study's own screen (P < 0.05 with fold ≥ 1.2 or ≤ 0.83) and its Q column.
- **Not done.** I did not re-quantify blot images and used no external data.

Files are in this folder:

- CRE-MK-02_validation_proposal.md, and the same text as CRE-MK-02_validation_proposal.pdf
- supporting/evidence_summary.png
- supporting/CRE-MK-01_reanalysis.xlsx (every recomputed test, the panel table in the Appendix, integrity flags, power)
- supporting/scripts/

---

## Appendix. Every panel in the source workbook

One row per sheet (87). Results are recomputed from the raw values; image-only panels were read by eye. The same table, with every test, is in supporting/CRE-MK-01_reanalysis.xlsx.

| Panel | System, design and n | Result | Role in this proposal |
|---|---|---|---|
| Fig 1a | Mouse lung; Vehicle vs creatine, n=6 mice/arm | Lung weight 0.227 vs 0.324 g (P=0.0003); PET SUV-BW 418 vs 894 (P=0.0026) | Foundation: creatine raises lung tumour load |
| Fig 1b | Mouse lung; Vehicle vs creatine, n=6 mice/arm | Burden 5.2 vs 16.2% (3.1×, P=0.0005); foci 27.7 vs 53.2 (P=0.0006) | Foundation |
| Fig 1c | Mouse survival; n=10 vs 10, all events | Median 22 vs 19 d; log-rank chi2 4.58, P=0.032 | Foundation |
| Fig 1f | Mouse lung; melanoma cells ± sh-Slc6a8; 2×2, n=6 mice/arm | Creatine raises burden in sh-scrambled (4.6 → 15.9%) and in sh-Slc6a8 tumours (5.8 → 18.3%); knock-down × creatine interaction P=0.68 (burden), 0.95 (foci) | Tumour-cell SLC6A8 is not the target |
| Fig 1h | Not labelled (time course 0.25-24 h); n=6 per arm per time point | No difference at 0.25 h (P=0.31); creatine higher at 6, 12, 24 h (1.5×, 1.8×, 2.8×; P=0.0002, 0.026, 0.004) | Early (hours) effect; y-axis identity to be confirmed |
| Fig 1i | Lung sections, GFP+ cells; 8 random fields/group (field-level n) | 9.1 vs 20.4 cells/field (P=5.5×10^-7, pseudo-replicated) | Supportive only |
| Fig 1j | Mouse lung (second cohort); n=6 mice/arm | Lung weight 0.185 vs 0.302 g (P=0.0011); SUV-BW 615 vs 1032 (P=0.0008) | Foundation |
| Fig 1k | Mouse lung (second cohort); n=6 mice/arm | Burden 7.2 vs 16.4% (2.3×, P=5.8×10^-5); foci 25.5 vs 42.2 (P=5.7×10^-5) | Foundation |
| Fig 1l | Mouse survival (second cohort); n=20 vs 18, all events | Median 16 vs 14 d; log-rank chi2 6.47, P=0.011 | Foundation; unequal n unexplained |
| Fig 2a | Mouse blood count; n=3 mice/arm | PLT 789 vs 789; PCT, PDW, MPV unchanged (all P>0.3) | Effect is not on platelet number |
| Fig 2b | Mouse platelets (peripheral blood); n=3 mice/arm | Aggregation: ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56% (P=0.0003, 0.0005, 0.0011) | Platelet hyper-reactivity |
| Fig 2c | Mouse platelets; 8 random fields/group | Alpha-granules 2.0 vs 3.9 (P=0.008, field-level) | Supportive only |
| Fig 2d | Mouse whole blood TEG; n=5 mice/arm | MA 39.7 vs 54.0 mm (P=0.049; Welch 0.052); R, K, alpha ns | Borderline |
| Fig 2e | Isolated mouse platelets; 3 lanes/arm | GP6, P2RY12 immunoblots, vehicle vs creatine; no densitometry in file | Qualitative |
| Fig 2f | Mouse primary MKs (bone marrow); n=3/arm, 11 transcripts | All 11 up 1.6-5.6× (10/11 P<0.05; Adra2a P=0.06) | MK activation programme |
| Fig 2g | Isolated mouse MKs; 3 lanes/arm | GP6, P2RY12 higher with creatine; no densitometry | Qualitative |
| Fig 2i | MKs and platelets treated in vitro (0, 0.2, 2 mM); 1 lane/condition | GP6/P2RY12 rise in MKs at 0.2 and 2 mM; no change in platelets treated directly | Creatine acts on MKs, not on platelets directly |
| Fig 2j | Mouse platelets, PKH label; 8 random fields/group | PKH+ area 1.9 vs 4.5% (P=0.0014, field-level) | Supportive only |
| Fig 3b | Mouse serum; n=5 mice/arm, both genotypes | Serum creatine rises equally: 89 → 239 µM (Cre control), 89 → 218 µM (deletion) | Systemic exposure intact in deletion mice |
| Fig 3c | Mouse primary MKs, intracellular; n=3 mice/arm | Creatine 13.7 → 72.1 in Cre controls (P=0.049; Welch 0.105); 13.7 → 21.1 in deletion (P=0.20); interaction P=0.045 | Uptake needs SLC6A8; small n |
| Fig 3d | Mouse platelets; 2×2, n=3 mice/arm | Creatine raises aggregation in controls (ADP +7, collagen +12, thrombin +13 points) and lowers it in deletion mice (-23, -10, -10); deletion lowers vehicle baseline (ADP -9, collagen -4, thrombin -16) | SLC6A8 node; baseline haemostasis flag |
| Fig 3f | Mouse primary MKs; 2×2, n=3/arm, 11 transcripts | Controls: 11/11 up 2.0-5.5×. Deletion + creatine vs deletion vehicle: median 1.0×, 0/11 significantly up; Fcgr2a stays ~3× vs reference | SLC6A8 node |
| Fig 3g | Cell source not labelled; 2 lanes/arm | GP6/P2RY12 rise with creatine in Cre controls, not in deletion | Qualitative |
| Fig 3i | Mouse lung; 2×2, n=4 mice/arm | Burden 2.4 → 7.9% in Cre controls, 3.4 → 2.9% in deletion; interaction P=0.0003 (burden), 0.004 (foci), 0.0002 (lung weight) | Primary evidence for SLC6A8 |
| Fig 4a | Mouse primary MKs; brain tissue; n=3 mice/arm | MK creatine 42 → 129 µmol/g (P=0.0004); brain 96 → 114 (P=0.027) | MKs accumulate creatine; brain also takes it up |
| Fig 4b | MKs and brain; 1 lane/condition | CKB band stronger in MKs from creatine mice; CKB abundant in brain in both arms | CKB induction; CKB not MK-restricted |
| Fig 4c | Mouse primary MKs; brain tissue; n=3 mice/arm | Phosphocreatine MK 0.37 → 1.46 (P=0.0006); brain 0.32 → 0.63 (P=0.031) | — |
| Fig 4d | MKs in vitro; n=3 | Creatine 30 → 109 (P=0.005); sheet label reads "Creatinine" | Label to confirm |
| Fig 4e | MKs; n=3 | Ckb mRNA 1.8× (P=0.011); CKB blot control vs creatine | CKB induction |
| Fig 4f | MKs in vitro; n=3 | Phosphocreatine 0.23 → 1.24 (P=0.023; Welch 0.061) | — |
| Fig 4g | MKs in vitro; 1 lane/condition | Creatine raises CKB, GP6, P2RY12; phosphocreatine does not raise GP6/P2RY12 | Qualitative |
| Fig 4h | Mouse primary MKs in vitro; n=3/arm, 11 transcripts | Creatine 1.9-11.5× (11/11 P<0.05); phosphocreatine 0.29-1.12× (none up) | Signal is creatine, not phosphocreatine |
| Fig 4i | MKs in vitro; 1 lane/condition | si-Ckb blunts creatine-induced GP6/P2RY12 | Qualitative |
| Fig 4j | Mouse primary MKs in vitro; 2×2, n=3/arm | Creatine+si-scrambled 1.7-7.4×; creatine+si-Ckb 0.46-1.78× (all 11 lower, P<=0.009); si-Ckb alone lowers baseline (0.55-0.90×) | CKB required (in vitro) |
| Fig 4k | MKs in vitro; 1 lane/condition | CKB over-expression raises GP6, P2RY12 | Qualitative |
| Fig 4l | Mouse primary MKs in vitro; n=3/arm | CKB over-expression: 11/11 up 1.7-6.0× (all P<0.05) | CKB sufficient (in vitro) |
| Fig 5e | STAT5B-FLAG constructs (EV, WT, S127A, 3A, S127D); cell system not stated; n=3 blots | pan-phospho/FLAG: creatine raises WT 1.39× (P=0.009); S127A 1.06× (ns); S127D high in both; WT vs S127A × creatine interaction P=0.024 | S127 evidence: over-expressed tagged protein, pan-phospho antibody |
| Fig 5f | As 5e (second series); n=3 blots | WT 1.28× (P=0.087); S127A 0.88×; interaction P=0.043 | — |
| Fig 5g | si-GATM cells; STAT5B-FLAG WT/S127A; CKB-EV/OE; 1 blot | CKB over-expression raises pan-phospho of WT, not S127A | Qualitative |
| Fig 5h | Nuclear fraction; si-scrambled vs si-CKB; vehicle vs creatine; 1 blot | Creatine raises nuclear pan-phospho STAT5B-FLAG; lost with si-CKB | Qualitative |
| Fig 5i | STAT5B-FLAG WT or S127A with CKB-EV/OE; 1 blot each | Smeared pan-phospho signal; not interpretable without quantification | Weak |
| Fig 5j | ChIP-qPCR (antibody and cells not stated in sheet); n=3/arm | Creatine raises promoter signal: P2ry12 -0.2/-1/-2 kb 12×/4.7×/4.8×; Gp6 -1 kb 3.8×, -0.2 kb 2.9×; exons unchanged | Promoter occupancy |
| Fig 6a | Mouse primary MKs; 2×2, n=3/arm | Creatine 1.9-42× (10/11 P<0.05); creatine+STAT5-IN-1 0.18-1.18× (0/11 up); inhibitor alone lowers baseline (median 0.56×) | STAT5 node; inhibitor not creatine-specific |
| Fig 6b | Mouse lung; 2×2, n=5 mice/arm | Burden 3.4 → 13.9% without inhibitor, 3.6 → 4.5% with; interaction P=7×10^-6; foci interaction P=0.0007; inhibitor alone no effect | In vivo pharmacology (STAT5A/B, systemic); 3+3 values duplicated in Supp 2d |
| Fig 6d | Isolated MKs; 1 lane/genotype | STAT5B band absent in Pf4-iCre;Stat5bfl/fl | Deletion check |
| Fig 6e | Mouse primary MKs, intracellular; 3 arms, n=3 | Creatine 20 → 95 (WT) and 98 (Stat5b deletion + creatine); deletion does not affect uptake | STAT5B is downstream of uptake |
| Fig 6f | Isolated MKs and platelets; 1 lane/condition | CKB still induced in Stat5b-deleted MKs; GP6/P2RY12 induction blunted in MKs and platelets | Qualitative; places CKB upstream |
| Fig 6g | Mouse primary MKs; 3 arms, n=3 | WT+creatine 2.1-4.5×; deletion+creatine median 1.3×: 6 genes at/below baseline, P2ry12/Adra2a/Gp1ba/F2r/Gp6 still 1.4-1.9×; all 11 lower than WT+creatine | STAT5B node: molecular only, no deletion-vehicle arm |
| Fig 7b | Human serum (before breakfast); n=11, days 0/3/7/14 | 45 → 153/156/159 µM (3.4-3.5×; paired P<1×10^-7) | Human exposure matches mouse (66 → 178 µM) |
| Fig 7c | Human platelets; n=11, fold vs own day 0 | Day 14 max aggregation: collagen geo-mean 2.5× (9/11 up, Wilcoxon P=0.005); epinephrine 1.6× (10/11, P=0.002); arachidonic acid 1.3× (P=0.04); ADP 1.07× (6/11, P=0.46) | Human function; ADP pathway not engaged |
| Fig 7d | Human circulating CD41+ cells; n=4 volunteers, triplicate wells | Heterogeneous; day 14: ADRA2A, RAB27B, PITPNB up in 4/4; GP6 3/4; P2RY12 3/4; RAB4A down in 4/4 (0.28-0.53×) | n=4; volunteer 2 largely unresponsive; RAB4A opposite to mouse |
| Fig 7e | Human platelets, immunoblot densitometry; n=4 volunteers | GP6/ACTB 0.42 → 0.83 (d7) → 1.08 (d14), 4/4 up; P2RY12/ACTB 0.73 → 1.21 (d14), 4/4 up (paired P=0.025) | Best human marker = GP6 protein |
| Fig 7g | Recipient mice given human platelets (day 0 vs day 7 donors); n=5 mice/arm | Burden 4.6 vs 12.7% (P=0.014); foci 21.8 vs 39.4 (P=0.012) | Human platelets carry the effect; donor number not recorded |
| Supp 1a | Mouse body weight; n=4/arm | No difference at day 0 or 7 | Tolerability |
| Supp 1b | Food intake; n=6/arm | No difference | — |
| Supp 1c | Water intake; n=6/arm | No difference | — |
| Supp 1d | Mouse serum; n=6/arm | Creatine 66 → 178 µM (2.7×, P=4×10^-10) | Exposure |
| Supp 1e | Mouse lung (additional cohort); n=6/arm | Burden 16.2 → 33.6% (P=0.001) | Foundation; model not named |
| Supp 1f | Mouse lung (additional cohort); n=4/arm | Burden 3.9 → 10.8% (P=0.009) | Foundation; model not named |
| Supp 1g | Mouse lung (additional cohort); n=10/arm | Burden 7.6 → 26.2% (P=2.5×10^-7) | Foundation; model not named |
| Supp 1h | Mouse serum, creatine diet; n=4/arm | 78 → 227 µM (P=2×10^-5) | Exposure by diet |
| Supp 1i | Mouse lung, creatine diet; n=4/arm | Burden 7.3 → 26.2% (P=0.005) | Route-independent |
| Supp 1k | Mouse lung (additional cohort); n=10/arm | Burden 3.8 → 13.4% (P=0.0008) | Foundation; model not named |
| Supp 2a | Tumour cells; n=3 | Slc6a8 mRNA 0.18×; SLC6A8 blot reduced | Knock-down check for Fig 1f |
| Supp 2d | Recipient mice given donor platelets; 3 arms, n=6 | Burden 5.9% (vehicle donors), 17.9% (creatine donors), 4.4% (creatine+aspirin donors); adjP=0.0004 and 0.0001 | Platelets carry the effect; aspirin benchmark; no aspirin-only arm; 3+3 values duplicated in Fig 6b |
| Supp 3a | Mouse blood count; n=5/arm | WBC, lymphocytes, monocytes, RBC unchanged | — |
| Supp 3c | MKs; n=3/arm, 9 maturation genes | Nfe2, Gata1, Zfpm1, Itgb3, Tubb1, Lims1 unchanged; Hsd3b1 1.4×, Casp12 1.9×, Myl9 0.5× | No broad maturation shift |
| Supp 4a | Isolated MKs; 1 lane/genotype | SLC6A8 band reduced, not absent, in Pf4-Cre;Slc6a8fl/fl | Deletion incomplete on the one blot |
| Supp 4b | Mouse blood; 2×2, n=3 | PLT unchanged by genotype or creatine | — |
| Supp 4c | Platelets; 8 fields/group | Alpha-granules rise with creatine in controls only (field-level) | Supportive only |
| Supp 4e | MKs from Pf4-Cre;Slc6a8fl/fl; 3 arms, n=3 | Free creatine: median 1.0×; liposomal creatine: 9/11 genes up 2.1-4.0× | Rescue: the defect is creatine entry |
| Supp 5a | MKs; n=3 | Gatm, Gamt unchanged | No change in synthesis genes |
| Supp 5b | MKs in vitro; 1 lane/condition | si-Ckb reduces, over-expression raises CKB | Reagent check; knock-down partial |
| Supp 5c | MKs in vitro; n=3 | CKB over-expression does not change creatine (P=0.61) or phosphocreatine (P=0.16) | CKB effect not via metabolite pools |
| Supp 6a | Isolated MKs; Jurkat ± IL-2 control; 3 lanes/arm | pSTAT5A/B Y694/699 not detected in MKs in either arm; positive control works; total STAT5B unchanged | Canonical STAT5 activation not involved |
| Supp 6d | In vitro reaction, His-CKB ± with ATP; 1 blot | pan-phospho signal on FLAG substrate stronger with His-CKB | Single blot; no mutant controls in panel |
| Supp 6e | 293T; 1 blot | CKB over-expression check | — |
| Supp 6f | 293T; 1 blot | GATM knock-down check | — |
| Supp 6g | 293T; 1 blot | CKB knock-down check | — |
| Supp 6h | Isolated MKs, nuclear fraction; 2 lanes/arm | Nuclear STAT5B higher with creatine | Qualitative |
| Supp 6i | ChIP-qPCR, Rab4a; n=3/arm | -0.2 kb 5.5× (adjP=5×10^-5), -1 kb 2.7× (adjP=0.04); exon, -2 kb unchanged | Promoter occupancy |
| Supp 7a | Mouse blood count, STAT5-IN-1; 2×2, n=3 | No significant change in PLT, PCT, MPV, PDW (wide CIs) | Safety signal absent but underpowered |
| Supp 7b | Mouse blood count, Stat5b deletion; 3 arms, n=3 | No significant change | — |
| Supp 8a | Volunteers; n=11 | BMI unchanged (paired P=0.24) | — |
| Supp 8b | Volunteers, blood count; n=11 | PLT, PCT, MPV, PDW unchanged | Not a platelet-number effect in humans |
| Supp 8c | Human CD41+ cells vs monocytes vs MEG-01; n=3 | CD41 transcript ~17× higher in CD41+ fraction than monocytes | Purity check for Fig 7d |
| Supp 8d | Human platelets, 4 volunteers × 4 time points; 1 lane each | Source blots for Fig 7e | — |
