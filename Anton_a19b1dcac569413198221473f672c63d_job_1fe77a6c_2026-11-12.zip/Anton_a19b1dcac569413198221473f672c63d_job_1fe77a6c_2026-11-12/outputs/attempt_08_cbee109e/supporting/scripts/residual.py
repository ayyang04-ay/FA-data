from qpcr import *
import io, contextlib
def run(sheet, defs, title, comps=None):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        df, data = analyze(sheet, defs, title, comparisons=comps, show=False)
    return df, data
out = {}
# Slc6a8 KO
df,_ = run('Fig. 3f', [('WTcre','G','I'),('KOveh','K','M'),('KOcre','O','Q')], '', [('KOcre','KOveh')])
t = pd.DataFrame({'gene':df.gene, 'cre_FC':df.WTcre_FC, 'pert_veh_FC':df.KOveh_FC, 'pert_cre_FC':df.KOcre_FC})
t['cre_effect_within_pert'] = t.pert_cre_FC/t.pert_veh_FC
t['P_within_pert'] = df['KOcre_vs_KOveh_P']
t['resid_vs_WTveh'] = (t.pert_cre_FC-1)/(t.cre_FC-1)
out['Slc6a8 MK-KO (Fig 3f)'] = t
df,_ = run('Fig.6a', [('creatine','G','I'),('veh_inh','K','M'),('cre_inh','O','Q')], '', [('cre_inh','veh_inh')])
t = pd.DataFrame({'gene':df.gene, 'cre_FC':df.creatine_FC, 'pert_veh_FC':df.veh_inh_FC, 'pert_cre_FC':df.cre_inh_FC})
t['cre_effect_within_pert'] = t.pert_cre_FC/t.pert_veh_FC; t['P_within_pert']=df['cre_inh_vs_veh_inh_P']; t['resid_vs_WTveh']=(t.pert_cre_FC-1)/(t.cre_FC-1)
out['STAT5-IN-1 (Fig 6a)'] = t
df,_ = run('Fig. 4j', [('siCkb','G','I'),('cre_siScr','K','M'),('cre_siCkb','O','Q')], '', [('cre_siCkb','siCkb')])
t = pd.DataFrame({'gene':df.gene, 'cre_FC':df.cre_siScr_FC, 'pert_veh_FC':df.siCkb_FC, 'pert_cre_FC':df.cre_siCkb_FC})
t['cre_effect_within_pert'] = t.pert_cre_FC/t.pert_veh_FC; t['P_within_pert']=df['cre_siCkb_vs_siCkb_P']; t['resid_vs_WTveh']=(t.pert_cre_FC-1)/(t.cre_FC-1)
out['si-Ckb (Fig 4j)'] = t
df,_ = run('Fig. 6g', [('WTcre','G','I'),('KOcre','K','M')], '', [('WTcre','KOcre')])
t = pd.DataFrame({'gene':df.gene, 'cre_FC':df.WTcre_FC, 'pert_veh_FC':np.nan, 'pert_cre_FC':df.KOcre_FC})
t['cre_effect_within_pert'] = np.nan; t['P_within_pert']=np.nan; t['resid_vs_WTveh']=(t.pert_cre_FC-1)/(t.cre_FC-1)
t['P_KOcre_vs_WTveh'] = df['KOcre_P']; t['P_KOcre_vs_WTcre']=df['WTcre_vs_KOcre_P']
out['Stat5b MK-KO (Fig 6g)'] = t
pd.set_option('display.width',250)
for k,t in out.items():
    print('==',k); print(t.round(3).to_string(index=False))
    print('   median creatine FC (control arm) %.2f; median FC in perturbed+creatine %.2f; median residual fraction vs WT-veh %.2f; genes with pert+cre FC>=1.3: %d/11' % (t.cre_FC.median(), t.pert_cre_FC.median(), t.resid_vs_WTveh.median(), (t.pert_cre_FC>=1.3).sum()))
    if t.cre_effect_within_pert.notna().any():
        print('   within-perturbation creatine effect: median %.2f; n genes >=1.3x & P<0.05: %d' % (t.cre_effect_within_pert.median(), ((t.cre_effect_within_pert>=1.3)&(t.P_within_pert<0.05)).sum()))
import pickle; pickle.dump(out, open('residual_tables.pkl','wb'))
