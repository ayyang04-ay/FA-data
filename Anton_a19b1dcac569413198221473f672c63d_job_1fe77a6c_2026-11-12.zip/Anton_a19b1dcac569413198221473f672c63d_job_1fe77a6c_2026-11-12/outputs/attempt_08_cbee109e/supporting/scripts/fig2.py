from common import *
print('=== Fig 2a CBC (n=3) ===')
for lab,r0 in [('PLT',4),('PCT',12),('PDW',19),('MPV',27)]:
    a=col('Fig. 2a','B',r0,r0+2); b=col('Fig. 2a','C',r0,r0+2)
    print(fmt(ttest(a,b,lab)))
print(' reported P:', cell('Fig. 2a','F4'), cell('Fig. 2a','F12'), cell('Fig. 2a','F19'), cell('Fig. 2a','F27'))
print('=== Fig 2b aggregation (n=3) ===')
for r,lab in [(4,'ADP'),(5,'Collagen'),(6,'Thrombin')]:
    a=row('Fig. 2b',r,'B','D'); b=row('Fig. 2b',r,'E','G')
    print(fmt(ttest(a,b,lab)), a, b)
print(' reported P:', cell('Fig. 2b','B18'), cell('Fig. 2b','B32'), cell('Fig. 2b','B45'))
print('=== Fig 2c alpha granules (8 fields) ===')
print(fmt(ttest(col('Fig. 2c','B',4,11), col('Fig. 2c','C',4,11),'a-granules')), '| reported', cell('Fig. 2c','F5'), cell('Fig. 2c','F9'))
print('=== Fig 2d TEG (n=5) ===')
for lab,r0 in [('R',4),('K',12),('alpha',20),('MA',28)]:
    a=col('Fig. 2d','B',r0,r0+4); b=col('Fig. 2d','C',r0,r0+4)
    print(fmt(ttest(a,b,lab)))
print(' reported P:', cell('Fig. 2d','F4'), cell('Fig. 2d','F12'), cell('Fig. 2d','F20'), cell('Fig. 2d','F28'))
print('=== Fig 2j PKH (8 fields) ===')
print(fmt(ttest(col('Fig. 2j','B',4,11), col('Fig. 2j','C',4,11),'PKH+ area')), '| reported', cell('Fig. 2j','F4'), cell('Fig. 2j','F8'))
