from common import *
import numpy as np
def logrank(t1, t2):
    # all events
    times = np.unique(np.concatenate([t1,t2]))
    O1=E1=V=0
    for t in times:
        n1 = np.sum(t1>=t); n2 = np.sum(t2>=t); n = n1+n2
        d1 = np.sum(t1==t); d2 = np.sum(t2==t); d = d1+d2
        if n>1:
            E1 += d*n1/n
            V += d*(n1/n)*(n2/n)*(n-d)/(n-1)
        O1 += d1
    chi2 = (O1-E1)**2/V
    from scipy.stats import chi2 as c2
    return chi2, c2.sf(chi2,1), O1, E1
for sh, rows in [('Fig. 1c',(4,23)), ('Fig. 1l',(4,41))]:
    ws = wb()[sh]
    v=[];c=[]
    for r in range(rows[0], rows[1]+1):
        t = ws[f'A{r}'].value
        if ws[f'B{r}'].value is not None: v.append((t, ws[f'B{r}'].value))
        if ws[f'C{r}'].value is not None: c.append((t, ws[f'C{r}'].value))
    tv = np.array([x[0] for x in v],float); tc = np.array([x[0] for x in c],float)
    print(sh, 'vehicle n=',len(tv),'events', sum(x[1] for x in v), 'median', np.median(tv), '| creatine n=', len(tc), 'events', sum(x[1] for x in c), 'median', np.median(tc))
    chi2,p,O1,E1 = logrank(tv,tc)
    print('   log-rank chi2=%.3f P=%.4f'%(chi2,p), '| reported', [ws[a].value for a in (['F6','F8'] if sh=='Fig. 1c' else ['F5','F7'])])
    print('   vehicle times', tv, '\n   creatine times', tc)
    # hazard ratio (Mantel-Haenszel style) 
    O2 = len(tc); E2 = len(tv)+len(tc)-E1
    print('   HR (creatine vs vehicle, O/E ratio)= %.2f' % ((O2/E2)/(O1/E1)))
    try:
        from lifelines import CoxPHFitter
    except Exception as e:
        pass
