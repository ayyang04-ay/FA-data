from common import *
ws = wb()['Fig. 7d']
# blocks: gene label rows
blocks = []
for r in range(1, ws.max_row+1):
    for gc, c0 in [('A','C'),('H','I')]:
        g = ws[f'{gc}{r}'].value
        if isinstance(g,str) and ws[f'{c0}{r}'].value=='Volunteer1':
            blocks.append((g, r, c0))
from openpyxl.utils import column_index_from_string, get_column_letter
rows=[]
for g,r,c0 in blocks:
    ci = column_index_from_string(c0)
    lab_col = get_column_letter(ci-1)
    d = {}
    for rr in range(r+1, r+17):
        lab = ws[f'{lab_col}{rr}'].value
        vals = [ws.cell(row=rr, column=ci+k).value for k in range(4)]
        d.setdefault(lab, []).append(vals)
    dct = {k: np.array(v, float) for k,v in d.items() if k and k.startswith('ΔCT')}
    norm = {k: np.array(v[0], float) for k,v in d.items() if k and k.startswith('After')}
    base = dct['ΔCT-0d'].mean(axis=0)
    rec = {'gene': g}
    for day in ['3d','7d','14d']:
        l2 = dct[f'ΔCT-{day}'].mean(axis=0) - base   # per volunteer log2FC
        rep = norm[f'After normalization-{day}']
        rec[f'{day}_FC_per_vol'] = np.round(2**l2, 2)
        rec[f'{day}_rep'] = np.round(rep,2)
        rec[f'{day}_consistent'] = bool(np.allclose(2**l2, rep, rtol=0.02))
        rec[f'{day}_geomean'] = 2**np.mean(l2)
        rec[f'{day}_n_up'] = int(np.sum(l2>0))
        rec[f'{day}_pairedt_P'] = stats.ttest_1samp(l2, 0).pvalue
    rec['baseline_dCT'] = np.round(base,2)
    rows.append(rec)
pd.set_option('display.width',400); pd.set_option('display.max_columns',60); pd.set_option('display.max_colwidth',60)
df = pd.DataFrame(rows)
print(df[['gene','3d_FC_per_vol','3d_geomean','3d_n_up','3d_pairedt_P','3d_consistent']].to_string(index=False))
print(df[['gene','7d_FC_per_vol','7d_geomean','7d_n_up','7d_pairedt_P','7d_consistent']].to_string(index=False))
print(df[['gene','14d_FC_per_vol','14d_geomean','14d_n_up','14d_pairedt_P','14d_consistent']].to_string(index=False))
print(df[['gene','baseline_dCT']].to_string(index=False))
df.to_pickle('fig7d.pkl')
print('=== Fig 7e human platelet immunoblot densitometry (n=4 volunteers; row = volunteer?) ===')
for lab,r0 in [('GP6/ACTB',4),('P2RY12/ACTB',12)]:
    g=[col('Fig. 7e',c,r0,r0+3) for c in 'BCDE']
    print(lab, [f'{np.mean(x):.3f}' for x in g])
    for i,d in zip([1,2,3],[3,7,14]):
        tp=stats.ttest_rel(g[i],g[0]); 
        l=np.log2(g[i]/g[0])
        print(f'   day {d} vs 0: ratio of means {np.mean(g[i])/np.mean(g[0]):.2f}; per-volunteer fold {np.round(g[i]/g[0],2)}; paired t P={tp.pvalue:.3g}; paired log-ratio t P={stats.ttest_1samp(l,0).pvalue:.3g}; unpaired t P={stats.ttest_ind(g[i],g[0]).pvalue:.3g}')
    print_tukey(tukey(g,['d0','d3','d7','d14']))
print(' reported GP6:', [(cell('Fig. 7e',f'G{r}'), cell('Fig. 7e',f'L{r}')) for r in (4,5,6)])
print(' reported P2RY12:', [(cell('Fig. 7e',f'G{r}'), cell('Fig. 7e',f'L{r}')) for r in (12,13,14)])
print('=== Fig 7g human donor platelets -> mice (n=5) ===')
for lab,r0 in [('lung weight',4),('met burden',12),('foci',19)]:
    print(fmt(ttest(col('Fig. 7g','B',r0,r0+4), col('Fig. 7g','C',r0,r0+4), lab)))
print(' reported', cell('Fig. 7g','F4'), cell('Fig. 7g','F12'), cell('Fig. 7g','F19'))
