import openpyxl, numpy as np, pandas as pd
from scipy import stats
import warnings
warnings.filterwarnings('ignore')
import os
DATA_DIR = os.environ.get('CRE_DATA_DIR', '/tmp/world/filesystem')
SRC = os.path.join(DATA_DIR, 'CRE-MK-01_source_data.xlsx')
_wb = None
def wb():
    global _wb
    if _wb is None:
        _wb = openpyxl.load_workbook(SRC, data_only=True)
    return _wb
def col(sheet, colletter, r0, r1):
    ws = wb()[sheet]
    out = []
    for r in range(r0, r1+1):
        v = ws[f'{colletter}{r}'].value
        if isinstance(v,(int,float)):
            out.append(float(v))
    return np.array(out)
def row(sheet, r, c0, c1):
    ws = wb()[sheet]
    from openpyxl.utils import column_index_from_string, get_column_letter
    out=[]
    for ci in range(column_index_from_string(c0), column_index_from_string(c1)+1):
        v = ws.cell(row=r, column=ci).value
        if isinstance(v,(int,float)):
            out.append(float(v))
    return np.array(out)
def cell(sheet, addr):
    return wb()[sheet][addr].value
def ttest(a,b, label=''):
    t,p = stats.ttest_ind(a,b)
    tw,pw = stats.ttest_ind(a,b,equal_var=False)
    try:
        u,pu = stats.mannwhitneyu(a,b,alternative='two-sided')
    except Exception:
        pu = np.nan
    return dict(label=label, n1=len(a), n2=len(b), m1=np.mean(a), sd1=np.std(a,ddof=1), m2=np.mean(b), sd2=np.std(b,ddof=1),
                ratio=np.mean(b)/np.mean(a) if np.mean(a)!=0 else np.nan, t=abs(t), df=len(a)+len(b)-2, p=p, p_welch=pw, p_mwu=pu)
def fmt(d):
    return (f"{d['label']}: n={d['n1']}/{d['n2']}; mean±SD {d['m1']:.4g}±{d['sd1']:.3g} vs {d['m2']:.4g}±{d['sd2']:.3g}; ratio {d['ratio']:.2f}; "
            f"t={d['t']:.3f}, df={d['df']}, P={d['p']:.4g}; Welch P={d['p_welch']:.4g}; MWU P={d['p_mwu']:.4g}")
def hedges_g(a,b):
    na,nb=len(a),len(b)
    sp = np.sqrt(((na-1)*np.var(a,ddof=1)+(nb-1)*np.var(b,ddof=1))/(na+nb-2))
    d = (np.mean(b)-np.mean(a))/sp
    J = 1-3/(4*(na+nb)-9)
    return d*J
def tukey(groups, names):
    # ordinary one-way ANOVA + Tukey HSD
    from scipy.stats import tukey_hsd, f_oneway
    F,p = f_oneway(*groups)
    res = tukey_hsd(*groups)
    out = {'F':F,'p_anova':p,'pairs':{}}
    ci = res.confidence_interval(0.95)
    for i in range(len(groups)):
        for j in range(i+1,len(groups)):
            out['pairs'][(names[i],names[j])] = dict(diff=np.mean(groups[i])-np.mean(groups[j]), p=res.pvalue[i,j], lo=ci.low[i,j], hi=ci.high[i,j])
    return out
def print_tukey(out, only=None):
    print(f"   one-way ANOVA F={out['F']:.3f}, P={out['p_anova']:.3g}")
    for k,v in out['pairs'].items():
        if only is None or k in only or (k[1],k[0]) in only:
            print(f"   {k[0]} vs {k[1]}: diff={v['diff']:.4g} [{v['lo']:.4g},{v['hi']:.4g}] adjP={v['p']:.3g}")
