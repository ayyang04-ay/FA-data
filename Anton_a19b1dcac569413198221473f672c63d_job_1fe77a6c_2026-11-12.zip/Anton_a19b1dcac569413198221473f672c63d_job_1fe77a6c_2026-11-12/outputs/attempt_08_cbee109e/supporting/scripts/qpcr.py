from common import *
from openpyxl.utils import get_column_letter, column_index_from_string
def parse_qpcr(sheet, ctrl_cols=('G','I'), grp_defs=None, header_row=None, gene_col='A'):
    """Return dict gene -> {'ctrl': dCT array, group: dCT array}. grp_defs: list of (groupname, first_col, last_col) for treatment groups
    All groups rows: gene row has ΔCT1 (control) in each block; next row has ΔCTk for the block's group."""
    ws = wb()[sheet]
    res = {}
    for r in range(1, ws.max_row+1):
        g = ws[f'{gene_col}{r}'].value
        lab = ws['F'+str(r)].value if gene_col=='A' else None
        if isinstance(g,str) and isinstance(lab,str) and lab.startswith('ΔCT'):
            d = {}
            d['ctrl'] = row(sheet, r, ctrl_cols[0], ctrl_cols[1])
            for name,c0,c1 in grp_defs:
                d[name] = row(sheet, r+1, c0, c1)
                # check that the control row in this block equals ctrl
                cc = row(sheet, r, c0, c1)
                if not np.allclose(cc, d['ctrl']):
                    print('  !! control ΔCT differs between blocks for', sheet, g, name, cc, d['ctrl'])
            # reported fold values
            d['_rep_ctrl_norm'] = row(sheet, r+3, 'C','E')
            for name,c0,c1 in grp_defs:
                d['_rep_'+name] = row(sheet, r+3, c0, c1)
            res[g.strip()] = d
    return res
def analyze(sheet, grp_defs, title, comparisons=None, show=True):
    data = parse_qpcr(sheet, grp_defs=grp_defs)
    rows = []
    for gene, d in data.items():
        ctrl = d['ctrl']
        rec = {'gene':gene}
        for name,_,_ in grp_defs:
            x = d[name]
            l2fc = np.mean(x)-np.mean(ctrl)
            t,p = stats.ttest_ind(x, ctrl)
            rec[f'{name}_log2FC'] = l2fc
            rec[f'{name}_FC'] = 2**l2fc
            rec[f'{name}_P'] = p
            # consistency: reported 2^(ddCT) should equal 2^(x - ctrl) pairwise
            rep = d['_rep_'+name]
            if len(rep)==len(x) and not np.allclose(rep, 2**(x-ctrl), rtol=1e-3):
                rec[f'{name}_inconsistent'] = True
                print('  !! reported fold != 2^(dCT diff) for', sheet, gene, name, rep, 2**(x-ctrl))
            rec[f'{name}_repmeanFC'] = np.mean(rep) if len(rep) else np.nan
        rows.append(rec)
    df = pd.DataFrame(rows)
    # comparisons between treatment groups
    if comparisons:
        for a,b in comparisons:
            ps=[]; l2=[]
            for gene,d in data.items():
                t,p = stats.ttest_ind(d[a], d[b])
                ps.append(p); l2.append(np.mean(d[a])-np.mean(d[b]))
            df[f'{a}_vs_{b}_log2'] = l2
            df[f'{a}_vs_{b}_P'] = ps
    if show:
        pd.set_option('display.width', 300); pd.set_option('display.max_columns', 50)
        print(f'=== {title} ({sheet}) ===')
        print(df.round(4).to_string(index=False))
    return df, data
if __name__ == '__main__':
    analyze('Fig. 2f', [('creatine','G','I')], 'MKs from vehicle vs creatine mice')
    analyze('Fig. 3f', [('WTcre','G','I'),('KOveh','K','M'),('KOcre','O','Q')], 'Pf4-Cre Slc6a8 WT/KO x creatine', comparisons=[('KOcre','KOveh'),('WTcre','KOcre')])
    analyze('Fig. 4h', [('creatine','G','I'),('PCr','K','M')], 'MK in vitro creatine vs phosphocreatine', comparisons=[('creatine','PCr')])
    analyze('Fig. 4j', [('siCkb','G','I'),('cre_siScr','K','M'),('cre_siCkb','O','Q')], 'si-Ckb x creatine', comparisons=[('cre_siScr','cre_siCkb'),('cre_siCkb','siCkb')])
    analyze('Fig. 4l', [('CKB_OE','G','I')], 'CKB OE')
    analyze('Fig.6a', [('creatine','G','I'),('veh_inh','K','M'),('cre_inh','O','Q')], 'STAT5 inhibitor x creatine', comparisons=[('creatine','cre_inh'),('cre_inh','veh_inh')])
    analyze('Fig. 6g', [('WTcre','G','I'),('KOcre','K','M')], 'Stat5b MK KO + creatine', comparisons=[('WTcre','KOcre')])
    analyze('Supplementary Fig  3c', [('creatine','G','I')], 'MK differentiation/maturation genes')
    analyze('Supplementary Fig  4e', [('creatine','G','I'),('cre_lipo','K','M')], 'Slc6a8-KO MKs: creatine vs creatine@liposome', comparisons=[('cre_lipo','creatine')])
