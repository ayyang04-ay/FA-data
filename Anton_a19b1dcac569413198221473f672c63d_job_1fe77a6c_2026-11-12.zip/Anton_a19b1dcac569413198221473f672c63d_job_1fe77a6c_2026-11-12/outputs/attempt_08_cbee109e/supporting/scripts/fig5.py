from common import *
import statsmodels.formula.api as smf, statsmodels.api as sm
names=['WT','S127A','3A','S127D']
for sh, cols, rv, rc in [('Fig. 5e','NOPQ',(4,6),(17,19)), ('Fig. 5f','NOPQ',(4,6),(17,19))]:
    print('===', sh, 'p-FLAG/FLAG densitometry (pan-phos / FLAG), n=3 blots ===')
    gv=[col(sh,c,rv[0],rv[1]) for c in cols]; gc=[col(sh,c,rc[0],rc[1]) for c in cols]
    print(' vehicle:', {n:list(np.round(x,3)) for n,x in zip(names,gv)}, [round(np.mean(x),3) for x in gv])
    print_tukey(tukey(gv,names))
    print(' creatine:', {n:list(np.round(x,3)) for n,x in zip(names,gc)}, [round(np.mean(x),3) for x in gc])
    print_tukey(tukey(gc,names))
    # creatine vs vehicle within each construct
    for n,a,b in zip(names,gv,gc):
        print('   ', fmt(ttest(a,b,f'{n}: vehicle vs creatine')))
    # two-way interaction: construct(WT vs S127A) x creatine
    df = pd.DataFrame({'y':np.concatenate([gv[0],gc[0],gv[1],gc[1]]), 'mut':[0]*6+[1]*6, 'cre':[0,0,0,1,1,1]*2})
    m = smf.ols('y ~ mut*cre', df).fit()
    print('   WT vs S127A x creatine interaction: %.3f (P=%.3g)'%(m.params['mut:cre'], m.pvalues['mut:cre']))
    # paired by blot index?
    print('   paired (by row/blot) WT: creatine-vehicle diffs', np.round(gc[0]-gv[0],3), 'paired t P=%.3g'%stats.ttest_rel(gc[0],gv[0]).pvalue)
ws = wb()['Fig. 5e']
print('reported 5e:', [(ws[f'M{r}'].value, ws[f'R{r}'].value) for r in (10,11,12,13,22,23,24)])
ws = wb()['Fig. 5f']
print('reported 5f:', [(ws[f'L{r}'].value, ws[f'Q{r}'].value) for r in (9,10,11,12,22,23,24)])

def chip(sh, rows, vcols, ccols, labelcol, title):
    print('===', title, '===')
    recs=[]
    for r in rows:
        lab = cell(sh, f'{labelcol}{r}')
        v = row(sh, r, vcols[0], vcols[1]); c = row(sh, r, ccols[0], ccols[1])
        print('  ', fmt(ttest(v,c,str(lab))))
        for x in v: recs.append((lab,'veh',x))
        for x in c: recs.append((lab,'cre',x))
    df = pd.DataFrame(recs, columns=['region','trt','y'])
    m = smf.ols('y ~ C(region)*C(trt)', df).fit()
    an = sm.stats.anova_lm(m, typ=2); print(an.round(5).to_string())
    # Sidak using pooled MSE from two-way ANOVA
    mse = m.mse_resid; dfres = m.df_resid
    k = df.region.nunique()
    for reg, sub in df.groupby('region', sort=False):
        v = sub[sub.trt=='veh'].y.values; c = sub[sub.trt=='cre'].y.values
        diff = v.mean()-c.mean(); se = np.sqrt(mse*(1/len(v)+1/len(c)))
        t = diff/se; p = 2*stats.t.sf(abs(t), dfres); padj = 1-(1-p)**k
        print(f'   Sidak {reg}: diff(veh-cre)={diff:.4g}, adjP={padj:.3g}; fold cre/veh={c.mean()/v.mean():.2f}')
chip('Fig. 5j', [5,6,7,8], ('B','D'), ('E','G'), 'A', 'Fig 5j ChIP P2ry12 (% input)')
print(' reported:', [(cell('Fig. 5j',f'I{r}'), cell('Fig. 5j',f'J{r}'), cell('Fig. 5j',f'N{r}')) for r in (7,8,9,10)])
chip('Fig. 5j', [15,16,17,18], ('B','D'), ('E','G'), 'A', 'Fig 5j ChIP Gp6 (% input)')
print(' reported:', [(cell('Fig. 5j',f'I{r}'), cell('Fig. 5j',f'J{r}'), cell('Fig. 5j',f'N{r}')) for r in (17,18,19,20)])
chip('Supplementary Fig  6i', [7,8,9,10], ('C','E'), ('F','H'), 'B', 'Supp 6i ChIP Rab4a (% input)')
print(' reported:', [(cell('Supplementary Fig  6i',f'J{r}'), cell('Supplementary Fig  6i',f'K{r}'), cell('Supplementary Fig  6i',f'O{r}')) for r in (10,11,12,13)])
