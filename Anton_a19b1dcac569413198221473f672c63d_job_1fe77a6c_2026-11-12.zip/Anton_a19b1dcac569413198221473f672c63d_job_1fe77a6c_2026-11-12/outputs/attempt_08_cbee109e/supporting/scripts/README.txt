Scripts behind the CRE-MK-02 proposal. Run run_all.sh (set PY to the interpreter, CRE_DATA_DIR to the data folder).

common.py          cell/row/column readers, t tests, Tukey helper
fig1.py ... fig7.py, fig7d.py, supp.py, surv.py, dunnett.py
                   panel-by-panel reproduction of every reported test, plus the added 2x2 interaction
                   contrasts (fig1f, fig3, fig5, fig6) and paired volunteer analyses (fig7, fig7d)
fig7d_check.py     recomputes the volunteer transcript fold changes from the dCT rows
qpcr.py            megakaryocyte transcript panels: fold change and t test on dCT
residual.py        share of the creatine-induced transcript change left under each intervention
remain.py          share of the creatine effect on metastasis left under each intervention (decision metric)
effects.py, meta.py creatine effect in the 11 cohorts, random-effects pooling
power2.py          simulation-based power for the genotype x creatine interaction
human_explore.py, human_power.py  volunteer response patterns and crossover sample size
phospho.py         summary of the phosphoproteomics table
duplicates.py      scan for values repeated across sheets
build_tables.py, inventory.py, write_xlsx.py  build supporting/CRE-MK-01_reanalysis.xlsx
figure.py          builds supporting/evidence_summary.png
md2pdf.py          renders the proposal markdown to PDF
