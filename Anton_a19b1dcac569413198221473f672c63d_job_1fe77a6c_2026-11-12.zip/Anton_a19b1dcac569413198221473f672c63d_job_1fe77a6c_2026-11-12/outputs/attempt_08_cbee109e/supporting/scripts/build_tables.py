from common import *
from qpcr import parse_qpcr
import statsmodels.formula.api as smf
from scipy.stats import dunnett
S='Supplementary Fig  '
rows=[]   # two-group tests
def add2(panel, sheet, readout, material, unit, a, b, la, lb, rep_cell=None, note=''):
    d = ttest(a,b)
    rows.append(dict(panel=panel, readout=readout, material=material, n_unit=unit, group1=la, group2=lb, n1=len(a), n2=len(b),
                     mean1=np.mean(a), sd1=np.std(a,ddof=1), mean2=np.mean(b), sd2=np.std(b,ddof=1), ratio_2_over_1=d['ratio'],
                     t=d['t'], df=d['df'], P_recomputed_student=d['p'], P_welch=d['p_welch'], P_mann_whitney=d['p_mwu'],
                     P_reported=(cell(sheet,rep_cell) if rep_cell else None), note=note))
M='mice'; 
add2('Fig 1a','Fig. 1a','Lung weight (g)','lung','mice',col('Fig. 1a','B',3,8),col('Fig. 1a','C',3,8),'Vehicle','Creatine','F4')
add2('Fig 1a','Fig. 1a','SUV-BW (PET)','lung','mice',col('Fig. 1a','B',12,17),col('Fig. 1a','C',12,17),'Vehicle','Creatine','F12')
add2('Fig 1b','Fig. 1b','Metastatic burden (%)','lung','mice',col('Fig. 1b','B',3,8),col('Fig. 1b','C',3,8),'Vehicle','Creatine','F3')
add2('Fig 1b','Fig. 1b','Metastatic foci (n)','lung','mice',col('Fig. 1b','B',12,17),col('Fig. 1b','C',12,17),'Vehicle','Creatine','F12')
for r,t,rc in zip([4,5,6,7],[0.25,6,12,24],['B17','E17','H17','K17']):
    add2('Fig 1h','Fig. 1h',f'Time-course readout at {t} h (y-axis not labelled in sheet)','not labelled','mice (6 per arm per time point)',row('Fig. 1h',r,'B','G'),row('Fig. 1h',r,'H','M'),'Vehicle','Creatine',rc)
add2('Fig 1i','Fig. 1i','GFP+ cells per field','lung sections','8 random fields per group (not animals)',col('Fig. 1i','B',4,11),col('Fig. 1i','C',4,11),'Vehicle','Creatine','F4','field-level n: pseudo-replication')
add2('Fig 1j','Fig. 1j','Lung weight (g)','lung','mice',col('Fig. 1j','B',4,9),col('Fig. 1j','C',4,9),'Vehicle','Creatine','F4')
add2('Fig 1j','Fig. 1j','SUV-BW (PET)','lung','mice',col('Fig. 1j','B',13,18),col('Fig. 1j','C',13,18),'Vehicle','Creatine','F13')
add2('Fig 1k','Fig. 1k','Metastatic burden (%)','lung','mice',col('Fig. 1k','B',4,9),col('Fig. 1k','C',4,9),'Vehicle','Creatine','F4')
add2('Fig 1k','Fig. 1k','Metastatic foci (n)','lung','mice',col('Fig. 1k','B',12,17),col('Fig. 1k','C',12,17),'Vehicle','Creatine','F12')
for lab,r0,rc in [('PLT (x10^9/L)',4,'F4'),('PCT (%)',12,'F12'),('PDW (fL)',19,'F19'),('MPV (fL)',27,'F27')]:
    add2('Fig 2a','Fig. 2a',lab,'mouse blood','mice',col('Fig. 2a','B',r0,r0+2),col('Fig. 2a','C',r0,r0+2),'Vehicle','Creatine',rc)
for r,lab,rc in [(4,'ADP','B18'),(5,'Collagen','B32'),(6,'Thrombin','B45')]:
    add2('Fig 2b','Fig. 2b',f'Platelet aggregation, {lab} (%)','mouse platelets (peripheral blood)','mice',row('Fig. 2b',r,'B','D'),row('Fig. 2b',r,'E','G'),'Vehicle','Creatine',rc)
add2('Fig 2c','Fig. 2c','Alpha-granules (n)','mouse platelets','8 random fields per group (not animals)',col('Fig. 2c','B',4,11),col('Fig. 2c','C',4,11),'Vehicle','Creatine','F5','field-level n')
for lab,r0,rc in [('TEG-R (min)',4,'F4'),('TEG-K (min)',12,'F12'),('TEG-alpha (deg)',20,'F20'),('TEG-MA (mm)',28,'F28')]:
    add2('Fig 2d','Fig. 2d',lab,'mouse blood','mice',col('Fig. 2d','B',r0,r0+4),col('Fig. 2d','C',r0,r0+4),'Vehicle','Creatine',rc)
add2('Fig 2j','Fig. 2j','PKH-positive area (%)','mouse platelets','8 random fields per group (not animals)',col('Fig. 2j','B',4,11),col('Fig. 2j','C',4,11),'Vehicle','Creatine','F4','field-level n')
add2('Fig 3b','Fig. 3b','Serum creatine (uM)','mouse serum','mice',row('Fig. 3b',4,'B','F'),row('Fig. 3b',4,'G','K'),'Pf4-Cre;Slc6a8+/+ vehicle','Pf4-Cre;Slc6a8+/+ creatine','B17')
add2('Fig 3b','Fig. 3b','Serum creatine (uM)','mouse serum','mice',row('Fig. 3b',5,'B','F'),row('Fig. 3b',5,'G','K'),'Pf4-Cre;Slc6a8fl/fl vehicle','Pf4-Cre;Slc6a8fl/fl creatine','B31')
add2('Fig 3c','Fig. 3c','MK intracellular creatine','mouse primary MKs','mice',row('Fig. 3c',4,'B','D'),row('Fig. 3c',4,'E','G'),'Pf4-Cre;Slc6a8+/+ vehicle','Pf4-Cre;Slc6a8+/+ creatine','B15','Welch P=0.105; n=3')
add2('Fig 3c','Fig. 3c','MK intracellular creatine','mouse primary MKs','mice',row('Fig. 3c',5,'B','D'),row('Fig. 3c',5,'E','G'),'Pf4-Cre;Slc6a8fl/fl vehicle','Pf4-Cre;Slc6a8fl/fl creatine','B30')
add2('Fig 4a','Fig. 4a','Creatine (umol/g)','mouse primary MKs','mice',col('Fig. 4a','B',4,6),col('Fig. 4a','C',4,6),'Vehicle','Creatine','H10')
add2('Fig 4a','Fig. 4a','Creatine (umol/g)','mouse brain tissue','mice',col('Fig. 4a','D',4,6),col('Fig. 4a','E',4,6),'Vehicle','Creatine','H24')
add2('Fig 4c','Fig. 4c','Phosphocreatine (ng/ug)','mouse primary MKs','mice',col('Fig. 4c','B',4,6),col('Fig. 4c','C',4,6),'Vehicle','Creatine','H10')
add2('Fig 4c','Fig. 4c','Phosphocreatine (ng/ug)','mouse brain tissue','mice',col('Fig. 4c','D',4,6),col('Fig. 4c','E',4,6),'Vehicle','Creatine','H24')
add2('Fig 4d','Fig. 4d','MK creatine in vitro (sheet label reads "Creatinine (umol/g)")','mouse MKs in vitro','cultures',col('Fig. 4d','C',4,6),col('Fig. 4d','D',4,6),'Control','Creatine','G10','label says creatinine; assay per conventions is creatine')
add2('Fig 4e','Fig. 4e','Ckb mRNA (fold, as reported)','MKs','samples',row('Fig. 4e',8,'E','G'),row('Fig. 4e',8,'I','K'),'Vehicle','Creatine','O5')
add2('Fig 4f','Fig. 4f','Phosphocreatine in vitro (ng/ug)','mouse MKs in vitro','cultures',col('Fig. 4f','B',4,6),col('Fig. 4f','C',4,6),'Control','Creatine','F4','Welch P=0.061')
for lab,r0,rc in [('Lung weight (g)',4,'F4'),('Metastatic burden (%)',12,'F12'),('Metastatic foci (n)',19,'F19')]:
    add2('Fig 7g','Fig. 7g',lab,'recipient mice given human volunteer platelets','recipient mice (donor number not recorded)',col('Fig. 7g','B',r0,r0+4),col('Fig. 7g','C',r0,r0+4),'Day-0 donor platelets','Day-7 donor platelets',rc,'human platelets into mice; donors are the true unit')
add2('Supp 1a',S+'1a','Body weight day 0 (g)','mice','mice',row(S+'1a',4,'B','E'),row(S+'1a',4,'F','I'),'Vehicle','Creatine','M11')
add2('Supp 1a',S+'1a','Body weight day 7 (g)','mice','mice',row(S+'1a',5,'B','E'),row(S+'1a',5,'F','I'),'Vehicle','Creatine','M25')
add2('Supp 1b',S+'1b','Food intake (g/day)','mice','mice',col(S+'1b','B',4,9),col(S+'1b','C',4,9),'Vehicle','Creatine','F4')
add2('Supp 1c',S+'1c','Water intake (g/day)','mice','mice',col(S+'1c','B',4,9),col(S+'1c','C',4,9),'Vehicle','Creatine','F4')
add2('Supp 1d',S+'1d','Serum creatine (uM)','mouse serum','mice',col(S+'1d','B',4,9),col(S+'1d','C',4,9),'Vehicle','Creatine','F4')
for pan,sh,spec in [('Supp 1e',S+'1e',[('Lung weight (g)',4,9,'F4'),('Metastatic burden (%)',13,18,'F13'),('Metastatic foci (n)',22,27,'F22')]),
                    ('Supp 1f',S+'1f',[('Lung weight (g)',4,7,'F4'),('Metastatic burden (%)',12,15,'F12'),('Metastatic foci (n)',20,23,'F20')]),
                    ('Supp 1g',S+'1g',[('Lung weight (g)',3,12,'F3'),('Metastatic burden (%)',15,24,'F15'),('Metastatic foci (n)',28,37,'F28')]),
                    ('Supp 1i',S+'1i',[('Lung weight (g)',3,6,'F3'),('Metastatic burden (%)',11,14,'F11'),('Metastatic foci (n)',18,21,'F18')])]:
    for lab,r0,r1,rc in spec:
        add2(pan,sh,lab,'lung','mice',col(sh,'B',r0,r1),col(sh,'C',r0,r1),'Control diet' if pan=='Supp 1i' else 'Vehicle','Creatine diet' if pan=='Supp 1i' else 'Creatine',rc,'tumour model not named in sheet')
for lab,r0,r1,rc in [('Lung weight (g)',4,13,'G4'),('Metastatic burden (%)',16,25,'G16'),('Metastatic foci (n)',29,38,'G29')]:
    add2('Supp 1k',S+'1k',lab,'lung','mice',col(S+'1k','B',r0,r1),col(S+'1k','C',r0,r1),'Vehicle','Creatine',rc,'tumour model not named in sheet')
add2('Supp 1h',S+'1h','Serum creatine (uM)','mouse serum','mice',col(S+'1h','C',4,7),col(S+'1h','D',4,7),'Control diet','Creatine diet','F4')
add2('Supp 2a',S+'2a','Slc6a8 mRNA in tumour cells (fold, as reported)','tumour cells','samples',row(S+'2a',7,'D','F'),row(S+'2a',7,'H','J'),'si-scrambled','si-Slc6a8','M4')
for lab,r0,rc in [('WBC',4,'F4'),('Lymphocytes',12,'F12'),('Monocytes',20,'F20'),('RBC',28,'F28')]:
    add2('Supp 3a',S+'3a',lab,'mouse blood','mice',col(S+'3a','B',r0,r0+4),col(S+'3a','C',r0,r0+4),'Vehicle','Creatine',rc)
add2('Supp 5c',S+'5c','MK creatine (umol/g)','mouse MKs in vitro','cultures',col(S+'5c','B',5,7),col(S+'5c','C',5,7),'CKB-EV','CKB-OE','F5')
add2('Supp 5c',S+'5c','MK phosphocreatine (ng/ug)','mouse MKs in vitro','cultures',col(S+'5c','B',13,15),col(S+'5c','C',13,15),'CKB-EV','CKB-OE','F13')
add2('Supp 5a',S+'5a','Gatm mRNA (normalised)','MKs','samples',row(S+'5a',6,'C','E'),row(S+'5a',6,'G','I'),'Vehicle','Creatine','N10')
add2('Supp 5a',S+'5a','Gamt mRNA (normalised)','MKs','samples',row(S+'5a',9,'C','E'),row(S+'5a',9,'G','I'),'Vehicle','Creatine','N24')
add2('Supp 8a',S+'8a','BMI (kg/m2)','volunteers','volunteers (paired; analysed unpaired in sheet)',col(S+'8a','C',4,14),col(S+'8a','D',4,14),'Day 0','Day 14','G5','paired t P=0.238')
two = pd.DataFrame(rows)
two['reported_matches'] = [ (abs(float(r.P_reported)-r.P_recomputed_student) <= max(0.00051, 0.02*r.P_recomputed_student)) if isinstance(r.P_reported,(int,float)) else None for r in two.itertuples()]

# ---------- factorial / multi-group ----------
fac=[]
def add_fac(panel, sheet, readout, groups, names, unit, factor_layout=None, reported=None, note=''):
    out = tukey(groups, names)
    rec = dict(panel=panel, readout=readout, n_unit=unit, groups=' | '.join(f'{n}: {np.mean(g):.4g}±{np.std(g,ddof=1):.3g} (n={len(g)})' for n,g in zip(names,groups)), anova_F=out['F'], anova_P=out['p_anova'])
    rec['tukey_pairs'] = '; '.join(f'{a} vs {b}: adjP={v["p"]:.3g}' for (a,b),v in out['pairs'].items())
    if factor_layout is not None:   # 2x2: order = [ctl-veh, ctl-cre, pert-veh, pert-cre]
        y=np.concatenate(groups); pert=np.repeat([0,0,1,1],[len(g) for g in groups]); cre=np.repeat([0,1,0,1],[len(g) for g in groups])
        m=smf.ols('y ~ pert*cre', pd.DataFrame(dict(y=y,pert=pert,cre=cre))).fit(); ci=m.conf_int().loc['pert:cre']
        rec.update(creatine_effect_control=m.params['cre'], creatine_effect_perturbed=m.params['cre']+m.params['pert:cre'], interaction=m.params['pert:cre'], interaction_CI_low=ci[0], interaction_CI_high=ci[1], interaction_P=m.pvalues['pert:cre'], perturbation_effect_at_vehicle=m.params['pert'], perturbation_at_vehicle_P=m.pvalues['pert'])
    rec['reported']=reported; rec['note']=note
    fac.append(rec)
n4=['shScr-vehicle','shScr-creatine','shSlc6a8-vehicle','shSlc6a8-creatine']
for lab,r0,r1,rp in [('Lung weight (g)',4,9,'L4/L5/L6'),('SUV-BW',13,18,'L13/L14/L15'),('Metastatic burden (%)',22,27,'L22/L23/L24'),('Metastatic foci (n)',31,36,'L31/L32/L33')]:
    add_fac('Fig 1f','Fig. 1f',lab,[col('Fig. 1f',c,r0,r1) for c in 'BCDE'],n4,'mice',True,'reported Tukey adjP: '+', '.join(str(cell('Fig. 1f',x)) for x in rp.split('/')),'tumour-cell Slc6a8 knock-down (melanoma)')
nk=['Cre;+/+ vehicle','Cre;+/+ creatine','Cre;fl/fl vehicle','Cre;fl/fl creatine']
for r,lab,rp in [(4,'ADP','T4/T5'),(5,'Collagen','T10/T11'),(6,'Thrombin','T15/T16')]:
    add_fac('Fig 3d','Fig. 3d',f'Platelet aggregation, {lab} (%)',[row('Fig. 3d',r,a,b) for a,b in [('B','D'),('E','G'),('H','J'),('K','M')]],nk,'mice',True,'reported Tukey adjP: '+', '.join(str(cell('Fig. 3d',x)) for x in rp.split('/')),'Pf4-Cre;Slc6a8')
for lab,r0,rp in [('Lung weight (g)',3,'L3/L4/L5'),('Metastatic burden (%)',10,'L10/L11/L12'),('Metastatic foci (n)',17,'L17/L18/L19')]:
    add_fac('Fig 3i','Fig. 3i',lab,[col('Fig. 3i',c,r0,r0+3) for c in 'BCDE'],nk,'mice',True,'reported Tukey adjP: '+', '.join(str(cell('Fig. 3i',x)) for x in rp.split('/')),'Pf4-Cre;Slc6a8')
g=[row('Fig. 3c',4,'B','D'),row('Fig. 3c',4,'E','G'),row('Fig. 3c',5,'B','D'),row('Fig. 3c',5,'E','G')]
add_fac('Fig 3c','Fig. 3c','MK intracellular creatine',g,nk,'mice',True,'sheet reports per-genotype t tests only (0.0493; 0.198)','Pf4-Cre;Slc6a8')
ni=['Vehicle','Creatine','Vehicle+STAT5-IN-1','Creatine+STAT5-IN-1']
for lab,r0,rp in [('Metastatic burden (%)',4,'L4/L5/L6/L7'),('Metastatic foci (n)',13,'L13/L14/L15/L16')]:
    add_fac('Fig 6b','Fig. 6b',lab,[col('Fig. 6b',c,r0,r0+4) for c in 'BCDE'],ni,'mice',True,'reported Tukey adjP: '+', '.join(str(cell('Fig. 6b',x)) for x in rp.split('/')),'3 vehicle + 3 creatine values identical to Supp 2d')
    gg=[col('Fig. 6b',c,r0,r0+4) for c in 'BCDE']; gg=[gg[0][[0,4]],gg[1][[0,4]],gg[2],gg[3]]
    add_fac('Fig 6b (sensitivity)','Fig. 6b',lab+' - excluding values duplicated in Supp 2d',gg,ni,'mice',True,None,'n=2 in the two no-inhibitor arms')
add_fac('Fig 6e','Fig. 6e','MK intracellular creatine (umol/g)',[col('Fig. 6e',c,5,7) for c in 'CDE'],['WT vehicle','WT creatine','Pf4-iCre;Stat5bfl/fl creatine'],'mice',None,'reported Tukey adjP: '+', '.join(str(cell('Fig. 6e',x)) for x in ['L5','L6','L7']),'no deletion-vehicle arm; control is WT not Cre')
nd=['Vehicle donor PLT','Creatine donor PLT','Creatine+aspirin donor PLT']
for lab,r0,rp in [('Metastatic burden (%)',5,'L5/L6/L7'),('Metastatic foci (n)',14,'L14/L15/L16')]:
    add_fac('Supp 2d',S+'2d',lab,[col(S+'2d',c,r0,r0+5) for c in 'CDE'],nd,'recipient mice',None,'reported Tukey adjP: '+', '.join(str(cell(S+'2d',x)) for x in rp.split('/')),'rows 4-6 of vehicle and creatine arms identical to Fig 6b; no aspirin-only arm')
    add_fac('Supp 2d (sensitivity)',S+'2d',lab+' - first three animals per arm only',[col(S+'2d',c,r0,r0+2) for c in 'CDE'],nd,'recipient mice',None,None,'excludes rows that duplicate Fig 6b')
add_fac('Supp 4b',S+'4b','PLT (x10^9/L)',[col(S+'4b',c,5,7) for c in 'CDEF'],nk,'mice',True,'all ns','')
add_fac('Supp 4c',S+'4c','Alpha-granules (n)',[col(S+'4c',c,6,13) for c in 'CDEF'],nk,'8 random fields per group (not animals)',True,'reported adjP: '+', '.join(str(cell(S+'4c',x)) for x in ['N7','N8','N9']),'field-level n')
for lab,r0 in [('PLT',4),('PCT',11),('MPV',17),('PDW',23)]:
    add_fac('Supp 7a',S+'7a',lab,[col(S+'7a',c,r0,r0+2) for c in 'BCDE'],ni,'mice',True,'all ns','n=3; wide CIs')
for lab,r0 in [('PLT',4),('PCT',10),('MPV',16),('PDW',22)]:
    add_fac('Supp 7b',S+'7b',lab,[col(S+'7b',c,r0,r0+2) for c in 'BCD'],['WT vehicle','WT creatine','Pf4-Cre;Stat5bfl/fl creatine'],'mice',None,'all ns','n=3; no deletion-vehicle arm')
nm=['WT','S127A','3A','S127D']
for sh in ['Fig. 5e','Fig. 5f']:
    gv=[col(sh,c,4,6) for c in 'NOPQ']; gc=[col(sh,c,17,19) for c in 'NOPQ']
    add_fac(sh.replace('. ',' '),sh,'pan-phospho/FLAG densitometry, vehicle',gv,nm,'blots',None,None,'STAT5B-FLAG constructs; "3A" not defined in file')
    add_fac(sh.replace('. ',' '),sh,'pan-phospho/FLAG densitometry, creatine',gc,nm,'blots',None,None,'')
    add_fac(sh.replace('. ',' ')+' (derived)',sh,'pan-phospho/FLAG: WT vs S127A x creatine',[gv[0],gc[0],gv[1],gc[1]],['WT vehicle','WT creatine','S127A vehicle','S127A creatine'],'blots',True,None,'derived 2x2; creatine raises WT signal 1.39x (5e) / 1.28x (5f)')
for lab,r0 in [('GP6/ACTB',4),('P2RY12/ACTB',12)]:
    add_fac('Fig 7e','Fig. 7e',lab+' densitometry',[col('Fig. 7e',c,r0,r0+3) for c in 'BCDE'],['d0','d3','d7','d14'],'4 volunteers (paired; analysed unpaired in sheet)',None,'reported Tukey adjP (0 vs 3/7/14): '+', '.join(str(cell('Fig. 7e',f'L{r}')) for r in (r0,r0+1,r0+2)),'immunoblot densitometry, not transcript')
add_fac('Fig 7b','Fig. 7b','Serum creatine (uM)',[col('Fig. 7b',c,4,14) for c in 'BCDE'],['d0','d3','d7','d14'],'11 volunteers (paired; analysed unpaired in sheet)',None,'reported adjP: '+', '.join(str(cell('Fig. 7b',x)) for x in ['L5','L6','L7']),'')
facdf=pd.DataFrame(fac)

# ---------- ChIP ----------
chip=[]
def add_chip(panel, sh, rws, vc, cc, lc, target, rep_col):
    recs=[]
    for r in rws:
        v=row(sh,r,vc[0],vc[1]); c=row(sh,r,cc[0],cc[1]); lab=cell(sh,f'{lc}{r}')
        for x in v: recs.append((lab,'veh',x))
        for x in c: recs.append((lab,'cre',x))
    df=pd.DataFrame(recs,columns=['region','trt','y']); m=smf.ols('y ~ C(region)*C(trt)',df).fit(); mse=m.mse_resid; dfres=m.df_resid; k=df.region.nunique()
    for reg,sub in df.groupby('region',sort=False):
        v=sub[sub.trt=='veh'].y.values; c=sub[sub.trt=='cre'].y.values
        se=np.sqrt(mse*(1/len(v)+1/len(c))); t=(v.mean()-c.mean())/se; p=2*stats.t.sf(abs(t),dfres)
        chip.append(dict(panel=panel,target_promoter=target,region=reg,vehicle_mean_pct_input=v.mean(),creatine_mean_pct_input=c.mean(),fold=c.mean()/v.mean(),sidak_adjP_recomputed=1-(1-p)**k,n_per_group=len(v)))
add_chip('Fig 5j','Fig. 5j',[5,6,7,8],('B','D'),('E','G'),'A','P2ry12','N')
add_chip('Fig 5j','Fig. 5j',[15,16,17,18],('B','D'),('E','G'),'A','Gp6','N')
add_chip('Supp 6i',S+'6i',[7,8,9,10],('C','E'),('F','H'),'B','Rab4a','O')
chipdf=pd.DataFrame(chip)
chipdf['reported_adjP']=[cell('Fig. 5j',f'N{r}') for r in (7,8,9,10)]+[cell('Fig. 5j',f'N{r}') for r in (17,18,19,20)]+[cell(S+'6i',f'O{r}') for r in (10,11,12,13)]

# ---------- qPCR ----------
genes=None
q=[]
def add_q(panel, sheet, defs, ctrl_name, material):
    d=parse_qpcr(sheet, grp_defs=defs)
    for g,dd in d.items():
        for name,_,_ in defs:
            x=dd[name]; c=dd['ctrl']; t,p=stats.ttest_ind(x,c)
            q.append(dict(panel=panel, material=material, gene=g.replace('Gpiba','Gp1ba'), group=name, reference=ctrl_name, n=len(x), log2FC=np.mean(x)-np.mean(c), fold=2**(np.mean(x)-np.mean(c)), P_ttest_on_dCT=p, reported_mean_fold=np.mean(dd['_rep_'+name])))
MK='mouse primary MKs (bone marrow)'
add_q('Fig 2f','Fig. 2f',[('Creatine','G','I')],'Vehicle',MK)
add_q('Fig 3f','Fig. 3f',[('Cre;Slc6a8+/+ creatine','G','I'),('Cre;Slc6a8fl/fl vehicle','K','M'),('Cre;Slc6a8fl/fl creatine','O','Q')],'Cre;Slc6a8+/+ vehicle',MK)
add_q('Fig 4h','Fig. 4h',[('Creatine','G','I'),('Phosphocreatine','K','M')],'Control',MK)
add_q('Fig 4j','Fig. 4j',[('Control+si-Ckb','G','I'),('Creatine+si-scrambled','K','M'),('Creatine+si-Ckb','O','Q')],'Control+si-scrambled',MK)
add_q('Fig 4l','Fig. 4l',[('CKB-OE','G','I')],'CKB-EV',MK)
add_q('Fig 6a','Fig.6a',[('Creatine','G','I'),('Vehicle+STAT5-IN-1','K','M'),('Creatine+STAT5-IN-1','O','Q')],'Vehicle',MK)
add_q('Fig 6g','Fig. 6g',[('WT creatine','G','I'),('Pf4-iCre;Stat5bfl/fl creatine','K','M')],'WT vehicle',MK)
add_q('Supp 3c',S+'3c',[('Creatine','G','I')],'Vehicle','MKs')
add_q('Supp 4e',S+'4e',[('Creatine','G','I'),('Creatine@liposome','K','M')],'Control (Slc6a8-deleted MKs)','MKs from Pf4-Cre;Slc6a8fl/fl')
qdf=pd.DataFrame(q)
# within-perturbation creatine contrasts
wc=[]
def within(panel, sheet, defs, a, b, label):
    d=parse_qpcr(sheet, grp_defs=defs)
    for g,dd in d.items():
        t,p=stats.ttest_ind(dd[a],dd[b]); wc.append(dict(panel=panel,gene=g.replace('Gpiba','Gp1ba'),contrast=label,log2FC=np.mean(dd[a])-np.mean(dd[b]),fold=2**(np.mean(dd[a])-np.mean(dd[b])),P_ttest_on_dCT=p))
within('Fig 3f','Fig. 3f',[('WTcre','G','I'),('KOveh','K','M'),('KOcre','O','Q')],'KOcre','KOveh','creatine effect within Slc6a8 deletion')
within('Fig 3f','Fig. 3f',[('WTcre','G','I'),('KOveh','K','M'),('KOcre','O','Q')],'WTcre','KOcre','control+creatine vs deletion+creatine')
within('Fig 6a','Fig.6a',[('c','G','I'),('vi','K','M'),('ci','O','Q')],'ci','vi','creatine effect under STAT5-IN-1')
within('Fig 6a','Fig.6a',[('c','G','I'),('vi','K','M'),('ci','O','Q')],'c','ci','creatine vs creatine+STAT5-IN-1')
within('Fig 4j','Fig. 4j',[('s','G','I'),('cs','K','M'),('cc','O','Q')],'cc','s','creatine effect under si-Ckb')
within('Fig 4j','Fig. 4j',[('s','G','I'),('cs','K','M'),('cc','O','Q')],'cs','cc','creatine+si-scrambled vs creatine+si-Ckb')
within('Fig 6g','Fig. 6g',[('WTcre','G','I'),('KOcre','K','M')],'WTcre','KOcre','WT+creatine vs Stat5b deletion+creatine')
within('Fig 4h','Fig. 4h',[('c','G','I'),('p','K','M')],'c','p','creatine vs phosphocreatine')
within('Supp 4e',S+'4e',[('c','G','I'),('l','K','M')],'l','c','creatine@liposome vs creatine in Slc6a8-deleted MKs')
wcdf=pd.DataFrame(wc)

# ---------- human ----------
hb=[('Collagen','maximum aggregation',4),('Collagen','average aggregation',18),('Collagen','adhesion',32),('Epinephrine','maximum aggregation',46),('Epinephrine','average aggregation',60),('Epinephrine','adhesion',74),('Arachidonic acid','maximum aggregation',88),('Arachidonic acid','average aggregation',102),('Arachidonic acid','adhesion',116),('ADP','maximum aggregation',130),('ADP','average aggregation',144),('ADP','adhesion',157)]
hrows=[]
ws=wb()['Fig. 7c']
for ag,met,r0 in hb:
    g=[col('Fig. 7c',c,r0,r0+10) for c in 'BCDE']; dn=dunnett(g[1],g[2],g[3],control=g[0]).pvalue
    rep=[ws[f'L{r}'].value for r in range(r0-2,r0+12) if ws[f'G{r}'].value in ('0 vs. 3','0 vs. 7','0 vs. 14')]
    for i,d in zip([1,2,3],[3,7,14]):
        x=g[i]; xl=np.log2(x[x>0])
        hrows.append(dict(agonist=ag,metric=met,day=d,n=len(x),n_above_baseline=int((x>1).sum()),arithmetic_mean_fold=x.mean(),median_fold=np.median(x),geometric_mean_fold=2**xl.mean(),min=x.min(),max=x.max(),
                          P_wilcoxon_signed_rank=stats.wilcoxon(x-1).pvalue,P_one_sample_t_log2=stats.ttest_1samp(xl,0).pvalue,P_one_sample_t_raw=stats.ttest_1samp(x,1).pvalue,
                          P_dunnett_unpaired_recomputed=dn[i-1],P_dunnett_reported=rep[i-1],note='zero value excluded from log analysis' if (x<=0).any() else ''))
hdf=pd.DataFrame(hrows)
# 7d
from openpyxl.utils import column_index_from_string, get_column_letter
ws=wb()['Fig. 7d']; blocks=[]
for r in range(1,ws.max_row+1):
    for gc,c0 in [('A','C'),('H','I')]:
        gname=ws[f'{gc}{r}'].value
        if isinstance(gname,str) and ws[f'{c0}{r}'].value=='Volunteer1': blocks.append((gname,r,c0))
h7=[]
for gname,r,c0 in blocks:
    ci=column_index_from_string(c0); lc=get_column_letter(ci-1); d={}
    for rr in range(r+1,r+17):
        lab=ws[f'{lc}{rr}'].value; d.setdefault(lab,[]).append([ws.cell(row=rr,column=ci+k).value for k in range(4)])
    dct={k:np.array(v,float) for k,v in d.items() if k and k.startswith('ΔCT')}; norm={k:np.array(v[0],float) for k,v in d.items() if k and k.startswith('After')}
    base=(2**dct['ΔCT-0d']).mean(axis=0)
    for day in ['3d','7d','14d']:
        rep=norm[f'After normalization-{day}']; comp=(2**dct[f'ΔCT-{day}']).mean(axis=0)/base; l=np.log2(rep)
        h7.append(dict(gene=gname.replace('ADAR2A','ADRA2A (sheet label "ADAR2A")').replace('GPIBA','GP1BA'),day=day,V1=rep[0],V2=rep[1],V3=rep[2],V4=rep[3],n_up_of_4=int((rep>1).sum()),geometric_mean=2**l.mean(),P_one_sample_t_log2=stats.ttest_1samp(l,0).pvalue,
                       reproducible_from_dCT=bool(np.allclose(comp,rep,rtol=1e-3)),V4_recomputed_from_dCT=comp[3]))
h7df=pd.DataFrame(h7)
# CBC human
hc=[]
for lab,r0 in [('PLT (x10^9/L)',4),('PCT (%)',19),('MPV (fL)',33),('PDW (fL)',48)]:
    g=[col(S+'8b',c,r0,r0+10) for c in 'BCDE']
    hc.append(dict(readout=lab,d0=g[0].mean(),d3=g[1].mean(),d7=g[2].mean(),d14=g[3].mean(),P_paired_d3=stats.ttest_rel(g[1],g[0]).pvalue,P_paired_d7=stats.ttest_rel(g[2],g[0]).pvalue,P_paired_d14=stats.ttest_rel(g[3],g[0]).pvalue))
g=[col('Fig. 7b',c,4,14) for c in 'BCDE']
hc.append(dict(readout='Serum creatine (uM)',d0=g[0].mean(),d3=g[1].mean(),d7=g[2].mean(),d14=g[3].mean(),P_paired_d3=stats.ttest_rel(g[1],g[0]).pvalue,P_paired_d7=stats.ttest_rel(g[2],g[0]).pvalue,P_paired_d14=stats.ttest_rel(g[3],g[0]).pvalue))
for lab,r0 in [('Platelet GP6/ACTB (n=4, densitometry)',4),('Platelet P2RY12/ACTB (n=4, densitometry)',12)]:
    g=[col('Fig. 7e',c,r0,r0+3) for c in 'BCDE']
    hc.append(dict(readout=lab,d0=g[0].mean(),d3=g[1].mean(),d7=g[2].mean(),d14=g[3].mean(),P_paired_d3=stats.ttest_rel(g[1],g[0]).pvalue,P_paired_d7=stats.ttest_rel(g[2],g[0]).pvalue,P_paired_d14=stats.ttest_rel(g[3],g[0]).pvalue))
hcdf=pd.DataFrame(hc)

# ---------- survival ----------
def logrank(t1,t2):
    times=np.unique(np.concatenate([t1,t2])); O1=E1=V=0
    for t in times:
        n1=np.sum(t1>=t); n2=np.sum(t2>=t); n=n1+n2; d1=np.sum(t1==t); d2=np.sum(t2==t); d=d1+d2
        if n>1: E1+=d*n1/n; V+=d*(n1/n)*(n2/n)*(n-d)/(n-1)
        O1+=d1
    chi2=(O1-E1)**2/V; return chi2, stats.chi2.sf(chi2,1)
sv=[]
for pan,sh,r0,r1,rc in [('Fig 1c','Fig. 1c',4,23,('F6','F8')),('Fig 1l','Fig. 1l',4,41,('F5','F7'))]:
    w=wb()[sh]; tv=np.array([w[f'A{r}'].value for r in range(r0,r1+1) if w[f'B{r}'].value is not None],float); tc=np.array([w[f'A{r}'].value for r in range(r0,r1+1) if w[f'C{r}'].value is not None],float)
    c2,p=logrank(tv,tc); sv.append(dict(panel=pan,n_vehicle=len(tv),n_creatine=len(tc),median_survival_vehicle_d=np.median(tv),median_survival_creatine_d=np.median(tc),logrank_chi2_recomputed=c2,P_recomputed=p,chi2_reported=w[rc[0]].value,P_reported=w[rc[1]].value,note='all animals reached endpoint; tumour model not named in sheet'))
svdf=pd.DataFrame(sv)

# ---------- phospho ----------
ph=pd.read_excel(os.path.join(DATA_DIR,'CRE-MK-01_phosphoproteomics.xlsx'),sheet_name=0); ph.columns=['gene','p','q','lfc']
phs=pd.DataFrame([
 dict(item='Phosphopeptide rows',value=len(ph)),dict(item='Unique gene names',value=ph.gene.nunique()),
 dict(item='Rows with P<0.05',value=int((ph.p<0.05).sum())),dict(item='Rows expected at P<0.05 by chance (5% of rows)',value=round(0.05*len(ph),1)),
 dict(item='Rows meeting the study screen (P<0.05 and fold >=1.2 or <=0.83; LOG_FOLDCHANGE read as log2)',value=int(((ph.p<0.05)&((ph.lfc>=np.log2(1.2))|(ph.lfc<=np.log2(0.83)))).sum())),
 dict(item='  of which up',value=int(((ph.p<0.05)&(ph.lfc>=np.log2(1.2))).sum())),dict(item='  of which down',value=int(((ph.p<0.05)&(ph.lfc<=np.log2(0.83))).sum())),
 dict(item='Rows with Q<0.05',value=int((ph.q<0.05).sum())),dict(item='Smallest Q in file',value=float(ph.q.min())),
 dict(item='Rows with P=0.42265 (pattern of a peptide quantified in a single sample)',value=int(np.isclose(ph.p,0.42265,atol=1e-5).sum())),
 dict(item='Stat5b peptide 1: log2FC / P / Q / rank by P',value=f"{ph[(ph.gene=='Stat5b')].sort_values('p').iloc[0].lfc:.2f} / {ph[(ph.gene=='Stat5b')].sort_values('p').iloc[0].p:.4f} / {ph[(ph.gene=='Stat5b')].sort_values('p').iloc[0].q:.3f} / {int((ph.p<ph[(ph.gene=='Stat5b')].p.min()).sum())+1}"),
 dict(item='Stat5b peptide 2: log2FC / P / Q',value=f"{ph[(ph.gene=='Stat5b')].sort_values('p').iloc[1].lfc:.2f} / {ph[(ph.gene=='Stat5b')].sort_values('p').iloc[1].p:.3f} / {ph[(ph.gene=='Stat5b')].sort_values('p').iloc[1].q:.3f}"),
 dict(item='Stat5a peptide: log2FC / P / Q',value=f"{ph[(ph.gene=='Stat5a')].iloc[0].lfc:.2f} / {ph[(ph.gene=='Stat5a')].iloc[0].p:.3f} / {ph[(ph.gene=='Stat5a')].iloc[0].q:.3f}"),
 dict(item='Jak2 peptide: log2FC / P',value=f"{ph[(ph.gene=='Jak2')].iloc[0].lfc:.2f} / {ph[(ph.gene=='Jak2')].iloc[0].p:.3f}"),
 dict(item='Phosphosite positions',value='not present in the file (gene-level rows only)'),
])
top=ph.sort_values('p').head(40).reset_index(drop=True); top.insert(0,'rank_by_P',top.index+1)

import pickle
pickle.dump(dict(two=two,fac=facdf,chip=chipdf,q=qdf,wc=wcdf,h=hdf,h7=h7df,hc=hcdf,sv=svdf,phs=phs,top=top), open('tables.pkl','wb'))
print(two.shape, facdf.shape, chipdf.shape, qdf.shape, wcdf.shape, hdf.shape, h7df.shape, hcdf.shape, svdf.shape)
print('two-group reported vs recomputed mismatches:'); print(two[two.reported_matches==False][['panel','readout','P_recomputed_student','P_reported']])
