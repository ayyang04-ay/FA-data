from common import *
S='Supplementary Fig  '
print('=== S1a body weight ===')
print(fmt(ttest(row(S+'1a',4,'B','E'), row(S+'1a',4,'F','I'),'d0')), '| rep', cell(S+'1a','M11'))
print(fmt(ttest(row(S+'1a',5,'B','E'), row(S+'1a',5,'F','I'),'d7')), '| rep', cell(S+'1a','M25'))
print('=== S1b food, S1c water ===')
print(fmt(ttest(col(S+'1b','B',4,9), col(S+'1b','C',4,9),'food')), '| rep', cell(S+'1b','F4'))
print(fmt(ttest(col(S+'1c','B',4,9), col(S+'1c','C',4,9),'water')), '| rep', cell(S+'1c','F4'))
print('=== S1e (n=6) ===')
for lab,r0,rp in [('lung wt',4,'F4'),('burden',13,'F13'),('foci',22,'F22')]:
    print(fmt(ttest(col(S+'1e','B',r0,r0+5), col(S+'1e','C',r0,r0+5),lab)), '| rep', cell(S+'1e',rp))
print('=== S1f (n=4) ===')
for lab,r0,rp in [('lung wt',4,'F4'),('burden',12,'F12'),('foci',20,'F20')]:
    print(fmt(ttest(col(S+'1f','B',r0,r0+3), col(S+'1f','C',r0,r0+3),lab)), '| rep', cell(S+'1f',rp))
print('=== S1g (n=10) ===')
for lab,r0,rp in [('lung wt',3,'F3'),('burden',15,'F15'),('foci',28,'F28')]:
    print(fmt(ttest(col(S+'1g','B',r0,r0+9), col(S+'1g','C',r0,r0+9),lab)), '| rep', cell(S+'1g',rp))
print('=== S1i diet (n=4) ===')
for lab,r0,rp in [('lung wt',3,'F3'),('burden',11,'F11'),('foci',18,'F18')]:
    print(fmt(ttest(col(S+'1i','B',r0,r0+3), col(S+'1i','C',r0,r0+3),lab)), '| rep', cell(S+'1i',rp))
print('=== S1k (n=10) ===')
for lab,r0,rp in [('lung wt',4,'G4'),('burden',16,'G16'),('foci',29,'G29')]:
    print(fmt(ttest(col(S+'1k','B',r0,r0+9), col(S+'1k','C',r0,r0+9),lab)), '| rep', cell(S+'1k',rp))
print('=== S2a Slc6a8 knockdown ===')
a=row(S+'2a',4,'H','J'); b=row(S+'2a',5,'H','J'); print('  dCT scr',a,'si',b,'FC=%.3f'%(2**(b.mean()-a.mean())), 'P(dCT)=%.4f'%stats.ttest_ind(a,b).pvalue, '| rep', cell(S+'2a','M4'))
print('=== S3a WBC etc (n=5) ===')
for lab,r0,rp in [('WBC',4,'F4'),('lymph',12,'F12'),('mono',20,'F20'),('RBC',28,'F28')]:
    print(fmt(ttest(col(S+'3a','B',r0,r0+4), col(S+'3a','C',r0,r0+4),lab)), '| rep', cell(S+'3a',rp))
print('=== S8a BMI (n=11, paired) ===')
a=col(S+'8a','C',4,14); b=col(S+'8a','D',4,14)
print('  d0 %.2f±%.2f d14 %.2f±%.2f; paired t P=%.3f; unpaired P=%.3f (rep %s)'%(a.mean(),a.std(ddof=1),b.mean(),b.std(ddof=1),stats.ttest_rel(a,b).pvalue,stats.ttest_ind(a,b).pvalue, cell(S+'8a','G5')))
print('=== S8b human CBC (n=11, paired) ===')
for lab,r0 in [('PLT',4),('PCT',19),('MPV',33),('PDW',48)]:
    g=[col(S+'8b',c,r0,r0+10) for c in 'BCDE']
    print(' ',lab, [f'{x.mean():.3g}' for x in g], 'paired t P (d3,d7,d14 vs d0):', [round(stats.ttest_rel(g[i],g[0]).pvalue,3) for i in (1,2,3)])
print('=== S8c CD41 expression purity check ===')
a=row(S+'8c',9,'E','G'); b=row(S+'8c',9,'I','K'); c=row(S+'8c',9,'M','O'); print('  CD41+ cells',a,'monocyte',b,'MEG-01',c)
print('=== S1d serum creatine mouse ===')
print(fmt(ttest(col(S+'1d','B',4,9), col(S+'1d','C',4,9),'serum creatine')))
