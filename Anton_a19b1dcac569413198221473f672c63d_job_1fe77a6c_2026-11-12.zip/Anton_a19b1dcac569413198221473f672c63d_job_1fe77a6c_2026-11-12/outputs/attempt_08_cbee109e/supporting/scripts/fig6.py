from common import *
import statsmodels.formula.api as smf
names=['Veh','Cre','Veh+inh','Cre+inh']
print('=== Fig 6b STAT5 inhibitor in vivo n=5 ===')
for lab,r0,rep in [('met burden',4,(4,5,6,7)),('foci',13,(13,14,15,16))]:
    g=[col('Fig. 6b',c,r0,r0+4) for c in 'BCDE']
    print(lab, [f'{np.mean(x):.4g}±{np.std(x,ddof=1):.3g}' for x in g], [list(x) for x in g])
    print_tukey(tukey(g,names))
    for rr in rep: print('   reported:', cell('Fig. 6b',f'G{rr}'), cell('Fig. 6b',f'H{rr}'), cell('Fig. 6b',f'L{rr}'))
    df = pd.DataFrame({'y':np.concatenate(g), 'inh':[0]*10+[1]*10, 'cre':([0]*5+[1]*5)*2})
    m = smf.ols('y ~ inh*cre', df).fit(); ci=m.conf_int().loc['inh:cre']
    print('   2x2: creatine effect w/o inh %.4g (P=%.3g); with inh %.4g; interaction %.4g [%.4g,%.4g] (P=%.3g); inh main at vehicle %.4g (P=%.3g)'%(m.params['cre'], m.pvalues['cre'], m.params['cre']+m.params['inh:cre'], m.params['inh:cre'], ci[0],ci[1], m.pvalues['inh:cre'], m.params['inh'], m.pvalues['inh']))
    # sensitivity: drop duplicated animals (rows 2-4 of Veh and Cre arms)
    g2=[g[0][[0,4]], g[1][[0,4]], g[2], g[3]]
    print('   sensitivity excluding the 3+3 values duplicated in Supp 2d: Veh', g2[0], 'Cre', g2[1])
    try:
        print_tukey(tukey(g2,names))
    except Exception as e: print(e)
print('=== Supp 2d platelet transfer ± aspirin n=6 ===')
n2=['Veh donor PLT','Cre donor PLT','Cre+ASA donor PLT']
for lab,r0,rep in [('met burden',5,(5,6,7)),('foci',14,(14,15,16))]:
    g=[col('Supplementary Fig  2d',c,r0,r0+5) for c in 'CDE']
    print(lab, [f'{np.mean(x):.4g}±{np.std(x,ddof=1):.3g}' for x in g], [list(x) for x in g])
    print_tukey(tukey(g,n2))
    for rr in rep: print('   reported:', cell('Supplementary Fig  2d',f'G{rr}'), cell('Supplementary Fig  2d',f'H{rr}'), cell('Supplementary Fig  2d',f'L{rr}'))
    # sensitivity: only first three rows (non-duplicated), and only last three
    ga=[x[:3] for x in g]; gb=[x[3:] for x in g]
    print('   first-3 rows only (not duplicated elsewhere):', [f'{np.mean(x):.4g}' for x in ga]); print_tukey(tukey(ga,n2))
    print('   last-3 rows only (Veh & Cre values duplicate Fig 6b):', [f'{np.mean(x):.4g}' for x in gb]); print_tukey(tukey(gb,n2))
print('=== Supp 7a CBC STAT5 inhibitor n=3 ===')
for lab,r0 in [('PLT',4),('PCT',11),('MPV',17),('PDW',23)]:
    g=[col('Supplementary Fig  7a',c,r0,r0+2) for c in 'BCDE']
    print(lab, [f'{np.mean(x):.4g}' for x in g]); print_tukey(tukey(g,names))
print('=== Supp 7b CBC Stat5b KO n=3 ===')
for lab,r0 in [('PLT',4),('PCT',10),('MPV',16),('PDW',22)]:
    g=[col('Supplementary Fig  7b',c,r0,r0+2) for c in 'BCD']
    print(lab, [f'{np.mean(x):.4g}' for x in g]); print_tukey(tukey(g,['WTveh','WTcre','KOcre']))
print('=== Supp 4b PLT Slc6a8 KO n=3 ===')
g=[col('Supplementary Fig  4b',c,5,7) for c in 'CDEF']; print([f'{np.mean(x):.4g}' for x in g]); print_tukey(tukey(g,['WTveh','WTcre','KOveh','KOcre']))
print('=== Supp 4c alpha-granules (8 fields) ===')
g=[col('Supplementary Fig  4c',c,6,13) for c in 'CDEF']; print([f'{np.mean(x):.4g}' for x in g]); print_tukey(tukey(g,['WTveh','WTcre','KOveh','KOcre']))
