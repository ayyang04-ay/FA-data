from common import *
rng=np.random.default_rng(11)
def remaining(g, label):
    L=[np.log2(x) for x in g]
    e_ctrl=L[1].mean()-L[0].mean(); e_pert=L[3].mean()-L[2].mean()
    frac=e_pert/e_ctrl
    # Fieller-type CI via parametric simulation from group means/SEs (t approx) 
    sims=[]
    s2=np.mean([x.var(ddof=1) for x in L]); 
    for _ in range(20000):
        m=[rng.normal(x.mean(), np.sqrt(s2/len(x))) for x in L]
        sims.append(((m[3]-m[2])/(m[1]-m[0])))
    lo,hi=np.percentile(sims,[2.5,97.5])
    print(f'{label}: creatine effect control x{2**e_ctrl:.2f}, perturbed x{2**e_pert:.2f}; fraction of log effect remaining {frac:.2f} (approx 95% interval {lo:.2f} to {hi:.2f})')
remaining([col('Fig. 3i',c,10,13) for c in 'BCDE'],'Fig 3i burden')
remaining([col('Fig. 3i',c,17,20) for c in 'BCDE'],'Fig 3i foci')
remaining([col('Fig. 6b',c,4,8) for c in 'BCDE'],'Fig 6b burden')
remaining([col('Fig. 6b',c,13,17) for c in 'BCDE'],'Fig 6b foci')
remaining([col('Fig. 1f',c,22,27) for c in 'BCDE'],'Fig 1f burden (tumour knock-down)')
