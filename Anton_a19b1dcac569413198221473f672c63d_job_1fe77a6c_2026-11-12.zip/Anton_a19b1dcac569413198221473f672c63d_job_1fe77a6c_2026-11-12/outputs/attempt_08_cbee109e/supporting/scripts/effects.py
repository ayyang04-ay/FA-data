from common import *
S='Supplementary Fig  '
# collect all vehicle-vs-creatine metastasis comparisons (WT host, direct dosing)
exps = [
 ('Fig 1a/b', 'Fig. 1b','B','C',3,8,  'Fig. 1b','B','C',12,17),
 ('Fig 1f shScr', 'Fig. 1f','B','C',22,27, 'Fig. 1f','B','C',31,36),
 ('Fig 1f shSlc6a8 tumour', 'Fig. 1f','D','E',22,27, 'Fig. 1f','D','E',31,36),
 ('Fig 1k', 'Fig. 1k','B','C',4,9, 'Fig. 1k','B','C',12,17),
 ('Fig 3i WT', 'Fig. 3i','B','C',10,13, 'Fig. 3i','B','C',17,20),
 ('Fig 6b no-inh', 'Fig. 6b','B','C',4,8, 'Fig. 6b','B','C',13,17),
 ('S1e', S+'1e','B','C',13,18, S+'1e','B','C',22,27),
 ('S1f', S+'1f','B','C',12,15, S+'1f','B','C',20,23),
 ('S1g', S+'1g','B','C',15,24, S+'1g','B','C',28,37),
 ('S1i diet', S+'1i','B','C',11,14, S+'1i','B','C',18,21),
 ('S1k', S+'1k','B','C',16,25, S+'1k','B','C',29,38),
]
rows=[]
for name, sh,c1,c2,r0,r1, sh2,d1,d2,q0,q1 in exps:
    a=col(sh,c1,r0,r1); b=col(sh,c2,r0,r1)
    fa=col(sh2,d1,q0,q1); fb=col(sh2,d2,q0,q1)
    la=np.log2(a); lb=np.log2(b)
    sp = np.sqrt(((len(a)-1)*la.var(ddof=1)+(len(b)-1)*lb.var(ddof=1))/(len(a)+len(b)-2))
    rows.append(dict(exp=name, n=f'{len(a)}/{len(b)}', burden_veh=a.mean(), burden_cre=b.mean(), ratio=b.mean()/a.mean(), log2ratio=lb.mean()-la.mean(), sd_log2=sp,
                     P_burden=stats.ttest_ind(a,b).pvalue, g_burden=hedges_g(a,b), foci_veh=fa.mean(), foci_cre=fb.mean(), foci_ratio=fb.mean()/fa.mean(), P_foci=stats.ttest_ind(fa,fb).pvalue, sd_raw=np.sqrt((a.var(ddof=1)+b.var(ddof=1))/2)))
df=pd.DataFrame(rows)
pd.set_option('display.width',300)
print(df.round(3).to_string(index=False))
print('median log2 ratio', df.log2ratio.median(), 'range', df.log2ratio.min(), df.log2ratio.max(), '| median sd_log2', df.sd_log2.median(), 'max', df.sd_log2.max())
df.to_csv('creatine_effect_across_experiments.csv', index=False)
# random-effects-ish summary of log ratio
w = 1/(df.sd_log2**2*(2/np.array([int(x.split('/')[0]) for x in df.n])))
print('inverse-variance weighted mean log2 ratio = %.3f -> ratio %.2f'%(np.sum(w*df.log2ratio)/np.sum(w), 2**(np.sum(w*df.log2ratio)/np.sum(w))))

# Power simulation for genotype x creatine interaction on log2 burden
rng = np.random.default_rng(20240611)
def power(n, eff_log2, sd, attenuation, nsim=4000, alpha=0.05):
    # cells: WTveh (0), WTcre (eff), KOveh (0), KOcre (eff*(1-attenuation))
    hits=0
    for _ in range(nsim):
        y00=rng.normal(0,sd,n); y01=rng.normal(eff_log2,sd,n); y10=rng.normal(0,sd,n); y11=rng.normal(eff_log2*(1-attenuation),sd,n)
        est = (y11.mean()-y10.mean())-(y01.mean()-y00.mean())
        s2 = (y00.var(ddof=1)+y01.var(ddof=1)+y10.var(ddof=1)+y11.var(ddof=1))/4
        se = np.sqrt(s2*4/n); t = est/se; p = 2*stats.t.sf(abs(t), 4*(n-1))
        hits += p<alpha
    return hits/nsim
print('\nPower for interaction (log2 burden). Assumptions: creatine effect log2 ratio; SD(log2) ; attenuation by KO')
for eff in [1.0, 1.3, 1.65]:
    for sd in [0.6, 0.8, 1.0]:
        for att in [1.0, 0.7, 0.5]:
            line = f'eff={eff:.2f} (x{2**eff:.1f}) sd={sd} attenuation={att:.0%}: ' + ', '.join(f'n={n}: {power(n,eff,sd,att):.2f}' for n in [6,8,10,12,15])
            print(line)
