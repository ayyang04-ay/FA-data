#!/usr/bin/env bash
# Re-runs the whole re-analysis. Needs python with numpy, pandas, scipy, statsmodels, openpyxl, matplotlib (and reportlab for the PDF).
# Data location: set CRE_DATA_DIR to the folder holding the two CRE-MK-01 workbooks (default /tmp/world/filesystem).
set -e
cd "$(dirname "$0")"
PY=${PY:-python}
for s in fig1 surv fig1f fig2 fig3 fig4 fig5 fig6 fig7 fig7d fig7d_check supp dunnett qpcr residual remain phospho duplicates human_explore human_power effects meta power2; do
  echo "===== $s.py"; $PY $s.py
done
$PY build_tables.py      # all recomputed tests -> tables.pkl
$PY inventory.py         # panel-by-panel table -> inventory.pkl
$PY write_xlsx.py        # -> ../CRE-MK-01_reanalysis.xlsx
$PY figure.py            # -> ../evidence_summary.png
$PY md2pdf.py ../../CRE-MK-02_validation_proposal.md ../../CRE-MK-02_validation_proposal.pdf
