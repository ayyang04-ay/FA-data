from common import *
from scipy.stats import dunnett
ws = wb()['Fig. 7c']
blocks = [('Collagen','max',4),('Collagen','avg',18),('Collagen','adh',32),('EPI','max',46),('EPI','avg',60),('EPI','adh',74),('AA','max',88),('AA','avg',102),('AA','adh',116),('ADP','max',130),('ADP','avg',144),('ADP','adh',157)]
ok=True
for ag,met,r0 in blocks:
    g=[col('Fig. 7c',c,r0,r0+10) for c in 'BCDE']
    res = dunnett(g[1],g[2],g[3], control=g[0])
    rep=[]
    for r in range(r0-2, r0+12):
        if ws[f'G{r}'].value in ('0 vs. 3','0 vs. 7','0 vs. 14'):
            rep.append(ws[f'L{r}'].value)
    print(ag, met, 'recomputed', np.round(res.pvalue,4), 'reported', rep)
g=[col('Supplementary Fig  8b',c,4,14) for c in 'BCDE']; print('S8b PLT', np.round(dunnett(g[1],g[2],g[3],control=g[0]).pvalue,4), [cell('Supplementary Fig  8b',f'L{r}') for r in (4,5,6)])
# Fig 7b Tukey
g=[col('Fig. 7b',c,4,14) for c in 'BCDE']; print_tukey(tukey(g,['d0','d3','d7','d14']))
