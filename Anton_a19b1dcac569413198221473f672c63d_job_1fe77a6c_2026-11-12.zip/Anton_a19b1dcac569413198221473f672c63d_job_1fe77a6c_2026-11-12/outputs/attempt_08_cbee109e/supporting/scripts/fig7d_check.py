from common import *
from openpyxl.utils import column_index_from_string, get_column_letter
ws = wb()['Fig. 7d']
blocks = []
for r in range(1, ws.max_row+1):
    for gc, c0 in [('A','C'),('H','I')]:
        g = ws[f'{gc}{r}'].value
        if isinstance(g,str) and ws[f'{c0}{r}'].value=='Volunteer1':
            blocks.append((g, r, c0))
allok=True
res={}
for g,r,c0 in blocks:
    ci = column_index_from_string(c0); lab_col = get_column_letter(ci-1)
    d = {}
    for rr in range(r+1, r+17):
        lab = ws[f'{lab_col}{rr}'].value
        vals = [ws.cell(row=rr, column=ci+k).value for k in range(4)]
        d.setdefault(lab, []).append(vals)
    dct = {k: np.array(v, float) for k,v in d.items() if k and k.startswith('ΔCT')}
    norm = {k: np.array(v[0], float) for k,v in d.items() if k and k.startswith('After')}
    base = (2**dct['ΔCT-0d']).mean(axis=0)
    res[g]={}
    for day in ['3d','7d','14d']:
        fc = (2**dct[f'ΔCT-{day}']).mean(axis=0)/base
        rep = norm[f'After normalization-{day}']
        ok = np.allclose(fc, rep, rtol=1e-3)
        res[g][day]=(fc,rep)
        if not ok:
            allok=False
            print('MISMATCH', g, day, 'computed', np.round(fc,4), 'reported', np.round(rep,4))
print('all consistent' if allok else 'some mismatches')
# Summaries on reported values: n up of 4, geometric mean, paired test on log2
print('gene, day: reported per-volunteer FC | geomean | n>1 | P (one-sample t on log2)')
for g in res:
    for day in ['3d','7d','14d']:
        rep = res[g][day][1]
        l = np.log2(rep)
        print(f'{g:7s} {day:>3s}: {np.round(rep,2)} | geomean {2**l.mean():.2f} | mean {rep.mean():.2f} | up {int((rep>1).sum())}/4 | P={stats.ttest_1samp(l,0).pvalue:.3f}')
