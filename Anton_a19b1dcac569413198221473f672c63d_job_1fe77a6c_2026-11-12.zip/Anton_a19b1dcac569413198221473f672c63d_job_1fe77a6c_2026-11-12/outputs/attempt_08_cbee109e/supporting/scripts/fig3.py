from common import *
import statsmodels.formula.api as smf
print('=== Fig 3b serum creatine (uM) n=5 ===')
for r,lab in [(4,'WT (Pf4cre;Slc6a8+/+)'),(5,'KO (Pf4cre;Slc6a8fl/fl)')]:
    a=row('Fig. 3b',r,'B','F'); b=row('Fig. 3b',r,'G','K')
    print(fmt(ttest(a,b,lab)))
print(' reported', cell('Fig. 3b','B17'), cell('Fig. 3b','B21'), cell('Fig. 3b','B31'), cell('Fig. 3b','B35'))
print('=== Fig 3c MK intracellular creatine n=3 ===')
G={}
for r,lab in [(4,'WT'),(5,'KO')]:
    a=row('Fig. 3c',r,'B','D'); b=row('Fig. 3c',r,'E','G')
    G[lab]=(a,b)
    print(fmt(ttest(a,b,lab)), a, b)
print(' reported', cell('Fig. 3c','B15'), cell('Fig. 3c','B19'), cell('Fig. 3c','B30'), cell('Fig. 3c','B34'))
df = pd.DataFrame({'y':np.concatenate([G['WT'][0],G['WT'][1],G['KO'][0],G['KO'][1]]), 'ko':[0]*6+[1]*6, 'cre':[0,0,0,1,1,1]*2})
m = smf.ols('y ~ ko*cre', df).fit(); print('   2x2 interaction: %.3g (P=%.3g)'%(m.params['ko:cre'], m.pvalues['ko:cre']))
print('   WT-cre vs KO-cre:', fmt(ttest(G['WT'][1], G['KO'][1], 'WTcre vs KOcre')))
m2 = smf.ols('np.log2(y) ~ ko*cre', df).fit(); print('   log2 scale 2x2 interaction: %.3g (P=%.3g)'%(m2.params['ko:cre'], m2.pvalues['ko:cre']))
print('=== Fig 3d aggregation n=3 ===')
names=['WTveh','WTcre','KOveh','KOcre']
for r,lab in [(4,'ADP'),(5,'Collagen'),(6,'Thrombin')]:
    g=[row('Fig. 3d',r,a,b) for a,b in [('B','D'),('E','G'),('H','J'),('K','M')]]
    print(lab, [list(x) for x in g], [f'{np.mean(x):.1f}' for x in g])
    out=tukey(g,names); print_tukey(out)
    df = pd.DataFrame({'y':np.concatenate(g), 'ko':[0]*6+[1]*6, 'cre':[0,0,0,1,1,1]*2})
    m = smf.ols('y ~ ko*cre', df).fit(); print('   2x2 interaction: %.3g (P=%.3g); KO main at vehicle: %.3g (P=%.3g)'%(m.params['ko:cre'], m.pvalues['ko:cre'], m.params['ko'], m.pvalues['ko']))
print(' reported ADP:', cell('Fig. 3d','P4'), cell('Fig. 3d','T4'), cell('Fig. 3d','P5'), cell('Fig. 3d','T5'))
print(' reported Collagen:', cell('Fig. 3d','P10'), cell('Fig. 3d','T10'), cell('Fig. 3d','P11'), cell('Fig. 3d','T11'))
print(' reported Thrombin:', cell('Fig. 3d','P15'), cell('Fig. 3d','T15'), cell('Fig. 3d','P16'), cell('Fig. 3d','T16'))
print('=== Fig 3i metastasis n=4 ===')
for lab,r0,rep in [('lung weight',3,(3,4,5)),('met burden',10,(10,11,12)),('foci',17,(17,18,19))]:
    g=[col('Fig. 3i',c,r0,r0+3) for c in 'BCDE']
    print(lab, [f'{np.mean(x):.4g}±{np.std(x,ddof=1):.3g}' for x in g], [list(x) for x in g])
    out=tukey(g,names); print_tukey(out)
    for rr in rep:
        print('   reported:', cell('Fig. 3i',f'G{rr}'), cell('Fig. 3i',f'H{rr}'), cell('Fig. 3i',f'I{rr}'), cell('Fig. 3i',f'L{rr}'))
    df = pd.DataFrame({'y':np.concatenate(g), 'ko':[0]*8+[1]*8, 'cre':[0,0,0,0,1,1,1,1]*2})
    m = smf.ols('y ~ ko*cre', df).fit(); ci=m.conf_int().loc['ko:cre']
    print('   2x2: creatine effect in WT %.4g (P=%.3g); in KO %.4g; interaction %.4g [%.4g,%.4g] (P=%.3g); KO main (veh) %.4g (P=%.3g)'%(m.params['cre'], m.pvalues['cre'], m.params['cre']+m.params['ko:cre'], m.params['ko:cre'], ci[0], ci[1], m.pvalues['ko:cre'], m.params['ko'], m.pvalues['ko']))
    # within KO t-test
    print('   KO veh vs KO cre:', fmt(ttest(g[2],g[3],'')))
