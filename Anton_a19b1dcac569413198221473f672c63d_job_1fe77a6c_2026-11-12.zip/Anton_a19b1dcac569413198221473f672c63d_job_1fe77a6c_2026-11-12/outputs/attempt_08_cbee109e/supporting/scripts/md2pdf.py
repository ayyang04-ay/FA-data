"""Render the proposal markdown to PDF (subset of markdown: headings, bold/italic, lists, pipe tables, images, rules)."""
import re, os, sys
import matplotlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, NextPageTemplate, Paragraph, Spacer, Table, TableStyle, Image, HRFlowable, ListFlowable, ListItem, KeepTogether, PageBreak
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
fd = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
pdfmetrics.registerFont(TTFont('DV', os.path.join(fd, 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B', os.path.join(fd, 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DV-I', os.path.join(fd, 'DejaVuSans-Oblique.ttf')))
pdfmetrics.registerFont(TTFont('DV-BI', os.path.join(fd, 'DejaVuSans-BoldOblique.ttf')))
registerFontFamily('DV', normal='DV', bold='DV-B', italic='DV-I', boldItalic='DV-BI')
src, dst = sys.argv[1], sys.argv[2]
base = os.path.dirname(os.path.abspath(src))
body = ParagraphStyle('body', fontName='DV', fontSize=9.2, leading=13, spaceAfter=5, alignment=TA_LEFT)
lead = ParagraphStyle('lead', parent=body, fontSize=10.6, leading=15, spaceAfter=8, backColor=colors.HexColor('#eef2ff'), borderPadding=(6,6,6,6), borderColor=colors.HexColor('#c7d2fe'), borderWidth=0.6)
h2 = ParagraphStyle('h2', parent=body, fontName='DV-B', fontSize=12.5, leading=16, spaceBefore=10, spaceAfter=5, textColor=colors.HexColor('#111827'))
h3 = ParagraphStyle('h3', parent=body, fontName='DV-B', fontSize=10.3, leading=14, spaceBefore=7, spaceAfter=4, textColor=colors.HexColor('#1f2937'))
cell = ParagraphStyle('cell', parent=body, fontSize=7.5, leading=9.8, spaceAfter=0)
cellh = ParagraphStyle('cellh', parent=cell, fontName='DV-B', textColor=colors.white)
bullet = ParagraphStyle('bullet', parent=body, spaceAfter=2.5)
def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?![\*\w])', r'<i>\1</i>', t)
    return t
lines = open(src, encoding='utf-8').read().split('\n')
story = []; i = 0; first_par = True
W = A4[0] - 30*mm
def col_widths(ncol, header):
    if ncol == 2:
        return [0.19*W, 0.81*W] if header[0].strip().lower() in ('item',) else [0.46*W, 0.54*W]
    if ncol == 3: return [0.25*W, 0.30*W, 0.45*W]
    if ncol == 4 and header[0].strip().lower() == 'panel': return [0.09*W, 0.25*W, 0.45*W, 0.21*W]
    if ncol == 4: return [0.14*W, 0.29*W, 0.30*W, 0.27*W]
    return [W/ncol]*ncol
def flush_list(items):
    # items: list of (level, text)
    out = []
    k = 0
    while k < len(items):
        lvl, txt = items[k]
        sub = []
        k2 = k + 1
        while k2 < len(items) and items[k2][0] > lvl:
            sub.append(items[k2]); k2 += 1
        content = [Paragraph(inline(txt), bullet)]
        if sub:
            content.append(ListFlowable([ListItem(Paragraph(inline(t), bullet), leftIndent=10) for _, t in sub], bulletType='bullet', start='–', leftIndent=12, bulletFontSize=8))
        out.append(ListItem(content, leftIndent=12))
        k = k2
    return out
while i < len(lines):
    ln = lines[i]
    if not ln.strip():
        i += 1; continue
    if ln.strip() == '---':
        story.append(Spacer(1, 3)); story.append(HRFlowable(width='100%', thickness=0.5, color=colors.HexColor('#9ca3af'))); story.append(Spacer(1, 3)); i += 1; continue
    m = re.match(r'!\[(.*?)\]\((.*?)\)', ln.strip())
    if m:
        path = os.path.join(base, m.group(2))
        from PIL import Image as PI
        w, h = PI.open(path).size
        LW, LH = A4[1] - 24*mm, A4[0] - 30*mm      # landscape frame
        ih = LH - 8*mm; iw = ih * w / h
        if iw > LW: iw = LW; ih = iw * h / w
        story.append(NextPageTemplate('landscape')); story.append(PageBreak())
        story.append(Image(path, width=iw, height=ih, hAlign='CENTER'))
        story.append(NextPageTemplate('portrait')); story.append(PageBreak()); i += 1; continue
    if ln.startswith('### '):
        story.append(Paragraph(inline(ln[4:]), h3)); i += 1; continue
    if ln.startswith('## '):
        if ln.startswith('## Appendix'): story.append(PageBreak())
        story.append(Paragraph(inline(ln[3:]), h2)); i += 1; continue
    if ln.lstrip().startswith('|'):
        rows = []
        while i < len(lines) and lines[i].lstrip().startswith('|'):
            cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
            rows.append(cells); i += 1
        header = rows[0]; data = [r for r in rows[2:]]
        ncol = len(header)
        tbl = [[Paragraph(inline(c) if c else '', cellh) for c in header]] + [[Paragraph(inline(c), cell) for c in r] for r in data]
        t = Table(tbl, colWidths=col_widths(ncol, header), repeatRows=1)
        t.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1f2937')), ('VALIGN', (0,0), (-1,-1), 'TOP'),
                               ('GRID', (0,0), (-1,-1), 0.35, colors.HexColor('#9ca3af')), ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f3f4f6')]),
                               ('LEFTPADDING', (0,0), (-1,-1), 3.5), ('RIGHTPADDING', (0,0), (-1,-1), 3.5), ('TOPPADDING', (0,0), (-1,-1), 3), ('BOTTOMPADDING', (0,0), (-1,-1), 3)]))
        story.append(t); story.append(Spacer(1, 7)); continue
    if re.match(r'^\s*(-|\d+\.)\s+', ln):
        items = []; numbered = bool(re.match(r'^\s*\d+\.\s+', ln))
        while i < len(lines) and re.match(r'^\s*(-|\d+\.)\s+', lines[i]):
            mm_ = re.match(r'^(\s*)(-|\d+\.)\s+(.*)$', lines[i])
            items.append((len(mm_.group(1))//2, mm_.group(3))); i += 1
        story.append(ListFlowable(flush_list(items), bulletType='1', bulletFormat='%s.', leftIndent=16, bulletFontName='DV', bulletFontSize=9) if numbered else ListFlowable(flush_list(items), bulletType='bullet', start='•', leftIndent=14, bulletFontName='DV', bulletFontSize=9))
        story.append(Spacer(1, 4)); continue
    # paragraph (join consecutive lines)
    par = [ln]; i += 1
    while i < len(lines) and lines[i].strip() and not re.match(r'^(\s*(-|\d+\.)\s+|#|\||!\[|---)', lines[i]):
        par.append(lines[i]); i += 1
    txt = inline(' '.join(par))
    story.append(Paragraph(txt, lead if first_par else body)); first_par = False
def footer(canvas, doc):
    pw, ph = canvas._pagesize
    canvas.saveState(); canvas.setFont('DV', 7); canvas.setFillColor(colors.HexColor('#6b7280'))
    canvas.drawString(15*mm, 9*mm, 'CRE-MK-02 validation proposal (basis: CRE-MK-01 data package)'); canvas.drawRightString(pw-15*mm, 9*mm, f'Page {doc.page}')
    canvas.restoreState()
doc = BaseDocTemplate(dst, pagesize=A4, leftMargin=15*mm, rightMargin=15*mm, topMargin=14*mm, bottomMargin=16*mm, title='CRE-MK-02 validation proposal', author='')
pf = Frame(15*mm, 16*mm, A4[0]-30*mm, A4[1]-30*mm, id='p', leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
lf = Frame(12*mm, 15*mm, A4[1]-24*mm, A4[0]-30*mm, id='l', leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
doc.addPageTemplates([PageTemplate(id='portrait', frames=[pf], onPage=footer, pagesize=A4), PageTemplate(id='landscape', frames=[lf], onPage=footer, pagesize=(A4[1], A4[0]))])
doc.build(story)
print('pdf written', dst)
