from common import *
from qpcr import parse_qpcr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import matplotlib.patches as mpatches
plt.rcParams.update({'font.size':8.5,'axes.spines.top':False,'axes.spines.right':False,'font.family':'DejaVu Sans','axes.titlesize':9.5,'axes.titleweight':'bold','axes.titlelocation':'left'})
S='Supplementary Fig  '
C_VEH='#6b7280'; C_CRE='#c2410c'; C_BLUE='#1d4ed8'
fig = plt.figure(figsize=(14, 11.6))
gs = GridSpec(3, 24, figure=fig, hspace=0.50, wspace=1.0, left=0.06, right=0.985, top=0.965, bottom=0.06, height_ratios=[1,1,1.02])

# ---------- A: forest ----------
ax = fig.add_subplot(gs[0, 5:12])
exps = [
 ('Fig 1b (n=6/6)', 'Fig. 1b','B','C',3,8),
 ('Fig 1f, sh-scrambled tumour (6/6)', 'Fig. 1f','B','C',22,27),
 ('Fig 1f, sh-Slc6a8 tumour (6/6)', 'Fig. 1f','D','E',22,27),
 ('Fig 1k (6/6)', 'Fig. 1k','B','C',4,9),
 ('Fig 3i, Cre control arms (4/4)', 'Fig. 3i','B','C',10,13),
 ('Fig 6b, no-inhibitor arms (5/5)', 'Fig. 6b','B','C',4,8),
 ('Supp 1e (6/6)', S+'1e','B','C',13,18),
 ('Supp 1f (4/4)', S+'1f','B','C',12,15),
 ('Supp 1g (10/10)', S+'1g','B','C',15,24),
 ('Supp 1i, creatine diet (4/4)', S+'1i','B','C',11,14),
 ('Supp 1k (10/10)', S+'1k','B','C',16,25),
]
ys=[]; vs=[]
for i,(lab,sh,c1,c2,r0,r1) in enumerate(exps):
    a=np.log2(col(sh,c1,r0,r1)); b=np.log2(col(sh,c2,r0,r1))
    d=b.mean()-a.mean(); sp2=((len(a)-1)*a.var(ddof=1)+(len(b)-1)*b.var(ddof=1))/(len(a)+len(b)-2); se=np.sqrt(sp2*(1/len(a)+1/len(b)))
    tcrit=stats.t.ppf(0.975,len(a)+len(b)-2)
    y=len(exps)-i
    ax.plot([2**(d-tcrit*se),2**(d+tcrit*se)],[y,y],color=C_CRE,lw=1.4); ax.plot(2**d,y,'o',color=C_CRE,ms=5)
    ys.append(d); vs.append(se**2)
ys=np.array(ys); vs=np.array(vs); w=1/vs; yf=np.sum(w*ys)/np.sum(w); Q=np.sum(w*(ys-yf)**2); k=len(ys)
tau2=max(0,(Q-(k-1))/(np.sum(w)-np.sum(w**2)/np.sum(w))); wr=1/(vs+tau2); yr=np.sum(wr*ys)/np.sum(wr); ser=np.sqrt(1/np.sum(wr))
ax.plot([2**(yr-1.96*ser),2**(yr+1.96*ser)],[0,0],color='k',lw=2); ax.plot(2**yr,0,'D',color='k',ms=6)
ax.set_yticks(list(range(len(exps),0,-1))+[0]); ax.set_yticklabels([e[0] for e in exps]+[f'Pooled (random effects): {2**yr:.1f}x [{2**(yr-1.96*ser):.1f}-{2**(yr+1.96*ser):.1f}]'])
ax.axvline(1,color='grey',lw=0.8,ls='--'); ax.set_xscale('log'); ax.set_xticks([1,2,3,4,6,8]); ax.set_xticklabels(['1','2','3','4','6','8'])
ax.set_xlabel('Lung metastatic burden, creatine / vehicle (ratio of geometric means, 95% CI)')
ax.set_title('A  Creatine raises lung metastatic burden in every cohort in the file', x=-0.72)
ax.set_ylim(-0.8,len(exps)+0.7)

# ---------- helper for 2x2 dot plots ----------
def dots(ax, groups, labels, colors, ylabel, title, hollow=None, annot=None):
    rng=np.random.default_rng(3)
    for i,g in enumerate(groups):
        x=i+rng.uniform(-0.12,0.12,len(g))
        for j,(xx,yy) in enumerate(zip(x,g)):
            hol = hollow is not None and (i,j) in hollow
            ax.plot(xx,yy,'o',ms=5.5,mfc='white' if hol else colors[i],mec=colors[i],mew=1.2,alpha=0.95)
        ax.plot([i-0.25,i+0.25],[np.mean(g)]*2,color='k',lw=1.6)
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(labels,fontsize=7.8)
    ax.set_ylabel(ylabel); ax.set_title(title)
    if annot: ax.text(0.02,0.97,annot,transform=ax.transAxes,va='top',ha='left',fontsize=7.6,bbox=dict(fc='white',ec='#d1d5db',lw=0.6,pad=3))
    ax.set_ylim(0, max(max(g) for g in groups)*1.32)

# ---------- B: Fig 3i ----------
ax = fig.add_subplot(gs[0, 14:24])
g=[col('Fig. 3i',c,10,13) for c in 'BCDE']
dots(ax,g,['Cre;Slc6a8+/+\nvehicle','Cre;Slc6a8+/+\ncreatine','Cre;Slc6a8fl/fl\nvehicle','Cre;Slc6a8fl/fl\ncreatine'],[C_VEH,C_CRE,C_VEH,C_CRE],'Lung metastatic burden (%)',
     'B  Megakaryocyte-lineage Slc6a8 deletion (Fig 3i, n=4/arm)',
     annot='Creatine effect: +5.5 pts in controls, -0.5 pts in deletion\nGenotype x creatine interaction P = 0.0003\nVehicle arms: 2.4% vs 3.4% (no baseline effect)')

# ---------- C: Fig 6b ----------
ax = fig.add_subplot(gs[1, 0:10])
g=[col('Fig. 6b',c,4,8) for c in 'BCDE']
hollow={(0,1),(0,2),(0,3),(1,1),(1,2),(1,3)}
dots(ax,g,['Vehicle','Creatine','Vehicle +\nSTAT5-IN-1','Creatine +\nSTAT5-IN-1'],[C_VEH,C_CRE,C_VEH,C_CRE],'Lung metastatic burden (%)',
     'C  Systemic STAT5A/B inhibitor (Fig 6b, n=5/arm)', hollow=hollow,
     annot='Inhibitor x creatine interaction P = 7e-6\nInhibitor alone: no baseline effect (3.4% vs 3.6%)\nOpen symbols: values that also appear in Supp 2d')

# ---------- D: heat map ----------
ax = fig.add_subplot(gs[1, 15:23])
genes=['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
def l2(sheet, defs):
    d=parse_qpcr(sheet, grp_defs=defs); out={}
    for name,_,_ in defs:
        out[name]=[np.mean(d[g][name])-np.mean(d[g]['ctrl']) for g in genes]
    return out
cols=[]; labs=[]
a=l2('Fig. 2f',[('c','G','I')]); cols.append(a['c']); labs.append('Creatine in vivo (2f)')
a=l2('Fig. 3f',[('WTcre','G','I'),('KOveh','K','M'),('KOcre','O','Q')]); cols+= [a['WTcre'],a['KOveh'],a['KOcre']]; labs+=['Cre control + creatine (3f)','Slc6a8 deletion, vehicle (3f)','Slc6a8 deletion + creatine (3f)']
a=l2('Fig. 6g',[('WTcre','G','I'),('KOcre','K','M')]); cols+=[a['WTcre'],a['KOcre']]; labs+=['WT + creatine (6g)','Stat5b deletion + creatine (6g)']
a=l2('Fig.6a',[('c','G','I'),('vi','K','M'),('ci','O','Q')]); cols+=[a['c'],a['vi'],a['ci']]; labs+=['Creatine (6a)','STAT5-IN-1 alone (6a)','Creatine + STAT5-IN-1 (6a)']
a=l2('Fig. 4j',[('s','G','I'),('cs','K','M'),('cc','O','Q')]); cols+=[a['cs'],a['s'],a['cc']]; labs+=['Creatine + si-scrambled (4j)','si-Ckb alone (4j)','Creatine + si-Ckb (4j)']
a=l2('Fig. 4l',[('oe','G','I')]); cols.append(a['oe']); labs.append('CKB over-expression (4l)')
a=l2('Fig. 4h',[('c','G','I'),('p','K','M')]); cols.append(a['p']); labs.append('Phosphocreatine (4h)')
M=np.array(cols)
im=ax.imshow(M,cmap='RdBu_r',vmin=-3,vmax=3,aspect='auto')
ax.set_xticks(range(len(genes))); ax.set_xticklabels(['Itga2b','P2ry12','Gp6','Gp1ba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb'],rotation=45,ha='right',fontsize=7.5)
ax.set_yticks(range(len(labs))); ax.set_yticklabels(labs,fontsize=7.3)
for sp in ax.spines.values(): sp.set_visible(False)
for yline in [0.5,3.5,5.5,8.5,11.5,12.5]: ax.axhline(yline,color='white',lw=2.5)
cb=fig.colorbar(im,ax=ax,fraction=0.04,pad=0.02); cb.set_label('log2 fold vs panel control',fontsize=7.5); cb.ax.tick_params(labelsize=7)
ax.set_title('D  Megakaryocyte platelet-activation transcripts (n=3/group)')

# ---------- E: human ----------
ax = fig.add_subplot(gs[2, 0:10])
blocks=[('Collagen',4),('Epinephrine',46),('Arachidonic\nacid',88),('ADP',130)]
rng=np.random.default_rng(5)
for i,(lab,r0) in enumerate(blocks):
    x=col('Fig. 7c','E',r0,r0+10)
    ax.plot(i+rng.uniform(-0.13,0.13,len(x)),x,'o',ms=5.5,color=C_BLUE,alpha=0.8,mec='white',mew=0.5)
    gm=2**np.mean(np.log2(x)); ax.plot([i-0.27,i+0.27],[gm,gm],color='k',lw=1.8)
    p=stats.wilcoxon(x-1).pvalue
    ax.text(i,17,f'{int((x>1).sum())}/11 up\ngeo-mean {gm:.2f}x\nWilcoxon P={p:.3f}',ha='center',va='bottom',fontsize=7.4)
ax.axhline(1,color='grey',ls='--',lw=0.8); ax.set_yscale('log'); ax.set_ylim(0.3,60); ax.set_yticks([0.5,1,2,4,8,16]); ax.set_yticklabels(['0.5','1','2','4','8','16'])
ax.set_xticks(range(4)); ax.set_xticklabels([b[0] for b in blocks]); ax.set_ylabel('Maximum aggregation, day 14 / day 0')
ax.set_title('E  Healthy volunteers, 20 g/day for 14 days (Fig 7c, n=11, no control arm)')

# ---------- F: evidence matrix ----------
ax = fig.add_subplot(gs[2, 14:24])
rows=['Megakaryocyte SLC6A8\n(creatine uptake)','Megakaryocyte STAT5B\n(S127)','CKB','GP6 / P2RY12\n(platelet effectors)']
colsF=['Lineage-specific\ndeletion:\nmetastasis','Lineage-specific\ndeletion:\nplatelet / MK\nreadouts','Pharmacology\nin vivo:\nmetastasis','Loss / gain of\nfunction in\nprimary MKs','Human\nnode-level\ndata']
# 2=direct, 1=partial/indirect, 0=none
mat=np.array([[2,2,0,2,0],
              [0,1,1,1,0],
              [0,0,0,2,0],
              [0,0,1,0,1]])
txt=[['Fig 3i\n2x2, n=4','Fig 3c,d,f\nSupp 4b,c','none','Supp 4e\nliposome rescue','none'],
     ['not done','Fig 6e-g: no\ndeletion-vehicle arm,\nno function assay','Fig 6b: STAT5A/B\ninhibitor, systemic','Fig 6a inhibitor;\nS127 data are\nFLAG-STAT5B blots','none'],
     ['no model','no model','none','Fig 4j, 4l\nsi-Ckb, over-expr.','none'],
     ['not tested','not tested','Supp 2d: aspirin on\ndonor platelets','not tested','Fig 7c-e: marker\nand function only']]
cmap={2:'#15803d',1:'#fbbf24',0:'#e5e7eb'}
for i in range(mat.shape[0]):
    for j in range(mat.shape[1]):
        ax.add_patch(mpatches.Rectangle((j,mat.shape[0]-1-i),0.96,0.92,color=cmap[mat[i,j]]))
        ax.text(j+0.48,mat.shape[0]-1-i+0.46,txt[i][j],ha='center',va='center',fontsize=6.7,color='white' if mat[i,j]==2 else 'black')
ax.set_xlim(0,mat.shape[1]); ax.set_ylim(0,mat.shape[0])
ax.set_xticks(np.arange(mat.shape[1])+0.48); ax.set_xticklabels(colsF,fontsize=7.2); ax.xaxis.tick_top()
ax.set_yticks(np.arange(mat.shape[0])+0.46); ax.set_yticklabels(rows[::-1],fontsize=7.8)
ax.tick_params(length=0)
for sp in ax.spines.values(): sp.set_visible(False)
ax.set_title('F  Where each candidate has causal evidence', pad=46)
handles=[mpatches.Patch(color=cmap[2],label='direct'),mpatches.Patch(color=cmap[1],label='partial / indirect'),mpatches.Patch(color=cmap[0],label='absent')]
ax.legend(handles=handles,loc='upper center',bbox_to_anchor=(0.5,-0.03),ncol=3,frameon=False,fontsize=7.5)
fig.text(0.06,0.012,'All panels re-derived from the CRE-MK-01 source data. Bars: arithmetic mean (B, C), geometric mean (E). A: pooled estimate from a random-effects model on log ratios. D: each row is relative to the control group of its own panel.',fontsize=7.2,color='#374151')
fig.savefig('../evidence_summary.png',dpi=170)
print('saved')
