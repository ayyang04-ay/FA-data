import pandas as pd, numpy as np, pickle
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
T = pickle.load(open('tables.pkl','rb')); inv = pd.read_pickle('inventory.pkl')
eff = pd.read_csv('creatine_effect_across_experiments.csv')
qc = pd.DataFrame([
 ('Duplicate animals across experiments','Fig 6b (vehicle B5:B7, creatine C5:C7; foci B14:B16, C14:C16) and Supp 2d (C8:C10, D8:D10; foci C17:C19, D17:D19)','Three vehicle and three creatine animals carry identical burden and foci values in a direct-dosing experiment and a platelet-transfer experiment','Conclusions of both panels survive exclusion of the shared values (see factorial sheet, sensitivity rows), but the two panels are not independent and one is mislabelled or shares controls; reconcile against animal records before either is cited'),
 ('Values not reproducible from listed inputs','Fig 7d, volunteer 4, RAB27B and PITPNB','Normalised fold values (e.g. day 14: 2.36 and 6.26) do not follow from the listed dCT rows (recomputed 0.49 and 0.59); PITPNB volunteer-4 "dCT" entries are +26 to +28 and look like raw Ct','Treat volunteer-4 values for these two genes as unverified'),
 ('Identical high-precision replicate values','Fig 3f: Gp6 deletion-vehicle replicates 1 and 3 (K19=M19); Fcgr2a deletion-creatine replicates 1 and 3 (O39=Q39)','16-digit identical dCT in nominally independent samples','2 of 132 values; does not change the panel conclusion'),
 ('Field-level n','Fig 1i, 2c, 2j, Supp 4c','n = 8 random fields per group; animal number not recorded','P values are pseudo-replicated; used as supportive only'),
 ('Paired data analysed as unpaired','Fig 7b, 7c, 7e, Supp 8a, 8b','Repeated measures in the same volunteers analysed with ordinary one-way ANOVA; in 7c the day-0 column is fixed at 1 (zero variance)','Re-analysed here with paired / one-sample tests on the log scale and Wilcoxon signed-rank; collagen and epinephrine conclusions hold, ADP is null, arachidonic acid borderline'),
 ('No control arm in the human study','Fig 7b-7g','Single-arm before/after design, 11 healthy volunteers aged 20-25, 20 g/day','Time and regression effects cannot be excluded; no placebo; no cancer patients'),
 ('Incomplete factorial designs','Fig 6e-6g, Supp 7b (Stat5b deletion); Supp 2d (aspirin)','No deletion-vehicle arm and a WT (not Cre) control for Stat5b; no aspirin-only donor arm','A creatine-specific effect of Stat5b deletion cannot be separated from a baseline effect'),
 ('Discovery screen without error control','Phosphoproteomics','n=3/group; screen uses uncorrected P<0.05; no row has Q<0.05 (minimum 0.167); 238 rows at P<0.05 against about 291 expected by chance; phosphosite positions not in the file','STAT5B nomination is hypothesis-generating; Stat5b peptide Q=0.246'),
 ('Allocation and sizing','All animal work','Not masked at allocation or readout; no sample-size calculation; sex not analysed (male C57BL/6J, female BALB/cJ: sex confounded with strain)','Effect sizes are likely optimistic; follow-up must be blinded, powered and sex-balanced'),
 ('Immunoblot replication','Fig 2e, 2g, 2i, 3g, 4b, 4g, 4i, 4k, 5g-5i, 6d, 6f, Supp 4a, 5b, 6a, 6d-6h','1-3 lanes per condition, no densitometry in file except 5e, 5f, 7e; loading control run on a different gel','Qualitative support only'),
 ('Labels to confirm','Fig 4d; Fig 1f; Fig 7d; Fig 6e/6g/Supp 7b; Fig 1h; Supp 1e-1k','"Creatinine" header on a creatine panel; "WT-creatine vs. si-Slc6a8-creatine" comparison label; "ADAR2A" for ADRA2A; "PF4-cre" for the Pf4-iCre line; no y-axis label; tumour model not named','None changes a number; all should be fixed in the master file'),
 ('Unequal group size','Fig 1l','20 vehicle vs 18 creatine animals','Reason not recorded'),
 ('Primer table','Study conventions, ChIP primers','The Rab4a promoter -1000 and -2000 forward primers have the same sequence','Check which amplicons Supp 6i rows "1K" and "2K" measure'),
 ('Normality testing','Study conventions','The D Agostino-Pearson test named in the conventions needs at least 8 values per group; most groups have 3-6','Parametric tests were applied without a usable normality check; Welch and Mann-Whitney P values are given beside each two-group test'),
 ('Borderline single tests','Fig 3c (P=0.049; Welch 0.105), Fig 2d TEG-MA (P=0.049; Welch 0.052), Fig 5f WT vehicle vs creatine (P=0.087)','n=3-5','Direction consistent with better-powered panels'),
], columns=['issue','where','what','consequence'])
power = pd.DataFrame([
 ('Observed creatine effect on burden, 11 comparisons','ratio 2.1-4.0x; random-effects pooled 3.2x (95% CI 2.7-3.7); I2=55%'),
 ('Observed SD of log2 burden within arm','median 0.50, maximum 0.82'),
 ('Planning assumption (shrunken)','true creatine effect 2.5x (log2 1.3), SD(log2) 0.6; sensitivity at SD 0.8'),
 ('Test','genotype x creatine interaction on log2 burden, two-sided alpha 0.025 per deletion line (two lines)'),
 ('Power, complete abolition, n=12/arm','0.92 (2.5x, SD 0.6); 0.69 (2.5x, SD 0.8); 0.99 (3.1x, SD 0.6); 0.89 (3.1x, SD 0.8)'),
 ('Power, 70% attenuation, n=12/arm','0.62 (2.5x, SD 0.6); 0.84 (3.1x, SD 0.6); 0.95 (3.1x, SD 0.5)'),
 ('Power, complete abolition, n=8/arm (fallback)','0.75 (2.5x, SD 0.6); 0.93 (3.1x, SD 0.6)'),
 ('Same at alpha 0.05, n=12/arm','abolition 0.96 (2.5x, SD 0.6), 0.79 (2.5x, SD 0.8); 70% attenuation 0.73 (2.5x, SD 0.6), 0.90 (3.1x, SD 0.6)'),
 ('Method','20,000 simulations per cell, normal errors on log2 burden, interaction t-test with pooled variance (scripts/power2.py)'),
 ('Human crossover: day-14 maximum aggregation','collagen: observed mean log2 fold 1.33 (2.5x), SD 1.17; epinephrine 0.70 (1.6x), SD 0.64'),
 ('Human crossover sample size','assuming placebo-period noise equals active-period noise: 15 completers for 80% power at the observed effect; 24-25 at 75% of it; 31-33 for 90% power at 75% of it'),
], columns=['item','value'])
sheets = [
 ('README', pd.DataFrame({'CRE-MK-01 re-analysis workbook':[
   'Every numeric panel in CRE-MK-01_source_data.xlsx was re-computed from the raw values; reported P values are shown next to recomputed ones.',
   'panel_inventory: one row per source sheet (87) with what it is, n unit and the re-derived headline.',
   'two_group_tests: Student t (as in the source), Welch and Mann-Whitney for every two-group comparison (71).',
   'factorial_tests: one-way ANOVA/Tukey as in the source plus 2x2 interaction contrasts that the source did not report.',
   'creatine_effect_by_cohort: metastatic burden and foci, creatine vs vehicle, for the 11 cohorts; used for the pooled estimate and power.',
   'qpcr_by_gene / qpcr_contrasts: fold changes from dCT with t tests on dCT (log scale).',
   'chip: percent-input ChIP-qPCR with Sidak-adjusted P (two-way ANOVA error term).',
   'human_fig7c / human_fig7d / human_summary: paired re-analysis of the volunteer data.',
   'survival: log-rank re-computation.',
   'phospho_summary / phospho_top40: summary of the volcano table.',
   'qc_flags: data-integrity and design issues found.',
   'power: planning numbers for the proposed studies.',
   'Scripts that generated every table are in supporting/scripts.']})),
 ('panel_inventory', inv), ('two_group_tests', T['two']), ('factorial_tests', T['fac']), ('creatine_effect_by_cohort', eff),
 ('qpcr_by_gene', T['q']), ('qpcr_contrasts', T['wc']), ('chip', T['chip']), ('human_fig7c', T['h']), ('human_fig7d', T['h7']), ('human_summary', T['hc']),
 ('survival', T['sv']), ('phospho_summary', T['phs']), ('phospho_top40', T['top']), ('qc_flags', qc), ('power', power)]
wb = Workbook(); wb.remove(wb.active)
for name, df in sheets:
    ws = wb.create_sheet(name)
    df = df.copy()
    for c in df.columns:
        if df[c].dtype.kind == 'f':
            df[c] = df[c].apply(lambda v: None if pd.isna(v) else float(f'{v:.4g}'))
    ws.append([str(c) for c in df.columns])
    for r in df.itertuples(index=False):
        ws.append([ (None if (isinstance(v,float) and np.isnan(v)) else (bool(v) if isinstance(v,(np.bool_,)) else (v.item() if hasattr(v,'item') else v))) for v in r])
    for cell in ws[1]:
        cell.font = Font(bold=True, color='FFFFFF'); cell.fill = PatternFill('solid', fgColor='1F2937'); cell.alignment = Alignment(wrap_text=True, vertical='top')
    for i, c in enumerate(df.columns, 1):
        mx = max([len(str(c))] + [len(str(v)) for v in df[c].head(200)])
        ws.column_dimensions[get_column_letter(i)].width = min(max(10, mx + 2), 70)
    for row in ws.iter_rows(min_row=2):
        for cell in row: cell.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'A2'
wb.save('../CRE-MK-01_reanalysis.xlsx')
print('written', [s[0] for s in sheets])
