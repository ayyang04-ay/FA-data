from common import *
names = ['shScr-veh','shScr-cre','shSlc6a8-veh','shSlc6a8-cre']
for label, r0, r1, reprow in [('lung weight',4,9,(4,5,6)),('SUV-BW',13,18,(13,14,15)),('met burden',22,27,(22,23,24)),('foci',31,36,(31,32,33))]:
    g = [col('Fig. 1f',c,r0,r1) for c in 'BCDE']
    print('==', label, [f'{np.mean(x):.4g}±{np.std(x,ddof=1):.3g} (n={len(x)})' for x in g])
    out = tukey(g, names); print_tukey(out)
    for rr in reprow:
        print('   reported:', cell('Fig. 1f',f'G{rr}'), '| diff', cell('Fig. 1f',f'H{rr}'), '| CI', cell('Fig. 1f',f'I{rr}'), '| adjP', cell('Fig. 1f',f'L{rr}'))
    # 2x2 interaction test
    import statsmodels.api as sm, statsmodels.formula.api as smf
    df = pd.DataFrame({'y':np.concatenate(g), 'kd':np.repeat([0,0,1,1],[len(x) for x in g]), 'cre':np.repeat([0,1,0,1],[len(x) for x in g])})
    m = smf.ols('y ~ kd*cre', df).fit()
    print('   2x2 OLS: creatine effect in shScr=%.4g (P=%.3g); interaction kd:cre=%.4g (P=%.3g); kd main=%.4g (P=%.3g)' % (m.params['cre'], m.pvalues['cre'], m.params['kd:cre'], m.pvalues['kd:cre'], m.params['kd'], m.pvalues['kd']))
    ci = m.conf_int().loc['kd:cre']
    print('   interaction 95%% CI [%.4g, %.4g]; creatine effect within shSlc6a8 = %.4g' % (ci[0], ci[1], m.params['cre']+m.params['kd:cre']))
