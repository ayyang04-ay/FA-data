"""Exact-match scan for numeric values repeated across different sheets of the source-data workbook."""
import os, openpyxl, collections
DATA_DIR = os.environ.get('CRE_DATA_DIR', '/tmp/world/filesystem')
wb = openpyxl.load_workbook(os.path.join(DATA_DIR, 'CRE-MK-01_source_data.xlsx'), data_only=True)
vals = collections.defaultdict(list)
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            v = c.value
            if isinstance(v, float) and abs(v - round(v)) > 1e-9 and len(repr(v)) >= 7:
                vals[v].append((ws.title, c.coordinate))
hits = {v: l for v, l in vals.items() if len({x[0] for x in l}) > 1}
# keep raw measurements with >=5 significant digits (drops 2-decimal Ct differences and rounded P values)
for v, l in sorted(hits.items(), key=lambda kv: kv[1][0]):
    digits = len(repr(v).replace('.', '').replace('-', '').lstrip('0'))
    if 5 <= digits <= 9:
        print(v, l)
print('\nInteger foci counts, Fig 6b vs Supplementary Fig 2d (same animals):')
a = wb['Fig. 6b']; b = wb['Supplementary Fig  2d']
print(' Fig 6b vehicle', [a[f'B{r}'].value for r in range(13, 18)], 'creatine', [a[f'C{r}'].value for r in range(13, 18)])
print(' Supp 2d vehicle donors', [b[f'C{r}'].value for r in range(14, 20)], 'creatine donors', [b[f'D{r}'].value for r in range(14, 20)])
