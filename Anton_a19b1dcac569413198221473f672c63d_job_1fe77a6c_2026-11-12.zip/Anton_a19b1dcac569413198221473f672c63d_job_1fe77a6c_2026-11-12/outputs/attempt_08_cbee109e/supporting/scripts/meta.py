import pandas as pd, numpy as np
from scipy import stats
df = pd.read_csv('creatine_effect_across_experiments.csv')
n = np.array([int(x.split('/')[0]) for x in df.n]); n2 = np.array([int(x.split('/')[1]) for x in df.n])
# exclude duplicate-animal issue? keep all; note Fig 1f arms are 2 comparisons within the same experiment
y = df.log2ratio.values; v = df.sd_log2.values**2*(1/n+1/n2)
w = 1/v; yf = np.sum(w*y)/np.sum(w); Q = np.sum(w*(y-yf)**2); k=len(y)
tau2 = max(0,(Q-(k-1))/(np.sum(w)-np.sum(w**2)/np.sum(w)))
wr = 1/(v+tau2); yr = np.sum(wr*y)/np.sum(wr); se = np.sqrt(1/np.sum(wr))
print('k=%d; fixed log2=%.3f (x%.2f); Q=%.2f (P=%.3f); tau2=%.3f; I2=%.0f%%'%(k,yf,2**yf,Q,stats.chi2.sf(Q,k-1),tau2,max(0,(Q-(k-1))/Q)*100))
print('random-effects pooled ratio: x%.2f (95%% CI %.2f-%.2f)'%(2**yr, 2**(yr-1.96*se), 2**(yr+1.96*se)))
print('range of ratios: %.2f-%.2f; all P<%.3f'%(df.ratio.min(), df.ratio.max(), df.P_burden.max()))
print('foci ratio range: %.2f-%.2f; max P %.4f'%(df.foci_ratio.min(), df.foci_ratio.max(), df.P_foci.max()))
