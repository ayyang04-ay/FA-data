"""Summary of the phosphoproteomics volcano table (CRE-MK-01_phosphoproteomics.xlsx)."""
import os, pandas as pd, numpy as np
DATA_DIR = os.environ.get('CRE_DATA_DIR', '/tmp/world/filesystem')
df = pd.read_excel(os.path.join(DATA_DIR, 'CRE-MK-01_phosphoproteomics.xlsx'), sheet_name=0)
df.columns = ['gene', 'p', 'q', 'lfc']
print('rows', len(df), '| unique genes', df.gene.nunique())
print('P<0.05:', int((df.p < 0.05).sum()), '| expected by chance at 5%:', round(0.05 * len(df), 1))
degenerate = np.isclose(df.p, 0.42265, atol=1e-5)
print('rows with P=0.42265 (single-sample detections):', int(degenerate.sum()), '| chance expectation excluding them:', round(0.05 * (~degenerate).sum(), 1))
up = (df.p < 0.05) & (df.lfc >= np.log2(1.2)); dn = (df.p < 0.05) & (df.lfc <= np.log2(0.83))
print('study screen (P<0.05 and fold>=1.2 or <=0.83, log2): up', int(up.sum()), 'down', int(dn.sum()))
print('Q<0.05:', int((df.q < 0.05).sum()), '| minimum Q:', round(float(df.q.min()), 3))
d = df.sort_values('p').reset_index(drop=True); d['rank_by_P'] = d.index + 1
print(d[d.gene.isin(['Stat5b', 'Stat5a', 'Jak2'])].to_string(index=False))
print(d.head(25).to_string(index=False))
