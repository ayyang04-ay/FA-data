import numpy as np
from scipy import stats
rng = np.random.default_rng(7)
def power(n, eff, sd, att, alpha, nsim=20000):
    y00=rng.normal(0,sd,(nsim,n)); y01=rng.normal(eff,sd,(nsim,n)); y10=rng.normal(0,sd,(nsim,n)); y11=rng.normal(eff*(1-att),sd,(nsim,n))
    est=(y11.mean(1)-y10.mean(1))-(y01.mean(1)-y00.mean(1))
    s2=(y00.var(1,ddof=1)+y01.var(1,ddof=1)+y10.var(1,ddof=1)+y11.var(1,ddof=1))/4
    t=est/np.sqrt(s2*4/n); p=2*stats.t.sf(np.abs(t),4*(n-1))
    return (p<alpha).mean()
for alpha in [0.05,0.025]:
    print('alpha',alpha)
    for eff,sd in [(1.3,0.6),(1.3,0.8),(1.65,0.6),(1.65,0.8),(1.65,0.5)]:
        for att in [1.0,0.7]:
            print(f'  eff x{2**eff:.1f} sd {sd} att {att:.0%}: ' + ', '.join(f'n={n}: {power(n,eff,sd,att,alpha):.2f}' for n in [8,10,12,14,16]))
