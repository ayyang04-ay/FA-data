from common import *
import statsmodels.formula.api as smf
print('=== Fig 7b human serum creatine (uM), n=11, paired by row? ===')
g=[col('Fig. 7b',c,4,14) for c in 'BCDE']
print([f'{np.mean(x):.1f}±{np.std(x,ddof=1):.1f}' for x in g])
for i,d in zip([1,2,3],[3,7,14]):
    tp = stats.ttest_rel(g[i],g[0]); w = stats.wilcoxon(g[i],g[0])
    print(f'  day {d} vs 0: mean diff {np.mean(g[i]-g[0]):.1f}, fold {np.mean(g[i])/np.mean(g[0]):.2f}, paired t P={tp.pvalue:.3g}, Wilcoxon P={w.pvalue:.3g}')
print('  mouse serum (Supp 1d): ', fmt(ttest(col('Supplementary Fig  1d','B',4,9), col('Supplementary Fig  1d','C',4,9),'mouse serum creatine')))
print('  mouse diet (Supp 1h): ', fmt(ttest(col('Supplementary Fig  1h','C',4,7), col('Supplementary Fig  1h','D',4,7),'mouse serum creatine, diet')))

print('=== Fig 7c human platelet function (fold vs day 0; n=11) ===')
blocks = [('Collagen','max aggregation',4),('Collagen','avg aggregation',18),('Collagen','adhesion',32),
          ('EPI','max aggregation',46),('EPI','avg aggregation',60),('EPI','adhesion',74),
          ('AA','max aggregation',88),('AA','avg aggregation',102),('AA','adhesion',116),
          ('ADP','max aggregation',130),('ADP','avg aggregation',144),('ADP','adhesion',157)]
rows=[]
for ag, met, r0 in blocks:
    g=[col('Fig. 7c',c,r0,r0+10) for c in 'BCDE']
    assert all(len(x)==11 for x in g), (ag,met,[len(x) for x in g])
    rec={'agonist':ag,'metric':met}
    for i,d in zip([1,2,3],[3,7,14]):
        x=g[i]
        rec[f'd{d}_mean']=np.mean(x); rec[f'd{d}_median']=np.median(x)
        rec[f'd{d}_n_up']=int(np.sum(x>1))
        # one-sample tests vs 1 (paired design; baseline normalised to 1)
        rec[f'd{d}_t_P']=stats.ttest_1samp(x,1).pvalue
        xl = np.log2(np.where(x<=0, np.nan, x))
        xl2 = xl[~np.isnan(xl)]
        rec[f'd{d}_geomean']=2**np.mean(xl2)
        rec[f'd{d}_logt_P']=stats.ttest_1samp(xl2,0).pvalue
        try:
            rec[f'd{d}_wilcoxon_P']=stats.wilcoxon(x-1).pvalue
        except Exception as e:
            rec[f'd{d}_wilcoxon_P']=np.nan
        # sign test
        k=int(np.sum(x>1)); n=int(np.sum(x!=1))
        rec[f'd{d}_sign_P']=stats.binomtest(k,n,0.5).pvalue
    rows.append(rec)
df=pd.DataFrame(rows)
pd.set_option('display.width',350); pd.set_option('display.max_columns',60)
print(df[['agonist','metric']+[c for c in df.columns if c.startswith('d14')]].round(4).to_string(index=False))
print(df[['agonist','metric']+[c for c in df.columns if c.startswith('d7')]].round(4).to_string(index=False))
print(df[['agonist','metric']+[c for c in df.columns if c.startswith('d3')]].round(4).to_string(index=False))
df.to_csv('fig7c_reanalysis.csv', index=False)
# reported Dunnett
ws = wb()['Fig. 7c']
print('reported Dunnett adj P (0 vs 3/7/14):')
for ag,met,r0 in blocks:
    # find rows with '0 vs. 14' near block
    out=[]
    for r in range(r0-2, r0+12):
        if ws[f'G{r}'].value in ('0 vs. 3','0 vs. 7','0 vs. 14'):
            out.append((ws[f'G{r}'].value, ws[f'L{r}'].value))
    print('  ',ag,met,out)
