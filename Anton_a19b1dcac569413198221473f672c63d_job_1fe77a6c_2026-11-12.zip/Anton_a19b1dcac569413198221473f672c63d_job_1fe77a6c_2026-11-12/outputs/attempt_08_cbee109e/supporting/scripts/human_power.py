from common import *
from scipy import stats
blocks = [('Collagen','max',4),('EPI','max',46),('AA','max',88),('ADP','max',130),('Collagen','adh',32),('EPI','adh',74)]
for ag,met,r0 in blocks:
    x = col('Fig. 7c','E',r0,r0+10); l=np.log2(x)
    m,s = l.mean(), l.std(ddof=1)
    ci = stats.t.interval(0.95, len(l)-1, loc=m, scale=s/np.sqrt(len(l)))
    print(f'{ag} {met} day14: mean log2FC={m:.2f} (geo-mean {2**m:.2f}x; 95% CI {2**ci[0]:.2f}-{2**ci[1]:.2f}x), SD(log2)={s:.2f}, d_z={m/s:.2f}')
def n_paired(d, power=0.8, alpha=0.05):
    from statsmodels.stats.power import TTestPower
    return TTestPower().solve_power(effect_size=d, power=power, alpha=alpha)
# placebo-controlled crossover: difference of two changes; assume placebo-period change has same SD and is independent -> SD_diff = sqrt(2)*SD
for name, m, s in [('Collagen max',1.33,1.17),('EPI max',0.70,0.63)]:
    for shrink in [1.0,0.75,0.5]:
        d = (m*shrink)/(np.sqrt(2)*s)
        print(f'{name}: assumed true effect {shrink:.0%} of observed -> d={d:.2f} -> n completers for 80% power={n_paired(d):.1f}; 90%={n_paired(d,0.9):.1f}')
