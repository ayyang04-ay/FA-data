from common import *
g=[col('Fig. 7b',c,4,14) for c in 'BCDE']
d14 = g[3]-g[0]; fold14 = g[3]/g[0]
blocks = [('Collagen','max',4),('Collagen','avg',18),('Collagen','adh',32),('EPI','max',46),('EPI','avg',60),('EPI','adh',74),('AA','max',88),('AA','avg',102),('AA','adh',116),('ADP','max',130),('ADP','avg',144),('ADP','adh',157)]
M={}
for ag,met,r0 in blocks:
    M[(ag,met)] = col('Fig. 7c','E',r0,r0+10)
df = pd.DataFrame({f'{a}_{m}':v for (a,m),v in M.items()})
df['cre_d0']=g[0]; df['cre_d14']=g[3]; df['cre_fold14']=fold14
pd.set_option('display.width',300)
print(df.round(2).to_string())
print('\nSpearman correlations of day-14 responses (max aggregation) across agonists (assumes rows = same volunteers):')
cols=['Collagen_max','EPI_max','AA_max','ADP_max','cre_d14','cre_fold14']
print(df[cols].corr(method='spearman').round(2).to_string())
# responders: number of volunteers with >=1.5x in max aggregation
for c in ['Collagen_max','EPI_max','AA_max','ADP_max']:
    print(c, '>=1.5x:', int((df[c]>=1.5).sum()), '/11 ; <1:', int((df[c]<1).sum()), '/11 ; range', df[c].min().round(2), df[c].max().round(2))
