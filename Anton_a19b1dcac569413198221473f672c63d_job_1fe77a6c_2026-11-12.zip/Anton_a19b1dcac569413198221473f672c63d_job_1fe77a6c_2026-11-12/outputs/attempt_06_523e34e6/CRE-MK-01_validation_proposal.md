**Recommendation: take megakaryocyte SLC6A8 — the transporter megakaryocytes use to load exogenous creatine — forward as the primary target, and spend next quarter's in vivo slot on a blinded, adequately powered repeat of its megakaryocyte-specific knock-out; megakaryocyte STAT5B is first backup and CKB second, each gated on a named missing experiment.**

*CRE-MK-01 follow-up validation proposal for the portfolio committee. Every number below was recomputed from the three supplied files (`CRE-MK-01_source_data.xlsx`, `CRE-MK-01_phosphoproteomics.xlsx`, `study_conventions.pdf`). No external dataset was used as evidence; the few places where I lean on general background are marked "external", and textbook pharmacology is used only to name pathways (aspirin and arachidonic acid, GP6 and collagen, P2RY12 and ADP).*

*Contents: 1 the decision · 2 the three nodes compared · 3 evidence and data problems · 4 follow-up studies · 5 what would change the ranking · 6 indications and populations · 7 derivation and files · Appendix A, every sheet.*

---

## 1. The decision in brief

**What we take forward.** One target hypothesis: megakaryocytes (MKs) that import extra creatine through SLC6A8 release platelets that help tumour cells seed the lung; stop the import and the extra metastasis goes away.

**Why SLC6A8 ranks first**

1. **It is the only node whose MK-specific loss was tested against metastasis.** In Pf4-Cre; Slc6a8 fl/fl mice (gene deleted in the megakaryocyte lineage), creatine no longer raised lung weight, metastatic burden or foci: burden went 2.4 → 7.9% in Cre-only controls but 3.4 → 2.9% in knock-outs (genotype × creatine interaction P = 0.0002, 0.0003, 0.004 for the three readouts; 4 mice per arm; Fig. 3i). Serum creatine rose in both genotypes (Fig. 3b).
2. **Every link between target and outcome was measured in the same knock-out line and moved the right way:** MK creatine loading (Fig. 3c), platelet aggregation (Fig. 3d; replicate caveats in section 3.8), platelet α-granules (Suppl. Fig. 4c) and the panel of 11 platelet-activation transcripts measured in MKs throughout the study (Fig. 3f). Delivering creatine past the transporter in liposomes switched the panel back on in knock-out MKs (×2.4; Suppl. Fig. 4e), so the transporter matters because it lets creatine in.
3. **It is the most selective lever in the package.** Knock-out alone left the MK transcript panel at baseline (×0.93). The STAT5 inhibitor alone and Ckb knock-down alone pushed it below baseline (×0.52 and ×0.70), i.e. they also act on normal MK biology. (Knock-out alone did lower basal platelet aggregation; section 3.3.)

**Why STAT5B is a backup and not the lead.** The MK-specific Stat5b knock-out was never tested for platelet function or metastasis, has no vehicle-treated knock-out arm, and left 5 of 11 panel genes 1.4–1.9× above baseline (Fig. 6g). The in vivo metastasis result (Fig. 6b) comes from STAT5-IN-1, which inhibits both STAT5A and STAT5B and was dosed systemically; it was read by unblinded histology only, and shares three of five animals in each control arm, value for value, with a different experiment (Suppl. Fig. 2d). The phosphoproteomic STAT5B hit does not survive multiple-testing correction (Q = 0.25; no peptide in the file reaches Q < 0.05).

**Why CKB (creatine kinase B) is second backup.** All CKB evidence is from cultured MKs: knock-down blocks the creatine response and over-expression mimics it (Figs. 4j, 4l). There are no in vivo, platelet-function or metastasis data.

**The risk that sits above the choice of node.** Nothing in the package shows that blocking any node helps a host that is not being given creatine: knock-out alone and inhibitor alone left metastasis unchanged (Fig. 3i, Fig. 6b). As the data stand, this is a target for creatine-exposed hosts, and it competes with two cheap alternatives — stopping creatine and taking aspirin. The proposed study carries both as comparators so the committee sees that answer at the same time.

**What the slot buys.** A 2 × 2 (genotype × creatine) of 64 mice that re-tests the primary under blinding, in both sexes; three comparator arms (48 mice) for creatine withdrawal and aspirin; a non-tumour satellite (48 mice) for platelet, megakaryocyte and bleeding readouts; and, if the slot can hold it, the matching Stat5b 2 × 2 (64 mice) so the first backup is tested on the same footing (section 4).

**How sure I am.** The ranking: fairly sure, because it follows from which experiments exist rather than from effect sizes. That SLC6A8 will hold up on repeat: moderately sure — it rests on one unblinded experiment with four mice per arm.

**Two things to settle before the meeting.** Ask the study team to reconcile the six animals whose values appear in both Fig. 6b and Suppl. Fig. 2d, and to supply the tumour-model key for each panel (section 3.8).

---

## 2. The three nodes side by side

The chain the package proposes, with what was measured at each step:

`serum creatine ↑ (×2.7–2.9)` → **SLC6A8** → `MK creatine ↑ (×3–5)` → **CKB** ↑ → **STAT5B** (serine-127 phosphorylation proposed) → `MK transcript panel ↑ (×3.1–5.3)` → `primed platelets (aggregation ↑, GP6 protein ↑)` → `lung metastatic burden ↑ (×3.2)`

"Panel" = the 11 MK transcripts measured throughout the study (Itga2b, P2ry12, Gp6, Gp1ba, F2r, Adra2a, Fcgr2a, Runx1, Rab4a, Rab27b, Pitpnb). "Panel fold" = geometric mean across the 11 genes of each gene's fold change against the control arm of the same experiment (n = 3 per arm).

| Evidence the decision needs | SLC6A8 (creatine import) | STAT5B (transcription factor) | CKB (creatine kinase B) |
|---|---|---|---|
| MK-specific loss removes creatine-driven **metastasis** in vivo | **Yes** — Fig. 3i, interaction P = 0.0003 (burden), 4 mice/arm, Cre-only controls | **Not tested** | **Not tested** |
| MK-specific loss removes creatine-driven **platelet hyper-reactivity** | **Yes** — Fig. 3d (3 values/arm; independence unclear, section 3.8), Suppl. Fig. 4c | **Not tested** (platelet indices only, Suppl. Fig. 7b) | **Not tested** |
| Loss blocks the creatine-induced **MK panel** | Yes, in vivo: ×3.3 → ×0.84 (Fig. 3f) | Partly, in vivo: ×3.6 → ×1.09, 5 genes still 1.4–1.9× (Fig. 6g); no knock-out + vehicle arm | Yes, in vitro only: ×3.7 → ×1.0 (Fig. 4j) |
| Gain of function / bypass | Liposomal creatine restores panel in knock-out MKs, ×2.4 (Suppl. Fig. 4e) | None on a functional readout | Over-expression alone ×2.5 (Fig. 4l) |
| Pharmacology on metastasis | None in package | Pan-STAT5A/B inhibitor, systemic (Fig. 6b, 5/arm) | None |
| Effect of blocking the node **without creatine** | Panel ×0.93 (unchanged); metastasis unchanged; basal aggregation lower (Fig. 3d) | Inhibitor: panel ×0.52; metastasis unchanged. Knock-out: unknown (arm missing) | Knock-down: panel ×0.70 |
| Human evidence for the node itself | None | None | None |
| Position | Entry point; upstream of everything measured | Downstream of uptake and of CKB (Figs. 6e, 6f) | Between uptake and STAT5B |
| Single most important gap | n = 4, unblinded, one model, sex not analysed; no inhibitor tested | No platelet or metastasis readout in the MK knock-out | No in vivo data at all |

The ranking uses evidence only. Tractability (chemical matter, modality, selectivity over related proteins) is not addressed anywhere in the package and should be assessed separately before any node is promoted.

![Megakaryocyte-lineage Slc6a8 knock-out](figures/Fig1_MK_Slc6a8_knockout.png)

---

## 3. Evidence, with source and derivation

Citations give the sheet (as "Fig." / "Suppl. Fig.") and cell range in `CRE-MK-01_source_data.xlsx`. "Recomputed" means my own test on those cells; table numbers (T1–T8) refer to the CSV files listed in section 7. Unless stated, n is mice per arm. All animal work was randomised but **not blinded at any stage ("not masked" in the conventions file), with no sample-size calculation and no analysis by sex**.

### 3.1 The phenomenon: creatine increases lung metastasis

| Observation | Source (cells; n) | Result (recomputed) |
|---|---|---|
| Lung metastatic burden rises in every intact-host experiment | 11 experiments: Fig. 1b, 1f (both tumour lines), 1k, 3i (controls), 6b (no inhibitor), Suppl. Fig. 1e, 1f, 1g, 1i, 1k; n = 4–10 | Creatine/vehicle ratio ×2.1 to ×4.0 in each (every P < 0.01). Random-effects pooled ratio **×3.16 (95% CI 2.68–3.73)**; foci ×2.04 (1.77–2.36) (T2, T2b) |
| Same with creatine in the diet | Suppl. Fig. 1i (B11:C14; n = 4) | Burden 7.3 → 26.2% (P = 0.005) |
| Survival is shorter | Fig. 1c (n = 10/10); Fig. 1l (n = 20/18) | Median 22 → 19 days (log-rank P = 0.032); 16 → 14 days (P = 0.011) |
| The difference appears within hours of tumour-cell arrival | Fig. 1h (B4:M7; n = 6; the measured variable is not named in the sheet) | No difference at 15 min (P = 0.31); ×1.5, ×1.8, ×2.8 more signal with creatine at 6, 12, 24 h (P = 0.0002, 0.026, 0.004) |
| Exposure achieved | Suppl. Fig. 1d (n = 6); Suppl. Fig. 1h (n = 4); Fig. 3b (n = 5) | Serum creatine 66 → 179 µM (gavage); 78 → 227 µM (5% diet); 89 → 239 µM |
| Not explained by intake, body weight, blood counts or platelet number | Suppl. Fig. 1a–c, 3a; Fig. 2a | Body weight, food, water, leukocyte and red-cell counts, platelet count and indices unchanged (all P ≥ 0.08) |

Derivation: each experiment's ratio and CI were computed on log-transformed values; pooling used the DerSimonian–Laird method. The comparisons behind this table all reproduce the P values embedded in the workbook (T1).

What it does not tell us: which tumour models these are. Only Fig. 1f is labelled ("Melanoma"); the conventions file lists male C57BL/6J and female BALB/cJ mice but no model key.

### 3.2 The effect travels with platelets and is set in megakaryocytes

| Observation | Source | Result | Caveat |
|---|---|---|---|
| Platelets from creatine-fed mice transfer the effect to recipients | Suppl. Fig. 2d (C5:D10; n = 6) | Burden 5.9 → 17.9% (geometric-mean ratio ×3.3, 95% CI 1.8–5.8) | Rows 4–6 of both arms equal Fig. 6b rows (section 3.8); rows 1–3 alone: 8.4 → 23.0%, P = 0.006 |
| Platelets from volunteers after 7 days of creatine do the same in mice | Fig. 7g (n = 5 recipients) | Burden 4.6 → 12.7% (P = 0.014); foci 21.8 → 39.4; lung weight 0.186 → 0.236 g | Human platelets in mice; no placebo-donor control; donor number not given |
| Platelets are more reactive, not more numerous | Fig. 2b (n = 3); 2c (8 fields); 2d (n = 5) | Aggregation: ADP 42 → 57, collagen 66 → 79, thrombin 25 → 56 (P = 0.0003–0.0011). α-granule count 2.0 → 3.9. Thromboelastography: only maximum amplitude moves (39.7 → 54.0, P = 0.049) | In every aggregation group the third value is exactly the mean of the other two, so there are two measurements per arm (P = 0.02–0.04 on those; section 3.8); α-granule n is fields, not mice |
| GP6 and P2RY12 protein are higher in platelets and MKs | Fig. 2e, 2g (blot images, 3 + 3 lanes) | Bands stronger with creatine by eye — clearly in MKs, modestly in platelets | Images only; no densitometry in workbook |
| The MK transcript panel rises about three-fold | Fig. 2f, 3f, 4h, 4j, 6a, 6g (creatine arms) | Panel fold ×3.1, 3.3, 3.3, 3.7, 5.3, 3.6; 11 of 11 genes up in all six (T4b) | n = 3 each |
| Creatine acts on MKs, not on circulating platelets | Fig. 2i (blot image) | 0.2 and 2 mM creatine raise GP6/P2RY12 in cultured MKs; no change in platelets treated directly | Single lanes |
| Tumour-cell SLC6A8 is not required | Fig. 1f (B4:E36; n = 6) | Creatine effect unchanged by tumour-cell Slc6a8 knock-down (interaction P = 0.21–0.95 across four endpoints; T3) | Knock-down is 81% at mRNA (Suppl. Fig. 2a) but the protein band is only partly reduced in the blot — roughly 40% by my crude densitometry of the embedded image |

![MK transcript panel across all perturbations](figures/Fig3_MK_gene_panel_heatmap.png)

### 3.3 Primary: SLC6A8 in the megakaryocyte lineage

All rows compare Pf4-Cre; Slc6a8+/+ ("Cre control") with Pf4-Cre; Slc6a8 fl/fl ("knock-out"), each ± creatine. Interaction P is from a two-way ANOVA I ran on the four arms (T3); the workbook itself reports only pairwise Tukey tests, which all reproduce (T1).

| Readout (sheet; n per arm) | Cre control, vehicle | Cre control, creatine | Knock-out, vehicle | Knock-out, creatine | Interaction P |
|---|---|---|---|---|---|
| Serum creatine, µM (Fig. 3b; 5) | 88.6 | 239.3 | 89.1 | 217.7 | 0.18 |
| MK intracellular creatine, µmol/g (Fig. 3c; 3) | 13.7 | 72.1 | 13.7 | 21.1 | 0.045 (0.065 on the log scale) |
| Platelet aggregation, ADP (Fig. 3d; 3) | 63.3 | 70.7 | 54.0 | 31.3 | < 0.0001 |
| Platelet aggregation, collagen (Fig. 3d; 3) | 64.7 | 76.7 | 60.7 | 50.7 | < 0.0001 |
| Platelet aggregation, thrombin (Fig. 3d; 3) | 61.3 | 74.7 | 45.3 | 35.3 | < 0.0001 |
| Platelet α-granules (Suppl. Fig. 4c; 8 fields) | 2.6 | 5.1 | 2.3 | 2.3 | 0.006 |
| Platelet count, ×10⁹/L (Suppl. Fig. 4b; 3) | 890 | 909 | 1042 | 992 | 0.73 |
| MK panel fold (Fig. 3f; 3) | 1 | 3.30 | 0.93 | 0.84 | — |
| **Lung weight, g (Fig. 3i; 4)** | 0.206 | 0.249 | 0.222 | 0.225 | **0.0002** |
| **Metastatic burden, % (Fig. 3i; 4)** | 2.36 | 7.91 | 3.39 | 2.88 | **0.0003** |
| **Metastatic foci (Fig. 3i; 4)** | 29.8 | 56.5 | 26.5 | 24.8 | **0.004** |

What this supports

- **Necessity, in the right lineage, for the endpoint that matters.** The knock-out removed 93% of the creatine increment in lung weight and all of it in burden and foci. Lung weight is the one metastasis readout here that does not rest on a reader's judgement, and it agrees. Creatine-treated knock-outs are completely separated from creatine-treated controls on all three readouts. With four mice per arm an exact rank test cannot go below P = 0.029, and each of these contrasts sits at that floor (T3c); the smaller parametric P values lean on distributional assumptions that four values cannot check.
- **The block is at uptake.** Serum creatine still rose in knock-out mice, MK creatine did not, and liposomal creatine restored the panel in knock-out MKs in vitro (×2.35, 10 of 11 genes up) where free creatine did not (×0.89) (Suppl. Fig. 4e).
- **Selectivity for the creatine-induced state.** Knock-out alone did not change the panel (×0.93), platelet count, α-granules or metastasis.

What weakens it — to be designed out in the next study

- **Thin and unblinded:** one experiment, four mice per arm, one (unnamed) model, sex not analysed.
- **Lineage restriction is assumed, not shown:** the conventions file states that Pf4-driven Cre is active in the megakaryocyte lineage; the package has no check for recombination elsewhere. The platelet-transfer test in section 4 would close this.
- **Deletion looks incomplete:** the SLC6A8 band in knock-out MKs is reduced, not absent (Suppl. Fig. 4a image, one lane per genotype), and MK creatine still drifts up with creatine in the knock-out (13.7 → 21.1; P = 0.20).
- **Knock-out alone lowered platelet aggregation** (ADP 54 vs 63, thrombin 45 vs 61, collagen 61 vs 65; Tukey P = 0.0002, < 0.0001, 0.012). This is either an on-target antiplatelet effect or a bleeding liability; no bleeding data exist.
- **In the knock-out, creatine lowered aggregation further** (ADP −23, collagen −10, thrombin −10) and suppressed some transcripts (Pitpnb ×0.37, Runx1 ×0.50). Creatine therefore has an SLC6A8-independent, inhibitory effect on this lineage that nobody has explained.
- **The aggregation replicates may not be independent.** In Fig. 3d the three values agree within 2 units in 11 of 12 groups, much tighter than the wild-type data of Fig. 2b, and the n unit is not stated. Treat the aggregation P values as nominal (section 3.8).
- **Not every panel gene depends on SLC6A8:** Fcgr2a stayed high in the knock-out with or without creatine (×2.0, ×3.3).
- **No benefit without creatine:** knock-out vehicle vs control vehicle burden ratio ×1.53 (95% CI 0.84–2.76); lung weight slightly higher (0.222 vs 0.206 g).
- **No inhibitor has been tested.** Tractability and safety are outside this package. One in-package pointer: brain creatine and phosphocreatine also rose with supplementation (Fig. 4a, 4c), so brain tissue draws on circulating creatine too and a systemic blocker would need to be watched there.

### 3.4 First backup: STAT5B

| Evidence | Source | Result (recomputed) | What it does not show |
|---|---|---|---|
| Phosphoproteomics, MKs ± creatine | phosphoproteomics file; 3 mice/group; 5,812 phosphopeptide rows | One of two STAT5B peptides: log2 fold +5.70, P = 0.0012, 17th smallest P. **Q = 0.246.** No row has Q < 0.05 (minimum 0.167). A change of that size (×52) is typical of a peptide detected in one group and not the other; 71 peptides show such a change at P < 0.05, 33 up and 38 down. Overall 5.8% of the 4,110 informative rows have P < 0.05, against 5% expected if nothing changed (T6) | Not significant after correction, and not unusual among present/absent calls. The file has gene names only, so the S127 site cannot be checked |
| Canonical activation | Suppl. Fig. 6a (image) | No Y694/699 phospho-STAT5 signal in MKs ± creatine; IL-2-treated Jurkat control positive | Creatine does not switch on the classical tyrosine-phosphorylation route; how STAT5-IN-1 then blocks the creatine response is not addressed in the package |
| S127 dependence | Fig. 5e, 5f (N4:Q19; 3 blots each) | Creatine raises pan-phospho/FLAG on wild-type STAT5B ×1.39 (P = 0.009) and ×1.28 (P = 0.087); not on S127A (interaction P = 0.024, 0.043; T3) | Pan-phospho antibody on over-expressed protein; S127D also reads higher than wild type without creatine (×1.3–1.5), which is unexpected for a phospho-antibody and suggests the mutation changes phosphorylation elsewhere on the protein; cell system not stated for these sheets; the site itself was never measured |
| CKB → STAT5B | Fig. 5g, 5h, 5i; Suppl. Fig. 6d, 6h (images) | Single blots, read by eye. 5g: CKB over-expression strengthens the pan-phospho band on wild type; weak on S127A. 5h: creatine raises the nuclear signal with control siRNA — on S127A as well as wild type — and not with si-CKB. 5i: not readable. S6d: recombinant CKB + ATP strengthens the band. S6h: more nuclear STAT5B with creatine | One image each, unquantified; S127 dependence is not consistent across them; the in vitro kinase blot has no kinase-dead or no-ATP lane |
| Promoter occupancy (ChIP) | Fig. 5j; Suppl. Fig. 6i (3/arm) | With creatine, % input rises 2.7–12× at seven of the nine promoter amplicons of P2ry12, Gp6 and Rab4a; exon amplicons unchanged | The antibody is not named in the workbook; the primer table gives the same forward primer for the Rab4a −1 kb and −2 kb amplicons |
| Pan-STAT5 inhibitor, MK panel | Fig. 6a (3/arm) | Creatine ×5.3 → ×0.57 with STAT5-IN-1; **inhibitor alone ×0.52** (10 of 11 genes down) | Lowers the basal programme; inhibits STAT5A and STAT5B (conventions file) |
| Pan-STAT5 inhibitor, metastasis | Fig. 6b (B4:E17; 5/arm) | Burden 3.4 → 13.9% without, 3.6 → 4.5% with inhibitor (interaction P < 0.0001); foci 30 → 58 vs 30 → 27. Creatine-treated animals with and without inhibitor are completely separated (exact rank P = 0.008; T3c) | Systemic, not MK-specific; histology endpoints only; 3 of 5 animals in each no-inhibitor arm duplicate Suppl. Fig. 2d. Without them the interaction holds (P = 0.0003) but on 2 animals per arm |
| MK-specific Stat5b knock-out | Fig. 6d–6g (3/arm) | STAT5B absent on blot; MK creatine uptake intact (95 vs 98 µmol/g); panel ×3.6 in wild type vs ×1.09 in knock-out + creatine | **No knock-out + vehicle arm**; comparator is "WT", not Cre-only; residual induction of P2ry12 ×1.9, Adra2a ×1.9, Gp1ba ×1.6, F2r ×1.6, Gp6 ×1.4; **no platelet function, no metastasis** |
| Platelet indices | Suppl. Fig. 7a, 7b (3/arm) | Unchanged; plateletcrit lower in knock-out + creatine (0.26 vs 0.36, Tukey P = 0.055) | n = 3 |

Reading: STAT5B is a plausible transcriptional effector, downstream of uptake (Fig. 6e) and of CKB induction (Fig. 6f image). But because the knock-out + vehicle arm is missing, the data cannot separate "STAT5B carries the creatine signal" from "STAT5B sets the baseline of these genes" — and the inhibitor-alone result (×0.52) shows that STAT5 activity, A or B, does set that baseline. STAT5B has not been tested against platelet function or metastasis in any MK-specific way.

![STAT5 inhibitor and aspirin donor-platelet experiments](figures/Fig2_STAT5_inhibitor_and_aspirin.png)

### 3.5 Second backup: CKB

| Evidence | Source (n = 3 unless stated) | Result (recomputed) | What it does not show |
|---|---|---|---|
| Creatine induces CKB in MKs | Fig. 4e; Fig. 4b, 4g, 6f (images) | Ckb mRNA ×1.82 (P = 0.011); CKB band stronger, including in Stat5b-knock-out MKs | Single-lane images |
| Knock-down blocks the creatine response | Fig. 4j | Panel ×3.7 → ×1.0; knock-down alone ×0.70 (11 of 11 genes down) | In vitro; number of knock-down reagents not stated; lowers baseline |
| Over-expression mimics creatine | Fig. 4l; Suppl. Fig. 5c | Panel ×2.5 with no change in MK creatine (33.7 vs 32.7 µmol/g) or phosphocreatine (P = 0.16) | In vitro |
| Phosphocreatine is not the messenger | Fig. 4h | Added phosphocreatine: panel ×0.63 (creatine ×3.3 in the same experiment) | Uptake of added phosphocreatine was not measured |
| Creatine and phosphocreatine load into MKs | Fig. 4a, 4c, 4d, 4f | MK creatine ×3.0, phosphocreatine ×3.9 in vivo; brain ×1.2 and ×2.0 | — |
| Synthesis enzymes unchanged | Suppl. Fig. 5a | Gatm, Gamt mRNA unchanged (P = 0.37, 0.61) | — |

Reading: CKB has both knock-down and over-expression evidence, but all of it is in culture, on transcripts and single blots. Whether MK CKB is needed for platelet hyper-reactivity or metastasis is unknown.

### 3.6 Aspirin and the platelet receptors: comparators and biomarkers, not targets yet

- **Aspirin** (Suppl. Fig. 2d, C5:E19; 6/arm). Platelets from creatine + aspirin donors did not raise recipient burden (4.4% vs 17.9% from creatine donors; 5.9% from vehicle donors; Tukey P = 0.0001). There is **no aspirin-alone arm**, so this shows that creatine-conditioned platelets need an aspirin-sensitive step, not that aspirin acts on the creatine axis. The result holds in rows 1–3 alone (n = 3/arm, P = 0.002; T3b). The two halves of the sheet differ (vehicle 8.4 vs 3.3%, P = 0.008), which fits two batches.
- **GP6 and P2RY12** were never perturbed, so they are readouts. GP6 is the better-supported one across species: transcript and protein rise in mouse, collagen aggregation rises in mouse and human, and platelet GP6 protein rises in all four volunteers tested (section 3.7). ADP aggregation, the P2RY12 readout, did not change in volunteers, and the arachidonic-acid pathway that aspirin blocks barely moved (×1.13). If a qualified collagen-pathway (GP6) blocking reagent is available, it is worth one exploratory arm in Study 1 for that reason.

### 3.7 Healthy volunteers: the phenomenon translates; no target is tested

Eleven healthy volunteers aged 20–25 took 20 g/day creatine for 14 days; no placebo arm; each subject is their own day-0 control (conventions file). On a mg/kg basis this equals the mouse gavage regimen (both ≈ 0.35 g/kg/day) and gives a similar serum level.

| Observation | Source (n) | Result (recomputed) |
|---|---|---|
| Exposure | Fig. 7b (11) | Serum creatine 45 → 153, 156, 159 µM at days 3, 7, 14 (×3.4–3.5); plateau by day 3 |
| Platelet count, indices, BMI | Suppl. Fig. 8a, 8b (11) | Unchanged |
| Collagen-induced maximal aggregation | Fig. 7c (C4:E14; 11) | Day 14: median ×2.25, 9 of 11 up, Wilcoxon P = 0.005 (Holm-adjusted over 12 endpoints 0.044). Days 3 and 7: not significant (day 7 ×1.14, P = 0.10) |
| Epinephrine-induced | Fig. 7c (C46:E56; 11) | Day 7: ×1.21, 10 of 11 up (P = 0.005). Day 14: ×1.40, 10 of 11 up (P = 0.002; Holm 0.020) |
| Arachidonic-acid-induced | Fig. 7c (C88:E98; 11) | Day 14: ×1.13 (P = 0.042; Holm 0.21) |
| ADP-induced | Fig. 7c (C130:E140; 11) | Day 14: ×1.02, 6 of 11 up (P = 0.46) |
| Platelet GP6 protein (immunoblot) | Fig. 7e (B4:E7; 4) | ×2.6 at day 14; up in 4 of 4 (paired P = 0.02) |
| Platelet P2RY12 protein (immunoblot) | Fig. 7e (B12:E15; 4) | ×1.65 at day 14; up in 4 of 4 (paired P = 0.025) |
| Circulating CD41+ cell transcripts | Fig. 7d (4) | Peak at day 7: ADRA2A ×21 (4 of 4), GP1BA ×10, F2R ×6.5, GP6 ×6.4, P2RY12 ×3.1. One volunteer shows no induction for most genes. **RAB4A falls** to ×0.38 at day 14 in 4 of 4 — opposite to mouse |

Derivation: the workbook analysed these ratios as unpaired groups with Dunnett's test (reproduced, T1). Because every subject is 1.0 at day 0 and some ratios are extreme (up to ×40), I re-tested each endpoint against 1.0 with a Wilcoxon signed-rank test and Holm-adjusted within each day (T5). Fig. 7e is protein, not transcript; Fig. 7d is circulating CD41+ cells, not marrow MKs; both used 4 of the 11 volunteers.

Which readouts move the same way in both species — this sets the biomarkers for Studies 1 and 4:

| Readout | Mouse (creatine vs vehicle) | Volunteers (vs own day 0) | Carries across? |
|---|---|---|---|
| Serum creatine | ×2.7–2.9 | ×3.4–3.5 | Yes |
| Platelet count | Unchanged (Fig. 2a) | Unchanged (Suppl. Fig. 8b) | Yes |
| Collagen-induced aggregation | 66 → 79 (Fig. 2b) | ×2.25 at day 14 | **Yes** |
| Platelet GP6 protein | Modestly stronger band (Fig. 2e image) | ×2.6 at day 14, 4 of 4 | **Yes** |
| ADP-induced aggregation | 42 → 57 (Fig. 2b) | ×1.02, no change | No |
| Platelet P2RY12 protein | Modestly stronger band (Fig. 2e image) | ×1.65 at day 14, 4 of 4 | Partly (protein without function) |
| Epinephrine-induced aggregation | Not measured | ×1.40 at day 14 | Unknown |
| Rab4a / RAB4A transcript | ×2.6–4.3 in MKs | ×0.38 in CD41+ cells at day 14 | No (opposite) |

Reading: 20 g/day primes human platelets after one to two weeks, on the collagen and epinephrine pathways. The lag behind serum creatine fits an effect made in MKs and delivered by new platelets. Nothing here tests SLC6A8, CKB or STAT5B in humans, and nothing tests lower doses.

![Healthy-volunteer cohort](figures/Fig4_healthy_volunteer_cohort.png)

### 3.8 Data problems found, and what each does to the ranking

I recomputed all 232 statistical results embedded in the workbook (71 t-tests, 99 Tukey, 48 Dunnett, 12 Šidák comparisons, 2 log-rank tests); **all 232 reproduce from the raw cells** (T1). The problems below are of other kinds.

| # | Problem | Where | Effect on the decision | Action before committee |
|---|---|---|---|---|
| 1 | Three vehicle and three creatine animals have identical burden (7 significant figures) and foci values in two nominally different experiments | Fig. 6b B5:C7, B14:C16 = Suppl. Fig. 2d C8:D10, C17:D19 (T7) | Weakens the STAT5-inhibitor and aspirin results: each has only 2–3 unique animals per control arm, or shares controls across designs | Reconcile against animal IDs |
| 2 | Aggregation replicates are not independent. Wild type: in all six groups the third value is exactly the mean of the first two (chance below 1 in a million). Knock-out experiment: 11 of 12 groups are two identical values plus one 2 units away | Fig. 2b B4:G6; Fig. 3d B4:M6 (T7b) | Platelet hyper-reactivity links MK to metastasis for every node; it rests on two measurements per arm in wild type (P = 0.02–0.04 rather than ≤ 0.001) and possibly one sample per arm in the knock-out experiment. Direction unaffected | Obtain per-animal aggregation records; Study 1 measures aggregation per animal |
| 3 | Stat5b knock-out experiments lack a knock-out + vehicle arm and a Cre-only control | Fig. 6e, 6g; Suppl. Fig. 7b | Cannot tell a creatine-specific block from a lower baseline | Add both arms (section 4, module 2) |
| 4 | n is microscope fields, not animals | Fig. 1i, 2c, 2j; Suppl. Fig. 4c (conventions file) | P values for seeding and α-granules are overstated; direction unaffected | Re-report per animal |
| 5 | Two volunteer columns do not reproduce from their own ΔCT rows | Fig. 7d, Volunteer 4: RAB27B (sheet 2.5/4.4/2.4; recomputed 4.0/5.7/0.49) and PITPNB (ΔCT entries +26 to +28, against −1.6 to −10 in the other three volunteers) (T5d) | Human transcript evidence for those two genes is unverified | Recover raw CT values |
| 6 | Phosphoproteomics was screened at nominal P < 0.05 with no false-discovery control. 1,702 of 5,812 rows share P = 0.42265 (t = 1 on 2 d.f.: a peptide seen in one replicate), which the stated unpaired Student's test on 3 vs 3 (4 d.f.) would not give | phosphoproteomics file (T6) | STAT5B is a lead from this file, not a finding | Re-run with more replicates, site-level output, false-discovery control |
| 7 | Identity gaps: tumour model per panel; ChIP antibody; cell system for Fig. 5e/5f and 3g; creatine concentration in each in vitro panel (0.2 or 2 mM; 2 mM is about 10× the in vivo serum level); Fig. 4d is labelled "Creatinine"; tumour knock-down is labelled both "si-" and "sh-". Completeness gaps: primers are listed for Plcg1 and Orai1 (mouse and human) but the workbook has no data for them; the volunteers' coagulation tests are mentioned but absent | workbook labels, conventions file | Limits indication scoping and interpretation of in vitro panels; two panel genes and one clinical readout may be unreported | Obtain from study records |
| 8 | Blot loading controls were run on different gels from their targets (conventions file), and most groups are n = 3–6, too few for the normality test the conventions file cites | Fig. 5e, 5f, 7e and all small-n tests | Densitometry ratios carry gel-to-gel error; P values from n = 3 are approximate | Same-membrane controls and adequate n in follow-up work |
| 9 | Two pairs of replicate ΔCT values identical to 16 digits; separately, 4 of 22 replicate triplets in the CKB over-expression panel contain a value equal to the mean of the other two (about 0.5 expected by chance) | Fig. 3f K19 = M19, O39 = Q39; Fig. 4l (T7c) | Minor; the second touches the only gain-of-function evidence for CKB | Check against instrument exports |
| 10 | Survival groups unequal (20 vs 18) with no censoring recorded | Fig. 1l | Minor | Account for the two animals |

---

## 4. Follow-up studies

### Study 1 — the in vivo slot: megakaryocyte SLC6A8, confirm and extend

**Questions.** (a) Does MK-lineage Slc6a8 loss remove the creatine effect when the experiment is blinded, powered and run in both sexes? (b) Does it do anything in mice not given creatine? (c) Is it better than stopping creatine, or than aspirin?

| Element | Specification |
|---|---|
| Population | Pf4-Cre; Slc6a8 fl/fl vs Pf4-Cre; Slc6a8+/+ littermates (the control genotype of Fig. 3). Both sexes, sex as a blocking factor. (External note for the breeding plan: Slc6a8 is X-linked by public annotation, so males are hemizygous; the workbook labels all knock-outs "flox/flox".) |
| Indication model | The melanoma lung-metastasis model of Fig. 1f (confirm against the model key that Fig. 3i used it) |
| Exposure | The study's oral regimen (42.5 mg/mL, 400 µL, three times a week) vs water, with the same timing relative to tumour challenge as the source protocol (not recorded in the workbook) |
| Core arms | 2 × 2, genotype × creatine; **16 mice per arm (8 per sex), 64 mice** |
| Comparator arms (Cre-control mice, 16 each; module 1) | (i) creatine, then withdrawal before tumour challenge, long enough for the platelet pool to turn over (duration set from the satellite readouts); (ii) creatine + aspirin 30 mg/kg/day dosed directly to the tumour-bearing mouse; (iii) vehicle + aspirin — the aspirin-alone control missing from Suppl. Fig. 2d |
| Primary endpoint | Lung metastatic burden (% area), read blind, analysed on the log scale. Primary test: genotype × creatine interaction |
| Key secondary endpoints | Lung weight; foci count; PET SUV-BW if available (as Fig. 1a, 1f, 1j); tumour-cell lung retention at 6–24 h in an optional early-readout group (as Fig. 1h, 1i) |
| Target-engagement and platelet readouts (per animal, at termination) | Serum creatine; MK intracellular creatine; SLC6A8 protein in MKs (deletion efficiency); platelet aggregation to collagen (lead), ADP, thrombin; platelet GP6 and P2RY12 protein, quantified; MK panel — each linked to that animal's burden |
| Non-tumour satellite (8 per arm: 32 mice for the four core arms, 16 for two lower creatine doses in Cre controls) | The same readouts without a tumour, plus bleeding time. The lower doses find the serum level at which MK loading and platelet priming begin; the package cannot say, because the 5% diet delivers roughly 20 times the gavage dose yet gives the same serum level (227 vs 179–239 µM) and the same effect |
| Safety readouts | Platelet count and indices; bleeding time (satellite); blood counts; body weight |
| Size | With SD of log burden 0.35 (median within-group SD in the package is 0.28) and a ×3.16 creatine effect in controls, 16 per arm gives 90% power for the interaction if creatine raises burden by ×1.8 or less in knock-outs (half the effect removed on the log scale), and 81% power to see a 30% lower burden from knock-out alone. If the SD is nearer 0.5 these fall to 62% and 51%; review after the first cohort and extend to 24 per arm if needed (T8) |
| Conduct | Randomise within litter and cage; conceal allocation; blind all readers; the mouse is the unit for every readout, including microscopy; fix the analysis plan in advance; report every animal entered |
| Feasibility assumption | The colony can supply 32 knock-out and 32 Cre-control mice, plus satellites, within the quarter. If not, run one sex as the first cohort and the other as a replicate cohort rather than cutting group size |
| Priority if the slot is smaller | Core 2 × 2 (64) → withdrawal and aspirin arms (48) → non-tumour satellite (48) → Stat5b 2 × 2, module 2 (64) → early-readout group |

**Decision rule, proposed for ratification**

- *Confirmed:* interaction P < 0.05; in knock-outs creatine raises burden by no more than about a third (×1.33, i.e. at least 75% of the log-fold effect removed) and the 95% interval excludes ×1.8; same direction in lung weight and in each sex.
- *Not confirmed:* creatine still raises burden ×1.8 or more in knock-outs, or the block appears in one sex only. SLC6A8 is demoted.
- *In between:* report as partial; extend before deciding.
- *Read-outs that change the programme, not the node:* see section 5.

**Module 2 — same slot if it can hold another 64 mice; otherwise the first call on the following slot.** Pf4-iCre; Stat5b fl/fl vs Pf4-iCre; Stat5b+/+ × creatine vs vehicle, 16 per arm, same model, same blinded readers, same endpoints and satellite readouts. This supplies the two arms (Cre-only control; knock-out + vehicle) and the two readouts (platelet function; metastasis) that STAT5B lacks, and puts primary and backup on the same footing. If the slot holds only one 2 × 2, I would still run SLC6A8 first: the inhibitor qualification and the human-cell bridge both depend on the primary being real, whereas a positive Stat5b result would not by itself change what we do next.

**What I would not spend slot capacity on.** Repeating STAT5-IN-1. Whatever it shows, it cannot distinguish STAT5A from STAT5B or MKs from any other cell.

**If Study 1 confirms — next in line.** A spontaneous-metastasis model (primary tumour, resection, later lung readout) and a second tumour type from the Suppl. Fig. 1 series; qualification of an SLC6A8 tool inhibitor by MK creatine loading before any efficacy claim; and a platelet-transfer test (platelets from creatine-fed knock-out vs control donors into wild-type recipients) to pin the effect on the platelet compartment.

### Study 2 — STAT5B gate (cell and ex vivo work; no slot needed)

| Question | Design | Readout |
|---|---|---|
| Is S127 really phosphorylated in MKs in response to creatine? | MKs from vehicle- and creatine-dosed Cre-control, Slc6a8-knock-out and Stat5b-knock-out mice; site-resolved measurement | pS127 occupancy, reported with the site, per animal |
| Is S127 required for the programme? | Stat5b-null MKs re-expressing wild-type vs S127A STAT5B, ± creatine | MK panel; GP6 protein |
| Is the phosphoproteomic hit real? | Repeat with more animals per group; site-level table; false-discovery control stated in advance | Q value for STAT5B sites |
| Does STAT5A cover for STAT5B? | Stat5a expression and phosphorylation in Stat5b-knock-out MKs ± creatine | Explains, or not, the residual 1.4–1.9× induction |

### Study 3 — CKB gate (cell work; in vivo only if it passes)

Two independent knock-down reagents with rescue by wild-type vs catalytically inactive CKB, on the MK panel and GP6 protein, at 0.2 mM creatine. Go to an MK-restricted in vivo loss-of-function (2 × 2 as in Study 1) only if rescue needs catalytic activity.

### Study 4 — human pharmacodynamic study

| Element | Specification |
|---|---|
| Design | Randomised, double-blind, placebo-controlled, parallel groups |
| Population | Healthy adults, both sexes, wider in age and ancestry than CRE-MK-01 (which enrolled 11 Asian volunteers aged 20–25, mean BMI 20.9, no NSAID use); no antiplatelet or NSAID use; no creatine supplements beforehand; no history of cancer or thrombosis, given what the study is testing; usual diet recorded |
| Arms | Placebo; creatine 20 g/day (the CRE-MK-01 dose); creatine at a maintenance dose (3–5 g/day is the usual figure — external; not tested in our data) |
| Duration | 14 days on treatment, then follow-up after stopping until readouts return to baseline |
| Primary endpoint | Change from baseline to day 14 in collagen-induced maximal platelet aggregation, 20 g/day vs placebo |
| Key secondary | Epinephrine-induced aggregation; platelet GP6 protein; ADP- and arachidonic-acid-induced aggregation; serum creatine (exposure–response across all subjects); time to return to baseline |
| Exploratory | CD41+ cell transcripts (GP6, ADRA2A, ITGA2B, P2RY12 — not RAB4A, which moved the wrong way); platelet transfer into mice with placebo-subject platelets as the control the original lacked |
| Size | About 18 per arm gives 90% power for the day-14 collagen effect seen in CRE-MK-01 (mean log2 change 1.33, SD 1.17); I propose 24 per arm. The low-dose arm is for estimation: 80% power for half that effect would need about 50 per arm |
| Indication | None; this is a pharmacodynamic and safety-signal study. It also tells us which creatine users are relevant |

A cell-based bridge should run alongside: human MKs in culture at creatine concentrations spanning fasting to supplemented serum (about 0.05 to 0.2 mM) with and without SLC6A8 knock-down, reading intracellular creatine and GP6. That is the first direct test of the primary target in human cells.

---

## 5. What would move one choice above another

| If we learn that… | Then |
|---|---|
| Study 1 confirms (rule above) | SLC6A8 stays primary; open tool-inhibitor qualification |
| Study 1 does not confirm | SLC6A8 is demoted. STAT5B becomes primary only if its own 2 × 2 is positive; otherwise no node is validated |
| Knock-out alone lowers burden, or lowers platelet reactivity without prolonging bleeding | The target matters without supplementation; the indication widens and the programme's value rises |
| Withdrawal returns platelets and burden to vehicle level, **and** knock-out alone does nothing, **and** maintenance-dose volunteers show no platelet change | The finding is advice about creatine, not a drug target. Recommend stopping the target programme whichever node leads |
| Aspirin dosed directly removes the creatine increment and aspirin alone is neutral | Aspirin becomes the benchmark any new agent has to beat on efficacy and bleeding |
| Stat5b 2 × 2 meets the same rule as Study 1, normalises platelet function, and knock-out + vehicle is neutral on counts and bleeding | STAT5B becomes a strong backup, at the tier SLC6A8 holds today |
| …and Study 2 shows pS127 is a creatine-specific switch (measured directly; S127A fails to rescue) while the basal programme is spared | STAT5B could overtake SLC6A8 as the more creatine-selective, MK-intrinsic handle — most likely if SLC6A8 blockade cannot be kept away from other creatine-dependent tissues |
| Knock-out + vehicle MKs already have a lower panel, or the residual induction persists | STAT5B is a baseline regulator, not the creatine switch. Demote |
| Both 2 × 2s confirm | The choice then turns on what this package cannot show: tractability, and which knock-out leaves basal platelet function, counts and bleeding untouched |
| Slc6a8 knock-out prolongs bleeding or lowers basal aggregation on per-animal data | A liability to weigh against aspirin; favours a downstream node if that one spares baseline |
| CKB rescue needs catalytic activity and MK-specific loss blocks the phenotype in vivo | CKB becomes a backup with an enzymatic handle |
| The duplicated rows turn out to be an error in Fig. 6b | The STAT5-inhibitor result has two control animals per arm until repeated |
| Human MKs do not load creatine through SLC6A8, or do not raise GP6 | Translation of the primary target is in doubt regardless of mouse results |

---

## 6. Indications and populations the data do and do not support

- **Supported as a hypothesis:** preventing blood-borne seeding of the lung in hosts with raised circulating creatine. The early-retention data (Fig. 1h, 1i) and the platelet-transfer data place the effect at seeding.
- **Tumour type:** melanoma is the only model named in the workbook. Other models exist in the data but are unlabelled.
- **Not supported:** treating established metastases; controlling primary tumours (not measured); any benefit in hosts not taking creatine (sections 3.3, 3.4).
- **Human population actually studied:** healthy adults aged 20–25 on a loading dose for 14 days. Older patients, people with cancer, maintenance doses and people already on antiplatelet drugs are untested.
- **Consequence for positioning:** until Study 1 and Study 4 report, the honest label is "a mechanism by which high-dose creatine primes platelets and promotes seeding in mice, with MK SLC6A8 as its entry point", not "an anti-metastatic target".

---

## 7. How the numbers were derived, and where to find them

- **Reproduction audit.** Every test result pasted into the workbook (P value with its t, χ² or mean difference) was recomputed from the raw cells: 232 results, all reproduce (`tables/T1_embedded_statistics_audit.csv`).
- **Effect sizes and pooling.** Ratios on log-transformed values; DerSimonian–Laird random effects (`T2`, `T2b`).
- **Factorial tests.** Two-way ANOVA with interaction for every 2 × 2 in the package; the workbook reports pairwise tests only (`T3`, `T3b`). Exact rank tests on the key metastasis contrasts as an assumption-free check (`T3c`).
- **Transcript panels.** Fold changes taken from the sheets after checking each against its ΔCT rows; summarised as geometric means; per-gene tests on the log2 scale (`T4`, `T4b`).
- **Volunteers.** Wilcoxon signed-rank tests against 1.0 with Holm adjustment; paired tests for the four-volunteer blots; transcript folds recomputed from ΔCT (`T5`–`T5e`).
- **Phosphoproteomics.** Counts against the file's own P and Q columns; Benjamini–Hochberg recomputed as a check (minimum 0.25) (`T6`, `T6b`).
- **Duplicate and pattern search.** Every numeric cell with six or more significant digits compared across sheets (`T7`); replicate groups checked for values that are arithmetic functions of the others (`T7b`, `T7c`).
- **Power.** Non-central t for the interaction contrast (`T8`).
- **Blot images.** Read by eye. The one place where I give a number from an image (tumour-cell SLC6A8 knock-down: band at about 0.6 of control after β-actin normalisation) is a crude measurement on the embedded JPEG (`analysis/04_blot_image_check.py`) and marked as such.
- **Not done.** No external data were brought in. No model key, animal IDs, dosing timeline or raw blot files were available, so I could not resolve the items in section 3.8.

Files in `/tmp/outputs/`: this proposal (`.md`, `.html`); `figures/` (four figures, individual data points); `tables/` (T1–T8); `analysis/` (four scripts that regenerate every table, figure and the blot check from the supplied files).

---

## Appendix A. Inventory of every sheet in the source workbook

Means are vehicle/control → creatine/treated unless stated. "Image" = blot image only, no densitometry in the workbook. Cell types are from the conventions file.

| Sheet | What it holds (n per arm) | Result (recomputed) | Used for |
|---|---|---|---|
| Fig. 1a | Lung weight; PET SUV-BW (6) | 0.227 → 0.324 g (P = 0.0003); 418 → 894 (P = 0.003) | Phenomenon |
| Fig. 1b | Burden; foci (6) | 5.2 → 16.2% (P = 0.0005); 27.7 → 53.2 (P = 0.0006) | Phenomenon |
| Fig. 1c | Survival (10/10) | Median 22 → 19 d; log-rank P = 0.032 | Phenomenon |
| Fig. 1f | Tumour-cell sh-Slc6a8 × creatine: lung weight, SUV-BW, burden, foci (6) | Creatine effect intact with knock-down (interaction P = 0.21, 0.66, 0.68, 0.95) | Host, not tumour, SLC6A8 |
| Fig. 1h | Time course 0.25–24 h, variable unnamed (6) | Equal at 0.25 h; ×1.5–2.8 higher with creatine at 6–24 h | Seeding step |
| Fig. 1i | GFP+ cells per field (8 fields) | 9.1 → 20.4 | Seeding step |
| Fig. 1j | Lung weight; SUV-BW (6) | 0.185 → 0.302 g (P = 0.001); 614 → 1032 (P = 0.0008) | Phenomenon |
| Fig. 1k | Burden; foci (6) | 7.2 → 16.4%; 25.5 → 42.2 (both P < 0.0001) | Phenomenon |
| Fig. 1l | Survival (20/18) | Median 16 → 14 d; P = 0.011 | Phenomenon |
| Fig. 2a | Platelet count and indices (3) | 789 vs 789 ×10⁹/L; PCT, PDW, MPV unchanged | Count unchanged |
| Fig. 2b | Platelet aggregation: ADP, collagen, thrombin (3) | 42 → 57; 66 → 79; 25 → 56 | Platelet priming |
| Fig. 2c | Platelet α-granules (8 fields) | 2.0 → 3.9 (P = 0.008) | Platelet priming |
| Fig. 2d | Thromboelastography R, K, α, MA (5) | MA 39.7 → 54.0 (P = 0.049); others P > 0.14 | Platelet priming |
| Fig. 2e | Image: GP6, P2RY12, β-actin, isolated platelets (3 + 3 lanes) | Stronger with creatine | Effector protein |
| Fig. 2f | MK panel, dosed mice (3) | ×3.1; 11/11 up | MK programme |
| Fig. 2g | Image: GP6, P2RY12, isolated MKs (3 + 3 lanes) | Stronger with creatine | Effector protein |
| Fig. 2i | Image: creatine 0, 0.2, 2 mM on MKs and on platelets in vitro | MKs respond; platelets do not | MK is the site of action |
| Fig. 2j | PKH-positive area, % (8 fields) | 1.9 → 4.5 (P = 0.001) | Platelet priming |
| Fig. 3b | Serum creatine by genotype (5) | Section 3.3 | SLC6A8 |
| Fig. 3c | MK creatine by genotype (3) | Section 3.3 | SLC6A8 |
| Fig. 3d | Aggregation by genotype (3) | Section 3.3 | SLC6A8 |
| Fig. 3f | MK panel by genotype (3) | Section 3.3 | SLC6A8 |
| Fig. 3g | Image: GP6, P2RY12 by genotype ± creatine (2 lanes/arm; cell type not stated) | Rise with creatine in +/+ only | SLC6A8 |
| Fig. 3i | Lung weight, burden, foci by genotype (4) | Section 3.3 | SLC6A8 |
| Fig. 4a | Creatine in MKs and brain (3) | MK 42 → 129 µmol/g (P = 0.0004); brain 96 → 114 (P = 0.027) | MK loading; brain pointer |
| Fig. 4b | Image: CKB in MKs and brain ± creatine | Low in MKs, rises with creatine; abundant in brain | CKB |
| Fig. 4c | Phosphocreatine in MKs and brain (3) | MK 0.37 → 1.46 ng/µg (P = 0.0006); brain 0.32 → 0.63 (P = 0.031) | MK loading |
| Fig. 4d | MKs in vitro, labelled "Creatinine (umol/g)" (3) | 29.8 → 108.7 (P = 0.005) | MK loading |
| Fig. 4e | Ckb mRNA (3); image: CKB blot | ×1.82 (P = 0.011) | CKB |
| Fig. 4f | Phosphocreatine, MKs in vitro (3) | 0.23 → 1.24 ng/µg (P = 0.023) | MK loading |
| Fig. 4g | Image: CKB, GP6, P2RY12 in MKs: control, creatine, phosphocreatine | Creatine raises all three | CKB |
| Fig. 4h | MK panel: creatine, phosphocreatine (3) | ×3.3; ×0.63 | CKB |
| Fig. 4i | Image: GP6, P2RY12 with si-Ckb ± creatine | Induction lost with si-Ckb | CKB |
| Fig. 4j | MK panel, si-Ckb × creatine (3) | ×3.7 → ×1.0; si-Ckb alone ×0.70 | CKB |
| Fig. 4k | Image: GP6, P2RY12 with CKB over-expression | Stronger | CKB |
| Fig. 4l | MK panel, CKB over-expression (3) | ×2.5; 11/11 up | CKB |
| Fig. 5e | Pan-phospho/FLAG on STAT5B wild type, S127A, 3A, S127D, ± creatine (3 blots); images | Section 3.4 | STAT5B |
| Fig. 5f | Same design, second set (3 blots); images | Section 3.4 | STAT5B |
| Fig. 5g | Image: pan-phospho on STAT5B wild type vs S127A, CKB over-expression, si-GATM cells | Stronger with CKB on wild type; weak on S127A | STAT5B / CKB |
| Fig.5h | Image: nuclear pan-phospho STAT5B (wild type, S127A), si-CKB × creatine | Creatine raises the signal with control siRNA (S127A too), not with si-CKB | STAT5B / CKB |
| Fig. 5i | Image: pan-phospho on wild type vs S127A with CKB over-expression | Low-quality blot; no difference readable by eye | STAT5B / CKB |
| Fig. 5j | ChIP, P2ry12 and Gp6 promoters (3) | Section 3.4 | STAT5B |
| Fig.6a | MK panel, STAT5-IN-1 × creatine (3) | Section 3.4 | STAT5 |
| Fig. 6b | Burden, foci, STAT5-IN-1 × creatine (5) | Section 3.4 | STAT5 |
| Fig. 6d | Image: STAT5B in wild-type vs Pf4-iCre; Stat5b fl/fl MKs | Absent in knock-out | STAT5B |
| Fig. 6e | MK creatine: WT vehicle, WT creatine, knock-out creatine (3) | 20 → 95; knock-out 98 µmol/g | STAT5B is downstream of uptake |
| Fig. 6f | Image: CKB, GP6, P2RY12 in MKs and platelets, same three arms | CKB rises in both creatine arms; GP6/P2RY12 only in WT | Order of nodes |
| Fig. 6g | MK panel, same three arms (3) | ×3.6; knock-out ×1.09 | STAT5B |
| Fig. 7b | Human serum creatine, days 0, 3, 7, 14 (11) | Section 3.7 | Human |
| Fig. 7c | Human platelet aggregation and adhesion, four agonists (11) | Section 3.7 | Human |
| Fig. 7d | Human CD41+ cell transcripts (4) | Section 3.7 | Human |
| Fig. 7e | Human platelet GP6, P2RY12 protein (4) | Section 3.7 | Human |
| Fig. 7g | Mouse lung weight, burden, foci after human donor platelets, day 0 vs day 7 (5) | 0.186 → 0.236 g; 4.6 → 12.7%; 21.8 → 39.4 | Human platelets carry effect |
| Suppl. Fig. 1a | Body weight, days 0 and 7 (4) | 20.6 vs 20.7 g; 21.8 vs 23.2 g (P = 0.08) | Confounders |
| Suppl. Fig. 1b, 1c | Food and water intake (6) | 2.86 vs 2.86 g; 5.10 vs 5.02 g | Confounders |
| Suppl. Fig. 1d | Serum creatine (6) | 66 → 179 µM | Exposure |
| Suppl. Fig. 1e | Lung weight, burden, foci (6) | 0.220 → 0.294 g; 16.2 → 33.6%; 40.7 → 66.8 | Phenomenon |
| Suppl. Fig. 1f | Same (4) | 0.147 → 0.180 g; 3.9 → 10.8%; 7.0 → 18.5 | Phenomenon |
| Suppl. Fig. 1g | Same (10) | 0.207 → 0.278 g; 7.6 → 26.2%; 14.8 → 44.7 | Phenomenon |
| Suppl. Fig. 1h | Serum creatine, creatine diet (4) | 78 → 227 µM | Exposure |
| Suppl. Fig. 1i | Lung weight, burden, foci, creatine diet (4) | 0.253 → 0.362 g; 7.3 → 26.2%; 17.0 → 25.5 | Phenomenon |
| Suppl. Fig. 1k | Lung weight, burden, foci (10) | 0.153 → 0.199 g; 3.8 → 13.4%; 3.4 → 8.3 | Phenomenon |
| Suppl. Fig. 2a | Tumour-cell Slc6a8 mRNA after knock-down (3); image: SLC6A8 blot | mRNA ×0.19 (P = 0.0008); protein band partly reduced | Quality of Fig. 1f |
| Suppl. Fig. 2d | Burden, foci after donor platelets: vehicle, creatine, creatine + aspirin (6) | Section 3.6 | Platelets; aspirin |
| Suppl. Fig. 3a | White cells, lymphocytes, monocytes, red cells (5) | Unchanged (P > 0.10) | Confounders |
| Suppl. Fig. 3c | Nine other MK transcripts (3) | Six unchanged; Hsd3b1 ×1.4, Casp12 ×1.9 up, Myl9 ×0.5 down (P = 0.01–0.03) | Specificity of panel |
| Suppl. Fig. 4a | Image: SLC6A8 in MKs by genotype | Reduced, not absent, in knock-out | Deletion efficiency |
| Suppl. Fig. 4b | Platelet count by genotype (3) | Section 3.3 | SLC6A8 |
| Suppl. Fig. 4c | α-granules by genotype (8 fields) | Section 3.3 | SLC6A8 |
| Suppl. Fig. 4e | MK panel in knock-out MKs: creatine, liposomal creatine (3) | ×0.89; ×2.35 | SLC6A8 bypass |
| Suppl. Fig. 5a | Gatm, Gamt mRNA (3) | ×1.15, ×0.88 (P = 0.37, 0.61) | CKB |
| Suppl. Fig. 5b | Image: CKB after si-Ckb and after over-expression | Lower; higher | Reagent check |
| Suppl. Fig. 5c | MK creatine and phosphocreatine with CKB over-expression (3) | 33.7 vs 32.7 µmol/g; 0.17 vs 0.21 ng/µg (P = 0.16) | CKB |
| Suppl. Fig. 6a | Image: phospho-STAT5 (Y694/699), STAT5B in MKs ± creatine; Jurkat ± IL-2 | No phospho-tyrosine signal in MKs | STAT5B |
| Suppl. Fig. 6d | Image: recombinant CKB + ATP on STAT5B-FLAG, pan-phospho | Stronger with CKB | STAT5B / CKB |
| Suppl. Fig. 6e, 6f, 6g | Images: CKB over-expression, si-GATM, si-CKB in 293T | Reagents work | Reagent check |
| Suppl. Fig. 6h | Image: nuclear STAT5B in MKs ± creatine (2 lanes/arm) | Stronger with creatine | STAT5B |
| Suppl. Fig. 6i | ChIP, Rab4a promoter (3) | ×2.7 (−1 kb), ×5.5 (−0.2 kb); exon, −2 kb unchanged | STAT5B |
| Suppl. Fig. 7a | Platelet indices, STAT5-IN-1 × creatine (3) | Unchanged | STAT5 safety pointer |
| Suppl. Fig. 7b | Platelet indices, WT vs Stat5b knock-out + creatine (3) | Count 896, 760, 693 (P = 0.19–0.79); plateletcrit P = 0.055 | STAT5B safety pointer |
| Suppl. Fig. 8a | Volunteer BMI, day 0 vs 14 (11) | 20.9 vs 21.1 | Human |
| Suppl. Fig. 8b | Volunteer platelet count and indices (11) | Unchanged | Human |
| Suppl. Fig. 8c | CD41 mRNA: CD41+ cells, monocytes, MEG-01 (3) | Monocytes ×0.06, MEG-01 ×0.71 of CD41+ cells | Identity of CD41+ cells |
| Suppl. Fig. 8d | Image: GP6, P2RY12, β-actin in platelets of four volunteers, days 0–14 | Source blots for Fig. 7e | Human |
