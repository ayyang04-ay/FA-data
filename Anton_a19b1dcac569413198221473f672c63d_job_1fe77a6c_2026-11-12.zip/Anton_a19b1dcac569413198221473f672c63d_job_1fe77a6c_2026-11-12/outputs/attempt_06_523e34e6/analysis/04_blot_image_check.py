#!/usr/bin/env python
"""
CRE-MK-01 re-analysis, part 4: a deliberately crude densitometry check of ONE embedded blot image,
used only to qualify the statement that tumour-cell SLC6A8 knock-down (Suppl. Fig. 2a) is partial at protein level.
The image is an 8-bit JPEG embedded in the workbook; this is indicative, not a validated quantification.
Run:  micromamba run -n chem python 04_blot_image_check.py
"""
import io, os, zipfile
import numpy as np
from PIL import Image
SRC = os.path.join(os.environ.get('CRE_DIR', '/tmp/world/filesystem'), 'CRE-MK-01_source_data.xlsx')
img = Image.open(io.BytesIO(zipfile.ZipFile(SRC).read('xl/media/image17.jpeg'))).convert('L')   # image attached to sheet 'Supplementary Fig  2a'
a = np.asarray(img).astype(float)

def band(x0, x1, y0, y1, bg_rows):
    """integrated darkness of the band window above a local background taken from the same lane"""
    bg = np.median(a[bg_rows[0]:bg_rows[1], x0:x1])
    return float(np.clip(bg - a[y0:y1, x0:x1], 0, None).sum()), float(bg)

# windows (pixels) were placed by eye on the ~60 kDa SLC6A8 band and the ~45 kDa beta-actin band of each lane
slc_scr, _ = band(197, 247, 262, 300, (215, 250))
slc_sh, _ = band(263, 311, 262, 300, (215, 250))
act_scr, _ = band(475, 515, 230, 256, (175, 215))
act_sh, _ = band(520, 562, 230, 256, (175, 215))
print(f'SLC6A8 band, sh-Slc6a8 / sh-scrambled      : {slc_sh / slc_scr:.2f}')
print(f'beta-actin band, sh-Slc6a8 / sh-scrambled  : {act_sh / act_scr:.2f}')
print(f'SLC6A8 normalised to beta-actin            : {(slc_sh / slc_scr) / (act_sh / act_scr):.2f}  (1.00 = no knock-down)')
