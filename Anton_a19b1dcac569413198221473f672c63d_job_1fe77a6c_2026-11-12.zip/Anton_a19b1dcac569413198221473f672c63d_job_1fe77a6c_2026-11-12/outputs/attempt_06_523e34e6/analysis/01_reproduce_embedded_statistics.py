#!/usr/bin/env python
"""
CRE-MK-01 re-analysis, part 1.
Recomputes every statistical test that is embedded (as pasted GraphPad Prism output) in
CRE-MK-01_source_data.xlsx from the raw values in the same sheets, and writes an audit table:
    ../tables/T1_embedded_statistics_audit.csv
Run:  micromamba run -n chem python 01_reproduce_embedded_statistics.py
"""
import re, itertools, sys, os
import numpy as np, pandas as pd, openpyxl
from scipy import stats
from scipy.stats import studentized_range
from openpyxl.utils import column_index_from_string

SRC = os.path.join(os.environ.get('CRE_DIR', '/tmp/world/filesystem'), 'CRE-MK-01_source_data.xlsx')   # set CRE_DIR to the folder holding the supplied files
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tables')
os.makedirs(OUT, exist_ok=True)
WB = openpyxl.load_workbook(SRC, data_only=True)

def col(ws, c, r0, r1):
    return np.array([float(ws[f'{c}{r}'].value) for r in range(r0, r1 + 1) if ws[f'{c}{r}'].value is not None])
def row(ws, r, c0, c1):
    a, b = column_index_from_string(c0), column_index_from_string(c1)
    return np.array([float(ws.cell(row=r, column=c).value) for c in range(a, b + 1) if ws.cell(row=r, column=c).value is not None])

AUDIT = []
def relclose(x, y, rtol=0.02, atol=6e-5):
    if isinstance(y, str):
        y = y.strip()
        if y.startswith('<'):  return x < float(y[1:]) * 1.0001
        if y.startswith('>'):  return x > float(y[1:]) * 0.9999
        y = float(y)
    return abs(x - y) <= max(atol, rtol * abs(y))

def add(sheet, block, comparison, test, n, rep_stat, calc_stat, rep_p, calc_p, ok, extra=''):
    AUDIT.append(dict(sheet=sheet, block=block, comparison=comparison, test=test, n_per_group=n,
                      reported_statistic=rep_stat, recomputed_statistic=calc_stat,
                      reported_p=rep_p, recomputed_p=calc_p, reproduces=bool(ok), note=extra))

# ------------------------------------------------------------------ unpaired t tests
def ttest(sheet, block, a, b, p_ref, tdf_ref):
    ws = WB[sheet]
    t, p = stats.ttest_ind(a, b, equal_var=True)
    df = len(a) + len(b) - 2
    rep_p = ws[p_ref].value
    m = re.match(r't=([\d.]+), df=(\d+)', ws[tdf_ref].value)
    rt, rdf = float(m.group(1)), int(m.group(2))
    ok = relclose(abs(t), rt, rtol=0.002, atol=0.0006) and df == rdf and relclose(p, rep_p, rtol=0.06)
    add(sheet, block, 'group B vs group A', 'unpaired two-tailed Student t', f'{len(a)}/{len(b)}',
        f't={rt}, df={rdf}', f't={abs(t):.4g}, df={df}', rep_p, p, ok,
        f'means {np.mean(a):.5g} vs {np.mean(b):.5g}')

T = [  # sheet, block, (kind, args A), (kind, args B), p cell, t/df cell
 ('Fig. 1a','lung weight',('c','B',3,8),('c','C',3,8),'F4','F8'),
 ('Fig. 1a','SUV-BW',('c','B',12,17),('c','C',12,17),'F12','F16'),
 ('Fig. 1b','metastatic burden',('c','B',3,8),('c','C',3,8),'F3','F7'),
 ('Fig. 1b','metastatic foci',('c','B',12,17),('c','C',12,17),'F12','F16'),
 ('Fig. 1h','0.25 h',('r',4,'B','G'),('r',4,'H','M'),'B17','B21'),
 ('Fig. 1h','6 h',('r',5,'B','G'),('r',5,'H','M'),'E17','E21'),
 ('Fig. 1h','12 h',('r',6,'B','G'),('r',6,'H','M'),'H17','H21'),
 ('Fig. 1h','24 h',('r',7,'B','G'),('r',7,'H','M'),'K17','K21'),
 ('Fig. 1i','GFP+ cells per field',('c','B',4,11),('c','C',4,11),'F4','F8'),
 ('Fig. 1j','lung weight',('c','B',4,9),('c','C',4,9),'F4','F8'),
 ('Fig. 1j','SUV-BW',('c','B',13,18),('c','C',13,18),'F13','F17'),
 ('Fig. 1k','metastatic burden',('c','B',4,9),('c','C',4,9),'F4','F8'),
 ('Fig. 1k','metastatic foci',('c','B',12,17),('c','C',12,17),'F12','F16'),
 ('Fig. 2a','PLT',('c','B',4,6),('c','C',4,6),'F4','F8'),
 ('Fig. 2a','PCT',('c','B',12,14),('c','C',12,14),'F12','F16'),
 ('Fig. 2a','PDW',('c','B',19,21),('c','C',19,21),'F19','F23'),
 ('Fig. 2a','MPV',('c','B',27,29),('c','C',27,29),'F27','F31'),
 ('Fig. 2b','ADP',('r',4,'B','D'),('r',4,'E','G'),'B18','B22'),
 ('Fig. 2b','collagen',('r',5,'B','D'),('r',5,'E','G'),'B32','B36'),
 ('Fig. 2b','thrombin',('r',6,'B','D'),('r',6,'E','G'),'B45','B49'),
 ('Fig. 2c','alpha-granules',('c','B',4,11),('c','C',4,11),'F5','F9'),
 ('Fig. 2d','TEG-R',('c','B',4,8),('c','C',4,8),'F4','F8'),
 ('Fig. 2d','TEG-K',('c','B',12,16),('c','C',12,16),'F12','F16'),
 ('Fig. 2d','TEG-alpha',('c','B',20,24),('c','C',20,24),'F20','F24'),
 ('Fig. 2d','TEG-MA',('c','B',28,32),('c','C',28,32),'F28','F32'),
 ('Fig. 2j','PKH-positive area',('c','B',4,11),('c','C',4,11),'F4','F8'),
 ('Fig. 3b','serum creatine, Slc6a8+/+',('r',4,'B','F'),('r',4,'G','K'),'B17','B21'),
 ('Fig. 3b','serum creatine, Slc6a8 fl/fl',('r',5,'B','F'),('r',5,'G','K'),'B31','B35'),
 ('Fig. 3c','MK creatine, Slc6a8+/+',('r',4,'B','D'),('r',4,'E','G'),'B15','B19'),
 ('Fig. 3c','MK creatine, Slc6a8 fl/fl',('r',5,'B','D'),('r',5,'E','G'),'B30','B34'),
 ('Fig. 4a','creatine, MKs',('c','B',4,6),('c','C',4,6),'H10','H14'),
 ('Fig. 4a','creatine, brain',('c','D',4,6),('c','E',4,6),'H24','H28'),
 ('Fig. 4c','phosphocreatine, MKs',('c','B',4,6),('c','C',4,6),'H10','H14'),
 ('Fig. 4c','phosphocreatine, brain',('c','D',4,6),('c','E',4,6),'H24','H28'),
 ('Fig. 4d','creatine, MKs in vitro',('c','C',4,6),('c','D',4,6),'G10','G14'),
 ('Fig. 4e','Ckb mRNA',('r',8,'E','G'),('r',8,'I','K'),'O5','O9'),
 ('Fig. 4f','phosphocreatine, MKs in vitro',('c','B',4,6),('c','C',4,6),'F4','F8'),
 ('Fig. 7g','lung weight',('c','B',4,8),('c','C',4,8),'F4','F8'),
 ('Fig. 7g','metastatic burden',('c','B',12,16),('c','C',12,16),'F12','F16'),
 ('Fig. 7g','metastatic foci',('c','B',19,23),('c','C',19,23),'F19','F23'),
 ('Supplementary Fig  1a','body weight d0',('r',4,'B','E'),('r',4,'F','I'),'M11','M15'),
 ('Supplementary Fig  1a','body weight d7',('r',5,'B','E'),('r',5,'F','I'),'M25','M29'),
 ('Supplementary Fig  1b','food intake',('c','B',4,9),('c','C',4,9),'F4','F8'),
 ('Supplementary Fig  1c','water intake',('c','B',4,9),('c','C',4,9),'F4','F8'),
 ('Supplementary Fig  1d','serum creatine',('c','B',4,9),('c','C',4,9),'F4','F8'),
 ('Supplementary Fig  1e','lung weight',('c','B',4,9),('c','C',4,9),'F4','F8'),
 ('Supplementary Fig  1e','metastatic burden',('c','B',13,18),('c','C',13,18),'F13','F17'),
 ('Supplementary Fig  1e','metastatic foci',('c','B',22,27),('c','C',22,27),'F22','F26'),
 ('Supplementary Fig  1f','lung weight',('c','B',4,7),('c','C',4,7),'F4','F8'),
 ('Supplementary Fig  1f','metastatic burden',('c','B',12,15),('c','C',12,15),'F12','F16'),
 ('Supplementary Fig  1f','metastatic foci',('c','B',20,23),('c','C',20,23),'F20','F24'),
 ('Supplementary Fig  1g','lung weight',('c','B',3,12),('c','C',3,12),'F3','F7'),
 ('Supplementary Fig  1g','metastatic burden',('c','B',15,24),('c','C',15,24),'F15','F19'),
 ('Supplementary Fig  1g','metastatic foci',('c','B',28,37),('c','C',28,37),'F28','F32'),
 ('Supplementary Fig  1h','serum creatine (diet)',('c','C',4,7),('c','D',4,7),'F4','F8'),
 ('Supplementary Fig  1i','lung weight (diet)',('c','B',3,6),('c','C',3,6),'F3','F7'),
 ('Supplementary Fig  1i','metastatic burden (diet)',('c','B',11,14),('c','C',11,14),'F11','F15'),
 ('Supplementary Fig  1i','metastatic foci (diet)',('c','B',18,21),('c','C',18,21),'F18','F22'),
 ('Supplementary Fig  1k','lung weight',('c','B',4,13),('c','C',4,13),'G4','G8'),
 ('Supplementary Fig  1k','metastatic burden',('c','B',16,25),('c','C',16,25),'G16','G20'),
 ('Supplementary Fig  1k','metastatic foci',('c','B',29,38),('c','C',29,38),'G29','G33'),
 ('Supplementary Fig  2a','Slc6a8 mRNA knock-down',('r',7,'D','F'),('r',7,'H','J'),'M4','M8'),
 ('Supplementary Fig  3a','WBC',('c','B',4,8),('c','C',4,8),'F4','F8'),
 ('Supplementary Fig  3a','lymphocytes',('c','B',12,16),('c','C',12,16),'F12','F16'),
 ('Supplementary Fig  3a','monocytes',('c','B',20,24),('c','C',20,24),'F20','F24'),
 ('Supplementary Fig  3a','RBC',('c','B',28,32),('c','C',28,32),'F28','F32'),
 ('Supplementary Fig  5a','Gatm mRNA',('r',6,'C','E'),('r',6,'G','I'),'N10','N14'),
 ('Supplementary Fig  5a','Gamt mRNA',('r',9,'C','E'),('r',9,'G','I'),'N24','N28'),
 ('Supplementary Fig  5c','MK creatine, CKB-OE',('c','B',5,7),('c','C',5,7),'F5','F9'),
 ('Supplementary Fig  5c','MK phosphocreatine, CKB-OE',('c','B',13,15),('c','C',13,15),'F13','F17'),
 ('Supplementary Fig  8a','BMI d0 vs d14 (analysed unpaired)',('c','C',4,14),('c','D',4,14),'G5','G9'),
]
def get(ws, spec):
    return col(ws, *spec[1:]) if spec[0] == 'c' else row(ws, *spec[1:])
for sheet, block, A, B, pc, tc in T:
    ws = WB[sheet]; ttest(sheet, block, get(ws, A), get(ws, B), pc, tc)

# ------------------------------------------------------------------ log-rank
def logrank(t1, t2):
    O1 = E1 = V = 0.0
    for t in np.unique(np.concatenate([t1, t2])):
        n1, n2 = (t1 >= t).sum(), (t2 >= t).sum(); d1, d2 = (t1 == t).sum(), (t2 == t).sum()
        n, d = n1 + n2, d1 + d2
        O1 += d1; E1 += d * n1 / n
        if n > 1: V += d * (n1 / n) * (n2 / n) * (n - d) / (n - 1)
    chi = (O1 - E1) ** 2 / V
    return chi, stats.chi2.sf(chi, 1)
for sheet, rmax, chi_c, p_c in [('Fig. 1c', 23, 'F6', 'F8'), ('Fig. 1l', 41, 'F5', 'F7')]:
    ws = WB[sheet]
    veh = np.array([ws[f'A{r}'].value for r in range(4, rmax + 1) if ws[f'B{r}'].value == 1], float)
    cre = np.array([ws[f'A{r}'].value for r in range(4, rmax + 1) if ws[f'C{r}'].value == 1], float)
    chi, p = logrank(veh, cre)
    ok = relclose(chi, ws[chi_c].value, rtol=0.002) and relclose(p, ws[p_c].value, rtol=0.03)
    add(sheet, 'survival', 'creatine vs vehicle', 'log-rank (Mantel-Cox)', f'{len(veh)}/{len(cre)}',
        f'chi2={ws[chi_c].value}', f'chi2={chi:.4g}', ws[p_c].value, p, ok,
        f'median survival {np.median(veh):g} d vs {np.median(cre):g} d; all animals are events')

# ------------------------------------------------------------------ one-way ANOVA + Tukey
def tukey_all(groups):
    k = len(groups); N = sum(len(g) for g in groups); dfe = N - k
    mse = sum(((g - g.mean()) ** 2).sum() for g in groups) / dfe
    qcrit = studentized_range.ppf(0.95, k, dfe); out = []
    for i, j in itertools.combinations(range(k), 2):
        d = groups[i].mean() - groups[j].mean()
        se = np.sqrt(mse / 2 * (1 / len(groups[i]) + 1 / len(groups[j])))
        out.append((i, j, d, d - qcrit * se, d + qcrit * se, studentized_range.sf(abs(d) / se, k, dfe)))
    return out
def rep_rows(ws, cols, r0, r1):
    rows = []
    for r in range(r0, r1 + 1):
        vals = [ws[f'{c}{r}'].value for c in cols]
        if vals[0] is not None and vals[1] is not None: rows.append(vals)
    return rows
def tukey_block(sheet, block, groups, names, cols, r0, r1):
    ws = WB[sheet]; calc = tukey_all(groups)
    for lab, md, ci, sigq, summ, padj in rep_rows(ws, cols, r0, r1):
        # match the reported row to a computed pair by mean difference (sign-insensitive)
        best = min(calc, key=lambda c: min(abs(c[2] - md), abs(c[2] + md)))
        i, j, d, lo, hi, p = best
        ok = relclose(abs(d), abs(md), rtol=0.003, atol=abs(md) * 0.003 + 1e-4) and relclose(p, padj, rtol=0.15, atol=1.5e-4)
        add(sheet, block, f'{str(lab).strip()}  [matched to: {names[i]} vs {names[j]}]', 'one-way ANOVA + Tukey',
            '/'.join(str(len(g)) for g in groups), f'diff={md}; CI {ci}', f'diff={d:.4g}; CI {lo:.4g} to {hi:.4g}', padj, p, ok)

ws = WB['Fig. 1f']; n4 = ['scr+veh', 'scr+cre', 'shSlc6a8+veh', 'shSlc6a8+cre']
for nm, r0 in [('lung weight', 4), ('SUV-BW', 13), ('metastatic burden', 22), ('metastatic foci', 31)]:
    tukey_block('Fig. 1f', nm, [col(ws, c, r0, r0 + 5) for c in 'BCDE'], n4, 'GHIJKL', r0, r0 + 2)
ws = WB['Fig. 3d']; n4 = ['Slc6a8+/+ veh', 'Slc6a8+/+ cre', 'Slc6a8fl/fl veh', 'Slc6a8fl/fl cre']
for nm, r, (a, b) in [('ADP', 4, (4, 5)), ('collagen', 5, (10, 11)), ('thrombin', 6, (15, 16))]:
    tukey_block('Fig. 3d', nm, [row(ws, r, 'B', 'D'), row(ws, r, 'E', 'G'), row(ws, r, 'H', 'J'), row(ws, r, 'K', 'M')], n4, 'OPQRST', a, b)
ws = WB['Fig. 3i']
for nm, r0 in [('lung weight', 3), ('metastatic burden', 10), ('metastatic foci', 17)]:
    tukey_block('Fig. 3i', nm, [col(ws, c, r0, r0 + 3) for c in 'BCDE'], n4, 'GHIJKL', r0, r0 + 2)
mut = ['WT', 'S127A', '3A', 'S127D']
ws = WB['Fig. 5e']
tukey_block('Fig. 5e', 'p-FLAG/FLAG vehicle', [col(ws, c, 4, 6) for c in 'NOPQ'], mut, 'MNOPQR', 10, 13)
tukey_block('Fig. 5e', 'p-FLAG/FLAG creatine', [col(ws, c, 17, 19) for c in 'NOPQ'], mut, 'MNOPQR', 22, 24)
ws = WB['Fig. 5f']
tukey_block('Fig. 5f', 'p-FLAG/FLAG vehicle', [col(ws, c, 4, 6) for c in 'NOPQ'], mut, 'LMNOPQ', 9, 12)
tukey_block('Fig. 5f', 'p-FLAG/FLAG creatine', [col(ws, c, 17, 19) for c in 'NOPQ'], mut, 'LMNOPQ', 22, 24)
ws = WB['Fig. 6b']; n4 = ['veh', 'cre', 'veh+STAT5i', 'cre+STAT5i']
tukey_block('Fig. 6b', 'metastatic burden', [col(ws, c, 4, 8) for c in 'BCDE'], n4, 'GHIJKL', 4, 7)
tukey_block('Fig. 6b', 'metastatic foci', [col(ws, c, 13, 17) for c in 'BCDE'], n4, 'GHIJKL', 13, 16)
ws = WB['Fig. 6e']
tukey_block('Fig. 6e', 'MK creatine', [col(ws, c, 5, 7) for c in 'CDE'], ['WT veh', 'WT cre', 'Stat5b cKO cre'], 'GHIJKL', 5, 7)
ws = WB['Fig. 7b']; d4 = ['d0', 'd3', 'd7', 'd14']
tukey_block('Fig. 7b', 'serum creatine (human)', [col(ws, c, 4, 14) for c in 'BCDE'], d4, 'GHIJKL', 5, 7)
ws = WB['Fig. 7e']
tukey_block('Fig. 7e', 'GP6/b-actin (human platelets)', [col(ws, c, 4, 7) for c in 'BCDE'], d4, 'GHIJKL', 4, 6)
tukey_block('Fig. 7e', 'P2RY12/b-actin (human platelets)', [col(ws, c, 12, 15) for c in 'BCDE'], d4, 'GHIJKL', 12, 14)
ws = WB['Supplementary Fig  2d']; n3 = ['veh donor PLT', 'cre donor PLT', 'cre+aspirin donor PLT']
tukey_block('Supplementary Fig  2d', 'metastatic burden', [col(ws, c, 5, 10) for c in 'CDE'], n3, 'GHIJKL', 5, 7)
tukey_block('Supplementary Fig  2d', 'metastatic foci', [col(ws, c, 14, 19) for c in 'CDE'], n3, 'GHIJKL', 14, 16)
ws = WB['Supplementary Fig  4b']; n4 = ['Slc6a8+/+ veh', 'Slc6a8+/+ cre', 'Slc6a8fl/fl veh', 'Slc6a8fl/fl cre']
tukey_block('Supplementary Fig  4b', 'PLT', [col(ws, c, 5, 7) for c in 'CDEF'], n4, 'HIJKLM', 5, 8)
ws = WB['Supplementary Fig  4c']
tukey_block('Supplementary Fig  4c', 'alpha-granules', [col(ws, c, 6, 13) for c in 'CDEF'], n4, 'IJKLMN', 7, 9)
ws = WB['Supplementary Fig  7a']; n4 = ['veh+ctrl', 'cre+ctrl', 'veh+STAT5i', 'cre+STAT5i']
for nm, r0 in [('PLT', 4), ('PCT', 11), ('MPV', 17), ('PDW', 23)]:
    tukey_block('Supplementary Fig  7a', nm, [col(ws, c, r0, r0 + 2) for c in 'BCDE'], n4, 'GHIJKL', r0, r0 + 2)
ws = WB['Supplementary Fig  7b']; n3 = ['WT veh', 'WT cre', 'Stat5b cKO cre']
for nm, r0 in [('PLT', 4), ('PCT', 10), ('MPV', 16), ('PDW', 22)]:
    tukey_block('Supplementary Fig  7b', nm, [col(ws, c, r0, r0 + 2) for c in 'BCD'], n3, 'FGHIJK', r0, r0 + 2)
ws = WB['Supplementary Fig  8c']
tukey_block('Supplementary Fig  8c', 'CD41 mRNA', [row(ws, 9, 'E', 'G'), row(ws, 9, 'I', 'K'), row(ws, 9, 'M', 'O')],
            ['CD41+ cells', 'monocytes', 'MEG-01'], 'DEFGHI', 15, 15)

# ------------------------------------------------------------------ Dunnett (vs day 0), as run in Prism on unpaired columns
def dunnett_block(sheet, block, groups, r0):
    ws = WB[sheet]
    res = stats.dunnett(*groups[1:], control=groups[0])
    for k, lab in enumerate(['0 vs. 3', '0 vs. 7', '0 vs. 14']):
        r = r0 + k
        md, padj = ws[f'H{r}'].value, ws[f'L{r}'].value
        d = groups[0].mean() - groups[k + 1].mean()
        ok = relclose(d, md, rtol=0.003, atol=abs(md) * 0.003 + 1e-4) and relclose(res.pvalue[k], padj, rtol=0.05, atol=6e-4)
        add(sheet, block, lab, 'one-way ANOVA + Dunnett (unpaired)', '11/11/11/11', f'diff={md}', f'diff={d:.4g}', padj, float(res.pvalue[k]), ok)
ws = WB['Fig. 7c']
B7C = [('collagen max aggregation', 4, 14, 4), ('collagen average aggregation', 18, 28, 18), ('collagen adhesion', 32, 42, 32),
       ('EPI max aggregation', 46, 56, 47), ('EPI average aggregation', 60, 70, 61), ('EPI adhesion', 74, 84, 75),
       ('AA max aggregation', 88, 98, 88), ('AA average aggregation', 102, 112, 103), ('AA adhesion', 116, 126, 117),
       ('ADP max aggregation', 130, 140, 131), ('ADP average aggregation', 144, 154, 145), ('ADP adhesion', 157, 167, 159)]
np.random.seed(1)
for nm, r0, r1, rr in B7C:
    dunnett_block('Fig. 7c', nm, [col(ws, c, r0, r1) for c in 'BCDE'], rr)
ws = WB['Supplementary Fig  8b']
for nm, r0, r1, rr in [('PLT', 4, 14, 4), ('PCT', 19, 29, 19), ('MPV', 33, 43, 33), ('PDW', 48, 58, 48)]:
    dunnett_block('Supplementary Fig  8b', nm, [col(ws, c, r0, r1) for c in 'BCDE'], rr)

# ------------------------------------------------------------------ two-way ANOVA + Sidak (ChIP)
def sidak_block(sheet, block, veh_rows, cre_rows, labels, cols, r0):
    ws = WB[sheet]; V = np.array(veh_rows); C = np.array(cre_rows); k, n = V.shape
    dfe = 2 * k * (n - 1)
    mse = (((V - V.mean(1, keepdims=True)) ** 2).sum() + ((C - C.mean(1, keepdims=True)) ** 2).sum()) / dfe
    for i, lab in enumerate(labels):
        d = V[i].mean() - C[i].mean(); se = np.sqrt(mse * 2 / n)
        p = 2 * stats.t.sf(abs(d / se), dfe); padj = 1 - (1 - p) ** k
        md, rp = ws[f'{cols[1]}{r0 + i}'].value, ws[f'{cols[5]}{r0 + i}'].value
        ok = relclose(d, md, rtol=0.003, atol=abs(md) * 0.003 + 1e-4) and relclose(padj, rp, rtol=0.05, atol=1e-4)
        add(sheet, block, f'{lab}: vehicle - creatine', 'two-way ANOVA + Sidak', '3/3', f'diff={md}', f'diff={d:.4g}', rp, padj, ok,
            f'% input {V[i].mean():.3g} -> {C[i].mean():.3g} ({C[i].mean() / V[i].mean():.2f}x)')
ws = WB['Fig. 5j']; L = ['Exon', '-2 kb', '-1 kb', '-0.2 kb']
sidak_block('Fig. 5j', 'ChIP P2ry12', [row(ws, r, 'B', 'D') for r in range(5, 9)], [row(ws, r, 'E', 'G') for r in range(5, 9)], L, 'IJKLMN', 7)
sidak_block('Fig. 5j', 'ChIP Gp6', [row(ws, r, 'B', 'D') for r in range(15, 19)], [row(ws, r, 'E', 'G') for r in range(15, 19)], L, 'IJKLMN', 17)
ws = WB['Supplementary Fig  6i']
sidak_block('Supplementary Fig  6i', 'ChIP Rab4a', [row(ws, r, 'C', 'E') for r in range(7, 11)], [row(ws, r, 'F', 'H') for r in range(7, 11)], L, 'JKLMNO', 10)

df = pd.DataFrame(AUDIT)
df.to_csv(os.path.join(OUT, 'T1_embedded_statistics_audit.csv'), index=False)
print(f'{len(df)} embedded test results recomputed; {int(df.reproduces.sum())} reproduce; {int((~df.reproduces).sum())} do not')
print(df.groupby('test').reproduces.agg(['size', 'sum']))
if (~df.reproduces).any():
    print(df[~df.reproduces].to_string())
