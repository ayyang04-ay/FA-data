#!/usr/bin/env python
"""
CRE-MK-01 re-analysis, part 3: figures for the proposal (individual data points, no smoothing).
Run after 02_decision_analyses.py:  micromamba run -n chem python 03_figures.py
"""
import os, collections
import numpy as np, pandas as pd, openpyxl
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from openpyxl.utils import column_index_from_string

D = os.environ.get('CRE_DIR', '/tmp/world/filesystem')
HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(HERE, '..', 'figures'); TAB = os.path.join(HERE, '..', 'tables'); os.makedirs(FIG, exist_ok=True)
WB = openpyxl.load_workbook(os.path.join(D, 'CRE-MK-01_source_data.xlsx'), data_only=True)
def col(ws, c, r0, r1): return np.array([float(ws[f'{c}{r}'].value) for r in range(r0, r1 + 1) if ws[f'{c}{r}'].value is not None])
def row(ws, r, c0, c1):
    a, b = column_index_from_string(c0), column_index_from_string(c1)
    return np.array([float(ws.cell(row=r, column=c).value) for c in range(a, b + 1) if ws.cell(row=r, column=c).value is not None])
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.titlesize': 9.5, 'axes.titleweight': 'bold',
                     'figure.dpi': 150, 'savefig.dpi': 200, 'font.family': 'DejaVu Sans'})
CV, CC = '#7f7f7f', '#d95f02'   # vehicle grey, creatine orange
rng = np.random.default_rng(7)

def strip(ax, groups, labels, colors, shared=None, ylabel='', title='', logy=False, ylim=None, marker='o'):
    for i, (g, c) in enumerate(zip(groups, colors)):
        x = i + rng.uniform(-0.13, 0.13, len(g))
        sh = np.zeros(len(g), bool) if shared is None or shared[i] is None else np.array(shared[i], bool)
        ax.scatter(x[~sh], g[~sh], s=26, color=c, edgecolor='k', linewidth=0.4, zorder=3, marker=marker)
        if sh.any(): ax.scatter(x[sh], g[sh], s=34, facecolor='white', edgecolor=c, linewidth=1.6, zorder=3, marker='D')
        ax.hlines(g.mean(), i - 0.25, i + 0.25, color='k', lw=1.4, zorder=4)
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(labels, fontsize=7.5)
    ax.set_ylabel(ylabel); ax.set_title(title, loc='left')
    if logy: ax.set_yscale('log')
    if ylim: ax.set_ylim(*ylim)
    ax.set_xlim(-0.6, len(groups) - 0.4)

# --------------------------------------------------------------------------- Figure 1: MK-lineage Slc6a8 knock-out
ws = WB['Fig. 3i']; lab4 = ['Cre-ctrl\nvehicle', 'Cre-ctrl\ncreatine', 'Slc6a8-cKO\nvehicle', 'Slc6a8-cKO\ncreatine']; c4 = [CV, CC, CV, CC]
fig, axs = plt.subplots(2, 3, figsize=(11, 6.6))
T3 = pd.read_csv(os.path.join(TAB, 'T3_factorial_interaction_analyses.csv'))
def pint(name, scale='linear'):
    return T3[(T3.experiment == name) & (T3.scale == scale)].interaction_p.iloc[0]
for ax, (nm, r0, yl, key) in zip(axs[0], [('Lung weight', 3, 'g (axis truncated)', 'Fig. 3i lung weight (g)'), ('Metastatic burden', 10, '% of lung area', 'Fig. 3i metastatic burden (%)'), ('Metastatic foci', 17, 'count', 'Fig. 3i metastatic foci')]):
    g = [col(ws, c, r0, r0 + 3) for c in 'BCDE']
    strip(ax, g, lab4, c4, ylabel=yl, title=f'{nm} (Fig. 3i, n=4 mice)')
    ax.text(0.98, 0.97, f'genotype × creatine\ninteraction P = {pint(key):.1g}', transform=ax.transAxes, ha='right', va='top', fontsize=8)
    if 'weight' in nm: ax.set_ylim(0.195, 0.27)
    else: ax.set_ylim(bottom=0)
ws = WB['Fig. 3c']
g = [row(ws, 4, 'B', 'D'), row(ws, 4, 'E', 'G'), row(ws, 5, 'B', 'D'), row(ws, 5, 'E', 'G')]
strip(axs[1, 0], g, lab4, c4, ylabel='µmol/g', title='MK creatine (Fig. 3c, n=3)')
axs[1, 0].text(0.98, 0.97, f'interaction P = {pint("Fig. 3c MK intracellular creatine (umol/g)"):.2g}', transform=axs[1, 0].transAxes, ha='right', va='top', fontsize=8)
ws = WB['Fig. 3b']
g = [row(ws, 4, 'B', 'F'), row(ws, 4, 'G', 'K'), row(ws, 5, 'B', 'F'), row(ws, 5, 'G', 'K')]
strip(axs[1, 1], g, lab4, c4, ylabel='µM', title='Serum creatine (Fig. 3b, n=5)')
axs[1, 1].text(0.5, 0.04, 'rises in both genotypes\n(interaction P = 0.18)', transform=axs[1, 1].transAxes, ha='center', va='bottom', fontsize=8)
axs[1, 1].set_ylim(0, 310)
ws = WB['Fig. 3d']; ax = axs[1, 2]
for k, (ag, r) in enumerate([('ADP', 4), ('collagen', 5), ('thrombin', 6)]):
    g = [row(ws, r, 'B', 'D'), row(ws, r, 'E', 'G'), row(ws, r, 'H', 'J'), row(ws, r, 'K', 'M')]
    for i, (v, c) in enumerate(zip(g, c4)):
        x0 = k * 5 + i
        ax.scatter(x0 + rng.uniform(-0.12, 0.12, len(v)), v, s=22, color=c, edgecolor='k', linewidth=0.4, zorder=3, marker='o' if i < 2 else 's')
        ax.hlines(v.mean(), x0 - 0.3, x0 + 0.3, color='k', lw=1.3)
    ax.text(k * 5 + 1.5, 84, ag, ha='center', fontsize=8.5, fontweight='bold')
ax.set_xticks([0.5, 2.5, 5.5, 7.5, 10.5, 12.5]); ax.set_xticklabels(['Cre-\nctrl', 'cKO'] * 3, fontsize=7.5)
ax.set_ylim(20, 90); ax.set_ylabel('aggregation (sheet units)'); ax.set_title('Platelet aggregation (Fig. 3d, 3 values/arm)', loc='left')
ax.text(0.02, 0.04, 'in the knock-out, creatine lowers aggregation', transform=ax.transAxes, fontsize=8, ha='left')
fig.legend(handles=[Line2D([], [], marker='o', color='w', markerfacecolor=CV, markeredgecolor='k', label='vehicle'), Line2D([], [], marker='o', color='w', markerfacecolor=CC, markeredgecolor='k', label='creatine'),
                    Line2D([], [], color='k', lw=1.4, label='group mean')], loc='upper right', ncol=3, frameon=False, fontsize=8.5, bbox_to_anchor=(0.99, 1.0))
fig.suptitle('Megakaryocyte-lineage Slc6a8 knock-out (Pf4-Cre; Slc6a8 fl/fl) vs Cre-only controls', x=0.01, ha='left', fontsize=11, fontweight='bold')
fig.tight_layout(rect=(0, 0, 1, 0.96)); fig.savefig(os.path.join(FIG, 'Fig1_MK_Slc6a8_knockout.png')); plt.close(fig)

# --------------------------------------------------------------------------- Figure 2: STAT5 inhibitor and aspirin donor-platelet experiments
fig, axs = plt.subplots(1, 4, figsize=(13.2, 4.3))
ws = WB['Fig. 6b']; lab = ['vehicle', 'creatine', 'vehicle\n+ STAT5\ninhibitor', 'creatine\n+ STAT5\ninhibitor']
sh6 = [[0, 1, 1, 1, 0], [0, 1, 1, 1, 0], None, None]
strip(axs[0], [col(ws, c, 4, 8) for c in 'BCDE'], lab, [CV, CC, CV, CC], shared=sh6, ylabel='% of lung area', title='Fig. 6b burden (n=5 mice/arm)')
strip(axs[1], [col(ws, c, 13, 17) for c in 'BCDE'], lab, [CV, CC, CV, CC], shared=sh6, ylabel='count', title='Fig. 6b foci')
ws = WB['Supplementary Fig  2d']; lab = ['vehicle\ndonor\nplatelets', 'creatine\ndonor\nplatelets', 'creatine\n+ aspirin\ndonor platelets']
sh2 = [[0, 0, 0, 1, 1, 1], [0, 0, 0, 1, 1, 1], None]
strip(axs[2], [col(ws, c, 5, 10) for c in 'CDE'], lab, [CV, CC, '#1b9e77'], shared=sh2, ylabel='% of lung area', title='Suppl. Fig. 2d burden (n=6/arm)')
strip(axs[3], [col(ws, c, 14, 19) for c in 'CDE'], lab, [CV, CC, '#1b9e77'], shared=sh2, ylabel='count', title='Suppl. Fig. 2d foci')
for ax in axs: ax.set_ylim(bottom=0)
fig.legend(handles=[Line2D([], [], marker='D', color='w', markerfacecolor='white', markeredgecolor='k', markeredgewidth=1.5, label='open diamonds: the same values (burden and foci) appear in both Fig. 6b and Suppl. Fig. 2d (3 vehicle + 3 creatine animals)'),
                    Line2D([], [], color='k', lw=1.4, label='group mean')], loc='lower center', ncol=2, frameon=False, fontsize=8.5)
fig.suptitle('Pharmacology on the metastasis endpoint: systemic STAT5A/B inhibitor (left) and aspirin-treated donor platelets (right)', x=0.01, ha='left', fontsize=11, fontweight='bold')
fig.tight_layout(rect=(0, 0.08, 1, 0.93)); fig.savefig(os.path.join(FIG, 'Fig2_STAT5_inhibitor_and_aspirin.png')); plt.close(fig)

# --------------------------------------------------------------------------- Figure 3: MK gene panel heat map
G = pd.read_csv(os.path.join(TAB, 'T4_MK_gene_panel_by_gene.csv'))
order = [('Fig. 2f', 'creatine', 'creatine\n(2f)'), ('Fig. 3f', 'Cre-ctrl creatine', 'creatine\n(3f)'), ('Fig. 4h', 'creatine', 'creatine\nin vitro\n(4h)'), ('Fig. 4j', 'creatine + si-scr', 'creatine\nin vitro\n(4j)'), ('Fig. 6a', 'creatine', 'creatine\n(6a)'), ('Fig. 6g', 'WT creatine', 'creatine\n(6g)'),
         ('Fig. 3f', 'Slc6a8-cKO vehicle', 'Slc6a8-cKO\nalone\n(3f)'), ('Fig. 3f', 'Slc6a8-cKO creatine', 'Slc6a8-cKO\n+ creatine\n(3f)'), ('Suppl. Fig. 4e', 'Slc6a8-cKO MK + creatine', 'cKO MKs\n+ creatine\n(S4e)'), ('Suppl. Fig. 4e', 'Slc6a8-cKO MK + liposomal creatine', 'cKO MKs\n+ liposomal\ncreatine\n(S4e)'),
         ('Fig. 4j', 'si-Ckb', 'si-Ckb\nalone\n(4j)'), ('Fig. 4j', 'creatine + si-Ckb', 'si-Ckb\n+ creatine\n(4j)'), ('Fig. 4l', 'CKB over-expression', 'CKB over-\nexpression\n(4l)'), ('Fig. 4h', 'phosphocreatine', 'phospho-\ncreatine\n(4h)'),
         ('Fig. 6a', 'STAT5-IN-1', 'STAT5-IN-1\nalone\n(6a)'), ('Fig. 6a', 'creatine + STAT5-IN-1', 'STAT5-IN-1\n+ creatine\n(6a)'), ('Fig. 6g', 'Stat5b-cKO creatine', 'Stat5b-cKO\n+ creatine\n(6g)')]
genes = ['Itga2b', 'P2ry12', 'Gp6', 'Gpiba', 'F2r', 'Adra2a', 'Fcgr2a', 'Runx1', 'Rab4a', 'Rab27b', 'Pitpnb']
M = np.array([[G[(G.panel == p) & (G.arm == a) & (G.gene == g)].geo_mean_fold_vs_first_arm.iloc[0] for (p, a, _) in order] for g in genes])
M = np.vstack([M, 2 ** np.log2(M).mean(axis=0)])
fig, ax = plt.subplots(figsize=(14, 6.4))
im = ax.imshow(np.log2(M), cmap='RdBu_r', vmin=-3, vmax=3, aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        ax.text(j, i, f'{M[i, j]:.1f}' if M[i, j] < 10 else f'{M[i, j]:.0f}', ha='center', va='center', fontsize=7.5, color='white' if abs(np.log2(M[i, j])) > 1.9 else 'k', fontweight='bold' if i == M.shape[0] - 1 else 'normal')
ax.set_xticks(range(len(order))); ax.set_xticklabels([o[2] for o in order], fontsize=7.3)
ax.set_yticks(range(len(genes) + 1)); ax.set_yticklabels(genes + ['panel geo-mean'], fontsize=8.5)
ax.get_yticklabels()[-1].set_fontweight('bold')
for x in (5.5, 9.5, 13.5): ax.axvline(x, color='k', lw=1.5)
ax.axhline(len(genes) - 0.5, color='k', lw=1.2)
for x, t in [(2.5, 'creatine, unperturbed cells (6 experiments)'), (7.5, 'SLC6A8 node'), (11.5, 'CKB node'), (15, 'STAT5 node')]:
    ax.text(x, -0.62, t, ha='center', va='bottom', fontsize=9, fontweight='bold')
for sp in ax.spines.values(): sp.set_visible(True)
cb = fig.colorbar(im, ax=ax, fraction=0.018, pad=0.01); cb.set_label('log2 fold vs the control arm of the same experiment')
fig.suptitle("Megakaryocyte platelet-activation transcript panel: geometric-mean fold change vs each experiment's own control arm (n=3 per arm)", x=0.01, ha='left', fontsize=11, fontweight='bold')
fig.text(0.01, 0.012, 'Control arm = vehicle/control of the same sheet (for S4e: untreated Slc6a8-cKO MKs). There is no vehicle-treated Stat5b-cKO arm anywhere in the workbook; the right-most column is the only Stat5b-cKO condition.', fontsize=8, style='italic', color='#333333')
fig.tight_layout(rect=(0, 0.03, 1, 0.95)); fig.savefig(os.path.join(FIG, 'Fig3_MK_gene_panel_heatmap.png')); plt.close(fig)

# --------------------------------------------------------------------------- Figure 4: healthy-volunteer cohort
fig = plt.figure(figsize=(13.6, 7.0)); gs = fig.add_gridspec(2, 5)
ws = WB['Fig. 7b']; cr = np.array([col(ws, c, 4, 14) for c in 'BCDE']).T; days = [0, 3, 7, 14]
ax = fig.add_subplot(gs[0, 0])
for i in range(11): ax.plot(days, cr[i], '-o', color='#999999', ms=3, lw=0.8)
ax.plot(days, cr.mean(0), '-o', color='k', lw=2, ms=5); ax.set_xticks(days); ax.set_ylabel('serum creatine (µM)'); ax.set_xlabel('day'); ax.set_title('Exposure (Fig. 7b, n=11)', loc='left'); ax.set_ylim(0, 230)
ws = WB['Fig. 7c']; T5 = pd.read_csv(os.path.join(TAB, 'T5_human_platelet_function.csv'))
for k, (ag, lab, r0, r1) in enumerate([('collagen', 'Collagen', 4, 14), ('epinephrine', 'Epinephrine', 46, 56), ('arachidonic acid', 'Arachidonic acid', 88, 98), ('ADP', 'ADP', 130, 140)]):
    ax = fig.add_subplot(gs[0, k + 1]); M = np.array([col(ws, c, r0, r1) for c in 'BCDE']).T
    for i in range(11): ax.plot(days, M[i], '-o', color='#bbbbbb', ms=3, lw=0.8)
    ax.plot(days, np.median(M, 0), '-o', color='#d95f02', lw=2.2, ms=5)
    ax.set_yscale('log', base=2); ax.set_ylim(0.09, 40); ax.set_yticks([0.125, 0.25, 0.5, 1, 2, 4, 8, 16]); ax.set_yticklabels(['1/8', '1/4', '1/2', '1', '2', '4', '8', '16'])
    ax.axhline(1, color='k', lw=0.6, ls=':'); ax.set_xticks(days); ax.set_xlabel('day')
    t = T5[(T5.agonist == ag) & (T5.readout == 'max aggregation')].set_index('day')
    ax.set_title(f'{lab} (Fig. 7c, n=11)', loc='left')
    ax.text(0.03, 0.98, f"day 14: median ×{t.loc[14, 'median_fold']:.2f}, {int(t.loc[14, 'n_up'])}/11 up\nWilcoxon P = {t.loc[14, 'wilcoxon_signed_rank_p']:.3f} (Holm {t.loc[14, 'holm_p_within_day_12_endpoints']:.2f})", transform=ax.transAxes, fontsize=7.6, va='top')
    if k == 0: ax.set_ylabel('max aggregation, fold vs own day 0')
ws = WB['Fig. 7e']
for k, (nm, r0) in enumerate([('GP6 / β-actin (Fig. 7e, n=4)', 4), ('P2RY12 / β-actin (Fig. 7e, n=4)', 12)]):
    ax = fig.add_subplot(gs[1, k]); M = np.array([col(ws, c, r0, r0 + 3) for c in 'BCDE']).T
    for i in range(4): ax.plot(days, M[i], '-o', ms=3.5, lw=0.9, color='#999999')
    ax.plot(days, M.mean(0), '-o', color='k', lw=2.2, ms=5); ax.set_xticks(days); ax.set_xlabel('day'); ax.set_ylim(0, 1.6)
    ax.set_title(nm, loc='left')
    if k == 0: ax.set_ylabel('platelet immunoblot densitometry ratio')
Tq = pd.read_csv(os.path.join(TAB, 'T5d_human_CD41_cell_transcripts.csv'))
ax = fig.add_subplot(gs[1, 2:]); gl = ['ITGA2B', 'P2RY12', 'GP6', 'GPIBA', 'F2R', 'ADRA2A (sheet label "ADAR2A")', 'FCGR2A', 'RUNX1', 'RAB4A', 'RAB27B', 'PITPNB']
cols = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
for gi, g in enumerate(gl):
    for di, day in enumerate([7, 14]):
        sub = Tq[(Tq.gene == g) & (Tq.day == day)].sort_values('volunteer')
        x = gi + (-0.2 if day == 7 else 0.2)
        for v in range(4):
            ax.scatter(x + (v - 1.5) * 0.06, sub.fold_recomputed_from_dCT.iloc[v], s=18, color=cols[v], marker='o' if day == 7 else 's', edgecolor='k', linewidth=0.3, zorder=3)
        ax.hlines(2 ** np.log2(sub.fold_recomputed_from_dCT).mean(), x - 0.17, x + 0.17, color='k', lw=1.3)
ax.set_yscale('log', base=2); ax.set_ylim(0.008, 64); ax.set_yticks([1 / 32, 1 / 8, 0.5, 1, 2, 8, 32]); ax.set_yticklabels(['1/32', '1/8', '1/2', '1', '2', '8', '32']); ax.axhline(1, color='k', lw=0.6, ls=':')
ax.set_xticks(range(len(gl))); ax.set_xticklabels([g.split(' ')[0] for g in gl], fontsize=7.5, rotation=30, ha='right'); ax.set_ylabel('fold vs own day 0')
ax.set_title('Circulating CD41+ cell transcripts (Fig. 7d, n=4), recomputed from the ΔCT rows', loc='left')
hd = [Line2D([], [], marker='o', color='w', markerfacecolor='#888888', markeredgecolor='k', label='day 7'), Line2D([], [], marker='s', color='w', markerfacecolor='#888888', markeredgecolor='k', label='day 14'), Line2D([], [], color='k', lw=1.3, label='geo-mean')] + \
     [Line2D([], [], marker='o', color='w', markerfacecolor=cols[v], markeredgecolor='k', label=f'Volunteer {v+1}') for v in range(4)]
ax.legend(handles=hd, ncol=7, fontsize=7, frameon=False, loc='lower left', columnspacing=1.0, handletextpad=0.2)
fig.suptitle('Healthy-volunteer cohort: 20 g/day creatine for 14 days, open-label, no placebo arm; each subject is their own day-0 control', x=0.01, ha='left', fontsize=11, fontweight='bold')
fig.text(0.01, 0.008, 'Orange line = median of 11; black line = mean. RAB27B and PITPNB, Volunteer 4: the sheet\'s "After normalization" values do not reproduce from its own ΔCT rows\n(PITPNB Volunteer-4 ΔCT entries are on a different scale, +26 to +28); the recomputed values are plotted and should be treated as unverified.', fontsize=7.6, style='italic', color='#333333')
fig.tight_layout(rect=(0, 0.05, 1, 0.95)); fig.savefig(os.path.join(FIG, 'Fig4_healthy_volunteer_cohort.png')); plt.close(fig)
print('figures written to', os.path.abspath(FIG))
