#!/usr/bin/env python
"""
CRE-MK-01 re-analysis, part 2: the analyses the target ranking rests on.
Writes tables T2..T8 to ../tables.   Run:  micromamba run -n chem python 02_decision_analyses.py   (set CRE_DIR to the folder holding the supplied files)
All numbers are computed from CRE-MK-01_source_data.xlsx / CRE-MK-01_phosphoproteomics.xlsx only.
"""
import os, itertools, collections, warnings, math
import numpy as np, pandas as pd, openpyxl
from scipy import stats
from scipy.stats import studentized_range
from openpyxl.utils import column_index_from_string, get_column_letter
import statsmodels.formula.api as smf, statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
warnings.filterwarnings('ignore')

D = os.environ.get('CRE_DIR', '/tmp/world/filesystem')
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tables'); os.makedirs(OUT, exist_ok=True)
WB = openpyxl.load_workbook(os.path.join(D, 'CRE-MK-01_source_data.xlsx'), data_only=True)
def col(ws, c, r0, r1): return np.array([float(ws[f'{c}{r}'].value) for r in range(r0, r1 + 1) if ws[f'{c}{r}'].value is not None])
def row(ws, r, c0, c1):
    a, b = column_index_from_string(c0), column_index_from_string(c1)
    return np.array([float(ws.cell(row=r, column=c).value) for c in range(a, b + 1) if ws.cell(row=r, column=c).value is not None])
def gmean(x): return float(np.exp(np.mean(np.log(x))))

# =====================================================================================================
# T2. Creatine effect on lung metastasis, every experiment (effect sizes on ratio scale)
# =====================================================================================================
E = []
def eff(label, context, sheet, vc, cc, r0, r1, endpoint, cells):
    ws = WB[sheet]; v, c = col(ws, vc, r0, r1), col(ws, cc, r0, r1)
    lv, lc = np.log(v), np.log(c); d = lc.mean() - lv.mean()
    se = np.sqrt(lv.var(ddof=1) / len(v) + lc.var(ddof=1) / len(c)); df = len(v) + len(c) - 2; tc = stats.t.ppf(.975, df)
    E.append(dict(experiment=label, host_context=context, endpoint=endpoint, cells=f"'{sheet}'!{cells}", n_control=len(v), n_creatine=len(c),
                  mean_control=v.mean(), mean_creatine=c.mean(), ratio_of_means=c.mean() / v.mean(),
                  geo_ratio=np.exp(d), geo_ratio_lo95=np.exp(d - tc * se), geo_ratio_hi95=np.exp(d + tc * se),
                  t_test_p=stats.ttest_ind(v, c).pvalue, mann_whitney_p=stats.mannwhitneyu(v, c).pvalue,
                  sd_log_control=lv.std(ddof=1), sd_log_creatine=lc.std(ddof=1), log_ratio=d, se_log_ratio=se))
X = [('Fig. 1b', 'intact host', 'Fig. 1b', 'B', 'C', 3, 8, 'burden %', 'B3:C8'), ('Fig. 1b', 'intact host', 'Fig. 1b', 'B', 'C', 12, 17, 'foci', 'B12:C17'),
     ('Fig. 1f sh-scrambled tumour', 'intact host', 'Fig. 1f', 'B', 'C', 22, 27, 'burden %', 'B22:C27'), ('Fig. 1f sh-scrambled tumour', 'intact host', 'Fig. 1f', 'B', 'C', 31, 36, 'foci', 'B31:C36'),
     ('Fig. 1f sh-Slc6a8 tumour', 'intact host, tumour Slc6a8 knock-down', 'Fig. 1f', 'D', 'E', 22, 27, 'burden %', 'D22:E27'), ('Fig. 1f sh-Slc6a8 tumour', 'intact host, tumour Slc6a8 knock-down', 'Fig. 1f', 'D', 'E', 31, 36, 'foci', 'D31:E36'),
     ('Fig. 1k', 'intact host', 'Fig. 1k', 'B', 'C', 4, 9, 'burden %', 'B4:C9'), ('Fig. 1k', 'intact host', 'Fig. 1k', 'B', 'C', 12, 17, 'foci', 'B12:C17'),
     ('Fig. 3i Pf4-Cre;Slc6a8+/+', 'intact host (Cre control)', 'Fig. 3i', 'B', 'C', 10, 13, 'burden %', 'B10:C13'), ('Fig. 3i Pf4-Cre;Slc6a8+/+', 'intact host (Cre control)', 'Fig. 3i', 'B', 'C', 17, 20, 'foci', 'B17:C20'),
     ('Fig. 3i Pf4-Cre;Slc6a8fl/fl', 'MK-lineage Slc6a8 knock-out', 'Fig. 3i', 'D', 'E', 10, 13, 'burden %', 'D10:E13'), ('Fig. 3i Pf4-Cre;Slc6a8fl/fl', 'MK-lineage Slc6a8 knock-out', 'Fig. 3i', 'D', 'E', 17, 20, 'foci', 'D17:E20'),
     ('Fig. 6b no inhibitor', 'intact host', 'Fig. 6b', 'B', 'C', 4, 8, 'burden %', 'B4:C8'), ('Fig. 6b no inhibitor', 'intact host', 'Fig. 6b', 'B', 'C', 13, 17, 'foci', 'B13:C17'),
     ('Fig. 6b + STAT5-IN-1', 'systemic STAT5A/B inhibitor', 'Fig. 6b', 'D', 'E', 4, 8, 'burden %', 'D4:E8'), ('Fig. 6b + STAT5-IN-1', 'systemic STAT5A/B inhibitor', 'Fig. 6b', 'D', 'E', 13, 17, 'foci', 'D13:E17'),
     ('Suppl. Fig. 1e', 'intact host', 'Supplementary Fig  1e', 'B', 'C', 13, 18, 'burden %', 'B13:C18'), ('Suppl. Fig. 1e', 'intact host', 'Supplementary Fig  1e', 'B', 'C', 22, 27, 'foci', 'B22:C27'),
     ('Suppl. Fig. 1f', 'intact host', 'Supplementary Fig  1f', 'B', 'C', 12, 15, 'burden %', 'B12:C15'), ('Suppl. Fig. 1f', 'intact host', 'Supplementary Fig  1f', 'B', 'C', 20, 23, 'foci', 'B20:C23'),
     ('Suppl. Fig. 1g', 'intact host', 'Supplementary Fig  1g', 'B', 'C', 15, 24, 'burden %', 'B15:C24'), ('Suppl. Fig. 1g', 'intact host', 'Supplementary Fig  1g', 'B', 'C', 28, 37, 'foci', 'B28:C37'),
     ('Suppl. Fig. 1i (5% creatine diet)', 'intact host', 'Supplementary Fig  1i', 'B', 'C', 11, 14, 'burden %', 'B11:C14'), ('Suppl. Fig. 1i (5% creatine diet)', 'intact host', 'Supplementary Fig  1i', 'B', 'C', 18, 21, 'foci', 'B18:C21'),
     ('Suppl. Fig. 1k', 'intact host', 'Supplementary Fig  1k', 'B', 'C', 16, 25, 'burden %', 'B16:C25'), ('Suppl. Fig. 1k', 'intact host', 'Supplementary Fig  1k', 'B', 'C', 29, 38, 'foci', 'B29:C38'),
     ('Suppl. Fig. 2d donor platelets (veh vs creatine donors)', 'platelet transfer', 'Supplementary Fig  2d', 'C', 'D', 5, 10, 'burden %', 'C5:D10'), ('Suppl. Fig. 2d donor platelets (veh vs creatine donors)', 'platelet transfer', 'Supplementary Fig  2d', 'C', 'D', 14, 19, 'foci', 'C14:D19'),
     ('Fig. 7g human donor platelets (d0 vs d7)', 'human platelet transfer', 'Fig. 7g', 'B', 'C', 12, 16, 'burden %', 'B12:C16'), ('Fig. 7g human donor platelets (d0 vs d7)', 'human platelet transfer', 'Fig. 7g', 'B', 'C', 19, 23, 'foci', 'B19:C23')]
for x in X: eff(*x)
T2 = pd.DataFrame(E)
def DL(sub):
    d, se = sub.log_ratio.values, sub.se_log_ratio.values; w = 1 / se ** 2; mu = (w * d).sum() / w.sum(); Q = (w * (d - mu) ** 2).sum(); k = len(d)
    tau2 = max(0, (Q - (k - 1)) / (w.sum() - (w ** 2).sum() / w.sum())); w2 = 1 / (se ** 2 + tau2); m = (w2 * d).sum() / w2.sum(); s = np.sqrt(1 / w2.sum())
    return k, np.exp(m), np.exp(m - 1.96 * s), np.exp(m + 1.96 * s), max(0, (Q - (k - 1)) / Q)
pooled = []
for ep in ['burden %', 'foci']:
    sub = T2[(T2.host_context.str.startswith('intact host')) & (T2.endpoint == ep)]
    k, m, lo, hi, I2 = DL(sub); pooled.append(dict(endpoint=ep, k_experiments=k, pooled_geo_ratio=m, lo95=lo, hi95=hi, I2=I2,
                                                   median_sd_log_within_group=np.median(np.r_[sub.sd_log_control, sub.sd_log_creatine])))
T2.drop(columns=['log_ratio', 'se_log_ratio']).to_csv(os.path.join(OUT, 'T2_creatine_effect_on_metastasis_by_experiment.csv'), index=False)
pd.DataFrame(pooled).to_csv(os.path.join(OUT, 'T2b_pooled_creatine_effect_random_effects.csv'), index=False)
print(pd.DataFrame(pooled).round(3).to_string())

# =====================================================================================================
# T3. Factorial (interaction) analyses for each perturbation experiment
# =====================================================================================================
F = []
def twoway(label, cells, g, A, B, log=False, note=''):
    rows = [dict(A=a, B=b, y=(np.log(x) if log else x)) for (a, b), v in g.items() for x in v]
    an = sm.stats.anova_lm(smf.ols('y ~ C(A)*C(B)', data=pd.DataFrame(rows)).fit(), typ=2)
    m = {k: (np.log(v).mean() if log else v.mean()) for k, v in g.items()}
    e0 = m[(A[0], B[1])] - m[(A[0], B[0])]; e1 = m[(A[1], B[1])] - m[(A[1], B[0])]
    F.append(dict(experiment=label, cells=cells, scale='log' if log else 'linear', n_per_cell='/'.join(str(len(v)) for v in g.values()),
                  **{f'mean[{a}|{b}]': (np.exp(m[(a, b)]) if log else m[(a, b)]) for a in A for b in B},
                  creatine_effect_in_reference=(np.exp(e0) if log else e0), creatine_effect_in_perturbed=(np.exp(e1) if log else e1),
                  attenuation_pct=(100 * (1 - e1 / e0)), interaction_p=an.loc['C(A):C(B)', 'PR(>F)'],
                  perturbation_alone_vs_reference_p=stats.ttest_ind(g[(A[0], B[0])], g[(A[1], B[0])]).pvalue, note=note))
ws = WB['Fig. 3i']
for nm, r0, cells in [('Fig. 3i lung weight (g)', 3, 'B3:E6'), ('Fig. 3i metastatic burden (%)', 10, 'B10:E13'), ('Fig. 3i metastatic foci', 17, 'B17:E20')]:
    g = {('Cre-ctrl', 'veh'): col(ws, 'B', r0, r0 + 3), ('Cre-ctrl', 'cre'): col(ws, 'C', r0, r0 + 3), ('Slc6a8-cKO', 'veh'): col(ws, 'D', r0, r0 + 3), ('Slc6a8-cKO', 'cre'): col(ws, 'E', r0, r0 + 3)}
    for lg in (False, True): twoway(nm, cells, g, ('Cre-ctrl', 'Slc6a8-cKO'), ('veh', 'cre'), lg)
ws = WB['Fig. 3d']
for nm, r in [('Fig. 3d ADP aggregation', 4), ('Fig. 3d collagen aggregation', 5), ('Fig. 3d thrombin aggregation', 6)]:
    g = {('Cre-ctrl', 'veh'): row(ws, r, 'B', 'D'), ('Cre-ctrl', 'cre'): row(ws, r, 'E', 'G'), ('Slc6a8-cKO', 'veh'): row(ws, r, 'H', 'J'), ('Slc6a8-cKO', 'cre'): row(ws, r, 'K', 'M')}
    twoway(nm, f'B{r}:M{r}', g, ('Cre-ctrl', 'Slc6a8-cKO'), ('veh', 'cre'), note='values quantised in steps of 2; n unit not stated')
ws = WB['Fig. 3c']
g = {('Cre-ctrl', 'veh'): row(ws, 4, 'B', 'D'), ('Cre-ctrl', 'cre'): row(ws, 4, 'E', 'G'), ('Slc6a8-cKO', 'veh'): row(ws, 5, 'B', 'D'), ('Slc6a8-cKO', 'cre'): row(ws, 5, 'E', 'G')}
for lg in (False, True): twoway('Fig. 3c MK intracellular creatine (umol/g)', 'B4:G5', g, ('Cre-ctrl', 'Slc6a8-cKO'), ('veh', 'cre'), lg)
ws = WB['Fig. 3b']
g = {('Cre-ctrl', 'veh'): row(ws, 4, 'B', 'F'), ('Cre-ctrl', 'cre'): row(ws, 4, 'G', 'K'), ('Slc6a8-cKO', 'veh'): row(ws, 5, 'B', 'F'), ('Slc6a8-cKO', 'cre'): row(ws, 5, 'G', 'K')}
twoway('Fig. 3b serum creatine (uM)', 'B4:K5', g, ('Cre-ctrl', 'Slc6a8-cKO'), ('veh', 'cre'))
ws = WB['Supplementary Fig  4c']
g = {('Cre-ctrl', 'veh'): col(ws, 'C', 6, 13), ('Cre-ctrl', 'cre'): col(ws, 'D', 6, 13), ('Slc6a8-cKO', 'veh'): col(ws, 'E', 6, 13), ('Slc6a8-cKO', 'cre'): col(ws, 'F', 6, 13)}
twoway('Suppl. Fig. 4c platelet alpha-granules', 'C6:F13', g, ('Cre-ctrl', 'Slc6a8-cKO'), ('veh', 'cre'), note='n = 8 random fields per group, not animals')
ws = WB['Supplementary Fig  4b']
g = {('Cre-ctrl', 'veh'): col(ws, 'C', 5, 7), ('Cre-ctrl', 'cre'): col(ws, 'D', 5, 7), ('Slc6a8-cKO', 'veh'): col(ws, 'E', 5, 7), ('Slc6a8-cKO', 'cre'): col(ws, 'F', 5, 7)}
twoway('Suppl. Fig. 4b platelet count', 'C5:F7', g, ('Cre-ctrl', 'Slc6a8-cKO'), ('veh', 'cre'))
ws = WB['Fig. 6b']
for nm, r0, r1 in [('Fig. 6b metastatic burden (%)', 4, 8), ('Fig. 6b metastatic foci', 13, 17)]:
    g = {('no inhibitor', 'veh'): col(ws, 'B', r0, r1), ('no inhibitor', 'cre'): col(ws, 'C', r0, r1), ('STAT5-IN-1', 'veh'): col(ws, 'D', r0, r1), ('STAT5-IN-1', 'cre'): col(ws, 'E', r0, r1)}
    for lg in (False, True): twoway(nm, f'B{r0}:E{r1}', g, ('no inhibitor', 'STAT5-IN-1'), ('veh', 'cre'), lg)
    g2 = {k: (np.delete(v, [1, 2, 3]) if k[0] == 'no inhibitor' else v) for k, v in g.items()}
    twoway(nm + ' - SENSITIVITY: rows shared with Suppl. Fig. 2d removed', f'B{r0}:E{r1} minus rows {r0+1}-{r0+3} of B,C', g2, ('no inhibitor', 'STAT5-IN-1'), ('veh', 'cre'),
           note='only 2 unique animals remain in each no-inhibitor arm')
ws = WB['Fig. 1f']
for nm, r0 in [('Fig. 1f lung weight (g)', 4), ('Fig. 1f SUV-BW', 13), ('Fig. 1f metastatic burden (%)', 22), ('Fig. 1f metastatic foci', 31)]:
    g = {('sh-scrambled tumour', 'veh'): col(ws, 'B', r0, r0 + 5), ('sh-scrambled tumour', 'cre'): col(ws, 'C', r0, r0 + 5), ('sh-Slc6a8 tumour', 'veh'): col(ws, 'D', r0, r0 + 5), ('sh-Slc6a8 tumour', 'cre'): col(ws, 'E', r0, r0 + 5)}
    twoway(nm, f'B{r0}:E{r0+5}', g, ('sh-scrambled tumour', 'sh-Slc6a8 tumour'), ('veh', 'cre'))
for sh in ['Fig. 5e', 'Fig. 5f']:
    ws = WB[sh]
    g = {('WT', 'veh'): col(ws, 'N', 4, 6), ('WT', 'cre'): col(ws, 'N', 17, 19), ('S127A', 'veh'): col(ws, 'O', 4, 6), ('S127A', 'cre'): col(ws, 'O', 17, 19)}
    twoway(f'{sh} STAT5B-FLAG pan-phospho/FLAG: WT vs S127A', 'N4:O6, N17:O19', g, ('WT', 'S127A'), ('veh', 'cre'),
           note=f"WT veh vs cre t-test p={stats.ttest_ind(g[('WT','veh')], g[('WT','cre')]).pvalue:.3g}; immunoblot densitometry, vehicle and creatine sets analysed as separate ANOVAs in the workbook")
T3 = pd.DataFrame(F); T3.to_csv(os.path.join(OUT, 'T3_factorial_interaction_analyses.csv'), index=False)

# assumption-free check for the two metastasis experiments: exact Mann-Whitney tests on the key pairwise contrasts
NP = []
def np_row(label, a, b, what):
    u = stats.mannwhitneyu(a, b, alternative='two-sided', method='exact')
    sep = bool(a.max() < b.min() or b.max() < a.min())
    NP.append(dict(experiment=label, contrast=what, n=f'{len(a)}/{len(b)}', exact_mann_whitney_p=u.pvalue, complete_separation=sep,
                   smallest_p_possible_at_this_n=2 / math.comb(len(a) + len(b), len(a))))
ws = WB['Fig. 3i']
for nm, r0 in [('Fig. 3i lung weight', 3), ('Fig. 3i metastatic burden', 10), ('Fig. 3i metastatic foci', 17)]:
    g = [col(ws, c, r0, r0 + 3) for c in 'BCDE']
    np_row(nm, g[0], g[1], 'Cre-ctrl: vehicle vs creatine'); np_row(nm, g[1], g[3], 'creatine: Cre-ctrl vs Slc6a8-cKO'); np_row(nm, g[2], g[3], 'Slc6a8-cKO: vehicle vs creatine'); np_row(nm, g[0], g[2], 'vehicle: Cre-ctrl vs Slc6a8-cKO')
ws = WB['Fig. 6b']
for nm, r0 in [('Fig. 6b metastatic burden', 4), ('Fig. 6b metastatic foci', 13)]:
    g = [col(ws, c, r0, r0 + 4) for c in 'BCDE']
    np_row(nm, g[0], g[1], 'no inhibitor: vehicle vs creatine'); np_row(nm, g[1], g[3], 'creatine: no inhibitor vs STAT5-IN-1'); np_row(nm, g[2], g[3], 'STAT5-IN-1: vehicle vs creatine'); np_row(nm, g[0], g[2], 'vehicle: no inhibitor vs STAT5-IN-1')
pd.DataFrame(NP).to_csv(os.path.join(OUT, 'T3c_exact_rank_tests_metastasis.csv'), index=False)
print(pd.DataFrame(NP).round(4).to_string())

# Supplementary Fig 2d (3 arms; no aspirin-alone arm) incl. sensitivity to the rows shared with Fig. 6b
ws = WB['Supplementary Fig  2d']; S2 = []
for nm, r0 in [('metastatic burden (%)', 5), ('metastatic foci', 14)]:
    v, c, a = col(ws, 'C', r0, r0 + 5), col(ws, 'D', r0, r0 + 5), col(ws, 'E', r0, r0 + 5)
    for lab, sl in [('all rows (n=6/arm)', slice(0, 6)), ('rows 1-3 only (not shared with Fig. 6b; n=3/arm)', slice(0, 3)), ('rows 4-6 only (vehicle & creatine values identical to Fig. 6b; n=3/arm)', slice(3, 6))]:
        S2.append(dict(endpoint=nm, subset=lab, mean_vehicle_PLT=v[sl].mean(), mean_creatine_PLT=c[sl].mean(), mean_creatine_aspirin_PLT=a[sl].mean(),
                       anova_p=stats.f_oneway(v[sl], c[sl], a[sl]).pvalue, creatine_vs_vehicle_t_p=stats.ttest_ind(v[sl], c[sl]).pvalue,
                       creatine_vs_creatine_aspirin_t_p=stats.ttest_ind(c[sl], a[sl]).pvalue,
                       aspirin_attenuation_pct=100 * (1 - (a[sl].mean() - v[sl].mean()) / (c[sl].mean() - v[sl].mean()))))
    S2.append(dict(endpoint=nm, subset='batch check: rows 1-3 vs rows 4-6 within arm (t-test p)', mean_vehicle_PLT=stats.ttest_ind(v[:3], v[3:]).pvalue,
                   mean_creatine_PLT=stats.ttest_ind(c[:3], c[3:]).pvalue, mean_creatine_aspirin_PLT=stats.ttest_ind(a[:3], a[3:]).pvalue))
pd.DataFrame(S2).to_csv(os.path.join(OUT, 'T3b_aspirin_donor_platelet_experiment.csv'), index=False)

# =====================================================================================================
# T4. Megakaryocyte 11-gene "platelet activation" qPCR panel across every perturbation
# =====================================================================================================
def parse_qpcr(sheet, gene_col='A'):
    ws = WB[sheet]; out = collections.OrderedDict()
    for r in range(1, ws.max_row + 1):
        g = ws[f'{gene_col}{r}'].value
        if not isinstance(g, str): continue
        labs = [c for c in range(1, ws.max_column + 1) if isinstance(ws.cell(row=r, column=c).value, str) and ws.cell(row=r, column=c).value.startswith('ΔCT')]
        if not labs: continue
        ctrl = None
        for c in range(1, ws.max_column + 1):
            if ws.cell(row=r + 3, column=c).value == 'After normalization':
                ctrl = np.array([ws.cell(row=r + 3, column=c + k).value for k in (1, 2, 3)], float)
        groups = [np.array([ws.cell(row=r + 3, column=c + k).value for k in (1, 2, 3)], float) for c in labs]
        # internal arithmetic check: fold == 2^(dCT_treated - dCT_control)
        for c, f in zip(labs, groups):
            d1 = np.array([ws.cell(row=r, column=c + k).value for k in (1, 2, 3)], float); d2 = np.array([ws.cell(row=r + 1, column=c + k).value for k in (1, 2, 3)], float)
            assert np.allclose(f, 2 ** (d2 - d1), rtol=2e-3), (sheet, g)
        out[g.strip()] = [ctrl] + groups
    return out
PANELS = [('Fig. 2f', ['vehicle', 'creatine'], 'MKs from dosed mice'),
          ('Fig. 3f', ['Cre-ctrl vehicle', 'Cre-ctrl creatine', 'Slc6a8-cKO vehicle', 'Slc6a8-cKO creatine'], 'MKs from dosed mice'),
          ('Fig. 4h', ['control', 'creatine', 'phosphocreatine'], 'MKs in vitro'),
          ('Fig. 4j', ['si-scr', 'si-Ckb', 'creatine + si-scr', 'creatine + si-Ckb'], 'MKs in vitro'),
          ('Fig. 4l', ['empty vector', 'CKB over-expression'], 'MKs in vitro'),
          ('Fig.6a', ['vehicle', 'creatine', 'STAT5-IN-1', 'creatine + STAT5-IN-1'], 'MKs from dosed mice'),
          ('Fig. 6g', ['WT vehicle', 'WT creatine', 'Stat5b-cKO creatine'], 'MKs from dosed mice'),
          ('Supplementary Fig  4e', ['Slc6a8-cKO MK control', 'Slc6a8-cKO MK + creatine', 'Slc6a8-cKO MK + liposomal creatine'], 'MKs in vitro')]
G = []; PANEL_SUMMARY = []
def tukey_p(groups, i, j):
    k = len(groups); N = sum(len(g) for g in groups); dfe = N - k; mse = sum(((g - g.mean()) ** 2).sum() for g in groups) / dfe
    d = groups[i].mean() - groups[j].mean(); se = np.sqrt(mse / 2 * (1 / len(groups[i]) + 1 / len(groups[j])))
    return float(studentized_range.sf(abs(d) / se, k, dfe))
for sheet, names, material in PANELS:
    q = parse_qpcr(sheet); per_arm = collections.defaultdict(list)
    for gene, groups in q.items():
        lg = [np.log2(x) for x in groups]
        for i, nm in enumerate(names):
            rec = dict(panel=sheet.replace('Supplementary Fig  ', 'Suppl. Fig. ').replace('Fig.6a', 'Fig. 6a'), material=material, gene=gene, arm=nm, n=len(groups[i]),
                       geo_mean_fold_vs_first_arm=2 ** lg[i].mean(), arithmetic_mean_fold=groups[i].mean(), values='; '.join(f'{v:.3g}' for v in groups[i]))
            if i > 0:
                rec['p_vs_first_arm_log2'] = (stats.ttest_ind(lg[0], lg[i]).pvalue if len(groups) == 2 else tukey_p(lg, 0, i))
                rec['test'] = 't-test on log2' if len(groups) == 2 else 'Tukey on log2 (all arms)'
                per_arm[nm].append(lg[i].mean())
            G.append(rec)
    for nm, v in per_arm.items():
        v = np.array(v)
        PANEL_SUMMARY.append(dict(panel=sheet.replace('Supplementary Fig  ', 'Suppl. Fig. ').replace('Fig.6a', 'Fig. 6a'), material=material, arm=nm, reference_arm=names[0], n_genes=len(v),
                                  panel_geo_mean_fold=2 ** v.mean(), genes_up=int((v > 0).sum()), genes_ge_1p5x=int((2 ** v >= 1.5).sum()), genes_le_0p67x=int((2 ** v <= 1 / 1.5).sum()),
                                  wilcoxon_p_across_genes=stats.wilcoxon(v).pvalue, one_sample_t_p_across_genes=stats.ttest_1samp(v, 0).pvalue))
pd.DataFrame(G).to_csv(os.path.join(OUT, 'T4_MK_gene_panel_by_gene.csv'), index=False)
T4 = pd.DataFrame(PANEL_SUMMARY); T4.to_csv(os.path.join(OUT, 'T4b_MK_gene_panel_summary.csv'), index=False)
print(T4.round(3).to_string())

# =====================================================================================================
# T5. Healthy-volunteer cohort
# =====================================================================================================
ws = WB['Fig. 7b']; cr = np.array([col(ws, c, 4, 14) for c in 'BCDE']).T
ws = WB['Fig. 7c']
B7C = [('collagen', 'max aggregation', 4, 14), ('collagen', 'average aggregation', 18, 28), ('collagen', 'adhesion', 32, 42), ('epinephrine', 'max aggregation', 46, 56), ('epinephrine', 'average aggregation', 60, 70), ('epinephrine', 'adhesion', 74, 84),
       ('arachidonic acid', 'max aggregation', 88, 98), ('arachidonic acid', 'average aggregation', 102, 112), ('arachidonic acid', 'adhesion', 116, 126), ('ADP', 'max aggregation', 130, 140), ('ADP', 'average aggregation', 144, 154), ('ADP', 'adhesion', 157, 167)]
H = []; PERVOL = []
for ag, ro, r0, r1 in B7C:
    M = np.array([col(ws, c, r0, r1) for c in 'BCDE']).T
    for j, day in zip([1, 2, 3], [3, 7, 14]):
        f = M[:, j]; pos = f[f > 0]
        H.append(dict(agonist=ag, readout=ro, day=day, cells=f"'Fig. 7c'!{'CDE'[j-1]}{r0}:{'CDE'[j-1]}{r1}", n=len(f), median_fold=np.median(f), geo_mean_fold=2 ** np.log2(pos).mean(), arithmetic_mean_fold=f.mean(),
                      n_up=int((f > 1).sum()), n_down=int((f < 1).sum()), n_ge_1p5x=int((f >= 1.5).sum()), max_fold=f.max(), n_zero=int((f == 0).sum()),
                      wilcoxon_signed_rank_p=stats.wilcoxon(f - 1).pvalue, sign_test_p=stats.binomtest(int((f > 1).sum()), int((f != 1).sum()), .5).pvalue))
    if ro == 'max aggregation':
        for i in range(11): PERVOL.append(dict(volunteer_row=i + 1, agonist=ag, d3=M[i, 1], d7=M[i, 2], d14=M[i, 3]))
T5 = pd.DataFrame(H)
for day in (3, 7, 14):
    m = T5.day == day
    T5.loc[m, 'holm_p_within_day_12_endpoints'] = multipletests(T5.loc[m, 'wilcoxon_signed_rank_p'], method='holm')[1]
T5.to_csv(os.path.join(OUT, 'T5_human_platelet_function.csv'), index=False)
pv = pd.DataFrame(PERVOL).pivot(index='volunteer_row', columns='agonist', values='d14'); pv.columns = [f'd14_max_agg_fold_{c}' for c in pv.columns]
pv['serum_creatine_d0_uM'] = cr[:, 0]; pv['serum_creatine_d3_uM'] = cr[:, 1]; pv['serum_creatine_d7_uM'] = cr[:, 2]; pv['serum_creatine_d14_uM'] = cr[:, 3]
pv.to_csv(os.path.join(OUT, 'T5b_human_per_volunteer_day14.csv'))
ws = WB['Fig. 7e']; P = []
for nm, r0 in [('GP6/beta-actin (platelet immunoblot)', 4), ('P2RY12/beta-actin (platelet immunoblot)', 12)]:
    M = np.array([col(ws, c, r0, r0 + 3) for c in 'BCDE']).T
    for j, day in zip([1, 2, 3], [3, 7, 14]):
        P.append(dict(readout=nm, day=day, n=4, mean_d0=M[:, 0].mean(), mean_day=M[:, j].mean(), fold_of_means=M[:, j].mean() / M[:, 0].mean(), per_volunteer_fold='; '.join(f'{x:.2f}' for x in M[:, j] / M[:, 0]),
                      n_up=int((M[:, j] > M[:, 0]).sum()), paired_t_p=stats.ttest_rel(M[:, j], M[:, 0]).pvalue, paired_t_p_log=stats.ttest_rel(np.log(M[:, j]), np.log(M[:, 0])).pvalue))
pd.DataFrame(P).to_csv(os.path.join(OUT, 'T5c_human_platelet_protein.csv'), index=False)
ws = WB['Fig. 7d']; Tq = []
for g, r0, c0 in [('ITGA2B', 6, 'C'), ('P2RY12', 6, 'I'), ('GP6', 25, 'C'), ('GPIBA', 25, 'I'), ('F2R', 44, 'C'), ('ADRA2A (sheet label "ADAR2A")', 44, 'I'), ('FCGR2A', 63, 'C'), ('RUNX1', 63, 'I'), ('RAB4A', 82, 'C'), ('RAB27B', 82, 'I'), ('PITPNB', 100, 'C')]:
    ci = column_index_from_string(c0)
    dct = np.array([[[ws.cell(row=r0 + 1 + t * 3 + rep, column=ci + v).value for v in range(4)] for rep in range(3)] for t in range(4)], float)
    norm = np.array([[ws.cell(row=r0 + 13 + t, column=ci + v).value for v in range(4)] for t in range(4)], float)
    lin = (2 ** dct).mean(axis=1); fold = lin / lin[0]
    for t, day in zip([1, 2, 3], [3, 7, 14]):
        for v in range(4):
            Tq.append(dict(gene=g, day=day, volunteer=v + 1, fold_recomputed_from_dCT=fold[t, v], fold_in_sheet_after_normalisation=norm[t, v],
                           sheet_value_reproduces=bool(abs(fold[t, v] - norm[t, v]) <= 0.02 * abs(norm[t, v])), mean_dCT_day0=dct[0, :, v].mean(), mean_dCT_day=dct[t, :, v].mean()))
T5d = pd.DataFrame(Tq); T5d.to_csv(os.path.join(OUT, 'T5d_human_CD41_cell_transcripts.csv'), index=False)
summ = T5d.groupby(['gene', 'day']).fold_recomputed_from_dCT.agg(geo_mean=lambda x: 2 ** np.log2(x).mean(), n_ge_1p5x=lambda x: int((x >= 1.5).sum()), n_le_0p67x=lambda x: int((x <= 1 / 1.5).sum()), minimum='min', maximum='max').reset_index()
summ.to_csv(os.path.join(OUT, 'T5e_human_CD41_cell_transcripts_summary.csv'), index=False)
print('human creatine uM mean by day', cr.mean(0).round(1), '; fold of means', (cr.mean(0) / cr.mean(0)[0]).round(2))
print('Fig 7d cells whose "After normalization" value does not reproduce from dCT rows:'); print(T5d[~T5d.sheet_value_reproduces].round(3).to_string())

# =====================================================================================================
# T6. Phosphoproteomics
# =====================================================================================================
wbp = openpyxl.load_workbook(os.path.join(D, 'CRE-MK-01_phosphoproteomics.xlsx'), data_only=True); r = list(wbp.worksheets[0].iter_rows(values_only=True))
ph = pd.DataFrame(r[1:], columns=['gene', 'p', 'q', 'log2fc']); ph['rank_by_p'] = ph.p.rank(method='min').astype(int); ph['BH_q_recomputed'] = multipletests(ph.p, method='fdr_bh')[1]
screen = ph[(ph.p < 0.05) & ((ph.log2fc >= np.log2(1.2)) | (ph.log2fc <= np.log2(0.83)))]
degenerate = np.isclose(ph.p, 2 * stats.t.sf(1, 2), atol=2e-5)
S6 = [dict(metric='phosphopeptide rows', value=len(ph)), dict(metric='unique gene names', value=ph.gene.nunique()), dict(metric='rows with blank gene name', value=int(ph.gene.isna().sum())),
      dict(metric='rows with P < 0.05', value=int((ph.p < 0.05).sum())), dict(metric='expected P < 0.05 if no peptide changed (5%)', value=round(0.05 * len(ph), 1)),
      dict(metric='rows passing the stated screen (P<0.05 and FC>=1.2 or <=0.83)', value=len(screen)), dict(metric='  of which up / down', value=f'{int((screen.log2fc > 0).sum())} / {int((screen.log2fc < 0).sum())}'),
      dict(metric='minimum Q-VALUE in file', value=ph.q.min()), dict(metric='rows with Q < 0.05', value=int((ph.q < 0.05).sum())), dict(metric='rows with Q < 0.10', value=int((ph.q < 0.10).sum())),
      dict(metric='minimum Benjamini-Hochberg q (recomputed from P)', value=ph.BH_q_recomputed.min()),
      dict(metric='rows with P = 0.42265 (= t of 1 on 2 d.f.; degenerate single-replicate pattern)', value=int(degenerate.sum())),
      dict(metric='rows with an informative test (all rows minus the P = 0.42265 rows)', value=int((~degenerate).sum())),
      dict(metric='  share of informative rows with P < 0.05 (5% expected if nothing changed)', value=round(float((ph.p[~degenerate] < 0.05).mean()), 4)),
      dict(metric='rows with P = 0.1835 to 0.20 and |log2FC| > 2.5 (t of 2 on 2 d.f.; two-replicate pattern)', value=int(((ph.p > 0.183) & (ph.p < 0.20) & (ph.log2fc.abs() > 2.5)).sum())),
      dict(metric='rows with |log2FC| > 2.5 (present/absent-type calls)', value=int((ph.log2fc.abs() > 2.5).sum())),
      dict(metric='  of which P < 0.05: total (up / down)', value=f"{int(((ph.log2fc.abs() > 2.5) & (ph.p < 0.05)).sum())} ({int(((ph.log2fc > 2.5) & (ph.p < 0.05)).sum())} / {int(((ph.log2fc < -2.5) & (ph.p < 0.05)).sum())})")]
for _, x in ph[ph.gene.isin(['Stat5b', 'Stat5a', 'Jak2', 'Stat1', 'Stat4'])].iterrows():
    S6.append(dict(metric=f'{x.gene} phosphopeptide: P={x.p:.4g}, Q={x.q:.3f}, log2FC={x.log2fc:+.2f}, rank by P', value=int(x.rank_by_p)))
S6.append(dict(metric='Ckb / Slc6a8 / Stat3 rows in file', value=int(ph.gene.isin(['Ckb', 'Slc6a8', 'Stat3']).sum())))
pd.DataFrame(S6).to_csv(os.path.join(OUT, 'T6_phosphoproteomics_summary.csv'), index=False)
ph.sort_values('p').head(40).to_csv(os.path.join(OUT, 'T6b_phosphoproteomics_top40_by_P.csv'), index=False)
print(pd.DataFrame(S6).to_string())

# =====================================================================================================
# T7. Data-integrity checks: identical values across nominally independent experiments
# =====================================================================================================
vals = collections.defaultdict(list)
for ws in WB.worksheets:
    for rw in ws.iter_rows():
        for c in rw:
            if isinstance(c.value, float):
                s = repr(c.value).split('e')[0].replace('-', '').replace('.', '').strip('0')
                if len(s) >= 6: vals[c.value].append((ws.title, c.coordinate))
I = []
for v, locs in vals.items():
    sheets = sorted(set(l[0] for l in locs))
    if len(sheets) > 1 and not all(s.startswith(('Fig. 2f', 'Fig. 3f', 'Fig. 4', 'Fig.6a', 'Fig. 6g', 'Supplementary Fig  4e')) for s in sheets):
        both = {'Fig. 6b', 'Supplementary Fig  2d'} == set(sheets)
        I.append(dict(value=v, locations='; '.join(f"'{a}'!{b}" for a, b in locs), endpoint='metastatic burden (%)' if both else 'ChIP % input',
                      comment=('same animal-level value in two nominally different experiments (direct dosing +/- STAT5-IN-1 vs donor-platelet transfer)' if both else
                               'single shared value between two ChIP sheets; % input is derived from CT differences on a coarse grid, so one coincidence is plausible - not flagged')))
# the matching foci counts are small integers, so they are compared explicitly, row by row
ws6, ws2 = WB['Fig. 6b'], WB['Supplementary Fig  2d']
for r6, r2 in zip((14, 15, 16), (17, 18, 19)):
    for c6, c2 in (('B', 'C'), ('C', 'D')):
        assert ws6[f'{c6}{r6}'].value == ws2[f'{c2}{r2}'].value
        I.append(dict(value=ws6[f'{c6}{r6}'].value, locations=f"'Fig. 6b'!{c6}{r6}; 'Supplementary Fig  2d'!{c2}{r2}", endpoint='metastatic foci (count)',
                      comment='foci count of the same row as the duplicated burden value; identical as well'))
T7 = pd.DataFrame(I).sort_values(['endpoint', 'locations'])
T7.to_csv(os.path.join(OUT, 'T7_identical_values_across_sheets.csv'), index=False)
print(T7.to_string())
# exact within-arm duplicates among biological replicates in Fig. 3f (full double precision)
ws = WB['Fig. 3f']
print('Fig 3f K19 == M19:', ws['K19'].value == ws['M19'].value, ws['K19'].value, '| O39 == Q39:', ws['O39'].value == ws['Q39'].value, ws['O39'].value)

# ---- replicate-pattern checks on the platelet aggregation sheets (are the "n = 3" values independent?)
RP = []
ws = WB['Fig. 2b']
for ag, r in [('ADP', 4), ('collagen', 5), ('thrombin', 6)]:
    a, b = row(ws, r, 'B', 'D'), row(ws, r, 'E', 'G')
    for arm, v in (('vehicle', a), ('creatine', b)):
        RP.append(dict(sheet='Fig. 2b', group=f'{ag} / {arm}', values='; '.join(f'{x:g}' for x in v), third_equals_mean_of_first_two=bool(abs(v[2] - (v[0] + v[1]) / 2) < 1e-9),
                       range=float(v.max() - v.min()), note=''))
    RP.append(dict(sheet='Fig. 2b', group=f'{ag}: creatine vs vehicle', values='', third_equals_mean_of_first_two=None, range=None,
                   note=f'P as entered (n=3/arm) = {stats.ttest_ind(a, b).pvalue:.4f}; P using only the first two values per arm = {stats.ttest_ind(a[:2], b[:2]).pvalue:.3f}'))
ws = WB['Fig. 3d']
for ag, r in [('ADP', 4), ('collagen', 5), ('thrombin', 6)]:
    for arm, (c0, c1) in [('Cre-ctrl vehicle', ('B', 'D')), ('Cre-ctrl creatine', ('E', 'G')), ('Slc6a8-cKO vehicle', ('H', 'J')), ('Slc6a8-cKO creatine', ('K', 'M'))]:
        v = row(ws, r, c0, c1)
        RP.append(dict(sheet='Fig. 3d', group=f'{ag} / {arm}', values='; '.join(f'{x:g}' for x in v), third_equals_mean_of_first_two=bool(abs(v[2] - (v[0] + v[1]) / 2) < 1e-9),
                       range=float(v.max() - v.min()), note='two identical values + one 2 units away' if sorted(np.abs(np.diff(np.sort(v))).tolist()) == [0.0, 2.0] else ''))
# chance that the third of three gridded values equals the mean of the first two, for six independent triplets (simulation, SD 2-5 units, integer grid)
_rng = np.random.default_rng(0); sim = {}
for sd in (2, 3, 5):
    x = np.round(_rng.normal(50, sd, size=(400000, 3)))
    sim[sd] = float((np.abs(x[:, 2] - (x[:, 0] + x[:, 1]) / 2) < 1e-9).mean())
RP.append(dict(sheet='Fig. 2b', group='chance of the pattern', values='', third_equals_mean_of_first_two=None, range=None,
               note='per-triplet chance that value 3 = mean(values 1,2) is ' + ', '.join(f'{v:.3f} (SD {k})' for k, v in sim.items()) + f'; for all six triplets < {max(sim.values())**6:.0e}'))
pd.DataFrame(RP).to_csv(os.path.join(OUT, 'T7b_replicate_pattern_checks.csv'), index=False)
print(pd.DataFrame(RP).to_string())

# ---- same check on the qPCR dCT triplets (values sit on a 0.005/0.01 grid, so a few coincidences are expected; chance rate estimated by simulation)
def _mean_event(v, tol=1e-7):
    a, b, c = v
    return (not a == b == c) and any(abs(x - (y + z) / 2) < tol for x, (y, z) in [(a, (b, c)), (b, (a, c)), (c, (a, b))])
def _grid(v):
    if all(abs(x * 100 - round(x * 100)) < 1e-6 for x in v): return 0.01
    if all(abs(x * 200 - round(x * 200)) < 1e-6 for x in v): return 0.005
    return None
_rng = np.random.default_rng(1); QS = []
for sh in ['Fig. 2f', 'Fig. 3f', 'Fig. 4h', 'Fig. 4j', 'Fig. 4l', 'Fig.6a', 'Fig. 6g', 'Supplementary Fig  4e']:
    ws = WB[sh]; obs = 0; exp = 0.0; n = 0; seen = set(); hits = []
    for r in range(1, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            lab = ws.cell(row=r, column=c).value
            if isinstance(lab, str) and lab.startswith('ΔCT'):
                v = [ws.cell(row=r, column=c + k).value for k in (1, 2, 3)]
                if not all(isinstance(x, (int, float)) for x in v) or (r, tuple(v)) in seen: continue
                seen.add((r, tuple(v))); g = _grid(v)
                if g is None: continue
                n += 1; e = _mean_event(v); obs += e
                x = np.round(_rng.normal(0, max(np.std(v, ddof=1), 0.05), size=(20000, 3)) / g) * g
                exp += float(np.mean([_mean_event(t) for t in x]))
                if e: hits.append(f"row {r}: " + ', '.join(f'{y:g}' for y in v))
    QS.append(dict(sheet=sh, gridded_dCT_triplets=n, observed_with_one_value_equal_to_mean_of_other_two=int(obs), expected_by_chance=round(exp, 2),
                   poisson_p_at_least_observed=(float(stats.poisson.sf(obs - 1, exp)) if obs else 1.0), triplets='; '.join(hits)))
pd.DataFrame(QS).to_csv(os.path.join(OUT, 'T7c_qpcr_replicate_pattern_scan.csv'), index=False)
print(pd.DataFrame(QS).drop(columns='triplets').to_string())

# =====================================================================================================
# T8. Planning numbers for the proposed in vivo study (power for the genotype x creatine interaction)
# =====================================================================================================
def power(delta, sigma, n, c2, df, alpha=.05):
    ncp = delta / (sigma * np.sqrt(c2 / n)); tc = stats.t.ppf(1 - alpha / 2, df)
    pw = float(1 - stats.nct.cdf(tc, df, ncp) + stats.nct.cdf(-tc, df, ncp))
    if not np.isfinite(pw):   # scipy's non-central t can return nan for very large non-centrality; power is then ~1
        pw = float(stats.norm.sf(tc - ncp))
    return pw
full = np.log(pooled[0]['pooled_geo_ratio']); PW = []
for sigma in (0.35, 0.50):
    # attenuation is defined on the log (ratio) scale: with a x3.16 effect in controls, removing 50% leaves x1.78 in the perturbed arm, 75% leaves x1.33
    for frac, lab in [(1.0, 'creatine effect fully removed (perturbed-arm ratio x1.00)'), (0.75, f'75% of the log-fold effect removed (perturbed-arm ratio x{np.exp(full*0.25):.2f})'), (0.5, f'50% of the log-fold effect removed (perturbed-arm ratio x{np.exp(full*0.5):.2f})')]:
        for n in (6, 8, 10, 12, 14, 16, 20):
            PW.append(dict(sd_log_burden=sigma, scenario=lab, n_per_arm=n, power_interaction_2x2=power(full * frac, sigma, n, 4, 4 * (n - 1)), power_pairwise_creatine_vs_creatine_plus_block=power(full * frac, sigma, n, 2, 4 * (n - 1))))
    for n in (12, 16, 20, 24):
        PW.append(dict(sd_log_burden=sigma, scenario='30% lower burden from the perturbation alone (no creatine)', n_per_arm=n, power_interaction_2x2=np.nan, power_pairwise_creatine_vs_creatine_plus_block=power(abs(np.log(.7)), sigma, n, 2, 4 * (n - 1))))
pd.DataFrame(PW).to_csv(os.path.join(OUT, 'T8_power_planning_in_vivo.csv'), index=False)
# human planning: SD of log2 fold change in collagen max aggregation at day 14
ws = WB['Fig. 7c']; f14 = col(ws, 'E', 4, 14); l = np.log2(f14)
print(f'human collagen max aggregation d14: mean log2 fold {l.mean():.2f}, SD {l.std(ddof=1):.2f}, standardised effect {l.mean()/l.std(ddof=1):.2f}')
from statsmodels.stats.power import TTestIndPower, TTestPower
for frac in (1.0, 0.5):
    d = frac * l.mean() / l.std(ddof=1)
    print(f'  parallel-group n/arm for 80%/90% power at {int(frac*100)}% of observed effect: {TTestIndPower().solve_power(d, power=.8, alpha=.05):.1f} / {TTestIndPower().solve_power(d, power=.9, alpha=.05):.1f}')
print('done')
