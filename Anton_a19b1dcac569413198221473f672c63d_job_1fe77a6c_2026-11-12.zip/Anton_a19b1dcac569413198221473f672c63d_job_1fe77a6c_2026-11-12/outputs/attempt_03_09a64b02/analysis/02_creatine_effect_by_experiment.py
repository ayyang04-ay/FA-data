"""Step 02. Creatine vs vehicle in every control-arm experiment; random-effects pooling of the log ratio of means.
Output: ../tables/creatine_effect_by_experiment.csv"""
from lib import *
import os, warnings; warnings.filterwarnings('ignore')
EXPS = [
 ('Fig. 1b', dict(burden=('Fig. 1b','B',3,8,'C',3,8), foci=('Fig. 1b','B',12,17,'C',12,17), lung_weight=('Fig. 1a','B',3,8,'C',3,8), suv=('Fig. 1a','B',12,17,'C',12,17))),
 ('Fig. 1f (sh-scrambled melanoma)', dict(burden=('Fig. 1f','B',22,27,'C',22,27), foci=('Fig. 1f','B',31,36,'C',31,36), lung_weight=('Fig. 1f','B',4,9,'C',4,9), suv=('Fig. 1f','B',13,18,'C',13,18))),
 ('Fig. 1f (sh-Slc6a8 melanoma; not pooled)', dict(burden=('Fig. 1f','D',22,27,'E',22,27), foci=('Fig. 1f','D',31,36,'E',31,36), lung_weight=('Fig. 1f','D',4,9,'E',4,9), suv=('Fig. 1f','D',13,18,'E',13,18))),
 ('Fig. 1k', dict(burden=('Fig. 1k','B',4,9,'C',4,9), foci=('Fig. 1k','B',12,17,'C',12,17), lung_weight=('Fig. 1j','B',4,9,'C',4,9), suv=('Fig. 1j','B',13,18,'C',13,18))),
 ('Fig. 3i (Pf4-Cre; Slc6a8+/+)', dict(burden=('Fig. 3i','B',10,13,'C',10,13), foci=('Fig. 3i','B',17,20,'C',17,20), lung_weight=('Fig. 3i','B',3,6,'C',3,6))),
 ('Fig. 6b (no inhibitor)', dict(burden=('Fig. 6b','B',4,8,'C',4,8), foci=('Fig. 6b','B',13,17,'C',13,17))),
 ('Supp. Fig. 1e', dict(burden=('Supplementary Fig  1e','B',13,18,'C',13,18), foci=('Supplementary Fig  1e','B',22,27,'C',22,27), lung_weight=('Supplementary Fig  1e','B',4,9,'C',4,9))),
 ('Supp. Fig. 1f', dict(burden=('Supplementary Fig  1f','B',12,15,'C',12,15), foci=('Supplementary Fig  1f','B',20,23,'C',20,23), lung_weight=('Supplementary Fig  1f','B',4,7,'C',4,7))),
 ('Supp. Fig. 1g', dict(burden=('Supplementary Fig  1g','B',15,24,'C',15,24), foci=('Supplementary Fig  1g','B',28,37,'C',28,37), lung_weight=('Supplementary Fig  1g','B',3,12,'C',3,12))),
 ('Supp. Fig. 1i (5% creatine diet)', dict(burden=('Supplementary Fig  1i','B',11,14,'C',11,14), foci=('Supplementary Fig  1i','B',18,21,'C',18,21), lung_weight=('Supplementary Fig  1i','B',3,6,'C',3,6))),
 ('Supp. Fig. 1k', dict(burden=('Supplementary Fig  1k','B',16,25,'C',16,25), foci=('Supplementary Fig  1k','B',29,38,'C',29,38), lung_weight=('Supplementary Fig  1k','B',4,13,'C',4,13))),
]
def dersimonian_laird(y, v):
    w=1/v; ybar=(w*y).sum()/w.sum(); Q=(w*(y-ybar)**2).sum(); k=len(y)
    C=w.sum()-(w**2).sum()/w.sum(); tau2=max(0,(Q-(k-1))/C)
    ws=1/(v+tau2); mu=(ws*y).sum()/ws.sum(); se=np.sqrt(1/ws.sum())
    return mu, se, (max(0,(Q-(k-1))/Q)*100 if Q>0 else 0)
def build():
    rows=[]
    for label,d in EXPS:
        for ep,(s,c1,r0,r1,c2,r2,r3) in d.items():
            a=col(s,c1,r0,r1); b=col(s,c2,r2,r3)
            lr=np.log(b.mean()/a.mean()); v=a.var(ddof=1)/(len(a)*a.mean()**2)+b.var(ddof=1)/(len(b)*b.mean()**2)
            rows.append(dict(experiment=label,endpoint=ep,n_vehicle=len(a),n_creatine=len(b),mean_vehicle=a.mean(),mean_creatine=b.mean(),
                             ratio_creatine_over_vehicle=b.mean()/a.mean(),ln_ratio=lr,variance_ln_ratio=v,ratio_ci95_low=np.exp(lr-1.96*np.sqrt(v)),
                             ratio_ci95_high=np.exp(lr+1.96*np.sqrt(v)),P_t_test=stats.ttest_ind(a,b).pvalue))
    return pd.DataFrame(rows)
if __name__=='__main__':
    M=build(); M.to_csv(os.path.join(TABLES,'creatine_effect_by_experiment.csv'),index=False)
    for ep in ['burden','foci','lung_weight','suv']:
        sub=M[(M.endpoint==ep)&(~M.experiment.str.contains('not pooled'))]
        mu,se,I2=dersimonian_laird(sub.ln_ratio.values,sub.variance_ln_ratio.values)
        print(f'{ep}: k={len(sub)}, n={int(sub.n_vehicle.sum()+sub.n_creatine.sum())}; pooled ratio {np.exp(mu):.2f} (95% CI {np.exp(mu-1.96*se):.2f}-{np.exp(mu+1.96*se):.2f}); I2={I2:.0f}%; range {sub.ratio_creatine_over_vehicle.min():.2f}-{sub.ratio_creatine_over_vehicle.max():.2f}; all P<0.05: {bool((sub.P_t_test<0.05).all())}')
