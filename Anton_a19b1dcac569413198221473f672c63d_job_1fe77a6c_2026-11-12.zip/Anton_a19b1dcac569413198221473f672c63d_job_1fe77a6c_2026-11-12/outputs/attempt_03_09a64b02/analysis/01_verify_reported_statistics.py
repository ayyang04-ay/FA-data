"""Step 01. Recompute every statistical result reported in the source-data workbook and compare with the reported P value.
Output: ../tables/verification_log.csv"""
from lib import *
import warnings, os
warnings.filterwarnings('ignore')
from scipy.stats import tukey_hsd, dunnett
import statsmodels.formula.api as smf
from lifelines.statistics import logrank_test
LOG = []
def num(x):
    if isinstance(x, (int, float)): return float(x)
    s = str(x).strip()
    if s[0] in '<>': return (s[0], float(s[1:]))
    return float(s)
def add(panel, comparison, test, reported, recomputed, n_desc):
    rp = num(reported)
    if isinstance(rp, tuple):
        ok = (recomputed < rp[1]) if rp[0] == '<' else (recomputed > rp[1]); rep = f'{rp[0]}{rp[1]}'
    else:
        ok = (abs(recomputed-rp) <= 6e-4) or (abs(recomputed-rp) <= 0.02*max(rp, 1e-300)) or (rp < 1e-9 and recomputed < 1e-9); rep = rp
    LOG.append(dict(panel=panel, comparison=comparison, test=test, n=n_desc, reported_P=rep, recomputed_P=recomputed, match=bool(ok)))
def T(panel, comp, a, b, prep):
    add(panel, comp, 'unpaired two-tailed t', prep, stats.ttest_ind(a, b).pvalue, f'{len(a)} vs {len(b)}')
# ---------------- t tests
S='Fig. 1a'; T(S,'lung weight',col(S,'B',3,8),col(S,'C',3,8),cell(S,'F4')); T(S,'SUV-BW',col(S,'B',12,17),col(S,'C',12,17),cell(S,'F12'))
S='Fig. 1b'; T(S,'burden',col(S,'B',3,8),col(S,'C',3,8),cell(S,'F3')); T(S,'foci',col(S,'B',12,17),col(S,'C',12,17),cell(S,'F12'))
S='Fig. 1h'
for r,t,pc in [(4,'0.25h','B17'),(5,'6h','E17'),(6,'12h','H17'),(7,'24h','K17')]: T(S,t,row(S,r,'B','G'),row(S,r,'H','M'),cell(S,pc))
S='Fig. 1i'; T(S,'GFP+ cells/field (n=fields)',col(S,'B',4,11),col(S,'C',4,11),cell(S,'F4'))
S='Fig. 1j'; T(S,'lung weight',col(S,'B',4,9),col(S,'C',4,9),cell(S,'F4')); T(S,'SUV-BW',col(S,'B',13,18),col(S,'C',13,18),cell(S,'F13'))
S='Fig. 1k'; T(S,'burden',col(S,'B',4,9),col(S,'C',4,9),cell(S,'F4')); T(S,'foci',col(S,'B',12,17),col(S,'C',12,17),cell(S,'F12'))
S='Fig. 2a'
for nm,r0,pc in [('PLT',4,'F4'),('PCT',12,'F12'),('PDW',19,'F19'),('MPV',27,'F27')]: T(S,nm,col(S,'B',r0,r0+2),col(S,'C',r0,r0+2),cell(S,pc))
S='Fig. 2b'
for nm,r,pc in [('ADP',4,'B18'),('Collagen',5,'B32'),('Thrombin',6,'B45')]: T(S,nm,row(S,r,'B','D'),row(S,r,'E','G'),cell(S,pc))
S='Fig. 2c'; T(S,'alpha-granules (n=fields)',col(S,'B',4,11),col(S,'C',4,11),cell(S,'F5'))
S='Fig. 2d'
for nm,r0,pc in [('TEG-R',4,'F4'),('TEG-K',12,'F12'),('TEG-alpha',20,'F20'),('TEG-MA',28,'F28')]: T(S,nm,col(S,'B',r0,r0+4),col(S,'C',r0,r0+4),cell(S,pc))
S='Fig. 2j'; T(S,'PKH+ area (n=fields)',col(S,'B',4,11),col(S,'C',4,11),cell(S,'F4'))
S='Fig. 3b'; T(S,'serum creatine, Slc6a8+/+',row(S,4,'B','F'),row(S,4,'G','K'),cell(S,'B17')); T(S,'serum creatine, Slc6a8 knockout',row(S,5,'B','F'),row(S,5,'G','K'),cell(S,'B31'))
S='Fig. 3c'; T(S,'MK creatine, Slc6a8+/+',row(S,4,'B','D'),row(S,4,'E','G'),cell(S,'B15')); T(S,'MK creatine, Slc6a8 knockout',row(S,5,'B','D'),row(S,5,'E','G'),cell(S,'B30'))
S='Fig. 4a'; T(S,'MK creatine',col(S,'B',4,6),col(S,'C',4,6),cell(S,'H10')); T(S,'brain creatine',col(S,'D',4,6),col(S,'E',4,6),cell(S,'H24'))
S='Fig. 4c'; T(S,'MK phosphocreatine',col(S,'B',4,6),col(S,'C',4,6),cell(S,'H10')); T(S,'brain phosphocreatine',col(S,'D',4,6),col(S,'E',4,6),cell(S,'H24'))
S='Fig. 4d'; T(S,'MK in vitro creatine',col(S,'C',4,6),col(S,'D',4,6),cell(S,'G10'))
S='Fig. 4e'; T(S,'Ckb mRNA',row(S,8,'E','G'),row(S,8,'I','K'),cell(S,'O5'))
S='Fig. 4f'; T(S,'MK in vitro phosphocreatine',col(S,'B',4,6),col(S,'C',4,6),cell(S,'F4'))
S='Fig. 7g'; T(S,'lung weight',col(S,'B',4,8),col(S,'C',4,8),cell(S,'F4')); T(S,'burden',col(S,'B',12,16),col(S,'C',12,16),cell(S,'F12')); T(S,'foci',col(S,'B',19,23),col(S,'C',19,23),cell(S,'F19'))
S='Supplementary Fig  1a'; T(S,'body weight d0',row(S,4,'B','E'),row(S,4,'F','I'),cell(S,'M11')); T(S,'body weight d7',row(S,5,'B','E'),row(S,5,'F','I'),cell(S,'M25'))
S='Supplementary Fig  1b'; T(S,'food intake',col(S,'B',4,9),col(S,'C',4,9),cell(S,'F4'))
S='Supplementary Fig  1c'; T(S,'water intake',col(S,'B',4,9),col(S,'C',4,9),cell(S,'F4'))
S='Supplementary Fig  1d'; T(S,'serum creatine',col(S,'B',4,9),col(S,'C',4,9),cell(S,'F4'))
S='Supplementary Fig  1e'; T(S,'lung weight',col(S,'B',4,9),col(S,'C',4,9),cell(S,'F4')); T(S,'burden',col(S,'B',13,18),col(S,'C',13,18),cell(S,'F13')); T(S,'foci',col(S,'B',22,27),col(S,'C',22,27),cell(S,'F22'))
S='Supplementary Fig  1f'; T(S,'lung weight',col(S,'B',4,7),col(S,'C',4,7),cell(S,'F4')); T(S,'burden',col(S,'B',12,15),col(S,'C',12,15),cell(S,'F12')); T(S,'foci',col(S,'B',20,23),col(S,'C',20,23),cell(S,'F20'))
S='Supplementary Fig  1g'; T(S,'lung weight',col(S,'B',3,12),col(S,'C',3,12),cell(S,'F3')); T(S,'burden',col(S,'B',15,24),col(S,'C',15,24),cell(S,'F15')); T(S,'foci',col(S,'B',28,37),col(S,'C',28,37),cell(S,'F28'))
S='Supplementary Fig  1h'; T(S,'serum creatine (diet)',col(S,'C',4,7),col(S,'D',4,7),cell(S,'F4'))
S='Supplementary Fig  1i'; T(S,'lung weight',col(S,'B',3,6),col(S,'C',3,6),cell(S,'F3')); T(S,'burden',col(S,'B',11,14),col(S,'C',11,14),cell(S,'F11')); T(S,'foci',col(S,'B',18,21),col(S,'C',18,21),cell(S,'F18'))
S='Supplementary Fig  1k'; T(S,'lung weight',col(S,'B',4,13),col(S,'C',4,13),cell(S,'G4')); T(S,'burden',col(S,'B',16,25),col(S,'C',16,25),cell(S,'G16')); T(S,'foci',col(S,'B',29,38),col(S,'C',29,38),cell(S,'G29'))
S='Supplementary Fig  2a'; T(S,'Slc6a8 mRNA knock-down',row(S,7,'D','F'),row(S,7,'H','J'),cell(S,'M4'))
S='Supplementary Fig  3a'
for nm,r0,pc in [('WBC',4,'F4'),('lymphocyte',12,'F12'),('monocyte',20,'F20'),('RBC',28,'F28')]: T(S,nm,col(S,'B',r0,r0+4),col(S,'C',r0,r0+4),cell(S,pc))
S='Supplementary Fig  5a'; T(S,'Gatm',row(S,6,'C','E'),row(S,6,'G','I'),cell(S,'N10')); T(S,'Gamt',row(S,9,'C','E'),row(S,9,'G','I'),cell(S,'N24'))
S='Supplementary Fig  5c'; T(S,'MK creatine CKB-EV vs OE',col(S,'B',5,7),col(S,'C',5,7),cell(S,'F5')); T(S,'MK phosphocreatine CKB-EV vs OE',col(S,'B',13,15),col(S,'C',13,15),cell(S,'F13'))
S='Supplementary Fig  8a'; T(S,'BMI d0 vs d14 (reported as unpaired)',col(S,'C',4,14),col(S,'D',4,14),cell(S,'G5'))
# ---------------- survival
def surv(sheet, r0, r1):
    A=[]; B=[]
    for r in range(r0, r1+1):
        t=cell(sheet,f'A{r}')
        if t is None: continue
        if cell(sheet,f'B{r}') is not None: A.append(t)
        if cell(sheet,f'C{r}') is not None: B.append(t)
    return np.array(A), np.array(B)
for sheet,r0,r1,pc in [('Fig. 1c',4,23,'F8'),('Fig. 1l',4,41,'F7')]:
    a,b=surv(sheet,r0,r1); res=logrank_test(a,b,np.ones(len(a)),np.ones(len(b)))
    add(sheet,'survival vehicle vs creatine','log-rank (Mantel-Cox)',cell(sheet,pc),res.p_value,f'{len(a)} vs {len(b)}')
# ---------------- Tukey
def TUK(sheet, groups, names, reported):
    res=tukey_hsd(*groups)
    for i,j,pc in reported:
        add(sheet,f'{names[i]} vs {names[j]}','one-way ANOVA + Tukey',cell(sheet,pc),res.pvalue[i,j],'/'.join(str(len(g)) for g in groups))
S='Fig. 1f'; nm=['scr-veh','scr-cre','sh-veh','sh-cre']
for lab,r0,rr in [('lung weight',4,(4,5,6)),('SUV',13,(13,14,15)),('burden',22,(22,23,24)),('foci',31,(31,32,33))]:
    TUK(S,[col(S,c,r0,r0+5) for c in 'BCDE'],[f'{lab}: {x}' for x in nm],[(0,1,f'L{rr[0]}'),(1,3,f'L{rr[1]}'),(2,3,f'L{rr[2]}')])
S='Fig. 3d'; nm=['control-veh','control-cre','knockout-veh','knockout-cre']
for lab,r,rr in [('ADP',4,(4,5)),('Collagen',5,(10,11)),('Thrombin',6,(15,16))]:
    TUK(S,[row(S,r,'B','D'),row(S,r,'E','G'),row(S,r,'H','J'),row(S,r,'K','M')],[f'{lab}: {x}' for x in nm],[(0,1,f'T{rr[0]}'),(2,3,f'T{rr[1]}')])
S='Fig. 3i'
for lab,r0,rr in [('lung weight',3,(3,4,5)),('burden',10,(10,11,12)),('foci',17,(17,18,19))]:
    TUK(S,[col(S,c,r0,r0+3) for c in 'BCDE'],[f'{lab}: {x}' for x in nm],[(0,1,f'L{rr[0]}'),(1,3,f'L{rr[1]}'),(2,3,f'L{rr[2]}')])
nm=['WT','S127A','3A','S127D']
S='Fig. 5e'
TUK(S,[col(S,c,4,6) for c in 'NOPQ'],['vehicle: '+x for x in nm],[(0,2,'R10'),(0,3,'R11'),(1,3,'R12'),(2,3,'R13')])
TUK(S,[col(S,c,17,19) for c in 'NOPQ'],['creatine: '+x for x in nm],[(0,1,'R22'),(0,3,'R23'),(1,2,'R24')])
S='Fig. 5f'
TUK(S,[col(S,c,4,6) for c in 'NOPQ'],['vehicle: '+x for x in nm],[(0,2,'Q9'),(0,3,'Q10'),(1,3,'Q11'),(2,3,'Q12')])
TUK(S,[col(S,c,17,19) for c in 'NOPQ'],['creatine: '+x for x in nm],[(0,1,'Q22'),(0,3,'Q23'),(1,2,'Q24')])
S='Fig. 6b'; nm=['veh','cre','veh+STAT5i','cre+STAT5i']
for lab,r0,rr in [('burden',4,(4,5,6,7)),('foci',13,(13,14,15,16))]:
    TUK(S,[col(S,c,r0,r0+4) for c in 'BCDE'],[f'{lab}: {x}' for x in nm],[(0,1,f'L{rr[0]}'),(0,2,f'L{rr[1]}'),(1,3,f'L{rr[2]}'),(2,3,f'L{rr[3]}')])
S='Fig. 6e'; TUK(S,[col(S,c,5,7) for c in 'CDE'],['WT-veh','WT-cre','Stat5b knockout-cre'],[(0,1,'L5'),(0,2,'L6'),(1,2,'L7')])
S='Fig. 7b'; d=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(4,15)],float)
TUK(S,[d[:,i] for i in range(4)],['d0','d3','d7','d14'],[(0,1,'L5'),(0,2,'L6'),(0,3,'L7')])
S='Fig. 7e'
for lab,r0,rr in [('GP6',4,(4,5,6)),('P2RY12',12,(12,13,14))]:
    d=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(r0,r0+4)],float)
    TUK(S,[d[:,i] for i in range(4)],[f'{lab}: d{x}' for x in (0,3,7,14)],[(0,1,f'L{rr[0]}'),(0,2,f'L{rr[1]}'),(0,3,f'L{rr[2]}')])
S='Supplementary Fig  2d'; nm=['veh donor PLT','cre donor PLT','cre+aspirin donor PLT']
for lab,r0,rr in [('burden',5,(5,6,7)),('foci',14,(14,15,16))]:
    TUK(S,[col(S,c,r0,r0+5) for c in 'CDE'],[f'{lab}: {x}' for x in nm],[(0,1,f'L{rr[0]}'),(0,2,f'L{rr[1]}'),(1,2,f'L{rr[2]}')])
S='Supplementary Fig  4b'; nm=['control-veh','control-cre','knockout-veh','knockout-cre']
TUK(S,[col(S,c,5,7) for c in 'CDEF'],['PLT: '+x for x in nm],[(0,1,'M5'),(0,2,'M6'),(1,3,'M7'),(2,3,'M8')])
S='Supplementary Fig  4c'
TUK(S,[col(S,c,6,13) for c in 'CDEF'],['alpha-granules (fields): '+x for x in nm],[(0,1,'N7'),(1,3,'N8'),(2,3,'N9')])
S='Supplementary Fig  7a'; nm=['veh','cre','veh+STAT5i','cre+STAT5i']
for lab,r0 in [('PLT',4),('PCT',11),('MPV',17),('PDW',23)]:
    TUK(S,[col(S,c,r0,r0+2) for c in 'BCDE'],[f'{lab}: {x}' for x in nm],[(0,1,f'L{r0}'),(0,2,f'L{r0+1}'),(0,3,f'L{r0+2}')])
S='Supplementary Fig  7b'; nm=['WT-veh','WT-cre','Stat5b knockout-cre']
for lab,r0 in [('PLT',4),('PCT',10),('MPV',16),('PDW',22)]:
    TUK(S,[col(S,c,r0,r0+2) for c in 'BCD'],[f'{lab}: {x}' for x in nm],[(0,1,f'K{r0}'),(0,2,f'K{r0+1}'),(1,2,f'K{r0+2}')])
S='Supplementary Fig  8c'
TUK(S,[row(S,9,'E','G'),row(S,9,'I','K'),row(S,9,'M','O')],['CD41+ cells','monocyte','MEG-01'],[(0,1,'I15')])
# ---------------- Sidak after two-way ANOVA (ChIP)
def SID(sheet, rows, labels, vc, cc, reported):
    recs=[]
    for r,l in zip(rows,labels):
        recs += [dict(region=l,trt='veh',y=x) for x in row(sheet,r,*vc)] + [dict(region=l,trt='cre',y=x) for x in row(sheet,r,*cc)]
    d=pd.DataFrame(recs); m=smf.ols('y ~ C(region)*C(trt)',d).fit(); k=len(rows)
    for l,pc in zip(labels,reported):
        v=d[(d.region==l)&(d.trt=='veh')].y.values; c=d[(d.region==l)&(d.trt=='cre')].y.values
        t=(v.mean()-c.mean())/np.sqrt(m.mse_resid*(1/len(v)+1/len(c))); p=2*stats.t.sf(abs(t),m.df_resid)
        add(sheet,f'{l}: veh vs cre','two-way ANOVA + Sidak',cell(sheet,pc),1-(1-p)**k,'3 vs 3 per region')
SID('Fig. 5j',[5,6,7,8],['P2ry12 Exon','P2ry12 2K','P2ry12 1K','P2ry12 0.2K'],('B','D'),('E','G'),['N7','N8','N9','N10'])
SID('Fig. 5j',[15,16,17,18],['Gp6 Exon','Gp6 2K','Gp6 1K','Gp6 0.2K'],('B','D'),('E','G'),['N17','N18','N19','N20'])
SID('Supplementary Fig  6i',[7,8,9,10],['Rab4a Exon','Rab4a 2K','Rab4a 1K','Rab4a 0.2K'],('C','E'),('F','H'),['O10','O11','O12','O13'])
# ---------------- Dunnett (human repeated measures, analysed in the workbook as unpaired groups)
S='Fig. 7c'
blocks=[('collagen max agg',4,[4,5,6]),('collagen avg agg',18,[18,19,20]),('collagen adhesion',32,[32,33,34]),('EPI max agg',46,[47,48,49]),('EPI avg agg',60,[61,62,63]),('EPI adhesion',74,[75,76,77]),('AA max agg',88,[88,89,90]),('AA avg agg',102,[103,104,105]),('AA adhesion',116,[117,118,119]),('ADP max agg',130,[131,132,133]),('ADP avg agg',144,[145,146,147]),('ADP adhesion',157,[159,160,161])]
for name,r0,rr in blocks:
    d=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(r0,r0+11)],float)
    dn=dunnett(d[:,1],d[:,2],d[:,3],control=d[:,0],random_state=1)
    for j,(day,r) in enumerate(zip((3,7,14),rr)): add(S,f'{name}: d0 vs d{day}','one-way ANOVA + Dunnett',cell(S,f'L{r}'),dn.pvalue[j],'11 volunteers')
S='Supplementary Fig  8b'
for name,r0,rr in [('PLT',4,[4,5,6]),('PCT',19,[19,20,21]),('MPV',33,[33,34,35]),('PDW',48,[48,49,50])]:
    d=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(r0,r0+11)],float)
    dn=dunnett(d[:,1],d[:,2],d[:,3],control=d[:,0],random_state=1)
    for j,(day,r) in enumerate(zip((3,7,14),rr)): add(S,f'{name}: d0 vs d{day}','one-way ANOVA + Dunnett',cell(S,f'L{r}'),dn.pvalue[j],'11 volunteers')
L=pd.DataFrame(LOG); L.to_csv(os.path.join(TABLES,'verification_log.csv'),index=False)
print('reported tests recomputed:',len(L),'| matched:',int(L.match.sum()),'| not matched:',int((~L.match).sum()))
print(L.groupby('test').match.agg(['count','sum']).to_string())
if (~L.match).any(): print(L[~L.match].to_string())
