"""Step 07. Sample-size calculations behind the proposed studies (printed)."""
from lib import *
def power_interaction(delta, sd, n, alpha=0.05):
    """2x2 between-animal design, n per cell: interaction contrast SE = sd*sqrt(4/n), df = 4(n-1)"""
    df=4*(n-1); ncp=delta/(sd*np.sqrt(4/n)); tc=stats.t.ppf(1-alpha/2,df)
    p=1-stats.nct.cdf(tc,df,ncp)+stats.nct.cdf(-tc,df,ncp)
    return 1.0 if np.isnan(p) else p   # the non-central t overflows to nan when power is essentially 1
def n_parallel(delta, sd, power=0.8, alpha=0.05):
    for n in range(3,2000):
        df=2*(n-1); ncp=delta/(sd*np.sqrt(2/n)); tc=stats.t.ppf(1-alpha/2,df)
        if 1-stats.nct.cdf(tc,df,ncp)>=power: return n
S='Fig. 3i'
print('--- In vivo 2x2 (from Fig. 3i)')
for lab,r0 in [('burden',10),('lung weight',3),('foci',17)]:
    g=[col(S,c,r0,r0+3) for c in 'BCDE']; sd=pooled_sd(g); inter=(g[1].mean()-g[0].mean())-(g[3].mean()-g[2].mean())
    print(f'{lab}: observed interaction {inter:.4g}, pooled SD {sd:.4g}')
    for frac,mult in [(1,1),(0.5,1),(0.5,1.5)]:
        n80=next(n for n in range(3,200) if power_interaction(inter*frac,sd*mult,n)>=0.8)
        print(f'   true interaction {frac:.0%} of observed, SD x{mult}: n per arm for 80% power = {n80}; power at n=12 = {power_interaction(inter*frac,sd*mult,12):.2f}')
print('   planning with across-experiment values (creatine adds ~10 points of burden, SD ~4): power at n=12 for 70% removal =', round(power_interaction(7,4,12),2))
print('--- Human placebo-controlled parallel study (from Fig. 7c, day 14, log2 fold change)')
H=pd.read_csv(os.path.join(TABLES,'human_platelet_response_by_agonist.csv')); H=H[H.day==14]
for _,r in H.iterrows():
    m=np.log2(r.geometric_mean_fold_vs_day0); sd=r.sd_log2
    print(f'{r.agonist}: mean log2 change {m:.2f}, SD {sd:.2f}; n per arm to detect half the effect: 80% power {n_parallel(m*0.5,sd,0.8)}, 90% power {n_parallel(m*0.5,sd,0.9)}')
