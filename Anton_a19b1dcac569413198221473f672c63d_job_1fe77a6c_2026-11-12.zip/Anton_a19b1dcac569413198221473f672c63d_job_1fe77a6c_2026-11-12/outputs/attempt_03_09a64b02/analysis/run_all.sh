#!/usr/bin/env bash
# Regenerates every table and figure of the proposal from the three CRE-MK-01 files.
# ENV_XLSX needs openpyxl + Pillow; ENV_STATS needs pandas, scipy, statsmodels, lifelines, matplotlib, reportlab.
set -euo pipefail
cd "$(dirname "$0")"
export CRE_INPUT="${CRE_INPUT:-/tmp/world/filesystem}"
ENV_XLSX="${ENV_XLSX:-chem}"; ENV_STATS="${ENV_STATS:-core}"
run() { micromamba run -n "$1" python "${@:2}"; }
run "$ENV_XLSX"  00_export_workbooks.py
run "$ENV_STATS" 01_verify_reported_statistics.py
run "$ENV_STATS" 02_creatine_effect_by_experiment.py
run "$ENV_STATS" 03_share_of_effect_removed.py
run "$ENV_STATS" 04_mk_gene_panel.py
run "$ENV_STATS" 05_human_cohort.py
run "$ENV_STATS" 06_phosphoproteomics.py
run "$ENV_STATS" 07_power.py
run "$ENV_XLSX"  08_blot_densitometry.py
run "$ENV_STATS" 09_evidence_ledger.py
for f in fig1_metastasis_endpoint fig2_mk_gene_panel fig3_human_cohort fig4_phosphoproteomics; do run "$ENV_STATS" "$f.py"; done
run "$ENV_STATS" 10_ledger_into_proposal.py
run "$ENV_STATS" build_pdf.py ../CRE-MK-01_validation_proposal.md ../CRE-MK-01_validation_proposal.pdf
