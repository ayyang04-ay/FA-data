"""Figure 3. Human cohort: exposure, platelet response by agonist (paired, log scale), platelet protein."""
from lib import *
import os, warnings; warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False})
S='Fig. 7b'; cr=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(4,15)],float)
S='Fig. 7c'
BL={'EPI':(46,60,74),'collagen':(4,18,32),'AA':(88,102,116),'ADP':(130,144,157)}
H={ag:[np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(r0,r0+11)],float) for r0 in rs] for ag,rs in BL.items()}
fig,axs=plt.subplots(1,3,figsize=(13,4.4),gridspec_kw=dict(width_ratios=[0.8,1.7,1.0],wspace=0.33))
ax=axs[0]
for i in range(cr.shape[0]): ax.plot(range(4),cr[i],color='#9ca3af',lw=0.8,marker='o',ms=3)
ax.plot(range(4),cr.mean(0),color='#c2410c',lw=2.2,marker='o',ms=5)
ax.set_xticks(range(4)); ax.set_xticklabels([0,3,7,14]); ax.set_xlabel('Day of creatine (20 g/day)'); ax.set_ylabel('Serum creatine (µM)')
ax.set_title('A  Exposure (Fig. 7b, n=11)',loc='left',fontweight='bold',fontsize=10)
ax.text(0.98,0.05,f'{cr[:,0].mean():.0f} → {cr[:,3].mean():.0f} µM\n(3.5×; 11/11 rise by day 3)',transform=ax.transAxes,ha='right',va='bottom',fontsize=8.3); ax.set_ylim(0,None)
ax=axs[1]; labs={'EPI':'Epinephrine','collagen':'Collagen','AA':'Arachidonic acid','ADP':'ADP'}; colors={'EPI':'#c2410c','collagen':'#b45309','AA':'#6b7280','ADP':'#1d4ed8'}
xpos=0; xt=[]; xl=[]; rng=np.random.default_rng(3)
for ag in ['EPI','collagen','AA','ADP']:
    for di,day in zip((1,2,3),(3,7,14)):
        Lg=np.array([np.log2(np.where(d[:,di]>0,d[:,di],np.nan)) for d in H[ag]]).T; c=np.nanmean(Lg,axis=1); m=c.mean(); se=c.std(ddof=1)/np.sqrt(len(c)); t=stats.t.ppf(0.975,len(c)-1)
        ax.scatter(xpos+rng.uniform(-0.16,0.16,len(c)),2**c,s=11,color=colors[ag],alpha=0.45,edgecolor='none')
        ax.errorbar([xpos],[2**m],yerr=[[2**m-2**(m-t*se)],[2**(m+t*se)-2**m]],fmt='o',color='k',ms=5,capsize=3,lw=1.3,zorder=5)
        if day==14: ax.text(xpos,2**(m+t*se)*1.12,f'{2**m:.2f}×\n{(c>0).sum()}/11 up',ha='center',va='bottom',fontsize=7.8)
        xt.append(xpos); xl.append(f'd{day}'); xpos+=1
    ax.text(xpos-2,0.17,labs[ag],ha='center',va='bottom',fontsize=9,fontweight='bold',color=colors[ag]); xpos+=0.7
ax.axhline(1,color='#9ca3af',lw=0.8,ls='--'); ax.set_yscale('log'); ax.set_yticks([0.25,0.5,1,2,4,8,16]); ax.set_yticklabels(['0.25','0.5','1','2','4','8','16']); ax.minorticks_off()
ax.set_xticks(xt); ax.set_xticklabels(xl,fontsize=8.3); ax.set_ylabel('Platelet response vs day 0 (fold, log scale)'); ax.set_ylim(0.15,24)
ax.set_title('B  Platelet aggregation/adhesion by agonist (Fig. 7c, n=11)',loc='left',fontweight='bold',fontsize=10)
ax.text(0.99,0.98,'points: volunteers (mean of 3 read-outs)\nblack: geometric mean, 95% CI',transform=ax.transAxes,ha='right',va='top',fontsize=7.6,color='#374151')
ax=axs[2]; S='Fig. 7e'
for k,(nm,r0,c) in enumerate([('GP6',4,'#c2410c'),('P2RY12',12,'#1d4ed8')]):
    d=np.array([[cell(S,f'{cc}{r}') for cc in 'BCDE'] for r in range(r0,r0+4)],float); rel=d/d[:,[0]]
    for i in range(4): ax.plot(np.arange(4)+k*4.6,rel[i],color=c,alpha=0.45,lw=0.9,marker='o',ms=3)
    g=2**np.log2(rel).mean(0); ax.plot(np.arange(4)+k*4.6,g,color=c,lw=2.2,marker='o',ms=5)
    ax.text(1.5+k*4.6,5.6,f'{nm}\nday 14: {g[3]:.1f}× (4/4)',ha='center',va='top',fontsize=8.6,color=c,fontweight='bold')
ax.axhline(1,color='#9ca3af',lw=0.8,ls='--'); ax.set_xticks(list(range(4))+[x+4.6 for x in range(4)]); ax.set_xticklabels(['0','3','7','14']*2); ax.set_xlabel('Day')
ax.set_ylabel('Platelet protein / β-actin, relative to day 0'); ax.set_ylim(0,5.8); ax.set_title('C  Platelet protein (Fig. 7e, n=4)',loc='left',fontweight='bold',fontsize=10)
fig.subplots_adjust(left=0.06,right=0.99,top=0.9,bottom=0.13)
fig.savefig(os.path.join(FIGS,'fig3_human_cohort.png'),dpi=170)
