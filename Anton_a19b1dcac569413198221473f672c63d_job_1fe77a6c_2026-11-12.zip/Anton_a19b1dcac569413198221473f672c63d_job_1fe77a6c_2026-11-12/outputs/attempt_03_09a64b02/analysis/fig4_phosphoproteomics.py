"""Figure 4. Phosphoproteomics screen: volcano with STAT5 peptides marked; P-value distribution of peptides with |log2FC| <= 2.5."""
import os, pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False})
HERE=os.path.dirname(os.path.abspath(__file__)); FIGS=os.path.join(HERE,'..','figures'); os.makedirs(FIGS,exist_ok=True)
df=pd.read_csv(os.path.join(HERE,'cache','phos.csv')); big=df.lfc.abs()>2.5
fig,axs=plt.subplots(1,2,figsize=(12.4,4.7),gridspec_kw=dict(width_ratios=[1.45,1],wspace=0.25))
ax=axs[0]
ax.scatter(df.lfc[~big],-np.log10(df.p[~big]),s=4,color='#6b7280',alpha=0.5,edgecolor='none'); ax.scatter(df.lfc[big],-np.log10(df.p[big]),s=4,color='#d6a77a',alpha=0.55,edgecolor='none')
ax.axhline(-np.log10(0.05),color='k',lw=0.8,ls='--'); ax.text(-8.4,-np.log10(0.05)+0.05,'P = 0.05 (unadjusted screening cut-off)',fontsize=7.8,va='bottom')
s5=df[df.gene=='Stat5b'].sort_values('p'); s5a=df[df.gene=='Stat5a']
ax.scatter(s5.lfc,-np.log10(s5.p),s=46,color='#c2410c',edgecolor='k',lw=0.6,zorder=5); ax.scatter(s5a.lfc,-np.log10(s5a.p),s=46,color='#1d4ed8',edgecolor='k',lw=0.6,zorder=5)
top,oth=s5.iloc[0],s5.iloc[1]
ax.annotate(f'Stat5b peptide 1\nlog2FC {top.lfc:.1f}, P={top.p:.4f}\nq={top.q:.2f}',xy=(top.lfc,-np.log10(top.p)),xytext=(2.3,3.7),fontsize=8.3,color='#c2410c',arrowprops=dict(arrowstyle='-',color='#c2410c',lw=0.8))
ax.annotate(f'Stat5b peptide 2\nlog2FC {oth.lfc:.1f}, P={oth.p:.2f}',xy=(oth.lfc,-np.log10(oth.p)),xytext=(1.6,1.55),fontsize=8.3,color='#c2410c',arrowprops=dict(arrowstyle='-',color='#c2410c',lw=0.8))
ax.annotate(f'Stat5a\nlog2FC {s5a.lfc.iloc[0]:.1f}, P={s5a.p.iloc[0]:.2f}',xy=(s5a.lfc.iloc[0],-np.log10(s5a.p.iloc[0])),xytext=(-5.2,1.55),fontsize=8.3,color='#1d4ed8',arrowprops=dict(arrowstyle='-',color='#1d4ed8',lw=0.8))
ax.text(-8.4,4.3,f'grey: |log2FC| ≤ 2.5 (n={(~big).sum():,})',fontsize=8,color='#4b5563',va='top'); ax.text(-8.4,4.05,f'tan: |log2FC| > 2.5 (n={big.sum():,})',fontsize=8,color='#a16207',va='top')
ax.set_xlabel('log2 fold change (creatine vs vehicle megakaryocytes)'); ax.set_ylabel('−log10 P (unadjusted, n=3 vs 3)')
ax.set_title(f'A  No phosphopeptide passes multiple-testing correction\n    (smallest q-value in the file is {df.q.min():.2f})',loc='left',fontweight='bold',fontsize=10); ax.set_ylim(0,4.5)
ax=axs[1]; small=df[~big]
ax.hist(small.p,bins=20,range=(0,1),color='#6b7280',edgecolor='white'); exp=len(small)/20
ax.axhline(exp,color='k',ls='--',lw=0.9); ax.text(0.5,exp*1.04,'level expected with no signal',ha='center',va='bottom',fontsize=8)
ax.set_xlabel('Unadjusted P value'); ax.set_ylabel('Phosphopeptides with |log2FC| ≤ 2.5')
ax.set_title(f'B  Peptides with |log2FC| ≤ 2.5 show no excess\n    of small P values ({100*(small.p<0.05).mean():.1f}% below 0.05)',loc='left',fontweight='bold',fontsize=10); ax.set_ylim(0,exp*1.85)
ntie=int(np.isclose(small.p,0.42265,atol=1e-5).sum())
ax.annotate(f'{ntie} rows sharing\nP=0.4227',xy=(0.425,307),xytext=(0.6,320),fontsize=7.8,color='#374151',arrowprops=dict(arrowstyle='-',color='#374151',lw=0.7))
fig.subplots_adjust(left=0.06,right=0.99,top=0.86,bottom=0.13)
fig.savefig(os.path.join(FIGS,'fig4_phosphoproteomics.png'),dpi=170)
