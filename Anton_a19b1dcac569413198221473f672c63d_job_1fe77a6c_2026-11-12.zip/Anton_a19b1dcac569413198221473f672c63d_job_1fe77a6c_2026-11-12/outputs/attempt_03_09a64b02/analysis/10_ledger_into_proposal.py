"""Step 10. Rewrite the 'Appendix A: evidence ledger' table inside the proposal markdown from ../tables/evidence_ledger.csv."""
import os, re, pandas as pd
HERE=os.path.dirname(os.path.abspath(__file__)); MD=os.path.join(HERE,'..','CRE-MK-01_validation_proposal.md')
L=pd.read_csv(os.path.join(HERE,'..','tables','evidence_ledger.csv')).fillna('')
THEME={'SLC6A8 (megakaryocyte)':'MK SLC6A8','SLC6A8 (tumour cell)':'Tumour SLC6A8','Platelets as effector':'Platelets','Human cohort':'Human','Safety signal':'Safety'}
def pretty(t):
    t=str(t)
    t=t.replace('->','→').replace('umol/g','µmol/g').replace(' uM',' µM').replace('x10^9/L','×10⁹/L').replace(' x ',' × ')
    t=re.sub(r'(?<=\d)x(?![0-9A-Za-z])','×',t)
    t=t.replace('|log2FC|<=2.5','absolute log2 fold change ≤ 2.5').replace('<=','≤').replace('>=','≥')
    t=t.replace('dCt','ΔCt').replace('beta-actin','β-actin').replace('|',' ')
    t=re.sub(r'(?<=\d)-(?=\d)','–',t); t=re.sub(r'(?<=[ (])-(?=\d)','−',t)
    t=re.sub(r'\s*\(step \d+\)','',t).replace('Phosphoproteomics workbook','Phospho-proteomics workbook')
    return '—' if t.strip() in ('','-') else t
rows=['| Theme | Panel | System; n | Finding | Statistic | Caveat |','|---|---|---|---|---|---|']
for r in L.itertuples():
    sysn=pretty(r.system) if pretty(r.n)=='—' else pretty(r.system)+'; '+pretty(r.n)
    rows.append('| '+' | '.join([THEME.get(r.theme,r.theme),pretty(r.panel),sysn,pretty(r.finding),pretty(r.statistic),pretty(r.caveat)])+' |')
block=("## Appendix A: evidence ledger\n\nEvery panel used, with the numbers recomputed from the raw cells. MK = megakaryocyte. "
       "The same table is in `tables/evidence_ledger.csv`.\n\n"+'\n'.join(rows)+'\n\n')
s=open(MD,encoding='utf-8').read(); a=s.index('## Appendix A: evidence ledger'); b=s.index('## Appendix B: smaller data notes')
open(MD,'w',encoding='utf-8').write(s[:a]+block+s[b:]); print('ledger rows written into proposal:',len(rows)-2)
