"""Step 09. Panel-level evidence ledger. Every number is computed here from the raw cells or read from the tables
written by steps 02-05, so nothing is typed by hand. Output: ../tables/evidence_ledger.csv"""
from lib import *
import os, warnings; warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf
from qpcr import parse_qpcr, PANEL_GENES as G, log2fc
rows=[]
def add(theme, panel, system, n, finding, stat, caveat=''):
    rows.append(dict(theme=theme,panel=panel,system=system,n=n,finding=finding,statistic=stat,caveat=caveat))
m=lambda x: float(np.mean(x))
p_t=lambda a,b: stats.ttest_ind(a,b).pvalue
def fp(p):
    if p<1e-4: return f'P={p:.0e}'.replace('e-0','e-')
    if p<0.001: return f'P={p:.4f}'
    return f'P={p:.3f}' if p<0.1 else f'P={p:.2f}'
def inter(g):
    d=pd.DataFrame([dict(A=a,B=b,y=v) for (a,b),x in zip([(0,0),(0,1),(1,0),(1,1)],g) for v in x]); return smf.ols('y ~ A*B',d).fit().pvalues['A:B']
gm=lambda l: 2**np.mean(l)
R=pd.read_csv(os.path.join(TABLES,'share_of_creatine_effect_removed.csv'))
def share(name, ep):
    r=R[R.intervention.str.contains(name,regex=False)&(R.endpoint==ep)].iloc[0]; return f'{r.fraction_of_creatine_effect_removed*100:.0f}% of creatine effect removed (95% CI {r.ci95_low*100:.0f}-{r.ci95_high*100:.0f}%)'
# ---------------- phenotype and exposure
add('Phenotype','Fig. 1b, 1f, 1k, 3i, 6b; Supp. Fig. 1e, 1f, 1g, 1i, 1k','mouse lung metastasis, creatine vs vehicle (control arms only)','10 experiments, 122 mice','Metastatic burden 3.0x (95% CI 2.5-3.6), foci 1.9x (1.7-2.2), lung weight 1.37x (1.26-1.50; 9 experiments); every experiment individually P<0.05','random-effects pooling of log ratio of means (step 02)','tumour line and route not labelled per panel; unblinded read-outs')
add('Phenotype','Fig. 1c; Fig. 1l','survival','10 vs 10; 20 vs 18','Median survival 22 vs 19 days (hazard ratio 2.9, 1.0-8.2) and 16 vs 14 days (2.3, 1.2-4.5)','log-rank P=0.032; P=0.011 (reproduced)','unequal n in Fig. 1l not explained')
S='Fig. 1h'; a,b,a0,b0=row(S,7,'B','G'),row(S,7,'H','M'),row(S,4,'B','G'),row(S,4,'H','M')
add('Phenotype','Fig. 1h','early lung signal after tumour-cell injection (units not stated)','6 vs 6',f'No difference at 0.25 h ({m(a0):.1f} vs {m(b0):.1f}); {m(b)/m(a):.1f}x more signal retained at 24 h with creatine',f't-test at 24 h {fp(p_t(a,b))}')
S='Supplementary Fig  1d'; a,b=col(S,'B',4,9),col(S,'C',4,9); S2='Supplementary Fig  1h'; c,d=col(S2,'C',4,7),col(S2,'D',4,7)
add('Exposure','Supp. Fig. 1d, 1h','mouse serum creatine','6 vs 6; 4 vs 4',f'{m(a):.0f} -> {m(b):.0f} uM (oral dosing); {m(c):.0f} -> {m(d):.0f} uM (5% diet)',f'{fp(p_t(a,b))}; {fp(p_t(c,d))}')
# ---------------- platelets
S='Fig. 2b'
add('Platelets as effector','Fig. 2b','mouse platelet aggregation','3 vs 3',f'ADP {m(row(S,4,"B","D")):.0f} -> {m(row(S,4,"E","G")):.0f}%, collagen {m(row(S,5,"B","D")):.0f} -> {m(row(S,5,"E","G")):.0f}%, thrombin {m(row(S,6,"B","D")):.0f} -> {m(row(S,6,"E","G")):.0f}%','t-tests P=0.0003-0.001','SDs of 1-5 points: replicates may be technical')
S='Fig. 2a'
add('Platelets as effector','Fig. 2a; Supp. Fig. 3a','mouse blood counts','3 vs 3; 5 vs 5',f'Platelet count unchanged ({m(col(S,"B",4,6)):.0f} vs {m(col(S,"C",4,6)):.0f} x10^9/L); white cells, lymphocytes, monocytes, red cells unchanged','all not significant')
S='Fig. 2d'; a,b=col(S,'B',28,32),col(S,'C',28,32)
add('Platelets as effector','Fig. 2d','thromboelastography','5 vs 5',f'Only maximum amplitude moved ({m(a):.1f} -> {m(b):.1f} mm)',f'{fp(p_t(a,b))}; Welch P={stats.ttest_ind(a,b,equal_var=False).pvalue:.3f}','one of four parameters; not robust to multiplicity')
S='Supplementary Fig  2d'; g=[col(S,c,5,10) for c in 'CDE']; gu=[col(S,'C',5,7),col(S,'D',5,7)]
add('Platelets as effector','Supp. Fig. 2d','metastasis in recipients of donor platelets','6/6/6',f'Burden {m(g[0]):.1f}% (vehicle donors) vs {m(g[1]):.1f}% (creatine donors) vs {m(g[2]):.1f}% (creatine + aspirin donors)','Tukey P=0.0004 and P=0.0001',f'3 vehicle + 3 creatine mice are numerically identical to Fig. 6b animals; excluding them: {m(gu[0]):.1f} vs {m(gu[1]):.1f}%, {fp(p_t(gu[0],gu[1]))}')
add('Platelets as effector','Fig. 2e, 2g (blots)','GP6 and P2RY12 protein in platelets and megakaryocytes of dosed mice','3 lanes per arm','Both bands stronger with creatine in megakaryocytes; in platelets the change is modest and bands are near saturation','not quantified in the package','read by eye')
add('Platelets as effector','Fig. 2i (blot)','creatine added to cultured cells','1 lane per dose','GP6 and P2RY12 rise in megakaryocytes at 0.2 and 2 mM; no change in platelets','not quantified in the package')
# ---------------- SLC6A8
S='Fig. 1f'; g=[col(S,c,22,27) for c in 'BCDE']
add('SLC6A8 (tumour cell)','Fig. 1f','melanoma with sh-Slc6a8, metastasis','6 per group',f'Creatine effect intact: burden {m(g[0]):.1f} -> {m(g[1]):.1f}% (sh-scrambled) vs {m(g[2]):.1f} -> {m(g[3]):.1f}% (sh-Slc6a8)',f'interaction {fp(inter(g))}; lung weight, SUV, foci P=0.21-0.95','knock-down 81% at mRNA (Supp. Fig. 2a) but only about 40% at protein by densitometry of the single blot (step 08)')
S='Fig. 3b'
add('SLC6A8 (megakaryocyte)','Fig. 3b','serum creatine in Pf4-Cre; Slc6a8 fl/fl vs Cre controls','5 per group',f'Systemic exposure equal: {m(row(S,4,"B","F")):.0f} -> {m(row(S,4,"G","K")):.0f} uM (controls), {m(row(S,5,"B","F")):.0f} -> {m(row(S,5,"G","K")):.0f} uM (knockout)','both P<1e-5')
S='Fig. 3c'; g=[row(S,4,'B','D'),row(S,4,'E','G'),row(S,5,'B','D'),row(S,5,'E','G')]
add('SLC6A8 (megakaryocyte)','Fig. 3c','megakaryocyte creatine content','3 per group',f'{m(g[0]):.1f} -> {m(g[1]):.1f} umol/g in controls ({m(g[1])/m(g[0]):.1f}x) vs {m(g[2]):.1f} -> {m(g[3]):.1f} in knockout ({m(g[3])/m(g[2]):.1f}x)',f'controls {fp(p_t(g[0],g[1]))}; knockout {fp(p_t(g[2],g[3]))}; interaction {fp(inter(g))}','n=3; wide spread in treated controls')
S='Fig. 3d'; v={lab:[row(S,r,'B','D'),row(S,r,'E','G'),row(S,r,'H','J'),row(S,r,'K','M')] for lab,r in [('ADP',4),('collagen',5),('thrombin',6)]}
add('SLC6A8 (megakaryocyte)','Fig. 3d','platelet aggregation','3 per group','Creatine effect reverses sign in knockout ('+'; '.join(f'{k}: controls {m(x[1])-m(x[0]):+.0f}, knockout {m(x[3])-m(x[2]):+.0f} points' for k,x in v.items())+'); knockout baseline 4-16 points lower','all Tukey P<=0.001','SD about 1 point: replicates may be technical; the drop below baseline in knockout is unexplained')
add('SLC6A8 (megakaryocyte)','Fig. 3f','megakaryocyte 11-gene platelet-activation panel','3 per group',f'Creatine induction {gm(log2fc("Fig. 3f","ΔCT2","ΔCT1")):.1f}x in controls (11/11 genes P<0.05) vs {gm(log2fc("Fig. 3f","ΔCT4","ΔCT3")):.2f}x in knockout','gene-level interaction P<0.05 for 7/11 genes')
S='Fig. 3i'
for lab,r0,f,u in [('burden',10,'{:.1f}','%'),('foci',17,'{:.1f}',''),('lung weight',3,'{:.3f}',' g')]:
    g4=[col(S,c,r0,r0+3) for c in 'BCDE']
    add('SLC6A8 (megakaryocyte)','Fig. 3i',f'metastasis: {lab}','4 per group',f'{f.format(m(g4[0]))} -> {f.format(m(g4[1]))}{u} in Cre controls vs {f.format(m(g4[2]))} -> {f.format(m(g4[3]))}{u} in knockout; {share("Slc6a8 knockout",lab)}',f'genotype x creatine interaction {fp(inter(g4))}','single experiment, n=4, unblinded; knockout band reduced but present on blot (Supp. Fig. 4a)' if lab=='burden' else '')
add('SLC6A8 (megakaryocyte)','Fig. 3g (blot)','megakaryocyte GP6 and P2RY12 protein','2 lanes per arm','Both rise with creatine in Cre-control megakaryocytes and not in knockout megakaryocytes','not quantified in the package','read by eye')
add('SLC6A8 (megakaryocyte)','Supp. Fig. 4e','knockout megakaryocytes in culture, free vs liposomal creatine','3 per group',f'Free creatine {gm(log2fc("Supplementary Fig  4e","ΔCT2","ΔCT1")):.2f}x; liposome-delivered creatine {gm(log2fc("Supplementary Fig  4e","ΔCT3","ΔCT1")):.2f}x (9/11 genes P<0.05)','per-gene t-tests','no empty-liposome control')
S='Fig. 4a'
add('Safety signal','Fig. 4a, 4c; Fig. 4b (blot)','brain tissue','3 vs 3',f'Oral creatine also raises brain creatine {m(col(S,"D",4,6)):.0f} -> {m(col(S,"E",4,6)):.0f} umol/g and phosphocreatine {m(col("Fig. 4c","E",4,6))/m(col("Fig. 4c","D",4,6)):.1f}x; CKB band far stronger in brain than megakaryocytes','P=0.027; P=0.031','relevant to systemic SLC6A8 or CKB inhibition')
# ---------------- CKB
S='Fig. 4e'
add('CKB','Fig. 4e; Fig. 4b, 4g (blots)','Ckb in megakaryocytes','3 vs 3',f'Creatine raises Ckb mRNA {m(row(S,8,"I","K"))/m(row(S,8,"E","G")):.1f}x; protein up on blots in vivo and in vitro',fp(p_t(row(S,8,"E","G"),row(S,8,"I","K"))),'blots have one lane per condition')
add('CKB','Fig. 4j','cultured megakaryocytes, si-Ckb','3 per group',f'Creatine induction {gm(log2fc("Fig. 4j","ΔCT3","ΔCT1")):.1f}x with si-scrambled vs {gm(log2fc("Fig. 4j","ΔCT4","ΔCT2")):.1f}x with si-Ckb; si-Ckb alone lowers baseline to {gm(log2fc("Fig. 4j","ΔCT2","ΔCT1")):.2f}x','interaction P<0.05 for 10/11 genes','in vitro only; knock-down partial (Supp. Fig. 5b)')
add('CKB','Fig. 4l','cultured megakaryocytes, CKB over-expression','3 vs 3',f'Panel up {gm(log2fc("Fig. 4l","ΔCT2","ΔCT1")):.1f}x without added creatine (11/11 genes P<0.05)','per-gene t-tests','in vitro only')
S='Supplementary Fig  5c'
add('CKB','Fig. 4h; Supp. Fig. 5c','is it energy buffering?','3 per group',f'Phosphocreatine does not reproduce the induction ({gm(log2fc("Fig. 4h","ΔCT3","ΔCT1")):.2f}x); CKB over-expression leaves megakaryocyte creatine ({m(col(S,"B",5,7)):.1f} vs {m(col(S,"C",5,7)):.1f} umol/g) and phosphocreatine unchanged','P=0.61; P=0.16')
add('CKB','no panel','in vivo loss of function','-','None in the package','-','the decisive gap for CKB')
# ---------------- STAT5B
ph=pd.read_csv(os.path.join(CACHE,'phos.csv')); s5=ph[ph.gene=='Stat5b'].sort_values('p'); big=ph.lfc.abs()>2.5
add('STAT5B','Phosphoproteomics workbook','megakaryocyte phosphopeptides, creatine vs vehicle','3 vs 3 mice; 5,812 peptides',f'One of two Stat5b peptides up (log2 fold change {s5.lfc.iloc[0]:.1f}, P={s5.p.iloc[0]:.4f}, q={s5.q.iloc[0]:.2f}; rank 17 by P); the other unchanged (P={s5.p.iloc[1]:.2f}); Stat5a unchanged (P=0.40)',f'0 peptides at q<0.05 (smallest q {ph.q.min():.2f}); among {int((~big).sum()):,} peptides with |log2FC|<=2.5, {100*(ph.p[~big]<0.05).mean():.1f}% have P<0.05','site not given in the file; a nomination, not a confirmation')
add('STAT5B','Supp. Fig. 6a (blot)','canonical tyrosine phosphorylation in megakaryocytes','3 vs 3 lanes','p-STAT5A/B (Y694/699) not detected with or without creatine; IL-2-treated Jurkat control positive; total STAT5B unchanged','not quantified','the creatine signal is not canonical STAT5 activation')
S='Fig. 5e'; w0,w1,a0,a1=col(S,'N',4,6),col(S,'N',17,19),col(S,'O',4,6),col(S,'O',17,19); S2='Fig. 5f'; x0,x1,y0,y1=col(S2,'N',4,6),col(S2,'N',17,19),col(S2,'O',4,6),col(S2,'O',17,19)
def mut_inter(sheet):
    recs=[]
    for mut,c in zip(['WT','S127A'],'NO'):
        recs += [dict(mut=mut,trt=0,y=v) for v in col(sheet,c,4,6)] + [dict(mut=mut,trt=1,y=v) for v in col(sheet,c,17,19)]
    for mut,c in zip(['3A','S127D'],'PQ'):
        recs += [dict(mut=mut,trt=0,y=v) for v in col(sheet,c,4,6)] + [dict(mut=mut,trt=1,y=v) for v in col(sheet,c,17,19)]
    mo=smf.ols('y ~ C(mut, Treatment("WT"))*trt',pd.DataFrame(recs)).fit(); return mo.pvalues[[k for k in mo.pvalues.index if 'S127A' in k and ':' in k][0]]
add('STAT5B','Fig. 5e, 5f','STAT5B-FLAG (WT, S127A, 3A, S127D): pan-phospho / FLAG densitometry','3 blots per arm',f'Creatine raises WT signal {m(w1)/m(w0):.2f}x ({fp(p_t(w0,w1))}) and {m(x1)/m(x0):.2f}x ({fp(p_t(x0,x1))}); S127A does not respond ({m(a1)/m(a0):.2f}x, {m(y1)/m(y0):.2f}x)',f'S127A x creatine interaction {fp(mut_inter(S))} and {fp(mut_inter(S2))} (two-way model over the four constructs)','over-expressed protein, pan-phospho antibody; cell type not labelled (companion blots are 293T, not megakaryocytes); in one replicate vehicle and creatine lanes are on separate membranes')
add('STAT5B','Fig. 5g-i; Supp. Fig. 6d (blots)','CKB dependence of STAT5B phosphorylation','single blots','si-CKB removes the creatine-induced signal; CKB over-expression raises it on WT not S127A; recombinant CKB + ATP raises signal on purified STAT5B-FLAG','not quantified in the package','no kinase-dead CKB or S127A-substrate control; in the nuclear blot (Fig. 5h) S127A still rises about 2x with creatine by densitometry (step 08)')
S='Fig. 5j'; fold=lambda sh,r,vc,cc: m(row(sh,r,*cc))/m(row(sh,r,*vc))
add('STAT5B','Fig. 5j; Supp. Fig. 6i','ChIP-qPCR at P2ry12, Gp6, Rab4a promoters','3 vs 3',f'P2ry12 promoter {fold(S,7,("B","D"),("E","G")):.1f}-{fold(S,8,("B","D"),("E","G")):.0f}x; Gp6 -1 kb {fold(S,17,("B","D"),("E","G")):.1f}x; Rab4a -0.2 kb {fold("Supplementary Fig  6i",10,("C","E"),("F","H")):.1f}x; exon controls unchanged','Sidak P<0.0001 to 0.04 (reproduced)','exon background 5-11% of input; antibody and IgG control not in the package')
add('STAT5B','Fig. 6a','megakaryocytes + STAT5-IN-1','3 per group',f'Creatine induction {gm(log2fc("Fig.6a","ΔCT2","ΔCT1")):.1f}x without vs {gm(log2fc("Fig.6a","ΔCT4","ΔCT3")):.2f}x with inhibitor; inhibitor alone lowers baseline to {gm(log2fc("Fig.6a","ΔCT3","ΔCT1")):.2f}x','interaction P<0.05 for 9/11 genes','inhibits STAT5A and STAT5B')
S='Fig. 6b'; g4=[col(S,c,4,8) for c in 'BCDE']
add('STAT5B','Fig. 6b','metastasis with systemic STAT5-IN-1','5 per group',f'Burden {m(g4[0]):.1f} -> {m(g4[1]):.1f}% without vs {m(g4[2]):.1f} -> {m(g4[3]):.1f}% with inhibitor; {share("STAT5-IN-1","burden")}',f'interaction {fp(inter(g4))}','not STAT5B-selective, not megakaryocyte-specific; 6 control animals also appear in Supp. Fig. 2d')
S='Fig. 6e'
add('STAT5B','Fig. 6e','megakaryocyte creatine in Pf4-iCre; Stat5b fl/fl','3 per group',f'Uptake intact: {m(col(S,"D",5,7)):.0f} (WT + creatine) vs {m(col(S,"E",5,7)):.0f} umol/g (knockout + creatine)','Tukey P=0.98','places STAT5B downstream of uptake')
g6=parse_qpcr('Fig. 6g'); res=[x for x in G if stats.ttest_ind(g6[x]['ΔCT3'],g6[x]['ΔCT1']).pvalue<0.05 and g6[x]['ΔCT3'].mean()>g6[x]['ΔCT1'].mean()]
add('STAT5B','Fig. 6g; Fig. 6f (blot)','megakaryocyte gene panel in Stat5b knockout','3 per group; 3 arms',f'{gm(log2fc("Fig. 6g","ΔCT2","ΔCT1")):.1f}x in WT + creatine vs {gm(log2fc("Fig. 6g","ΔCT3","ΔCT1")):.2f}x in knockout + creatine (both vs WT vehicle); all 11 genes lower than WT + creatine, but {", ".join(res)} remain 1.6-1.9x above vehicle (P<0.05)','per-gene t-tests','no vehicle-treated knockout arm; controls labelled WT, not Cre-matched; no platelet-function or metastasis read-out')
# ---------------- human cohort
S='Fig. 7b'; cr=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(4,15)],float)
add('Human cohort','Fig. 7b','serum creatine, 20 g/day for 14 days','11 volunteers',f'{cr[:,0].mean():.0f} -> {cr[:,1].mean():.0f} (day 3), {cr[:,2].mean():.0f} (day 7), {cr[:,3].mean():.0f} uM (day 14); 11/11 rise','paired t P<1e-7 at each day','single arm, no placebo; healthy 20-25-year-olds')
Hh=pd.read_csv(os.path.join(TABLES,'human_platelet_response_by_agonist.csv')); d14=Hh[Hh.day==14]
add('Human cohort','Fig. 7c','platelet aggregation/adhesion at day 14 vs day 0 (mean of three read-outs per agonist)','11 volunteers','; '.join(f'{r.agonist} {r.geometric_mean_fold_vs_day0:.2f}x ({r.ci95_low:.2f}-{r.ci95_high:.2f}; {r.volunteers_increased}/11 up; Wilcoxon {fp(r.P_wilcoxon_signed_rank)})' for r in d14.itertuples()),'paired analysis on log scale (the workbook used unpaired ANOVA against an all-ones baseline)',f'nothing moves at day 3; only epinephrine at day 7 ({Hh[(Hh.day==7)&(Hh.agonist=="epinephrine")].geometric_mean_fold_vs_day0.iloc[0]:.2f}x)')
S='Fig. 7e'; d=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(4,8)],float); d2=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(12,16)],float)
add('Human cohort','Fig. 7e','platelet protein (immunoblot / beta-actin)','4 volunteers',f'GP6 {gm(np.log2(d[:,2]/d[:,0])):.1f}x (day 7), {gm(np.log2(d[:,3]/d[:,0])):.1f}x (day 14), 4/4 up; P2RY12 {gm(np.log2(d2[:,3]/d2[:,0])):.1f}x (day 14), 4/4 up',f'paired t at day 14: GP6 {fp(stats.ttest_rel(d[:,3],d[:,0]).pvalue)}, P2RY12 {fp(stats.ttest_rel(d2[:,3],d2[:,0]).pvalue)}','protein, not transcript; n=4')
T=pd.read_csv(os.path.join(TABLES,'human_cd41_transcripts.csv')); t7=T[T.day==7]
add('Human cohort','Fig. 7d','transcripts in circulating CD41+ cells','4 volunteers',f'At day 7, {(t7.volunteers_increased>=3).sum()} of 11 genes are up in at least 3 of 4 volunteers (ADRA2A {t7[t7.gene=="ADRA2A"].geometric_mean_fold.iloc[0]:.0f}x, 4/4); volunteer 2 does not respond',f'paired log-scale t: {(t7.P_one_sample_t_on_log2<0.05).sum()} genes P<0.05 at day 7','volunteer-4 values for RAB27B and PITPNB cannot be reproduced from the listed dCt')
S='Fig. 7g'; a,b=col(S,'B',12,16),col(S,'C',12,16)
add('Human cohort','Fig. 7g','volunteer platelets (day 0 vs day 7) transferred into mice','5 vs 5 recipients',f'Burden {m(a):.1f} -> {m(b):.1f}% ({m(b)/m(a):.1f}x)',fp(p_t(a,b)),'number of donors not stated')
S='Supplementary Fig  8b'; d=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(4,15)],float)
add('Human cohort','Supp. Fig. 8a, 8b','BMI, platelet count and indices','11 volunteers',f'No change (platelets {d[:,0].mean():.0f} -> {d[:,3].mean():.0f} x10^9/L at day 14)','paired t all P>0.1')
pd.DataFrame(rows).to_csv(os.path.join(TABLES,'evidence_ledger.csv'),index=False)
print('ledger rows:',len(rows))
