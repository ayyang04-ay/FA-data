"""Render the proposal markdown (restricted subset) to PDF with reportlab."""
import re, os, sys
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether, CondPageBreak
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import matplotlib
fd=os.path.join(os.path.dirname(matplotlib.__file__),'mpl-data','fonts','ttf')
pdfmetrics.registerFont(TTFont('DV',os.path.join(fd,'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B',os.path.join(fd,'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DV-I',os.path.join(fd,'DejaVuSans-Oblique.ttf')))
pdfmetrics.registerFont(TTFont('DV-BI',os.path.join(fd,'DejaVuSans-BoldOblique.ttf')))
pdfmetrics.registerFont(TTFont('DVM',os.path.join(fd,'DejaVuSansMono.ttf')))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily('DV',normal='DV',bold='DV-B',italic='DV-I',boldItalic='DV-BI')
SRC=sys.argv[1]; OUT=sys.argv[2]; BASE=os.path.dirname(os.path.abspath(SRC))
body=ParagraphStyle('body',fontName='DV',fontSize=9.2,leading=13,spaceAfter=5,alignment=TA_LEFT)
lead=ParagraphStyle('lead',parent=body,fontName='DV-B',fontSize=10.6,leading=15,spaceAfter=8,textColor=colors.HexColor('#111827'),backColor=colors.HexColor('#fff7ed'),borderPadding=(7,7,7,7),borderColor=colors.HexColor('#c2410c'),borderWidth=0.8)
h1=ParagraphStyle('h1',fontName='DV-B',fontSize=14.5,leading=18,spaceBefore=10,spaceAfter=6)
h2=ParagraphStyle('h2',fontName='DV-B',fontSize=11.8,leading=15,spaceBefore=11,spaceAfter=4,textColor=colors.HexColor('#9a3412'),keepWithNext=1)
h3=ParagraphStyle('h3',fontName='DV-B',fontSize=10,leading=13,spaceBefore=7,spaceAfter=3,keepWithNext=1)
bullet=ParagraphStyle('bullet',parent=body,leftIndent=11,bulletIndent=1,spaceAfter=3,bulletFontName='DV',bulletFontSize=9.2)
cell=ParagraphStyle('cell',fontName='DV',fontSize=7.6,leading=9.8)
cellh=ParagraphStyle('cellh',fontName='DV-B',fontSize=7.8,leading=10,textColor=colors.white)
cap=ParagraphStyle('cap',fontName='DV-I',fontSize=8,leading=10.5,spaceAfter=9,textColor=colors.HexColor('#374151'))
def inline(t):
    t=t.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    t=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',t)
    t=re.sub(r'(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?![\*\w])',r'<i>\1</i>',t)
    t=re.sub(r'`(.+?)`',r'<font name="DVM" size="8">\1</font>',t)
    return t
lines=open(SRC,encoding='utf-8').read().split('\n')
story=[]; i=0; first=True
W=A4[0]-36*mm
while i<len(lines):
    ln=lines[i]
    if not ln.strip(): i+=1; continue
    if first:
        story.append(Paragraph(inline(ln.strip().strip('*')),lead)); story.append(Spacer(1,4)); first=False; i+=1; continue
    if ln.startswith('# '): story.append(Paragraph(inline(ln[2:]),h1)); i+=1; continue
    if ln.startswith('## ') or ln.startswith('### '):
        st=h2 if ln.startswith('## ') else h3; text=ln.split(' ',1)[1]
        j=i+1
        while j<len(lines) and not lines[j].strip(): j+=1
        if j<len(lines) and lines[j].startswith('|'):
            # next block is a table: keep the heading with the first rows only, then let the table split across pages
            story.append(CondPageBreak(150)); story.append(Paragraph(inline(text),ParagraphStyle(st.name+'_t',parent=st,keepWithNext=0)))
        else:
            story.append(Paragraph(inline(text),st))
        i+=1; continue
    m=re.match(r'!\[(.*?)\]\((.*?)\)',ln.strip())
    if m:
        path=os.path.join(BASE,m.group(2))
        from PIL import Image as PI
        w,h=PI.open(path).size; iw=W; ih=iw*h/w
        img=Image(path,width=iw,height=ih); i+=1
        # look ahead for caption line
        j=i
        while j<len(lines) and not lines[j].strip(): j+=1
        if j<len(lines) and lines[j].startswith('*') and not lines[j].startswith('**'):
            story.append(KeepTogether([img,Spacer(1,3),Paragraph(inline(lines[j].strip().strip('*')),cap)])); i=j+1
        else:
            story.append(img)
        continue
    if ln.startswith('|'):
        rows=[]
        while i<len(lines) and lines[i].startswith('|'):
            rows.append(lines[i]); i+=1
        hdr=[c.strip() for c in rows[0].strip().strip('|').split('|')]
        data=[[Paragraph(inline(c),cellh) for c in hdr]]
        for r in rows[2:]:
            cells=[c.strip() for c in r.strip().strip('|').split('|')]
            data.append([Paragraph(inline(c),cell) for c in cells])
        n=len(hdr)
        # column widths: first column narrower for multi-col tables
        if n==2:
            L0=sum(len(r.strip().strip('|').split('|')[0]) for r in rows[2:])/max(1,len(rows)-2)
            L1=sum(len(r.strip().strip('|').split('|')[1]) for r in rows[2:])/max(1,len(rows)-2)
            f=min(0.5,max(0.24,L0/(L0+L1))); cw=[W*f,W*(1-f)]
        elif n==4: cw=[W*0.19,W*0.31,W*0.28,W*0.22]
        elif n==5: cw=[W*0.15,W*0.2,W*0.24,W*0.23,W*0.18]
        elif n==6: cw=[W*0.1,W*0.1,W*0.17,W*0.31,W*0.15,W*0.17]
        else: cw=[W/n]*n
        t=Table(data,colWidths=cw,repeatRows=1)
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#7c2d12')),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),0.35,colors.HexColor('#d1d5db')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f9fafb')]),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
        story.append(t); story.append(Spacer(1,7)); continue
    if ln.startswith('- '):
        items=[]
        while i<len(lines) and lines[i].startswith('- '):
            items.append(lines[i][2:]); i+=1
        for it in items: story.append(Paragraph(inline(it),bullet,bulletText='•'))
        story.append(Spacer(1,3)); continue
    if ln.startswith('*') and ln.rstrip().endswith('*') and not ln.startswith('**'):
        story.append(Paragraph(inline(ln.strip().strip('*')),cap)); i+=1; continue
    story.append(Paragraph(inline(ln),body)); i+=1
def footer(canvas,doc):
    canvas.saveState(); canvas.setFont('DV',7.5); canvas.setFillColor(colors.HexColor('#6b7280'))
    canvas.drawString(18*mm,10*mm,'CRE-MK-01 follow-up: validation proposal'); canvas.drawRightString(A4[0]-18*mm,10*mm,f'Page {doc.page}'); canvas.restoreState()
doc=SimpleDocTemplate(OUT,pagesize=A4,leftMargin=18*mm,rightMargin=18*mm,topMargin=16*mm,bottomMargin=17*mm,title='CRE-MK-01 follow-up: validation proposal',author='')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print('built',OUT)
