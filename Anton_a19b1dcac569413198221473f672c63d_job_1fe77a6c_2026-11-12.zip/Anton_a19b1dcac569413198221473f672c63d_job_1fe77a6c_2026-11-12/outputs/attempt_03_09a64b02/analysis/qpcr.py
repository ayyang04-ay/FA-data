"""Parser for the ΔCt sheets. Each gene block holds rows labelled ΔCT1 (control arm), ΔCT2, ΔCT3, ΔCT4 (other arms),
three replicate values each. ΔCt is stored so that a larger value means more transcript (fold = 2^ΔΔCt)."""
import re, numpy as np, pandas as pd
from scipy import stats
from lib import CELLS, colnum

def parse_qpcr(sheet):
    rows = {}
    for addr, v in CELLS[sheet].items():
        m = re.match(r'([A-Z]+)(\d+)', addr)
        rows.setdefault(int(m.group(2)), {})[colnum(m.group(1))] = v
    genes = {}; cur = None
    for r in sorted(rows):
        rc = rows[r]; a = rc.get(1)
        if isinstance(a, str) and not a.startswith('Graphs') and len(a) < 20:
            cur = a; genes[cur] = {}
        if cur is None: continue
        for c in sorted(rc):
            v = rc[c]
            if isinstance(v, str) and re.fullmatch(r'ΔCT\d', v.strip()):
                vals = [rc.get(c+k) for k in (1, 2, 3)]
                if all(isinstance(x, (int, float)) for x in vals):
                    genes[cur].setdefault(v.strip(), np.array(vals, float))
    return {g: d for g, d in genes.items() if 'ΔCT1' in d}

PANEL_GENES = ['Gp6', 'P2ry12', 'Gpiba', 'F2r', 'Adra2a', 'Itga2b', 'Fcgr2a', 'Rab4a', 'Rab27b', 'Pitpnb', 'Runx1']
def log2fc(sheet, num, den, genes=PANEL_GENES):
    g = parse_qpcr(sheet)
    return np.array([g[x][num].mean()-g[x][den].mean() for x in genes])
