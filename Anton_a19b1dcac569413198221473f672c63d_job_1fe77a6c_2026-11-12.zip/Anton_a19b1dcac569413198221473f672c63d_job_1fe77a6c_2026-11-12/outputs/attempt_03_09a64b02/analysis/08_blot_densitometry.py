"""Step 08. Approximate densitometry of four embedded blot images, used only where the workbook gives no numbers.
These are 8-bit JPEGs of single blots, some bands near saturation: treat every value as semi-quantitative.
Needs Pillow. Band boxes were placed by inspection of each image (pixel coordinates in the original image)."""
import os, numpy as np
from PIL import Image
HERE=os.path.dirname(os.path.abspath(__file__)); B=os.path.join(HERE,'cache','blots')
def load(name):
    im=Image.open(os.path.join(B,name)); return 255-np.asarray(im.convert('L'),float), np.asarray(im.convert('RGB'),float)
def box(a, x0,x1,y0,y1, bgrows, mask=None):
    """integrated signal above local background (median of the stated background rows in the same lane)"""
    bg=np.median(np.concatenate([a[r0:r1,x0:x1].ravel() for r0,r1 in bgrows])); v=(a[y0:y1,x0:x1]-bg).clip(min=0)
    if mask is not None: v[mask[y0:y1,x0:x1]]=0
    return float(v.sum())
def lane_band(a, x0,x1, ysearch, half=10, pad=6, bgw=6):
    """find the band peak row within ysearch, integrate +/- half rows above the local background"""
    prof=np.convolve(a[ysearch[0]:ysearch[1],x0:x1].mean(1),np.ones(5)/5,mode='same'); yc=ysearch[0]+int(np.argmax(prof)); y0,y1=yc-half,yc+half+1
    bg=np.median(np.r_[a[y0-pad-bgw:y0-pad,x0:x1].ravel(),a[y1+pad:y1+pad+bgw,x0:x1].ravel()])
    return float((a[y0:y1,x0:x1]-bg).clip(min=0).sum())
# (a) Supp. Fig. 2a: tumour-cell SLC6A8 after sh-Slc6a8
a,_=load('Supplementary_Fig_2a.jpeg')
s_scr=box(a,200,248,262,298,[(215,245)]); s_sh=box(a,262,312,262,298,[(215,245)])
b_scr=box(a,472,508,232,258,[(200,225)]); b_sh=box(a,518,556,232,258,[(200,225)])
print(f'(a) Supp. Fig. 2a tumour-cell SLC6A8: sh-Slc6a8 / sh-scrambled = {s_sh/s_scr:.2f} raw, {(s_sh/b_sh)/(s_scr/b_scr):.2f} after beta-actin -> roughly 40% protein knock-down (mRNA knock-down 81%)')
# (b) Supp. Fig. 4a: megakaryocyte SLC6A8 in Pf4-Cre; Slc6a8 fl/fl (lanes inside the red box)
a,rgb=load('Supplementary_Fig_4a.jpeg'); red=(rgb[:,:,0]>150)&(rgb[:,:,1]<100)&(rgb[:,:,2]<100)
wt=box(a,271,305,259,279,[(249,256),(281,285)],red); ko=box(a,316,350,259,279,[(249,256),(281,285)],red)
bwt=box(a,808,852,224,249,[(214,221),(251,255)],red); bko=box(a,862,904,224,249,[(214,221),(251,255)],red)
print(f'(b) Supp. Fig. 4a megakaryocyte SLC6A8: knockout / control = {ko/wt:.2f} raw, {(ko/bko)/(wt/bwt):.2f} after beta-actin -> band reduced, not absent')
# (c) Fig. 5h: nuclear pan-phospho / FLAG for STAT5B-FLAG WT and S127A, +/- creatine, +/- si-CKB
a,_=load('Fig_5h.jpeg')
names=['si-scr veh WT','si-scr veh S127A','si-scr cre WT','si-scr cre S127A','si-CKB veh WT','si-CKB veh S127A','si-CKB cre WT','si-CKB cre S127A']
pp=[(318,356),(372,410),(474,512),(528,566),(630,668),(684,722),(792,830),(846,890)]; fl=[(326,366),(380,420),(488,522),(542,576),(644,678),(698,732),(800,840),(854,888)]
r=np.array([lane_band(a,*p,(320,385),half=10)/lane_band(a,*f,(700,770),half=14) for p,f in zip(pp,fl)])
print('(c) Fig. 5h pan-phospho/FLAG relative to si-scr vehicle WT:',dict(zip(names,np.round(r/r[0],2))))
print(f'    creatine / vehicle: si-scr WT {r[2]/r[0]:.2f}, si-scr S127A {r[3]/r[1]:.2f}, si-CKB WT {r[6]/r[4]:.2f}, si-CKB S127A {r[7]/r[5]:.2f}')
# (d) Supp. Fig. 6h: nuclear STAT5B / histone H3 in megakaryocytes, 2 vehicle and 2 creatine lanes
a,_=load('Supplementary_Fig_6h.jpeg')
st=[(232,268),(272,310),(312,352),(354,394)]; h3=[(706,748),(756,798),(804,844),(850,890)]
r=np.array([lane_band(a,*s,(222,250),half=7,pad=4,bgw=5)/lane_band(a,*h,(218,246),half=7,pad=4,bgw=5) for s,h in zip(st,h3)])
print(f'(d) Supp. Fig. 6h nuclear STAT5B/H3 relative to mean vehicle: vehicle {r[0]/r[:2].mean():.2f}, {r[1]/r[:2].mean():.2f}; creatine {r[2]/r[:2].mean():.2f}, {r[3]/r[:2].mean():.2f} (vehicle lanes differ {r[1]/r[0]:.1f}-fold)')
