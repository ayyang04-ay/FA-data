"""Step 06. Phosphoproteomics screen (megakaryocytes, creatine vs vehicle, n=3 vs 3): what the P and q values in the file support.
Output: ../tables/phosphoproteomics_screen_hits.csv (rows meeting the study's screening rule: P<0.05 and fold change >=1.2 or <=0.83)"""
import os, numpy as np, pandas as pd
from scipy import stats
HERE=os.path.dirname(os.path.abspath(__file__))
df=pd.read_csv(os.path.join(HERE,'cache','phos.csv'))
df['fold_change']=2**df.lfc
n=len(df); big=df.lfc.abs()>2.5; tie=np.isclose(df.p,0.42265,atol=1e-5)
print(f'rows {n:,}; genes {df.gene.nunique():,}; rows without gene name {df.gene.isna().sum()}')
print(f'P<0.05: {(df.p<0.05).sum()} ({100*(df.p<0.05).mean():.1f}%); q<0.05: {(df.q<0.05).sum()}; smallest q {df.q.min():.3f}; rows with q<0.25: {(df.q<0.25).sum()}')
print(f'rows sharing P=0.4227 (t=1, df=2: {2*stats.t.sf(1,2):.4f}): {tie.sum():,}; median |log2FC| among them {df.lfc[tie].abs().median():.2f} vs {df.lfc[~tie].abs().median():.2f} elsewhere')
print(f'|log2FC|>2.5: {big.sum():,} rows, {100*tie[big].mean():.0f}% of them share P=0.4227; |log2FC|<=2.5: {(~big).sum():,} rows, {100*(df.p[~big]<0.05).mean():.1f}% with P<0.05 and {(df.p[~big]<0.01).sum()} with P<0.01 (expected {0.01*(~big).sum():.0f})')
s=df.sort_values('p').reset_index(drop=True)
print('Stat5 rows:'); print(df[df.gene.fillna('').str.match(r'Stat5')].round(4).to_string())
print('rank of best Stat5b peptide by P:', s.index[s.gene=='Stat5b'][0]+1)
hits=df[(df.p<0.05)&((df.fold_change>=1.2)|(df.fold_change<=0.83))].sort_values('p')
up=hits[hits.lfc>0].sort_values('lfc',ascending=False).reset_index(drop=True)
print(f'screen-positive rows {len(hits)} ({hits.gene.nunique()} genes): up {len(up)}, down {(hits.lfc<0).sum()}; Stat5b rank among up-hits by fold change: {up.index[up.gene=="Stat5b"][0]+1}')
hits=hits.rename(columns={'gene':'GeneName','p':'P_unadjusted','q':'Q_value_from_file','lfc':'log2_fold_change'})
hits['abs_log2FC_above_2.5']=hits.log2_fold_change.abs()>2.5
hits.to_csv(os.path.join(HERE,'..','tables','phosphoproteomics_screen_hits.csv'),index=False)
