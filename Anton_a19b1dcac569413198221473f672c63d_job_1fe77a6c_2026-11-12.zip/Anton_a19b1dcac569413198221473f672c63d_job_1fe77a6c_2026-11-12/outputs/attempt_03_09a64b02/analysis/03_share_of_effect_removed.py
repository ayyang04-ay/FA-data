"""Step 03. For each perturbation tested on metastasis: interaction test (two-way model, permutation check, log scale)
and the share of the creatine effect removed, with bootstrap 95% intervals.
Output: ../tables/share_of_creatine_effect_removed.csv"""
from lib import *
import os, warnings; warnings.filterwarnings('ignore')
import statsmodels.formula.api as smf
rng=np.random.default_rng(20240607)
def share_2x2(v0,c0,v1,c1,B=20000):
    est=1-(c1.mean()-v1.mean())/(c0.mean()-v0.mean()); sims=[]
    for _ in range(B):
        a,b,c,d=[rng.choice(x,len(x)) for x in (v0,c0,v1,c1)]; den=b.mean()-a.mean()
        if den>0: sims.append(1-(d.mean()-c.mean())/den)
    return (est,*np.percentile(sims,[2.5,97.5]))
def share_3arm(v,c,x,B=20000):
    est=(c.mean()-x.mean())/(c.mean()-v.mean()); sims=[]
    for _ in range(B):
        a,b,d=[rng.choice(y,len(y)) for y in (v,c,x)]; den=b.mean()-a.mean()
        if den>0: sims.append((b.mean()-d.mean())/den)
    return (est,*np.percentile(sims,[2.5,97.5]))
def interaction(groups, log=False):
    rr=[dict(A=a,B=b,y=(np.log(v) if log else v)) for (a,b),g in zip([(0,0),(0,1),(1,0),(1,1)],groups) for v in g]
    d=pd.DataFrame(rr); m=smf.ols('y ~ A*B',d).fit(); return m.params['A:B'], m.pvalues['A:B']
def perm_interaction(groups, B=50000):
    g=[x.copy() for x in groups]; ns=[len(x) for x in g]; allv=np.concatenate(g); idx=np.cumsum(ns)[:-1]
    stat=lambda q: (q[1].mean()-q[0].mean())-(q[3].mean()-q[2].mean())
    A=np.r_[np.zeros(ns[0]+ns[1]),np.ones(ns[2]+ns[3])]; Bf=np.r_[np.zeros(ns[0]),np.ones(ns[1]),np.zeros(ns[2]),np.ones(ns[3])]
    X=np.c_[np.ones(len(allv)),A,Bf]; fit=X@np.linalg.lstsq(X,allv,rcond=None)[0]; res=allv-fit; obs=stat(g)
    cnt=sum(abs(stat(np.split(fit+rng.permutation(res),idx)))>=abs(obs)-1e-12 for _ in range(B))
    return (cnt+1)/(B+1)
out=[]
def do_2x2(name, sheet, cols, blocks, n):
    for lab,r0,r1 in blocks:
        g=[col(sheet,c,r0,r1) for c in cols]; e=share_2x2(*g); _,p=interaction(g); _,pl=interaction(g,log=True); pp=perm_interaction(g)
        out.append(dict(intervention=name,endpoint=lab,fraction_of_creatine_effect_removed=e[0],ci95_low=e[1],ci95_high=e[2],group_sizes=n,P_interaction=p,P_interaction_permutation=pp,P_interaction_log_scale=pl))
do_2x2('Megakaryocyte Slc6a8 knockout (Fig. 3i)','Fig. 3i','BCDE',[('lung weight',3,6),('burden',10,13),('foci',17,20)],'4 per group')
do_2x2('STAT5-IN-1, systemic (Fig. 6b)','Fig. 6b','BCDE',[('burden',4,8),('foci',13,17)],'5 per group')
do_2x2('Tumour-cell sh-Slc6a8 (Fig. 1f)','Fig. 1f','BCDE',[('lung weight',4,9),('SUV',13,18),('burden',22,27),('foci',31,36)],'6 per group')
S='Supplementary Fig  2d'
for lab,r0 in [('burden',5),('foci',14)]:
    g=[col(S,c,r0,r0+5) for c in 'CDE']; e=share_3arm(*g)
    out.append(dict(intervention='Aspirin-treated creatine-donor platelets (Supp. Fig. 2d)',endpoint=lab,fraction_of_creatine_effect_removed=e[0],ci95_low=e[1],ci95_high=e[2],group_sizes='6 per group'))
    g2=[col(S,'C',r0,r0+2),col(S,'D',r0,r0+2),col(S,'E',r0,r0+5)]; e=share_3arm(*g2)
    out.append(dict(intervention='  same, excluding the 3+3 mice that also appear in Fig. 6b',endpoint=lab,fraction_of_creatine_effect_removed=e[0],ci95_low=e[1],ci95_high=e[2],group_sizes='3/3/6'))
    print(f'Supp. Fig. 2d {lab}, unique animals only: vehicle-donor {g2[0].mean():.1f} vs creatine-donor {g2[1].mean():.1f}, P={stats.ttest_ind(g2[0],g2[1]).pvalue:.4f}')
R=pd.DataFrame(out); R.to_csv(os.path.join(TABLES,'share_of_creatine_effect_removed.csv'),index=False)
pd.set_option('display.width',250); print(R.round(4).to_string())
