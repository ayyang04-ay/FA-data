"""Figure 1. The metastasis endpoint: creatine effect in every experiment (A) and under each perturbation (B-E)."""
from lib import *
import os, warnings; warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False})
CV='#6b7280'; CC='#c2410c'; CB='#1d4ed8'
M=pd.read_csv(os.path.join(TABLES,'creatine_effect_by_experiment.csv'))
sub=M[(M.endpoint=='burden')&(~M.experiment.str.contains('not pooled'))].reset_index(drop=True)
def dl(y,v):
    w=1/v; ybar=(w*y).sum()/w.sum(); Q=(w*(y-ybar)**2).sum(); k=len(y); C=w.sum()-(w**2).sum()/w.sum(); tau2=max(0,(Q-(k-1))/C)
    ws=1/(v+tau2); return (ws*y).sum()/ws.sum(), np.sqrt(1/ws.sum())
mu,se=dl(sub.ln_ratio.values,sub.variance_ln_ratio.values)
fig=plt.figure(figsize=(13.5,8.0))
gs=GridSpec(2,3,figure=fig,width_ratios=[1.25,1,1],wspace=0.42,hspace=0.95,left=0.2,right=0.985,top=0.87,bottom=0.12)
ax=fig.add_subplot(gs[:,0])
labels=[f"{r.experiment}   n={r.n_vehicle}+{r.n_creatine}" for r in sub.itertuples()]
y=np.arange(len(sub))[::-1]+1.6
ax.errorbar(sub.ratio_creatine_over_vehicle,y,xerr=[sub.ratio_creatine_over_vehicle-sub.ratio_ci95_low,sub.ratio_ci95_high-sub.ratio_creatine_over_vehicle],fmt='s',color=CC,ecolor=CC,ms=5,capsize=2,lw=1.2)
ax.errorbar([np.exp(mu)],[0.3],xerr=[[np.exp(mu)-np.exp(mu-1.96*se)],[np.exp(mu+1.96*se)-np.exp(mu)]],fmt='D',color='k',ms=7,capsize=3,lw=1.6)
ax.axvline(1,color='#9ca3af',lw=0.8,ls='--')
ax.set_yticks(list(y)+[0.3]); ax.set_yticklabels(labels+['Pooled (random effects)\n10 experiments, 122 mice'],fontsize=8.3)
ax.set_xscale('log'); ax.set_xticks([1,2,3,4,6]); ax.set_xticklabels(['1','2','3','4','6']); ax.set_xlim(0.85,7); ax.minorticks_off()
ax.set_xlabel('Lung metastatic burden, creatine ÷ vehicle (95% CI)')
ax.set_title('A  Creatine raises metastatic burden\n    in every experiment',loc='left',fontweight='bold',fontsize=10)
ax.text(np.exp(mu),-0.35,f'{np.exp(mu):.1f}× ({np.exp(mu-1.96*se):.1f}–{np.exp(mu+1.96*se):.1f})',ha='center',va='top',fontsize=9,fontweight='bold')
ax.set_ylim(-1.2,len(sub)+1.3)
def panel(ax,groups,names,colors,title,note,pairs=None):
    rng=np.random.default_rng(1)
    for i,(g,c) in enumerate(zip(groups,colors)):
        ax.scatter(i+rng.uniform(-0.13,0.13,len(g)),g,s=18,color=c,alpha=0.9,edgecolor='white',lw=0.4,zorder=3)
        ax.hlines(np.mean(g),i-0.28,i+0.28,color='k',lw=1.6,zorder=4)
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(names,fontsize=8.2)
    ax.set_title(title,loc='left',fontweight='bold',fontsize=10,pad=30)
    ax.text(0,1.03,note,transform=ax.transAxes,va='bottom',ha='left',fontsize=8.2,color='#374151')
    ax.set_ylabel('Metastatic burden (% lung area)',fontsize=8.5); ax.set_ylim(0,None); ax.set_xlim(-0.5,len(groups)-0.5); ax.tick_params(axis='y',labelsize=8)
    for (x0,x1,lab) in (pairs or []):
        ax.annotate('',xy=(x0-0.3,-0.17),xytext=(x1+0.3,-0.17),xycoords=('data','axes fraction'),textcoords=('data','axes fraction'),arrowprops=dict(arrowstyle='-',color='#6b7280',lw=0.8))
        ax.text((x0+x1)/2,-0.2,lab,transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=8.4)
vc=['vehicle','creatine','vehicle','creatine']; cc=[CV,CC,CV,CC]
S='Fig. 3i'; panel(fig.add_subplot(gs[0,1]),[col(S,c,10,13) for c in 'BCDE'],vc,cc,'B  Megakaryocyte Slc6a8 knockout','Fig. 3i, n=4/group. Interaction P=0.0003;\n109% of the creatine effect removed',pairs=[(0,1,'Pf4-Cre; Slc6a8+/+'),(2,3,'Pf4-Cre; Slc6a8 fl/fl')])
S='Fig. 6b'; panel(fig.add_subplot(gs[0,2]),[col(S,c,4,8) for c in 'BCDE'],vc,cc,'C  STAT5-IN-1 (systemic)','Fig. 6b, n=5/group. Interaction P=7e-6;\n92% removed. Hits STAT5A+B; not cell-specific',pairs=[(0,1,'no inhibitor'),(2,3,'+ STAT5-IN-1')])
S='Fig. 1f'; panel(fig.add_subplot(gs[1,1]),[col(S,c,22,27) for c in 'BCDE'],vc,cc,'D  Tumour-cell Slc6a8 knock-down','Fig. 1f, n=6/group. Interaction P=0.68; effect intact\n(protein knock-down only partial)',pairs=[(0,1,'sh-scrambled tumour'),(2,3,'sh-Slc6a8 tumour')])
S='Supplementary Fig  2d'; panel(fig.add_subplot(gs[1,2]),[col(S,c,5,10) for c in 'CDE'],['vehicle\ndonor','creatine\ndonor','creatine+aspirin\ndonor'],[CV,CC,CB],'E  Donor-platelet transfer','Supp. Fig. 2d, n=6/group. P=0.0004; 0.0001.\n3+3 mice duplicate Fig. 6b values')
fig.savefig(os.path.join(FIGS,'fig1_metastasis_endpoint.png'),dpi=170)
