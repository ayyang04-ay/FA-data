"""Step 05. Human volunteer cohort (Fig. 7b-e, 7g; Supp. Fig. 8a-b) re-analysed as paired data.
Outputs: ../tables/human_platelet_response_per_readout.csv, human_platelet_response_by_agonist.csv, human_cd41_transcripts.csv"""
from lib import *
import os, warnings; warnings.filterwarnings('ignore')
from scipy.stats import dunnett
DAYS=(3,7,14)
# ---- serum creatine
S='Fig. 7b'; cr=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(4,15)],float)
print('Serum creatine (uM) mean by day 0/3/7/14:',cr.mean(0).round(1),'| paired t vs day 0:',[f'{stats.ttest_rel(cr[:,j],cr[:,0]).pvalue:.1e}' for j in (1,2,3)],'| volunteers increased:',[(cr[:,j]>cr[:,0]).sum() for j in (1,2,3)])
# ---- platelet function
S='Fig. 7c'
BLOCKS=[('collagen','max aggregation',4),('collagen','average aggregation',18),('collagen','adhesion',32),('epinephrine','max aggregation',46),('epinephrine','average aggregation',60),('epinephrine','adhesion',74),
        ('arachidonic acid','max aggregation',88),('arachidonic acid','average aggregation',102),('arachidonic acid','adhesion',116),('ADP','max aggregation',130),('ADP','average aggregation',144),('ADP','adhesion',157)]
H={}; rows=[]
for ag,metric,r0 in BLOCKS:
    d=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(r0,r0+11)],float); H[(ag,metric)]=d
    assert (d[:,0]==1).all()
    dn=dunnett(d[:,1],d[:,2],d[:,3],control=d[:,0],random_state=1)
    for j,day in zip((1,2,3),DAYS):
        x=d[:,j]; xl=np.log2(x[x>0])
        rows.append(dict(agonist=ag,read_out=metric,day=day,mean_fold=x.mean(),median_fold=np.median(x),geometric_mean_fold=2**xl.mean(),volunteers_increased=int((x>1).sum()),
                         P_dunnett_as_in_workbook=dn.pvalue[j-1],P_one_sample_t_on_log2=stats.ttest_1samp(xl,0).pvalue,P_wilcoxon_signed_rank=stats.wilcoxon(x-1).pvalue,max_fold=x.max()))
pd.DataFrame(rows).to_csv(os.path.join(TABLES,'human_platelet_response_per_readout.csv'),index=False)
def composite(ag, j):
    L=np.array([np.log2(np.where(H[k][:,j]>0,H[k][:,j],np.nan)) for k in H if k[0]==ag]).T
    return np.nanmean(L,axis=1)
rows=[]
for ag in ['epinephrine','collagen','arachidonic acid','ADP']:
    for j,day in zip((1,2,3),DAYS):
        c=composite(ag,j); m=c.mean(); se=c.std(ddof=1)/np.sqrt(len(c)); t=stats.t.ppf(0.975,len(c)-1)
        rows.append(dict(agonist=ag,day=day,n_volunteers=len(c),geometric_mean_fold_vs_day0=2**m,ci95_low=2**(m-t*se),ci95_high=2**(m+t*se),volunteers_increased=int((c>0).sum()),
                         P_one_sample_t_on_log2=stats.ttest_1samp(c,0).pvalue,P_wilcoxon_signed_rank=stats.wilcoxon(c).pvalue,sd_log2=c.std(ddof=1)))
C=pd.DataFrame(rows); C.to_csv(os.path.join(TABLES,'human_platelet_response_by_agonist.csv'),index=False)
pd.set_option('display.width',250); print(C.round(3).to_string())
# ---- platelet protein
S='Fig. 7e'
for nm,r0 in [('GP6',4),('P2RY12',12)]:
    d=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(r0,r0+4)],float)
    for j,day in zip((1,2,3),DAYS):
        lr=np.log2(d[:,j]/d[:,0]); print(f'{nm} day {day}: {2**lr.mean():.2f}x, up in {(lr>0).sum()}/4, paired t P={stats.ttest_rel(d[:,j],d[:,0]).pvalue:.3f}')
# ---- CD41+ cell transcripts
S='Fig. 7d'
GB=[('ITGA2B','A',6),('P2RY12','H',6),('GP6','A',25),('GPIBA','H',25),('F2R','A',44),('ADRA2A','H',44),('FCGR2A','A',63),('RUNX1','H',63),('RAB4A','A',82),('RAB27B','H',82),('PITPNB','A',100)]
rows=[]
for gene,c0,r0 in GB:
    base=colnum(c0); vcols=[colname(base+(2 if c0=='A' else 1)+i) for i in range(4)]
    dct={day:np.array([[cell(S,f'{c}{r0+1+3*k+q}') for c in vcols] for q in range(3)],float) for k,day in enumerate((0,3,7,14))}
    rep={day:np.array([cell(S,f'{c}{r0+13+k}') for c in vcols],float) for k,day in enumerate((0,3,7,14))}
    for day in DAYS:
        fc=(2**dct[day]).mean(0)/(2**dct[0]).mean(0); l2=dct[day].mean(0)-dct[0].mean(0)
        rows.append(dict(gene=gene,day=day,fold_volunteer1=fc[0],fold_volunteer2=fc[1],fold_volunteer3=fc[2],fold_volunteer4=fc[3],geometric_mean_fold=2**l2.mean(),volunteers_increased=int((fc>1).sum()),
                         P_one_sample_t_on_log2=stats.ttest_1samp(l2,0).pvalue,recomputed_matches_workbook=bool(np.allclose(fc,rep[day],rtol=2e-3)),workbook_normalised_values=np.round(rep[day],3).tolist()))
T=pd.DataFrame(rows); T.to_csv(os.path.join(TABLES,'human_cd41_transcripts.csv'),index=False)
print('transcript rows not reproducible from listed dCt:'); print(T[~T.recomputed_matches_workbook][['gene','day','fold_volunteer4','workbook_normalised_values']].round(2).to_string())
for day in DAYS:
    sub=T[T.day==day]; print(f'day {day}: genes up in >=3 of 4 volunteers: {(sub.volunteers_increased>=3).sum()}/11; P<0.05: {sub[sub.P_one_sample_t_on_log2<0.05].gene.tolist()}')
# ---- volunteer platelets into mice; BMI; counts
S='Fig. 7g'; show(tt(col(S,'B',12,16),col(S,'C',12,16),'Fig. 7g burden, day-0 vs day-7 donor platelets'))
S='Supplementary Fig  8a'; a=col(S,'C',4,14); b=col(S,'D',4,14); print(f'BMI paired t P={stats.ttest_rel(a,b).pvalue:.2f} (workbook, unpaired: {stats.ttest_ind(a,b).pvalue:.2f})')
S='Supplementary Fig  8b'; d=np.array([[cell(S,f'{c}{r}') for c in 'BCDE'] for r in range(4,15)],float); print('platelet count by day:',d.mean(0).round(0),'paired t P:',[round(stats.ttest_rel(d[:,j],d[:,0]).pvalue,2) for j in (1,2,3)])
