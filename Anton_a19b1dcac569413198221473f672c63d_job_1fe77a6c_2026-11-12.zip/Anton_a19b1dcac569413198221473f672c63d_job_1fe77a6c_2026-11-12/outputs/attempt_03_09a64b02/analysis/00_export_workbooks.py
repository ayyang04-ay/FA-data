"""Step 00. Export both workbooks to plain files so the remaining steps need no Excel reader.
Needs openpyxl. Writes cache/cells.json (every non-empty cell of the source-data workbook, cached values),
cache/phos.csv (phosphoproteomics table) and cache/blots/ (embedded blot images, named by sheet)."""
import openpyxl, json, os, re, zipfile, csv
HERE = os.path.dirname(os.path.abspath(__file__))
IN = os.environ.get('CRE_INPUT', '/tmp/world/filesystem')
CACHE = os.path.join(HERE, 'cache'); os.makedirs(os.path.join(CACHE, 'blots'), exist_ok=True)
src = os.path.join(IN, 'CRE-MK-01_source_data.xlsx')
wb = openpyxl.load_workbook(src, data_only=True)
out = {ws.title: {c.coordinate: c.value for r in ws.iter_rows() for c in r if c.value is not None} for ws in wb.worksheets}
json.dump(out, open(os.path.join(CACHE, 'cells.json'), 'w'), ensure_ascii=False)
print('sheets:', len(out), 'cells:', sum(len(v) for v in out.values()))
# phosphoproteomics
wb2 = openpyxl.load_workbook(os.path.join(IN, 'CRE-MK-01_phosphoproteomics.xlsx'), data_only=True)
rows = list(wb2.worksheets[0].iter_rows(values_only=True))
with open(os.path.join(CACHE, 'phos.csv'), 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['gene', 'p', 'q', 'lfc']); w.writerows(rows[1:])
print('phosphopeptide rows:', len(rows)-1)
# embedded images -> named by sheet
z = zipfile.ZipFile(src)
wbx = z.read('xl/workbook.xml').decode(); rels = z.read('xl/_rels/workbook.xml.rels').decode()
rid = {dict(re.findall(r'(\w+)="([^"]*)"', m))['Id']: dict(re.findall(r'(\w+)="([^"]*)"', m))['Target'] for m in re.findall(r'<Relationship ([^>]+)/>', rels)}
for m in re.findall(r'<sheet ([^>]+)/>', wbx):
    a = dict(re.findall(r'([\w:]+)="([^"]*)"', m)); sheetfile = os.path.basename(rid[a['r:id']])
    relp = f'xl/worksheets/_rels/{sheetfile}.rels'
    if relp not in z.namelist(): continue
    for m2 in re.findall(r'<Relationship ([^>]+)/>', z.read(relp).decode()):
        t = dict(re.findall(r'(\w+)="([^"]*)"', m2))['Target']
        if 'drawing' not in t: continue
        d = os.path.basename(t)
        for m3 in re.findall(r'<Relationship ([^>]+)/>', z.read(f'xl/drawings/_rels/{d}.rels').decode()):
            img = os.path.basename(dict(re.findall(r'(\w+)="([^"]*)"', m3))['Target'])
            name = re.sub(r'[^A-Za-z0-9]+', '_', a['name']).strip('_')
            open(os.path.join(CACHE, 'blots', f'{name}.jpeg'), 'wb').write(z.read(f'xl/media/{img}'))
print('blot images:', len(os.listdir(os.path.join(CACHE, 'blots'))))
