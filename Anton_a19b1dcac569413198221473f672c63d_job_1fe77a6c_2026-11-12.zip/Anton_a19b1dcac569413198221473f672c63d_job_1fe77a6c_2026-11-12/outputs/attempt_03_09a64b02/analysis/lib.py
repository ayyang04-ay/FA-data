"""Helpers shared by the re-analysis scripts: cell access to the exported workbook and small statistics utilities."""
import json, os, numpy as np, pandas as pd
from scipy import stats
HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, 'cache')
TABLES = os.path.join(HERE, '..', 'tables')
FIGS = os.path.join(HERE, '..', 'figures')
os.makedirs(TABLES, exist_ok=True); os.makedirs(FIGS, exist_ok=True)
CELLS = json.load(open(os.path.join(CACHE, 'cells.json')))

def colnum(s):
    n = 0
    for ch in s: n = n*26 + (ord(ch)-64)
    return n
def colname(n):
    s = ''
    while n > 0:
        n, r = divmod(n-1, 26); s = chr(65+r)+s
    return s
def cell(sheet, addr):
    return CELLS[sheet].get(addr)
def _isnum(v):
    return v is not None and isinstance(v, (int, float)) and not isinstance(v, bool)
def col(sheet, c, r0, r1):
    """numeric values in column c, rows r0..r1"""
    return np.array([float(cell(sheet, f'{c}{r}')) for r in range(r0, r1+1) if _isnum(cell(sheet, f'{c}{r}'))])
def row(sheet, r, c0, c1):
    """numeric values in row r, columns c0..c1"""
    return np.array([float(cell(sheet, f'{colname(ci)}{r}')) for ci in range(colnum(c0), colnum(c1)+1) if _isnum(cell(sheet, f'{colname(ci)}{r}'))])
def tt(a, b, label=''):
    a = np.asarray(a, float); b = np.asarray(b, float)
    t, p = stats.ttest_ind(a, b); tw, pw = stats.ttest_ind(a, b, equal_var=False)
    try: pu = stats.mannwhitneyu(a, b, alternative='two-sided').pvalue
    except Exception: pu = np.nan
    na, nb = len(a), len(b)
    sp = np.sqrt(((na-1)*a.var(ddof=1)+(nb-1)*b.var(ddof=1))/(na+nb-2))
    return dict(label=label, nA=na, nB=nb, meanA=a.mean(), sdA=a.std(ddof=1), meanB=b.mean(), sdB=b.std(ddof=1),
                ratio=b.mean()/a.mean() if a.mean() != 0 else np.nan, t=abs(t), df=na+nb-2, p=p, p_welch=pw, p_mwu=pu,
                d=(b.mean()-a.mean())/sp if sp > 0 else np.nan)
def show(d, reported=None):
    s = (f"{d['label']:45s} n={d['nA']}/{d['nB']} A={d['meanA']:.4g}±{d['sdA']:.3g} B={d['meanB']:.4g}±{d['sdB']:.3g} "
         f"ratio={d['ratio']:.3g} t={d['t']:.4g} df={d['df']} p={d['p']:.4g} welch={d['p_welch']:.4g} MWU={d['p_mwu']:.4g}")
    if reported is not None: s += f"  | reported: {reported}"
    print(s)
def pooled_sd(groups):
    return np.sqrt(sum(((g-g.mean())**2).sum() for g in groups)/sum(len(g)-1 for g in groups))
