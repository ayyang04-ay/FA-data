"""Step 04. Megakaryocyte platelet-activation gene panel (11 genes) in every ΔCt sheet.
Fold change = 2^(mean ΔCt arm - mean ΔCt reference arm); tests on ΔCt (n=3 per arm).
Outputs: ../tables/mk_gene_panel_per_gene.csv, ../tables/mk_gene_panel_by_perturbation.csv"""
from lib import *
from qpcr import parse_qpcr
import os, warnings; warnings.filterwarnings('ignore')
SPECS=[('Fig. 2f',{'ΔCT1':'Vehicle','ΔCT2':'Creatine'},'Fig. 2f megakaryocytes in vivo'),
 ('Fig. 3f',{'ΔCT1':'Control-vehicle','ΔCT2':'Control-creatine','ΔCT3':'Slc6a8 knockout-vehicle','ΔCT4':'Slc6a8 knockout-creatine'},'Fig. 3f megakaryocyte Slc6a8 knockout'),
 ('Fig. 4h',{'ΔCT1':'Control','ΔCT2':'Creatine','ΔCT3':'Phosphocreatine'},'Fig. 4h megakaryocytes in vitro'),
 ('Fig. 4j',{'ΔCT1':'Control+si-scrambled','ΔCT2':'Control+si-Ckb','ΔCT3':'Creatine+si-scrambled','ΔCT4':'Creatine+si-Ckb'},'Fig. 4j si-Ckb'),
 ('Fig. 4l',{'ΔCT1':'CKB-EV','ΔCT2':'CKB-OE'},'Fig. 4l CKB over-expression'),
 ('Fig.6a',{'ΔCT1':'Vehicle','ΔCT2':'Creatine','ΔCT3':'Vehicle+STAT5-IN-1','ΔCT4':'Creatine+STAT5-IN-1'},'Fig. 6a STAT5-IN-1'),
 ('Fig. 6g',{'ΔCT1':'WT-vehicle','ΔCT2':'WT-creatine','ΔCT3':'Stat5b knockout-creatine'},'Fig. 6g megakaryocyte Stat5b knockout'),
 ('Supplementary Fig  3c',{'ΔCT1':'Vehicle','ΔCT2':'Creatine'},'Supp. Fig. 3c megakaryocyte maturation genes'),
 ('Supplementary Fig  4e',{'ΔCT1':'Control','ΔCT2':'Creatine','ΔCT3':'Creatine@liposome'},'Supp. Fig. 4e Slc6a8-knockout megakaryocytes')]
rows=[]
for sheet,gn,label in SPECS:
    for gene,dd in parse_qpcr(sheet).items():
        c=dd['ΔCT1']
        for k,name in gn.items():
            if k=='ΔCT1' or k not in dd: continue
            t=dd[k]; rows.append(dict(panel=label,gene=gene,group=name,reference_group=gn['ΔCT1'],log2_fold_vs_reference=t.mean()-c.mean(),fold_vs_reference=2**(t.mean()-c.mean()),P_t_test_on_dCt=stats.ttest_ind(t,c).pvalue))
A=pd.DataFrame(rows); A.to_csv(os.path.join(TABLES,'mk_gene_panel_per_gene.csv'),index=False)
def block(name, sheet, ctrl, cre, ctrl_x, cre_x):
    """creatine induction in the control arm (cre vs ctrl) and in the perturbed arm (cre_x vs ctrl_x; if ctrl_x is None, vs ctrl)"""
    out=[]
    for gene,dd in parse_qpcr(sheet).items():
        ind=dd[cre].mean()-dd[ctrl].mean(); ref=dd[ctrl] if ctrl_x is None else dd[ctrl_x]; indx=dd[cre_x].mean()-ref.mean()
        pint=np.nan; base=np.nan
        if ctrl_x is not None:
            gs=[dd[ctrl],dd[cre],dd[ctrl_x],dd[cre_x]]; mse=sum(((x-x.mean())**2).sum() for x in gs)/sum(len(x)-1 for x in gs)
            se=np.sqrt(mse*sum(1/len(x) for x in gs)); dfree=sum(len(x)-1 for x in gs); pint=2*stats.t.sf(abs((indx-ind)/se),dfree); base=2**(dd[ctrl_x].mean()-dd[ctrl].mean())
        out.append(dict(panel=name,gene=gene,fold_induction_control_arm=2**ind,fold_induction_perturbed_arm=2**indx,baseline_fold_perturbed_vs_control_untreated=base,
                        P_creatine_effect_within_perturbed_arm=stats.ttest_ind(dd[cre_x],ref).pvalue,P_interaction=pint))
    R=pd.DataFrame(out)
    extra = (f'; genes with interaction P<0.05: {(R.P_interaction<0.05).sum()}/{len(R)}; baseline shift {2**np.log2(R.baseline_fold_perturbed_vs_control_untreated).mean():.2f}x'
             if ctrl_x is not None else '; no within-arm baseline, so no interaction test')
    print(f'{name}: geometric-mean induction control arm {2**np.log2(R.fold_induction_control_arm).mean():.2f}x -> perturbed arm {2**np.log2(R.fold_induction_perturbed_arm).mean():.2f}x' + extra)
    return R
B=pd.concat([
 block('Megakaryocyte Slc6a8 knockout (Fig. 3f)','Fig. 3f','ΔCT1','ΔCT2','ΔCT3','ΔCT4'),
 block('si-Ckb (Fig. 4j)','Fig. 4j','ΔCT1','ΔCT3','ΔCT2','ΔCT4'),
 block('STAT5-IN-1 (Fig. 6a)','Fig.6a','ΔCT1','ΔCT2','ΔCT3','ΔCT4'),
 block('Megakaryocyte Stat5b knockout, creatine-treated knockout vs WT vehicle (Fig. 6g; no vehicle-treated knockout arm)','Fig. 6g','ΔCT1','ΔCT2',None,'ΔCT3'),
 block('Slc6a8-knockout megakaryocytes: liposomal creatine (control arm) vs free creatine (Supp. Fig. 4e)','Supplementary Fig  4e','ΔCT1','ΔCT3',None,'ΔCT2'),
 block('Creatine (control arm) vs phosphocreatine (Fig. 4h)','Fig. 4h','ΔCT1','ΔCT2',None,'ΔCT3')])
B.to_csv(os.path.join(TABLES,'mk_gene_panel_by_perturbation.csv'),index=False)
for (p,g),sub in A.groupby(['panel','group'],sort=False):
    print(f'{p:48s} {g:28s} geometric mean {2**sub.log2_fold_vs_reference.mean():.2f}x; genes up/down at P<0.05: {((sub.P_t_test_on_dCt<0.05)&(sub.log2_fold_vs_reference>0)).sum()}/{((sub.P_t_test_on_dCt<0.05)&(sub.log2_fold_vs_reference<0)).sum()} of {len(sub)}')
