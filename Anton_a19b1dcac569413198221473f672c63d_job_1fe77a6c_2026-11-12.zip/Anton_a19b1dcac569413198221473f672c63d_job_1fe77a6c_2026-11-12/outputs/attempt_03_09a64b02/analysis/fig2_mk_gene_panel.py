"""Figure 2. Megakaryocyte platelet-activation gene panel under each perturbation (fold change vs the matched untreated arm)."""
from lib import *
from qpcr import PANEL_GENES as genes, log2fc as L
import os, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans'})
cols=[('Creatine, in vivo\n(Fig. 2f)',L('Fig. 2f','ΔCT2','ΔCT1')),('Creatine, in vitro\n(Fig. 4h)',L('Fig. 4h','ΔCT2','ΔCT1')),('Phosphocreatine,\nin vitro (Fig. 4h)',L('Fig. 4h','ΔCT3','ΔCT1')),
 ('Cre control\n(Fig. 3f)',L('Fig. 3f','ΔCT2','ΔCT1')),('MK Slc6a8 KO\n(Fig. 3f)',L('Fig. 3f','ΔCT4','ΔCT3')),('KO MKs + liposomal\ncreatine (S4e)',L('Supplementary Fig  4e','ΔCT3','ΔCT1')),
 ('si-scrambled\n(Fig. 4j)',L('Fig. 4j','ΔCT3','ΔCT1')),('si-Ckb\n(Fig. 4j)',L('Fig. 4j','ΔCT4','ΔCT2')),('CKB over-expression,\nno creatine (Fig. 4l)',L('Fig. 4l','ΔCT2','ΔCT1')),
 ('No inhibitor\n(Fig. 6a)',L('Fig.6a','ΔCT2','ΔCT1')),('+ STAT5-IN-1\n(Fig. 6a)',L('Fig.6a','ΔCT4','ΔCT3')),('WT\n(Fig. 6g)',L('Fig. 6g','ΔCT2','ΔCT1')),('MK Stat5b KO vs\nWT vehicle* (Fig. 6g)',L('Fig. 6g','ΔCT3','ΔCT1'))]
Mx=np.array([c[1] for c in cols]).T
fig,ax=plt.subplots(figsize=(12.5,5.6))
im=ax.imshow(Mx,cmap='RdBu_r',vmin=-3,vmax=3,aspect='auto')
ax.set_xticks(range(len(cols))); ax.set_xticklabels([c[0] for c in cols],rotation=40,ha='right',fontsize=8.3)
ax.set_yticks(range(len(genes))); ax.set_yticklabels(genes,fontsize=9,style='italic')
for i in range(Mx.shape[0]):
    for j in range(Mx.shape[1]):
        v=2**Mx[i,j]; ax.text(j,i,f'{v:.1f}' if v<10 else f'{v:.0f}',ha='center',va='center',fontsize=7.6,color='white' if abs(Mx[i,j])>1.7 else 'black')
for j,v in enumerate(2**Mx.mean(0)): ax.text(j,-0.75,f'{v:.2f}×',ha='center',va='bottom',fontsize=8.6,fontweight='bold')
ax.text(-0.58,-0.75,'geo. mean →',ha='right',va='bottom',fontsize=8.3)
for a,b,lab in [(0,2,'Exposure'),(3,5,'SLC6A8 node'),(6,8,'CKB node'),(9,12,'STAT5 node')]:
    ax.text((a+b)/2,-1.75,lab,ha='center',va='bottom',fontsize=9.5,fontweight='bold'); ax.plot([a-0.42,b+0.42],[-1.62,-1.62],color='k',lw=1,clip_on=False)
for x in (2.5,5.5,8.5): ax.axvline(x,color='white',lw=3)
ax.set_ylim(len(genes)-0.5,-0.5)
cb=fig.colorbar(im,ax=ax,fraction=0.025,pad=0.015); cb.set_label('log2 fold change')
ax.set_title('Megakaryocyte platelet-activation gene panel: fold change with creatine (or stated treatment) vs the matched untreated arm',fontsize=10,fontweight='bold',loc='left',pad=46)
fig.text(0.01,0.005,'Numbers are fold changes from mean ΔCt (n=3 per arm). Each column is creatine vs vehicle within the stated arm, except: phosphocreatine and CKB over-expression (vs control),\nliposomal creatine (vs untreated KO MKs) and *MK Stat5b KO (creatine-treated KO vs WT vehicle, because the package has no vehicle-treated KO arm).',fontsize=7.8,color='#374151')
fig.subplots_adjust(left=0.115,right=0.99,top=0.8,bottom=0.3)
fig.savefig(os.path.join(FIGS,'fig2_mk_gene_panel.png'),dpi=170)
