**Recommendation: take forward megakaryocyte SLC6A8 — the transporter that lets creatine into megakaryocytes — as the primary target, with megakaryocyte STAT5B as the strong backup and CKB as a conditional second backup; spend next quarter's in vivo slot on one blinded, powered experiment that re-tests the SLC6A8 knockout and gives the STAT5B knockout its first metastasis read-out.**

# CRE-MK-01 follow-up: validation proposal for the portfolio committee

Everything below is derived from the three CRE-MK-01 files (source-data workbook, phosphoproteomics workbook, study conventions). No external study results were used. "Megakaryocyte" is abbreviated MK in tables.

## 1. The decision in brief

- **Primary: megakaryocyte SLC6A8.** It is the only candidate whose megakaryocyte-specific deletion was tested against the metastasis endpoint, and the creatine effect disappeared: with creatine, lung metastatic burden rose from 2.4% to 7.9% in Cre-control mice but went from 3.4% to 2.9% in knockouts (genotype × creatine interaction P = 0.0003; n = 4 per group; Fig. 3i).
- **Strong backup: megakaryocyte STAT5B.** A STAT5 inhibitor removed 92% of the creatine effect on metastasis (Fig. 6b) and the megakaryocyte Stat5b knockout blunted the downstream gene programme (Fig. 6g). But the inhibitor hits STAT5A as well as STAT5B and acts body-wide, and the knockout was never read out on platelet function or metastasis.
- **Second backup, conditional: CKB.** In cultured megakaryocytes it is needed for, and sufficient to drive, the gene programme (Fig. 4j, 4l). It has no in vivo evidence at all.
- **Not taken forward.** Tumour-cell SLC6A8: knock-down left the creatine effect intact, although the protein knock-down was partial (Fig. 1f). The platelet receptors GP6 and P2RY12 are read-outs, not targets. Platelets from aspirin-treated donors lost the pro-metastatic effect (Supp. Fig. 2d), so aspirin is the comparator any new target has to beat.
- **The risk that applies to every candidate.** So far each one matters only when creatine is being taken: in vehicle-fed mice neither the SLC6A8 knockout nor the STAT5 inhibitor lowered metastasis (Fig. 3i, 6b). If simply stopping creatine reverses the platelet change, the case for any drug target weakens. The proposed experiment includes that test.
- **The ask.** Allocate the slot to the experiment in section 4.1 (120 mice, or 72 if only the Slc6a8 line is ready) and approve the studies in section 4.2, which do not need the slot.
- **Confidence.** High that creatine raises metastasis and that platelets carry the effect. Moderate that megakaryocyte SLC6A8 is required: one small experiment, but a complete and internally consistent effect. Low to moderate that STAT5B is the megakaryocyte mediator in vivo. Low for CKB in vivo.

## 2. Why this ranking: the evidence

The chain the package describes: creatine enters megakaryocytes through SLC6A8 and raises CKB; CKB phosphorylates STAT5B on serine 127; STAT5B switches on platelet-activation genes such as *Gp6* and *P2ry12*; the platelets that result are more reactive, and metastasis rises.

### 2.1 Candidates side by side

| Evidence | MK SLC6A8 | STAT5B | CKB |
|---|---|---|---|
| Metastasis after cell-specific genetic loss | **Creatine effect removed**: 109% of the burden effect, 107% of foci, 93% of lung weight; interaction P = 0.0003, 0.004, 0.0002; n = 4/group (Fig. 3i) | Not done | Not done |
| Metastasis, other in vivo test | — | STAT5-IN-1 removed 92% (95% CI 79–104%); interaction P = 7×10⁻⁶; n = 5/group (Fig. 6b). Compound inhibits STAT5A and STAT5B; given systemically | None |
| MK gene programme: creatine induction, control arm → perturbed arm (geometric mean of 11 genes) | 3.3× → 0.90× (Fig. 3f) | Knockout: 3.6× → 1.09×, with *P2ry12, Gpiba, F2r, Adra2a* still 1.6–1.9× (Fig. 6g). Inhibitor: 5.3× → 1.08× (Fig. 6a) | si-Ckb: 3.7× → 1.4×. Over-expression alone: 2.5× (Fig. 4j, 4l) |
| Platelet function after perturbation | Creatine no longer raises aggregation (Fig. 3d) | Not measured | Not measured |
| Place in the chain | Entry point. MK creatine rises 5.3× in controls, 1.5× in knockouts (Fig. 3c); delivering creatine in liposomes restores the programme in knockout MKs (2.35×; Supp. Fig. 4e) | Downstream of uptake (MK creatine unchanged in knockout; Fig. 6e) and of CKB (CKB still induced on the one blot; Fig. 6f) | Between uptake and STAT5B; induced by creatine (mRNA 1.8×, P = 0.011; Fig. 4e) |
| Controls and design | Cre-matched controls; full 2 × 2 | Controls labelled WT; no vehicle-treated knockout arm | siRNA and over-expression in culture |
| Evidence for this node in human cells | None | None | None |
| Main gap | One unblinded experiment at n = 4; no test of blocking uptake in an adult animal | No megakaryocyte-specific metastasis test; STAT5B not separated from STAT5A | No in vivo test |

### 2.2 The phenotype is robust and runs through platelets

- **Creatine increases metastasis in every experiment.** Across the 10 vehicle-versus-creatine comparisons in control animals (122 mice), metastatic burden rose 3.0× (95% CI 2.5–3.6), foci 1.9× (1.7–2.2) and lung weight 1.37× (1.26–1.50). Each experiment is individually significant, including the dietary regimen (Figure 1A).
- **Survival shortens.** Median 22 versus 19 days (log-rank P = 0.032; Fig. 1c) and 16 versus 14 days (P = 0.011; Fig. 1l).
- **Platelets carry the effect.** Platelets from creatine-fed donors raised burden in recipients from 5.9% to 17.9% (P = 0.0004); platelets from donors given creatine plus aspirin did not (4.4%; Supp. Fig. 2d). Platelet count was unchanged (Fig. 2a).
- **Creatine appears to act on megakaryocytes rather than on circulating platelets.** Added in culture, creatine raised GP6 and P2RY12 in megakaryocytes at 0.2 mM but not in platelets (Fig. 2i, blot). In volunteers, serum creatine plateaued by day 3 but platelet responses rose only at days 7–14, which fits replacement of platelets by newly made ones.

### 2.3 SLC6A8: the host megakaryocyte, not the tumour cell

- **Megakaryocyte knockout removes the effect on all three metastasis read-outs** (Figure 1B; table above), although serum creatine rose equally in both genotypes (from 89 to 239 µM in controls and from 89 to 218 µM in knockouts; Fig. 3b). The burden interaction holds in a permutation test (P < 0.001) and on a log scale (P = 0.0009).
- **Tumour-cell knock-down does not.** Burden rose from 4.6% to 15.9% with the control hairpin and from 5.8% to 18.3% with sh-Slc6a8 (interaction P = 0.68; Figure 1D). This test is weaker than it looks: knock-down is 81% at mRNA (Supp. Fig. 2a) but only about 40% at protein by my densitometry of the single blot provided.
- **Two loose ends.** The knockout band is reduced, not absent (Supp. Fig. 4a). And in knockout mice creatine *lowered* aggregation by 10–23 points (Fig. 3d), which is unexplained.

### 2.4 STAT5B: a coherent chain with weak links

- **Nomination.** One of two Stat5b phosphopeptides rose (log2 fold change 5.7, P = 0.0012), but its q-value is 0.25 and the smallest q-value in the whole file is 0.17. Among the 3,787 peptides whose fold change is below about 6× in either direction, 4.4% have P < 0.05 — what chance gives (Figure 4). The Stat5b peptide sits among the 2,025 rows with larger fold changes, most of which share one identical P value and look like present/absent calls. The file carries no site information.
- **Not canonical activation.** Tyrosine-phosphorylated STAT5 (Y694/699) was undetectable in megakaryocytes with or without creatine, while the positive control worked (Supp. Fig. 6a).
- **Serine 127.** On over-expressed FLAG-tagged STAT5B, creatine raised the pan-phospho signal 1.39× (P = 0.009; Fig. 5e) and 1.28× (P = 0.09; Fig. 5f); the S127A mutant did not respond (mutant × creatine interaction P = 0.015 and 0.018). The effect is modest and the antibody is not site-specific. The cell type is not labelled on these blots; the companion blots are from 293T cells, not megakaryocytes.
- **Link to CKB.** Knock-down of CKB removed the creatine-induced signal and recombinant CKB increased it in vitro (Fig. 5g–i, Supp. Fig. 6d). These are single, unquantified blots without a kinase-dead or S127A-substrate control.
- **In vivo.** The inhibitor result is strong in size but cannot be attributed to STAT5B or to megakaryocytes. The inhibitor also halves baseline expression of the gene panel (0.52×; Fig. 6a). The knockout leaves four receptor genes partly induced, has no vehicle-treated knockout arm, and stops at transcripts and blots.

### 2.5 CKB: the link, untested in animals

- **Necessary and sufficient in culture.** si-Ckb cut creatine induction from 3.7× to 1.4× (interaction P < 0.05 for 10 of 11 genes) and CKB over-expression alone gave 2.5× (Fig. 4j, 4l).
- **Not energy buffering.** Phosphocreatine did not reproduce the induction (0.63×; Fig. 4h), and CKB over-expression changed neither megakaryocyte creatine nor phosphocreatine (Supp. Fig. 5c).
- **A liability visible in the data.** On the one blot provided, CKB is far more abundant in brain than in megakaryocytes (Fig. 4b).

### 2.6 Human cohort: what carries over

- **Exposure is in the mouse range.** 20 g/day raised serum creatine from 45 to 153–159 µM in all 11 volunteers (Fig. 7b); dosed mice reached 179–239 µM.
- **Platelets become more reactive, selectively.** At day 14, response to epinephrine rose 1.84× (95% CI 1.36–2.50; 11/11 volunteers) and to collagen 2.25× (1.25–4.05; 9/11). ADP did not move (1.11×; 0.72–1.71), unlike in mice (Figure 3B).
- **GP6 protein rises** 2.6× by day 14 in 4 of 4 volunteers (paired P = 0.02); P2RY12 rises 1.7× (Fig. 7e). GP6 with the collagen and epinephrine responses are the human read-outs to carry forward; P2RY12 and ADP are not.
- **Function transfers.** Day-7 volunteer platelets raised burden in recipient mice from 4.6% to 12.7% (P = 0.014; Fig. 7g).
- **Limits.** Single arm, no placebo, 11 healthy Asian volunteers aged 20–25, one loading-level dose, and only 4 of the 11 for transcripts and protein. Nothing in the human data tests SLC6A8, CKB or STAT5B.

![Figure 1](figures/fig1_metastasis_endpoint.png)

*Figure 1. The metastasis endpoint. A, creatine-to-vehicle ratio of metastatic burden in each experiment. B–E, individual mice; bars are group means.*

![Figure 2](figures/fig2_mk_gene_panel.png)

*Figure 2. The megakaryocyte gene panel under each perturbation. Numbers are fold changes with creatine relative to the matched untreated arm; the top row is the geometric mean of the 11 genes.*

![Figure 3](figures/fig3_human_cohort.png)

*Figure 3. Human cohort. A, serum creatine. B, platelet response to each agonist relative to day 0. C, platelet GP6 and P2RY12 protein relative to day 0.*

![Figure 4](figures/fig4_phosphoproteomics.png)

*Figure 4. Phosphoproteomics. Of the 2,025 rows with |log2 fold change| above 2.5, 78% share one identical P value (0.4227), which suggests present/absent detection rather than a measured ratio.*

## 3. Features of the package that shape the design

- **No blinding, no sample-size calculation, sex not analysed** (conventions). Male C57BL/6J and female BALB/cJ were used, so sex and strain are confounded.
- **Six mice appear twice.** Three vehicle and three creatine animals have identical burden and foci values in Fig. 6b and Supp. Fig. 2d, although the two panels describe different experiments. Neither conclusion depends on them (Supp. Fig. 2d without them: 8.4 versus 23.0%, P = 0.006), but the records need checking.
- **Some n are fields or technical replicates, not animals.** Fig. 1i, 2c, 2j and Supp. Fig. 4c count 8 microscope fields per group; aggregation (Fig. 2b, 3d) has n = 3 with SDs of 1–5 points, which looks like technical replication.
- **Repeated human measures were analysed as unpaired groups.** I re-analysed them as paired data on a log scale; the epinephrine and collagen findings hold and the ADP result stays null.
- **Most immunoblots have one to three lanes per condition and no quantification in the workbook**, and β-actin was run on a separate gel. Densitometry values I quote are from the embedded images and are approximate.
- **One human entry cannot be reproduced.** Volunteer 4's normalised values for RAB27B and PITPNB in Fig. 7d do not follow from the listed ΔCt values.

## 4. Follow-up studies

**Working indication.** Lowering metastatic risk in people with solid tumours who are taking creatine, with lung metastasis as the index model (melanoma is the only tumour line named in the package). The package gives no support yet for people who are not taking creatine.

### 4.1 Next quarter's in vivo slot: one experiment, three questions

| Element | Specification |
|---|---|
| Questions | (1) Does megakaryocyte Slc6a8 loss remove the creatine effect on metastasis under blinded, powered, two-sex conditions? (2) Does megakaryocyte Stat5b loss do the same? (3) How do both compare with aspirin and with stopping creatine? |
| Indication model | The lung-metastasis model used for Fig. 3i, run as in CRE-MK-01 (same cells, inoculum and schedule). The workbook does not name the tumour line for that panel; melanoma is named in Fig. 1f |
| Exposure | The CRE-MK-01 regimen: creatine monohydrate 42.5 mg/mL, 400 µL by mouth three times a week; water as vehicle. Confirm by serum creatine (about 180–240 µM expected) |
| Population | Age-matched littermates of both sexes, 12 per arm (6 per sex). Slc6a8 is X-linked, so record hemizygous males and homozygous females |
| Module 1 — primary (4 arms) | Pf4-Cre; Slc6a8 +/+ or fl/fl × vehicle or creatine |
| Module 2 — backup (4 arms) | Pf4-iCre; Stat5b +/+ or fl/fl × vehicle or creatine. Adds the Cre-matched control and the vehicle-treated knockout missing from CRE-MK-01 |
| Module 3 — benchmarks (2 arms, Cre-control mice on creatine) | Aspirin 30 mg/kg/day to the host; creatine stopped at least one platelet turnover before tumour-cell injection |
| Primary endpoint | Lung metastatic burden (% of lung area), scored blind. Test: genotype × creatine interaction, log scale, sex as covariate. Module 1 is the confirmatory test; Module 2 is tested next, in fixed sequence |
| Secondary endpoints | Foci count; lung weight; share of the creatine effect removed, with confidence interval |
| Mechanism read-outs | Serum creatine; megakaryocyte creatine (shows the node was hit); megakaryocyte CKB and nuclear STAT5B; the 11-gene panel; platelet GP6 and P2RY12; aggregation to ADP, collagen and thrombin with animals as replicates; deletion efficiency per animal |
| Safety read-outs | Platelet count and indices, bleeding time, body weight |
| Bias controls | Randomise within litter and sex; score outcomes blind; each module has its own concurrent controls, with no control animals shared between experiments |
| Size and power | 120 mice. Twelve per arm gives 80% power for an interaction half the size seen in Fig. 3i with 1.5 times its SD (two-sided α = 0.05) |
| If capacity is short | Each module needs 24 knockout and 24 Cre-control littermates. If only one line is ready, run Module 1 and the benchmarks now and make Module 2 the first call on the next slot; STAT5B cannot be ranked until it has run. Drop the aspirin arm before any other. Never drop a vehicle-treated knockout arm |

**Pre-specified reading of the result**

- **SLC6A8 confirmed** if the interaction is significant and at least 70% of the creatine effect is removed, in the same direction in both sexes.
- **STAT5B joins SLC6A8 as co-lead** if it meets the same bar. It drops to a read-out if less than 50% is removed.
- **Stopping creatine** returning burden and platelet read-outs to vehicle level means a drug is justified only for people who cannot stop, which favours a node downstream of uptake.
- **Aspirin** sets the efficacy bar; a new target must match it with less effect on baseline platelet function or bleeding.

### 4.2 In parallel, outside the in vivo slot

| Study | Population / system | Comparators | Read-outs | Purpose |
|---|---|---|---|---|
| Human megakaryocyte test | Megakaryocytes derived from human progenitors | Creatine across baseline-to-supplemented serum range (about 0.05–0.25 mM) and 2 mM; knock-down of SLC6A8, CKB, STAT5B | Intracellular creatine, CKB, STAT5B phosphorylation, GP6, ADRA2A, P2RY12 | First human evidence for each node |
| STAT5B site confirmation | Mouse megakaryocytes, vehicle vs creatine, more than 3 per group | S127A versus wild-type STAT5B re-expressed in Stat5b-null megakaryocytes | Site-localised phosphopeptide measurement; gene panel | Replace the q = 0.25 screen hit and the pan-phospho blots |
| CKB kinase controls | Purified proteins | Kinase-dead CKB; S127A substrate | STAT5B phosphorylation with site mapping | Show the phosphorylation is direct and at S127 |
| Inhibitor specificity | Megakaryocytes from Stat5b-knockout and control mice, in culture | STAT5-IN-1 versus vehicle, with and without creatine | The 11-gene panel | Show whether the compound acts through STAT5B: it should do nothing more in knockout cells |

### 4.3 Human study

| Element | Specification |
|---|---|
| Design | Randomised, double-blind, placebo-controlled, parallel groups; 14 days on treatment plus follow-up after stopping |
| Population | Healthy adults, both sexes, wider age and ancestry than CRE-MK-01, no antiplatelet or anti-inflammatory drugs |
| Arms | Placebo; a lower chronic-use dose; 20 g/day as in CRE-MK-01 |
| Primary endpoint | Epinephrine-induced platelet aggregation at day 14 (the most consistent response, 11 of 11 volunteers) |
| Key secondary | Collagen-induced aggregation; platelet GP6 protein |
| Other read-outs | ADP and arachidonic-acid responses; P2RY12; serum creatine; blood count; time to return to baseline after stopping |
| Comparator ex vivo | Aspirin added to volunteer platelets in the assay |
| Size | About 36–48 per arm: 80–90% power to detect half the epinephrine effect seen in CRE-MK-01. The noisier collagen response would need about twice that for the same margin |
| Patients | Observation only: platelet reactivity and GP6 in people with resected solid tumours who do or do not take creatine. No creatine dosing of patients |

### 4.4 The following in vivo slot, conditional on the result

- **Blocking in the adult.** Test the winning node with a tool inhibitor or inducible deletion started after creatine exposure is established. CRE-MK-01 contains no SLC6A8 or CKB inhibitor.
- **A second indication model.** Repeat in the second strain background and in a model where metastasis arises from a primary tumour; add survival.
- **Target-specific safety.** Brain and muscle creatine for SLC6A8 (oral creatine already raises brain creatine 1.19×; Fig. 4a); brain for CKB; immune and blood-cell read-outs for STAT5B.
- **CKB in vivo.** Megakaryocyte-specific CKB loss in the same 2 × 2 design, if CKB is still in contention.

## 5. What would move one choice above another

| If we learn that… | Then |
|---|---|
| Megakaryocyte Stat5b knockout removes at least 70% of the creatine effect on metastasis, with normal baseline | STAT5B becomes co-lead, and leads if the product must leave creatine uptake intact |
| Megakaryocyte Stat5b knockout removes less than 50%, or platelets stay hyper-reactive | STAT5B is a partial mediator; look for other CKB substrates; CKB becomes the main downstream backup |
| The SLC6A8 knockout result does not replicate | SLC6A8 falls, and the whole chain is in doubt because CKB and STAT5B sit downstream of uptake |
| Stopping creatine normalises platelets and metastasis | The drug case narrows to people who must keep taking creatine. SLC6A8 blockade is then equivalent to stopping; CKB or STAT5B would be the only useful targets |
| Blocking SLC6A8 in an adult lowers brain or muscle creatine, or impairs clotting, at an effective exposure | SLC6A8 stays the validation node but drops as a drug target |
| Megakaryocyte-specific CKB loss removes the effect in vivo, and kinase-dead and S127A controls confirm direct phosphorylation | CKB moves above STAT5B |
| STAT5-IN-1 still lowers the gene panel in Stat5b-knockout megakaryocytes, or STAT5A rises to compensate | The inhibitor result was not a STAT5B result; STAT5B drops |
| Human megakaryocytes do not respond to creatine at serum-range concentrations | Translation risk for all three; pause before further animal work |
| The pathway is active without supplementation in tumour-bearing hosts | All three gain value; the downstream nodes gain most |
| Host aspirin fully normalises metastasis with acceptable bleeding | Existing antiplatelet therapy is the pragmatic answer; a new target needs a safety advantage |

## 6. How the numbers were derived

- **Reproduction.** I recomputed all 232 statistical results reported in the source workbook (71 t-tests, 2 log-rank tests, 99 Tukey, 12 Šidák and 48 Dunnett comparisons) from the raw cells. All 232 match to the precision reported.
- **Interaction tests.** For each 2 × 2 experiment I fitted a two-way model and report the genotype (or drug) × creatine interaction, with a permutation test and a log-scale fit as checks.
- **Share of the creatine effect removed** = 1 − (creatine effect in the perturbed arm ÷ creatine effect in the control arm), with bootstrap 95% intervals.
- **Pooled creatine effect.** Random-effects pooling of the log ratio of means across the 10 control-arm experiments.
- **Gene panel.** Fold change from mean ΔCt per arm; tests on ΔCt. The workbook's own ΔCt arithmetic checks out in all 300 blocks I tested.
- **Human data.** Paired analysis of log fold change; each agonist summarised as the mean of its three read-outs per volunteer.
- **Phosphoproteomics.** P and q values as given in the file; I did not have intensities or sites.
- **Densitometry.** Approximate, from the embedded blot images; used only where the package gives no numbers.

## Appendix A: evidence ledger

Every panel used, with the numbers recomputed from the raw cells. MK = megakaryocyte. The same table is in `tables/evidence_ledger.csv`.

| Theme | Panel | System; n | Finding | Statistic | Caveat |
|---|---|---|---|---|---|
| Phenotype | Fig. 1b, 1f, 1k, 3i, 6b; Supp. Fig. 1e, 1f, 1g, 1i, 1k | mouse lung metastasis, creatine vs vehicle (control arms only); 10 experiments, 122 mice | Metastatic burden 3.0× (95% CI 2.5–3.6), foci 1.9× (1.7–2.2), lung weight 1.37× (1.26–1.50; 9 experiments); every experiment individually P<0.05 | random-effects pooling of log ratio of means | tumour line and route not labelled per panel; unblinded read-outs |
| Phenotype | Fig. 1c; Fig. 1l | survival; 10 vs 10; 20 vs 18 | Median survival 22 vs 19 days (hazard ratio 2.9, 1.0–8.2) and 16 vs 14 days (2.3, 1.2–4.5) | log-rank P=0.032; P=0.011 (reproduced) | unequal n in Fig. 1l not explained |
| Phenotype | Fig. 1h | early lung signal after tumour-cell injection (units not stated); 6 vs 6 | No difference at 0.25 h (7.3 vs 6.3); 2.8× more signal retained at 24 h with creatine | t-test at 24 h P=0.004 | — |
| Exposure | Supp. Fig. 1d, 1h | mouse serum creatine; 6 vs 6; 4 vs 4 | 66 → 179 µM (oral dosing); 78 → 227 µM (5% diet) | P=4e-10; P=2e-5 | — |
| Platelets | Fig. 2b | mouse platelet aggregation; 3 vs 3 | ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56% | t-tests P=0.0003–0.001 | SDs of 1–5 points: replicates may be technical |
| Platelets | Fig. 2a; Supp. Fig. 3a | mouse blood counts; 3 vs 3; 5 vs 5 | Platelet count unchanged (789 vs 789 ×10⁹/L); white cells, lymphocytes, monocytes, red cells unchanged | all not significant | — |
| Platelets | Fig. 2d | thromboelastography; 5 vs 5 | Only maximum amplitude moved (39.7 → 54.0 mm) | P=0.049; Welch P=0.052 | one of four parameters; not robust to multiplicity |
| Platelets | Supp. Fig. 2d | metastasis in recipients of donor platelets; 6/6/6 | Burden 5.9% (vehicle donors) vs 17.9% (creatine donors) vs 4.4% (creatine + aspirin donors) | Tukey P=0.0004 and P=0.0001 | 3 vehicle + 3 creatine mice are numerically identical to Fig. 6b animals; excluding them: 8.4 vs 23.0%, P=0.006 |
| Platelets | Fig. 2e, 2g (blots) | GP6 and P2RY12 protein in platelets and megakaryocytes of dosed mice; 3 lanes per arm | Both bands stronger with creatine in megakaryocytes; in platelets the change is modest and bands are near saturation | not quantified in the package | read by eye |
| Platelets | Fig. 2i (blot) | creatine added to cultured cells; 1 lane per dose | GP6 and P2RY12 rise in megakaryocytes at 0.2 and 2 mM; no change in platelets | not quantified in the package | — |
| Tumour SLC6A8 | Fig. 1f | melanoma with sh-Slc6a8, metastasis; 6 per group | Creatine effect intact: burden 4.6 → 15.9% (sh-scrambled) vs 5.8 → 18.3% (sh-Slc6a8) | interaction P=0.68; lung weight, SUV, foci P=0.21–0.95 | knock-down 81% at mRNA (Supp. Fig. 2a) but only about 40% at protein by densitometry of the single blot |
| MK SLC6A8 | Fig. 3b | serum creatine in Pf4-Cre; Slc6a8 fl/fl vs Cre controls; 5 per group | Systemic exposure equal: 89 → 239 µM (controls), 89 → 218 µM (knockout) | both P<1e-5 | — |
| MK SLC6A8 | Fig. 3c | megakaryocyte creatine content; 3 per group | 13.7 → 72.1 µmol/g in controls (5.3×) vs 13.7 → 21.1 in knockout (1.5×) | controls P=0.049; knockout P=0.20; interaction P=0.045 | n=3; wide spread in treated controls |
| MK SLC6A8 | Fig. 3d | platelet aggregation; 3 per group | Creatine effect reverses sign in knockout (ADP: controls +7, knockout −23 points; collagen: controls +12, knockout −10 points; thrombin: controls +13, knockout −10 points); knockout baseline 4–16 points lower | all Tukey P≤0.001 | SD about 1 point: replicates may be technical; the drop below baseline in knockout is unexplained |
| MK SLC6A8 | Fig. 3f | megakaryocyte 11-gene platelet-activation panel; 3 per group | Creatine induction 3.3× in controls (11/11 genes P<0.05) vs 0.90× in knockout | gene-level interaction P<0.05 for 7/11 genes | — |
| MK SLC6A8 | Fig. 3i | metastasis: burden; 4 per group | 2.4 → 7.9% in Cre controls vs 3.4 → 2.9% in knockout; 109% of creatine effect removed (95% CI 83–132%) | genotype × creatine interaction P=0.0003 | single experiment, n=4, unblinded; knockout band reduced but present on blot (Supp. Fig. 4a) |
| MK SLC6A8 | Fig. 3i | metastasis: foci; 4 per group | 29.8 → 56.5 in Cre controls vs 26.5 → 24.8 in knockout; 107% of creatine effect removed (95% CI 67–148%) | genotype × creatine interaction P=0.004 | — |
| MK SLC6A8 | Fig. 3i | metastasis: lung weight; 4 per group | 0.206 → 0.249 g in Cre controls vs 0.222 → 0.225 g in knockout; 93% of creatine effect removed (95% CI 68–115%) | genotype × creatine interaction P=0.0002 | — |
| MK SLC6A8 | Fig. 3g (blot) | megakaryocyte GP6 and P2RY12 protein; 2 lanes per arm | Both rise with creatine in Cre-control megakaryocytes and not in knockout megakaryocytes | not quantified in the package | read by eye |
| MK SLC6A8 | Supp. Fig. 4e | knockout megakaryocytes in culture, free vs liposomal creatine; 3 per group | Free creatine 0.89×; liposome-delivered creatine 2.35× (9/11 genes P<0.05) | per-gene t-tests | no empty-liposome control |
| Safety | Fig. 4a, 4c; Fig. 4b (blot) | brain tissue; 3 vs 3 | Oral creatine also raises brain creatine 96 → 114 µmol/g and phosphocreatine 2.0×; CKB band far stronger in brain than megakaryocytes | P=0.027; P=0.031 | relevant to systemic SLC6A8 or CKB inhibition |
| CKB | Fig. 4e; Fig. 4b, 4g (blots) | Ckb in megakaryocytes; 3 vs 3 | Creatine raises Ckb mRNA 1.8×; protein up on blots in vivo and in vitro | P=0.011 | blots have one lane per condition |
| CKB | Fig. 4j | cultured megakaryocytes, si-Ckb; 3 per group | Creatine induction 3.7× with si-scrambled vs 1.4× with si-Ckb; si-Ckb alone lowers baseline to 0.70× | interaction P<0.05 for 10/11 genes | in vitro only; knock-down partial (Supp. Fig. 5b) |
| CKB | Fig. 4l | cultured megakaryocytes, CKB over-expression; 3 vs 3 | Panel up 2.5× without added creatine (11/11 genes P<0.05) | per-gene t-tests | in vitro only |
| CKB | Fig. 4h; Supp. Fig. 5c | is it energy buffering?; 3 per group | Phosphocreatine does not reproduce the induction (0.63×); CKB over-expression leaves megakaryocyte creatine (33.7 vs 32.7 µmol/g) and phosphocreatine unchanged | P=0.61; P=0.16 | — |
| CKB | no panel | in vivo loss of function | None in the package | — | the decisive gap for CKB |
| STAT5B | Phospho-proteomics workbook | megakaryocyte phosphopeptides, creatine vs vehicle; 3 vs 3 mice; 5,812 peptides | One of two Stat5b peptides up (log2 fold change 5.7, P=0.0012, q=0.25; rank 17 by P); the other unchanged (P=0.47); Stat5a unchanged (P=0.40) | 0 peptides at q<0.05 (smallest q 0.17); among 3,787 peptides with absolute log2 fold change ≤ 2.5, 4.4% have P<0.05 | site not given in the file; a nomination, not a confirmation |
| STAT5B | Supp. Fig. 6a (blot) | canonical tyrosine phosphorylation in megakaryocytes; 3 vs 3 lanes | p-STAT5A/B (Y694/699) not detected with or without creatine; IL-2-treated Jurkat control positive; total STAT5B unchanged | not quantified | the creatine signal is not canonical STAT5 activation |
| STAT5B | Fig. 5e, 5f | STAT5B-FLAG (WT, S127A, 3A, S127D): pan-phospho / FLAG densitometry; 3 blots per arm | Creatine raises WT signal 1.39× (P=0.009) and 1.28× (P=0.086); S127A does not respond (1.06×, 0.88×) | S127A × creatine interaction P=0.015 and P=0.018 (two-way model over the four constructs) | over-expressed protein, pan-phospho antibody; cell type not labelled (companion blots are 293T, not megakaryocytes); in one replicate vehicle and creatine lanes are on separate membranes |
| STAT5B | Fig. 5g-i; Supp. Fig. 6d (blots) | CKB dependence of STAT5B phosphorylation; single blots | si-CKB removes the creatine-induced signal; CKB over-expression raises it on WT not S127A; recombinant CKB + ATP raises signal on purified STAT5B-FLAG | not quantified in the package | no kinase-dead CKB or S127A-substrate control; in the nuclear blot (Fig. 5h) S127A still rises about 2× with creatine by densitometry |
| STAT5B | Fig. 5j; Supp. Fig. 6i | ChIP-qPCR at P2ry12, Gp6, Rab4a promoters; 3 vs 3 | P2ry12 promoter 4.6–12×; Gp6 −1 kb 3.8×; Rab4a −0.2 kb 5.5×; exon controls unchanged | Sidak P<0.0001 to 0.04 (reproduced) | exon background 5–11% of input; antibody and IgG control not in the package |
| STAT5B | Fig. 6a | megakaryocytes + STAT5-IN-1; 3 per group | Creatine induction 5.3× without vs 1.08× with inhibitor; inhibitor alone lowers baseline to 0.52× | interaction P<0.05 for 9/11 genes | inhibits STAT5A and STAT5B |
| STAT5B | Fig. 6b | metastasis with systemic STAT5-IN-1; 5 per group | Burden 3.4 → 13.9% without vs 3.6 → 4.5% with inhibitor; 92% of creatine effect removed (95% CI 79–104%) | interaction P=7e-6 | not STAT5B-selective, not megakaryocyte-specific; 6 control animals also appear in Supp. Fig. 2d |
| STAT5B | Fig. 6e | megakaryocyte creatine in Pf4-iCre; Stat5b fl/fl; 3 per group | Uptake intact: 95 (WT + creatine) vs 98 µmol/g (knockout + creatine) | Tukey P=0.98 | places STAT5B downstream of uptake |
| STAT5B | Fig. 6g; Fig. 6f (blot) | megakaryocyte gene panel in Stat5b knockout; 3 per group; 3 arms | 3.6× in WT + creatine vs 1.09× in knockout + creatine (both vs WT vehicle); all 11 genes lower than WT + creatine, but P2ry12, Gpiba, F2r, Adra2a remain 1.6–1.9× above vehicle (P<0.05) | per-gene t-tests | no vehicle-treated knockout arm; controls labelled WT, not Cre-matched; no platelet-function or metastasis read-out |
| Human | Fig. 7b | serum creatine, 20 g/day for 14 days; 11 volunteers | 45 → 153 (day 3), 156 (day 7), 159 µM (day 14); 11/11 rise | paired t P<1e-7 at each day | single arm, no placebo; healthy 20–25-year-olds |
| Human | Fig. 7c | platelet aggregation/adhesion at day 14 vs day 0 (mean of three read-outs per agonist); 11 volunteers | epinephrine 1.84× (1.36–2.50; 11/11 up; Wilcoxon P=0.0010); collagen 2.25× (1.25–4.05; 9/11 up; Wilcoxon P=0.010); arachidonic acid 1.51× (1.02–2.25; 9/11 up; Wilcoxon P=0.054); ADP 1.11× (0.72–1.71; 6/11 up; Wilcoxon P=0.70) | paired analysis on log scale (the workbook used unpaired ANOVA against an all-ones baseline) | nothing moves at day 3; only epinephrine at day 7 (1.51×) |
| Human | Fig. 7e | platelet protein (immunoblot / β-actin); 4 volunteers | GP6 2.0× (day 7), 2.6× (day 14), 4/4 up; P2RY12 1.7× (day 14), 4/4 up | paired t at day 14: GP6 P=0.022, P2RY12 P=0.025 | protein, not transcript; n=4 |
| Human | Fig. 7d | transcripts in circulating CD41+ cells; 4 volunteers | At day 7, 10 of 11 genes are up in at least 3 of 4 volunteers (ADRA2A 21×, 4/4); volunteer 2 does not respond | paired log-scale t: 4 genes P<0.05 at day 7 | volunteer-4 values for RAB27B and PITPNB cannot be reproduced from the listed ΔCt |
| Human | Fig. 7g | volunteer platelets (day 0 vs day 7) transferred into mice; 5 vs 5 recipients | Burden 4.6 → 12.7% (2.7×) | P=0.014 | number of donors not stated |
| Human | Supp. Fig. 8a, 8b | BMI, platelet count and indices; 11 volunteers | No change (platelets 253 → 245 ×10⁹/L at day 14) | paired t all P>0.1 | — |

## Appendix B: smaller data notes

- Fig. 1l has 20 vehicle and 18 creatine mice; the difference is not explained.
- Fig. 1f statistics labels mix "sh-" and "si-"; Supp. Fig. 2a is labelled "Si-" for the same knock-down shown as "Sh-" on the blot.
- Fig. 4d is labelled creatinine; the assay named in the conventions measures creatine.
- Fig. 7d: volunteer 4's PITPNB ΔCt values are on a different scale (+26 to +28) from every other entry (−12 to +1).
- Fig. 5e and 5f are two series of the same design; the workbook does not say how they differ.
- Thromboelastography (Fig. 2d): only one of four parameters reaches P = 0.049, and not after correcting for four tests.
- The conventions name the D'Agostino–Pearson normality test, which cannot be run on groups of 3–6.
- The conventions say coagulation tests were taken from the volunteers; the workbook contains none.
- The package has no data on primary-tumour growth, on metastatic sites other than lung, or on bleeding.
- Nuclear STAT5B (Supp. Fig. 6h) has two lanes per group, and the two vehicle lanes differ about 2.5-fold by my densitometry.
- In the nuclear-fraction blot (Fig. 5h) the S127A mutant still rises about 2-fold with creatine by my densitometry, so S127 may not be the only creatine-responsive site.

## Files

- `CRE-MK-01_validation_proposal.pdf` — this document with figures
- `tables/evidence_ledger.csv` — Appendix A as a spreadsheet
- `tables/verification_log.csv` — the 232 reported versus recomputed P values
- `tables/` — re-analysis tables (pooled creatine effect, share of effect removed, gene panel, human paired analysis, phosphoproteomics screen hits)
- `figures/` — Figures 1–4
- `analysis/` — scripts that regenerate every number and figure
