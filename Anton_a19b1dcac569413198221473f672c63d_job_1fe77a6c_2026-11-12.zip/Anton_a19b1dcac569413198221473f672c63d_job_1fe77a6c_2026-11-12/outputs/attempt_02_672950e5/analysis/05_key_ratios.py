import numpy as np, scipy.stats as st
from wb import *
def logratio(a, b, label):
    la, lb = np.log(a), np.log(b)
    n1, n2 = len(a), len(b); sp2 = ((n1-1)*la.var(ddof=1)+(n2-1)*lb.var(ddof=1))/(n1+n2-2)
    se = np.sqrt(sp2*(1/n1+1/n2)); d = lb.mean()-la.mean(); tc = st.t.ppf(0.975, n1+n2-2)
    p = 2*st.t.sf(abs(d/se), n1+n2-2)
    print(f'  {label}: geometric-mean ratio {np.exp(d):.2f} (95% CI {np.exp(d-tc*se):.2f}-{np.exp(d+tc*se):.2f}), p={p:.3g}; arithmetic means {a.mean():.2f} -> {b.mean():.2f} (x{b.mean()/a.mean():.2f})')
    return d, se, n1+n2-2, sp2
def ror(g, label):
    # g: [ctl_veh, ctl_cre, pert_veh, pert_cre], log scale, pooled var
    L = [np.log(x) for x in g]; dfree = sum(len(x) for x in L)-4
    mse = sum((len(x)-1)*x.var(ddof=1) for x in L)/dfree
    est = (L[3].mean()-L[2].mean())-(L[1].mean()-L[0].mean()); se = np.sqrt(mse*sum(1/len(x) for x in L)); tc = st.t.ppf(0.975, dfree)
    p = 2*st.t.sf(abs(est/se), dfree)
    print(f'  {label}: ratio of ratios {np.exp(est):.2f} (95% CI {np.exp(est-tc*se):.2f}-{np.exp(est+tc*se):.2f}), interaction p={p:.3g}; pooled SD ln = {np.sqrt(mse):.2f}')
print('Fig 3i (Slc6a8 cKO), metastatic burden:')
g = [col('Fig. 3i', c, 10, 13) for c in 'BCDE']
logratio(g[0], g[1], 'WT: creatine vs vehicle'); logratio(g[2], g[3], 'cKO: creatine vs vehicle'); logratio(g[0], g[2], 'vehicle: cKO vs WT'); logratio(g[1], g[3], 'creatine: cKO vs WT'); ror(g, 'cKO x creatine')
print('Fig 3i foci:')
g = [col('Fig. 3i', c, 17, 20) for c in 'BCDE']
logratio(g[0], g[1], 'WT'); logratio(g[2], g[3], 'cKO'); ror(g, 'cKO x creatine')
print('Fig 3i lung weight:')
g = [col('Fig. 3i', c, 3, 6) for c in 'BCDE']
logratio(g[0], g[1], 'WT'); logratio(g[2], g[3], 'cKO'); ror(g, 'cKO x creatine')
print('Fig 6b (STAT5-IN-1), burden:')
g = [col('Fig. 6b', c, 4, 8) for c in 'BCDE']
logratio(g[0], g[1], 'no inhibitor: creatine vs vehicle'); logratio(g[2], g[3], 'inhibitor: creatine vs vehicle'); logratio(g[0], g[2], 'vehicle: inhibitor vs none'); logratio(g[1], g[3], 'creatine: inhibitor vs none'); ror(g, 'STAT5i x creatine')
print('Fig 6b foci:')
g = [col('Fig. 6b', c, 13, 17) for c in 'BCDE']
logratio(g[0], g[1], 'no inh'); logratio(g[2], g[3], 'inh'); ror(g, 'STAT5i x creatine')
print('Fig 1f (tumor shSlc6a8), burden:')
g = [col('Fig. 1f', c, 22, 27) for c in 'BCDE']
logratio(g[0], g[1], 'shScr'); logratio(g[2], g[3], 'shSlc6a8'); ror(g, 'tumor KD x creatine')
print('Supp 2d platelet transfer, burden:')
g = [col('Supplementary Fig  2d', c, 5, 10) for c in 'CDE']
logratio(g[0], g[1], 'creatine-donor vs vehicle-donor PLT'); logratio(g[1], g[2], 'creatine+aspirin donor vs creatine donor'); logratio(g[0], g[2], 'creatine+aspirin donor vs vehicle donor')
print('Fig 7g human platelets d7 vs d0, burden:')
logratio(col('Fig. 7g','B',12,16), col('Fig. 7g','C',12,16), 'd7 vs d0 donor PLT'); logratio(col('Fig. 7g','B',19,23), col('Fig. 7g','C',19,23), 'foci d7 vs d0')
