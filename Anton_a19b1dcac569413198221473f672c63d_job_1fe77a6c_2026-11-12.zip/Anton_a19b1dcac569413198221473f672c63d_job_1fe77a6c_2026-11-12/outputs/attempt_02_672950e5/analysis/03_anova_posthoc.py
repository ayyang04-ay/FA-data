import numpy as np, scipy.stats as st, itertools, pandas as pd
from wb import *

def tukey(groups, names):
    res = st.tukey_hsd(*groups)
    F, p = st.f_oneway(*groups)
    out = {}
    for i in range(len(groups)):
        for j in range(i+1, len(groups)):
            ci = res.confidence_interval(0.95)
            out[(names[i], names[j])] = dict(diff=groups[i].mean()-groups[j].mean(), lo=ci.low[i,j], hi=ci.high[i,j], p=res.pvalue[i,j])
    return F, p, out

def show(title, groups, names, reported=None):
    F, p, out = tukey(groups, names)
    print(f'\n=== {title}')
    for n,g in zip(names, groups):
        print(f'   {n:45s} n={len(g)} mean={g.mean():.4g} sd={g.std(ddof=1):.3g}  vals={np.round(g,4).tolist()}')
    print(f'   one-way ANOVA F={F:.3f} p={p:.3g}')
    for (a,b),d in out.items():
        print(f'   Tukey {a} vs {b}: diff={d["diff"]:.4g} CI[{d["lo"]:.4g},{d["hi"]:.4g}] p={d["p"]:.4g}')
    if reported:
        print('   REPORTED:')
        for r in reported: print('     ', r)
    return out

def rep(sheet, rows, cols):
    out = []
    for r in rows:
        out.append(' | '.join(str(v(sheet, f'{c}{r}')) for c in cols))
    return out

# Fig 1f
names = ['shScr-Veh','shScr-Cre','shSlc6a8-Veh','shSlc6a8-Cre']
for lab, r0, r1, rr in [('Lung weight',4,9,(4,5,6)),('SUV-BW',13,18,(13,14,15)),('Metastatic burden',22,27,(22,23,24)),('Foci',31,36,(31,32,33))]:
    g = [col('Fig. 1f', c, r0, r1) for c in 'BCDE']
    show(f'Fig 1f {lab}', g, names, rep('Fig. 1f', rr, 'GHILK'))

# Fig 3d: rows 4 (ADP), 5 (Collagen), 6 (Thrombin); groups B-D, E-G, H-J, K-M
names = ['WT-Veh','WT-Cre','cKO-Veh','cKO-Cre']
for lab, r, rr in [('ADP',4,(4,5)),('Collagen',5,(10,11)),('Thrombin',6,(15,16))]:
    g = [row('Fig. 3d', r, a, b) for a,b in [('B','D'),('E','G'),('H','J'),('K','M')]]
    show(f'Fig 3d {lab}', g, names, rep('Fig. 3d', rr, 'OPQTS'))

# Fig 3i
for lab, r0, r1, rr in [('Lung weight',3,6,(3,4,5)),('Metastatic burden',10,13,(10,11,12)),('Foci',17,20,(17,18,19))]:
    g = [col('Fig. 3i', c, r0, r1) for c in 'BCDE']
    show(f'Fig 3i {lab}', g, names, rep('Fig. 3i', rr, 'GHILK'))

# Fig 5e
for sh, cols_, rrA, rrB, repc in [('Fig. 5e','NOPQ',(10,11,12,13),(22,23,24),'MNORQ'),('Fig. 5f','NOPQ',(9,10,11,12),(22,23,24),'LMNQP')]:
    g = [col(sh, c, 4, 6) for c in cols_]
    show(f'{sh} Vehicle p-FLAG/FLAG', g, ['Veh-WT','Veh-S127A','Veh-3A','Veh-S127D'], rep(sh, rrA, repc))
    g2 = [col(sh, c, 17, 19) for c in cols_]
    show(f'{sh} Creatine p-FLAG/FLAG', g2, ['Cre-WT','Cre-S127A','Cre-3A','Cre-S127D'], rep(sh, rrB, repc))
    # combined 8-group and two-way view
    allg = g+g2
    show(f'{sh} ALL 8 groups (not reported)', allg, ['Veh-WT','Veh-S127A','Veh-3A','Veh-S127D','Cre-WT','Cre-S127A','Cre-3A','Cre-S127D'])
    for nm, a, b in zip(['WT','S127A','3A','S127D'], g, g2):
        t,p = st.ttest_ind(a,b)
        print(f'   [{sh}] creatine vs vehicle within {nm}: {a.mean():.3f} -> {b.mean():.3f} (x{b.mean()/a.mean():.2f}) t-test p={p:.4f}')

# Fig 6b
names = ['Veh','Cre','Veh+STAT5i','Cre+STAT5i']
for lab, r0, r1, rr in [('Metastatic burden',4,8,(4,5,6,7)),('Foci',13,17,(13,14,15,16))]:
    g = [col('Fig. 6b', c, r0, r1) for c in 'BCDE']
    show(f'Fig 6b {lab}', g, names, rep('Fig. 6b', rr, 'GHILK'))

# Fig 6e
g = [col('Fig. 6e', c, 5, 7) for c in 'CDE']
show('Fig 6e MK creatine', g, ['WT-Veh','WT-Cre','Stat5b cKO-Cre'], rep('Fig. 6e', (5,6,7), 'GHILK'))

# Supp 2d
names = ['Veh donor PLT','Cre donor PLT','Cre+aspirin donor PLT']
for lab, r0, r1, rr in [('Metastatic burden',5,10,(5,6,7)),('Foci',14,19,(14,15,16))]:
    g = [col('Supplementary Fig  2d', c, r0, r1) for c in 'CDE']
    show(f'Supp 2d {lab}', g, names, rep('Supplementary Fig  2d', rr, 'GHILK'))

# Supp 4b, 4c
names = ['WT-Veh','WT-Cre','cKO-Veh','cKO-Cre']
g = [col('Supplementary Fig  4b', c, 5, 7) for c in 'CDEF']
show('Supp 4b PLT', g, names, rep('Supplementary Fig  4b', (5,6,7,8), 'HIJML'))
g = [col('Supplementary Fig  4c', c, 6, 13) for c in 'CDEF']
show('Supp 4c a-granules', g, names, rep('Supplementary Fig  4c', (7,8,9), 'IJKNM'))

# Supp 7a
names = ['Veh+Ctrl','Cre+Ctrl','Veh+STAT5i','Cre+STAT5i']
for lab, r0, r1, rr in [('PLT',4,6,(4,5,6)),('PCT',11,13,(11,12,13)),('MPV',17,19,(17,18,19)),('PDW',23,25,(23,24,25))]:
    g = [col('Supplementary Fig  7a', c, r0, r1) for c in 'BCDE']
    show(f'Supp 7a {lab}', g, names, rep('Supplementary Fig  7a', rr, 'GHILK'))
# Supp 7b
names = ['WT-Veh','WT-Cre','Stat5b cKO-Cre']
for lab, r0, r1, rr in [('PLT',4,6,(4,5,6)),('PCT',10,12,(10,11,12)),('MPV',16,18,(16,17,18)),('PDW',22,24,(22,23,24))]:
    g = [col('Supplementary Fig  7b', c, r0, r1) for c in 'BCD']
    show(f'Supp 7b {lab}', g, names, rep('Supplementary Fig  7b', rr, 'FGHKJ'))
