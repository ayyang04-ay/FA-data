#!/usr/bin/env bash
# Reproduces every number, table and figure in the proposal from the two workbooks.
# Inputs are read from $CRE_DATA_DIR (default /tmp/world/filesystem).
# 'chem' env: openpyxl, pandas, scipy, statsmodels, matplotlib.  'core' env: lifelines (survival only).
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p ../figures ../tables logs
PY="micromamba run -n chem python"
$PY 00_export_inputs.py
$PY 01_ttests.py                       > logs/01_ttests.txt
micromamba run -n core python 02_survival.py > logs/02_survival.txt 2>/dev/null
$PY 03_anova_posthoc.py                > logs/03_anova_posthoc.txt 2>/dev/null
$PY 04_interactions.py                 > logs/04_interactions.txt
$PY 05_key_ratios.py                   > logs/05_key_ratios.txt
$PY 06_creatine_effect_meta_fig2.py    > logs/06_creatine_effect_meta.txt
$PY 07_qpcr_panels.py                  > logs/07_qpcr_panels.txt
$PY 08_gene_program_contrasts.py       > logs/08_gene_program_contrasts.txt
$PY 09_human_platelet_function.py      > logs/09_human_platelet_function.txt 2>/dev/null
$PY 10_human_cd41_qpcr.py              > logs/10_human_cd41_qpcr.txt
$PY 11_human_protein_serum_cbc.py      > logs/11_human_protein_serum_cbc.txt
$PY 12_human_sample_size.py            > logs/12_human_sample_size.txt
$PY 13_chip_and_small_panels.py        > logs/13_chip_and_small_panels.txt
$PY 14_phosphoproteomics.py            > logs/14_phosphoproteomics.txt 2>/dev/null
$PY 15_duplicate_scan.py               > logs/15_duplicate_scan.txt
$PY 16_power_simulation.py             > logs/16_power_simulation.txt
$PY 17_inventory_of_reported_tests.py  > logs/17_inventory_of_reported_tests.txt 2>/dev/null
$PY 18_panel_by_panel_table.py         > logs/18_panel_by_panel_table.txt 2>/dev/null
$PY 19_export_tables.py                > logs/19_export_tables.txt
for f in fig1_causal_chain.py fig3_in_vivo_tests.py fig4_gene_program.py fig5_phosphoproteomics.py fig6_human_cohort.py slide_scorecard.py; do $PY $f; done
$PY 20_assemble_proposal.py            > logs/20_assemble_proposal.txt
$PY build_pdf.py ../CRE-MK-01_validation_proposal.md ../CRE-MK-01_validation_proposal.pdf > logs/21_build_pdf.txt
rm -rf __pycache__
echo "done"
