| Panel | Measurement | n | Result (re-derived from the raw values) | Caveat |
|---|---|---|---|---|
| Fig. 1a | Lung weight, vehicle vs creatine | 6/6 | 0.227 → 0.324 g (×1.43); p=0.0003 |  |
| Fig. 1a | PET SUV-BW | 6/6 | 418 → 894 (×2.14); p=0.003 |  |
| Fig. 1b | Lung metastatic burden | 6/6 | 5.2 → 16.2 % (×3.12); p=0.0005 |  |
| Fig. 1b | Metastatic foci | 6/6 | 27.7 → 53.2 (×1.92); p=0.0006 |  |
| Fig. 1c | Survival | 10/10 | median 22 → 19 d; HR 2.93 (95% CI 1.04–8.23); log-rank p=0.032 |  |
| Fig. 1f | Burden; melanoma cells with sh-scrambled vs sh-Slc6a8, ± creatine | 6 per group | sh-scr 4.6 → 15.9 %; sh-Slc6a8 5.8 → 18.3 %; interaction p=0.44 (ln scale); same pattern for lung weight, SUV, foci | tumor-cell knock-down; protein reduction modest on blot (Supp. Fig. 2a) |
| Fig. 1h | Time course 0.25–24 h (readout not named in sheet) | 6/6 | 0.25 h: ×0.86 (p=0.31); 6 h: ×1.51 (p=0.0002); 12 h: ×1.79 (p=0.026); 24 h: ×2.76 (p=0.004) | reads as early tumor-cell retention |
| Fig. 1i | GFP+ cells per field | 8/8 fields | 9.1 → 20.4 (×2.23); p<0.0001 | n = fields, not animals |
| Fig. 1j | Lung weight (second data set) | 6/6 | 0.185 → 0.302 g (×1.63); p=0.001 |  |
| Fig. 1j | PET SUV-BW | 6/6 | 614 → 1032 (×1.68); p=0.0008 |  |
| Fig. 1k | Lung metastatic burden | 6/6 | 7.2 → 16.4 % (×2.27); p<0.0001 |  |
| Fig. 1k | Metastatic foci | 6/6 | 25.5 → 42.2 (×1.65); p<0.0001 |  |
| Fig. 1l | Survival | 20/18 | median 16 → 14 d; HR 2.28 (95% CI 1.16–4.46); log-rank p=0.011 |  |
| Fig. 2a | Platelet count and indices (PLT, PCT, PDW, MPV) | 3/3 | PLT 789 → 789 ×10⁹/L (p=1.00); PCT, PDW, MPV all n.s. |  |
| Fig. 2b | Platelet aggregation (%) | 3/3 | ADP 42 → 57 (p=0.0003); collagen 66 → 79 (p=0.0005); thrombin 25 → 56 (p=0.001) |  |
| Fig. 2c | α-granules per field | 8/8 fields | 2.0 → 3.9 (×1.94); p=0.008 | n = fields, not animals |
| Fig. 2d | Thromboelastography | 5/5 | MA 39.7 → 54.0 mm (p=0.049); R p=0.90, K p=0.17, α p=0.15 | only MA nominally significant |
| Fig. 2e / 2g | GP6 and P2RY12 protein in platelets / MKs from treated mice (blots) | 3 lanes per group | MKs (2g): both bands stronger with creatine. Platelets (2e): little change once loading is allowed for | no densitometry in package; read by eye |
| Fig. 2f | 11-gene activation panel, MKs from treated mice (qPCR) | 3/3 | all 11 genes up, ×1.6–5.6 (median ×3.0); 10/11 p<0.05 |  |
| Fig. 2i | GP6, P2RY12 after creatine 0 / 0.2 / 2 mM in culture (blots) | 1 lane per dose | induced in MKs, not in isolated platelets | single blot |
| Fig. 2j | PKH-positive area (labeled platelets) | 8/8 fields | 1.87 → 4.47 % (×2.39); p=0.001 | n = fields, not animals |
| Fig. 3b | Serum creatine, Cre control vs Slc6a8 cKO | 5 per group | control 89 → 239 µM (×2.7); cKO 89 → 218 µM (×2.4); interaction p=0.18 | exposure equal in both genotypes |
| Fig. 3c | MK intracellular creatine | 3 per group | control 13.7 → 72.1 (×5.3, p=0.049); cKO 13.7 → 21.1 (×1.5, p=0.20); interaction p=0.045 |  |
| Fig. 3d | Platelet aggregation (%), 2×2 | 3 per group | ADP: control 63 → 71, cKO 54 → 31; collagen: control 65 → 77, cKO 61 → 51; thrombin: control 61 → 75, cKO 45 → 35; all interactions p<0.0001 | creatine lowers aggregation in cKO; cKO-vehicle below control-vehicle |
| Fig. 3f | 11-gene panel, 2×2 (qPCR) | 3 per group | control: median ×3.5; cKO (creatine vs cKO-vehicle): median ×1.0, 0/11 genes still induced; interaction p<0.05 for 7/11 |  |
| Fig. 3g | GP6, P2RY12 protein, 2×2 (blots) | 2 lanes per group | stronger with creatine in controls (GP6 clearly, P2RY12 in one of two lanes), unchanged in cKO | no densitometry |
| Fig. 3i | Lung metastasis, 2×2 (MK-lineage Slc6a8 × creatine) | 4 per group | burden: control 2.4 → 7.9 %, cKO 3.4 → 2.9 %; geometric-mean creatine effect ×3.56 (1.96–6.45) vs ×0.79 (0.44–1.42); interaction p=0.0009. Foci 30 → 56 vs 26 → 25 (p=0.023). Lung weight 0.206 → 0.249 vs 0.222 → 0.225 g (p=0.0002) | the only lineage-specific genetic test of the endpoint |
| Fig. 4a | Creatine in MKs and brain after dosing | 3/3 | MK 42 → 129 µmol/g (×3.0, p=0.0004); brain 96 → 114 (×1.19, p=0.027) |  |
| Fig. 4c | Phosphocreatine in MKs and brain | 3/3 | MK 0.37 → 1.46 ng/µg (×3.9, p=0.0006); brain 0.32 → 0.63 (×2.0, p=0.031) |  |
| Fig. 4b | CKB protein in MKs and brain (blot) | 1 lane per group | CKB up in MKs after creatine; brain CKB far higher and unchanged | single blot |
| Fig. 4d | Creatine in cultured MKs | 3/3 | 30 → 109 µmol/g (×3.6, p=0.005) | sheet label says "Creatinine" |
| Fig. 4e | Ckb mRNA (and CKB blot) in MKs | 3/3 | ×1.8, p=0.011; CKB band stronger | sheet says Vehicle, blot says Control |
| Fig. 4f | Phosphocreatine in cultured MKs | 3/3 | 0.23 → 1.24 ng/µg (×5.4, p=0.023) |  |
| Fig. 4g / 4h | Creatine vs phosphocreatine added to cultured MKs (blots; qPCR) | 3 per group | creatine: median ×3.3; phosphocreatine: median ×0.6 (no induction; 5/11 genes lower) | uptake of phosphocreatine not verified |
| Fig. 4i / 4j | si-Ckb ± creatine in cultured MKs (blots; qPCR) | 3 per group | creatine: median ×4.2 with si-scrambled vs ×1.5 with si-Ckb (relative to si-Ckb alone); 6/11 genes still induced; si-Ckb lowers baseline in 8/11 | partial knock-down (Supp. Fig. 5b) |
| Fig. 4k / 4l | CKB over-expression in cultured MKs (blots; qPCR) | 3/3 | all 11 genes up ×1.7–6.0 (median ×2.4) without creatine |  |
| Fig. 5e | pan-phospho / FLAG on STAT5B-FLAG WT, S127A, 3A, S127D ± creatine (densitometry) | 3 blots per group | WT 0.72 → 1.00 (×1.39, p=0.009); S127A 0.78 → 0.83; 3A 0.77 → 0.74; S127D 1.05 → 1.01; creatine WT vs S127A Tukey p=0.029 | host cell not named; vehicle and creatine analyzed in separate ANOVAs in sheet |
| Fig. 5f | pan-phospho / FLAG on STAT5B-FLAG WT, S127A, 3A, S127D ± creatine (densitometry) | 3 blots per group | WT 0.75 → 0.97 (×1.28, p=0.086); S127A 0.72 → 0.63; 3A 0.76 → 0.67; S127D 1.02 → 0.99; creatine WT vs S127A Tukey p=0.016 | host cell not named; vehicle and creatine analyzed in separate ANOVAs in sheet |
| Fig. 5g–5i | CKB over-expression / si-CKB effects on pan-phospho and nuclear STAT5B-FLAG (blots) | single blots | CKB-OE raises pan-phospho on WT not S127A; si-CKB blunts creatine-induced nuclear signal | 293T system (Supp. Fig. 6e–g); no densitometry |
| Fig. 5j | ChIP-qPCR at P2ry12 and Gp6 promoters, MKs ± creatine | 3/3 | P2ry12: −2 kb ×4.8, −1 kb ×4.7, −0.2 kb ×12.1 (each Sidak p<0.0001), exon ×1.3 n.s.; Gp6: −1 kb ×3.8 (p=0.0001), −0.2 kb ×2.9 (p=0.018), −2 kb and exon n.s. | ChIP antibody not named in package |
| Fig. 6a | 11-gene panel, MKs, creatine ± STAT5-IN-1 (qPCR) | 3 per group | creatine: median ×4.2 without vs ×1.15 with inhibitor; inhibitor alone lowers 7/11 genes (to ×0.2–0.7) | inhibits STAT5A and STAT5B |
| Fig. 6b | Lung metastasis, 2×2 (STAT5-IN-1 × creatine) | 5 per group | burden 3.4 → 13.9 % without vs 3.6 → 4.5 % with inhibitor; creatine effect ×4.08 (2.92–5.71) vs ×1.30 (0.80–2.10); interaction p=0.0004. Foci 30 → 58 vs 30 → 27 (p=0.002) | systemic, not isoform- or lineage-selective; 6 records identical to Supp. Fig. 2d |
| Fig. 6d | STAT5B protein in MKs, WT vs Pf4-iCre;Stat5b fl/fl (blot) | 1 lane each | band absent in cKO | single blot |
| Fig. 6e | MK creatine: WT-vehicle, WT-creatine, Stat5b cKO-creatine | 3 per group | 20, 95, 98 µmol/g; cKO-creatine vs WT-creatine p=0.98 | uptake intact; no cKO-vehicle group |
| Fig. 6f | CKB, GP6, P2RY12 in MKs; GP6, P2RY12 in platelets (blots) | 1 lane per group | CKB still induced in cKO; GP6 and P2RY12 back near vehicle level | single blots; no densitometry |
| Fig. 6g | 11-gene panel: WT-vehicle, WT-creatine, Stat5b cKO-creatine (qPCR) | 3 per group | WT-creatine median ×4.0; cKO-creatine median ×1.3 vs WT-vehicle; still up: P2ry12 ×1.9, Adra2a ×1.9, Gpiba ×1.6, F2r ×1.6 (p<0.05), Gp6 ×1.4 (p=0.06) | no cKO-vehicle group; control is "WT", not Cre-matched |
| Fig. 7b | Human serum creatine, days 0/3/7/14 | 11 volunteers | 45 → 153 / 156 / 159 µM (×3.5 at day 14; 11/11 up; paired p<0.0001) |  |
| Fig. 7c | Human platelet maximal aggregation, day 14 vs own day 0 | 11 volunteers | collagen ×2.51 (1.46–4.33), 9/11 up, p=0.005; epinephrine ×1.63 (1.21–2.20), 10/11 up, p=0.002; arachidonic acid ×1.32 (0.94–1.84), 9/11 up, p=0.042; ADP ×1.07 (0.73–1.58), 6/11 up, p=0.46 | paired Wilcoxon (mine); sheet used Dunnett on fold changes; average-aggregation and adhesion metrics agree |
| Fig. 7c | … day 7 | 11 volunteers | epinephrine ×1.33 (10/11 up, p=0.005); collagen ×1.25 (p=0.10); ADP ×1.03 |  |
| Fig. 7d | Human CD41+ cells, 11 genes, days 3/7/14 (qPCR) | 4 volunteers | day 7 (geometric mean; n up of 4): GP6 ×6.4 (3/4), P2RY12 ×3.1 (3/4), ADRA2A ×21 (4/4); day 14: GP6 ×3.2 (3/4), P2RY12 ×5.0 (3/4), RAB4A ×0.38 (0/4 up) | volunteer 2 largely non-responsive; RAB4A falls; two normalized values not reproducible |
| Fig. 7e | Human platelet GP6 and P2RY12 protein (densitometry) | 4 volunteers | day 14: GP6 ×2.6 (4/4 up; paired p=0.022); P2RY12 ×1.7 (4/4 up; p=0.025) |  |
| Fig. 7g | Lung metastasis in mice given human platelets from day 0 vs day 7 of supplementation | 5/5 recipients | burden 4.6 → 12.7 % (geometric-mean ratio ×2.76, 1.60–4.76; p=0.014); foci 22 → 39; lung weight 0.186 → 0.236 g | number of donors not recorded |
| Supp. Fig. 1a–c | Body weight, food and water intake | 4/4; 6/6 | no differences (p=0.08–0.99) |  |
| Supp. Fig. 1d | Serum creatine on the oral regimen | 6/6 | 66 → 179 µM (×2.71); p<0.0001 |  |
| Supp. Fig. 1e | Lung metastatic burden (further vehicle-vs-creatine data set) | 6/6 | 16.2 → 33.6 % (×2.07); p=0.001 | model not named in package |
| Supp. Fig. 1f | Lung metastatic burden (further vehicle-vs-creatine data set) | 4/4 | 3.9 → 10.8 % (×2.77); p=0.009 | model not named in package |
| Supp. Fig. 1g | Lung metastatic burden (further vehicle-vs-creatine data set) | 10/10 | 7.6 → 26.2 % (×3.45); p<0.0001 | model not named in package |
| Supp. Fig. 1k | Lung metastatic burden (further vehicle-vs-creatine data set) | 10/10 | 3.8 → 13.4 % (×3.54); p=0.0008 | model not named in package |
| Supp. Fig. 1h | Serum creatine on 5% creatine diet | 4/4 | 78 → 227 µM (×2.91); p<0.0001 |  |
| Supp. Fig. 1i | Lung metastatic burden, 5% creatine diet | 4/4 | 7.3 → 26.2 % (×3.60); p=0.005 |  |
| Supp. Fig. 2a | Slc6a8 knock-down in tumor cells (qPCR; blot) | 3/3 | mRNA 19% of control (p=0.0008); protein band only modestly weaker | sheet says si-, blot says sh- |
| Supp. Fig. 2d | Lung metastasis in recipients of platelets from vehicle, creatine, or creatine+aspirin donors | 6 per group | burden 5.9 / 17.9 / 4.4 %; creatine vs vehicle donors ×3.26 (1.83–5.82), Tukey p=0.0004; creatine+aspirin vs creatine donors ×0.22 (0.10–0.47), p=0.0001 | rows 4–6 of first two groups identical to Fig. 6b records |
| Supp. Fig. 3a | White cells, lymphocytes, monocytes, red cells | 5/5 | no differences (p=0.11–0.84) |  |
| Supp. Fig. 3c | MK maturation genes (qPCR) | 3/3 | Nfe2, Gata1, Zfpm1, Itgb3, Tubb1, Lims1 unchanged; Hsd3b1 ×1.4, Casp12 ×1.9 up, Myl9 ×0.5 down (p<0.05) |  |
| Supp. Fig. 4a | SLC6A8 protein in MKs, control vs cKO (blot) | 1 lane each | band reduced, not absent | single blot; no densitometry |
| Supp. Fig. 4b | Platelet count, 2×2 | 3 per group | 890 / 909 / 1042 / 992 ×10⁹/L; all n.s. |  |
| Supp. Fig. 4c | α-granules per field, 2×2 | 8 fields per group | control 2.6 → 5.1; cKO 2.25 → 2.25; interaction p=0.006 | n = fields, not animals |
| Supp. Fig. 4e | Slc6a8-cKO MKs in culture: free vs liposomal creatine (qPCR) | 3 per group | free creatine median ×1.0; liposomal creatine median ×2.7 (9/11 genes induced) | bypass of the transporter restores the response |
| Supp. Fig. 5a | Gatm, Gamt mRNA in MKs | 3/3 | ×1.15 (p=0.37), ×0.88 (p=0.61): creatine-synthesis genes unchanged |  |
| Supp. Fig. 5c | Creatine and phosphocreatine in MKs, empty vector vs CKB over-expression | 3/3 | creatine 33.7 vs 32.7 µmol/g (p=0.61); phosphocreatine 0.17 vs 0.21 ng/µg (×1.25, p=0.16) | n=3; cannot exclude a modest phosphocreatine rise |
| Supp. Fig. 6a | p-STAT5A/B (Y694/699) in MKs ± creatine; Jurkat ± IL-2 control (blots) | 3 lanes per group | no tyrosine-phospho signal in MKs with or without creatine; positive control works | canonical STAT5 activation not involved |
| Supp. Fig. 6d | Recombinant His-CKB + ATP on STAT5B-FLAG (blot) | single blot | pan-phospho signal stronger with CKB | no kinase-dead or S127A-substrate control in this panel |
| Supp. Fig. 6h | Nuclear STAT5B in MKs ± creatine (blot) | 2 lanes per group | band stronger with creatine: clearly against one vehicle lane, marginally against the other | no densitometry |
| Supp. Fig. 6i | ChIP-qPCR at Rab4a promoter | 3/3 | −0.2 kb ×5.5 (Sidak p<0.0001), −1 kb ×2.7 (p=0.039); −2 kb, exon n.s. | ChIP antibody not named |
| Supp. Fig. 7a | Platelet count and indices, creatine ± STAT5-IN-1 | 3 per group | all comparisons n.s. (PLT 646 / 762 / 836 / 598) | n=3, wide spread |
| Supp. Fig. 7b | Platelet count and indices: WT-vehicle, WT-creatine, Stat5b cKO-creatine | 3 per group | PLT 896 / 760 / 693 (n.s.); plateletcrit 0.36 / 0.29 / 0.26 (WT-vehicle vs cKO-creatine p=0.055) | no cKO-vehicle group |
| Supp. Fig. 8a–b | Human BMI; platelet count and indices | 11 volunteers | BMI 20.9 → 21.1 (paired p=0.24); PLT 253 → 245 ×10⁹/L, PCT, MPV, PDW unchanged |  |
| Supp. Fig. 8c | ITGA2B (CD41) mRNA: CD41+ fraction vs monocytes vs MEG-01 | 3 each | CD41+ fraction 17× monocytes; MEG-01 0.7× CD41+ fraction | purity check of the CD41+ preparation |
| Supp. Fig. 8d | GP6, P2RY12 blots for the 4 volunteers | 4 volunteers | source blots for Fig. 7e |  |
| Phosphoproteomics | MK phosphopeptides, creatine vs vehicle | 3/3 mice | 5,812 rows / 2,033 genes; 238 rows p<0.05 among 4,110 non-degenerate tests (205.5 expected by chance); 0 rows q<0.05 (min q 0.167; min BH-adjusted p 0.25); Stat5b: LOG_FOLDCHANGE 5.70, p=0.0012, q=0.246, rank 17; second Stat5b peptide and Stat5a unchanged | gene-level IDs only (no site); direction/base of log ratio not stated |