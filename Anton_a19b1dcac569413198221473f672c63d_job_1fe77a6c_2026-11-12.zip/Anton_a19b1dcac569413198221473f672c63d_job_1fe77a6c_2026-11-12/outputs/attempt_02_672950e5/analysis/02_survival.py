import numpy as np, json
C = json.load(open('cells.json'))
from lifelines.statistics import logrank_test
from lifelines import CoxPHFitter
import pandas as pd, warnings
warnings.filterwarnings('ignore')
for sh, r0, r1, rep in [('Fig. 1c',4,23,('F6','F8')),('Fig. 1l',4,41,('F5','F7'))]:
    ws = C[sh]
    tv, tc = [], []
    for r in range(r0, r1+1):
        t = ws.get(f'A{r}'); b = ws.get(f'B{r}'); c = ws.get(f'C{r}')
        if t is None: continue
        if b is not None: tv.append((t,b))
        if c is not None: tc.append((t,c))
    tv = np.array(tv); tc = np.array(tc)
    res = logrank_test(tv[:,0], tc[:,0], event_observed_A=tv[:,1], event_observed_B=tc[:,1])
    print(sh, 'n veh', len(tv), 'n cre', len(tc), 'events', tv[:,1].sum(), tc[:,1].sum())
    print('  median veh', np.median(tv[:,0]), 'median cre', np.median(tc[:,0]), ' times veh', sorted(tv[:,0]), ' cre', sorted(tc[:,0]))
    print('  logrank chi2=%.3f p=%.4f | reported chi2=%s p=%s' % (res.test_statistic, res.p_value, ws[rep[0]], ws[rep[1]]))
    df = pd.DataFrame({'T': np.r_[tv[:,0], tc[:,0]], 'E': np.r_[tv[:,1], tc[:,1]], 'creatine': np.r_[np.zeros(len(tv)), np.ones(len(tc))]})
    cph = CoxPHFitter().fit(df, 'T', 'E')
    s = cph.summary
    print('  Cox HR=%.2f (95%% CI %.2f-%.2f) p=%.4f' % (s.loc['creatine','exp(coef)'], s.loc['creatine','exp(coef) lower 95%'], s.loc['creatine','exp(coef) upper 95%'], s.loc['creatine','p']))
