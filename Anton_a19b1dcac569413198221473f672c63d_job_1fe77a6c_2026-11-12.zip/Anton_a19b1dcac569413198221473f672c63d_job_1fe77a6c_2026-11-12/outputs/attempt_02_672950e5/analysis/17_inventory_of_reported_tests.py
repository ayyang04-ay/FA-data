import numpy as np, pandas as pd, scipy.stats as st, json
from wb import *
rows = []
def add(panel, readout, design, result, test, p_mine, p_rep, note=''):
    match = ''
    try:
        if p_rep is not None and p_mine is not None and not isinstance(p_rep, str):
            match = 'yes' if (abs(float(p_mine)-float(p_rep)) <= max(6e-5, 0.06*float(p_rep))) else 'NO'
    except Exception: match = ''
    rows.append(dict(panel=panel, readout=readout, design=design, result=result, test=test, p_recomputed=p_mine, p_in_sheet=p_rep, reproduces=match, note=note))
tt = pd.read_csv('ttests.csv')
short = {'Supplementary Fig  ':'Supp. Fig. ', 'Fig. ':'Fig. '}
def sp(s):
    return s.replace('Supplementary Fig  ','Supp. Fig. ')
notes = {
 ('Fig. 1i','GFP+ cells/field'):'n = 8 microscope fields per group, not animals',
 ('Fig. 2c','a-granules'):'n = 8 fields per group, not animals',
 ('Fig. 2j','PKH positive area (%)'):'n = 8 fields per group, not animals',
 ('Fig. 2d','TEG-MA'):'borderline; R, K, alpha not significant',
 ('Fig. 4d','MK in vitro creatin(in)e'):'sheet label reads "Creatinine (umol/g)"',
 ('Supplementary Fig  8a','BMI 0d vs 14d'):'paired data analyzed unpaired in sheet; paired p = 0.24',
 ('Supplementary Fig  1i','Metastatic burden (%)'):'5% w/w creatine diet instead of oral dosing',
}
for _, r in tt.iterrows():
    add(sp(r.sheet), r.label, f'2 groups, n={r.nA}/{r.nB}', f'{r.meanA:.4g} -> {r.meanB:.4g} (x{r.ratio:.2f}; diff {r["diff"]:.3g}, 95% CI {r.ci_lo:.3g} to {r.ci_hi:.3g})', 'unpaired two-tailed t', r.p, r.rep_p, notes.get((r.sheet, r.label), ''))
# survival
add('Fig. 1c','Survival','n=10/10, all events','median 22 d -> 19 d; Cox HR 2.93 (1.04-8.23)','log-rank',0.0324,0.0324)
add('Fig. 1l','Survival','n=20/18, all events','median 16 d -> 14 d; Cox HR 2.28 (1.16-4.46)','log-rank',0.0110,0.011)
# helper for tukey panels
def tuk(panel, readout, sheet, groups, names, pairs, design, note=''):
    res = st.tukey_hsd(*groups)
    for (i, j, cell) in pairs:
        rep = v(sheet, cell) if cell else None
        add(panel, readout, design, f'{names[i]} {groups[i].mean():.4g} vs {names[j]} {groups[j].mean():.4g} (diff {groups[i].mean()-groups[j].mean():.3g})', 'one-way ANOVA + Tukey', res.pvalue[i,j], rep, note)
nm = ['shScr-veh','shScr-cre','shSlc6a8-veh','shSlc6a8-cre']
for lab, r0, r1, rr in [('Lung weight (g)',4,9,(4,5,6)),('SUV-BW',13,18,(13,14,15)),('Metastatic burden (%)',22,27,(22,23,24)),('Metastatic foci',31,36,(31,32,33))]:
    g = [col('Fig. 1f', c, r0, r1) for c in 'BCDE']
    tuk('Fig. 1f', lab, 'Fig. 1f', g, nm, [(0,1,f'L{rr[0]}'),(1,3,f'L{rr[1]}'),(2,3,f'L{rr[2]}')], '2x2 (tumor shRNA x creatine), n=6/group', 'tumor-cell Slc6a8 knock-down; protein knock-down looks partial on blot (Supp. Fig. 2a)')
for r, lab, pc in [(4,'ADP','B18'),(5,'Collagen','B32'),(6,'Thrombin','B45')]:
    a = row('Fig. 2b', r, 'B','D'); b = row('Fig. 2b', r, 'E','G')
    add('Fig. 2b', f'Platelet aggregation, {lab} (%)', '2 groups, n=3/3', f'{a.mean():.1f} -> {b.mean():.1f} (+{b.mean()-a.mean():.1f} points)', 'unpaired two-tailed t', st.ttest_ind(a,b).pvalue, v('Fig. 2b', pc))
for r, lab, pc in [(4,'0.25 h','B17'),(5,'6 h','E17'),(6,'12 h','H17'),(7,'24 h','K17')]:
    a = row('Fig. 1h', r, 'B','G'); b = row('Fig. 1h', r, 'H','M')
    add('Fig. 1h', f'Time course, {lab} (readout not named in sheet)', '2 groups, n=6/6', f'{a.mean():.3f} -> {b.mean():.3f} (x{b.mean()/a.mean():.2f})', 'unpaired two-tailed t per time point', st.ttest_ind(a,b).pvalue, v('Fig. 1h', pc), 'behaves like early tumor-cell retention: equal at 0.25 h, higher with creatine from 6 h')
for r, lab, pc in [(4,'Pf4-Cre;Slc6a8+/+','B17'),(5,'Pf4-Cre;Slc6a8fl/fl','B31')]:
    a = row('Fig. 3b', r, 'B','F'); b = row('Fig. 3b', r, 'G','K')
    add('Fig. 3b', f'Serum creatine (uM), {lab}', '2 groups, n=5/5', f'{a.mean():.1f} -> {b.mean():.1f} (x{b.mean()/a.mean():.2f})', 'unpaired two-tailed t', st.ttest_ind(a,b).pvalue, v('Fig. 3b', pc))
for r, lab, pc in [(4,'Pf4-Cre;Slc6a8+/+','B15'),(5,'Pf4-Cre;Slc6a8fl/fl','B30')]:
    a = row('Fig. 3c', r, 'B','D'); b = row('Fig. 3c', r, 'E','G')
    add('Fig. 3c', f'MK intracellular creatine, {lab}', '2 groups, n=3/3', f'{a.mean():.1f} -> {b.mean():.1f} (x{b.mean()/a.mean():.2f})', 'unpaired two-tailed t', st.ttest_ind(a,b).pvalue, v('Fig. 3c', pc), 'genotype x creatine interaction p = 0.045 (my two-way ANOVA)')
nm = ['WT-veh','WT-cre','cKO-veh','cKO-cre']
for lab, r, rr in [('ADP',4,('T4','T5')),('Collagen',5,('T10','T11')),('Thrombin',6,('T15','T16'))]:
    g = [row('Fig. 3d', r, a, b) for a,b in [('B','D'),('E','G'),('H','J'),('K','M')]]
    tuk('Fig. 3d', f'Platelet aggregation, {lab} (%)', 'Fig. 3d', g, nm, [(0,1,rr[0]),(2,3,rr[1]),(0,2,None)], '2x2 (MK Slc6a8 x creatine), n=3/group', 'creatine LOWERS aggregation in cKO; cKO-vehicle below control-vehicle')
for lab, r0, r1, rr in [('Lung weight (g)',3,6,(3,4,5)),('Metastatic burden (%)',10,13,(10,11,12)),('Metastatic foci',17,20,(17,18,19))]:
    g = [col('Fig. 3i', c, r0, r1) for c in 'BCDE']
    tuk('Fig. 3i', lab, 'Fig. 3i', g, nm, [(0,1,f'L{rr[0]}'),(1,3,f'L{rr[1]}'),(2,3,f'L{rr[2]}'),(0,2,None)], '2x2 (MK Slc6a8 x creatine), n=4/group', 'only lineage-specific genetic test on the metastasis endpoint in the package')
for sh in ['Fig. 5e','Fig. 5f']:
    g = [col(sh, c, 4, 6) for c in 'NOPQ']; g2 = [col(sh, c, 17, 19) for c in 'NOPQ']
    nmv = ['veh-WT','veh-S127A','veh-3A','veh-S127D']; nmc = ['cre-WT','cre-S127A','cre-3A','cre-S127D']
    pc = 'R' if sh=='Fig. 5e' else 'Q'; ra = (10,11,12,13) if sh=='Fig. 5e' else (9,10,11,12)
    tuk(sh, 'pan-phospho / FLAG-STAT5B (densitometry)', sh, g, nmv, [(0,2,f'{pc}{ra[0]}'),(0,3,f'{pc}{ra[1]}'),(1,3,f'{pc}{ra[2]}'),(2,3,f'{pc}{ra[3]}'),(0,1,None)], '4 constructs, vehicle; n=3 blots', 'host cell not named in package; separate ANOVA per treatment')
    tuk(sh, 'pan-phospho / FLAG-STAT5B (densitometry)', sh, g2, nmc, [(0,1,f'{pc}22'),(0,3,f'{pc}23'),(1,2,f'{pc}24')], '4 constructs, creatine; n=3 blots', 'creatine raises WT signal x%.2f (t-test p=%.3f); S127A x%.2f' % (g2[0].mean()/g[0].mean(), st.ttest_ind(g[0], g2[0]).pvalue, g2[1].mean()/g[1].mean()))
nm = ['veh','cre','veh+STAT5i','cre+STAT5i']
for lab, r0, r1, rr in [('Metastatic burden (%)',4,8,(4,5,6,7)),('Metastatic foci',13,17,(13,14,15,16))]:
    g = [col('Fig. 6b', c, r0, r1) for c in 'BCDE']
    tuk('Fig. 6b', lab, 'Fig. 6b', g, nm, [(0,1,f'L{rr[0]}'),(0,2,f'L{rr[1]}'),(1,3,f'L{rr[2]}'),(2,3,f'L{rr[3]}')], '2x2 (STAT5-IN-1 x creatine), n=5/group', 'systemic STAT5A/B inhibitor; 3 of 5 vehicle and 3 of 5 creatine records identical to Supp. Fig. 2d')
g = [col('Fig. 6e', c, 5, 7) for c in 'CDE']
tuk('Fig. 6e', 'MK intracellular creatine (umol/g)', 'Fig. 6e', g, ['WT-veh','WT-cre','Stat5b cKO-cre'], [(0,1,'L5'),(0,2,'L6'),(1,2,'L7')], '3 groups, n=3', 'no cKO-vehicle group; control is "WT" (no Cre-only control)')
nm = ['veh-donor PLT','cre-donor PLT','cre+aspirin-donor PLT']
for lab, r0, r1, rr in [('Metastatic burden (%)',5,10,(5,6,7)),('Metastatic foci',14,19,(14,15,16))]:
    g = [col('Supplementary Fig  2d', c, r0, r1) for c in 'CDE']
    tuk('Supp. Fig. 2d', lab, 'Supplementary Fig  2d', g, nm, [(0,1,f'L{rr[0]}'),(0,2,f'L{rr[1]}'),(1,2,f'L{rr[2]}')], '3 groups of recipients, n=6', 'rows 4-6 of vehicle- and creatine-donor groups identical to Fig. 6b records')
nm = ['WT-veh','WT-cre','cKO-veh','cKO-cre']
g = [col('Supplementary Fig  4b', c, 5, 7) for c in 'CDEF']
tuk('Supp. Fig. 4b', 'Platelet count (x10^9/L)', 'Supplementary Fig  4b', g, nm, [(0,1,'M5'),(0,2,'M6'),(1,3,'M7'),(2,3,'M8')], '2x2, n=3/group')
g = [col('Supplementary Fig  4c', c, 6, 13) for c in 'CDEF']
tuk('Supp. Fig. 4c', 'alpha-granules per field', 'Supplementary Fig  4c', g, nm, [(0,1,'N7'),(1,3,'N8'),(2,3,'N9')], '2x2, n=8 fields/group', 'fields, not animals')
nm = ['veh','cre','veh+STAT5i','cre+STAT5i']
for lab, r0, r1, rr in [('PLT',4,6,(4,5,6)),('PCT',11,13,(11,12,13)),('MPV',17,19,(17,18,19)),('PDW',23,25,(23,24,25))]:
    g = [col('Supplementary Fig  7a', c, r0, r1) for c in 'BCDE']
    tuk('Supp. Fig. 7a', lab, 'Supplementary Fig  7a', g, nm, [(0,1,f'L{rr[0]}'),(0,2,f'L{rr[1]}'),(0,3,f'L{rr[2]}')], '4 groups, n=3')
nm = ['WT-veh','WT-cre','Stat5b cKO-cre']
for lab, r0, r1, rr in [('PLT',4,6,(4,5,6)),('PCT',10,12,(10,11,12)),('MPV',16,18,(16,17,18)),('PDW',22,24,(22,23,24))]:
    g = [col('Supplementary Fig  7b', c, r0, r1) for c in 'BCD']
    tuk('Supp. Fig. 7b', lab, 'Supplementary Fig  7b', g, nm, [(0,1,f'K{rr[0]}'),(0,2,f'K{rr[1]}'),(1,2,f'K{rr[2]}')], '3 groups, n=3', 'no cKO-vehicle group')
# human
M = np.array([row('Fig. 7b', r, 'B', 'E') for r in range(4, 15)])
res = st.tukey_hsd(*[M[:,j] for j in range(4)])
for j, d, c in [(1,3,'L5'),(2,7,'L6'),(3,14,'L7')]:
    add('Fig. 7b', f'Human serum creatine, day 0 vs {d}', 'n=11 volunteers, repeated measures', f'{M[:,0].mean():.1f} -> {M[:,j].mean():.1f} uM (x{M[:,j].mean()/M[:,0].mean():.2f}); paired t p={st.ttest_rel(M[:,j],M[:,0]).pvalue:.1e}', 'Tukey (unpaired) as in sheet', res.pvalue[0,j], v('Fig. 7b', c), 'paired design analyzed as independent groups in sheet')
H = np.load('human_agg.npy', allow_pickle=True).item()
repcells = {('collagen','max'):('L4','L5','L6'),('collagen','avg'):('L18','L19','L20'),('collagen','adhesion'):('L32','L33','L34'),('EPI','max'):('L47','L48','L49'),('EPI','avg'):('L61','L62','L63'),('EPI','adhesion'):('L75','L76','L77'),('AA','max'):('L88','L89','L90'),('AA','avg'):('L103','L104','L105'),('AA','adhesion'):('L117','L118','L119'),('ADP','max'):('L131','L132','L133'),('ADP','avg'):('L145','L146','L147'),('ADP','adhesion'):('L159','L160','L161')}
hs = pd.read_csv('human_agg_stats.csv')
for (ag, m), arr in H.items():
    r = st.dunnett(arr[:,1], arr[:,2], arr[:,3], control=arr[:,0])
    for j, d in enumerate([3,7,14]):
        h = hs[(hs.agonist==ag)&(hs.metric==m)&(hs.day==d)].iloc[0]
        rep = v('Fig. 7c', repcells[(ag,m)][j])
        add('Fig. 7c', f'Human platelet {m} ({ag}), day {d} fold of day 0', 'n=11 volunteers', f'median x{h["median"]:.2f}; {int(h.n_up)}/11 up; Wilcoxon signed-rank p={h.p_wilcoxon:.4f}', 'Dunnett on fold changes as in sheet', r.pvalue[j], rep if not isinstance(rep,str) else None, 'baseline column is all 1.0 (zero variance); my paired test given in result column')
for lab, r0, cells_ in [('GP6/b-actin',4,('L4','L5','L6')),('P2RY12/b-actin',12,('L12','L13','L14'))]:
    Mx = np.array([row('Fig. 7e', r, 'B', 'E') for r in range(r0, r0+4)]); res = st.tukey_hsd(*[Mx[:,j] for j in range(4)])
    for j, d in enumerate([3,7,14], start=1):
        fc = Mx[:,j]/Mx[:,0]
        add('Fig. 7e', f'Human platelet {lab}, day 0 vs {d}', 'n=4 volunteers', f'fold per volunteer {np.round(fc,2).tolist()}; paired t p={st.ttest_rel(Mx[:,j],Mx[:,0]).pvalue:.3f}', 'Tukey (unpaired) as in sheet', res.pvalue[0,j], v('Fig. 7e', cells_[j-1]), 'immunoblot densitometry')
for lab, r0 in [('PLT',4),('PCT',19),('MPV',33),('PDW',48)]:
    Mx = np.array([row('Supplementary Fig  8b', r, 'B', 'E') for r in range(r0, r0+11)])
    add('Supp. Fig. 8b', f'Human {lab}', 'n=11 volunteers', f'means {np.round(Mx.mean(0),2).tolist()} at d0/3/7/14', 'paired t d0 vs d14 (mine)', st.ttest_rel(Mx[:,3], Mx[:,0]).pvalue, None, 'sheet reports Dunnett, all n.s.')
# ChIP
import statsmodels.formula.api as smf
def chip(panel, sheet, rows_, vc, cc, gene, repcells_):
    recs = []
    labs = ['Exon','2K','1K','0.2K']
    for r, lab in zip(rows_, labs):
        for x in row(sheet, r, *vc): recs.append(dict(region=lab, trt='veh', y=x))
        for x in row(sheet, r, *cc): recs.append(dict(region=lab, trt='cre', y=x))
    df = pd.DataFrame(recs); m = smf.ols('y ~ C(region)*C(trt)', df).fit(); mse = m.mse_resid; dfr = m.df_resid
    for lab, rc in zip(labs, repcells_):
        a = df[(df.region==lab)&(df.trt=='veh')].y.values; b = df[(df.region==lab)&(df.trt=='cre')].y.values
        t = (a.mean()-b.mean())/np.sqrt(mse*(1/len(a)+1/len(b))); p = 2*st.t.sf(abs(t), dfr); padj = 1-(1-p)**4
        add(panel, f'ChIP-qPCR % input, {gene} {lab}', 'n=3/3', f'{a.mean():.2f} -> {b.mean():.2f} (x{b.mean()/a.mean():.2f})', 'two-way ANOVA + Sidak', padj, v(sheet, rc), 'ChIP antibody not named in package')
chip('Fig. 5j', 'Fig. 5j', [5,6,7,8], ('B','D'), ('E','G'), 'P2ry12', ['N7','N8','N9','N10'])
chip('Fig. 5j', 'Fig. 5j', [15,16,17,18], ('B','D'), ('E','G'), 'Gp6', ['N17','N18','N19','N20'])
chip('Supp. Fig. 6i', 'Supplementary Fig  6i', [7,8,9,10], ('C','E'), ('F','H'), 'Rab4a', ['O10','O11','O12','O13'])
a = row('Fig. 4e', 8, 'E','G'); b = row('Fig. 4e', 8, 'I','K'); add('Fig. 4e','Ckb mRNA in MKs','n=3/3', f'x{b.mean()/a.mean():.2f}', 'unpaired two-tailed t', st.ttest_ind(a,b).pvalue, v('Fig. 4e','O5'))
a = row('Supplementary Fig  2a', 7, 'D','F'); b = row('Supplementary Fig  2a', 7, 'H','J'); add('Supp. Fig. 2a','Slc6a8 mRNA after knock-down','n=3/3', f'{100*b.mean()/a.mean():.0f}% of control remaining', 'unpaired two-tailed t', st.ttest_ind(a,b).pvalue, v('Supplementary Fig  2a','M4'), 'sheet header says si-Slc6a8; blot image says sh-Slc6a8 and shows only a modest protein reduction')
for gene, r, c in [('Gatm',6,'N10'),('Gamt',9,'N24')]:
    a = row('Supplementary Fig  5a', r, 'C','E'); b = row('Supplementary Fig  5a', r, 'G','I'); add('Supp. Fig. 5a', f'{gene} mRNA in MKs','n=3/3', f'x{b.mean()/a.mean():.2f}', 'unpaired two-tailed t', st.ttest_ind(a,b).pvalue, v('Supplementary Fig  5a', c))
for r, lab, pc in [(4,'day 0','M11'),(5,'day 7','M25')]:
    a = row('Supplementary Fig  1a', r, 'B','E'); b = row('Supplementary Fig  1a', r, 'F','I'); add('Supp. Fig. 1a', f'Body weight (g), {lab}', 'n=4/4', f'{a.mean():.2f} vs {b.mean():.2f}', 'unpaired two-tailed t', st.ttest_ind(a,b).pvalue, v('Supplementary Fig  1a', pc))
inv = pd.DataFrame(rows)
inv.to_csv('../tables/evidence_inventory_recomputed_statistics.csv', index=False)
print(len(inv), 'rows;', (inv.reproduces=='yes').sum(), 'reproduce;', (inv.reproduces=='NO').sum(), 'do not;', (inv.reproduces=='').sum(), 'no reported p to compare')
print(inv[inv.reproduces=='NO'].to_string())

# ---- additional coverage: Supp 3a (t-tests), Supp 8b (Dunnett), Supp 8c (Tukey), Fig 7c string-valued
extra = []
for lab, r0, pc in [('WBC',4,'F4'),('Lymphocytes',12,'F12'),('Monocytes',20,'F20'),('RBC',28,'F28')]:
    a = col('Supplementary Fig  3a','B',r0,r0+4); b = col('Supplementary Fig  3a','C',r0,r0+4)
    add('Supp. Fig. 3a', lab, '2 groups, n=5/5', f'{a.mean():.3g} -> {b.mean():.3g}', 'unpaired two-tailed t', st.ttest_ind(a,b).pvalue, v('Supplementary Fig  3a', pc))
for lab, r0, cells_ in [('PLT',4,('L4','L5','L6')),('PCT',19,('L19','L20','L21')),('MPV',33,('L33','L34','L35')),('PDW',48,('L48','L49','L50'))]:
    Mx = np.array([row('Supplementary Fig  8b', r, 'B', 'E') for r in range(r0, r0+11)])
    r_ = st.dunnett(Mx[:,1], Mx[:,2], Mx[:,3], control=Mx[:,0])
    for j, d in enumerate([3,7,14]):
        rep = v('Supplementary Fig  8b', cells_[j])
        add('Supp. Fig. 8b', f'Human {lab}, day 0 vs {d} (Dunnett as in sheet)', 'n=11 volunteers', f'means {Mx[:,0].mean():.3g} vs {Mx[:,j+1].mean():.3g}', 'Dunnett (unpaired) as in sheet', r_.pvalue[j], rep if not isinstance(rep, str) else None, f'sheet reports {rep}' if isinstance(rep, str) else '')
a = row('Supplementary Fig  8c', 9, 'E','G'); b = row('Supplementary Fig  8c', 9, 'I','K'); c = row('Supplementary Fig  8c', 9, 'M','O')
res = st.tukey_hsd(a, b, c)
add('Supp. Fig. 8c', 'ITGA2B mRNA, CD41+ cells vs monocytes', 'n=3 each', f'{a.mean():.2f} vs {b.mean():.3f}', 'one-way ANOVA + Tukey', res.pvalue[0,1], None, 'sheet reports <0.0001')
inv = pd.DataFrame(rows)
inv.to_csv('../tables/evidence_inventory_recomputed_statistics.csv', index=False)
num = inv[inv.p_in_sheet.notna()]
print(len(inv), 'rows;', (inv.reproduces=='yes').sum(), 'reproduce;', (inv.reproduces=='NO').sum(), 'do not;', len(num), 'numeric reported p-values compared')
print(inv[inv.note.astype(str).str.contains('sheet reports')][['panel','readout','p_recomputed','note']].to_string())
h = inv[(inv.panel=='Fig. 7c') & inv.p_in_sheet.isna()]
print(h[['readout','p_recomputed']].to_string())
