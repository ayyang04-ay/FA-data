import numpy as np, pandas as pd, scipy.stats as st
import statsmodels.formula.api as smf, statsmodels.api as sm
from wb import *
import warnings; warnings.filterwarnings('ignore')

def twoway(g, title, f1='factor', f2='creatine'):
    # g: dict {(f1level, creatine 0/1): array}
    rows = []
    for (a,b), arr in g.items():
        for x in arr: rows.append(dict(A=a, B=b, y=x))
    df = pd.DataFrame(rows)
    m = smf.ols('y ~ C(A)*C(B)', df).fit()
    an = sm.stats.anova_lm(m, typ=2)
    # interaction contrast: (A1B1 - A1B0) - (A0B1 - A0B0)
    means = df.groupby(['A','B']).y.mean()
    A = sorted(df.A.unique()); 
    d0 = means[(A[0],1)]-means[(A[0],0)]; d1 = means[(A[1],1)]-means[(A[1],0)]
    mse = m.mse_resid; dfres = m.df_resid
    ns = df.groupby(['A','B']).y.count()
    se = np.sqrt(mse*(1/ns).sum())
    tcrit = st.t.ppf(0.975, dfres)
    inter = d1-d0
    print(f'{title}: creatine effect in {A[0]} = {d0:.4g}; in {A[1]} = {d1:.4g}; interaction = {inter:.4g} (95% CI {inter-tcrit*se:.4g} to {inter+tcrit*se:.4g}); p_int = {an.loc["C(A):C(B)","PR(>F)"]:.3g}; % of WT creatine effect remaining = {100*d1/d0:.0f}%')
    return an

# Fig 1f: A = tumor shRNA (0 scr, 1 shSlc6a8)
for lab, r0, r1 in [('Lung weight',4,9),('SUV-BW',13,18),('Metastatic burden',22,27),('Foci',31,36)]:
    g = {('0-shScr',0): col('Fig. 1f','B',r0,r1), ('0-shScr',1): col('Fig. 1f','C',r0,r1), ('1-shSlc6a8',0): col('Fig. 1f','D',r0,r1), ('1-shSlc6a8',1): col('Fig. 1f','E',r0,r1)}
    twoway(g, f'Fig 1f {lab}')
# Fig 3i
for lab, r0, r1 in [('Lung weight',3,6),('Metastatic burden',10,13),('Foci',17,20)]:
    g = {('0-WT',0): col('Fig. 3i','B',r0,r1), ('0-WT',1): col('Fig. 3i','C',r0,r1), ('1-cKO',0): col('Fig. 3i','D',r0,r1), ('1-cKO',1): col('Fig. 3i','E',r0,r1)}
    twoway(g, f'Fig 3i {lab}')
# Fig 3c MK creatine
g = {('0-WT',0): row('Fig. 3c',4,'B','D'), ('0-WT',1): row('Fig. 3c',4,'E','G'), ('1-cKO',0): row('Fig. 3c',5,'B','D'), ('1-cKO',1): row('Fig. 3c',5,'E','G')}
twoway(g, 'Fig 3c MK creatine')
for k,v_ in g.items(): print('   ', k, v_.round(1), 'mean', v_.mean().round(1))
# Fig 3b serum creatine
g = {('0-WT',0): row('Fig. 3b',4,'B','F'), ('0-WT',1): row('Fig. 3b',4,'G','K'), ('1-cKO',0): row('Fig. 3b',5,'B','F'), ('1-cKO',1): row('Fig. 3b',5,'G','K')}
twoway(g, 'Fig 3b serum creatine')
for k,v_ in g.items(): print('   ', k, v_.round(1), 'mean', v_.mean().round(1))
# Fig 3d
for lab, r in [('ADP',4),('Collagen',5),('Thrombin',6)]:
    g = {('0-WT',0): row('Fig. 3d',r,'B','D'), ('0-WT',1): row('Fig. 3d',r,'E','G'), ('1-cKO',0): row('Fig. 3d',r,'H','J'), ('1-cKO',1): row('Fig. 3d',r,'K','M')}
    twoway(g, f'Fig 3d {lab}')
# Fig 6b
for lab, r0, r1 in [('Metastatic burden',4,8),('Foci',13,17)]:
    g = {('0-noInh',0): col('Fig. 6b','B',r0,r1), ('0-noInh',1): col('Fig. 6b','C',r0,r1), ('1-STAT5i',0): col('Fig. 6b','D',r0,r1), ('1-STAT5i',1): col('Fig. 6b','E',r0,r1)}
    twoway(g, f'Fig 6b {lab}')
# Supp 4c a-granules
g = {('0-WT',0): col('Supplementary Fig  4c','C',6,13), ('0-WT',1): col('Supplementary Fig  4c','D',6,13), ('1-cKO',0): col('Supplementary Fig  4c','E',6,13), ('1-cKO',1): col('Supplementary Fig  4c','F',6,13)}
twoway(g, 'Supp 4c a-granules (fields, not animals)')

# Fig 6b sensitivity: drop the 3 animals/group whose values duplicate Supp Fig 2d
print('\nSensitivity: Fig 6b without the values duplicated in Supp Fig 2d')
B = col('Fig. 6b','B',4,8); Cc = col('Fig. 6b','C',4,8); D = col('Fig. 6b','D',4,8); E = col('Fig. 6b','E',4,8)
B2 = B[[0,4]]; C2 = Cc[[0,4]]
print('  Veh', B2, 'Cre', C2, 'Cre+STAT5i', E)
print('  Cre vs Cre+STAT5i t-test p =', st.ttest_ind(C2, E).pvalue, ' Welch p =', st.ttest_ind(C2,E,equal_var=False).pvalue)
print('  Veh vs Cre t-test p =', st.ttest_ind(B2, C2).pvalue)
S_v = col('Supplementary Fig  2d','C',5,10); S_c = col('Supplementary Fig  2d','D',5,10); S_a = col('Supplementary Fig  2d','E',5,10)
print('Supp 2d without the duplicated values: Veh donor', S_v[:3], 'Cre donor', S_c[:3], 'Cre+asp donor', S_a)
print('  Veh vs Cre donor t p =', st.ttest_ind(S_v[:3], S_c[:3]).pvalue, '; Cre donor vs Cre+aspirin donor t p =', st.ttest_ind(S_c[:3], S_a).pvalue)
print('  Note: within Supp 2d the duplicated rows (4-6) have lower values than rows 1-3: Veh', S_v[:3].mean().round(2), 'vs', S_v[3:].mean().round(2), '; Cre', S_c[:3].mean().round(2), 'vs', S_c[3:].mean().round(2), '; Cre+asp', S_a[:3].mean().round(2), 'vs', S_a[3:].mean().round(2))
