import json, numpy as np, pandas as pd, scipy.stats as st, re
from openpyxl.utils import column_index_from_string as ci, get_column_letter as cl
C = json.load(open('cells.json'))

def parse_qpcr(sheet, header_row, groups, label_col='F', gene_col='A', first_val_col='G', norm_col='C'):
    """groups: list of group names in order: control, then treated groups (each block of 3 columns + 1 label col)"""
    d = C[sheet]
    rows = sorted(set(int(re.sub(r'[A-Z]+','',k)) for k in d))
    out = []
    for r in rows:
        g = d.get(f'{gene_col}{r}')
        lab = d.get(f'{label_col}{r}')
        if isinstance(g, str) and lab == 'ΔCT1':
            gene = g.strip()
            fc = ci(first_val_col)
            ctrl = [d.get(f'{cl(fc+i)}{r}') for i in range(3)]
            # control normalized (reported)
            nc = ci(norm_col)
            ctrl_norm_rep = [d.get(f'{cl(nc+i)}{r+3}') for i in range(3)]
            for k, grp in enumerate(groups[1:]):
                base = fc + 4*k
                lab2 = d.get(f'{cl(base-1)}{r+1}')
                dct = [d.get(f'{cl(base+i)}{r+1}') for i in range(3)]
                ctrl_k = [d.get(f'{cl(base+i)}{r}') for i in range(3)]
                fold_rep = [d.get(f'{cl(base+i)}{r+3}') for i in range(3)]
                out.append(dict(sheet=sheet, gene=gene, group=grp, label=lab2, ctrl_dct=ctrl, ctrl_dct_block=ctrl_k, dct=dct, fold_rep=fold_rep, ctrl_norm_rep=ctrl_norm_rep, ctrl_group=groups[0]))
    return out

specs = {
 'Fig. 2f': dict(header_row=3, groups=['Vehicle','Creatine']),
 'Fig. 3f': dict(header_row=7, groups=['WT-Veh','WT-Cre','cKO-Veh','cKO-Cre']),
 'Fig. 4h': dict(header_row=6, groups=['Control','Creatine','Phosphocreatine']),
 'Fig. 4j': dict(header_row=7, groups=['Ctrl+si-scr','Ctrl+si-Ckb','Cre+si-scr','Cre+si-Ckb']),
 'Fig. 4l': dict(header_row=5, groups=['CKB-EV','CKB-OE']),
 'Fig.6a': dict(header_row=6, groups=['Vehicle','Creatine','Veh+STAT5i','Cre+STAT5i']),
 'Fig. 6g': dict(header_row=4, groups=['WT-Veh','WT-Cre','Stat5b cKO-Cre']),
 'Supplementary Fig  3c': dict(header_row=4, groups=['Vehicle','Creatine']),
 'Supplementary Fig  4e': dict(header_row=7, groups=['Control','Creatine','Creatine@liposome']),
}
recs = []
for sh, sp in specs.items():
    recs += parse_qpcr(sh, **sp)
rows = []
for r in recs:
    ctrl = np.array(r['ctrl_dct'], float); trt = np.array(r['dct'], float)
    # reported style: paired by index
    fold_paired = 2**(trt-ctrl)
    rep = np.array([x if x is not None else np.nan for x in r['fold_rep']], float)
    # standard: relative to control mean of 2^dCT
    cn = 2**ctrl; cn_norm = cn/cn.mean()
    fold_std = 2**trt/cn.mean()
    # stats on dCT scale (log2): Welch/Student t-test treated vs control
    t, p = st.ttest_ind(trt, ctrl)
    rows.append(dict(sheet=r['sheet'], gene=r['gene'], group=r['group'], ctrl=r['ctrl_group'], label=r['label'],
                     log2fc=float((trt.mean()-ctrl.mean())), fold_geo=float(2**(trt.mean()-ctrl.mean())), fold_rep_mean=float(np.nanmean(rep)), fold_paired_mean=float(fold_paired.mean()),
                     max_abs_dev_rep=float(np.nanmax(np.abs(rep-fold_paired))), p_dct=float(p), ctrl_block_same=bool(np.allclose(np.array(r['ctrl_dct_block'],float), ctrl)),
                     rep_vals=rep.round(3).tolist(), ctrl_norm=np.array(r['ctrl_norm_rep'],float).round(3).tolist(), dct_ctrl=ctrl.round(3).tolist(), dct_trt=trt.round(3).tolist()))
df = pd.DataFrame(rows)
df.to_csv('qpcr.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_columns', 30)
print('max deviation between reported fold and recomputed 2^(dCT_trt - dCT_ctrl):')
print(df.groupby('sheet').max_abs_dev_rep.max())
print('ctrl block identical across groups:', df.ctrl_block_same.all())
bad = df[df.max_abs_dev_rep>1e-6]
print(bad[['sheet','gene','group','fold_rep_mean','fold_paired_mean','max_abs_dev_rep','rep_vals','dct_ctrl','dct_trt']].to_string())
for sh in specs:
    sub = df[df.sheet==sh]
    piv = sub.pivot(index='gene', columns='group', values='fold_geo')
    pivp = sub.pivot(index='gene', columns='group', values='p_dct')
    order = [g for g in specs[sh]['groups'][1:]]
    genes = list(dict.fromkeys(sub.gene))
    print(f'\n=== {sh}: geometric-mean fold vs {specs[sh]["groups"][0]} (p from t-test on dCT, n=3 v 3)')
    t = pd.DataFrame({f'{g} fold': piv[g] for g in order} | {f'{g} p': pivp[g] for g in order}).loc[genes]
    print(t.round(4).to_string())
