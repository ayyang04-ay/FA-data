import pandas as pd, numpy as np, scipy.stats as st
from statsmodels.stats.multitest import multipletests
df = pd.read_csv('phospho.csv'); df.columns = ['gene','p','q','lfc']
m = len(df)
df['bh'] = multipletests(df.p, method='fdr_bh')[1]
df['fc'] = 2**df.lfc
print('rows', m, 'genes', df.gene.nunique(), 'missing gene names', df.gene.isna().sum())
print('min BH-adjusted p:', df.bh.min(), ' | reported min q:', df.q.min())
print('ratio q/BH for top 10:', (df.sort_values("p").q/df.sort_values("p").bh).head(10).round(3).tolist())
# Is reported q monotone in p?
s = df.sort_values('p')
print('q monotone non-decreasing in p:', bool((np.diff(s.q.values) >= -1e-12).all()))
deg = np.isclose(df.p, 0.42265, atol=2e-5)
print('degenerate p=0.42265 rows:', deg.sum(), f'({100*deg.mean():.1f}%)', ' |lfc| of these: median %.2f, min %.2f, max %.2f' % (df[deg].lfc.abs().median(), df[deg].lfc.abs().min(), df[deg].lfc.abs().max()))
print('  t for p=0.42265 with df=2: ', st.t.isf(0.42265/2, 2), ' df=4:', st.t.isf(0.42265/2, 4))
nd = df[~deg]
print('non-degenerate rows:', len(nd), ' p<0.05:', (nd.p<0.05).sum(), ' expected under global null:', 0.05*len(nd), ' ratio: %.2f' % ((nd.p<0.05).sum()/(0.05*len(nd))))
print('all rows: p<0.05:', (df.p<0.05).sum(), 'expected', 0.05*m)
# KS test vs uniform for non-degenerate p
print('KS vs uniform (non-degenerate):', st.kstest(nd.p, 'uniform'))
# pi0 estimate (Storey lambda=0.5) on non-degenerate
for lam in [0.5, 0.6, 0.7, 0.8, 0.9]:
    print(f'  Storey pi0 (lambda={lam}) non-degenerate: {(nd.p>lam).mean()/(1-lam):.2f}; all rows: {(df.p>lam).mean()/(1-lam):.2f}')
crit = (df.p<0.05) & ((df.fc>=1.2)|(df.fc<=0.83))
print('pass screening rule:', crit.sum(), 'peptides in', df[crit].gene.nunique(), 'genes; up', (crit&(df.lfc>0)).sum(), 'down', (crit&(df.lfc<0)).sum())
print('  expected false positives if all null ~', 0.05*len(nd), '(rule passes', crit.sum(), ')')
s = df.sort_values('p').reset_index(drop=True); s['rank'] = s.index+1
st5 = s[s.gene.isin(['Stat5b','Stat5a'])]
print(st5.to_string())
# large |lfc| "on/off" class
big = df[df.lfc.abs()>=4]
print('|log2FC|>=4 rows:', len(big), ' of which p<0.05:', (big.p<0.05).sum(), ' up:', ((big.p<0.05)&(big.lfc>0)).sum(), ' down:', ((big.p<0.05)&(big.lfc<0)).sum())
# Among hits passing rule with lfc>0: list
hits = df[crit].sort_values('p')
print('\nTop 40 rule-passing hits:'); print(hits.head(40).round(4).to_string())
# transcription regulators among hits (crude name list)
tf_like = ['Stat5b','Nfkb2','Mef2a','Ncoa3','Arid1a','Foxk2','Arid3a','Runx1','Gata1','Fli1','Nfe2','Mecom','Zfpm1','Tal1','Erg','Ets','Irf','Srf','Creb1','Atf','Jun','Fos','Myc','Max','Sp1','Klf','Nr','Rel','Tcf','Lef','Smad','Foxo','Foxp','Tp53','Trp53','E2f','Rb1','Ep300','Crebbp','Brd4','Med1','Ncor','Hdac','Kdm','Kmt','Ezh','Dnmt','Tet','Bcl6','Ikzf','Spi1','Cebp','Hif1a','Nfat','Nfe2l','Yy1','Ctcf','Zeb','Snai','Twist','Tead','Yap1','Wwtr1']
tfh = hits[hits.gene.str.contains('|'.join(f'^{x}' for x in tf_like), regex=True, na=False)]
print('\nTF/chromatin-like genes among rule-passing hits:'); print(tfh.round(4).to_string())
# kinases among hits
kin = hits[hits.gene.str.contains(r'^(Cdk|Mapk|Map2k|Map3k|Map4k|Prk|Akt|Pik3|Src|Lyn|Fyn|Syk|Btk|Jak|Tyk|Csnk|Gsk3|Camk|Pak|Rock|Aak1|Stk|Nek|Plk|Aurk|Ttk|Wnk|Lrrk|Ripk|Irak|Tbk|Ikbk|Mtor|Atm|Atr|Prkd|Pkn|Rps6k|Sgk|Dyrk|Clk|Srpk|Hipk|Ulk|Tnk|Abl|Ptk|Tec|Itk|Zap70|Lck|Fgr|Hck|Csk|Tnik|Mink|Ck[a-z]|Nadk|Eno)', regex=True, na=False)]
print('\nkinase-like among hits:'); print(kin.round(4).to_string())
