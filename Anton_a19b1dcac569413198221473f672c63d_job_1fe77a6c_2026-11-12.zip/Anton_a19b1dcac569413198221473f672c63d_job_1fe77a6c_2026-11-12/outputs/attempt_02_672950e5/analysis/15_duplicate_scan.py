import json, re, collections
C = json.load(open('cells.json'))
qpcr = {'Fig. 2f','Fig. 3f','Fig. 4h','Fig. 4j','Fig. 4l','Fig.6a','Fig. 6g','Fig. 7d','Supplementary Fig  3c','Supplementary Fig  4e','Supplementary Fig  5a','Supplementary Fig  2a','Fig. 4e','Supplementary Fig  8c'}
idx = collections.defaultdict(list)
for sh, d in C.items():
    if sh in qpcr: continue
    for cell, val in d.items():
        if isinstance(val, (int,float)) and not isinstance(val, bool):
            s = repr(float(val))
            digits = len(re.sub(r'[^0-9]','', s.split('e')[0]).strip('0'))
            if digits >= 4:
                idx[round(float(val), 10)].append((sh, cell))
cross = {k:v for k,v in idx.items() if len(set(s for s,_ in v))>1}
print('values (>=4 sig digits) occurring in more than one non-qPCR sheet:', len(cross))
for k,v in sorted(cross.items(), key=lambda x: str(x[1])):
    print('    ', k, v)
print('\nWITHIN-SHEET duplicates (>=5 sig digits), non-qPCR')
for sh, d in C.items():
    if sh in qpcr: continue
    loc = collections.defaultdict(list)
    for cell, val in d.items():
        if isinstance(val, (int,float)) and not isinstance(val,bool):
            s = repr(float(val))
            digits = len(re.sub(r'[^0-9]','', s.split('e')[0]).strip('0'))
            if digits >= 5:
                loc[round(float(val),10)].append(cell)
    dd = {k:v for k,v in loc.items() if len(v)>1}
    if dd:
        print(sh, len(dd), list(dd.items())[:20])
