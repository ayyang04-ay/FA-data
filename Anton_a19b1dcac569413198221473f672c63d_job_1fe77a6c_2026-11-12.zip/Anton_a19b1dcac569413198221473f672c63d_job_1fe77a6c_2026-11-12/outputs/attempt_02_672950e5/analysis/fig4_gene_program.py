import json, numpy as np, pandas as pd, re
from figstyle import *
from matplotlib.colors import TwoSlopeNorm
from openpyxl.utils import column_index_from_string as ci, get_column_letter as cl
C = json.load(open('cells.json'))
def grab(sheet, groups, label_col='F', first_val_col='G'):
    d = C[sheet]; rows = sorted(set(int(re.sub(r'[A-Z]+','',k)) for k in d)); out = {}
    for r in rows:
        g = d.get(f'A{r}'); lab = d.get(f'{label_col}{r}')
        if isinstance(g, str) and lab == 'ΔCT1':
            fc = ci(first_val_col); res = {groups[0]: np.array([d.get(f'{cl(fc+i)}{r}') for i in range(3)], float)}
            for k, grp in enumerate(groups[1:]):
                base = fc + 4*k
                res[grp] = np.array([d.get(f'{cl(base+i)}{r+1}') for i in range(3)], float)
            out[g.strip()] = res
    return out
genes = ['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
blocks = [
 ('Fig. 2f\nMKs from treated mice', 'Fig. 2f', ['c','a'], [('a','creatine')]),
 ('Fig. 3f\nSlc6a8 cKO mice', 'Fig. 3f', ['c','a','b','d'], [('a','Cre control + creatine'),('b','Slc6a8 cKO, vehicle'),('d','Slc6a8 cKO + creatine')]),
 ('Supp. Fig. 4e\nSlc6a8-cKO MKs in culture', 'Supplementary Fig  4e', ['c','a','b'], [('a','free creatine'),('b','liposomal creatine')]),
 ('Fig. 4j\ncultured MKs', 'Fig. 4j', ['c','b','a','d'], [('a','creatine'),('b','si-Ckb'),('d','si-Ckb + creatine')]),
 ('Fig. 4l\ncultured MKs', 'Fig. 4l', ['c','a'], [('a','CKB over-expression')]),
 ('Fig. 4h\ncultured MKs', 'Fig. 4h', ['c','a','b'], [('a','creatine'),('b','phosphocreatine')]),
 ('Fig. 6a\nMKs', 'Fig.6a', ['c','a','b','d'], [('a','creatine'),('b','STAT5-IN-1'),('d','STAT5-IN-1 + creatine')]),
 ('Fig. 6g\nStat5b cKO mice', 'Fig. 6g', ['c','a','d'], [('a','WT + creatine'),('d','Stat5b cKO + creatine')]),
]
labels = []; M = []; edges = [0]; names = []
for name, sheet, order, show in blocks:
    data = grab(sheet, order)
    for key, lab in show:
        labels.append(lab); M.append([data[g][key].mean()-data[g]['c'].mean() for g in genes])
    edges.append(len(labels)); names.append(name)
M = np.array(M); med = np.median(M, axis=1)
fig = plt.figure(figsize=(WIDTH, 4.5)); ax = fig.add_axes([0.385, 0.03, 0.555, 0.885])
full = np.column_stack([M, np.full(len(labels), np.nan)])
norm = TwoSlopeNorm(vmin=-2.5, vcenter=0, vmax=4)
im = ax.imshow(np.ma.masked_invalid(full), cmap='RdBu_r', norm=norm, aspect='auto')
ax.set_xticks(range(len(genes)+1)); ax.set_xticklabels(genes+['median'], fontsize=6, rotation=45, ha='left'); ax.xaxis.tick_top()
for lab in ax.get_xticklabels()[:-1]: lab.set_style('italic')
ax.get_xticklabels()[-1].set_fontweight('bold')
ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels, fontsize=6)
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        val = 2**M[i,j]
        ax.text(j, i, f'{val:.1f}' if val < 10 else f'{val:.0f}', ha='center', va='center', fontsize=5.6, color='white' if (M[i,j] > 2.2 or M[i,j] < -1.6) else 'black')
    ax.text(len(genes), i, f'×{2**med[i]:.1f}', ha='center', va='center', fontsize=6, fontweight='bold')
for e in edges[1:-1]: ax.axhline(e-0.5, color='k', lw=0.9, xmin=-0.69, clip_on=False)
for (a, b), name in zip(zip(edges[:-1], edges[1:]), names):
    ax.text(-8.25, (a+b-1)/2, name, ha='left', va='center', fontsize=6, fontweight='bold', linespacing=1.15)
ax.tick_params(length=0); 
for sp in ax.spines.values(): sp.set_visible(False)
cax = fig.add_axes([0.953, 0.25, 0.012, 0.45]); cb = fig.colorbar(im, cax=cax); cb.set_label('log2 fold vs control', fontsize=5.8); cb.ax.tick_params(labelsize=5.5, length=2)
fig.savefig('../figures/figure4_mk_gene_program.png', bbox_inches='tight', pad_inches=0.03)
tab = pd.DataFrame(2**M, index=[f'{n.splitlines()[0]}: {l}' for (a,b),n in zip(zip(edges[:-1], edges[1:]), names) for l in labels[a:b]], columns=genes).round(2)
tab['median'] = (2**med).round(2); tab.to_csv('../tables/mk_gene_panel_fold_changes.csv')
