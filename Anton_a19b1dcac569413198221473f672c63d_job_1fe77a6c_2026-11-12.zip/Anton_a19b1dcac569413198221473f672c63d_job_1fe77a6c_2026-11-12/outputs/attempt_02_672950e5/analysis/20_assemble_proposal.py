"""Assemble the proposal Markdown from the hand-written text and the generated Appendix A table."""
main = open('text/proposal_main.md', encoding='utf-8').read().rstrip()
appA = open('appendix_table.md', encoding='utf-8').read().rstrip()
appB = open('text/appendix_b.md', encoding='utf-8').read().rstrip()
appC = open('text/appendix_c.md', encoding='utf-8').read().rstrip()
introA = ("## Appendix A. Panel-by-panel evidence, re-derived\n\n"
          "Values are group means, vehicle → creatine unless stated; × is the ratio of those means, or the geometric-mean ratio with its 95% confidence interval where an interval is shown. "
          "P-values are two-tailed and recomputed from the raw values with the test used in the sheet unless marked otherwise. Fold values for qPCR are geometric means of three replicates.\n\n")
doc = main + "\n\n" + introA + appA + "\n\n" + appB + "\n\n" + appC + "\n"
open('../CRE-MK-01_validation_proposal.md', 'w', encoding='utf-8').write(doc)
print(len(doc.split()), 'words;', len(main.split()), 'in the main body')
