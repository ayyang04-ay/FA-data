import numpy as np, scipy.stats as st, json
from wb import *

def tt(a, b):
    t, p = st.ttest_ind(a, b, equal_var=True)
    return t, p, len(a)+len(b)-2

def welch(a,b):
    t,p = st.ttest_ind(a,b,equal_var=False); return t,p

def mw(a,b):
    try:
        return st.mannwhitneyu(a,b,alternative='two-sided').pvalue
    except Exception as e:
        return np.nan

def hedges(a,b):
    na,nb=len(a),len(b)
    sp=np.sqrt(((na-1)*a.var(ddof=1)+(nb-1)*b.var(ddof=1))/(na+nb-2))
    d=(b.mean()-a.mean())/sp if sp>0 else np.nan
    J=1-3/(4*(na+nb)-9)
    return d*J

def ci_diff(a,b,alpha=0.05):
    na,nb=len(a),len(b)
    sp2=((na-1)*a.var(ddof=1)+(nb-1)*b.var(ddof=1))/(na+nb-2)
    se=np.sqrt(sp2*(1/na+1/nb))
    tcrit=st.t.ppf(1-alpha/2,na+nb-2)
    d=b.mean()-a.mean()
    return d-tcrit*se, d+tcrit*se

# spec: (sheet, label, (colA, r0, r1), (colB, r0, r1), reported p cell, reported t/df cell)
specs = [
 ('Fig. 1a','Lung weight (g)',('B',3,8),('C',3,8),'F4','F8'),
 ('Fig. 1a','SUV-BW',('B',12,17),('C',12,17),'F12','F16'),
 ('Fig. 1b','Metastatic burden (%)',('B',3,8),('C',3,8),'F3','F7'),
 ('Fig. 1b','Metastatic foci',('B',12,17),('C',12,17),'F12','F16'),
 ('Fig. 1i','GFP+ cells/field',('B',4,11),('C',4,11),'F4','F8'),
 ('Fig. 1j','Lung weight (g)',('B',4,9),('C',4,9),'F4','F8'),
 ('Fig. 1j','SUV-BW',('B',13,18),('C',13,18),'F13','F17'),
 ('Fig. 1k','Metastatic burden (%)',('B',4,9),('C',4,9),'F4','F8'),
 ('Fig. 1k','Metastatic foci',('B',12,17),('C',12,17),'F12','F16'),
 ('Fig. 2a','PLT',('B',4,6),('C',4,6),'F4','F8'),
 ('Fig. 2a','PCT',('B',12,14),('C',12,14),'F12','F16'),
 ('Fig. 2a','PDW',('B',19,21),('C',19,21),'F19','F23'),
 ('Fig. 2a','MPV',('B',27,29),('C',27,29),'F27','F31'),
 ('Fig. 2c','a-granules',('B',4,11),('C',4,11),'F5','F9'),
 ('Fig. 2d','TEG-R',('B',4,8),('C',4,8),'F4','F8'),
 ('Fig. 2d','TEG-K',('B',12,16),('C',12,16),'F12','F16'),
 ('Fig. 2d','TEG-alpha',('B',20,24),('C',20,24),'F20','F24'),
 ('Fig. 2d','TEG-MA',('B',28,32),('C',28,32),'F28','F32'),
 ('Fig. 2j','PKH positive area (%)',('B',4,11),('C',4,11),'F4','F8'),
 ('Fig. 4a','MK creatine (umol/g)',('B',4,6),('C',4,6),'H10','H14'),
 ('Fig. 4a','Brain creatine (umol/g)',('D',4,6),('E',4,6),'H24','H28'),
 ('Fig. 4c','MK phosphocreatine',('B',4,6),('C',4,6),'H10','H14'),
 ('Fig. 4c','Brain phosphocreatine',('D',4,6),('E',4,6),'H24','H28'),
 ('Fig. 4d','MK in vitro creatin(in)e',('C',4,6),('D',4,6),'G10','G14'),
 ('Fig. 4f','MK in vitro phosphocreatine',('B',4,6),('C',4,6),'F4','F8'),
 ('Fig. 7g','Lung weight (g)',('B',4,8),('C',4,8),'F4','F8'),
 ('Fig. 7g','Metastatic burden (%)',('B',12,16),('C',12,16),'F12','F16'),
 ('Fig. 7g','Metastatic foci',('B',19,23),('C',19,23),'F19','F23'),
 ('Supplementary Fig  1b','food intake',('B',4,9),('C',4,9),'F4','F8'),
 ('Supplementary Fig  1c','water intake',('B',4,9),('C',4,9),'F4','F8'),
 ('Supplementary Fig  1d','serum creatine (uM)',('B',4,9),('C',4,9),'F4','F8'),
 ('Supplementary Fig  1e','Lung weight (g)',('B',4,9),('C',4,9),'F4','F8'),
 ('Supplementary Fig  1e','Metastatic burden (%)',('B',13,18),('C',13,18),'F13','F17'),
 ('Supplementary Fig  1e','Metastatic foci',('B',22,27),('C',22,27),'F22','F26'),
 ('Supplementary Fig  1f','Lung weight (g)',('B',4,7),('C',4,7),'F4','F8'),
 ('Supplementary Fig  1f','Metastatic burden (%)',('B',12,15),('C',12,15),'F12','F16'),
 ('Supplementary Fig  1f','Metastatic foci',('B',20,23),('C',20,23),'F20','F24'),
 ('Supplementary Fig  1g','Lung weight (g)',('B',3,12),('C',3,12),'F3','F7'),
 ('Supplementary Fig  1g','Metastatic burden (%)',('B',15,24),('C',15,24),'F15','F19'),
 ('Supplementary Fig  1g','Metastatic foci',('B',28,37),('C',28,37),'F28','F32'),
 ('Supplementary Fig  1h','serum creatine diet (uM)',('C',4,7),('D',4,7),'F4','F8'),
 ('Supplementary Fig  1i','Lung weight (g)',('B',3,6),('C',3,6),'F3','F7'),
 ('Supplementary Fig  1i','Metastatic burden (%)',('B',11,14),('C',11,14),'F11','F15'),
 ('Supplementary Fig  1i','Metastatic foci',('B',18,21),('C',18,21),'F18','F22'),
 ('Supplementary Fig  1k','Lung weight (g)',('B',4,13),('C',4,13),'G4','G8'),
 ('Supplementary Fig  1k','Metastatic burden (%)',('B',16,25),('C',16,25),'G16','G20'),
 ('Supplementary Fig  1k','Metastatic foci',('B',29,38),('C',29,38),'G29','G33'),
 ('Supplementary Fig  5c','MK creatine CKB-EV vs OE',('B',5,7),('C',5,7),'F5','F9'),
 ('Supplementary Fig  5c','MK phosphocreatine CKB-EV vs OE',('B',13,15),('C',13,15),'F13','F17'),
 ('Supplementary Fig  8a','BMI 0d vs 14d',('C',4,14),('D',4,14),'G5','G9'),
]
rows = []
for sh, lab, A, B, pc, tc in specs:
    a = col(sh, *A); b = col(sh, *B)
    t, p, df = tt(a,b)
    rp = v(sh, pc); rt = v(sh, tc)
    lo, hi = ci_diff(a,b)
    rows.append(dict(sheet=sh, label=lab, nA=len(a), nB=len(b), meanA=a.mean(), meanB=b.mean(), sdA=a.std(ddof=1), sdB=b.std(ddof=1),
                     ratio=b.mean()/a.mean() if a.mean()!=0 else np.nan, diff=b.mean()-a.mean(), ci_lo=lo, ci_hi=hi, t=abs(t), df=df, p=p, p_welch=welch(a,b)[1], p_mw=mw(a,b), g=hedges(a,b), rep_p=rp, rep_t=rt))
import pandas as pd
df = pd.DataFrame(rows)
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 40); pd.set_option('display.max_rows', 200)
def fmt(x):
    return f'{x:.4g}' if isinstance(x,(float,np.floating)) else x
out = df.copy()
for c in out.columns:
    out[c] = out[c].map(fmt)
print(out[['sheet','label','nA','nB','meanA','meanB','ratio','t','df','p','rep_p','rep_t','p_welch','p_mw','g']].to_string())
df.to_csv('ttests.csv', index=False)
