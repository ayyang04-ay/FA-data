import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import textwrap
G, A, R, N = '#c8e6c9', '#ffe0a3', '#f5b7b1', '#e5e7e9'   # strong / partial / absent / n.a.
cols = ['SLC6A8\n(MK creatine uptake)', 'STAT5B\n(MK, S127 axis)', 'CKB\n(MK)', 'GP6 / P2RY12\n(platelet effectors)']
rows = [
 ('Engaged by creatine',
  [('MK creatine ×3.0–5.3 in 3 experiments; rise lost in cKO (×1.5, n.s.)', G),
   ('Phospho-peptide up in screen (p=0.0012, q=0.25); pan-phos ×1.3–1.4 on WT, not S127A; promoter occupancy ×2.7–12', A),
   ('mRNA ×1.8; protein up on 4 blots', A),
   ('mRNA ×3.0–5.6 in MKs; protein bands stronger in MKs, little change on the mouse platelet blot', G)]),
 ('Needed for the MK gene program',
  [('Yes: residual induction ×1.0 (median of 11 genes), 0/11 still induced', G),
   ('Mostly: cKO+creatine ×1.3 vs WT-vehicle, 4/11 genes still ×1.6–1.9; no cKO-vehicle arm. Inhibitor: ×1.15', A),
   ('Partly: si-Ckb leaves ×1.5, 6/11 genes still induced (partial knock-down)', A),
   ('n.a.', N)]),
 ('Sufficient',
  [('Liposomal creatine restores the program in cKO MKs (×2.7) — on-target', G),
   ('Not tested functionally', R),
   ('Yes in vitro: CKB-OE ×2.4 without creatine, creatine/PCr pools unchanged', G),
   ('Not tested', R)]),
 ('Needed for platelet\nhyper-reactivity',
  [('Yes: aggregation gain lost (n=3), α-granule gain lost', G),
   ('Not tested', R), ('Not tested', R), ('Not tested', R)]),
 ('Needed for metastasis:\nlineage-specific genetics',
  [('Yes: creatine effect ×3.6 → ×0.8, interaction p=0.0009 (n=4/group)', G),
   ('Not tested (cKO line exists)', R), ('Not tested (no line)', R), ('Not tested', R)]),
 ('Needed for metastasis:\npharmacology',
  [('None', R),
   ('Systemic STAT5A/B inhibitor: ×4.1 → ×1.3, p=0.0004 (n=5; 6 records shared with another panel)', A),
   ('None', R),
   ('Aspirin in platelet donors only — not receptor-specific', A)]),
 ('Human cohort',
  [('Not measured', R), ('Not measured', R), ('Not measured', R),
   ('GP6: protein ×2.6 (4/4), collagen aggregation ×2.5 (9/11). P2RY12: protein ×1.7 (4/4) but ADP aggregation unchanged', A)]),
 ('In vivo tool for next quarter',
  [('Pf4-Cre;Slc6a8 fl/fl (residual band on blot)', A),
   ('Pf4-iCre;Stat5b fl/fl (clean deletion); STAT5-IN-1', G),
   ('None (siRNA / over-expression only)', R),
   ('Aspirin only', A)]),
]
fig, ax = plt.subplots(figsize=(14, 8.4)); ax.axis('off')
x0, w0, w = 0.0, 0.155, 0.211; h = 0.102; top = 0.93
for j, c in enumerate(cols):
    ax.add_patch(FancyBboxPatch((x0+w0+j*w+0.004, top+0.004), w-0.008, 0.062, boxstyle='round,pad=0.002', fc='#1f4e79' if j==0 else ('#5d6d7e' if j in (1,2) else '#aab7b8'), ec='none'))
    ax.text(x0+w0+j*w+w/2, top+0.035, c, ha='center', va='center', color='white', fontsize=10.5, fontweight='bold')
labels = ['PRIMARY', 'BACKUP 1', 'BACKUP 2', 'READOUTS, NOT TARGETS']
for j, l in enumerate(labels):
    ax.text(x0+w0+j*w+w/2, top+0.082, l, ha='center', va='center', fontsize=9, fontweight='bold', color='#1f4e79' if j==0 else '#555')
for i, (rname, cells) in enumerate(rows):
    y = top - (i+1)*h
    ax.text(x0+w0-0.008, y+h/2, rname, ha='right', va='center', fontsize=9.2, fontweight='bold')
    for j, (txt, colr) in enumerate(cells):
        ax.add_patch(FancyBboxPatch((x0+w0+j*w+0.004, y+0.004), w-0.008, h-0.008, boxstyle='round,pad=0.002', fc=colr, ec='white'))
        ax.text(x0+w0+j*w+w/2, y+h/2, '\n'.join(textwrap.wrap(txt, 37)), ha='center', va='center', fontsize=7.7)
yleg = top - (len(rows)+1)*h + 0.055
for k, (colr, lab) in enumerate([(G,'direct evidence in the package'), (A,'partial / indirect / caveated'), (R,'not tested'), (N,'not applicable')]):
    ax.add_patch(FancyBboxPatch((0.16+k*0.21, yleg), 0.02, 0.022, boxstyle='round,pad=0.002', fc=colr, ec='grey', lw=0.5))
    ax.text(0.185+k*0.21, yleg+0.011, lab, va='center', fontsize=8.5)
ax.set_xlim(0, 1); ax.set_ylim(yleg-0.02, 1.03)
fig.savefig('../figures/slide_target_scorecard.png', dpi=200, bbox_inches='tight')
