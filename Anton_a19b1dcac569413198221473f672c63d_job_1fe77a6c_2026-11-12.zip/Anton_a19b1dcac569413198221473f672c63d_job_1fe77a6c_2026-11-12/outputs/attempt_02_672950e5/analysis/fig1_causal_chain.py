from figstyle import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
fig = plt.figure(figsize=(WIDTH, 3.05)); ax = fig.add_axes([0, 0, 1, 1]); ax.axis('off'); ax.set_xlim(0, WIDTH); ax.set_ylim(0, 3.05)
boxes = [
 ('Oral creatine', 'serum creatine\nmouse ×2.4–2.9\nhuman ×3.5', '#d6eaf8'),
 ('SLC6A8 uptake\ninto MKs', 'MK creatine\n×3.0–5.3', BLUE),
 ('CKB', 'mRNA ×1.8,\nprotein up', GREY),
 ('STAT5B\n(S127 phospho)', 'nuclear entry;\npromoter occupancy\n×2.7–12', GREY),
 ('MK activation-\ngene program', '11/11 genes up\n×1.6–5.6 (Gp6,\nP2ry12, Rab4a …)', '#aab7b8'),
 ('Hyper-reactive\nplatelets', 'aggregation up;\ncount unchanged', '#aab7b8'),
 ('Lung\nmetastasis', 'burden ×3.2,\nfoci ×2.0; survival\nHR 2.3–2.9', '#f5b7b1'),
]
n = len(boxes); bw, gap = 0.855, 0.194; y = 1.78; bh = 0.82
xs = [0.03 + i*(bw+gap) for i in range(n)]
for (title, sub, colr), x in zip(boxes, xs):
    dark = colr in (BLUE, GREY)
    ax.add_patch(FancyBboxPatch((x, y), bw, bh, boxstyle='round,pad=0.02', fc=colr, ec='#333', lw=0.6))
    ax.text(x+bw/2, y+bh*0.73, title, ha='center', va='center', fontsize=6.4, fontweight='bold', color='white' if dark else 'black', linespacing=1.1)
    ax.text(x+bw/2, y+bh*0.27, sub, ha='center', va='center', fontsize=5.4, color='white' if dark else '#222', linespacing=1.1)
for i in range(n-1):
    ax.add_patch(FancyArrowPatch((xs[i]+bw+0.03, y+bh/2), (xs[i+1]-0.03, y+bh/2), arrowstyle='-|>', mutation_scale=8, color='#333', lw=0.9))
notes = [
 (1, 1.42, 'MK-lineage Slc6a8 deletion (Pf4-Cre):\nblocks the MK creatine rise, the gene\nprogram, the aggregation gain AND\nmetastasis (n=4/group). The only\nlineage-specific genetic test of the\nmetastasis endpoint in the package', GREEN, 0),
 (2, 0.52, 'si-Ckb / CKB over-expression\nin cultured MKs only (partly\nnecessary, sufficient);\nno in vivo test', AMBER, 0),
 (3, 1.42, 'MK-lineage Stat5b deletion (Pf4-iCre):\ngene program blunted; no platelet-\nfunction or metastasis readout.\nSystemic STAT5A/B inhibitor blocks\nmetastasis (n=5/group)', AMBER, 0.12),
 (5, 1.42, 'Platelet transfer carries the\nphenotype (mouse donors; human\nday-7 donors); lost when donors\nalso received aspirin', GREEN, 0.1),
]
for idx, ytxt, txt, colr, dx in notes:
    x = xs[idx]+bw/2
    ax.annotate('', xy=(x, y-0.04), xytext=(x, ytxt+0.04), arrowprops=dict(arrowstyle='-|>', color=colr, lw=0.9, mutation_scale=7))
    ax.text(x+dx, ytxt, txt, ha='center', va='top', fontsize=5.7, color=colr, linespacing=1.15)
ax.text(0.03, 3.0, 'Green: tested on platelet function and/or metastasis in vivo.  Amber: molecular or non-selective evidence only.\nNo intervention lowered metastasis in mice that were not given creatine.', fontsize=5.8, va='top', color='#444', linespacing=1.2)
fig.savefig('../figures/figure1_causal_chain.png', bbox_inches='tight', pad_inches=0.03)
