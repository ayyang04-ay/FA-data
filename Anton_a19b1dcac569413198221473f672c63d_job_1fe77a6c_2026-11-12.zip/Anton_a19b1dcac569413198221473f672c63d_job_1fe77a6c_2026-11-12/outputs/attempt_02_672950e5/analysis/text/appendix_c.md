## Appendix C. Files delivered with this proposal

- **figures/** The six figures above as PNG files at print size, and slide_target_scorecard.png, a color version of Table 1 for slides.
- **tables/panel_by_panel_summary.csv** Appendix A as a table.
- **tables/evidence_inventory_recomputed_statistics.csv** Each test reported in the sheets with the reported and recomputed p-value, plus the additional paired and interaction tests.
- **tables/creatine_effect_by_experiment.csv** The ten vehicle-versus-creatine comparisons behind Figure 2.
- **tables/mk_gene_panel_fold_changes.csv, mk_gene_program_blockade_contrasts.csv, qpcr_mk_panels_recomputed.csv** The megakaryocyte gene panel behind Figure 4.
- **tables/phosphoproteomics_top250_by_p.csv** The phosphoproteomics rows ranked by p-value with Benjamini–Hochberg values added.
- **tables/human_platelet_function_paired_reanalysis.csv, human_cd41_qpcr_recomputed.csv** The human re-analysis behind Figure 6.
- **analysis/run_all.sh** Regenerates every number, table and figure from the two workbooks; the numbered scripts it calls are alongside it and their printed output is in analysis/logs.
