**Recommendation: take megakaryocyte creatine uptake through SLC6A8 forward as the primary target and give it next quarter's in vivo slot; carry megakaryocyte STAT5B as first backup by testing it in that same experiment, and hold CKB as second backup in culture work until it has an in vivo tool.**

# CRE-MK-01 follow-up: target validation proposal

Prepared for the portfolio committee from the CRE-MK-01 source data, the phosphoproteomics table and the study conventions. Every statistic was recomputed from the raw values (Section 6). Abbreviations: MK, megakaryocyte; cKO, deletion restricted to the megakaryocyte lineage by Pf4-driven Cre. Effects written as "×3.6 (2.0–6.5)" are geometric-mean ratios with 95% confidence intervals, creatine versus vehicle unless stated. Metastasis effects and within-volunteer changes are geometric means throughout; other fold changes are ratios of group means.

## 1. The decision in brief

- **SLC6A8 first.** It is the only node that was removed specifically in megakaryocytes and then read out on metastasis. In Cre-control mice creatine raised lung metastatic burden ×3.6 (2.0–6.5); in Pf4-Cre;Slc6a8 fl/fl mice the effect was ×0.8 (0.4–1.4) (interaction p = 0.0009; n = 4 per group; Fig. 3i). The same deletion removed megakaryocyte creatine accumulation (×5.3 versus ×1.5; Fig. 3c), the gain in platelet aggregation (Fig. 3d) and the induction of all 11 platelet-activation genes (median ×3.5 versus ×1.0; Fig. 3f), although serum creatine rose similarly in both genotypes (Fig. 3b). Delivering creatine past the transporter in liposomes restored the gene response in knockout megakaryocytes (median ×2.7; Supp. Fig. 4e), so the block is on-target.
- **STAT5B is the first backup, not the lead.** Its link to metastasis rests on one experiment with a systemic inhibitor of both STAT5A and STAT5B (creatine effect ×4.1 (2.9–5.7) without and ×1.3 (0.8–2.1) with inhibitor; interaction p = 0.0004; n = 5 per group; Fig. 6b). The megakaryocyte-specific Stat5b knockout was read out on genes and protein only. It leaves P2ry12, Adra2a, Gpiba and F2r at ×1.6–1.9 of vehicle (Fig. 6g), has no vehicle-treated knockout arm and no Cre-matched control, and was never tested on platelet function or metastasis. The phosphoproteomic hit that nominated STAT5B does not survive multiple-testing correction (q = 0.25; rank 17 of 5,812 rows). The knockout line exists, so this gap is cheap to close.
- **CKB is the second backup.** In cultured megakaryocytes, knock-down blunts the gene program and over-expression reproduces it (Fig. 4j, 4l). Nothing has been done in vivo and there is no in vivo tool.
- **GP6 and P2RY12 are readouts, not targets.** Nothing in the package blocks either receptor. GP6 is the better human marker: platelet GP6 protein rose ×2.6 in 4 of 4 volunteers and collagen-induced aggregation ×2.5 in 9 of 11, whereas P2RY12 protein rose but ADP-induced aggregation did not (Fig. 7c, 7e).
- **One caveat frames the whole program.** Every node is validated only as a mediator of the increase caused by creatine dosing. Neither Slc6a8 deletion nor STAT5 inhibition lowered metastasis in mice that were not given creatine (Fig. 3i, 6b). The program is therefore only as valuable as the exposure is common and dose-relevant, which Study C and the dose series in Study D address.

**What the slot buys.** One blinded, powered genotype × creatine study. It repeats the Slc6a8 result at decision grade (12–16 mice per group, both sexes) and gives the first platelet-function and metastasis readout for the Stat5b knockout, with the control arms that CRE-MK-01 lacks (Section 4). The ranking follows the strength of causal evidence on the metastasis endpoint in our own data, and the study is built so that STAT5B can overtake SLC6A8 on data.

![Figure 1. The causal chain supported by the package, and what breaks each link.](figures/figure1_causal_chain.png)

**Table 1. Evidence scorecard.** ● direct evidence in the package; ◐ partial, indirect or caveated; ○ not tested.

| Evidence line | SLC6A8 (primary) | STAT5B (backup 1) | CKB (backup 2) | GP6 and P2RY12 (readouts) |
|---|---|---|---|---|
| Engaged by creatine | ● MK creatine ×3.0–5.3 in three experiments; rise lost in the knockout | ◐ Phosphopeptide up in the screen (q = 0.25); pan-phospho ×1.3–1.4 on wild-type, not S127A; promoter occupancy ×2.7–12 | ◐ mRNA ×1.8; protein up on four blots | ● mRNA ×3.0–5.6 in MKs. ◐ Protein bands stronger in MKs, little change on the mouse platelet blot |
| Needed for the MK gene program | ● Yes: residual induction ×1.0, 0 of 11 genes | ◐ Mostly: knockout plus creatine ×1.3 of vehicle, four genes still ×1.6–1.9, no vehicle-treated knockout; inhibitor ×1.15 | ◐ Partly: si-Ckb leaves ×1.5, 6 of 11 genes still induced | Not applicable |
| Sufficient | ● Liposomal creatine restores the program in knockout MKs (×2.7) | ○ Not tested functionally | ● In culture: over-expression ×2.4 without creatine | ○ Not tested |
| Needed for platelet hyper-reactivity | ● Yes (n = 3) | ○ Not tested | ○ Not tested | ○ Not tested |
| Needed for metastasis: lineage-specific genetics | ● Yes: creatine effect ×3.6 → ×0.8, interaction p = 0.0009 (n = 4) | ○ Not tested; the line exists | ○ Not tested; no line | ○ Not tested |
| Needed for metastasis: pharmacology | ○ None | ◐ Systemic STAT5A/B inhibitor: ×4.1 → ×1.3, p = 0.0004 (n = 5; shared records) | ○ None | ◐ Aspirin, in platelet donors only |
| Human cohort | ○ Not measured | ○ Not measured | ○ Not measured | ◐ GP6 protein ×2.6 and collagen response ×2.5; P2RY12 protein ×1.7 but ADP response unchanged |
| In vivo tool for next quarter | ◐ Pf4-Cre;Slc6a8 fl/fl (residual band on blot) | ● Pf4-iCre;Stat5b fl/fl (clean deletion); STAT5-IN-1 | ○ None | ◐ Aspirin only |

## 2. Check before presenting

1. **Six animal records appear in two different experiments.** Three vehicle and three creatine records in the STAT5-inhibitor study (Fig. 6b) are identical, to the last recorded digit of burden and in the paired foci counts, to rows 4–6 of the vehicle-donor and creatine-donor groups in the platelet-transfer study (Supp. Fig. 2d). Both conclusions survive removing them, but on 2 or 3 animals per control group (Fig. 6b creatine versus creatine + inhibitor: Student p = 0.001, Welch p = 0.16 with n = 2 versus 5). Reconcile against the animal-level records before either panel is shown. No other block of repeated records was found, and none involves the Slc6a8 experiment (Fig. 3i).
2. **Metadata the package does not record.** The tumor line (only Fig. 1f is labeled "melanoma"), the inoculation route, which panels used which strain and sex, the readout of the Fig. 1h time course, the host cell of Fig. 5e and 5f, whether the Fig. 6a megakaryocytes were treated in culture or in the animal, the ChIP antibody, and the direction and base of LOG_FOLDCHANGE in the phosphoproteomics table (read here as log2, creatine ÷ vehicle).
3. **Numbers not to quote as they stand.** The human platelet-function p-values in the sheet come from Dunnett tests on fold changes whose baseline column is all 1.0; the paired re-analysis in Section 3.6 should be used instead. Four panels count microscope fields, not animals (Fig. 1i, 2c, 2j; Supp. Fig. 4c).

## 3. Evidence

### 3.1 Creatine raises lung metastasis about three-fold in every experiment

- **Ten of ten comparisons.** In ten vehicle-controlled comparisons (61 versus 61 mice; oral dosing three times a week in nine, 5% creatine diet in one) burden rose every time, each at p < 0.01. The pooled ratio is ×3.2 (2.6–3.9) for burden and ×2.0 (1.7–2.4) for foci; single experiments range from ×2.1 to ×4.3 (I² = 59%) (Fig. 1b, 1k, 1f, 3i, 6b; Supp. Fig. 1e, 1f, 1g, 1i, 1k; Figure 2).
- **Survival.** Median survival fell from 22 to 19 days (hazard ratio 2.9, 1.04–8.2; n = 10 and 10; Fig. 1c) and from 16 to 14 days (hazard ratio 2.3, 1.2–4.5; n = 20 and 18; Fig. 1l).
- **Early seeding.** A 0.25–24 h time course, which reads as early tumor-cell retention although the sheet does not name the readout, is equal at 0.25 h and ×1.5, ×1.8 and ×2.8 higher with creatine at 6, 12 and 24 h (n = 6; Fig. 1h). GFP-positive cells per lung field rose from 9 to 20 (Fig. 1i).
- **Exposure.** Serum creatine rose ×2.7 on the oral regimen (66 to 179 µM; Supp. Fig. 1d) and ×2.9 on diet (78 to 227 µM; Supp. Fig. 1h). Body weight, food and water intake and blood counts did not change (Supp. Fig. 1a–c, 3a).
- **Not through the tumor cell's own transporter.** With Slc6a8 knocked down in the melanoma cells the creatine effect was ×3.2 (2.4–4.1) against ×4.1 (2.1–8.0) with scrambled shRNA (interaction p = 0.44; n = 6 per group; Fig. 1f). The knock-down is 81% at mRNA level but modest on the protein blot (Supp. Fig. 2a), so a partial tumor-cell contribution is not excluded.

![Figure 2. Creatine effect on lung metastasis in the ten vehicle-controlled comparisons (122 mice), with the random-effects pooled estimate.](figures/figure2_creatine_effect_forest.png)

### 3.2 Platelets carry the effect; megakaryocytes are where creatine acts

- **Platelet reactivity rises, platelet number does not.** Counts and indices were unchanged (Fig. 2a). Aggregation rose to ADP (42 to 57%), collagen (66 to 79%) and thrombin (25 to 56%) (n = 3; Fig. 2b). Thromboelastography maximum amplitude rose from 39.7 to 54.0 mm (p = 0.049; n = 5), with the other three parameters unchanged (Fig. 2d).
- **Transferring platelets transfers the phenotype.** Recipients of platelets from creatine-treated donors carried ×3.3 (1.8–5.8) the burden of recipients of vehicle-donor platelets, and platelets from donors given creatine plus aspirin did not (n = 6 per group; Supp. Fig. 2d; see Section 2, item 1). Human platelets taken on day 7 of supplementation gave recipient mice ×2.8 (1.6–4.8) the burden of day-0 platelets from the same cohort (n = 5 and 5; Fig. 7g).
- **Creatine acts on megakaryocytes, not on circulating platelets.** In culture, creatine at 0.2–2 mM raised GP6 and P2RY12 protein in megakaryocytes but not in isolated platelets (Fig. 2i). Megakaryocytes from treated mice had all 11 activation genes up, ×1.6–5.6 (median ×3.0; Fig. 2f), with maturation and creatine-synthesis genes largely unchanged (Supp. Fig. 3c, 5a).
- **Megakaryocytes accumulate creatine strongly.** Intracellular creatine rose ×3.0–5.3 in three experiments (Fig. 3c, 4a, 6e) and phosphocreatine ×3.9 (Fig. 4c). Brain from the same animals changed less: creatine ×1.19, phosphocreatine ×2.0 (Fig. 4a, 4c).

### 3.3 SLC6A8, the primary target

| Readout (n per group) | Cre control, vehicle → creatine | Slc6a8 cKO, vehicle → creatine | Genotype × creatine interaction |
|---|---|---|---|
| Serum creatine, µM (5; Fig. 3b) | 89 → 239 | 89 → 218 | p = 0.18: exposure is equal |
| MK creatine, µmol/g (3; Fig. 3c) | 13.7 → 72.1 | 13.7 → 21.1 | p = 0.045; 0.065 on the log scale |
| Aggregation to ADP / collagen / thrombin, % (3; Fig. 3d) | 63 → 71 / 65 → 77 / 61 → 75 | 54 → 31 / 61 → 51 / 45 → 35 | each p < 0.0001 |
| 11-gene panel, median fold (3; Fig. 3f) | ×3.5 | ×1.0; 0 of 11 genes induced | p < 0.05 for 7 of 11 genes |
| α-granules per field (8 fields; Supp. Fig. 4c) | 2.6 → 5.1 | 2.25 → 2.25 | p = 0.006 |
| Lung metastatic burden, % (4; Fig. 3i) | 2.4 → 7.9; ×3.6 (2.0–6.5) | 3.4 → 2.9; ×0.8 (0.4–1.4) | p = 0.0009 |
| Metastatic foci (4; Fig. 3i) | 30 → 56 | 26 → 25 | p = 0.023 |
| Lung weight, g (4; Fig. 3i) | 0.206 → 0.249 | 0.222 → 0.225 | p = 0.0002 |
| Platelet count, ×10⁹/L (3; Supp. Fig. 4b) | 890 → 909 | 1042 → 992 | not significant |

Interactions are two-way contrasts computed for this proposal, on the log scale for the three metastasis readouts and on the raw scale otherwise. The sheet's own Tukey test for control-creatine versus knockout-creatine burden gives p = 0.0004. Figure 3A shows the individual animals of Fig. 3i, and Figure 4 the gene panel for every perturbation side by side.

What still has to be resolved for SLC6A8:

- **Replication.** The metastasis result is one experiment with 4 mice per group, unblinded, and the package does not record the sex of the knockout cohorts.
- **Completeness of deletion.** The SLC6A8 band in knockout megakaryocytes is reduced, not absent (Supp. Fig. 4a; one blot, no densitometry).
- **An unexplained platelet finding.** In the knockout, creatine lowered aggregation, and vehicle-treated knockout platelets already aggregated less than controls (ADP 54 versus 63%; thrombin 45 versus 61%; Fig. 3d). At n = 3 this may be batch noise, or it may mean megakaryocyte SLC6A8 supports normal platelet reactivity, which would be a bleeding question for any inhibitor.
- **Tractability.** No SLC6A8 inhibitor has been tested in our system, and the transporter is not megakaryocyte-restricted: the melanoma cells express it (Supp. Fig. 2a). The only package data on tissue selectivity are that dosing raised creatine ×3.0 in megakaryocytes but ×1.19 in brain (Fig. 4a).

![Figure 3. The four in vivo tests of where the creatine effect comes from.](figures/figure3_in_vivo_tests.png)

### 3.4 STAT5B, the first backup

What supports it:

- **Screen.** One Stat5b phosphopeptide is higher with creatine (LOG_FOLDCHANGE 5.70, about 52-fold if log2; p = 0.0012; n = 3 mice per group).
- **Site.** The pan-phospho signal on FLAG-tagged STAT5B rose with creatine for wild-type protein (×1.39, p = 0.009 in Fig. 5e; ×1.28, p = 0.09 in Fig. 5f) but not for the S127A or 3A mutants (n = 3 blots).
- **Occupancy.** ChIP signal rose ×2.7–12 at the proximal promoters of P2ry12, Gp6 and Rab4a and not at exons (n = 3; Fig. 5j; Supp. Fig. 6i).
- **Inhibitor.** STAT5-IN-1 removed the creatine effect on the gene panel (median ×4.2 to ×1.15; Fig. 6a) and on lung burden (Fig. 6b; Figure 3B).
- **Knockout.** STAT5B protein is absent in Pf4-iCre;Stat5b fl/fl megakaryocytes (Fig. 6d). Creatine still accumulates (95 versus 98 µmol/g; Fig. 6e) and still induces CKB (Fig. 6f), which places STAT5B downstream of both. The gene panel is blunted from a median ×4.0 to ×1.3 (Fig. 6g).
- **Route.** Tyrosine-phosphorylated STAT5 was not detectable in megakaryocytes with or without creatine (Supp. Fig. 6a), consistent with a non-canonical serine route.

What is missing or weak:

- **The in vivo metastasis evidence is pharmacological only.** The study conventions state that STAT5-IN-1 inhibits both STAT5A and STAT5B, and it was given systemically, so the result cannot be assigned to STAT5B or to megakaryocytes. The inhibitor alone also pushed 7 of 11 genes below control (to ×0.2–0.7; Fig. 6a), so it acts on the basal program and not only on the creatine-induced part. This is also the experiment with the shared records.
- **The knockout is under-controlled and under-read.** There is no vehicle-treated knockout group, the control is "WT" rather than Cre-matched, four receptor genes stay ×1.6–1.9 above vehicle, and platelet function and metastasis were not measured.
- **The screen is hypothesis-generating at best.** No row reaches q < 0.05 (minimum q = 0.167). Among the 4,110 rows with a usable test, 238 have p < 0.05 against 205.5 expected by chance. Changes as large as the Stat5b one are mostly on/off-type calls in this table (93% of the 2,139 rows with at least a four-fold change sit in two stereotyped p-value bands), and the table gives no intensities to check. It carries gene names without site positions, so it cannot confirm S127, and the second Stat5b peptide and the Stat5a peptide do not move (Figure 5).
- **The site evidence is indirect.** It comes from over-expressed, tagged protein and a pan-phospho antibody. The phosphomimetic S127D gives a higher pan-phospho signal than wild-type in vehicle (1.05 versus 0.72), which a site-specific readout would not do.

![Figure 4. How completely each perturbation removes the megakaryocyte gene program. Numbers are fold changes against that experiment's own control group (qPCR, n = 3 per group).](figures/figure4_mk_gene_program.png)

![Figure 5. Phosphoproteomics: the Stat5b hit in context.](figures/figure5_phosphoproteomics.png)

### 3.5 CKB, the second backup

- **Induced by creatine.** Ckb mRNA rose ×1.8 (p = 0.011; Fig. 4e) and CKB protein rose in megakaryocytes on four blots (Fig. 4b, 4e, 4g, 6f).
- **Partly necessary in culture.** With si-Ckb, creatine induction of the panel fell from a median ×4.2 to ×1.5, with 6 of 11 genes still significantly induced; the knock-down is partial and also lowers 8 of 11 genes at baseline (Fig. 4j; Supp. Fig. 5b).
- **Sufficient in culture.** Over-expression alone raised all 11 genes ×1.7–6.0 (median ×2.4; Fig. 4l) without changing creatine (33.7 versus 32.7 µmol/g) or, detectably, phosphocreatine (×1.25, 0.88–1.78; n = 3) (Supp. Fig. 5c). Added phosphocreatine did not induce the panel (median ×0.6; Fig. 4h), though its uptake was not verified.
- **Link to STAT5B.** CKB over-expression raised the pan-phospho signal on wild-type but not S127A STAT5B, si-CKB blunted the creatine-induced nuclear signal, and recombinant CKB with ATP raised the signal in a cell-free reaction (single blots; Fig. 5g–i; Supp. Fig. 6d).
- **Missing.** Any in vivo loss of function, a catalytically dead control, and a complete knockout. Brain expresses far more CKB than megakaryocytes (Fig. 4b), which matters for any systemic inhibitor.

### 3.6 GP6, P2RY12 and the human cohort

The cohort is 11 healthy volunteers aged 20–25 (6 women, 5 men), 20 g creatine per day for 14 days, single arm, no placebo; molecular readouts come from 4 of the 11.

- **Exposure matches the mouse.** Serum creatine rose from 45 to 159 µM (×3.5; 11 of 11; Fig. 7b), close to the levels reached in mice (179–239 µM). Platelet count did not change (Supp. Fig. 8b).
- **Platelet function, paired re-analysis of Fig. 7c (day 14 versus each volunteer's day 0; Wilcoxon signed-rank p).** Collagen ×2.5 (1.5–4.3), 9 of 11 up, p = 0.005. Epinephrine ×1.6 (1.2–2.2), 10 of 11 up, p = 0.002, and already ×1.3 at day 7. Arachidonic acid ×1.3 (0.9–1.8), p = 0.04. ADP ×1.07 (0.7–1.6), p = 0.46. After Holm correction across all 36 agonist, metric and day tests only epinephrine readouts stay below 0.05; collagen at day 14 is 0.16.
- **Platelet protein (4 volunteers; Fig. 7e).** At day 14 GP6 was ×2.6 and P2RY12 ×1.7, each up in 4 of 4.
- **CD41-positive cells (4 volunteers; Fig. 7d).** GP6, P2RY12, GPIBA, F2R and ADRA2A transcripts were up in 3 or 4 of 4 at day 7; one volunteer barely responded. RAB4A, one of the three mouse genes with a promoter-occupancy signal, fell in 4 of 4 by day 14 (×0.38).
- **What this supports.** That 20 g/day for two weeks produces the platelet phenotype in people. It says nothing about SLC6A8, CKB or STAT5B in human cells, none of which was measured. The ADP result argues against P2RY12 being the limiting effector in humans; collagen with GP6, and epinephrine with ADRA2A, are the concordant pairs.
- **Mouse effectors.** Gp6 is the most induced gene in megakaryocytes from treated mice (×5.6) and P2ry12 rises ×3.0 (Fig. 2f). On the blots both proteins are stronger in megakaryocytes (Fig. 2g), while platelets from the same treatment show little change once loading is allowed for (Fig. 2e); neither blot is quantified in the package. No receptor was blocked or deleted, and aspirin was given only to platelet donors.

![Figure 6. Healthy-volunteer cohort: 20 g creatine per day for 14 days, single arm, no placebo.](figures/figure6_human_cohort.png)

### 3.7 Limits on confidence that apply across the package

- **Design.** Allocation was not masked, group sizes were not set by a power calculation, and sex was not analyzed; the package used male C57BL/6J and female BALB/cJ, so sex is confounded with strain.
- **Size.** Most mechanistic readouts have 3 per group, and many links rest on single blots without densitometry.
- **One exposure level.** Every regimen gave serum creatine ×2.4–2.9, so there is no dose-response, and nothing was measured after stopping creatine.
- **Prevention only.** The deletions were in place before creatine dosing began, and the package shows no intervention started after exposure was established, so nothing tests whether blocking a node reverses the effect.

## 4. Proposed studies

### 4.1 Study A: the in vivo slot

| Element | Specification |
|---|---|
| Questions | (1) Confirm that megakaryocyte-lineage Slc6a8 deletion removes the creatine effect on lung metastasis. (2) Test for the first time whether megakaryocyte-lineage Stat5b deletion does the same. |
| Model and indication | The lung-metastasis model and oral creatine regimen used for Fig. 3i (42.5 mg/mL, 400 µL, three times a week). The package names the tumor only for Fig. 1f, melanoma, which is therefore the first indication hypothesis; confirm the line and route used for Fig. 3i from the study records. |
| Population | Both sexes, stratified, age-matched littermates. Four genotypes: Pf4-Cre;Slc6a8 +/+, Pf4-Cre;Slc6a8 fl/fl, Pf4-iCre;Stat5b +/+, Pf4-iCre;Stat5b fl/fl. Slc6a8 is X-linked (general background, not from the package), so the colony must supply fl/Y males and fl/fl females. |
| Arms and comparators | Each genotype on vehicle (water) or creatine: 8 groups. Cre-positive wild-type littermates are the genetic comparators, which adds the Cre-matched control and the vehicle-treated knockout that the Stat5b data lack. If capacity allows, two pharmacological comparators in control mice: creatine plus aspirin 30 mg/kg/day, because aspirin was only ever given to platelet donors, and a repeat of the STAT5-IN-1 arms of Fig. 6b, to replace the experiment affected by the shared records. |
| Sample size | 12 per group, 96 mice; 16 per group if the colonies allow. Assuming a ×3 effect in controls and an SD of ln(burden) of 0.45–0.55 (the upper end of the ten experiments, range 0.16–0.57), 12 per group gives 92–98% power for the interaction. If deletion removes the whole effect, the knockout's upper confidence bound falls below ×2 in 85–96% of runs at 12 per group and 94–99% at 16. A partial block (a residual ×1.7) would show as an interaction in only 42–56% of runs at 12 per group, so partial effects are estimated rather than tested. |
| Primary endpoint | Lung metastatic burden (% of lung area), one value per animal, assessed blind to group. |
| Secondary endpoints | Number of foci; lung weight. |
| Mechanism and exposure readouts (satellite animals without tumor, 6 per group) | Serum creatine; megakaryocyte creatine; platelet aggregation to collagen, ADP, thrombin and, to bridge to the volunteers, epinephrine; platelet GP6 and P2RY12 protein with densitometry; the 11-gene panel; megakaryocyte CKB; deletion efficiency quantified in each cohort. One extra control-genotype cohort stops creatine and is followed until platelet reactivity and GP6 return to baseline, which sets the washout for Study C and the timing for Study D. |
| Safety readouts | Platelet count and indices, bleeding time, body weight. |
| Design safeguards | Randomization stratified by sex and litter; outcome assessment blind to genotype and treatment; group sizes from the calculation above; the animal as the unit throughout. CRE-MK-01 randomized its animals but did not mask allocation or readout, did not size groups by calculation and did not analyze sex. |
| Analysis | ln(burden) on genotype, creatine and their interaction, adjusted for sex. Test the Slc6a8 interaction first at α = 0.05, then the Stat5b interaction. |
| A valid run requires | Serum creatine at least doubled, a creatine effect of at least ×2 in each control genotype, and verified deletion. |
| Decision rule for each target | Confirmed: interaction p < 0.05 and the upper confidence bound of the creatine effect in the knockout below ×2. Partial: a significant interaction with a residual effect above that bound. Not confirmed: no interaction. |

If the slot can hold only four groups, run the Slc6a8 half as specified: a primary target resting on 4 mice per group is not a basis for further spend. If the Slc6a8 colony cannot supply the animals next quarter, the Stat5b half takes the slot unchanged.

### 4.2 Study B: cell-based enabling work that needs no in vivo slot

- **SLC6A8 tractability.** A selective blocker in wild-type megakaryocytes should reproduce the knockout on creatine accumulation, the 11-gene panel and GP6 and P2RY12 protein, and liposomal creatine should rescue it. Run the same in human megakaryocytes. Add a concentration series spanning human serum levels (45 µM at baseline, about 160 µM on 20 g/day) to find the threshold.
- **STAT5B specificity.** Site-resolved, targeted mass spectrometry for STAT5B S127 in megakaryocytes with more than 3 per group; separate and combined Stat5a and Stat5b knock-down; S127A and S127D put back into Stat5b-null megakaryocytes with the gene panel as readout; ChIP repeated in knockout cells as the specificity control.
- **CKB mechanism and tool.** Catalytically dead versus wild-type CKB over-expression; complete rather than partial loss; a cell-free reaction with S127A substrate. If these hold, start a megakaryocyte-lineage Ckb deletion, which is the gating item for any CKB in vivo study.
- **Which receptor carries the gain.** Platelets from creatine-treated mice, with GP6 or P2RY12 blocked, in tumor-cell interaction assays outside the animal. The transfer version belongs in Study D.

### 4.3 Study C: human confirmation

| Element | Specification |
|---|---|
| Design | Randomized, double-blind, placebo-controlled. Crossover if platelet measures are shown to return to baseline after stopping, otherwise parallel groups at about twice the size; a lower-dose arm can run alongside. |
| Population | Healthy adults of both sexes, stratified, across a wider age range and more than one ancestry than the current cohort (11 Asian volunteers aged 20–25); no antiplatelet or NSAID use. No creatine dosing in cancer patients. |
| Intervention and comparator | Creatine monohydrate 20 g/day for 14 days against matched placebo, plus a lower-dose arm, since 20 g/day is the only dose tested. |
| Primary endpoint | Change from baseline to day 14 in collagen-induced maximal aggregation, against placebo. |
| Key secondary endpoint | Epinephrine-induced aggregation at days 7 and 14. |
| Other readouts | ADP and arachidonic acid responses; platelet GP6 and P2RY12 protein; GP6, ADRA2A and P2RY12 transcripts in CD41-positive cells (not RAB4A); serum creatine; return to baseline after stopping; and, for the first time, SLC6A8, CKB and STAT5B in the CD41-positive fraction. |
| Sample size | In a crossover, about 20 completers give 90% power for effects of the size seen (collagen ×2.5, epinephrine ×1.6), assuming the placebo period is as variable as the creatine period. Half that effect at a lower dose needs about 70. |
| Indication it serves | Creatine-associated platelet priming in people with, or at high risk of, blood-borne metastasis, melanoma first. A parallel observational survey of supplement use and platelet reactivity in patients with resected high-risk melanoma would show whether the exposure exists in that population. |

### 4.4 Study D: the following in vivo study, contingent on A and B

Pharmacological blockade of the confirmed node, started both before and after creatine exposure is established, with aspirin and STAT5-IN-1 as comparators; a second tumor model in the BALB/cJ background; platelets from knockout donors transferred into wild-type recipients, to confirm the platelet as the carrier; survival as an endpoint (about 20 per group for a hazard ratio near 2.5); and a creatine dose series.

## 5. What would move the ranking

| New information | Effect |
|---|---|
| Study A confirms Slc6a8 with verified deletion in both sexes | SLC6A8 stays primary and moves to pharmacology. |
| Study A does not confirm Slc6a8, or the effect tracks residual protein or one sex | SLC6A8 is demoted; the Stat5b result decides the lead. |
| Stat5b knockout removes the aggregation gain and the metastasis effect as completely as Slc6a8 deletion, with normal platelet count and bleeding time | STAT5B becomes co-primary; it already has a small-molecule handle, though not an isoform-selective one. |
| Stat5b knockout is partial or has no effect | STAT5B is demoted; the Fig. 6b result is then attributed to STAT5A or to other cell types, and CKB becomes first backup. |
| A selective SLC6A8 blocker reproduces the knockout in mouse and human megakaryocytes and is rescued by liposomal creatine | Cements the primary and defines Study D. |
| No usable SLC6A8 blocker, or blocking uptake lowers baseline platelet function or prolongs bleeding | Lead passes to STAT5B if its genetics are positive, otherwise to CKB. |
| Catalytically dead CKB fails to induce the program, complete Ckb loss abolishes the creatine response, and a lineage deletion is available | CKB is promoted; it is the only node shown to be sufficient. |
| Targeted mass spectrometry confirms S127 in megakaryocytes and S127A fails to restore the program | Strengthens STAT5B and the CKB to STAT5B step. |
| The six shared records prove to belong to the platelet-transfer study | Fig. 6b keeps 2 vehicle and 2 creatine animals, and the in vivo case for STAT5B weakens further. |
| Blocking GP6 alone removes the creatine increment | An effector-level route opens and could overtake the upstream targets. |
| Study C fails against placebo, or there is no effect at the lower dose | The whole program is deprioritized, since stopping supplementation already removes the exposure. |

## 6. How the numbers were derived

- **Reproduction.** Every test reported in the source sheets was recomputed from the raw values: unpaired two-tailed t tests, log-rank tests, one-way ANOVA with Tukey or Dunnett, two-way ANOVA with Sidak. All 232 reported p-values reproduce (227 numerically; 5 are given as inequalities and are consistent). All qPCR fold values reproduce from the listed ΔCt values except one volunteer's RAB27B and PITPNB series in Fig. 7d.
- **Ratios and interactions.** Ratios are geometric-mean ratios from t-based intervals on log values. Interactions are the genotype × creatine or inhibitor × creatine contrast on ln(burden) with pooled variance. The pooled creatine effect is a DerSimonian–Laird random-effects mean of the ten log ratios.
- **Gene panel.** Contrasts on ΔCt with pooled variance across the groups of each experiment; "still induced" means creatine versus the perturbation-alone group at p < 0.05. The Stat5b knockout has no such group, so its values are against wild-type vehicle.
- **Human data.** Paired: Wilcoxon signed-rank and one-sample t on log fold change for platelet function, paired t for protein.
- **Phosphoproteomics.** Rows with the degenerate p = 0.4227 (1,702 of 5,812) were set aside before comparing the count of p < 0.05 with the uniform expectation; the q-values are those in the file, and Benjamini–Hochberg gives a minimum adjusted p of 0.25.
- **Duplicates and blots.** All sheets were scanned for values repeated across experiments. Blots were read by eye, with rough pixel-intensity checks on a few; no new densitometry is reported.
- **Power.** Simulation with a ×3 effect in controls and the SDs stated in Section 4.1.
- **Sources.** Only the three supplied files were used as evidence. No external literature was used; the one piece of general background that informs a design choice is labeled where it appears.
