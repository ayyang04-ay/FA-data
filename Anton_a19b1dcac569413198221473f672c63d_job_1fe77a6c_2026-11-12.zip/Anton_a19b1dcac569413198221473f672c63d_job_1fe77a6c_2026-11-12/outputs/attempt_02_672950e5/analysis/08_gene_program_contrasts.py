import json, numpy as np, pandas as pd, scipy.stats as st, re
from openpyxl.utils import column_index_from_string as ci, get_column_letter as cl
C = json.load(open('cells.json'))
def grab(sheet, groups, label_col='F', first_val_col='G'):
    d = C[sheet]; rows = sorted(set(int(re.sub(r'[A-Z]+','',k)) for k in d)); out = {}
    for r in rows:
        g = d.get(f'A{r}'); lab = d.get(f'{label_col}{r}')
        if isinstance(g, str) and lab == 'ΔCT1':
            fc = ci(first_val_col); res = {groups[0]: np.array([d.get(f'{cl(fc+i)}{r}') for i in range(3)], float)}
            for k, grp in enumerate(groups[1:]):
                base = fc + 4*k
                res[grp] = np.array([d.get(f'{cl(base+i)}{r+1}') for i in range(3)], float)
            out[g.strip()] = res
    return out
def contrast(groups_vals, weights):
    # groups_vals: list of arrays; weights: list -> contrast on means, pooled variance
    n = [len(g) for g in groups_vals]; dfree = sum(n)-len(n)
    mse = sum((len(g)-1)*g.var(ddof=1) for g in groups_vals)/dfree
    est = sum(w*g.mean() for w,g in zip(weights, groups_vals)); se = np.sqrt(mse*sum(w*w/len(g) for w,g in zip(weights, groups_vals)))
    t = est/se; p = 2*st.t.sf(abs(t), dfree); tc = st.t.ppf(0.975, dfree)
    return est, est-tc*se, est+tc*se, p
genes = ['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
rows = []
# 4-group designs
designs = {
 'Slc6a8 cKO (MKs from treated mice; Fig 3f)': ('Fig. 3f', ['ctl','cre','pert','pert_cre']),
 'si-Ckb (MKs in vitro; Fig 4j)': ('Fig. 4j', ['ctl','pert','cre','pert_cre']),
 'STAT5-IN-1 (MKs in vitro; Fig 6a)': ('Fig.6a', ['ctl','cre','pert','pert_cre']),
}
for name, (sheet, order) in designs.items():
    data = grab(sheet, order)
    for g in genes:
        dd = data[g]
        G = [dd['ctl'], dd['cre'], dd['pert'], dd['pert_cre']]
        ind, lo, hi, p = contrast(G, [-1,1,0,0])            # creatine induction in control background (log2)
        res, rlo, rhi, rp = contrast(G, [0,0,-1,1])          # creatine induction in perturbed background
        base, blo, bhi, bp = contrast(G, [-1,0,1,0])         # perturbation effect on baseline
        inter, ilo, ihi, ipv = contrast(G, [1,-1,-1,1])      # interaction
        abs_, alo, ahi, ap = contrast(G, [-1,0,0,1])         # pert+cre vs control
        rows.append(dict(design=name, gene=g, induction_log2=ind, ind_p=p, residual_log2=res, res_lo=rlo, res_hi=rhi, res_p=rp, baseline_shift_log2=base, base_p=bp, interaction_log2=inter, int_p=ipv, pertcre_vs_ctl_log2=abs_, abs_p=ap, pct_remaining=100*res/ind))
# 3-group design (Stat5b cKO): no cKO-vehicle
data = grab('Fig. 6g', ['ctl','cre','pert_cre'])
for g in genes:
    dd = data[g]; G = [dd['ctl'], dd['cre'], dd['pert_cre']]
    ind, lo, hi, p = contrast(G, [-1,1,0]); abs_, alo, ahi, ap = contrast(G, [-1,0,1]); diff, dlo, dhi, dp = contrast(G, [0,-1,1])
    rows.append(dict(design='Stat5b cKO (MKs from treated mice; Fig 6g; no cKO-vehicle arm)', gene=g, induction_log2=ind, ind_p=p, residual_log2=np.nan, res_p=np.nan, baseline_shift_log2=np.nan, base_p=np.nan, interaction_log2=np.nan, int_p=np.nan, pertcre_vs_ctl_log2=abs_, abs_lo=alo, abs_hi=ahi, abs_p=ap, cre_ko_vs_cre_wt_log2=diff, diff_p=dp, pct_remaining=100*abs_/ind))
# liposome rescue (Slc6a8 cKO MKs in vitro)
data = grab('Supplementary Fig  4e', ['ctl','cre','lipo'])
for g in genes:
    dd = data[g]; G = [dd['ctl'], dd['cre'], dd['lipo']]
    a, alo, ahi, ap = contrast(G, [-1,1,0]); b, blo, bhi, bp = contrast(G, [-1,0,1])
    rows.append(dict(design='Slc6a8-cKO MKs in vitro: free creatine vs creatine@liposome (S4e)', gene=g, induction_log2=b, ind_p=bp, residual_log2=a, res_p=ap, pct_remaining=np.nan))
# Phosphocreatine and CKB-OE
data = grab('Fig. 4h', ['ctl','cre','pcr'])
for g in genes:
    dd = data[g]; G = [dd['ctl'], dd['cre'], dd['pcr']]
    a, alo, ahi, ap = contrast(G, [-1,1,0]); b, blo, bhi, bp = contrast(G, [-1,0,1])
    rows.append(dict(design='WT MKs in vitro: creatine vs phosphocreatine (4h)', gene=g, induction_log2=a, ind_p=ap, residual_log2=b, res_p=bp))
data = grab('Fig. 4l', ['ev','oe'])
for g in genes:
    dd = data[g]; G = [dd['ev'], dd['oe']]
    a, alo, ahi, ap = contrast(G, [-1,1])
    rows.append(dict(design='CKB-OE vs EV (4l)', gene=g, induction_log2=a, ind_p=ap))
data = grab('Fig. 2f', ['veh','cre'])
for g in genes:
    dd = data[g]; G = [dd['veh'], dd['cre']]
    a, alo, ahi, ap = contrast(G, [-1,1])
    rows.append(dict(design='WT MKs from treated mice (2f)', gene=g, induction_log2=a, ind_p=ap))
df = pd.DataFrame(rows); df.to_csv('program.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300); pd.set_option('display.max_columns', 30)
for name, sub in df.groupby('design', sort=False):
    print('\n##', name)
    cols = [c for c in ['gene','induction_log2','ind_p','residual_log2','res_p','baseline_shift_log2','base_p','interaction_log2','int_p','pertcre_vs_ctl_log2','abs_p','cre_ko_vs_cre_wt_log2','diff_p','pct_remaining'] if c in sub and sub[c].notna().any()]
    t = sub[cols].copy()
    for c in cols:
        if c.endswith('log2'): t[c.replace('_log2','_fold')] = 2**t[c]
    show = ['gene'] + [c for c in t.columns if c.endswith('_fold')] + [c for c in cols if c.endswith('_p')] + (['pct_remaining'] if 'pct_remaining' in cols else [])
    print(t[show].round(3).to_string(index=False))
    if 'residual_log2' in cols and 'interaction_log2' in cols:
        print('   median fold induction (control bg): %.2f; median residual fold induction (perturbed bg): %.2f; median %% remaining (log scale): %.0f%%; genes with residual induction p<0.05: %d/11; genes with significant interaction: %d/11; genes where perturbation lowers baseline p<0.05: %d/11' % (2**sub.induction_log2.median(), 2**sub.residual_log2.median(), sub.pct_remaining.median(), ((sub.res_p<0.05)&(sub.residual_log2>0)).sum(), (sub.int_p<0.05).sum(), ((sub.base_p<0.05)&(sub.baseline_shift_log2<0)).sum()))
    if 'cre_ko_vs_cre_wt_log2' in cols:
        print('   median fold induction WT: %.2f; median cKO+cre vs WT-veh: %.2f; median %% remaining: %.0f%%; genes still > WT-veh at p<0.05: %d/11; genes below WT-veh p<0.05: %d/11' % (2**sub.induction_log2.median(), 2**sub.pertcre_vs_ctl_log2.median(), sub.pct_remaining.median(), ((sub.abs_p<0.05)&(sub.pertcre_vs_ctl_log2>0)).sum(), ((sub.abs_p<0.05)&(sub.pertcre_vs_ctl_log2<0)).sum()))
