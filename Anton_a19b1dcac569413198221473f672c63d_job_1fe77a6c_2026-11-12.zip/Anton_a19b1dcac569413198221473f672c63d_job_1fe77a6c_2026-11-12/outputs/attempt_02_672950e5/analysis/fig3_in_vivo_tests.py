import numpy as np
from figstyle import *
from wb import *
rng = np.random.default_rng(3)
def strip(ax, groups, labels, colors, flagged=None):
    for i, (g, c) in enumerate(zip(groups, colors)):
        x = i + rng.uniform(-0.13, 0.13, len(g))
        fl = flagged[i] if flagged else [False]*len(g)
        for xx, yy, f in zip(x, g, fl):
            ax.scatter(xx, yy, s=15, color=c, edgecolor='k' if not f else RED, linewidth=0.4 if not f else 1.2, marker='o' if not f else 'D', zorder=3)
        ax.hlines(np.mean(g), i-0.25, i+0.25, color='k', lw=1.1, zorder=4)
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(labels, fontsize=5.8)
    ax.set_ylabel('Lung metastatic burden (%)'); ax.spines[['top','right']].set_visible(False); ax.set_ylim(bottom=0)
fig, axes = plt.subplots(2, 2, figsize=(WIDTH, 5.5))
cV, cC = LIGHT, ORANGE
g = [col('Fig. 3i', c, 10, 13) for c in 'BCDE']
strip(axes[0,0], g, ['Slc6a8 +/+\nvehicle','Slc6a8 +/+\ncreatine','Slc6a8 fl/fl\nvehicle','Slc6a8 fl/fl\ncreatine'], [cV,cC,cV,cC])
axes[0,0].set_title('A. MK-lineage Slc6a8 deletion (Fig. 3i; n = 4 per group)\ncreatine ×3.6 in controls, ×0.8 in knockout; interaction p = 0.0009', fontsize=6.5)
g = [col('Fig. 6b', c, 4, 8) for c in 'BCDE']
flag = [[False,True,True,True,False],[False,True,True,True,False],[False]*5,[False]*5]
strip(axes[0,1], g, ['vehicle','creatine','vehicle +\nSTAT5-IN-1','creatine +\nSTAT5-IN-1'], [cV,cC,cV,cC], flag)
axes[0,1].set_title('B. Systemic STAT5A/B inhibitor (Fig. 6b; n = 5 per group)\ncreatine ×4.1 without, ×1.3 with inhibitor; interaction p = 0.0004', fontsize=6.5)
g = [col('Fig. 1f', c, 22, 27) for c in 'BCDE']
strip(axes[1,0], g, ['sh-scrambled\nvehicle','sh-scrambled\ncreatine','sh-Slc6a8\nvehicle','sh-Slc6a8\ncreatine'], [cV,cC,cV,cC])
axes[1,0].set_title('C. Slc6a8 knock-down in the melanoma cells (Fig. 1f; n = 6 per group)\ncreatine ×4.1 and ×3.2; interaction p = 0.44', fontsize=6.5)
g = [col('Supplementary Fig  2d', c, 5, 10) for c in 'CDE']
flag = [[False,False,False,True,True,True],[False,False,False,True,True,True],[False]*6]
strip(axes[1,1], g, ['platelets from\nvehicle donors','platelets from\ncreatine donors','platelets from creatine\n+ aspirin donors'], [cV,cC,'#2e86c1'], flag)
axes[1,1].set_title('D. Platelet transfer (Supp. Fig. 2d; n = 6 recipients per group)\ncreatine-donor platelets ×3.3; lost when donors also had aspirin', fontsize=6.5)
fig.text(0.5, 0.0, 'Bars are group means. Red-outlined diamonds are the six records (burden and foci) that are identical in Fig. 6b and Supp. Fig. 2d.\nRatios are geometric-mean ratios; interactions are tested on ln(burden).', ha='center', va='bottom', fontsize=5.8, color='#444')
fig.tight_layout(rect=(0, 0.045, 1, 1), h_pad=1.2, w_pad=1.0)
fig.savefig('../figures/figure3_in_vivo_tests.png', bbox_inches='tight', pad_inches=0.03)
