import numpy as np, pandas as pd, scipy.stats as st
from figstyle import *
from matplotlib.colors import TwoSlopeNorm
from wb import *
H = np.load('human_agg.npy', allow_pickle=True).item()
fig = plt.figure(figsize=(WIDTH, 5.9))
gs = fig.add_gridspec(2, 4, height_ratios=[1, 1.05], hspace=0.5, wspace=0.45, left=0.075, right=0.985, top=0.9, bottom=0.075)
agon = [('collagen','Collagen'),('EPI','Epinephrine'),('AA','Arachidonic acid'),('ADP','ADP')]
for k, (key, name) in enumerate(agon):
    ax = fig.add_subplot(gs[0, k]); arr = H[(key,'max')]
    for i in range(arr.shape[0]): ax.plot(range(4), arr[i], color=LIGHT, lw=0.6, marker='o', ms=1.6, alpha=0.95)
    gm = [1]+[np.exp(np.mean(np.log(arr[:,j]))) for j in (1,2,3)]
    ax.plot(range(4), gm, color=RED, lw=1.5, marker='D', ms=3, label='geometric mean')
    ax.set_yscale('log'); ax.set_yticks([0.125,0.25,0.5,1,2,4,8]); ax.set_yticklabels(['0.125','0.25','0.5','1','2','4','8']); ax.minorticks_off()
    ax.set_ylim(0.1, 14); ax.axhline(1, color='k', lw=0.4, ls='--'); ax.set_xticks(range(4)); ax.set_xticklabels(['d0','d3','d7','d14'])
    fc = arr[:,3]; w = st.wilcoxon(fc-1).pvalue; l = np.log2(fc); n = len(l)
    lo, hi = 2**(l.mean()-st.t.ppf(0.975,n-1)*l.std(ddof=1)/np.sqrt(n)), 2**(l.mean()+st.t.ppf(0.975,n-1)*l.std(ddof=1)/np.sqrt(n))
    ax.set_title(f'{name}\nday 14: ×{2**l.mean():.2f} ({lo:.2f}–{hi:.2f})\n{int((fc>1).sum())} of 11 up; p = {w:.3f}', fontsize=6.3)
    if k == 0: ax.set_ylabel('Maximal aggregation,\nfold of own day 0 (log scale)'); ax.legend(frameon=False, loc='upper left', fontsize=5.3, handlelength=1.5)
    ax.spines[['top','right']].set_visible(False)
ax = fig.add_subplot(gs[1, 0])
M = np.array([row('Fig. 7b', r, 'B', 'E') for r in range(4, 15)])
for i in range(M.shape[0]): ax.plot(range(4), M[i], color=LIGHT, lw=0.6, marker='o', ms=1.6)
ax.plot(range(4), M.mean(0), color=RED, lw=1.5, marker='D', ms=3)
ax.set_xticks(range(4)); ax.set_xticklabels(['d0','d3','d7','d14']); ax.set_ylabel('Serum creatine (µM)')
ax.set_title(f'Serum creatine (n = 11)\n{M.mean(0)[0]:.0f} → {M.mean(0)[3]:.0f} µM (×{M.mean(0)[3]/M.mean(0)[0]:.1f})', fontsize=6.3); ax.spines[['top','right']].set_visible(False); ax.set_ylim(0, 230)
ax = fig.add_subplot(gs[1, 1])
G = np.array([row('Fig. 7e', r, 'B', 'E') for r in range(4, 8)]); P = np.array([row('Fig. 7e', r, 'B', 'E') for r in range(12, 16)])
for i in range(4):
    ax.plot(np.arange(4), G[i]/G[i,0], color=ORANGE, lw=0.7, marker='o', ms=2, label='GP6' if i==0 else None)
    ax.plot(np.arange(4)+4.7, P[i]/P[i,0], color=BLUE, lw=0.7, marker='s', ms=2, label='P2RY12' if i==0 else None)
ax.axhline(1, color='k', lw=0.4, ls='--'); ax.set_yscale('log'); ax.set_yticks([0.5,1,2,4]); ax.set_yticklabels(['0.5','1','2','4']); ax.minorticks_off()
ax.set_xticks(list(range(4))+[4.7,5.7,6.7,7.7]); ax.set_xticklabels(['d0','3','7','14','d0','3','7','14'], fontsize=5.3)
ax.set_ylabel('Platelet protein / β-actin,\nfold of own day 0'); ax.legend(frameon=False, loc='upper left', fontsize=5.3, handlelength=1.2)
gg = np.exp(np.mean(np.log(G[:,3]/G[:,0]))); pp = np.exp(np.mean(np.log(P[:,3]/P[:,0])))
ax.set_title(f'Platelet protein (n = 4)\nday 14: GP6 ×{gg:.1f}, P2RY12 ×{pp:.1f}', fontsize=6.3); ax.spines[['top','right']].set_visible(False)
ax = fig.add_subplot(gs[1, 2:])
q = pd.read_csv('human_qpcr.csv')
order = ['ITGA2B','P2RY12','GP6','GPIBA','F2R','ADAR2A','FCGR2A','RUNX1','RAB4A','RAB27B','PITPNB']
piv = q.pivot_table(index='gene', columns=['day','vol'], values='reported').loc[order]
L = np.log2(piv.values)
im = ax.imshow(L, cmap='RdBu_r', norm=TwoSlopeNorm(vmin=-3, vcenter=0, vmax=5), aspect='auto')
ax.set_yticks(range(len(order))); ax.set_yticklabels([g if g != 'ADAR2A' else 'ADRA2A*' for g in order], fontsize=5.4, style='italic')
ax.set_xticks(range(12)); ax.set_xticklabels([f'V{v}' for d in (3,7,14) for v in (1,2,3,4)], fontsize=5.3); ax.tick_params(length=0)
for j, d in enumerate(['day 3','day 7','day 14']): ax.text(1.5+4*j, -0.75, d, ha='center', fontsize=6, fontweight='bold')
ax.axvline(3.5, color='k', lw=0.8); ax.axvline(7.5, color='k', lw=0.8)
for i in range(L.shape[0]):
    for j in range(L.shape[1]):
        val = piv.values[i,j]; flag = (order[i] in ('PITPNB','RAB27B') and (j % 4) == 3)
        ax.text(j, i, (f'{val:.1f}' if val < 10 else f'{val:.0f}') + ('†' if flag else ''), ha='center', va='center', fontsize=4.9, color='white' if (L[i,j] > 3 or L[i,j] < -2) else 'black')
ax.set_title('CD41-positive cells, qPCR, 4 volunteers\n(fold of own day 0)', fontsize=6.3, pad=11)
fig.text(0.5, 0.003, 'Grey lines are individual volunteers. p: Wilcoxon signed-rank test of the day-14 fold change against 1 (paired re-analysis).  * Headed "ADAR2A" in the source sheet.\n† The normalized value in the sheet cannot be reproduced from the listed ΔCt values (volunteer 4, RAB27B and PITPNB).', ha='center', va='bottom', fontsize=5.5, color='#444')
fig.savefig('../figures/figure6_human_cohort.png', bbox_inches='tight', pad_inches=0.03)
