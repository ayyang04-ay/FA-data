"""Write the supporting tables that are not produced by the other scripts."""
import pandas as pd, numpy as np
from statsmodels.stats.multitest import multipletests
q = pd.read_csv('qpcr.csv')
q2 = q[['sheet','gene','group','ctrl','fold_geo','fold_rep_mean','p_dct','max_abs_dev_rep']].copy()
q2.columns = ['sheet','gene','group','control_group','fold_geometric_mean','fold_mean_as_in_sheet','p_ttest_on_dCt','max_abs_deviation_from_sheet_fold']
q2.to_csv('../tables/qpcr_mk_panels_recomputed.csv', index=False)
pd.read_csv('program.csv').to_csv('../tables/mk_gene_program_blockade_contrasts.csv', index=False)
df = pd.read_csv('phospho.csv'); df.columns = ['gene','p','q','log_fc']
df['bh_adjusted_p'] = multipletests(df.p, method='fdr_bh')[1]
df['rank_by_p'] = df.p.rank(method='min').astype(int)
df['passes_screening_rule'] = (df.p < 0.05) & ((2**df.log_fc >= 1.2) | (2**df.log_fc <= 0.83))
df.sort_values('p').head(250).to_csv('../tables/phosphoproteomics_top250_by_p.csv', index=False)
pd.read_csv('human_agg_stats.csv').to_csv('../tables/human_platelet_function_paired_reanalysis.csv', index=False)
pd.read_csv('human_qpcr.csv').to_csv('../tables/human_cd41_qpcr_recomputed.csv', index=False)
print('tables written')
