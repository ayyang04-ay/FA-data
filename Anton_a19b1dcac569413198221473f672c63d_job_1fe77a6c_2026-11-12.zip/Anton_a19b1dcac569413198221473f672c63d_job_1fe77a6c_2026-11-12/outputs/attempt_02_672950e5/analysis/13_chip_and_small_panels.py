import numpy as np, pandas as pd, scipy.stats as st
import statsmodels.formula.api as smf, statsmodels.api as sm
from wb import *
import warnings; warnings.filterwarnings('ignore')
def sidak_twoway(sheet, rows, vcols, ccols, labels, title, rep_cells):
    recs = []
    for r, lab in zip(rows, labels):
        for x in row(sheet, r, *vcols): recs.append(dict(region=lab, trt='veh', y=x))
        for x in row(sheet, r, *ccols): recs.append(dict(region=lab, trt='cre', y=x))
    df = pd.DataFrame(recs)
    m = smf.ols('y ~ C(region)*C(trt)', df).fit()
    mse = m.mse_resid; dfr = m.df_resid
    an = sm.stats.anova_lm(m, typ=2)
    print(f'\n{title}: two-way ANOVA  region p={an.loc["C(region)","PR(>F)"]:.3g}, creatine p={an.loc["C(trt)","PR(>F)"]:.3g}, interaction p={an.loc["C(region):C(trt)","PR(>F)"]:.3g}; MSE={mse:.3f} df={dfr:.0f}')
    k = len(labels)
    for lab in labels:
        a = df[(df.region==lab)&(df.trt=='veh')].y.values; b = df[(df.region==lab)&(df.trt=='cre')].y.values
        diff = a.mean()-b.mean(); se = np.sqrt(mse*(1/len(a)+1/len(b)))
        t = diff/se; p = 2*st.t.sf(abs(t), dfr); padj = 1-(1-p)**k
        # Sidak CI
        alpha_adj = 1-(1-0.05)**(1/k); tc = st.t.ppf(1-alpha_adj/2, dfr)
        pt = st.ttest_ind(a,b).pvalue
        print(f'   {lab:5s} veh {a.mean():6.2f} (n={len(a)}) cre {b.mean():6.2f} fold {b.mean()/a.mean():5.2f}  diff {diff:7.3f} CI[{diff-tc*se:.3f},{diff+tc*se:.3f}] Sidak p={padj:.4g} | simple t-test p={pt:.4g} | vals veh {np.round(a,2)} cre {np.round(b,2)}')
    print('   REPORTED:', [ (v(sheet, c[0]), v(sheet, c[1]), v(sheet, c[2])) for c in rep_cells])
sidak_twoway('Fig. 5j', [5,6,7,8], ('B','D'), ('E','G'), ['Exon','2K','1K','0.2K'], 'Fig 5j P2ry12 ChIP (% input)', [('I7','J7','N7'),('I8','J8','N8'),('I9','J9','N9'),('I10','J10','N10')])
sidak_twoway('Fig. 5j', [15,16,17,18], ('B','D'), ('E','G'), ['Exon','2K','1K','0.2K'], 'Fig 5j Gp6 ChIP (% input)', [('I17','J17','N17'),('I18','J18','N18'),('I19','J19','N19'),('I20','J20','N20')])
sidak_twoway('Supplementary Fig  6i', [7,8,9,10], ('C','E'), ('F','H'), ['Exon','2K','1K','0.2K'], 'Supp 6i Rab4a ChIP (% input)', [('J10','K10','O10'),('J11','K11','O11'),('J12','K12','O12'),('J13','K13','O13')])

# Fig 2b, 3b, 3c, 1h, S1a t-tests
print('\nFig 2b aggregation (n=3 v 3):')
for r, lab, pc in [(4,'ADP','B18'),(5,'Collagen','B32'),(6,'Thrombin','B45')]:
    a = row('Fig. 2b', r, 'B','D'); b = row('Fig. 2b', r, 'E','G'); t,p = st.ttest_ind(a,b)
    print(f'  {lab}: veh {a} mean {a.mean():.1f} -> cre {b} mean {b.mean():.1f} (+{b.mean()-a.mean():.1f} points; x{b.mean()/a.mean():.2f}); p={p:.4g}; reported {v("Fig. 2b", pc)}')
print('Fig 3b serum creatine:')
for r, lab, pc in [(4,'WT','B17'),(5,'cKO','B31')]:
    a = row('Fig. 3b', r, 'B','F'); b = row('Fig. 3b', r, 'G','K'); t,p = st.ttest_ind(a,b)
    print(f'  {lab}: {a.mean():.1f} -> {b.mean():.1f} x{b.mean()/a.mean():.2f} p={p:.3g} reported {v("Fig. 3b", pc)}')
print('Fig 3c MK creatine:')
for r, lab, pc in [(4,'WT','B15'),(5,'cKO','B30')]:
    a = row('Fig. 3c', r, 'B','D'); b = row('Fig. 3c', r, 'E','G'); t,p = st.ttest_ind(a,b)
    print(f'  {lab}: {a.mean():.1f} -> {b.mean():.1f} x{b.mean()/a.mean():.2f} p={p:.3g} reported {v("Fig. 3c", pc)}')
print('Fig 1h time course:')
for r, lab, pc in [(4,'0.25h','B17'),(5,'6h','E17'),(6,'12h','H17'),(7,'24h','K17')]:
    a = row('Fig. 1h', r, 'B','G'); b = row('Fig. 1h', r, 'H','M'); t,p = st.ttest_ind(a,b)
    print(f'  {lab}: veh {a.mean():.3f} (sd {a.std(ddof=1):.2f}) -> cre {b.mean():.3f} (sd {b.std(ddof=1):.2f}) x{b.mean()/a.mean():.2f} p={p:.4g} reported {v("Fig. 1h", pc)}')
print('Supp 1a body weight:')
for r, lab, pc in [(4,'0 d','M11'),(5,'7 d','M25')]:
    a = row('Supplementary Fig  1a', r, 'B','E'); b = row('Supplementary Fig  1a', r, 'F','I'); t,p = st.ttest_ind(a,b)
    print(f'  {lab}: veh {a.mean():.2f} -> cre {b.mean():.2f} p={p:.4g} reported {v("Supplementary Fig  1a", pc)}')
# Fig 4e Ckb mRNA; S2a; S5a; S8c
a = row('Fig. 4e', 8, 'E','G'); b = row('Fig. 4e', 8, 'I','K'); print('Fig 4e Ckb mRNA: ctrl', a.round(2), 'cre', b.round(2), 'fold', b.mean()/a.mean(), 'p', st.ttest_ind(a,b).pvalue, 'reported', v('Fig. 4e','O5'))
a = row('Supplementary Fig  2a', 7, 'D','F'); b = row('Supplementary Fig  2a', 7, 'H','J'); print('S2a Slc6a8 mRNA KD: ctrl', a.round(2), 'KD', b.round(2), 'remaining', b.mean()/a.mean(), 'p', st.ttest_ind(a,b).pvalue, 'reported', v('Supplementary Fig  2a','M4'))
for gene, r in [('Gatm',6),('Gamt',9)]:
    a = row('Supplementary Fig  5a', r, 'C','E'); b = row('Supplementary Fig  5a', r, 'G','I'); print(f'S5a {gene}: veh', a.round(2), 'cre', b.round(2), 'fold', (b.mean()/a.mean()).round(2), 'p', st.ttest_ind(a,b).pvalue)
a = row('Supplementary Fig  8c', 9, 'E','G'); b = row('Supplementary Fig  8c', 9, 'I','K'); c = row('Supplementary Fig  8c', 9, 'M','O')
print('S8c CD41 mRNA: CD41+ cells', a.round(3), 'monocytes', b.round(3), 'MEG-01', c.round(3)); print('  monocyte/CD41+ =', b.mean()/a.mean(), ' -> CD41+ fraction has', a.mean()/b.mean(), 'x more ITGA2B than monocytes; MEG-01/CD41+ =', c.mean()/a.mean())
