import numpy as np, scipy.stats as st
H = np.load('human_agg.npy', allow_pickle=True).item()
from scipy.stats import nct, t as tdist
def n_paired(delta, sd, power=0.9, alpha=0.05):
    for n in range(4, 400):
        dfree = n-1; ncp = delta/(sd/np.sqrt(n)); tc = tdist.ppf(1-alpha/2, dfree)
        pw = 1 - nct.cdf(tc, dfree, ncp) + nct.cdf(-tc, dfree, ncp)
        if pw >= power: return n
    return None
for key in [('collagen','max'),('EPI','max'),('EPI','avg'),('AA','max'),('ADP','max')]:
    fc = H[key][:,3]
    l = np.log2(fc)
    m, s = l.mean(), l.std(ddof=1)
    # crossover: difference of two period changes -> SD*sqrt(2) (conservative: assume placebo-period change has same SD, independent)
    print(f'{key}: day-14 log2FC mean {m:.2f} (x{2**m:.2f}), SD {s:.2f}; dz={m/s:.2f}; single-arm paired n(90%)={n_paired(m,s)}; crossover vs placebo n(90%) for full effect={n_paired(m, s*np.sqrt(2))}, for half the effect={n_paired(m/2, s*np.sqrt(2))}')
