import numpy as np, scipy.stats as st
from wb import *
for lab, r0 in [('GP6/ACTB',4),('P2RY12/ACTB',12)]:
    M = np.array([row('Fig. 7e', r, 'B', 'E') for r in range(r0, r0+4)])
    print(lab); print(M)
    for j, day in enumerate([3,7,14], start=1):
        fc = M[:,j]/M[:,0]
        l = np.log2(fc); t,p = st.ttest_1samp(l,0)
        tp, pp = st.ttest_rel(M[:,j], M[:,0])
        print(f'  day {day}: FC per volunteer {np.round(fc,2)}; gmean {2**l.mean():.2f}; n_up {(fc>1).sum()}/4; paired t (raw) p={pp:.4f}; one-sample t log2FC p={p:.4f}')
    # reported: Tukey on independent groups
    res = st.tukey_hsd(*[M[:,j] for j in range(4)])
    print('  Tukey (as reported) p 0v3,0v7,0v14:', np.round(res.pvalue[0,1:],4))
    # RM-ANOVA-like: Friedman
    print('  Friedman p =', st.friedmanchisquare(*[M[:,j] for j in range(4)]).pvalue)
# Fig 7b serum creatine
M = np.array([row('Fig. 7b', r, 'B', 'E') for r in range(4, 15)])
print('Fig 7b serum creatine (uM) n=', M.shape[0]); print('  means', M.mean(0).round(1), 'sd', M.std(0, ddof=1).round(1), 'fold vs d0', (M.mean(0)/M.mean(0)[0]).round(2))
for j, day in enumerate([3,7,14], start=1):
    t,p = st.ttest_rel(M[:,j], M[:,0]); print(f'  day {day}: paired t p={p:.2e}; per-volunteer fold range {np.round((M[:,j]/M[:,0]).min(),2)}-{np.round((M[:,j]/M[:,0]).max(),2)}; all up: {(M[:,j]>M[:,0]).all()}')
res = st.tukey_hsd(*[M[:,j] for j in range(4)]); print('  Tukey as reported:', res.pvalue[0,1:])
# Supp 8b human CBC
for lab, r0 in [('PLT',4),('PCT',19),('MPV',33),('PDW',48)]:
    M = np.array([row('Supplementary Fig  8b', r, 'B', 'E') for r in range(r0, r0+11)])
    ps = [st.ttest_rel(M[:,j], M[:,0]).pvalue for j in (1,2,3)]
    print(f'S8b {lab}: n={M.shape[0]} means {M.mean(0).round(2)} paired p {np.round(ps,3)}')
# Supp 8a BMI paired
a = col('Supplementary Fig  8a','C',4,14); b = col('Supplementary Fig  8a','D',4,14)
print('S8a BMI paired t p=', st.ttest_rel(a,b).pvalue, 'mean diff', (b-a).mean(), 'BMI d0 mean', a.mean(), 'sd', a.std(ddof=1), 'range', a.min(), a.max())
