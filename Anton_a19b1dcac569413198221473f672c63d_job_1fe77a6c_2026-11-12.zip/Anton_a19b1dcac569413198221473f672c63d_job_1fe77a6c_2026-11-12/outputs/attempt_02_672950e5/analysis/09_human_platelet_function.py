import json, numpy as np, pandas as pd, scipy.stats as st, re, itertools
C = json.load(open('cells.json'))
d = C['Fig. 7c']
rows = sorted(set(int(re.sub(r'[A-Z]+','',k)) for k in d))
ag = None; metric = None; blocks = {}
for r in rows:
    a = d.get(f'A{r}')
    if isinstance(a, str):
        s = a.strip()
        if s in ('collagen','EPI','AA','ADP'):
            ag = s
        if s.startswith('Relative'):
            metric = 'max' if 'maximum' in s else ('avg' if 'average' in s else 'adhesion')
    b, c, dd, e = (d.get(f'{x}{r}') for x in 'BCDE')
    if all(isinstance(x,(int,float)) for x in (b,c,dd,e)):
        blocks.setdefault((ag, metric), []).append((b,c,dd,e))
    # header-on-same-row case handled because label parsed before the data check
res = []
H = {}
for k, vals in blocks.items():
    arr = np.array(vals, float)
    H[k] = arr
    print(k, arr.shape, 'baseline all 1:', np.all(arr[:,0]==1))
np.save('human_agg.npy', H, allow_pickle=True)

def onesample(fc):
    fc = np.asarray(fc, float)
    n = len(fc)
    up = int((fc>1).sum()); dn = int((fc<1).sum())
    # Wilcoxon signed-rank on fc-1 (handles zeros in fc)
    try:
        w = st.wilcoxon(fc-1, alternative='two-sided').pvalue
    except Exception:
        w = np.nan
    # sign test
    sg = st.binomtest(up, up+dn, 0.5).pvalue if (up+dn)>0 else np.nan
    # paired t on log2 (if no zeros)
    if np.all(fc>0):
        l = np.log2(fc); t, p = st.ttest_1samp(l, 0); gm = 2**l.mean()
        lo, hi = 2**(l.mean()-st.t.ppf(0.975,n-1)*l.std(ddof=1)/np.sqrt(n)), 2**(l.mean()+st.t.ppf(0.975,n-1)*l.std(ddof=1)/np.sqrt(n))
    else:
        p = np.nan; gm = np.nan; lo=hi=np.nan
    # one-sample t on raw fc vs 1
    t2, p2 = st.ttest_1samp(fc, 1)
    return dict(n=n, mean=fc.mean(), median=np.median(fc), gmean=gm, gm_lo=lo, gm_hi=hi, n_up=up, n_down=dn, p_wilcoxon=w, p_sign=sg, p_t_log=p, p_t_raw=p2, max=fc.max())

out = []
for (ag, metric), arr in H.items():
    for j, day in enumerate([3,7,14], start=1):
        r = onesample(arr[:,j]); r.update(agonist=ag, metric=metric, day=day)
        out.append(r)
df = pd.DataFrame(out)[['agonist','metric','day','n','mean','median','gmean','gm_lo','gm_hi','n_up','n_down','p_wilcoxon','p_sign','p_t_log','p_t_raw','max']]
# multiplicity: Holm across the 12 day-14 tests and across all 36
from statsmodels.stats.multitest import multipletests
df['p_wilcoxon_holm36'] = multipletests(df.p_wilcoxon.fillna(1), method='holm')[1]
df['p_wilcoxon_bh36'] = multipletests(df.p_wilcoxon.fillna(1), method='fdr_bh')[1]
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 30)
print(df.round(4).to_string())
df.to_csv('human_agg_stats.csv', index=False)

# reproduce the reported Dunnett (independent groups on fold change) for the record
print('\nReported-style Dunnett (treating groups as independent):')
for (ag, metric), arr in H.items():
    try:
        r = st.dunnett(arr[:,1], arr[:,2], arr[:,3], control=arr[:,0])
        print(f'  {ag:9s} {metric:9s} p(3,7,14) = {np.round(r.pvalue,4)}')
    except Exception as ex:
        print('  ', ag, metric, 'ERR', ex)

# Volunteer-level responder map at day 14 (max aggregation), to see whether the same people respond across agonists
print('\nDay-14 fold change per volunteer (rows = volunteer index as listed in each block; order assumed consistent across blocks — NOT verifiable from the file):')
tab = pd.DataFrame({f'{ag}-{m}': H[(ag,m)][:,3] for ag in ['collagen','EPI','AA','ADP'] for m in ['max','avg','adhesion']})
print(tab.round(2).to_string())
print('\nSpearman correlations between agonists (day 14 max agg) across volunteers:')
mx = pd.DataFrame({ag: H[(ag,'max')][:,3] for ag in ['collagen','EPI','AA','ADP']})
print(mx.corr(method='spearman').round(2))
print('\nDay-7:')
tab7 = pd.DataFrame({f'{ag}-{m}': H[(ag,m)][:,2] for ag in ['collagen','EPI','AA','ADP'] for m in ['max','avg','adhesion']})
print(tab7.round(2).to_string())
