"""Export the two workbooks to flat files used by the other scripts.
Run with an environment that has openpyxl and pandas (here: micromamba env 'chem')."""
import json, os, openpyxl, pandas as pd
DATA = os.environ.get('CRE_DATA_DIR', '/tmp/world/filesystem')
wb = openpyxl.load_workbook(f'{DATA}/CRE-MK-01_source_data.xlsx', data_only=True)
out = {}
for ws in wb.worksheets:
    d = {}
    for r in ws.iter_rows():
        for c in r:
            if c.value is not None:
                d[c.coordinate] = c.value
    out[ws.title] = d
json.dump(out, open('cells.json', 'w'))
df = pd.read_excel(f'{DATA}/CRE-MK-01_phosphoproteomics.xlsx', sheet_name=0)
df.to_csv('phospho.csv', index=False)
print('exported', len(out), 'sheets and', len(df), 'phosphoproteomics rows')
