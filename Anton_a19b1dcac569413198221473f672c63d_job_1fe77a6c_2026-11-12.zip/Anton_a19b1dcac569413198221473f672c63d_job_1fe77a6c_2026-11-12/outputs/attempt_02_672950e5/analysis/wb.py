import openpyxl, numpy as np, re
from openpyxl.utils import column_index_from_string, get_column_letter
import os
F = os.environ.get('CRE_DATA_DIR', '/tmp/world/filesystem') + '/CRE-MK-01_source_data.xlsx'
_wb = openpyxl.load_workbook(F, data_only=True)
_wbf = openpyxl.load_workbook(F, data_only=False)
SHEETS = _wb.sheetnames

def S(name):
    return _wb[name]

def v(sheet, cell):
    return _wb[sheet][cell].value

def col(sheet, c, r0, r1):
    ws = _wb[sheet]
    out = []
    for r in range(r0, r1+1):
        x = ws[f'{c}{r}'].value
        if x is None or isinstance(x, str):
            continue
        out.append(float(x))
    return np.array(out)

def row(sheet, r, c0, c1):
    ws = _wb[sheet]
    out = []
    for ci in range(column_index_from_string(c0), column_index_from_string(c1)+1):
        x = ws.cell(row=r, column=ci).value
        if x is None or isinstance(x, str):
            continue
        out.append(float(x))
    return np.array(out)

def cells(sheet):
    ws = _wb[sheet]
    d = {}
    for r in ws.iter_rows():
        for c in r:
            if c.value is not None:
                d[c.coordinate] = c.value
    return d
