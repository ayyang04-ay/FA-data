import numpy as np, pandas as pd, scipy.stats as st
from figstyle import *
from wb import *
exps = [
 ('Fig. 1b (n=6/6)', 'Fig. 1b', ('B',3,8), ('C',3,8), ('B',12,17), ('C',12,17)),
 ('Fig. 1k (n=6/6)', 'Fig. 1k', ('B',4,9), ('C',4,9), ('B',12,17), ('C',12,17)),
 ('Fig. 1f, sh-scrambled melanoma (n=6/6)', 'Fig. 1f', ('B',22,27), ('C',22,27), ('B',31,36), ('C',31,36)),
 ('Fig. 3i, Pf4-Cre;Slc6a8+/+ hosts (n=4/4)', 'Fig. 3i', ('B',10,13), ('C',10,13), ('B',17,20), ('C',17,20)),
 ('Fig. 6b, no-inhibitor arms (n=5/5)', 'Fig. 6b', ('B',4,8), ('C',4,8), ('B',13,17), ('C',13,17)),
 ('Supp. Fig. 1e (n=6/6)', 'Supplementary Fig  1e', ('B',13,18), ('C',13,18), ('B',22,27), ('C',22,27)),
 ('Supp. Fig. 1f (n=4/4)', 'Supplementary Fig  1f', ('B',12,15), ('C',12,15), ('B',20,23), ('C',20,23)),
 ('Supp. Fig. 1g (n=10/10)', 'Supplementary Fig  1g', ('B',15,24), ('C',15,24), ('B',28,37), ('C',28,37)),
 ('Supp. Fig. 1i, 5% creatine diet (n=4/4)', 'Supplementary Fig  1i', ('B',11,14), ('C',11,14), ('B',18,21), ('C',18,21)),
 ('Supp. Fig. 1k (n=10/10)', 'Supplementary Fig  1k', ('B',16,25), ('C',16,25), ('B',29,38), ('C',29,38)),
]
rows = []
for name, sh, A, B, FA, FB in exps:
    for lab, (a_, b_) in [('burden',(A,B)),('foci',(FA,FB))]:
        a = np.log(col(sh,*a_)); b = np.log(col(sh,*b_))
        n1, n2 = len(a), len(b); sp2 = ((n1-1)*a.var(ddof=1)+(n2-1)*b.var(ddof=1))/(n1+n2-2)
        d = b.mean()-a.mean(); se = np.sqrt(sp2*(1/n1+1/n2)); tc = st.t.ppf(0.975, n1+n2-2)
        rows.append(dict(exp=name, measure=lab, n_vehicle=n1, n_creatine=n2, gm_ratio=np.exp(d), lo=np.exp(d-tc*se), hi=np.exp(d+tc*se), lnr=d, se=se, sd_ln_pooled=np.sqrt(sp2), p=2*st.t.sf(abs(d/se), n1+n2-2)))
df = pd.DataFrame(rows)
def dl(sub):
    y = sub.lnr.values; v_ = sub.se.values**2; w = 1/v_
    ybar = (w*y).sum()/w.sum(); Q = (w*(y-ybar)**2).sum(); k = len(y)
    tau2 = max(0, (Q-(k-1))/(w.sum()-(w**2).sum()/w.sum()))
    wr = 1/(v_+tau2); mu = (wr*y).sum()/wr.sum(); se = np.sqrt(1/wr.sum())
    I2 = max(0,(Q-(k-1))/Q) if Q>0 else 0
    # prediction interval
    tcrit = st.t.ppf(0.975, k-2); pi = (np.exp(mu-tcrit*np.sqrt(tau2+se**2)), np.exp(mu+tcrit*np.sqrt(tau2+se**2)))
    return np.exp(mu), np.exp(mu-1.96*se), np.exp(mu+1.96*se), tau2, I2, k, pi
pd.set_option('display.width', 200)
print(df.round(3).to_string())
res = {}
for m in ['burden','foci']:
    sub = df[df.measure==m]; res[m] = dl(sub)
    print(m, 'pooled GM ratio %.2f (%.2f-%.2f), tau2=%.3f, I2=%.0f%%, k=%d, 95%% prediction interval %.2f-%.2f' % (res[m][0], res[m][1], res[m][2], res[m][3], 100*res[m][4], res[m][5], res[m][6][0], res[m][6][1]))
    print('   all p<0.01:', (sub.p<0.01).all(), ' max p', sub.p.max(), ' SD ln: median %.2f, range %.2f-%.2f' % (sub.sd_ln_pooled.median(), sub.sd_ln_pooled.min(), sub.sd_ln_pooled.max()))
print('animals:', df[df.measure=="burden"].n_vehicle.sum(), '+', df[df.measure=="burden"].n_creatine.sum())
df.drop(columns=['lnr','se']).to_csv('../tables/creatine_effect_by_experiment.csv', index=False)
fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 3.0), sharey=True)
for ax, m, title in zip(axes, ['burden','foci'], ['Lung metastatic burden (%)','Number of metastatic foci']):
    sub = df[df.measure==m].reset_index(drop=True); k = len(sub); y = np.arange(k)[::-1]+1
    ax.errorbar(sub.gm_ratio, y, xerr=[sub.gm_ratio-sub.lo, sub.hi-sub.gm_ratio], fmt='s', color=BLUE, ecolor=BLUE, capsize=1.8, ms=3.2, lw=0.9)
    mu, lo, hi, tau2, I2, kk, pi = res[m]
    ax.errorbar([mu], [0], xerr=[[mu-lo],[hi-mu]], fmt='D', color=RED, ecolor=RED, capsize=2.2, ms=4.5, lw=1.1)
    ax.axvline(1, color='grey', lw=0.6, ls='--'); ax.set_xscale('log'); ax.set_xticks([1,1.5,2,3,4,6,8]); ax.set_xticklabels(['1','1.5','2','3','4','6','8']); ax.minorticks_off(); ax.set_xlim(0.8, 14)
    ax.set_yticks(list(y)+[0]); ax.set_yticklabels(list(sub.exp)+[f'Pooled (random effects, k={kk})'], fontsize=5.8)
    ax.set_title(f'{title}\npooled ×{mu:.2f} (95% CI {lo:.2f}–{hi:.2f}); I² = {100*I2:.0f}%', fontsize=6.8)
    ax.set_xlabel('Geometric-mean ratio, creatine ÷ vehicle (log scale)')
    for yy, r in zip(y, sub.gm_ratio): ax.text(13.4, yy, f'×{r:.1f}', va='center', ha='right', fontsize=5.6, color=BLUE)
    ax.text(13.4, 0, f'×{mu:.1f}', va='center', ha='right', fontsize=6, color=RED, fontweight='bold')
    ax.spines[['top','right']].set_visible(False)
fig.tight_layout(w_pad=0.6); fig.savefig('../figures/figure2_creatine_effect_forest.png', bbox_inches='tight', pad_inches=0.03)
