import numpy as np, pandas as pd
from figstyle import *
df = pd.read_csv('phospho.csv'); df.columns = ['gene','p','q','lfc']
deg = np.isclose(df.p, 0.42265, atol=2e-5)
fig, axes = plt.subplots(1, 3, figsize=(WIDTH, 2.75), gridspec_kw={'width_ratios': [1.25, 1.0, 0.95]})
ax = axes[0]
ax.scatter(df.lfc[~deg], -np.log10(df.p[~deg]), s=1.2, color=LIGHT, alpha=0.7, rasterized=True, linewidths=0)
ax.scatter(df.lfc[deg], -np.log10(df.p[deg]), s=1.2, color='#d5dbdb', alpha=0.7, rasterized=True, linewidths=0)
ax.axhline(-np.log10(0.05), color='k', ls='--', lw=0.5); ax.text(-8.6, -np.log10(0.05)+0.07, 'nominal p = 0.05', fontsize=5.3)
s5 = df[df.gene=='Stat5b'].sort_values('p')
ax.scatter(s5.lfc, -np.log10(s5.p), s=22, color=RED, edgecolor='k', linewidths=0.5, zorder=5)
r = s5.iloc[0]; ax.annotate(f'Stat5b peptide 1\n{r.lfc:.2f}; p = {r.p:.4f}; q = {r.q:.2f}', (r.lfc, -np.log10(r.p)), xytext=(-2.6, 3.75), fontsize=5.5, arrowprops=dict(arrowstyle='-', lw=0.4), color=RED)
r = s5.iloc[1]; ax.annotate(f'Stat5b peptide 2\n{r.lfc:.2f}; p = {r.p:.2f}', (r.lfc, -np.log10(r.p)), xytext=(2.6, 1.55), fontsize=5.5, arrowprops=dict(arrowstyle='-', lw=0.4), color=RED)
s5a = df[df.gene=='Stat5a']
ax.scatter(s5a.lfc, -np.log10(s5a.p), s=16, color='#2e86c1', edgecolor='k', linewidths=0.5, zorder=5)
ax.annotate(f'Stat5a\n{s5a.lfc.iloc[0]:.2f}; p = {s5a.p.iloc[0]:.2f}', (s5a.lfc.iloc[0], -np.log10(s5a.p.iloc[0])), xytext=(-8.6, 1.95), fontsize=5.5, color='#2e86c1', arrowprops=dict(arrowstyle='-', lw=0.4))
ax.set_xlabel('LOG_FOLDCHANGE as given\n(read as log2, creatine ÷ vehicle)'); ax.set_ylabel('−log10 p (t-test, n = 3 vs 3)')
ax.set_title(f'A. {len(df):,} rows, {df.gene.nunique():,} genes\n209 pass the screening rule', fontsize=6.5)
ax.spines[['top','right']].set_visible(False); ax.set_ylim(-0.1, 4.7)
ax = axes[1]
nd = df[~deg]
ax.hist(nd.p, bins=20, range=(0,1), color=GREY, edgecolor='white', linewidth=0.4)
ax.axhline(len(nd)/20, color=RED, ls='--', lw=0.7); ax.text(0.99, len(nd)/20+9, 'expected if nothing changed', color=RED, fontsize=5.3, ha='right')
ax.set_xlabel('p-value'); ax.set_ylabel('rows')
ax.set_title(f'B. {len(nd):,} rows with a usable test\n238 at p<0.05; 205.5 expected by chance', fontsize=6.5)
ax.spines[['top','right']].set_visible(False)
ax = axes[2]
s = df.sort_values('p').reset_index(drop=True).head(20)
ax.barh(range(len(s))[::-1], s.q, color=[RED if g=='Stat5b' else GREY for g in s.gene], height=0.75)
ax.set_yticks(range(len(s))[::-1]); ax.set_yticklabels([f'{i+1}. {g}' for i, g in enumerate(s.gene)], fontsize=5.2)
ax.axvline(0.05, color='k', ls='--', lw=0.5)
ax.set_xlim(0, 0.3); ax.set_xlabel('q-value in the file\n(dashed line: 0.05)'); ax.set_ylim(-0.7, 19.9)
ax.set_title('C. Top 20 rows by p-value\nminimum q = 0.167; Stat5b 17th', fontsize=6.5)
ax.spines[['top','right']].set_visible(False)
fig.tight_layout(w_pad=0.8)
fig.savefig('../figures/figure5_phosphoproteomics.png', bbox_inches='tight', pad_inches=0.03)
