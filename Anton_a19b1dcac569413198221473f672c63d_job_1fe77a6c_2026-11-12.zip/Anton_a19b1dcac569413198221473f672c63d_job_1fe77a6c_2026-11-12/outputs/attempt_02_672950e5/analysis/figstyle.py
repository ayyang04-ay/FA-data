"""Shared matplotlib settings: figures are drawn at the width they are printed (7.2 in), with 5.5-7 pt text."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({
    'font.size': 6.5, 'axes.titlesize': 7, 'axes.labelsize': 6.5, 'xtick.labelsize': 6, 'ytick.labelsize': 6,
    'legend.fontsize': 6, 'axes.linewidth': 0.6, 'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
    'xtick.major.size': 2.5, 'ytick.major.size': 2.5, 'lines.linewidth': 1.0, 'savefig.dpi': 300, 'figure.dpi': 150,
})
WIDTH = 7.2
BLUE, GREY, LIGHT, ORANGE, RED, GREEN, AMBER = '#1f4e79', '#5d6d7e', '#9aa7b1', '#d35400', '#c0392b', '#1e8449', '#b9770e'
