import numpy as np, pandas as pd, scipy.stats as st, json
from wb import *
q = pd.read_csv('qpcr.csv'); prog = pd.read_csv('program.csv'); hs = pd.read_csv('human_agg_stats.csv'); hq = pd.read_csv('human_qpcr.csv')
R = []
def add(panel, what, n, result, caveat=''):
    R.append((panel, what, n, result, caveat))
def tt2(sh, A, B):
    a = col(sh, *A); b = col(sh, *B); return a, b, st.ttest_ind(a, b).pvalue
def f(x, d=2): return f'{x:.{d}f}'
def pfmt(p):
    if p < 0.0001: return 'p<0.0001'
    if p < 0.001: return f'p={p:.4f}'
    return f'p={p:.3f}' if p < 0.1 else f'p={p:.2f}'
def two(panel, what, sh, A, B, unit='', caveat='', nlab=None, d=2):
    a, b, p = tt2(sh, A, B)
    add(panel, what, nlab or f'{len(a)}/{len(b)}', f'{a.mean():.{d}f} → {b.mean():.{d}f}{unit} (×{b.mean()/a.mean():.2f}); {pfmt(p)}', caveat)
# ---- Figure 1
two('Fig. 1a','Lung weight, vehicle vs creatine','Fig. 1a',('B',3,8),('C',3,8),' g', d=3)
two('Fig. 1a','PET SUV-BW','Fig. 1a',('B',12,17),('C',12,17), d=0)
two('Fig. 1b','Lung metastatic burden','Fig. 1b',('B',3,8),('C',3,8),' %', d=1)
two('Fig. 1b','Metastatic foci','Fig. 1b',('B',12,17),('C',12,17), d=1)
add('Fig. 1c','Survival','10/10','median 22 → 19 d; HR 2.93 (95% CI 1.04–8.23); log-rank p=0.032')
g = [col('Fig. 1f', c, 22, 27) for c in 'BCDE']
add('Fig. 1f','Burden; melanoma cells with sh-scrambled vs sh-Slc6a8, ± creatine','6 per group', f'sh-scr {g[0].mean():.1f} → {g[1].mean():.1f} %; sh-Slc6a8 {g[2].mean():.1f} → {g[3].mean():.1f} %; interaction p=0.44 (ln scale); same pattern for lung weight, SUV, foci', 'tumor-cell knock-down; protein reduction modest on blot (Supp. Fig. 2a)')
a = [row('Fig. 1h', r, 'B','G') for r in (4,5,6,7)]; b = [row('Fig. 1h', r, 'H','M') for r in (4,5,6,7)]
add('Fig. 1h','Time course 0.25–24 h (readout not named in sheet)','6/6', '; '.join(f'{t}: ×{y.mean()/x.mean():.2f} ({pfmt(st.ttest_ind(x,y).pvalue)})' for t,x,y in zip(['0.25 h','6 h','12 h','24 h'], a, b)), 'reads as early tumor-cell retention')
two('Fig. 1i','GFP+ cells per field','Fig. 1i',('B',4,11),('C',4,11), caveat='n = fields, not animals', nlab='8/8 fields', d=1)
two('Fig. 1j','Lung weight (second data set)','Fig. 1j',('B',4,9),('C',4,9),' g', d=3)
two('Fig. 1j','PET SUV-BW','Fig. 1j',('B',13,18),('C',13,18), d=0)
two('Fig. 1k','Lung metastatic burden','Fig. 1k',('B',4,9),('C',4,9),' %', d=1)
two('Fig. 1k','Metastatic foci','Fig. 1k',('B',12,17),('C',12,17), d=1)
add('Fig. 1l','Survival','20/18','median 16 → 14 d; HR 2.28 (95% CI 1.16–4.46); log-rank p=0.011')
# ---- Figure 2
for lab, A in [('PLT',(4,6)),('PCT',(12,14)),('PDW',(19,21)),('MPV',(27,29))]:
    pass
a,b,p = tt2('Fig. 2a',('B',4,6),('C',4,6)); add('Fig. 2a','Platelet count and indices (PLT, PCT, PDW, MPV)','3/3', f'PLT {a.mean():.0f} → {b.mean():.0f} ×10⁹/L ({pfmt(p)}); PCT, PDW, MPV all n.s.')
x = [(row('Fig. 2b', r, 'B','D'), row('Fig. 2b', r, 'E','G')) for r in (4,5,6)]
add('Fig. 2b','Platelet aggregation (%)','3/3', '; '.join(f'{n} {u.mean():.0f} → {w.mean():.0f} ({pfmt(st.ttest_ind(u,w).pvalue)})' for n,(u,w) in zip(['ADP','collagen','thrombin'], x)))
two('Fig. 2c','α-granules per field','Fig. 2c',('B',4,11),('C',4,11), caveat='n = fields, not animals', nlab='8/8 fields', d=1)
a,b,p = tt2('Fig. 2d',('B',28,32),('C',28,32)); add('Fig. 2d','Thromboelastography','5/5', f'MA {a.mean():.1f} → {b.mean():.1f} mm ({pfmt(p)}); R p=0.90, K p=0.17, α p=0.15', 'only MA nominally significant')
add('Fig. 2e / 2g','GP6 and P2RY12 protein in platelets / MKs from treated mice (blots)','3 lanes per group','MKs (2g): both bands stronger with creatine. Platelets (2e): little change once loading is allowed for','no densitometry in package; read by eye')
s = q[q.sheet=='Fig. 2f']; add('Fig. 2f','11-gene activation panel, MKs from treated mice (qPCR)','3/3', f'all 11 genes up, ×{s.fold_geo.min():.1f}–{s.fold_geo.max():.1f} (median ×{s.fold_geo.median():.1f}); {int((s.p_dct<0.05).sum())}/11 p<0.05')
add('Fig. 2i','GP6, P2RY12 after creatine 0 / 0.2 / 2 mM in culture (blots)','1 lane per dose','induced in MKs, not in isolated platelets','single blot')
two('Fig. 2j','PKH-positive area (labeled platelets)','Fig. 2j',('B',4,11),('C',4,11),' %', caveat='n = fields, not animals', nlab='8/8 fields')
# ---- Figure 3
x = [(row('Fig. 3b', r, 'B','F'), row('Fig. 3b', r, 'G','K')) for r in (4,5)]
add('Fig. 3b','Serum creatine, Cre control vs Slc6a8 cKO','5 per group', f'control {x[0][0].mean():.0f} → {x[0][1].mean():.0f} µM (×{x[0][1].mean()/x[0][0].mean():.1f}); cKO {x[1][0].mean():.0f} → {x[1][1].mean():.0f} µM (×{x[1][1].mean()/x[1][0].mean():.1f}); interaction p=0.18', 'exposure equal in both genotypes')
x = [(row('Fig. 3c', r, 'B','D'), row('Fig. 3c', r, 'E','G')) for r in (4,5)]
add('Fig. 3c','MK intracellular creatine','3 per group', f'control {x[0][0].mean():.1f} → {x[0][1].mean():.1f} (×{x[0][1].mean()/x[0][0].mean():.1f}, {pfmt(st.ttest_ind(*x[0]).pvalue)}); cKO {x[1][0].mean():.1f} → {x[1][1].mean():.1f} (×{x[1][1].mean()/x[1][0].mean():.1f}, {pfmt(st.ttest_ind(*x[1]).pvalue)}); interaction p=0.045')
g = {lab: [row('Fig. 3d', r, a_, b_) for a_,b_ in [('B','D'),('E','G'),('H','J'),('K','M')]] for lab, r in [('ADP',4),('collagen',5),('thrombin',6)]}
add('Fig. 3d','Platelet aggregation (%), 2×2','3 per group', '; '.join(f'{k}: control {v_[0].mean():.0f} → {v_[1].mean():.0f}, cKO {v_[2].mean():.0f} → {v_[3].mean():.0f}' for k, v_ in g.items()) + '; all interactions p<0.0001', 'creatine lowers aggregation in cKO; cKO-vehicle below control-vehicle')
s = prog[prog.design.str.startswith('Slc6a8 cKO (MKs')]
add('Fig. 3f','11-gene panel, 2×2 (qPCR)','3 per group', f'control: median ×{2**s.induction_log2.median():.1f}; cKO (creatine vs cKO-vehicle): median ×{2**s.residual_log2.median():.1f}, {int(((s.res_p<0.05)&(s.residual_log2>0)).sum())}/11 genes still induced; interaction p<0.05 for {int((s.int_p<0.05).sum())}/11')
add('Fig. 3g','GP6, P2RY12 protein, 2×2 (blots)','2 lanes per group','stronger with creatine in controls (GP6 clearly, P2RY12 in one of two lanes), unchanged in cKO','no densitometry')
g = [col('Fig. 3i', c, 10, 13) for c in 'BCDE']; f_ = [col('Fig. 3i', c, 17, 20) for c in 'BCDE']; w = [col('Fig. 3i', c, 3, 6) for c in 'BCDE']
add('Fig. 3i','Lung metastasis, 2×2 (MK-lineage Slc6a8 × creatine)','4 per group', f'burden: control {g[0].mean():.1f} → {g[1].mean():.1f} %, cKO {g[2].mean():.1f} → {g[3].mean():.1f} %; geometric-mean creatine effect ×3.56 (1.96–6.45) vs ×0.79 (0.44–1.42); interaction p=0.0009. Foci {f_[0].mean():.0f} → {f_[1].mean():.0f} vs {f_[2].mean():.0f} → {f_[3].mean():.0f} (p=0.023). Lung weight {w[0].mean():.3f} → {w[1].mean():.3f} vs {w[2].mean():.3f} → {w[3].mean():.3f} g (p=0.0002)', 'the only lineage-specific genetic test of the endpoint')
# ---- Figure 4
a,b,p = tt2('Fig. 4a',('B',4,6),('C',4,6)); c,d,p2 = tt2('Fig. 4a',('D',4,6),('E',4,6))
add('Fig. 4a','Creatine in MKs and brain after dosing','3/3', f'MK {a.mean():.0f} → {b.mean():.0f} µmol/g (×{b.mean()/a.mean():.1f}, {pfmt(p)}); brain {c.mean():.0f} → {d.mean():.0f} (×{d.mean()/c.mean():.2f}, {pfmt(p2)})')
a,b,p = tt2('Fig. 4c',('B',4,6),('C',4,6)); c,d,p2 = tt2('Fig. 4c',('D',4,6),('E',4,6))
add('Fig. 4c','Phosphocreatine in MKs and brain','3/3', f'MK {a.mean():.2f} → {b.mean():.2f} ng/µg (×{b.mean()/a.mean():.1f}, {pfmt(p)}); brain {c.mean():.2f} → {d.mean():.2f} (×{d.mean()/c.mean():.1f}, {pfmt(p2)})')
add('Fig. 4b','CKB protein in MKs and brain (blot)','1 lane per group','CKB up in MKs after creatine; brain CKB far higher and unchanged','single blot')
a,b,p = tt2('Fig. 4d',('C',4,6),('D',4,6)); add('Fig. 4d','Creatine in cultured MKs','3/3', f'{a.mean():.0f} → {b.mean():.0f} µmol/g (×{b.mean()/a.mean():.1f}, {pfmt(p)})', 'sheet label says "Creatinine"')
a = row('Fig. 4e', 8, 'E','G'); b = row('Fig. 4e', 8, 'I','K'); add('Fig. 4e','Ckb mRNA (and CKB blot) in MKs','3/3', f'×{b.mean()/a.mean():.1f}, {pfmt(st.ttest_ind(a,b).pvalue)}; CKB band stronger', 'sheet says Vehicle, blot says Control')
a,b,p = tt2('Fig. 4f',('B',4,6),('C',4,6)); add('Fig. 4f','Phosphocreatine in cultured MKs','3/3', f'{a.mean():.2f} → {b.mean():.2f} ng/µg (×{b.mean()/a.mean():.1f}, {pfmt(p)})')
s = prog[prog.design.str.startswith('WT MKs in vitro')]
add('Fig. 4g / 4h','Creatine vs phosphocreatine added to cultured MKs (blots; qPCR)','3 per group', f'creatine: median ×{2**s.induction_log2.median():.1f}; phosphocreatine: median ×{2**s.residual_log2.median():.1f} (no induction; {int(((s.res_p<0.05)&(s.residual_log2<0)).sum())}/11 genes lower)', 'uptake of phosphocreatine not verified')
s = prog[prog.design.str.startswith('si-Ckb')]
add('Fig. 4i / 4j','si-Ckb ± creatine in cultured MKs (blots; qPCR)','3 per group', f'creatine: median ×{2**s.induction_log2.median():.1f} with si-scrambled vs ×{2**s.residual_log2.median():.1f} with si-Ckb (relative to si-Ckb alone); {int(((s.res_p<0.05)&(s.residual_log2>0)).sum())}/11 genes still induced; si-Ckb lowers baseline in {int(((s.base_p<0.05)&(s.baseline_shift_log2<0)).sum())}/11', 'partial knock-down (Supp. Fig. 5b)')
s = q[q.sheet=='Fig. 4l']; add('Fig. 4k / 4l','CKB over-expression in cultured MKs (blots; qPCR)','3/3', f'all 11 genes up ×{s.fold_geo.min():.1f}–{s.fold_geo.max():.1f} (median ×{s.fold_geo.median():.1f}) without creatine')
# ---- Figure 5
for sh in ['Fig. 5e','Fig. 5f']:
    g = [col(sh, c, 4, 6) for c in 'NOPQ']; g2 = [col(sh, c, 17, 19) for c in 'NOPQ']
    add(sh,'pan-phospho / FLAG on STAT5B-FLAG WT, S127A, 3A, S127D ± creatine (densitometry)','3 blots per group', f'WT {g[0].mean():.2f} → {g2[0].mean():.2f} (×{g2[0].mean()/g[0].mean():.2f}, {pfmt(st.ttest_ind(g[0],g2[0]).pvalue)}); S127A {g[1].mean():.2f} → {g2[1].mean():.2f}; 3A {g[2].mean():.2f} → {g2[2].mean():.2f}; S127D {g[3].mean():.2f} → {g2[3].mean():.2f}; creatine WT vs S127A Tukey {pfmt(st.tukey_hsd(*g2).pvalue[0,1])}', 'host cell not named; vehicle and creatine analyzed in separate ANOVAs in sheet')
add('Fig. 5g–5i','CKB over-expression / si-CKB effects on pan-phospho and nuclear STAT5B-FLAG (blots)','single blots','CKB-OE raises pan-phospho on WT not S127A; si-CKB blunts creatine-induced nuclear signal','293T system (Supp. Fig. 6e–g); no densitometry')
add('Fig. 5j','ChIP-qPCR at P2ry12 and Gp6 promoters, MKs ± creatine','3/3','P2ry12: −2 kb ×4.8, −1 kb ×4.7, −0.2 kb ×12.1 (each Sidak p<0.0001), exon ×1.3 n.s.; Gp6: −1 kb ×3.8 (p=0.0001), −0.2 kb ×2.9 (p=0.018), −2 kb and exon n.s.','ChIP antibody not named in package')
# ---- Figure 6
s = prog[prog.design.str.startswith('STAT5-IN-1')]
add('Fig. 6a','11-gene panel, MKs, creatine ± STAT5-IN-1 (qPCR)','3 per group', f'creatine: median ×{2**s.induction_log2.median():.1f} without vs ×{2**s.residual_log2.median():.2f} with inhibitor; inhibitor alone lowers {int(((s.base_p<0.05)&(s.baseline_shift_log2<0)).sum())}/11 genes (to ×0.2–0.7)', 'inhibits STAT5A and STAT5B')
g = [col('Fig. 6b', c, 4, 8) for c in 'BCDE']; f_ = [col('Fig. 6b', c, 13, 17) for c in 'BCDE']
add('Fig. 6b','Lung metastasis, 2×2 (STAT5-IN-1 × creatine)','5 per group', f'burden {g[0].mean():.1f} → {g[1].mean():.1f} % without vs {g[2].mean():.1f} → {g[3].mean():.1f} % with inhibitor; creatine effect ×4.08 (2.92–5.71) vs ×1.30 (0.80–2.10); interaction p=0.0004. Foci {f_[0].mean():.0f} → {f_[1].mean():.0f} vs {f_[2].mean():.0f} → {f_[3].mean():.0f} (p=0.002)', 'systemic, not isoform- or lineage-selective; 6 records identical to Supp. Fig. 2d')
add('Fig. 6d','STAT5B protein in MKs, WT vs Pf4-iCre;Stat5b fl/fl (blot)','1 lane each','band absent in cKO','single blot')
g = [col('Fig. 6e', c, 5, 7) for c in 'CDE']; add('Fig. 6e','MK creatine: WT-vehicle, WT-creatine, Stat5b cKO-creatine','3 per group', f'{g[0].mean():.0f}, {g[1].mean():.0f}, {g[2].mean():.0f} µmol/g; cKO-creatine vs WT-creatine p=0.98', 'uptake intact; no cKO-vehicle group')
add('Fig. 6f','CKB, GP6, P2RY12 in MKs; GP6, P2RY12 in platelets (blots)','1 lane per group','CKB still induced in cKO; GP6 and P2RY12 back near vehicle level','single blots; no densitometry')
s = prog[prog.design.str.startswith('Stat5b cKO')]
add('Fig. 6g','11-gene panel: WT-vehicle, WT-creatine, Stat5b cKO-creatine (qPCR)','3 per group', f'WT-creatine median ×{2**s.induction_log2.median():.1f}; cKO-creatine median ×{2**s.pertcre_vs_ctl_log2.median():.1f} vs WT-vehicle; still up: P2ry12 ×1.9, Adra2a ×1.9, Gpiba ×1.6, F2r ×1.6 (p<0.05), Gp6 ×1.4 (p=0.06)', 'no cKO-vehicle group; control is "WT", not Cre-matched')
# ---- Figure 7
M = np.array([row('Fig. 7b', r, 'B', 'E') for r in range(4, 15)])
add('Fig. 7b','Human serum creatine, days 0/3/7/14','11 volunteers', f'{M[:,0].mean():.0f} → {M[:,1].mean():.0f} / {M[:,2].mean():.0f} / {M[:,3].mean():.0f} µM (×{M[:,3].mean()/M[:,0].mean():.1f} at day 14; 11/11 up; paired p<0.0001)')
def hrow(ag, m, d):
    h = hs[(hs.agonist==ag)&(hs.metric==m)&(hs.day==d)].iloc[0]; return h
txt = []
for ag, nm in [('collagen','collagen'),('EPI','epinephrine'),('AA','arachidonic acid'),('ADP','ADP')]:
    h = hrow(ag,'max',14); txt.append(f'{nm} ×{h.gmean:.2f} ({h.gm_lo:.2f}–{h.gm_hi:.2f}), {int(h.n_up)}/11 up, {pfmt(h.p_wilcoxon)}')
add('Fig. 7c','Human platelet maximal aggregation, day 14 vs own day 0','11 volunteers', '; '.join(txt), 'paired Wilcoxon (mine); sheet used Dunnett on fold changes; average-aggregation and adhesion metrics agree')
h7 = hrow('EPI','max',7); add('Fig. 7c','… day 7','11 volunteers', f'epinephrine ×{h7.gmean:.2f} ({int(h7.n_up)}/11 up, {pfmt(h7.p_wilcoxon)}); collagen ×{hrow("collagen","max",7).gmean:.2f} ({pfmt(hrow("collagen","max",7).p_wilcoxon)}); ADP ×{hrow("ADP","max",7).gmean:.2f}')
o = hq.groupby(['gene','day']).reported.apply(lambda x: (2**np.log2(x).mean(), int((x>1).sum()))).unstack()
add('Fig. 7d','Human CD41+ cells, 11 genes, days 3/7/14 (qPCR)','4 volunteers', f'day 7 (geometric mean; n up of 4): GP6 ×{o.loc["GP6",7][0]:.1f} ({o.loc["GP6",7][1]}/4), P2RY12 ×{o.loc["P2RY12",7][0]:.1f} ({o.loc["P2RY12",7][1]}/4), ADRA2A ×{o.loc["ADAR2A",7][0]:.0f} ({o.loc["ADAR2A",7][1]}/4); day 14: GP6 ×{o.loc["GP6",14][0]:.1f} ({o.loc["GP6",14][1]}/4), P2RY12 ×{o.loc["P2RY12",14][0]:.1f} ({o.loc["P2RY12",14][1]}/4), RAB4A ×{o.loc["RAB4A",14][0]:.2f} ({o.loc["RAB4A",14][1]}/4 up)', 'volunteer 2 largely non-responsive; RAB4A falls; two normalized values not reproducible')
G = np.array([row('Fig. 7e', r, 'B', 'E') for r in range(4, 8)]); P = np.array([row('Fig. 7e', r, 'B', 'E') for r in range(12, 16)])
add('Fig. 7e','Human platelet GP6 and P2RY12 protein (densitometry)','4 volunteers', f'day 14: GP6 ×{np.exp(np.log(G[:,3]/G[:,0]).mean()):.1f} (4/4 up; paired {pfmt(st.ttest_rel(G[:,3],G[:,0]).pvalue)}); P2RY12 ×{np.exp(np.log(P[:,3]/P[:,0]).mean()):.1f} (4/4 up; {pfmt(st.ttest_rel(P[:,3],P[:,0]).pvalue)})')
a,b,p = tt2('Fig. 7g',('B',12,16),('C',12,16)); add('Fig. 7g','Lung metastasis in mice given human platelets from day 0 vs day 7 of supplementation','5/5 recipients', f'burden {a.mean():.1f} → {b.mean():.1f} % (geometric-mean ratio ×2.76, 1.60–4.76; {pfmt(p)}); foci 22 → 39; lung weight 0.186 → 0.236 g', 'number of donors not recorded')
# ---- Supplementary
add('Supp. Fig. 1a–c','Body weight, food and water intake','4/4; 6/6','no differences (p=0.08–0.99)')
two('Supp. Fig. 1d','Serum creatine on the oral regimen','Supplementary Fig  1d',('B',4,9),('C',4,9),' µM', d=0)
for tag, sh, A, B in [('Supp. Fig. 1e','Supplementary Fig  1e',('B',13,18),('C',13,18)),('Supp. Fig. 1f','Supplementary Fig  1f',('B',12,15),('C',12,15)),('Supp. Fig. 1g','Supplementary Fig  1g',('B',15,24),('C',15,24)),('Supp. Fig. 1k','Supplementary Fig  1k',('B',16,25),('C',16,25))]:
    two(tag,'Lung metastatic burden (further vehicle-vs-creatine data set)',sh,A,B,' %', caveat='model not named in package', d=1)
two('Supp. Fig. 1h','Serum creatine on 5% creatine diet','Supplementary Fig  1h',('C',4,7),('D',4,7),' µM', d=0)
two('Supp. Fig. 1i','Lung metastatic burden, 5% creatine diet','Supplementary Fig  1i',('B',11,14),('C',11,14),' %', d=1)
a = row('Supplementary Fig  2a', 7, 'D','F'); b = row('Supplementary Fig  2a', 7, 'H','J'); add('Supp. Fig. 2a','Slc6a8 knock-down in tumor cells (qPCR; blot)','3/3', f'mRNA {100*b.mean()/a.mean():.0f}% of control ({pfmt(st.ttest_ind(a,b).pvalue)}); protein band only modestly weaker', 'sheet says si-, blot says sh-')
g = [col('Supplementary Fig  2d', c, 5, 10) for c in 'CDE']
add('Supp. Fig. 2d','Lung metastasis in recipients of platelets from vehicle, creatine, or creatine+aspirin donors','6 per group', f'burden {g[0].mean():.1f} / {g[1].mean():.1f} / {g[2].mean():.1f} %; creatine vs vehicle donors ×3.26 (1.83–5.82), Tukey p=0.0004; creatine+aspirin vs creatine donors ×0.22 (0.10–0.47), p=0.0001', 'rows 4–6 of first two groups identical to Fig. 6b records')
add('Supp. Fig. 3a','White cells, lymphocytes, monocytes, red cells','5/5','no differences (p=0.11–0.84)')
s = q[q.sheet=='Supplementary Fig  3c']; add('Supp. Fig. 3c','MK maturation genes (qPCR)','3/3', 'Nfe2, Gata1, Zfpm1, Itgb3, Tubb1, Lims1 unchanged; Hsd3b1 ×1.4, Casp12 ×1.9 up, Myl9 ×0.5 down (p<0.05)')
add('Supp. Fig. 4a','SLC6A8 protein in MKs, control vs cKO (blot)','1 lane each','band reduced, not absent','single blot; no densitometry')
add('Supp. Fig. 4b','Platelet count, 2×2','3 per group','890 / 909 / 1042 / 992 ×10⁹/L; all n.s.')
g = [col('Supplementary Fig  4c', c, 6, 13) for c in 'CDEF']; add('Supp. Fig. 4c','α-granules per field, 2×2','8 fields per group', f'control {g[0].mean():.1f} → {g[1].mean():.1f}; cKO {g[2].mean():.2f} → {g[3].mean():.2f}; interaction p=0.006', 'n = fields, not animals')
s = prog[prog.design.str.startswith('Slc6a8-cKO MKs in vitro')]
add('Supp. Fig. 4e','Slc6a8-cKO MKs in culture: free vs liposomal creatine (qPCR)','3 per group', f'free creatine median ×{2**s.residual_log2.median():.1f}; liposomal creatine median ×{2**s.induction_log2.median():.1f} ({int(((s.ind_p<0.05)&(s.induction_log2>0)).sum())}/11 genes induced)', 'bypass of the transporter restores the response')
add('Supp. Fig. 5a','Gatm, Gamt mRNA in MKs','3/3','×1.15 (p=0.37), ×0.88 (p=0.61): creatine-synthesis genes unchanged')
a,b,p = tt2('Supplementary Fig  5c',('B',5,7),('C',5,7)); c,d,p2 = tt2('Supplementary Fig  5c',('B',13,15),('C',13,15))
add('Supp. Fig. 5c','Creatine and phosphocreatine in MKs, empty vector vs CKB over-expression','3/3', f'creatine {a.mean():.1f} vs {b.mean():.1f} µmol/g ({pfmt(p)}); phosphocreatine {c.mean():.2f} vs {d.mean():.2f} ng/µg (×{d.mean()/c.mean():.2f}, {pfmt(p2)})', 'n=3; cannot exclude a modest phosphocreatine rise')
add('Supp. Fig. 6a','p-STAT5A/B (Y694/699) in MKs ± creatine; Jurkat ± IL-2 control (blots)','3 lanes per group','no tyrosine-phospho signal in MKs with or without creatine; positive control works','canonical STAT5 activation not involved')
add('Supp. Fig. 6d','Recombinant His-CKB + ATP on STAT5B-FLAG (blot)','single blot','pan-phospho signal stronger with CKB','no kinase-dead or S127A-substrate control in this panel')
add('Supp. Fig. 6h','Nuclear STAT5B in MKs ± creatine (blot)','2 lanes per group','band stronger with creatine: clearly against one vehicle lane, marginally against the other','no densitometry')
add('Supp. Fig. 6i','ChIP-qPCR at Rab4a promoter','3/3','−0.2 kb ×5.5 (Sidak p<0.0001), −1 kb ×2.7 (p=0.039); −2 kb, exon n.s.','ChIP antibody not named')
add('Supp. Fig. 7a','Platelet count and indices, creatine ± STAT5-IN-1','3 per group','all comparisons n.s. (PLT 646 / 762 / 836 / 598)','n=3, wide spread')
add('Supp. Fig. 7b','Platelet count and indices: WT-vehicle, WT-creatine, Stat5b cKO-creatine','3 per group','PLT 896 / 760 / 693 (n.s.); plateletcrit 0.36 / 0.29 / 0.26 (WT-vehicle vs cKO-creatine p=0.055)','no cKO-vehicle group')
add('Supp. Fig. 8a–b','Human BMI; platelet count and indices','11 volunteers','BMI 20.9 → 21.1 (paired p=0.24); PLT 253 → 245 ×10⁹/L, PCT, MPV, PDW unchanged')
add('Supp. Fig. 8c','ITGA2B (CD41) mRNA: CD41+ fraction vs monocytes vs MEG-01','3 each','CD41+ fraction 17× monocytes; MEG-01 0.7× CD41+ fraction','purity check of the CD41+ preparation')
add('Supp. Fig. 8d','GP6, P2RY12 blots for the 4 volunteers','4 volunteers','source blots for Fig. 7e')
add('Phosphoproteomics','MK phosphopeptides, creatine vs vehicle','3/3 mice','5,812 rows / 2,033 genes; 238 rows p<0.05 among 4,110 non-degenerate tests (205.5 expected by chance); 0 rows q<0.05 (min q 0.167; min BH-adjusted p 0.25); Stat5b: LOG_FOLDCHANGE 5.70, p=0.0012, q=0.246, rank 17; second Stat5b peptide and Stat5a unchanged','gene-level IDs only (no site); direction/base of log ratio not stated')
df = pd.DataFrame(R, columns=['Panel','What was measured','n (vehicle/creatine or per group)','Result (re-derived)','Caveat'])
df.to_csv('../tables/panel_by_panel_summary.csv', index=False)
md = ['| Panel | Measurement | n | Result (re-derived from the raw values) | Caveat |','|---|---|---|---|---|']
for r in R:
    md.append('| ' + ' | '.join(str(x).replace('|','/') for x in r) + ' |')
open('appendix_table.md','w').write('\n'.join(md))
print(len(R), 'rows'); print('\n'.join(md[:12]))
