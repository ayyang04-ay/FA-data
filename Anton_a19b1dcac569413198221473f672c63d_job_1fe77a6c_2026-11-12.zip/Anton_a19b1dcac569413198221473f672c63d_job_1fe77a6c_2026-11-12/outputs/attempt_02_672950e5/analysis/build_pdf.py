"""Render the proposal Markdown to PDF with reportlab (subset of Markdown: headings, paragraphs,
bold/italic, bullet and numbered lists, pipe tables, images)."""
import re, os, sys
import matplotlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether, PageBreak
from PIL import Image as PILImage

src, dst = sys.argv[1], sys.argv[2]
base = os.path.dirname(os.path.abspath(src))
fd = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
pdfmetrics.registerFont(TTFont('DV', os.path.join(fd, 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B', os.path.join(fd, 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DV-I', os.path.join(fd, 'DejaVuSans-Oblique.ttf')))
pdfmetrics.registerFont(TTFont('DV-BI', os.path.join(fd, 'DejaVuSans-BoldOblique.ttf')))
pdfmetrics.registerFontFamily('DV', normal='DV', bold='DV-B', italic='DV-I', boldItalic='DV-BI')

W, H = A4; LM = RM = 1.7*cm; TM = BM = 1.6*cm; TW = W - LM - RM
body = ParagraphStyle('body', fontName='DV', fontSize=9, leading=12.6, spaceAfter=5, alignment=TA_LEFT)
lead = ParagraphStyle('lead', parent=body, fontName='DV-B', fontSize=11, leading=15, spaceAfter=8, textColor=colors.HexColor('#1f4e79'))
h1 = ParagraphStyle('h1', parent=body, fontName='DV-B', fontSize=14.5, leading=18, spaceBefore=2, spaceAfter=6)
h2 = ParagraphStyle('h2', parent=body, fontName='DV-B', fontSize=11.5, leading=15, spaceBefore=10, spaceAfter=5, textColor=colors.HexColor('#1f4e79'), keepWithNext=1)
h3 = ParagraphStyle('h3', parent=body, fontName='DV-B', fontSize=9.8, leading=13, spaceBefore=7, spaceAfter=4, keepWithNext=1)
bullet = ParagraphStyle('bullet', parent=body, leftIndent=12, bulletIndent=2, spaceAfter=3.5, bulletFontName='DV', bulletFontSize=9)
cap = ParagraphStyle('cap', parent=body, fontName='DV-I', fontSize=8, leading=10.5, spaceAfter=8, textColor=colors.HexColor('#444444'))
cell = ParagraphStyle('cell', parent=body, fontSize=7.6, leading=9.8, spaceAfter=0)
cellh = ParagraphStyle('cellh', parent=cell, fontName='DV-B')
cell_s = ParagraphStyle('cell_s', parent=body, fontSize=6.4, leading=8.1, spaceAfter=0)
cellh_s = ParagraphStyle('cellh_s', parent=cell_s, fontName='DV-B')

def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?![\*\w])', r'<i>\1</i>', t)
    return t

def make_table(rows):
    ncol = len(rows[0]); small = ncol >= 5
    cs, chs = (cell_s, cellh_s) if small else (cell, cellh)
    # column widths: proportional to sqrt of max text length, bounded
    lens = [max(len(r[i]) for r in rows) for i in range(ncol)]
    if small and rows[0][0].startswith('Evidence'): wts = [1.55, 2.25, 2.35, 1.9, 2.1]
    elif small: wts = [1.15, 2.6, 1.25, 5.2, 2.4][:ncol]
    elif ncol == 4: wts = [2.4, 2.3, 2.3, 2.0]
    elif ncol == 2: wts = [1.0, 3.1] if lens[0] < 90 else [1.6, 1.4]
    else: wts = [max(1.0, min(4.0, l**0.5/4)) for l in lens]
    tot = sum(wts); widths = [TW*w/tot for w in wts]
    data = [[Paragraph(inline(c), chs if i == 0 else cs) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#dfe7ef')),
        ('GRID', (0,0), (-1,-1), 0.35, colors.HexColor('#9aa7b1')),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 3.5), ('RIGHTPADDING', (0,0), (-1,-1), 3.5),
        ('TOPPADDING', (0,0), (-1,-1), 2.5), ('BOTTOMPADDING', (0,0), (-1,-1), 2.5),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f6f8fa')]),
    ]))
    return t

lines = open(src, encoding='utf-8').read().split('\n')
story = []; i = 0; first = True
while i < len(lines):
    ln = lines[i]
    if not ln.strip(): i += 1; continue
    if ln.startswith('|'):
        rows = []
        while i < len(lines) and lines[i].startswith('|'):
            cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r':?-{3,}:?', c) for c in cells): rows.append(cells)
            i += 1
        story.append(make_table(rows)); story.append(Spacer(1, 7)); continue
    m = re.match(r'!\[(.*?)\]\((.*?)\)', ln)
    if m:
        p = os.path.join(base, m.group(2)); im = PILImage.open(p); w, h = im.size
        maxh = 21.5*cm; sc = min(TW/w, maxh/h)
        story.append(KeepTogether([Image(p, width=w*sc, height=h*sc), Paragraph(inline(m.group(1)), cap)]))
        i += 1; continue
    if ln.startswith('### '): story.append(Paragraph(inline(ln[4:]), h3)); i += 1; continue
    if ln.startswith('## '):
        if ln.startswith('## Appendix'): story.append(PageBreak())
        story.append(Paragraph(inline(ln[3:]), h2)); i += 1; continue
    if ln.startswith('# '): story.append(Paragraph(inline(ln[2:]), h1)); i += 1; continue
    if ln.startswith('- '):
        story.append(Paragraph(inline(ln[2:]), bullet, bulletText='•')); i += 1; continue
    m = re.match(r'(\d+)\. (.*)', ln)
    if m:
        story.append(Paragraph(inline(m.group(2)), bullet, bulletText=m.group(1)+'.')); i += 1; continue
    story.append(Paragraph(inline(ln), lead if first else body)); first = False; i += 1

def footer(canvas, doc):
    canvas.saveState(); canvas.setFont('DV', 7); canvas.setFillColor(colors.HexColor('#666666'))
    canvas.drawString(LM, 0.9*cm, 'CRE-MK-01 follow-up: target validation proposal')
    canvas.drawRightString(W-RM, 0.9*cm, f'Page {doc.page}'); canvas.restoreState()
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame
doc = BaseDocTemplate(dst, pagesize=A4, leftMargin=LM, rightMargin=RM, topMargin=TM, bottomMargin=BM, title='CRE-MK-01 follow-up: target validation proposal', author='')
frame = Frame(LM, BM, TW, H-TM-BM, leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0, id='main')
doc.addPageTemplates([PageTemplate(id='all', frames=[frame], onPageEnd=footer)])  # footer drawn after the page content
doc.build(story)
print('written', dst)
