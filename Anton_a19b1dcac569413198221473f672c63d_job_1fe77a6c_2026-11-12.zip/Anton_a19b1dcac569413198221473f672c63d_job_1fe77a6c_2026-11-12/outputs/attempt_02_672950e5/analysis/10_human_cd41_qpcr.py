import json, numpy as np, pandas as pd, scipy.stats as st, re
from openpyxl.utils import column_index_from_string as ci, get_column_letter as cl
C = json.load(open('cells.json'))
d = C['Fig. 7d']
blocks = []
for k, val in d.items():
    if val == 'Volunteer1':
        col = re.sub(r'\d+','',k); r = int(re.sub(r'[A-Z]+','',k))
        if col == 'C':
            blocks.append((d.get(f'A{r}'), 'B', 'C', r))
        elif col == 'I':
            blocks.append((d.get(f'H{r}'), 'H', 'I', r))
print(blocks)
rows = []
for gene, lab_col, v0, r in blocks:
    c0 = ci(v0)
    dct = {}; norm = {}
    for rr in range(r+1, r+17):
        lab = d.get(f'{lab_col}{rr}')
        vals = [d.get(f'{cl(c0+i)}{rr}') for i in range(4)]
        if isinstance(lab, str) and lab.startswith('ΔCT'):
            day = int(re.search(r'(\d+)d', lab).group(1)); dct.setdefault(day, []).append(vals)
        elif isinstance(lab, str) and lab.startswith('After'):
            day = int(re.search(r'(\d+)d', lab).group(1)); norm[day] = vals
    for vi in range(4):
        base = np.array([x[vi] for x in dct[0]], float)
        for day in (3,7,14):
            arr = np.array([x[vi] for x in dct[day]], float)
            rows.append(dict(gene=gene.strip(), vol=vi+1, day=day, fc_geo=2**(arr.mean()-base.mean()), fc_lin=(2**arr).mean()/(2**base).mean(), reported=norm[day][vi], base_dct=base.mean(), base_sd=base.std(ddof=1), dct=arr.mean(), dct_sd=arr.std(ddof=1)))
df = pd.DataFrame(rows)
df['ratio_rep_lin'] = df.reported/df.fc_lin
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
print('n rows', len(df), 'agreement of reported with linear-mean fold (1%):', (np.abs(df.ratio_rep_lin-1)<0.01).mean())
print(df[np.abs(df.ratio_rep_lin-1)>0.01].round(4).to_string())
df.to_csv('human_qpcr.csv', index=False)
order = ['ITGA2B','P2RY12','GP6','GPIBA','F2R','ADAR2A','FCGR2A','RUNX1','RAB4A','RAB27B','PITPNB']
piv = df.pivot_table(index='gene', columns=['day','vol'], values='reported').loc[order]
print(piv.round(2).to_string())
out = []
for (g, day), sub in df.groupby(['gene','day']):
    l = np.log2(sub.reported.values)
    t, p = st.ttest_1samp(l, 0)
    out.append(dict(gene=g, day=day, gmean=2**l.mean(), n_up=int((sub.reported>1).sum()), n_gt2=int((sub.reported>2).sum()), n_lt05=int((sub.reported<0.5).sum()), p_t_log=p))
o = pd.DataFrame(out)
print(o.pivot(index='gene', columns='day', values=['gmean','n_up','n_gt2','p_t_log']).loc[order].round(3).to_string())
print('\nbaseline dCT by volunteer:')
print(df[df.day==3].pivot(index='gene', columns='vol', values='base_dct').loc[order].round(2).to_string())
print('\nwithin-triplicate SD of dCT (max per gene):')
print(df.groupby('gene')[['base_sd','dct_sd']].max().round(2).to_string())
