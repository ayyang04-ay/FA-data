import numpy as np, scipy.stats as st
rng = np.random.default_rng(20240611)
def sim(n, sd, r_wt=3.0, r_ko=1.0, nsim=4000, thr_block=0.5):
    out_int = 0; out_block = 0; out_ub15 = 0; out_ub20 = 0
    for _ in range(nsim):
        wv = rng.normal(0, sd, n); wc = rng.normal(np.log(r_wt), sd, n); kv = rng.normal(0, sd, n); kc = rng.normal(np.log(r_ko), sd, n)
        mse = (wv.var(ddof=1)+wc.var(ddof=1)+kv.var(ddof=1)+kc.var(ddof=1))/4; dfree = 4*(n-1)
        d_wt = wc.mean()-wv.mean(); d_ko = kc.mean()-kv.mean()
        se_i = np.sqrt(mse*4/n); t = (d_ko-d_wt)/se_i; p = 2*st.t.sf(abs(t), dfree)
        if p < 0.05 and d_ko < d_wt: out_int += 1
        # residual effect upper bound in KO
        se_k = np.sqrt(mse*2/n); ub = d_ko + st.t.ppf(0.975, dfree)*se_k
        if ub < np.log(1.5): out_ub15 += 1
        if ub < np.log(2.0): out_ub20 += 1
        # blockade fraction lower bound via Fieller-free bootstrap-lite: delta method on f = 1 - d_ko/d_wt
        if d_wt > 0:
            f = 1 - d_ko/d_wt
            var = (se_k**2)/d_wt**2 + (d_ko**2)*(se_k**2)/d_wt**4
            lb = f - st.t.ppf(0.975, dfree)*np.sqrt(var)
            if lb > thr_block: out_block += 1
    return out_int/nsim, out_ub15/nsim, out_ub20/nsim, out_block/nsim
print('n  SD  | P(interaction p<.05) | P(KO residual upper bound <1.5x) | P(<2x) | P(lower bound of blockade >50%)   [true: WT x3.0, KO x1.0]')
for sd in (0.35, 0.45, 0.55):
    for n in (8, 12, 16, 20):
        r = sim(n, sd)
        print(f'{n:2d} {sd:.2f} | {r[0]:.2f} | {r[1]:.2f} | {r[2]:.2f} | {r[3]:.2f}')
print('\nPartial blockade scenario (true: WT x3.0, KO x1.7 ~ 52% of log-effect remaining) -> power to detect interaction')
for sd in (0.45, 0.55):
    for n in (12, 16, 20):
        r = sim(n, sd, r_ko=1.7)
        print(f'{n:2d} {sd:.2f} | {r[0]:.2f} | ub<1.5: {r[1]:.2f} | ub<2: {r[2]:.2f}')
