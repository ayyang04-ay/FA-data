**Recommendation: take megakaryocyte creatine uptake through the SLC6A8 transporter forward as the primary target for next quarter's in vivo slot; hold megakaryocyte STAT5B (its Ser127 phosphorylation step) as first backup and creatine kinase B (CKB) as second backup, and run aspirin as the benchmark to beat, not as a target.**

# CRE-MK-01 validation proposal: the megakaryocyte creatine axis in metastasis

Prepared for the portfolio committee from the CRE-MK-01 source-data workbook, the phosphoproteomics table and the study-conventions document. Every number below was recomputed from the raw cell values; the derivations are in `CRE-MK-01_evidence_tables.xlsx` and `reanalysis/reanalysis.py`.

## 1. Decision in brief

- **The phenotype is robust.** Exogenous creatine raised lung metastatic burden 3.2-fold (95% CI 2.7–3.7) across 11 vehicle-controlled comparisons and shortened survival in both cohorts tested.
- **The effect is carried by platelets made under creatine.** Platelets from creatine-dosed mice, and from volunteers after 7 days of creatine, transferred the pro-metastatic phenotype to recipient mice.
- **SLC6A8 is the only candidate tested the decisive way.** Megakaryocyte-lineage deletion (Pf4-Cre;Slc6a8 flox/flox) removed 109% (95% CI 74–147%) of the creatine-induced rise in metastatic burden without altering serum creatine exposure. No integrity flag touches that experiment.
- **STAT5B is a backup because its in vivo evidence is not specific.** The only metastasis data come from a systemic inhibitor that hits STAT5A and STAT5B. The megakaryocyte Stat5b knockout was never tested against platelet function or metastasis.
- **CKB is second backup because it has no in vivo test.** Its knock-down and over-expression data in isolated megakaryocytes are clean.
- **The main programme risk applies to all three.** The axis mattered only when creatine was supplemented: neither the knockout nor the inhibitor lowered metastasis in vehicle-treated mice. The next study has to size that limitation.
- **What the slot buys.** A masked, powered, sex-balanced genotype × creatine study in the Slc6a8 knockout with an aspirin benchmark (Study 1, Section 5). The missing Stat5b-knockout metastasis experiment is the first add-on if capacity allows.

On efficacy alone the candidates cannot be separated: megakaryocyte Slc6a8 deletion and STAT5 inhibition both abolished the creatine effect. The ranking rests on how specific and how sound the evidence for each is.

## 2. What the data package shows

### 2.1 Creatine increases metastasis, and platelets carry the effect

| Finding | Data (panel; n per group) | Result, recomputed |
|---|---|---|
| Lung metastatic burden | 11 comparisons: Fig. 1b, 1f (two arms), 1k, 3i, 6b; Supp. Fig. 1e, 1f, 1g, 1i, 1k; n = 4–10 | Creatine/vehicle ratio of means 2.1–4.0 in every comparison; pooled 3.2× (2.7–3.7). Foci 2.0× (1.8–2.4); lung weight 1.36× (1.26–1.47) |
| Survival | Fig. 1c (10 + 10); Fig. 1l (20 + 18) | Median 22 → 19 days, hazard ratio 2.9 (1.04–8.2), log-rank P = 0.032; median 16 → 14 days, hazard ratio 2.3 (1.2–4.5), P = 0.011 |
| Early time course | Fig. 1h (6 + 6); Fig. 1i (8 fields) | Equal at 0.25 h (P = 0.31); creatine 1.5×, 1.8× and 2.8× higher at 6, 12 and 24 h (P = 0.0002, 0.026, 0.004). GFP+ cells per field 9.1 → 20.4 |
| Exposure | Supp. Fig. 1d (6 + 6); 1h (4 + 4); Fig. 3b (5 + 5) | Serum creatine 66 → 178 µM by gavage, 78 → 227 µM by 5% diet, 89 → 239 µM in the knockout study |
| General condition | Supp. Fig. 1a–c; 3a; Fig. 2a | Body weight, food, water, blood counts and platelet count unchanged |
| Megakaryocyte programme | Fig. 2f (3 + 3); Supp. Fig. 3c | 11-gene platelet-activation composite 3.1× (P = 0.001); 9 of 11 genes up. Megakaryopoiesis genes largely unchanged |
| Target cell | Fig. 2i (blot) | In vitro creatine raised GP6 and P2RY12 in megakaryocytes, not in platelets treated directly |
| Platelet function, mouse | Fig. 2b (3 + 3); 2c; 2d (5 + 5) | Aggregation higher to ADP, collagen and thrombin (see caution 2, Section 4); thromboelastography maximum amplitude 39.7 → 54.0 mm (P = 0.049); other clotting parameters unchanged |
| Platelet transfer, mouse donors | Supp. Fig. 2d (6 per group) | Recipient burden 5.9% with vehicle-donor platelets, 17.9% with creatine-donor platelets, 4.4% when donors also received aspirin |
| Platelet transfer, human donors | Fig. 7g (5 + 5 recipients) | Recipient burden 4.6% with day-0 platelets, 12.7% with day-7 platelets (P = 0.014) |

The Fig. 1h readout is not named in the sheet; its pattern fits retention of labelled tumour cells in lung over the first day. The pooled ratio is descriptive: it is 3.0× (2.5–3.7) if the flagged Fig. 6b arm and the tumour-knock-down arm are left out.

Averaged over the week, the mouse gavage regimen (17 mg three times a week in a mouse of about 21 g) and the volunteers' 20 g/day both work out at about 0.34 g/kg/day, and both produced serum creatine of roughly 150–240 µM. The 5% diet delivers roughly 20 times the gavage intake (at the food intake in Supp. Fig. 1b) yet gave the same serum level and the same effect size. That suggests the effect is already saturated at the gavage dose; the package contains no lower dose.

### 2.2 Where each candidate stands

![Node perturbation and metastasis](figures/fig2_node_perturbation_metastasis.png)

*Metastatic burden in the four intervention experiments, and the share of the creatine-induced increment each intervention removed (95% CI by Fieller's theorem; P for the intervention × creatine interaction). A value above 100% means the treated group on creatine finished below its own vehicle group.*

| Evidence | SLC6A8 (creatine entry) | CKB (intracellular step) | STAT5B (transcriptional step) |
|---|---|---|---|
| Megakaryocyte-lineage loss of function against metastasis | **Yes.** Fig. 3i, n = 4: burden 2.4 → 7.9% in Slc6a8+/+, 3.4 → 2.9% in knockout; 109% of the increment removed (74–147%), interaction P = 0.0003. Foci 107% (56–161%), P = 0.004 | Not tested | Not tested. The Pf4-iCre;Stat5b flox/flox mice exist, but no metastasis or platelet-function readout is in the package |
| In vivo pharmacology against metastasis | Not tested | Not tested | Fig. 6b, n = 5: STAT5-IN-1 removed 92% of the increment (70–113%), interaction P = 7 × 10⁻⁶. Systemic; inhibits STAT5A and STAT5B |
| Megakaryocyte gene programme (11-gene composite, n = 3) | Fig. 3f: 3.3× in Slc6a8+/+ vs 0.84× in knockout (P = 0.0001) | Fig. 4j: 3.7× with control siRNA vs 1.0× with si-Ckb (P = 0.0007) | Fig. 6a: inhibitor 5.3× → 0.57×, but it also halves baseline (0.52×). Fig. 6g: knockout 3.6× → 1.09× (P = 0.0009) |
| Completeness of the block | Complete for genes, α-granules (Supp. Fig. 4c) and GP6/P2RY12 protein (Fig. 3g blot) | Complete for genes; protein by single-lane blot (Fig. 4i) | Partial for the receptor genes: P2ry12, Gp6, Gpiba, F2r and Adra2a keep 33–49% of their induction in the knockout |
| Bypass or sufficiency | Supp. Fig. 4e: liposomal creatine restores the programme in knockout megakaryocytes (0.89× free vs 2.35× liposomal, P = 0.0001) | Fig. 4l: CKB over-expression alone gives 2.5× (P = 0.0001) with no change in creatine or phosphocreatine (Supp. Fig. 5c) | S127D phosphomimetic not tested functionally |
| Position and mechanism | Fig. 3b–c: knockout blocks 87% of the rise in megakaryocyte creatine (n = 3); the serum creatine rise is the same in both genotypes | Creatine raises megakaryocyte creatine 3.0×, phosphocreatine 3.9× and Ckb mRNA 1.8× (Fig. 4a, 4c, 4e). Added phosphocreatine does not mimic (0.63×, Fig. 4h), though its uptake was not shown. Blots show CKB-dependent STAT5B phosphorylation (Fig. 5g–i; Supp. Fig. 6d) | Creatine raises pan-phospho signal on wild-type STAT5B 1.39× and 1.28×, not on S127A (interaction P = 0.024 and 0.043; Fig. 5e, 5f). Promoter occupancy rises at P2ry12, Gp6 and Rab4a (Fig. 5j; Supp. Fig. 6i). Canonical Tyr694/699 phosphorylation is undetectable (Supp. Fig. 6a) |
| Controls | Cre-matched control genotype (Pf4-Cre;Slc6a8+/+); knockout-vehicle arm present | Scrambled siRNA; empty vector | Wild-type rather than Cre-matched controls; no knockout-vehicle arm (Fig. 6e–g) |
| Effect without creatine | None on metastasis (knockout-vehicle vs control-vehicle burden ratio 1.43, P = 0.14) | si-Ckb alone lowers the programme to 0.70× | None on metastasis (inhibitor alone, ratio 1.05) |
| Integrity flags on the key data | None found | None found | Three of five vehicle and three of five creatine animals in Fig. 6b duplicate animals in Supp. Fig. 2d |

**The relevant SLC6A8 is the host megakaryocyte's, not the tumour cell's.** Knocking Slc6a8 down in the melanoma cells left the creatine effect intact (burden 4.6 → 15.9% vs 5.8 → 18.3%; −10% of the increment removed, interaction P = 0.68; Fig. 1f). The knock-down was 81% at mRNA level but visibly partial on the protein blot (Supp. Fig. 2a), so a tumour-cell contribution is not fully excluded.

**Phosphoproteomics is hypothesis-level support for STAT5B.** Of 5,812 phosphopeptide rows, 238 have P < 0.05. That is 4.1% of all rows, or 5.8% of the 4,110 rows with signal in more than one replicate, against 5% expected by chance. None passes false-discovery control (minimum Q = 0.17). The Stat5b peptide has P = 0.0012 and Q = 0.25 and ranks 17th overall and 6th among increased peptides; 17 rows reach that P value where about 5 would by chance, so there is some signal, but not enough to single out one protein. Its 52-fold change is the size expected of a presence/absence call rather than a measured ratio. A second Stat5b peptide, the Stat5a peptide and the Jak2 peptide did not change. The table has no site column, so Ser127 rests on the mutagenesis in over-expressing cells.

### 2.3 Human cohort

![Human platelet response](figures/fig4_human_platelets.png)

*Maximum aggregation for each volunteer relative to their own day 0 (log scale), and platelet GP6 and P2RY12 protein.*

Eleven healthy volunteers aged 20–25 (6 women, 5 men) took 20 g/day for 14 days. There was no placebo arm.

**Exposure.** Serum creatine rose from 45 to 153, 156 and 159 µM at days 3, 7 and 14 (3.4–3.5×; all 11 volunteers; Fig. 7b). Platelet count, platelet indices and body-mass index did not change (Supp. Fig. 8a, 8b).

**Platelet function (Fig. 7c).** The sheet tests normalised fold changes with an unpaired ANOVA. Re-analysed as paired data on the log scale, maximum aggregation relative to each volunteer's own day 0 was:

| Agonist | Day 3 | Day 7 | Day 14 |
|---|---|---|---|
| Collagen | 1.01× (6 of 11 up; P = 0.64) | 1.25× (8 of 11; P = 0.10) | **2.51×** (9 of 11; P = 0.005) |
| Epinephrine | 0.86× (5 of 11; P = 0.37) | **1.33×** (10 of 11; P = 0.005) | **1.63×** (10 of 11; P = 0.002) |
| Arachidonic acid | 0.86× (5 of 11; P = 0.77) | 1.04× (7 of 11; P = 0.24) | 1.32× (9 of 11; P = 0.04) |
| ADP | 0.77× (5 of 11; P = 0.70) | 1.03× (6 of 11; P = 0.64) | 1.07× (6 of 11; P = 0.47) |

Values are geometric means with Wilcoxon signed-rank P; bold entries stay below 0.05 after Benjamini–Hochberg correction across all 36 agonist × metric × day tests. Nothing had changed at day 3, although serum creatine had already plateaued. That lag fits platelets being reprogrammed at the megakaryocyte rather than in circulation.

**Platelet protein (Fig. 7e; n = 4; immunoblot densitometry).** GP6 rose 2.0× at day 7 and 2.6× at day 14 (4 of 4 up; paired P = 0.044 and 0.022). P2RY12 rose 1.3–1.7× at all three time points (4 of 4 up; P = 0.018–0.033).

**Transcripts in circulating CD41+ cells (Fig. 7d; n = 4).** Responses were heterogeneous. ADRA2A rose in 4 of 4 at day 7 (21×) and day 14 (4×); GPIBA and F2R rose in 4 of 4 at day 7 (10× and 6×). GP6 and P2RY12 rose in 3 of 4 at days 7 and 14 (geometric means 3–6×; not significant with n = 4). RAB4A fell in 4 of 4 at day 14 (0.38×), the opposite of mouse. One volunteer decreased or did not change for most genes.

The human data confirm that creatine loading makes platelets more reactive and pro-metastatic on transfer. They contain nothing on SLC6A8, CKB or STAT5B, so they do not discriminate between the candidates. The agonist pattern matches the receptor data: the collagen response rose with GP6, and the epinephrine response with ADRA2A, while the ADP response did not move despite modestly higher P2RY12 protein. Collagen-induced aggregation and platelet GP6 are therefore the most consistent human pharmacodynamic readouts.

## 3. Why this ranking

**SLC6A8 first.** It is the entry point, and removing it in the megakaryocyte lineage blocks every downstream readout measured: megakaryocyte creatine, the gene programme, α-granules, GP6/P2RY12 protein and metastasis. The liposomal-creatine bypass shows the knockout phenotype reflects lack of creatine entry, not a defective megakaryocyte. Because SLC6A8 sits at the entry, removing it also removes the part of the response that survives loss of STAT5B. The design has the right controls, and the key experiment is free of integrity flags. Its weaknesses are the small group size (n = 4), an incomplete protein knockout in the megakaryocyte preparation (roughly one-third of the band remains on my rough reading of the Supp. Fig. 4a image), and no pharmacological tool in the package.

**STAT5B second.** The mechanistic story is coherent, and one experiment in mice that already exist would close its main gap. It is not the lead today for five reasons:

1. The in vivo inhibitor cannot attribute the effect to STAT5B, to megakaryocytes, or to Ser127, and the package has no pharmacodynamic readout showing target engagement in vivo.
2. The megakaryocyte knockout was never tested for platelet function or metastasis.
3. Five platelet-receptor genes keep a third to a half of their induction without STAT5B.
4. The starting point was a nominal phosphoproteomic hit.
5. Part of the Fig. 6b data is duplicated in another experiment.

There is also a weak safety hint: platelet count was lowest in both STAT5-blocked, creatine-treated groups (598 and 693 × 10⁹/L against 646–896 in the other groups; n = 3; not significant after correction; Supp. Fig. 7a, 7b).

**CKB third.** Knock-down and over-expression in primary megakaryocytes show necessity and sufficiency for the gene programme. CKB is also the only node that drives the programme without added creatine, which could matter for the baseline question. Everything is in vitro with n = 3 or single blots, and the proposed protein-kinase action on STAT5B rests on over-expression and one in vitro kinase blot.

**Aspirin is a comparator.** Aspirin given to creatine-dosed donors abolished the pro-metastatic activity of their platelets (112% of the increment reversed, 95% CI 74–178%; Supp. Fig. 2d). Any new agent has to beat that on efficacy or bleeding risk. The experiment has no aspirin-alone arm and carries the duplication flag.

**Downstream receptors are readouts, not candidates.** GP6 and P2RY12 were never perturbed in this package.

## 4. Cautions about the package

| # | Observation | Consequence |
|---|---|---|
| 1 | Burden values 3.29136, 3.733544, 2.886353 (vehicle) and 11.13465, 13.22011, 14.12619 (creatine), with their foci counts 37/25/33 and 53/62/47, appear in both Fig. 6b (rows 5–7, 14–16) and Supp. Fig. 2d (rows 8–10, 17–19). One is a direct-treatment experiment, the other a platelet-transfer experiment | Source records for both need checking before either is used as decision-grade evidence. Both conclusions hold if the shared values are dropped, but on n = 2–3 in the reference arms |
| 2 | In Fig. 2b the third value in each of the six groups is the exact mean of the other two. In Fig. 3d, 11 of 12 groups are two identical values plus one 2 units away. None of 49 other n = 3 groups shows either pattern | Mouse aggregation values look like technical replicates, not independent animals. With n = 2, Fig. 2b gives P = 0.02–0.04, not ≤ 0.001. The reversal of aggregation in knockout mice given creatine (Fig. 3d) is unexplained |
| 3 | Allocation was not masked; no sample-size calculation; sex not analysed, and sex is confounded with strain (male C57BL/6J, female BALB/cJ). The normality test named in the conventions needs at least eight values, and most groups have three to six | All effect sizes are open to bias; none is confirmed in both sexes; parametric assumptions are untested |
| 4 | n is eight microscope fields, not animals, in Fig. 1i, 2c, 2j and Supp. Fig. 4c | Those P values do not reflect animal-to-animal variation |
| 5 | Human study: single arm, single dose (20 g/day), 11 healthy Asian volunteers aged 20–25; transcript and protein data on 4 of them | Time or assay drift is not excluded; generalisation and dose relevance unknown |
| 6 | Fig. 7d: for volunteer 4, the RAB27B and PITPNB summary values do not follow from the ΔCT values in the sheet (PITPNB 6.3× stated vs 0.59× recalculated at day 14) | Two secondary genes; not decision-critical, but traceability needs fixing |
| 7 | Missing controls: aspirin alone; Stat5b knockout with vehicle; Cre-matched control for Stat5b; in vivo target engagement for STAT5-IN-1 | Limits what the aspirin and STAT5B experiments can prove |
| 8 | Most immunoblots are one to three lanes without densitometry in the workbook; loading controls ran on separate gels | Protein-level statements are qualitative except Fig. 5e, 5f and 7e |
| 9 | Labelling: the tumour model is named only in Fig. 1f (melanoma); Fig. 1h has no readout name; Fig. 4d is labelled "Creatinine" while the assay is for creatine; coagulation tests mentioned in the conventions are not in the workbook | Assumptions listed in Section 7 |

The embedded statistics are otherwise arithmetically sound: all 71 two-group tests and every Tukey, Dunnett, Šidák and log-rank result reproduce from the raw values.

## 5. Follow-up studies

### Study 1 (next quarter's in vivo slot): megakaryocyte SLC6A8 confirmation

This is not a repeat for its own sake. The existing result rests on four unmasked animals per group in one sex, and the package cannot say whether the target matters without supplementation or how it compares with aspirin. The core design answers those questions; the add-on arms cover exposure and reversibility.

| Element | Specification |
|---|---|
| Objective | Confirm that megakaryocyte SLC6A8 is required for creatine-driven metastasis under masked, powered, sex-balanced conditions; measure whether it matters without supplementation; benchmark against aspirin |
| Population | Pf4-Cre;Slc6a8 flox/flox and Pf4-Cre;Slc6a8+/+ littermates, both sexes, randomised within sex. Slc6a8 is X-linked (general knowledge, not from the package), so genotype by sex needs to be specified |
| Indication model | The melanoma lung-metastasis model used in Fig. 3i (to be confirmed). A second syngeneic model in which metastasis arises from a primary tumour, if none of the CRE-MK-01 models did |
| Core arms | Genotype × exposure: Slc6a8+/+ vehicle, Slc6a8+/+ creatine, knockout vehicle, knockout creatine. Creatine by the CRE-MK-01 gavage regimen |
| Comparators | In Slc6a8+/+ mice: creatine + aspirin and vehicle + aspirin (30 mg/kg daily, as in CRE-MK-01). This supplies the aspirin-alone control the package lacks |
| Primary endpoint | Lung metastatic burden (% of lung area), read masked, analysed on the log scale. Primary test: genotype × creatine interaction |
| Secondary endpoints | Number of foci; lung weight; 24-hour lung retention of labelled tumour cells in a satellite cohort; survival in a satellite cohort if capacity allows |
| Target-engagement and pharmacodynamic readouts | Serum creatine; megakaryocyte intracellular creatine; platelet GP6 and P2RY12 protein; megakaryocyte gene composite; platelet aggregation to collagen, thrombin and ADP on independent animals |
| Safety readouts | Platelet count and indices; bleeding time; body weight |
| Size | 12 per arm (6 per sex); 72 animals for the six arms. This gives 90% power for a 75% block and 99% for a full block at a conservative log-SD of 0.45, and detects a baseline reduction of about 40%. It checks consistency between sexes but is not powered for a sex interaction. Satellite cohorts of 6 per core arm for early lung retention and for target-engagement and platelet readouts add 48 |
| Analysis | Pre-specified before unmasking: two-way model on log burden with sex as a blocking factor; share of the creatine increment removed with its confidence interval |
| Decision rule | Confirmed: at least 75% of the creatine increment removed, interaction P < 0.05, same direction in both sexes, and megakaryocyte creatine rise blocked by at least 70%. Demoted: less than 50% removed or no target engagement |

Add-on arms, in priority order if capacity allows:

1. **Stat5b qualifier** (Study 2 below), run alongside.
2. **Lower exposure.** One creatine arm giving roughly half the serum rise, in both genotypes, to find out whether the effect exists below the plateau.
3. **Withdrawal.** Creatine stopped before tumour-cell challenge for at least one platelet turnover, to learn whether stopping supplementation is enough.
4. **Attribution by transfer.** Platelets from creatine-dosed knockout versus Slc6a8+/+ donors into wild-type recipients.

### Study 1b: pharmacological SLC6A8 blockade (after Study 1, or as an arm if a tool compound is in hand)

No SLC6A8 inhibitor was tested in CRE-MK-01, so tractability is unproven. This is the step that turns a genetic result into a drug target.

| Element | Specification |
|---|---|
| Objective | Show that blocking SLC6A8 with a compound reproduces the knockout |
| Entry criterion | A tool compound that blocks the creatine-induced rise in megakaryocyte creatine (the Fig. 3c readout) at a tolerated exposure |
| Population and arms | Wild-type mice, both sexes: vehicle or creatine, each with and without inhibitor. Knockout mice on creatine with and without inhibitor as the specificity control (no further effect expected) |
| Comparators | Aspirin; the Slc6a8 knockout |
| Endpoints and readouts | As Study 1 |
| Safety readouts | As Study 1, plus brain creatine, since brain carries high creatine and CKB (Fig. 4a, 4b) |

### Study 2: megakaryocyte STAT5B qualifier (first backup)

| Element | Specification |
|---|---|
| Objective | Supply the missing test: does megakaryocyte-lineage Stat5b deletion block creatine-driven metastasis? |
| Population | Pf4-iCre;Stat5b flox/flox and Pf4-iCre;Stat5b+/+ (Cre-matched), both sexes |
| Indication model | As Study 1 |
| Arms and comparators | Genotype × vehicle/creatine, including the knockout-vehicle arm absent from Fig. 6e–g. Comparator: STAT5-IN-1 (5 mg/kg daily, as in CRE-MK-01) given to creatine-treated mice of both genotypes. If the knockout blocks only partly, any further block by the inhibitor places the remainder in STAT5A or outside the megakaryocyte lineage |
| Endpoints and readouts | As Study 1. Add megakaryocyte creatine (should stay high), CKB (should stay induced), and a Ser127 phosphorylation readout on endogenous STAT5B once an assay exists |
| Safety | Platelet count is a key readout here, given the hint in Supp. Fig. 7a and 7b |
| Longer term | A Ser127-to-alanine Stat5b allele is the definitive test of the site; it is not a next-quarter study |
| Size and rule | 12 per arm; same decision rule as Study 1 |

### Study 3: CKB, first in vivo test (second backup)

| Element | Specification |
|---|---|
| Objective | Establish whether megakaryocyte CKB is required in vivo, and whether its catalytic activity is what matters |
| Enabling step, no animals | In Ckb-silenced megakaryocytes, test whether catalytically inactive CKB restores the creatine response. This decides whether an active-site inhibitor is a valid modality |
| Population and arms | Megakaryocyte-restricted Ckb loss of function (conditional allele or marrow chimera) against matched controls, × vehicle/creatine; both sexes |
| Indication model and comparators | As Study 1, with the Slc6a8 knockout on creatine as the positive-control arm |
| Endpoints and readouts | As Study 1, plus megakaryocyte phosphocreatine and STAT5B Ser127 phosphorylation |

### Study 4: human pharmacodynamic study (no animal slot)

| Element | Specification |
|---|---|
| Objective | Confirm the platelet effect against placebo and establish dose dependence and reversibility |
| Population | Healthy adults, both sexes, wider age range and more than one ancestry than the CRE-MK-01 cohort; no antiplatelet or anti-inflammatory drugs |
| Arms and comparator | Randomised, double-blind: placebo, a standard maintenance dose, and the 20 g/day used in CRE-MK-01; 14 days, then washout with follow-up |
| Primary endpoint | Change in collagen-induced maximum aggregation at day 14 versus placebo, log scale |
| Secondary readouts | Epinephrine-, ADP- and arachidonic-acid-induced aggregation; platelet GP6 and P2RY12 protein by a quantitative method; platelet count; serum creatine; time to return to baseline after stopping. Exploratory: the gene panel in circulating CD41+ cells |
| Size | About 20 per arm gives 90% power for the effect seen at 20 g/day; about 70 per arm if the lower dose has half that effect |
| Patients | No interventional creatine dosing in cancer patients, since the hypothesis is harm. An observational comparison of creatine users and non-users (serum creatine, platelet reactivity) is the appropriate first step |

**Indications.** The package supports one setting: blood-borne seeding of lung metastases under high exogenous creatine exposure. The tumour types are melanoma (the only one named in the workbook) and whatever was run in the female BALB/cJ mice, which the files do not record. Any wider indication is an extrapolation until Study 1 answers the baseline and dose questions.

## 6. What would move one candidate above another

| Information | Effect on the ranking |
|---|---|
| Study 1 confirms the block in both sexes with target engagement | SLC6A8 stays primary |
| Study 1 removes less than 50% of the increment, or fails to replicate | SLC6A8 demoted; the lead passes to whichever backup has in vivo support |
| A SLC6A8 inhibitor engages the target in megakaryocytes and reproduces the knockout (Study 1b) | SLC6A8 is confirmed as tractable. If it engages the target and does not reproduce the knockout, the genetic result needs re-examining before further investment |
| Stat5b knockout blocks at least 75% of the increment with no fall in platelet count | STAT5B becomes co-lead. It moves ahead of SLC6A8 if it also lowers metastasis without creatine, or if SLC6A8 blockade shows a bleeding or tissue-creatine liability |
| Stat5b knockout blocks only part of the increment, in line with the 33–49% residual receptor-gene induction | STAT5B is a partial mediator at best; CKB, which sits upstream of it, becomes first backup |
| Stat5b knockout blocks only partly and STAT5-IN-1 removes the rest | The Fig. 6b result was not megakaryocyte STAT5B alone; the pharmacology evidence for STAT5B is discounted |
| In vivo megakaryocyte Ckb loss of function blocks the effect, and catalytic activity is required | CKB moves above STAT5B on tractability. It becomes lead if megakaryocyte CKB drives platelet reactivity without supplementation |
| Any knockout lowers metastasis in vehicle-treated mice | That node gains most: the population widens from creatine users to all patients at risk |
| No effect at the lower creatine exposure, or full reversal on withdrawal | The finding becomes a supplement-safety matter; the case for any drug target weakens |
| Aspirin matches the knockout in Study 1 with acceptable bleeding | The bar for a new agent rises to safety differentiation only |
| Source-record check fails for Fig. 6b or Supp. Fig. 2d | STAT5B and aspirin evidence weaken further; SLC6A8 is unaffected |

## 7. Assumptions to confirm with the study team

- Which tumour line, mouse strain and route was used in each panel, especially Fig. 3i, Fig. 1j–l and Supp. Fig. 1e–k. The workbook names only "melanoma" in Fig. 1f.
- What Fig. 1h measures, and what Fig. 2j (PKH-positive area) measures.
- Whether the Fig. 2b and 3d aggregation values are technical replicates of pooled platelets.
- The source records behind the duplicated values in Fig. 6b and Supp. Fig. 2d.
- How many volunteers supplied the platelets for Fig. 7g.
- That both knockout colonies can supply sex-balanced cohorts next quarter.

## Appendix A. How the numbers were derived

- **Two-group panels.** Unpaired two-tailed t tests recomputed from raw values for all 71 panels; all match the embedded GraphPad results. Welch and Mann–Whitney tests are alongside in the evidence tables.
- **Multi-group panels.** One-way ANOVA with Tukey comparisons recomputed; all match. For 2 × 2 designs I added the two-way interaction test and "share of the creatine increment removed" = 1 − (creatine − vehicle in perturbed)/(creatine − vehicle in control), with a 95% CI by Fieller's theorem on the pooled within-group variance. A percentile bootstrap gives narrower intervals and is kept in the evidence tables as a cross-check. With n = 4–5 either interval is indicative.
- **Pooled creatine effect.** Geometric-mean ratio per experiment (t interval on logs), pooled by random effects. Descriptive.
- **Survival.** Log-rank recomputed (matches); Cox hazard ratio added. No animals were censored.
- **Gene panels.** The 2^ΔΔCT arithmetic was verified from the ΔCT values (maximum deviation 0.3%). The composite is the mean log2 relative expression of the 11 genes per replicate, compared by t test on n = 3 replicates.
- **Human aggregation.** One-sample t test on log2 fold change and Wilcoxon signed-rank test against no change; Benjamini–Hochberg and Holm correction across the 36 agonist × metric × day tests. Rows are assumed to be the same volunteer across blocks.
- **Phosphoproteomics.** Counts against the study's screening rule (P < 0.05 and fold ≥ 1.2 or ≤ 0.83), the Q values supplied, and a recomputed Benjamini–Hochberg adjustment.
- **Integrity scans.** Values and ordered runs shared between sheets; n = 3 groups where one value is the exact mean of the other two.
- **Blots.** Read by eye from the embedded images. Rough densitometry only for the two knock-down/knockout validation blots, quoted as approximate.
- **Power.** Non-central t for the interaction contrast on log burden, using the pooled creatine effect (log 3.16) and within-group log-SDs observed across experiments (median 0.34, maximum 0.57).

## Appendix B. Panel inventory

| Panel | Design (n per group) | Result, recomputed |
|---|---|---|
| Fig. 1a | Lung weight, PET signal (6 + 6) | 0.227 → 0.324 g (P = 0.0003); SUV 418 → 894 (P = 0.003) |
| Fig. 1b | Histology (6 + 6) | Burden 5.2 → 16.2% (P = 0.0005); foci 27.7 → 53.2 (P = 0.0006) |
| Fig. 1c | Survival (10 + 10) | Median 22 → 19 days; P = 0.032 |
| Fig. 1f | Melanoma sh-scrambled vs sh-Slc6a8 × creatine (6) | Creatine effect retained in both; interaction P = 0.68 |
| Fig. 1h | Time course, readout unnamed (6 + 6) | Equal at 0.25 h; higher with creatine at 6, 12, 24 h |
| Fig. 1i | GFP+ cells per field (8 fields) | 9.1 → 20.4 |
| Fig. 1j, 1k | Second cohort (6 + 6) | Lung weight 0.185 → 0.302 g; burden 7.2 → 16.4%; foci 25.5 → 42.2 |
| Fig. 1l | Survival (20 + 18) | Median 16 → 14 days; P = 0.011 |
| Supp. Fig. 1a–c | Body weight (4 + 4), food, water (6 + 6) | No difference (weight day 7: +6%, P = 0.08) |
| Supp. Fig. 1d | Serum creatine (6 + 6) | 66 → 178 µM |
| Supp. Fig. 1e, 1f, 1g, 1k | Further cohorts (6, 4, 10, 10) | Burden ratio 2.1×, 2.8×, 3.5×, 3.5×; all P < 0.01 |
| Supp. Fig. 1h, 1i | Creatine diet (4 + 4) | Serum creatine 78 → 227 µM; burden 7.3 → 26.2% (P = 0.005) |
| Supp. Fig. 2a | Tumour-cell Slc6a8 knock-down (3 + 3; blot) | mRNA 0.19× (P = 0.0008); protein band reduced but present |
| Supp. Fig. 2d | Donor-platelet transfer ± aspirin (6) | Burden 5.9 / 17.9 / 4.4%; foci 33.8 / 56.3 / 28.7 |
| Fig. 2a | Platelet count and indices (3 + 3) | Unchanged |
| Fig. 2b | Aggregation (3 + 3) | ADP 42 → 57; collagen 66 → 79; thrombin 25 → 56 |
| Fig. 2c | α-granules (8 fields) | 2.0 → 3.9 |
| Fig. 2d | Thromboelastography (5 + 5) | Maximum amplitude 39.7 → 54.0 mm (P = 0.049); R, K, angle not significant |
| Fig. 2e, 2g | GP6, P2RY12 blots, platelets and megakaryocytes (3 lanes) | Visibly higher with creatine |
| Fig. 2f | Megakaryocyte gene panel (3 + 3) | Composite 3.1× |
| Fig. 2i | In vitro creatine on megakaryocytes vs platelets (blot) | Induction in megakaryocytes only |
| Fig. 2j | PKH-positive area (8 fields) | 1.9 → 4.5% |
| Supp. Fig. 3a | White cells, lymphocytes, monocytes, red cells (5 + 5) | Unchanged |
| Supp. Fig. 3c | Megakaryopoiesis genes (3 + 3) | 6 of 9 unchanged; Hsd3b1 1.4×, Casp12 1.9×, Myl9 0.5× |
| Fig. 3b | Serum creatine by genotype (5) | 89 → 239 µM control; 89 → 218 µM knockout |
| Fig. 3c | Megakaryocyte creatine (3) | 13.7 → 72.1 control; 13.7 → 21.1 µmol/g knockout |
| Fig. 3d | Aggregation by genotype (3) | Control up (ADP 63 → 71); knockout down (54 → 31) |
| Fig. 3f | Gene panel (3) | 3.3× control; 0.84× knockout with creatine |
| Fig. 3g | GP6, P2RY12 blot (2 lanes) | Induced in control genotype only |
| Fig. 3i | Metastasis by genotype (4) | See Section 2.2 |
| Supp. Fig. 4a | SLC6A8 blot, megakaryocytes | Reduced, not absent, in knockout |
| Supp. Fig. 4b | Platelet count (3) | No differences |
| Supp. Fig. 4c | α-granules (8 fields) | 2.6 → 5.1 control; 2.25 → 2.25 knockout |
| Supp. Fig. 4e | Knockout megakaryocytes, free vs liposomal creatine (3) | 0.89× vs 2.35× |
| Fig. 4a, 4c | Creatine, phosphocreatine in megakaryocytes and brain (3) | Megakaryocytes 3.0× and 3.9×; brain 1.19× and 1.95× |
| Fig. 4b, 4e | CKB blots; Ckb mRNA (3 + 3) | Protein higher with creatine; mRNA 1.8× (P = 0.011) |
| Fig. 4d, 4f | Megakaryocytes in vitro (3 + 3) | Creatine 3.6× (P = 0.005); phosphocreatine 5.4× (P = 0.023) |
| Fig. 4g | Blot: control, creatine, phosphocreatine | CKB, GP6, P2RY12 rise with creatine |
| Fig. 4h | Gene panel (3) | Creatine 3.3×; phosphocreatine 0.63× |
| Fig. 4i, 4j | si-Ckb (blot; 3) | 3.7× → 1.0× |
| Fig. 4k, 4l | CKB over-expression (blot; 3) | 2.5× |
| Supp. Fig. 5a | Gatm, Gamt mRNA (3 + 3) | Unchanged |
| Supp. Fig. 5b | si-Ckb and over-expression validation blots | Confirmed |
| Supp. Fig. 5c | Creatine, phosphocreatine with CKB over-expression (3 + 3) | Unchanged |
| Phosphoproteomics | Megakaryocytes (3 + 3 mice) | See Section 2.2 |
| Fig. 5e, 5f | STAT5B mutants ± creatine (3 blots each) | Wild type 1.39×, 1.28×; S127A 1.06×, 0.88× |
| Fig. 5g–i | CKB manipulation and STAT5B phosphorylation (blots) | Consistent with CKB- and S127-dependence; not quantified |
| Fig. 5j | ChIP-qPCR, P2ry12 and Gp6 (3 + 3) | P2ry12 promoter 4.6–12×; Gp6 2.9–3.8× at −1 and −0.2 kb; exons unchanged |
| Supp. Fig. 6a | Phospho-Tyr694/699 STAT5 blot | Not detected in megakaryocytes; detected in positive control |
| Supp. Fig. 6d | In vitro kinase blot | Higher phospho-signal with CKB |
| Supp. Fig. 6e–g | Cell-line validation blots | Confirmed |
| Supp. Fig. 6h | Nuclear STAT5B blot (2 lanes) | Higher with creatine |
| Supp. Fig. 6i | ChIP-qPCR, Rab4a (3 + 3) | 2.7× at −1 kb; 5.5× at −0.2 kb |
| Fig. 6a | Gene panel ± STAT5-IN-1 (3) | 5.3× → 0.57×; inhibitor alone 0.52× |
| Fig. 6b | Metastasis ± STAT5-IN-1 (5) | Burden 3.4 / 13.9 / 3.6 / 4.5% |
| Supp. Fig. 7a | Platelet indices ± inhibitor (3) | No significant differences |
| Fig. 6d | STAT5B blot | Absent in knockout megakaryocytes |
| Fig. 6e | Megakaryocyte creatine (3) | 20 → 95 wild type; 98 µmol/g knockout with creatine |
| Fig. 6f | Blots (single lanes) | CKB induction retained; GP6/P2RY12 induction blunted |
| Fig. 6g | Gene panel (3) | 3.6× wild type; 1.09× knockout with creatine |
| Supp. Fig. 7b | Platelet indices (3) | Count 896 / 760 / 693 × 10⁹/L |
| Fig. 7b | Volunteer serum creatine (11) | 45 → 153, 156, 159 µM |
| Fig. 7c | Volunteer aggregation (11) | See Section 2.3 |
| Fig. 7d | CD41+ cell transcripts (4) | See Section 2.3 |
| Fig. 7e | Platelet GP6, P2RY12 protein (4) | See Section 2.3 |
| Fig. 7g | Volunteer platelets into mice (5 + 5) | Burden 4.6 → 12.7%; foci 21.8 → 39.4; lung weight 0.186 → 0.236 g |
| Supp. Fig. 8a, 8b | Body-mass index; platelet indices (11) | Unchanged |
| Supp. Fig. 8c | CD41 mRNA in isolated CD41+ cells, monocytes, MEG-01 (3) | Monocytes 0.06×; MEG-01 0.71× of CD41+ cells |
| Supp. Fig. 8d | Volunteer platelet blots | Source for Fig. 7e |

## Appendix C. Supporting figures

![Creatine phenotype across experiments](figures/fig1_creatine_phenotype.png)

*Creatine versus vehicle in every metastasis experiment in the package: geometric-mean ratio with 95% CI; dashed line and band show the pooled estimate.*

![Megakaryocyte gene programme](figures/fig3_mk_gene_programme.png)

*The 11-gene platelet-activation composite in megakaryocytes across the eight gene-panel experiments. Bars are the geometric mean of three replicates (dots), relative to each panel's control.*

![Phosphoproteomics](figures/fig5_phosphoproteomics.png)

*Megakaryocyte phosphoproteomics, creatine versus vehicle (n = 3 mice per group). Blue points meet the study's screening rule; the Stat5b peptide is highlighted.*
