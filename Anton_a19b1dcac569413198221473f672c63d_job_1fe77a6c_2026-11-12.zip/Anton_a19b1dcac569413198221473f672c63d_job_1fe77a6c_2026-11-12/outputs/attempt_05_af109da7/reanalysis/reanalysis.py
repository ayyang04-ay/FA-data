#!/usr/bin/env python
"""
CRE-MK-01 — independent re-analysis of the source-data workbook and the phosphoproteomics table.

Run:  micromamba run -n singlecell python reanalysis.py
Inputs  (read-only): /tmp/world/filesystem/CRE-MK-01_source_data.xlsx, CRE-MK-01_phosphoproteomics.xlsx
Outputs: ../CRE-MK-01_evidence_tables.xlsx and ../figures/*.png

Every number quoted in the proposal is produced here from the raw cell values (cell ranges are given in the
tables).  Where the workbook carries an embedded GraphPad result, it is re-derived and compared.
"""
import os, re, warnings, collections
import numpy as np, pandas as pd, openpyxl
from scipy import stats
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker

warnings.filterwarnings("ignore")
SRC  = "/tmp/world/filesystem/CRE-MK-01_source_data.xlsx"
PHOS = "/tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx"
HERE = os.path.dirname(os.path.abspath(__file__))
OUT_XLSX = os.path.join(HERE, "..", "CRE-MK-01_evidence_tables.xlsx")
FIGDIR = os.path.join(HERE, "..", "figures")
os.makedirs(FIGDIR, exist_ok=True)
RNG = np.random.default_rng(20240607)

WB = openpyxl.load_workbook(SRC, data_only=True)

def col(sheet, rng):
    ws = WB[sheet]; vals = []
    for row in ws[rng]:
        for c in row:
            if isinstance(c.value, (int, float)): vals.append(float(c.value))
    return np.array(vals)

def cell(sheet, ref): return WB[sheet][ref].value

S1 = "Supplementary Fig  1"   # sheet-name prefixes (note the double space in the workbook)
def S(n): return f"Supplementary Fig  {n}"

# ----------------------------------------------------------------------------------------------------------
# 1. Two-group panels: re-derive every unpaired t test that the workbook reports
# ----------------------------------------------------------------------------------------------------------
T = [  # sheet, label, control range, test range, reported-P cell, reported "t, df" cell
 ("Fig. 1a","Lung weight (g)","B3:B8","C3:C8","F4","F8"), ("Fig. 1a","SUV-BW","B12:B17","C12:C17","F12","F16"),
 ("Fig. 1b","Metastatic burden (%)","B3:B8","C3:C8","F3","F7"), ("Fig. 1b","Metastatic foci (n)","B12:B17","C12:C17","F12","F16"),
 ("Fig. 1h","time-course readout 0.25 h","B4:G4","H4:M4","B17","B21"), ("Fig. 1h","time-course readout 6 h","B5:G5","H5:M5","E17","E21"),
 ("Fig. 1h","time-course readout 12 h","B6:G6","H6:M6","H17","H21"), ("Fig. 1h","time-course readout 24 h","B7:G7","H7:M7","K17","K21"),
 ("Fig. 1i","GFP+ cells per field (8 fields)","B4:B11","C4:C11","F4","F8"),
 ("Fig. 1j","Lung weight (g)","B4:B9","C4:C9","F4","F8"), ("Fig. 1j","SUV-BW","B13:B18","C13:C18","F13","F17"),
 ("Fig. 1k","Metastatic burden (%)","B4:B9","C4:C9","F4","F8"), ("Fig. 1k","Metastatic foci (n)","B12:B17","C12:C17","F12","F16"),
 ("Fig. 2a","PLT (x10^9/L)","B4:B6","C4:C6","F4","F8"), ("Fig. 2a","PCT (%)","B12:B14","C12:C14","F12","F16"),
 ("Fig. 2a","PDW (fl)","B19:B21","C19:C21","F19","F23"), ("Fig. 2a","MPV (fl)","B27:B29","C27:C29","F27","F31"),
 ("Fig. 2b","Aggregation, ADP","B4:D4","E4:G4","B18","B22"), ("Fig. 2b","Aggregation, collagen","B5:D5","E5:G5","B32","B36"),
 ("Fig. 2b","Aggregation, thrombin","B6:D6","E6:G6","B45","B49"),
 ("Fig. 2c","alpha-granules (8 fields)","B4:B11","C4:C11","F5","F9"),
 ("Fig. 2d","TEG-R (min)","B4:B8","C4:C8","F4","F8"), ("Fig. 2d","TEG-K (min)","B12:B16","C12:C16","F12","F16"),
 ("Fig. 2d","TEG-alpha (deg)","B20:B24","C20:C24","F20","F24"), ("Fig. 2d","TEG-MA (mm)","B28:B32","C28:C32","F28","F32"),
 ("Fig. 2j","PKH-positive area % (8 fields)","B4:B11","C4:C11","F4","F8"),
 ("Fig. 3b","Serum creatine (uM), Pf4-Cre;Slc6a8+/+","B4:F4","G4:K4","B17","B21"),
 ("Fig. 3b","Serum creatine (uM), Pf4-Cre;Slc6a8fl/fl","B5:F5","G5:K5","B31","B35"),
 ("Fig. 3c","MK creatine, Pf4-Cre;Slc6a8+/+","B4:D4","E4:G4","B15","B19"),
 ("Fig. 3c","MK creatine, Pf4-Cre;Slc6a8fl/fl","B5:D5","E5:G5","B30","B34"),
 ("Fig. 4a","Creatine (umol/g), MKs","B4:B6","C4:C6","H10","H14"), ("Fig. 4a","Creatine (umol/g), brain","D4:D6","E4:E6","H24","H28"),
 ("Fig. 4c","Phosphocreatine (ng/ug), MKs","B4:B6","C4:C6","H10","H14"), ("Fig. 4c","Phosphocreatine (ng/ug), brain","D4:D6","E4:E6","H24","H28"),
 ("Fig. 4d","Creatine (sheet label 'Creatinine'), MKs in vitro","C4:C6","D4:D6","G10","G14"),
 ("Fig. 4e","Ckb mRNA, MKs","E8:G8","I8:K8","O5","O9"),
 ("Fig. 4f","Phosphocreatine, MKs in vitro","B4:B6","C4:C6","F4","F8"),
 ("Fig. 7g","Lung weight (g), human-platelet recipients","B4:B8","C4:C8","F4","F8"),
 ("Fig. 7g","Metastatic burden (%), human-platelet recipients","B12:B16","C12:C16","F12","F16"),
 ("Fig. 7g","Metastatic foci (n), human-platelet recipients","B19:B23","C19:C23","F19","F23"),
 (S("1a"),"Body weight d0 (g)","B4:E4","F4:I4","M11","M15"), (S("1a"),"Body weight d7 (g)","B5:E5","F5:I5","M25","M29"),
 (S("1b"),"Food intake (g/d)","B4:B9","C4:C9","F4","F8"), (S("1c"),"Water intake (g/d)","B4:B9","C4:C9","F4","F8"),
 (S("1d"),"Serum creatine (uM)","B4:B9","C4:C9","F4","F8"),
 (S("1e"),"Lung weight (g)","B4:B9","C4:C9","F4","F8"), (S("1e"),"Metastatic burden (%)","B13:B18","C13:C18","F13","F17"), (S("1e"),"Metastatic foci (n)","B22:B27","C22:C27","F22","F26"),
 (S("1f"),"Lung weight (g)","B4:B7","C4:C7","F4","F8"), (S("1f"),"Metastatic burden (%)","B12:B15","C12:C15","F12","F16"), (S("1f"),"Metastatic foci (n)","B20:B23","C20:C23","F20","F24"),
 (S("1g"),"Lung weight (g)","B3:B12","C3:C12","F3","F7"), (S("1g"),"Metastatic burden (%)","B15:B24","C15:C24","F15","F19"), (S("1g"),"Metastatic foci (n)","B28:B37","C28:C37","F28","F32"),
 (S("1h"),"Serum creatine (uM), creatine diet","C4:C7","D4:D7","F4","F8"),
 (S("1i"),"Lung weight (g), creatine diet","B3:B6","C3:C6","F3","F7"), (S("1i"),"Metastatic burden (%), creatine diet","B11:B14","C11:C14","F11","F15"), (S("1i"),"Metastatic foci (n), creatine diet","B18:B21","C18:C21","F18","F22"),
 (S("1k"),"Lung weight (g)","B4:B13","C4:C13","G4","G8"), (S("1k"),"Metastatic burden (%)","B16:B25","C16:C25","G16","G20"), (S("1k"),"Metastatic foci (n)","B29:B38","C29:C38","G29","G33"),
 (S("2a"),"Slc6a8 mRNA after knock-down (tumour cells)","D7:F7","H7:J7","M4","M8"),
 (S("3a"),"WBC","B4:B8","C4:C8","F4","F8"), (S("3a"),"Lymphocytes","B12:B16","C12:C16","F12","F16"),
 (S("3a"),"Monocytes","B20:B24","C20:C24","F20","F24"), (S("3a"),"RBC","B28:B32","C28:C32","F28","F32"),
 (S("5a"),"Gatm mRNA, MKs","C6:E6","G6:I6","N10","N14"), (S("5a"),"Gamt mRNA, MKs","C9:E9","G9:I9","N24","N28"),
 (S("5c"),"MK creatine, CKB-EV vs CKB-OE","B5:B7","C5:C7","F5","F9"), (S("5c"),"MK phosphocreatine, CKB-EV vs CKB-OE","B13:B15","C13:C15","F13","F17"),
 (S("8a"),"BMI d0 vs d14 (volunteers; sheet uses unpaired test)","C4:C14","D4:D14","G5","G9"),
]
rows = []
for sh, lab, ra, rb, pc, tc in T:
    a, b = col(sh, ra), col(sh, rb)
    t, p = stats.ttest_ind(a, b); df = len(a) + len(b) - 2
    rp, rt = cell(sh, pc), cell(sh, tc)
    m = re.match(r"t=([\d.]+), df=(\d+)", str(rt))
    rtv, rdf = (float(m.group(1)), int(m.group(2))) if m else (np.nan, np.nan)
    match = bool(m) and abs(abs(t) - rtv) <= 0.02 * max(1, rtv) and rdf == df
    try: pm = stats.mannwhitneyu(a, b, alternative="two-sided").pvalue
    except Exception: pm = np.nan
    rows.append(dict(sheet=sh.replace("  ", " "), endpoint=lab, control_cells=ra, test_cells=rb, n_control=len(a), n_test=len(b),
                     mean_control=a.mean(), sd_control=a.std(ddof=1), mean_test=b.mean(), sd_test=b.std(ddof=1),
                     ratio_test_over_control=b.mean()/a.mean() if a.mean() else np.nan,
                     t_recomputed=abs(t), df=df, p_recomputed=p, p_reported_in_sheet=rp, t_reported=rtv,
                     reported_matches_recomputed=match, p_welch=stats.ttest_ind(a, b, equal_var=False).pvalue, p_mann_whitney=pm))
TT = pd.DataFrame(rows)

# ----------------------------------------------------------------------------------------------------------
# 2. Multi-group panels (one-way ANOVA + Tukey, as in the workbook) and factorial re-analysis
# ----------------------------------------------------------------------------------------------------------
def tukey(groups, names):
    res = stats.tukey_hsd(*groups); ci = res.confidence_interval(0.95); out = []
    for i in range(len(groups)):
        for j in range(i + 1, len(groups)):
            out.append((f"{names[i]} vs {names[j]}", groups[i].mean() - groups[j].mean(), ci.low[i, j], ci.high[i, j], res.pvalue[i, j]))
    return out

MG = [  # sheet, endpoint, ranges, names
 ("Fig. 1f","Lung weight (g)",["B4:B9","C4:C9","D4:D9","E4:E9"],["shScr-veh","shScr-cre","shSlc6a8-veh","shSlc6a8-cre"]),
 ("Fig. 1f","SUV-BW",["B13:B18","C13:C18","D13:D18","E13:E18"],["shScr-veh","shScr-cre","shSlc6a8-veh","shSlc6a8-cre"]),
 ("Fig. 1f","Metastatic burden (%)",["B22:B27","C22:C27","D22:D27","E22:E27"],["shScr-veh","shScr-cre","shSlc6a8-veh","shSlc6a8-cre"]),
 ("Fig. 1f","Metastatic foci (n)",["B31:B36","C31:C36","D31:D36","E31:E36"],["shScr-veh","shScr-cre","shSlc6a8-veh","shSlc6a8-cre"]),
 ("Fig. 3d","Aggregation, ADP",["B4:D4","E4:G4","H4:J4","K4:M4"],["WT-veh","WT-cre","cKO-veh","cKO-cre"]),
 ("Fig. 3d","Aggregation, collagen",["B5:D5","E5:G5","H5:J5","K5:M5"],["WT-veh","WT-cre","cKO-veh","cKO-cre"]),
 ("Fig. 3d","Aggregation, thrombin",["B6:D6","E6:G6","H6:J6","K6:M6"],["WT-veh","WT-cre","cKO-veh","cKO-cre"]),
 ("Fig. 3i","Lung weight (g)",["B3:B6","C3:C6","D3:D6","E3:E6"],["WT-veh","WT-cre","cKO-veh","cKO-cre"]),
 ("Fig. 3i","Metastatic burden (%)",["B10:B13","C10:C13","D10:D13","E10:E13"],["WT-veh","WT-cre","cKO-veh","cKO-cre"]),
 ("Fig. 3i","Metastatic foci (n)",["B17:B20","C17:C20","D17:D20","E17:E20"],["WT-veh","WT-cre","cKO-veh","cKO-cre"]),
 ("Fig. 6b","Metastatic burden (%)",["B4:B8","C4:C8","D4:D8","E4:E8"],["veh","cre","veh+STAT5i","cre+STAT5i"]),
 ("Fig. 6b","Metastatic foci (n)",["B13:B17","C13:C17","D13:D17","E13:E17"],["veh","cre","veh+STAT5i","cre+STAT5i"]),
 ("Fig. 6e","MK creatine (umol/g)",["C5:C7","D5:D7","E5:E7"],["WT-veh","WT-cre","Stat5b-cKO-cre"]),
 (S("2d"),"Metastatic burden (%)",["C5:C10","D5:D10","E5:E10"],["veh-donor PLT","cre-donor PLT","cre+aspirin-donor PLT"]),
 (S("2d"),"Metastatic foci (n)",["C14:C19","D14:D19","E14:E19"],["veh-donor PLT","cre-donor PLT","cre+aspirin-donor PLT"]),
 (S("4b"),"PLT (x10^9/L)",["C5:C7","D5:D7","E5:E7","F5:F7"],["WT-veh","WT-cre","cKO-veh","cKO-cre"]),
 (S("4c"),"alpha-granules (8 fields)",["C6:C13","D6:D13","E6:E13","F6:F13"],["WT-veh","WT-cre","cKO-veh","cKO-cre"]),
 (S("7a"),"PLT (x10^9/L)",["B4:B6","C4:C6","D4:D6","E4:E6"],["veh","cre","veh+STAT5i","cre+STAT5i"]),
 (S("7a"),"PCT (%)",["B11:B13","C11:C13","D11:D13","E11:E13"],["veh","cre","veh+STAT5i","cre+STAT5i"]),
 (S("7b"),"PLT (x10^9/L)",["B4:B6","C4:C6","D4:D6"],["WT-veh","WT-cre","Stat5b-cKO-cre"]),
 (S("7b"),"PCT (%)",["B10:B12","C10:C12","D10:D12"],["WT-veh","WT-cre","Stat5b-cKO-cre"]),
 ("Fig. 5e","p-FLAG/FLAG, vehicle",["N4:N6","O4:O6","P4:P6","Q4:Q6"],["WT","S127A","3A","S127D"]),
 ("Fig. 5e","p-FLAG/FLAG, creatine",["N17:N19","O17:O19","P17:P19","Q17:Q19"],["WT","S127A","3A","S127D"]),
 ("Fig. 5f","p-FLAG/FLAG, vehicle",["N4:N6","O4:O6","P4:P6","Q4:Q6"],["WT","S127A","3A","S127D"]),
 ("Fig. 5f","p-FLAG/FLAG, creatine",["N17:N19","O17:O19","P17:P19","Q17:Q19"],["WT","S127A","3A","S127D"]),
 ("Fig. 7b","Serum creatine (uM), volunteers",["B4:B14","C4:C14","D4:D14","E4:E14"],["d0","d3","d7","d14"]),
 ("Fig. 7e","GP6/b-ACTIN (immunoblot), volunteers",["B4:B7","C4:C7","D4:D7","E4:E7"],["d0","d3","d7","d14"]),
 ("Fig. 7e","P2RY12/b-ACTIN (immunoblot), volunteers",["B12:B15","C12:C15","D12:D15","E12:E15"],["d0","d3","d7","d14"]),
]
rows = []
for sh, ep, ranges, names in MG:
    g = [col(sh, r) for r in ranges]
    F, pF = stats.f_oneway(*g)
    for comp, md, lo, hi, padj in tukey(g, names):
        rows.append(dict(sheet=sh.replace("  ", " "), endpoint=ep, group_means="; ".join(f"{n}={x.mean():.4g} (n={len(x)})" for n, x in zip(names, g)),
                         anova_F=F, anova_p=pF, comparison=comp, mean_diff=md, ci95_low=lo, ci95_high=hi, tukey_p=padj))
MGT = pd.DataFrame(rows)

def fieller_ratio(a, b, va, vb, cov, df, alpha=0.05):
    """95% CI for R = a/b by Fieller's theorem; returns (lo, hi) or (nan, nan) if the denominator is not clearly non-zero."""
    t = stats.t.ppf(1-alpha/2, df); A = b*b - t*t*vb; B = -2*(a*b - t*t*cov); C = a*a - t*t*va; disc = B*B - 4*A*C
    if A <= 0 or disc < 0: return np.nan, np.nan
    return (-B-np.sqrt(disc))/(2*A), (-B+np.sqrt(disc))/(2*A)

def factorial(sheet, endpoint, ranges, perturbation, nboot=20000):
    """ranges = [control-veh, control-cre, perturbed-veh, perturbed-cre]"""
    g = [col(sheet, r) for r in ranges]
    d = pd.DataFrame([(p, c, v) for (p, c), vals in zip([(0,0),(0,1),(1,0),(1,1)], g) for v in vals], columns=["pert","cre","y"])
    a = sm.stats.anova_lm(ols("y ~ C(pert)*C(cre)", data=d).fit(), typ=2)
    dl = d.copy(); dl["y"] = np.log(dl.y)
    al = sm.stats.anova_lm(ols("y ~ C(pert)*C(cre)", data=dl).fit(), typ=2)
    ic, ip = g[1].mean() - g[0].mean(), g[3].mean() - g[2].mean()
    bs = []
    for _ in range(nboot):
        s = [RNG.choice(x, len(x), replace=True) for x in g]
        c_ = s[1].mean() - s[0].mean()
        if c_ != 0: bs.append(1 - (s[3].mean() - s[2].mean()) / c_)
    lo, hi = np.percentile(bs, [2.5, 97.5])
    n = [len(x) for x in g]; dfe = sum(n)-4; s2 = sum((len(x)-1)*x.var(ddof=1) for x in g)/dfe
    rlo, rhi = fieller_ratio(ip, ic, s2*(1/n[3]+1/n[2]), s2*(1/n[1]+1/n[0]), 0.0, dfe)
    return dict(sheet=sheet.replace("  ", " "), endpoint=endpoint, perturbation=perturbation, n_per_group=str([len(x) for x in g]),
                control_vehicle=g[0].mean(), control_creatine=g[1].mean(), perturbed_vehicle=g[2].mean(), perturbed_creatine=g[3].mean(),
                creatine_increment_control=ic, creatine_increment_perturbed=ip, pct_increment_blocked=100*(1-ip/ic),
                fieller_ci95_low=100*(1-rhi), fieller_ci95_high=100*(1-rlo),
                boot_ci95_low=100*lo, boot_ci95_high=100*hi, interaction_p=a.loc["C(pert):C(cre)","PR(>F)"],
                interaction_p_log_scale=al.loc["C(pert):C(cre)","PR(>F)"],
                p_creatine_in_control=stats.ttest_ind(g[0], g[1]).pvalue, p_creatine_in_perturbed=stats.ttest_ind(g[2], g[3]).pvalue,
                baseline_ratio_perturbed_over_control=g[2].mean()/g[0].mean(), p_baseline=stats.ttest_ind(g[0], g[2]).pvalue)
FA = [
 ("Fig. 3i","Lung weight (g)",["B3:B6","C3:C6","D3:D6","E3:E6"],"MK Slc6a8 deletion (Pf4-Cre;Slc6a8fl/fl)"),
 ("Fig. 3i","Metastatic burden (%)",["B10:B13","C10:C13","D10:D13","E10:E13"],"MK Slc6a8 deletion (Pf4-Cre;Slc6a8fl/fl)"),
 ("Fig. 3i","Metastatic foci (n)",["B17:B20","C17:C20","D17:D20","E17:E20"],"MK Slc6a8 deletion (Pf4-Cre;Slc6a8fl/fl)"),
 ("Fig. 3b","Serum creatine (uM)",["B4:F4","G4:K4","B5:F5","G5:K5"],"MK Slc6a8 deletion (Pf4-Cre;Slc6a8fl/fl)"),
 ("Fig. 3c","MK intracellular creatine",["B4:D4","E4:G4","B5:D5","E5:G5"],"MK Slc6a8 deletion (Pf4-Cre;Slc6a8fl/fl)"),
 ("Fig. 3d","Aggregation, ADP",["B4:D4","E4:G4","H4:J4","K4:M4"],"MK Slc6a8 deletion (Pf4-Cre;Slc6a8fl/fl)"),
 ("Fig. 3d","Aggregation, collagen",["B5:D5","E5:G5","H5:J5","K5:M5"],"MK Slc6a8 deletion (Pf4-Cre;Slc6a8fl/fl)"),
 ("Fig. 3d","Aggregation, thrombin",["B6:D6","E6:G6","H6:J6","K6:M6"],"MK Slc6a8 deletion (Pf4-Cre;Slc6a8fl/fl)"),
 (S("4c"),"alpha-granules (8 fields)",["C6:C13","D6:D13","E6:E13","F6:F13"],"MK Slc6a8 deletion (Pf4-Cre;Slc6a8fl/fl)"),
 (S("4b"),"PLT (x10^9/L)",["C5:C7","D5:D7","E5:E7","F5:F7"],"MK Slc6a8 deletion (Pf4-Cre;Slc6a8fl/fl)"),
 ("Fig. 6b","Metastatic burden (%)",["B4:B8","C4:C8","D4:D8","E4:E8"],"STAT5-IN-1 (systemic, STAT5A+STAT5B)"),
 ("Fig. 6b","Metastatic foci (n)",["B13:B17","C13:C17","D13:D17","E13:E17"],"STAT5-IN-1 (systemic, STAT5A+STAT5B)"),
 (S("7a"),"PLT (x10^9/L)",["B4:B6","C4:C6","D4:D6","E4:E6"],"STAT5-IN-1 (systemic, STAT5A+STAT5B)"),
 ("Fig. 1f","Lung weight (g)",["B4:B9","C4:C9","D4:D9","E4:E9"],"Tumour-cell Slc6a8 knock-down (melanoma sh-Slc6a8)"),
 ("Fig. 1f","SUV-BW",["B13:B18","C13:C18","D13:D18","E13:E18"],"Tumour-cell Slc6a8 knock-down (melanoma sh-Slc6a8)"),
 ("Fig. 1f","Metastatic burden (%)",["B22:B27","C22:C27","D22:D27","E22:E27"],"Tumour-cell Slc6a8 knock-down (melanoma sh-Slc6a8)"),
 ("Fig. 1f","Metastatic foci (n)",["B31:B36","C31:C36","D31:D36","E31:E36"],"Tumour-cell Slc6a8 knock-down (melanoma sh-Slc6a8)"),
]
FAT = pd.DataFrame([factorial(*x) for x in FA])

# three-arm designs (no perturbation-alone arm): % of the creatine increment reversed
rows = []
for ep, r0 in [("Metastatic burden (%)", 5), ("Metastatic foci (n)", 14)]:
    v, c, a = (col(S("2d"), f"{x}{r0}:{x}{r0+5}") for x in "CDE")
    bs = []
    for _ in range(20000):
        sv, sc, sa = (RNG.choice(x, len(x), replace=True) for x in (v, c, a))
        if sc.mean() != sv.mean(): bs.append((sc.mean() - sa.mean()) / (sc.mean() - sv.mean()))
    lo, hi = np.percentile(bs, [2.5, 97.5])
    dfe = len(v)+len(c)+len(a)-3; s2 = ((len(v)-1)*v.var(ddof=1)+(len(c)-1)*c.var(ddof=1)+(len(a)-1)*a.var(ddof=1))/dfe
    flo, fhi = fieller_ratio(c.mean()-a.mean(), c.mean()-v.mean(), s2*(1/len(c)+1/len(a)), s2*(1/len(c)+1/len(v)), s2/len(c), dfe)
    rows.append(dict(sheet="Supplementary Fig 2d", endpoint=ep, design="platelet transfer; donors: vehicle / creatine / creatine+aspirin (no aspirin-alone arm)",
                     vehicle_donor=v.mean(), creatine_donor=c.mean(), creatine_aspirin_donor=a.mean(), n="6/6/6",
                     pct_increment_reversed=100*(c.mean()-a.mean())/(c.mean()-v.mean()), fieller_ci95_low=100*flo, fieller_ci95_high=100*fhi, boot_ci95_low=100*lo, boot_ci95_high=100*hi,
                     p_cre_vs_veh=stats.ttest_ind(v, c).pvalue, p_cre_vs_cre_aspirin=stats.ttest_ind(c, a).pvalue,
                     sensitivity_excluding_values_shared_with_Fig6b=f"veh {v[:3].mean():.3g} (n=3) vs cre {c[:3].mean():.3g} (n=3): p={stats.ttest_ind(v[:3], c[:3]).pvalue:.3g}; cre (n=3) vs cre+aspirin (n=6): p={stats.ttest_ind(c[:3], a).pvalue:.3g}"))
for ep, r0 in [("Metastatic burden (%)", 12), ("Metastatic foci (n)", 19)]:
    v, c = col("Fig. 7g", f"B{r0}:B{r0+4}"), col("Fig. 7g", f"C{r0}:C{r0+4}")
    rows.append(dict(sheet="Fig. 7g", endpoint=ep, design="platelet transfer; donors: volunteers at day 0 / day 7 of creatine",
                     vehicle_donor=v.mean(), creatine_donor=c.mean(), n="5/5", p_cre_vs_veh=stats.ttest_ind(v, c).pvalue))
TRANSFER = pd.DataFrame(rows)

# ----------------------------------------------------------------------------------------------------------
# 3. The creatine phenotype across independent experiments (effect sizes, pooled ratio)
# ----------------------------------------------------------------------------------------------------------
E = [("Fig. 1a/b","Fig. 1a","Lung weight (g)","B3:B8","C3:C8"), ("Fig. 1a/b","Fig. 1b","Metastatic burden (%)","B3:B8","C3:C8"), ("Fig. 1a/b","Fig. 1b","Metastatic foci (n)","B12:B17","C12:C17"),
     ("Fig. 1f (sh-scrambled arm)","Fig. 1f","Lung weight (g)","B4:B9","C4:C9"), ("Fig. 1f (sh-scrambled arm)","Fig. 1f","Metastatic burden (%)","B22:B27","C22:C27"), ("Fig. 1f (sh-scrambled arm)","Fig. 1f","Metastatic foci (n)","B31:B36","C31:C36"),
     ("Fig. 1f (sh-Slc6a8 arm)","Fig. 1f","Lung weight (g)","D4:D9","E4:E9"), ("Fig. 1f (sh-Slc6a8 arm)","Fig. 1f","Metastatic burden (%)","D22:D27","E22:E27"), ("Fig. 1f (sh-Slc6a8 arm)","Fig. 1f","Metastatic foci (n)","D31:D36","E31:E36"),
     ("Fig. 1j/k","Fig. 1j","Lung weight (g)","B4:B9","C4:C9"), ("Fig. 1j/k","Fig. 1k","Metastatic burden (%)","B4:B9","C4:C9"), ("Fig. 1j/k","Fig. 1k","Metastatic foci (n)","B12:B17","C12:C17"),
     ("Supp. Fig. 1e",S("1e"),"Lung weight (g)","B4:B9","C4:C9"), ("Supp. Fig. 1e",S("1e"),"Metastatic burden (%)","B13:B18","C13:C18"), ("Supp. Fig. 1e",S("1e"),"Metastatic foci (n)","B22:B27","C22:C27"),
     ("Supp. Fig. 1f",S("1f"),"Lung weight (g)","B4:B7","C4:C7"), ("Supp. Fig. 1f",S("1f"),"Metastatic burden (%)","B12:B15","C12:C15"), ("Supp. Fig. 1f",S("1f"),"Metastatic foci (n)","B20:B23","C20:C23"),
     ("Supp. Fig. 1g",S("1g"),"Lung weight (g)","B3:B12","C3:C12"), ("Supp. Fig. 1g",S("1g"),"Metastatic burden (%)","B15:B24","C15:C24"), ("Supp. Fig. 1g",S("1g"),"Metastatic foci (n)","B28:B37","C28:C37"),
     ("Supp. Fig. 1i (creatine diet)",S("1i"),"Lung weight (g)","B3:B6","C3:C6"), ("Supp. Fig. 1i (creatine diet)",S("1i"),"Metastatic burden (%)","B11:B14","C11:C14"), ("Supp. Fig. 1i (creatine diet)",S("1i"),"Metastatic foci (n)","B18:B21","C18:C21"),
     ("Supp. Fig. 1k",S("1k"),"Lung weight (g)","B4:B13","C4:C13"), ("Supp. Fig. 1k",S("1k"),"Metastatic burden (%)","B16:B25","C16:C25"), ("Supp. Fig. 1k",S("1k"),"Metastatic foci (n)","B29:B38","C29:C38"),
     ("Fig. 3i (Pf4-Cre;Slc6a8+/+ arm)","Fig. 3i","Lung weight (g)","B3:B6","C3:C6"), ("Fig. 3i (Pf4-Cre;Slc6a8+/+ arm)","Fig. 3i","Metastatic burden (%)","B10:B13","C10:C13"), ("Fig. 3i (Pf4-Cre;Slc6a8+/+ arm)","Fig. 3i","Metastatic foci (n)","B17:B20","C17:C20"),
     ("Fig. 6b (no-inhibitor arm)","Fig. 6b","Metastatic burden (%)","B4:B8","C4:C8"), ("Fig. 6b (no-inhibitor arm)","Fig. 6b","Metastatic foci (n)","B13:B17","C13:C17")]
rows = []
for exp, sh, ep, ra, rb in E:
    a, b = col(sh, ra), col(sh, rb); la, lb = np.log(a), np.log(b); n1, n2 = len(a), len(b)
    sp = np.sqrt(((n1-1)*la.var(ddof=1) + (n2-1)*lb.var(ddof=1)) / (n1+n2-2)); se = sp*np.sqrt(1/n1+1/n2); tc = stats.t.ppf(0.975, n1+n2-2)
    d = lb.mean() - la.mean()
    rows.append(dict(experiment=exp, endpoint=ep, n_vehicle=n1, n_creatine=n2, mean_vehicle=a.mean(), mean_creatine=b.mean(), ratio_of_means=b.mean()/a.mean(),
                     geo_mean_ratio=np.exp(d), gmr_ci95_low=np.exp(d-tc*se), gmr_ci95_high=np.exp(d+tc*se), log_se=se, pooled_log_sd=sp,
                     p_t=stats.ttest_ind(a, b).pvalue, p_mann_whitney=stats.mannwhitneyu(a, b).pvalue))
PH = pd.DataFrame(rows)
pooled = []
for ep, s in PH.groupby("endpoint"):
    y, se = np.log(s.geo_mean_ratio.values), s.log_se.values; w = 1/se**2
    yf = (w*y).sum()/w.sum(); Q = (w*(y-yf)**2).sum(); k = len(y)
    tau2 = max(0, (Q-(k-1)) / (w.sum() - (w**2).sum()/w.sum())); wr = 1/(se**2+tau2); yr = (wr*y).sum()/wr.sum(); ser = np.sqrt(1/wr.sum())
    pooled.append(dict(endpoint=ep, k_experiments=k, pooled_ratio_random_effects=np.exp(yr), ci95_low=np.exp(yr-1.96*ser), ci95_high=np.exp(yr+1.96*ser),
                       min_ratio_of_means=s.ratio_of_means.min(), max_ratio_of_means=s.ratio_of_means.max(), I2_pct=100*max(0, (Q-(k-1))/Q) if Q > 0 else 0,
                       median_within_group_log_sd=np.median(s.pooled_log_sd), max_within_group_log_sd=s.pooled_log_sd.max()))
PHP = pd.DataFrame(pooled)

# survival
def surv(sheet, r0, r1):
    ws = WB[sheet]; v, c = [], []
    for r in range(r0, r1+1):
        t = ws[f"A{r}"].value
        if t is None: continue
        if ws[f"B{r}"].value is not None: v.append(t)
        if ws[f"C{r}"].value is not None: c.append(t)
    return np.array(v, float), np.array(c, float)
def logrank(t1, t2):
    times = np.unique(np.concatenate([t1, t2])); O1 = E1 = V = 0
    for t in times:
        n1, n2 = (t1 >= t).sum(), (t2 >= t).sum(); n = n1+n2; d1, d2 = (t1 == t).sum(), (t2 == t).sum(); d = d1+d2
        O1 += d1; E1 += d*n1/n
        if n > 1: V += d*(n1/n)*(n2/n)*(n-d)/(n-1)
    chi = (O1-E1)**2/V; return chi, stats.chi2.sf(chi, 1)
rows = []
for sh, r0, r1, rc, rp in [("Fig. 1c", 4, 23, "F6", "F8"), ("Fig. 1l", 4, 41, "F5", "F7")]:
    v, c = surv(sh, r0, r1); chi, p = logrank(v, c)
    t = np.concatenate([v, c]); g = np.array([0]*len(v) + [1]*len(c))
    m = sm.PHReg(t, g[:, None], status=np.ones(len(t)), ties="efron").fit()
    rows.append(dict(sheet=sh, n_vehicle=len(v), n_creatine=len(c), median_survival_vehicle_d=np.median(v), median_survival_creatine_d=np.median(c),
                     logrank_chi2=chi, logrank_p=p, chi2_reported=cell(sh, rc), p_reported=cell(sh, rp),
                     cox_HR_creatine=np.exp(m.params[0]), HR_ci95_low=np.exp(m.conf_int()[0][0]), HR_ci95_high=np.exp(m.conf_int()[0][1]), censoring="none (all animals reached the event)"))
SURV = pd.DataFrame(rows)

# ----------------------------------------------------------------------------------------------------------
# 4. Megakaryocyte gene programme (qPCR sheets): verify arithmetic, summarise as an 11-gene composite
# ----------------------------------------------------------------------------------------------------------
def parse_qpcr(sheet):
    ws = WB[sheet]; out = collections.OrderedDict()
    for row in ws.iter_rows(min_col=1, max_col=1):
        c = row[0]
        if isinstance(c.value, str) and c.value.strip() and not c.value.startswith(("Graphs", "Relative")):
            r = c.row; labels = [cc.column for cc in ws[r] if isinstance(cc.value, str) and cc.value.startswith("ΔCT")]
            if not labels: continue
            first = min(labels)
            rec = dict(ctrl=[ws.cell(row=r+3, column=first-3+i).value for i in range(3)], d1=[ws.cell(row=r, column=first+1+i).value for i in range(3)], blocks=[])
            for lc in sorted(labels):
                rec["blocks"].append(dict(d2=[ws.cell(row=r+1, column=lc+1+i).value for i in range(3)], fc=[ws.cell(row=r+3, column=lc+1+i).value for i in range(3)]))
            out[c.value.strip()] = rec
    return out
PANELS = collections.OrderedDict([
 ("Fig. 2f", ("MKs isolated from dosed mice", ["Vehicle", "Creatine"])),
 ("Fig. 3f", ("MKs from Pf4-Cre;Slc6a8 mice", ["Slc6a8+/+ vehicle", "Slc6a8+/+ creatine", "Slc6a8 cKO vehicle", "Slc6a8 cKO creatine"])),
 (S("4e"),   ("Slc6a8-cKO MKs, in vitro", ["Control", "Creatine", "Creatine@liposome"])),
 ("Fig. 4h", ("MKs, in vitro", ["Control", "Creatine", "Phosphocreatine"])),
 ("Fig. 4j", ("MKs, in vitro", ["Control + si-scr", "Control + si-Ckb", "Creatine + si-scr", "Creatine + si-Ckb"])),
 ("Fig. 4l", ("MKs, in vitro", ["CKB empty vector", "CKB over-expression"])),
 ("Fig.6a",  ("MKs, in vitro", ["Vehicle", "Creatine", "Vehicle + STAT5-IN-1", "Creatine + STAT5-IN-1"])),
 ("Fig. 6g", ("MKs from mice", ["WT vehicle", "WT creatine", "Stat5b cKO creatine"])),
])
CORE = ["Itga2b","P2ry12","Gp6","Gpiba","F2r","Adra2a","Fcgr2a","Runx1","Rab4a","Rab27b","Pitpnb"]
qrows, qgene, arith = [], [], []
COMP = {}
for sh, (desc, conds) in PANELS.items():
    q = parse_qpcr(sh); L = {c: [] for c in conds}
    for gname in CORE:
        rec = q[gname]; d1 = np.array(rec["d1"], float)
        ctrl_calc = 2**d1/(2**d1).mean()
        arith.append(dict(sheet=sh.replace("  "," "), gene=gname, block="control normalisation", max_rel_dev=np.max(np.abs(ctrl_calc/np.array(rec["ctrl"], float)-1))))
        L[conds[0]].append(np.log2(np.array(rec["ctrl"], float)))
        for cnd, b in zip(conds[1:], rec["blocks"]):
            fc = np.array(b["fc"], float); calc = 2**(np.array(b["d2"], float)-d1)
            arith.append(dict(sheet=sh.replace("  "," "), gene=gname, block=cnd, max_rel_dev=np.max(np.abs(calc/fc-1))))
            L[cnd].append(np.log2(fc))
    comp = {c: np.array(L[c]).mean(0) for c in conds}; COMP[sh] = comp
    for c in conds:
        M = np.array(L[c]); gm = 2**M.mean(1)
        rec = dict(sheet=sh.replace("  "," "), material=desc, condition=c, n_replicates=3, median_gene_fold=np.median(gm), min_gene_fold=gm.min(), min_gene=CORE[int(gm.argmin())],
                   max_gene_fold=gm.max(), max_gene=CORE[int(gm.argmax())], composite_fold=2**comp[c].mean(), composite_replicates=", ".join(f"{x:.2f}" for x in 2**comp[c]))
        if c != conds[0]:
            nsig = sum(stats.ttest_ind(2**np.array(L[conds[0]][i]), 2**M[i]).pvalue < 0.05 and M[i].mean() > 0 for i in range(len(CORE)))
            rec.update(genes_up_p_lt_0_05=f"{nsig}/11", composite_p_vs_control=stats.ttest_ind(comp[conds[0]], comp[c]).pvalue)
        qrows.append(rec)
        for i, gname in enumerate(CORE): qgene.append(dict(sheet=sh.replace("  "," "), condition=c, gene=gname, rep1=2**M[i][0], rep2=2**M[i][1], rep3=2**M[i][2], geo_mean=2**M[i].mean()))
QP, QG, AR = pd.DataFrame(qrows), pd.DataFrame(qgene), pd.DataFrame(arith)
contrasts = [("Fig. 3f","Slc6a8+/+ creatine","Slc6a8 cKO creatine"), ("Fig. 3f","Slc6a8 cKO vehicle","Slc6a8 cKO creatine"),
             (S("4e"),"Creatine","Creatine@liposome"), ("Fig. 4j","Creatine + si-scr","Creatine + si-Ckb"), ("Fig. 4j","Control + si-Ckb","Creatine + si-Ckb"),
             ("Fig.6a","Creatine","Creatine + STAT5-IN-1"), ("Fig.6a","Vehicle","Vehicle + STAT5-IN-1"), ("Fig.6a","Vehicle + STAT5-IN-1","Creatine + STAT5-IN-1"),
             ("Fig. 6g","WT creatine","Stat5b cKO creatine"), ("Fig. 6g","WT vehicle","Stat5b cKO creatine")]
QC = pd.DataFrame([dict(sheet=sh.replace("  "," "), contrast=f"{a} vs {b}", composite_fold_a=2**COMP[sh][a].mean(), composite_fold_b=2**COMP[sh][b].mean(),
                        p_composite=stats.ttest_ind(COMP[sh][a], COMP[sh][b]).pvalue) for sh, a, b in contrasts])
# residual induction per gene in Stat5b cKO
g6 = QG[QG.sheet == "Fig. 6g"].pivot(index="gene", columns="condition", values="geo_mean").loc[CORE]
g6["residual_pct_of_WT_log_induction"] = 100*np.log2(g6["Stat5b cKO creatine"])/np.log2(g6["WT creatine"])
G6 = g6.reset_index()

# megakaryopoiesis genes (Supp 3c) – simple per-gene test
q3 = parse_qpcr(S("3c"))
S3C = pd.DataFrame([dict(gene=g, fold_creatine=np.mean(r["blocks"][0]["fc"]), p=stats.ttest_ind(np.array(r["ctrl"], float), np.array(r["blocks"][0]["fc"], float)).pvalue) for g, r in q3.items()])

# ----------------------------------------------------------------------------------------------------------
# 5. Human cohort
# ----------------------------------------------------------------------------------------------------------
ws = WB["Fig. 7c"]
BL = collections.OrderedDict([(("Collagen","max aggregation"),4),(("Collagen","mean aggregation"),18),(("Collagen","adhesion"),32),
      (("Epinephrine","max aggregation"),46),(("Epinephrine","mean aggregation"),60),(("Epinephrine","adhesion"),74),
      (("Arachidonic acid","max aggregation"),88),(("Arachidonic acid","mean aggregation"),102),(("Arachidonic acid","adhesion"),116),
      (("ADP","max aggregation"),130),(("ADP","mean aggregation"),144),(("ADP","adhesion"),157)])
REP = {4:(4,5,6),18:(18,19,20),32:(32,33,34),46:(47,48,49),60:(61,62,63),74:(75,76,77),88:(88,89,90),102:(103,104,105),116:(117,118,119),130:(131,132,133),144:(145,146,147),157:(159,160,161)}
HUM = {}; rows = []
for k, r0 in BL.items():
    arr = np.array([[ws.cell(row=r, column=c).value for c in (2,3,4,5)] for r in range(r0, r0+11)], float); HUM[k] = arr
    assert np.allclose(arr[:, 0], 1)
    for j, day in enumerate((3, 7, 14)):
        fc = arr[:, j+1]; lfc = np.log2(np.where(fc <= 0, np.nan, fc)); ok = ~np.isnan(lfc)
        rows.append(dict(agonist=k[0], metric=k[1], day=day, first_cell=f"B{r0}", n=11, arithmetic_mean_fold=fc.mean(), median_fold=np.median(fc), geo_mean_fold=2**np.nanmean(lfc),
                         n_volunteers_up=int((fc > 1).sum()), max_fold=fc.max(), sheet_dunnett_p_unpaired=ws[f"L{REP[r0][j]}"].value,
                         p_one_sample_t_log2=stats.ttest_1samp(lfc[ok], 0).pvalue, p_wilcoxon_signed_rank=stats.wilcoxon(fc-1).pvalue))
HA = pd.DataFrame(rows)
# re-derive the sheet's own test (ordinary one-way ANOVA + Dunnett vs day 0) to confirm the embedded values
dn = []
for k, r0 in BL.items():
    arr = HUM[k]; res = stats.dunnett(arr[:, 1], arr[:, 2], arr[:, 3], control=arr[:, 0])
    dn += list(res.pvalue)
HA["dunnett_p_recomputed"] = dn
HA["wilcoxon_BH_36_tests"] = multipletests(HA.p_wilcoxon_signed_rank, method="fdr_bh")[1]
HA["wilcoxon_Holm_36_tests"] = multipletests(HA.p_wilcoxon_signed_rank, method="holm")[1]

rows = []
cr = np.array([[cell("Fig. 7b", f"{c}{r}") for c in "BCDE"] for r in range(4, 15)], float)
for j, day in enumerate((3, 7, 14)):
    rows.append(dict(readout="Serum creatine (uM), n=11", day=day, mean_d0=cr[:,0].mean(), mean_day=cr[:,j+1].mean(), ratio_of_means=cr[:,j+1].mean()/cr[:,0].mean(),
                     geo_mean_individual_ratio=2**np.log2(cr[:,j+1]/cr[:,0]).mean(), n_up=f"{int((cr[:,j+1]>cr[:,0]).sum())}/11", p_paired_t=stats.ttest_rel(cr[:,j+1], cr[:,0]).pvalue))
for lab, r0 in [("GP6/b-ACTIN immunoblot, platelets, n=4", 4), ("P2RY12/b-ACTIN immunoblot, platelets, n=4", 12)]:
    arr = np.array([[cell("Fig. 7e", f"{c}{r}") for c in "BCDE"] for r in range(r0, r0+4)], float)
    for j, day in enumerate((3, 7, 14)):
        ratio = arr[:, j+1]/arr[:, 0]
        rows.append(dict(readout=lab, day=day, mean_d0=arr[:,0].mean(), mean_day=arr[:,j+1].mean(), ratio_of_means=arr[:,j+1].mean()/arr[:,0].mean(),
                         geo_mean_individual_ratio=2**np.log2(ratio).mean(), n_up=f"{int((ratio>1).sum())}/4", p_paired_t=stats.ttest_rel(arr[:,j+1], arr[:,0]).pvalue))
ws8 = WB[S("8b")]
for lab, r0 in [("Platelet count (x10^9/L), n=11", 4), ("Plateletcrit (%), n=11", 19), ("MPV (fl), n=11", 33), ("PDW (fl), n=11", 48)]:
    arr = np.array([[ws8[f"{c}{r}"].value for c in "BCDE"] for r in range(r0, r0+11)], float)
    for j, day in enumerate((3, 7, 14)):
        rows.append(dict(readout=lab, day=day, mean_d0=arr[:,0].mean(), mean_day=arr[:,j+1].mean(), ratio_of_means=arr[:,j+1].mean()/arr[:,0].mean(),
                         n_up=f"{int((arr[:,j+1]>arr[:,0]).sum())}/11", p_paired_t=stats.ttest_rel(arr[:,j+1], arr[:,0]).pvalue))
DUN8 = []
for lab, r0, rr in [("Platelet count", 4, (4, 5, 6)), ("Plateletcrit", 19, (19, 20, 21)), ("MPV", 33, (33, 34, 35)), ("PDW", 48, (48, 49, 50))]:
    arr = np.array([[ws8[f"{c}{r}"].value for c in "BCDE"] for r in range(r0, r0+11)], float)
    res = stats.dunnett(arr[:, 1], arr[:, 2], arr[:, 3], control=arr[:, 0])
    for j, day in enumerate((3, 7, 14)):
        DUN8.append(dict(sheet="Supplementary Fig 8b", readout=lab, comparison=f"day 0 vs day {day}", dunnett_p_recomputed=res.pvalue[j], dunnett_p_in_sheet=ws8[f"L{rr[j]}"].value))
DUN8 = pd.DataFrame(DUN8)
bmi0, bmi14 = col(S("8a"), "C4:C14"), col(S("8a"), "D4:D14")
rows.append(dict(readout="BMI (kg/m2), n=11", day=14, mean_d0=bmi0.mean(), mean_day=bmi14.mean(), ratio_of_means=bmi14.mean()/bmi0.mean(), n_up=f"{int((bmi14>bmi0).sum())}/11", p_paired_t=stats.ttest_rel(bmi14, bmi0).pvalue))
HO = pd.DataFrame(rows)

# human CD41+ cell transcripts (Fig 7d): recompute fold change from the ΔCT triplicates
ws7 = WB["Fig. 7d"]; rows = []
genes = [(c.value.strip(), c.row, c.column) for row in ws7.iter_rows() for c in row
         if isinstance(c.value, str) and c.column in (1, 8) and c.value.strip() and not c.value.startswith(("ΔCT", "After", "Graphs", "Note"))]
for gname, r, cidx in genes:
    lc = cidx+1 if cidx == 1 else cidx; c0 = lc+1
    dct = {day: np.array([[ws7.cell(row=r+1+3*k+i, column=c0+v).value for v in range(4)] for i in range(3)], float) for k, day in enumerate(("0d","3d","7d","14d"))}
    for k, day in enumerate(("3d","7d","14d")):
        rep = np.array([ws7.cell(row=r+14+k, column=c0+v).value for v in range(4)], float)
        calc = (2**dct[day]).mean(0)/(2**dct["0d"]).mean(0)          # the workbook's own method (verified on 9 of 11 genes)
        ddct = dct[day].mean(0)-dct["0d"].mean(0)
        rows.append(dict(gene=gname.replace("ADAR2A","ADRA2A (sheet label 'ADAR2A')"), day=day, **{f"sheet_V{i+1}": rep[i] for i in range(4)}, **{f"recalc_V{i+1}": calc[i] for i in range(4)},
                         max_rel_mismatch=np.max(np.abs(rep/calc-1)), geo_mean_fold_sheet=2**np.log2(rep).mean(), n_up_sheet=f"{int((rep>1).sum())}/4",
                         p_one_sample_t_log2_sheet=stats.ttest_1samp(np.log2(rep), 0).pvalue,
                         geo_mean_fold_from_mean_dCt=2**ddct.mean(), n_up_from_mean_dCt=f"{int((ddct>0).sum())}/4", p_paired_on_ddCt=stats.ttest_1samp(ddct, 0).pvalue))
H7D = pd.DataFrame(rows)

# ChIP-qPCR (two-way ANOVA, Sidak per region as in the sheet) and STAT5B phospho-mutants
def chip(sheet, target, rows_, vc, cc, repcol):
    wsx = WB[sheet]; d = []
    for r, lab in rows_.items():
        for c in vc: d.append((lab, "veh", wsx[f"{c}{r}"].value))
        for c in cc: d.append((lab, "cre", wsx[f"{c}{r}"].value))
    d = pd.DataFrame(d, columns=["region", "trt", "y"]); m = ols("y ~ C(region)*C(trt)", data=d).fit(); out = []
    for (r, lab), rr in zip(rows_.items(), repcol[1]):
        a, b = d[(d.region == lab) & (d.trt == "veh")].y.values, d[(d.region == lab) & (d.trt == "cre")].y.values
        t = (a.mean()-b.mean())/np.sqrt(m.mse_resid*(1/len(a)+1/len(b))); pr = 2*stats.t.sf(abs(t), m.df_resid)
        out.append(dict(sheet=sheet.replace("  ", " "), target=target, region=lab, pct_input_vehicle=a.mean(), pct_input_creatine=b.mean(), fold=b.mean()/a.mean(),
                        sidak_p_recomputed=1-(1-pr)**len(rows_), sidak_p_in_sheet=wsx[f"{repcol[0]}{rr}"].value))
    return out
CH = pd.DataFrame(chip("Fig. 5j", "P2ry12", {5:"exon", 6:"-2 kb", 7:"-1 kb", 8:"-0.2 kb"}, "BCD", "EFG", ("N", (7, 8, 9, 10)))
                  + chip("Fig. 5j", "Gp6", {15:"exon", 16:"-2 kb", 17:"-1 kb", 18:"-0.2 kb"}, "BCD", "EFG", ("N", (17, 18, 19, 20)))
                  + chip(S("6i"), "Rab4a", {7:"exon", 8:"-2 kb", 9:"-1 kb", 10:"-0.2 kb"}, "CDE", "FGH", ("O", (10, 11, 12, 13))))
rows = []
for sh in ("Fig. 5e", "Fig. 5f"):
    veh = {k: col(sh, f"{c}4:{c}6") for k, c in zip(["WT", "S127A", "3A", "S127D"], "NOPQ")}
    cre = {k: col(sh, f"{c}17:{c}19") for k, c in zip(["WT", "S127A", "3A", "S127D"], "NOPQ")}
    d = pd.DataFrame([(k, t, v) for k in ("WT", "S127A") for t, g in (("veh", veh), ("cre", cre)) for v in g[k]], columns=["mut", "trt", "y"])
    pint = sm.stats.anova_lm(ols("y ~ C(mut)*C(trt)", data=d).fit(), typ=2).loc["C(mut):C(trt)", "PR(>F)"]
    for k in veh:
        rows.append(dict(sheet=sh, construct=k, p_FLAG_over_FLAG_vehicle=veh[k].mean(), p_FLAG_over_FLAG_creatine=cre[k].mean(), ratio_creatine_over_vehicle=cre[k].mean()/veh[k].mean(),
                         p_unpaired_t=stats.ttest_ind(veh[k], cre[k]).pvalue, interaction_p_WT_vs_S127A_x_creatine=pint if k in ("WT", "S127A") else np.nan))
MUT = pd.DataFrame(rows)

# ----------------------------------------------------------------------------------------------------------
# 6. Phosphoproteomics
# ----------------------------------------------------------------------------------------------------------
ph = pd.read_excel(PHOS, sheet_name=0); ph.columns = ["gene", "p", "q", "log2fc"]
ph["fold"] = 2**ph.log2fc; ph["single_sample_call"] = np.isclose(ph.p, 0.422649730810374, atol=1e-9)   # t=1, df=2: signal in one replicate only
ph["rank_p"] = ph.p.rank(method="min").astype(int)
nd = ph[~ph.single_sample_call]
up = ph[(ph.p < 0.05) & (ph.fold >= 1.2)]; dn = ph[(ph.p < 0.05) & (ph.fold <= 0.83)]
st = ph[ph.gene == "Stat5b"].sort_values("p").iloc[0]
PS = pd.DataFrame([
 ("Phosphopeptide rows", len(ph)), ("Unique gene names", ph.gene.nunique()), ("Rows with p = 0.4226 exactly (t = 1, df = 2: signal in a single replicate)", int(ph.single_sample_call.sum())),
 ("Rows with p < 0.05", int((ph.p < 0.05).sum())), ("... as % of all rows (5% expected under the null)", 100*(ph.p < 0.05).mean()),
 ("... as % of rows excluding single-replicate calls", 100*(nd.p < 0.05).mean()),
 ("Rows meeting the study's screening rule: p < 0.05 and fold >= 1.2 (up)", len(up)), ("Rows meeting the study's screening rule: p < 0.05 and fold <= 0.83 (down)", len(dn)),
 ("Minimum Q-VALUE in the table", ph.q.min()), ("Rows with Q < 0.05", int((ph.q < 0.05).sum())), ("Rows with Q < 0.25", int((ph.q < 0.25).sum())),
 ("Minimum Benjamini-Hochberg adjusted p (recomputed, all rows)", multipletests(ph.p, method="fdr_bh")[1].min()),
 ("Stat5b top phosphopeptide: p", st.p), ("Stat5b top phosphopeptide: Q", st.q), ("Stat5b top phosphopeptide: log2 fold change", st.log2fc),
 ("Stat5b top phosphopeptide: rank by p among all rows", int(st.rank_p)), ("Stat5b top phosphopeptide: rank by p among increased rows", int(((ph.p < st.p) & (ph.log2fc > 0)).sum()+1)),
 ("Second Stat5b phosphopeptide: p / log2FC", f"{ph[ph.gene=='Stat5b'].sort_values('p').iloc[1].p:.3f} / {ph[ph.gene=='Stat5b'].sort_values('p').iloc[1].log2fc:.2f}"),
 ("Stat5a phosphopeptide: p / log2FC", f"{ph[ph.gene=='Stat5a'].iloc[0].p:.3f} / {ph[ph.gene=='Stat5a'].iloc[0].log2fc:.2f}"),
 ("Jak2 phosphopeptide: p / log2FC", f"{ph[ph.gene=='Jak2'].iloc[0].p:.3f} / {ph[ph.gene=='Jak2'].iloc[0].log2fc:.2f}"),
 ("Rows with p <= Stat5b p: observed vs expected under a global null (excluding single-replicate calls)", f"{int((nd.p <= st.p).sum())} vs {len(nd)*st.p:.1f}"),
 ("Site localisation column present in the table", "no (gene, P, Q, log fold change only)"),
], columns=["item", "value"])
PTOP = ph.sort_values("p").head(40)[["gene", "p", "q", "log2fc", "fold", "rank_p"]]

# ----------------------------------------------------------------------------------------------------------
# 7. Data-integrity scans
# ----------------------------------------------------------------------------------------------------------
# 7a. measured values (>= 5 significant digits) that occur in more than one sheet.  qPCR/ChIP-qPCR sheets are
#     excluded because the instrument rounds CT to 2 dp, so derived values repeat by construction.
idx = collections.defaultdict(list)
QPCR_SHEETS = set(PANELS) | {"Fig. 7d", "Fig. 4e", "Fig. 5j", S("2a"), S("3c"), S("5a"), S("6i"), S("8c")}
for w in WB.worksheets:
    if w.title in QPCR_SHEETS: continue
    for row in w.iter_rows():
        for c in row:
            v = c.value
            if isinstance(v, float) and not v.is_integer() and "e" not in repr(v) and len(repr(v).replace("-", "").replace(".", "").lstrip("0")) >= 5:
                idx[v].append((w.title.replace("  ", " "), c.coordinate))
DUP = pd.DataFrame([dict(kind="identical measured value in two sheets", value=str(v), locations="; ".join(f"{s_}!{c}" for s_, c in locs))
                    for v, locs in idx.items() if len({s_ for s_, _ in locs}) > 1])
# 7b. ordered runs of three consecutive values (integers included) shared between different sheets
runs = collections.defaultdict(list)
for w in WB.worksheets:
    if w.title in QPCR_SHEETS: continue
    for cc in w.iter_cols():
        vals = [(c.row, c.value) for c in cc if isinstance(c.value, (int, float)) and not isinstance(c.value, bool)]
        for i in range(len(vals)-2):
            if vals[i+1][0] == vals[i][0]+1 and vals[i+2][0] == vals[i][0]+2:
                key = (vals[i][1], vals[i+1][1], vals[i+2][1])
                if len(set(key)) == 3 and min(abs(k) for k in key) > 10: runs[key].append((w.title.replace("  ", " "), f"{cc[0].column_letter}{vals[i][0]}:{cc[0].column_letter}{vals[i][0]+2}"))
DUP = pd.concat([DUP, pd.DataFrame([dict(kind="identical ordered run of three values in two sheets", value=str(k), locations="; ".join(f"{a}!{b}" for a, b in v))
                                     for k, v in runs.items() if len({a for a, _ in v}) > 1])], ignore_index=True)
# 7c. triplets in which one value is the exact mean of the other two
def exact_mid(v):
    v = sorted(v); return v[0] != v[2] and abs((v[0]+v[2])/2 - v[1]) < 1e-9
trip = []
for lab, sh, rngs in [("Fig. 2b aggregation (6 groups)", "Fig. 2b", ["B4:D4","E4:G4","B5:D5","E5:G5","B6:D6","E6:G6"]),
                      ("Fig. 3d aggregation (12 groups)", "Fig. 3d", [f"{a}{r}:{b}{r}" for r in (4,5,6) for a, b in (("B","D"),("E","G"),("H","J"),("K","M"))]),
                      ("Other n=3 measured groups (Fig. 2a, 3c, 4a, 4c, 4d, 4f, 6e, Supp. 4b, 5c, 7a, 7b; 49 groups)", None, None)]:
    if sh:
        g = [col(sh, r) for r in rngs]
        trip.append(dict(panel=lab, groups=len(g), groups_where_one_value_is_exact_mean_of_other_two=sum(exact_mid(x) for x in g),
                         groups_with_two_identical_values=sum(len(set(x)) == 2 for x in g), values="; ".join(str([int(v) for v in x]) for x in g)))
others = [("Fig. 2a", ["B4:B6","C4:C6","B12:B14","C12:C14","B19:B21","C19:C21","B27:B29","C27:C29"]), ("Fig. 3c", ["B4:D4","E4:G4","B5:D5","E5:G5"]),
          ("Fig. 4a", ["B4:B6","C4:C6","D4:D6","E4:E6"]), ("Fig. 4c", ["B4:B6","C4:C6","D4:D6","E4:E6"]), ("Fig. 4d", ["C4:C6","D4:D6"]), ("Fig. 4f", ["B4:B6","C4:C6"]),
          ("Fig. 6e", ["C5:C7","D5:D7","E5:E7"]), (S("4b"), ["C5:C7","D5:D7","E5:E7","F5:F7"]), (S("5c"), ["B5:B7","C5:C7","B13:B15","C13:C15"]),
          (S("7a"), ["B4:B6","C4:C6","D4:D6","E4:E6","B11:B13","C11:C13","D11:D13","E11:E13"]), (S("7b"), ["B4:B6","C4:C6","D4:D6","B10:B12","C10:C12","D10:D12"])]
g = [col(sh, r) for sh, rs in others for r in rs]
trip.append(dict(panel=f"Other n=3 measured groups (Fig. 2a, 3c, 4a, 4c, 4d, 4f, 6e, Supp. 4b, 5c, 7a, 7b; {len(g)} groups)", groups=len(g),
                 groups_where_one_value_is_exact_mean_of_other_two=sum(exact_mid(x) for x in g), groups_with_two_identical_values=sum(len(set(x)) == 2 for x in g), values=""))
TRIP = pd.DataFrame(trip)
# Fig 2b re-test using only the two values that are not the mean
rows = []
for lab, r in [("ADP", 4), ("Collagen", 5), ("Thrombin", 6)]:
    a2, b2 = col("Fig. 2b", f"B{r}:C{r}"), col("Fig. 2b", f"E{r}:F{r}"); a3, b3 = col("Fig. 2b", f"B{r}:D{r}"), col("Fig. 2b", f"E{r}:G{r}")
    rows.append(dict(agonist=lab, vehicle=str(a3.tolist()), creatine=str(b3.tolist()), p_as_reported_n3=stats.ttest_ind(a3, b3).pvalue, p_if_n2=stats.ttest_ind(a2, b2).pvalue))
F2B = pd.DataFrame(rows)

# ----------------------------------------------------------------------------------------------------------
# 8. Planning numbers (sample size) from the observed variability
# ----------------------------------------------------------------------------------------------------------
def pw_int(delta, sd, n, alpha=0.05):
    df = 4*n-4; ncp = delta/(sd*np.sqrt(4/n)); tc = stats.t.ppf(1-alpha/2, df); return stats.nct.sf(tc, df, ncp) + stats.nct.cdf(-tc, df, ncp)
full = float(np.log(PHP.loc[PHP.endpoint == "Metastatic burden (%)", "pooled_ratio_random_effects"].iloc[0]))
rows = []
for sd in (0.34, 0.45, 0.57):
    for n in (6, 8, 10, 12, 16):
        rows.append(dict(within_group_log_sd=sd, n_per_group=n, power_full_block=pw_int(full, sd, n), power_75pct_block=pw_int(0.75*full, sd, n), power_50pct_block=pw_int(0.5*full, sd, n),
                         detectable_baseline_ratio_80pct_power=np.exp(-(stats.t.ppf(0.975, 2*n-2)+stats.t.ppf(0.8, 2*n-2))*sd*np.sqrt(2/n))))
PW = pd.DataFrame(rows)

# ----------------------------------------------------------------------------------------------------------
# 9. Write tables
# ----------------------------------------------------------------------------------------------------------
README = pd.DataFrame({"sheet": ["creatine_phenotype","phenotype_pooled","survival","node_factorial","platelet_transfer","mk_gene_programme","mk_gene_contrasts","mk_genes_long","stat5b_cko_residual",
                                  "human_aggregation","human_other","human_cd41_qpcr","phospho_summary","phospho_top40","two_group_check","multi_group_check","qpcr_arithmetic","megakaryopoiesis_genes","chip_qpcr","stat5b_phospho_mutants","human_indices_dunnett","duplicate_values","triplet_patterns","fig2b_sensitivity","power"],
 "content": ["Creatine vs vehicle in every independent metastasis experiment: ratio of means, geometric-mean ratio with 95% CI (t interval on log values).",
             "DerSimonian-Laird random-effects pooling of the log geometric-mean ratios per endpoint (descriptive; Fig. 1f arms share one experiment).",
             "Log-rank and Cox re-derivation of Fig. 1c and Fig. 1l.",
             "2x2 re-analysis (perturbation x creatine): % of the creatine-induced increment blocked = 1 - (increment in perturbed)/(increment in control); 95% CI by Fieller's theorem (pooled within-group variance), with a percentile bootstrap (20,000 resamples) as cross-check; interaction P from two-way ANOVA (raw and log scale).",
             "Platelet-transfer experiments (three-arm / two-arm).",
             "11-gene platelet-activation panel in megakaryocytes. Composite = mean log2 relative expression over the 11 genes per replicate (n = 3 replicates/condition); P = unpaired t test on the composite.",
             "Selected composite contrasts.", "Per-gene, per-replicate relative expression used for the composite.", "Fig. 6g: per-gene induction remaining in Stat5b-cKO megakaryocytes given creatine.",
             "Fig. 7c (n = 11 volunteers, fold change vs own day 0). Sheet test = ordinary one-way ANOVA + Dunnett on fold changes (unpaired, day-0 column is all 1). Re-analysis: one-sample t on log2 fold change, Wilcoxon signed-rank, BH/Holm over the 36 tests.",
             "Serum creatine, platelet GP6/P2RY12 protein (n = 4), platelet indices and BMI: paired tests.",
             "Fig. 7d (n = 4 volunteers): the sheet's 'After normalization' values (sheet_V1-4) vs the same quantity recomputed from the ΔCT triplicates (recalc_V1-4 = mean 2^ΔCT at day / mean 2^ΔCT at day 0, which reproduces the sheet for all entries except volunteer 4 RAB27B and PITPNB). Summary statistics are given on the sheet's values and, for comparison, on the difference of mean ΔCT.",
             "Phosphoproteomics volcano table summary.", "Forty smallest P values in the phosphoproteomics table.",
             "Every two-group panel: recomputed unpaired t test vs the P value/t statistic embedded in the sheet (all match).",
             "One-way ANOVA + Tukey recomputation for every multi-group panel.", "Check that 2^ΔΔCT values in the qPCR sheets follow from the ΔCT values given.",
             "Supplementary Fig. 3c.", "Fig. 5j and Supp. Fig. 6i: % input by region, fold with creatine, Sidak-adjusted P recomputed vs sheet.",
             "Fig. 5e/5f: pan-phospho/FLAG ratio per STAT5B construct with and without creatine; WT-vs-S127A x creatine interaction.",
             "Supp. Fig. 8b: Dunnett P values recomputed vs sheet.", "Measured values (>= 5 significant digits), and ordered runs of three values, that occur in more than one sheet (qPCR/ChIP-qPCR sheets excluded: CT is rounded to 2 dp).",
             "n = 3 groups in which one value is the exact mean of the other two, or two values are identical.", "Fig. 2b P values as reported (n = 3) and using only the two values that are not the mean (n = 2).",
             "Power of the genotype x creatine interaction test on log metastatic burden for the proposed factorial study."]})
with pd.ExcelWriter(OUT_XLSX, engine="openpyxl") as xw:
    README.to_excel(xw, "README", index=False)
    for name, df in [("creatine_phenotype", PH), ("phenotype_pooled", PHP), ("survival", SURV), ("node_factorial", FAT), ("platelet_transfer", TRANSFER), ("mk_gene_programme", QP),
                     ("mk_gene_contrasts", QC), ("mk_genes_long", QG), ("stat5b_cko_residual", G6), ("human_aggregation", HA), ("human_other", HO), ("human_cd41_qpcr", H7D),
                     ("phospho_summary", PS), ("phospho_top40", PTOP), ("two_group_check", TT), ("multi_group_check", MGT), ("qpcr_arithmetic", AR), ("megakaryopoiesis_genes", S3C), ("chip_qpcr", CH), ("stat5b_phospho_mutants", MUT), ("human_indices_dunnett", DUN8),
                     ("duplicate_values", DUP), ("triplet_patterns", TRIP), ("fig2b_sensitivity", F2B), ("power", PW)]:
        df.to_excel(xw, name, index=False)
    for wsx in xw.book.worksheets:
        for colcells in wsx.columns:
            width = max(len(str(c.value)) if c.value is not None else 0 for c in colcells[:60])
            wsx.column_dimensions[colcells[0].column_letter].width = min(max(10, width+2), 70)
        wsx.freeze_panes = "A2"

# ----------------------------------------------------------------------------------------------------------
# 10. Figures
# ----------------------------------------------------------------------------------------------------------
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})
C_VEH, C_CRE, C_A, C_B, C_C = "#7f7f7f", "#d95f02", "#1b9e77", "#7570b3", "#e7298a"

# Fig 1 – phenotype forest
fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2), sharey=True)
for ax, ep in zip(axes, ["Metastatic burden (%)", "Metastatic foci (n)"]):
    s = PH[PH.endpoint == ep].reset_index(drop=True); y = np.arange(len(s))[::-1]
    ax.errorbar(s.geo_mean_ratio, y, xerr=[s.geo_mean_ratio-s.gmr_ci95_low, s.gmr_ci95_high-s.geo_mean_ratio], fmt="o", color=C_CRE, ecolor="#555555", capsize=2, ms=5)
    pr = PHP[PHP.endpoint == ep].iloc[0]
    ax.axvspan(pr.ci95_low, pr.ci95_high, color=C_CRE, alpha=0.12); ax.axvline(pr.pooled_ratio_random_effects, color=C_CRE, lw=1, ls="--"); ax.axvline(1, color="k", lw=0.8)
    ax.set_xscale("log"); ax.set_xticks([1, 2, 4, 8]); ax.set_xticklabels(["1", "2", "4", "8"]); ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter()); ax.set_xlim(0.9, 9)
    ax.set_xlabel("creatine / vehicle, geometric-mean ratio (95% CI)")
    ax.set_title(f"{ep}\npooled {pr.pooled_ratio_random_effects:.1f}x (95% CI {pr.ci95_low:.1f}-{pr.ci95_high:.1f}), {int(pr.k_experiments)} comparisons", fontsize=9)
    ax.set_yticks(y); ax.set_yticklabels([f"{e}  (n={a}+{b})" for e, a, b in zip(s.experiment, s.n_vehicle, s.n_creatine)])
fig.suptitle("Exogenous creatine increases lung metastasis in every experiment in the package", fontsize=10, y=1.0)
fig.tight_layout(); fig.savefig(os.path.join(FIGDIR, "fig1_creatine_phenotype.png"), bbox_inches="tight"); plt.close(fig)

# Fig 2 – node perturbation on metastatic burden: raw data + % blocked
fig, axes = plt.subplots(1, 5, figsize=(16.5, 4.2), gridspec_kw={"width_ratios": [1, 1, 1, 0.8, 1.5]})
def strip(ax, groups, labels, colors, title, ylabel="Metastatic burden (% lung area)"):
    for i, (g, c) in enumerate(zip(groups, colors)):
        x = i + (RNG.random(len(g))-0.5)*0.25
        ax.scatter(x, g, s=22, color=c, alpha=0.85, zorder=3, edgecolor="white", linewidth=0.4); ax.hlines(g.mean(), i-0.28, i+0.28, color="k", lw=1.5, zorder=4)
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(labels, fontsize=7.5); ax.set_title(title, fontsize=9); ax.set_ylabel(ylabel); ax.set_ylim(0, None)
g3 = [col("Fig. 3i", r) for r in ["B10:B13","C10:C13","D10:D13","E10:E13"]]
strip(axes[0], g3, ["+/+\nveh","+/+\ncre","cKO\nveh","cKO\ncre"], [C_VEH, C_CRE, C_VEH, C_A], "Megakaryocyte Slc6a8 deletion\n(Fig. 3i, n=4)")
g6b = [col("Fig. 6b", r) for r in ["B4:B8","C4:C8","D4:D8","E4:E8"]]
strip(axes[1], g6b, ["veh","cre","veh\n+STAT5i","cre\n+STAT5i"], [C_VEH, C_CRE, C_VEH, C_B], "STAT5-IN-1, systemic\n(Fig. 6b, n=5)")
g1f = [col("Fig. 1f", r) for r in ["B22:B27","C22:C27","D22:D27","E22:E27"]]
strip(axes[2], g1f, ["sh-scr\nveh","sh-scr\ncre","sh-Slc\nveh","sh-Slc\ncre"], [C_VEH, C_CRE, C_VEH, C_CRE], "Tumour-cell Slc6a8 knock-down\n(Fig. 1f, n=6)")
g2d = [col(S("2d"), r) for r in ["C5:C10","D5:D10","E5:E10"]]
strip(axes[3], g2d, ["veh\ndonor","cre\ndonor","cre+ASA\ndonor"], [C_VEH, C_CRE, C_C], "Donor-platelet transfer\n(Supp. Fig. 2d, n=6)")
ax = axes[4]
bars = [("MK Slc6a8\ncKO\n(Fig. 3i)", FAT[(FAT.sheet=="Fig. 3i")&(FAT.endpoint=="Metastatic burden (%)")].iloc[0], C_A),
        ("STAT5-IN-1\nsystemic\n(Fig. 6b)", FAT[(FAT.sheet=="Fig. 6b")&(FAT.endpoint=="Metastatic burden (%)")].iloc[0], C_B),
        ("Tumour\nsh-Slc6a8\n(Fig. 1f)", FAT[(FAT.sheet=="Fig. 1f")&(FAT.endpoint=="Metastatic burden (%)")].iloc[0], C_CRE)]
for i, (lab, r, c) in enumerate(bars):
    ax.bar(i, r.pct_increment_blocked, color=c, width=0.6); ax.errorbar(i, r.pct_increment_blocked, yerr=[[r.pct_increment_blocked-r.fieller_ci95_low], [r.fieller_ci95_high-r.pct_increment_blocked]], color="k", capsize=3)
    ax.text(i, max(r.fieller_ci95_high, 0)+6, f"{r.pct_increment_blocked:.0f}%\nP(int)={r.interaction_p:.1g}", ha="center", fontsize=7.5)
tr = TRANSFER[(TRANSFER.sheet=="Supplementary Fig 2d")&(TRANSFER.endpoint=="Metastatic burden (%)")].iloc[0]
ax.bar(3, tr.pct_increment_reversed, color=C_C, width=0.6); ax.errorbar(3, tr.pct_increment_reversed, yerr=[[tr.pct_increment_reversed-tr.fieller_ci95_low],[tr.fieller_ci95_high-tr.pct_increment_reversed]], color="k", capsize=3)
ax.text(3, tr.fieller_ci95_high+6, f"{tr.pct_increment_reversed:.0f}%\n(3-arm)", ha="center", fontsize=7.5)
ax.axhline(0, color="k", lw=0.8); ax.axhline(100, color="k", lw=0.6, ls=":"); ax.set_xticks(range(4)); ax.set_xticklabels([b[0] for b in bars]+["Aspirin,\ndonor PLT\n(Supp. 2d)"], fontsize=7.5)
ax.set_ylabel("% of creatine-induced increment\nin metastatic burden removed (95% CI)"); ax.set_ylim(-95, 210); ax.set_title("Size of the block", fontsize=9)
fig.tight_layout(); fig.savefig(os.path.join(FIGDIR, "fig2_node_perturbation_metastasis.png"), bbox_inches="tight"); plt.close(fig)

# Fig 3 – MK gene-programme composite
COLS = {"control": C_VEH, "creatine": C_CRE, "blocked": C_A, "alone": "#c7c7c7", "bypass": C_B, "pcr": C_C}
ROLE = {("Fig. 2f","Vehicle"):"control", ("Fig. 2f","Creatine"):"creatine",
        ("Fig. 3f","Slc6a8+/+ vehicle"):"control", ("Fig. 3f","Slc6a8+/+ creatine"):"creatine", ("Fig. 3f","Slc6a8 cKO vehicle"):"alone", ("Fig. 3f","Slc6a8 cKO creatine"):"blocked",
        (S("4e"),"Control"):"alone", (S("4e"),"Creatine"):"blocked", (S("4e"),"Creatine@liposome"):"bypass",
        ("Fig. 4h","Control"):"control", ("Fig. 4h","Creatine"):"creatine", ("Fig. 4h","Phosphocreatine"):"pcr",
        ("Fig. 4j","Control + si-scr"):"control", ("Fig. 4j","Control + si-Ckb"):"alone", ("Fig. 4j","Creatine + si-scr"):"creatine", ("Fig. 4j","Creatine + si-Ckb"):"blocked",
        ("Fig. 4l","CKB empty vector"):"control", ("Fig. 4l","CKB over-expression"):"bypass",
        ("Fig.6a","Vehicle"):"control", ("Fig.6a","Creatine"):"creatine", ("Fig.6a","Vehicle + STAT5-IN-1"):"alone", ("Fig.6a","Creatine + STAT5-IN-1"):"blocked",
        ("Fig. 6g","WT vehicle"):"control", ("Fig. 6g","WT creatine"):"creatine", ("Fig. 6g","Stat5b cKO creatine"):"blocked"}
HEAD = {"Fig. 2f":"Fig. 2f\nMKs, dosed mice", "Fig. 3f":"Fig. 3f\nMK Slc6a8 cKO mice", S("4e"):"Supp. Fig. 4e\nSlc6a8-cKO MKs in vitro", "Fig. 4h":"Fig. 4h\nMKs in vitro",
        "Fig. 4j":"Fig. 4j\nMKs in vitro", "Fig. 4l":"Fig. 4l\nMKs in vitro", "Fig.6a":"Fig. 6a\nMKs in vitro", "Fig. 6g":"Fig. 6g\nMK Stat5b cKO mice"}
fig, ax = plt.subplots(figsize=(12.5, 4.6)); x = 0; ticks, labels, heads = [], [], []
for sh, (desc, conds) in PANELS.items():
    x0 = x
    for c in conds:
        v = 2**COMP[sh][c]
        ax.bar(x, v.mean(), color=COLS[ROLE[(sh, c)]], width=0.75); ax.scatter(x + (RNG.random(3)-0.5)*0.3, v, s=10, color="k", zorder=3)
        ticks.append(x); labels.append(c); x += 1
    heads.append(((x0 + x - 1)/2, HEAD[sh])); x += 0.7
ax.axhline(1, color="k", lw=0.8, ls=":"); ax.set_xticks(ticks); ax.set_xticklabels(labels, rotation=55, ha="right", fontsize=7.5); ax.set_ylim(0, 7.4)
ax.set_ylabel("11-gene platelet-activation composite\n(fold vs panel control; n = 3 replicates)")
for xc, h in heads: ax.text(xc, 7.3, h, ha="center", va="top", fontsize=7.2)
import matplotlib.patches as mpatches
ax.legend(handles=[mpatches.Patch(color=COLS[k], label=l) for k, l in [("control","control"),("creatine","creatine, pathway intact"),("blocked","creatine + node removed/inhibited"),
          ("alone","perturbation alone"),("bypass","bypass / gain (liposomal creatine, CKB over-expression)"),("pcr","phosphocreatine")]], frameon=False, fontsize=7, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.42))
fig.tight_layout(); fig.savefig(os.path.join(FIGDIR, "fig3_mk_gene_programme.png"), bbox_inches="tight"); plt.close(fig)

# Fig 4 – human platelets
fig, axes = plt.subplots(1, 5, figsize=(15, 3.8), gridspec_kw={"width_ratios": [1, 1, 1, 1, 1.1]})
for ax, ag in zip(axes[:4], ["Collagen", "Epinephrine", "Arachidonic acid", "ADP"]):
    arr = np.clip(HUM[(ag, "max aggregation")], 0.1, None)
    for i in range(11): ax.plot([0, 3, 7, 14], arr[i], color="#999999", lw=0.7, marker="o", ms=2.5)
    gm = 2**np.log2(arr).mean(0); ax.plot([0, 3, 7, 14], gm, color=C_CRE, lw=2.2, marker="s", ms=5, label="geometric mean")
    r14 = HA[(HA.agonist == ag) & (HA.metric == "max aggregation") & (HA.day == 14)].iloc[0]
    ax.set_yscale("log"); ax.set_ylim(0.09, 16); ax.set_yticks([0.125, 0.25, 0.5, 1, 2, 4, 8, 16]); ax.set_yticklabels(["0.125", "0.25", "0.5", "1", "2", "4", "8", "16"])
    ax.yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter()); ax.axhline(1, color="k", lw=0.6, ls=":")
    ax.set_xticks([0, 3, 7, 14]); ax.set_xlabel("day of creatine (20 g/day)"); ax.set_title(f"{ag}\nday 14: {r14.geo_mean_fold:.2f}x, {r14.n_volunteers_up}/11 up, Wilcoxon P={r14.p_wilcoxon_signed_rank:.3f}", fontsize=8.5)
axes[0].set_ylabel("max. aggregation, fold of own day 0 (n=11)"); axes[0].legend(frameon=False, fontsize=7, loc="upper left")
ax = axes[4]
for lab, r0, c in [("GP6", 4, C_A), ("P2RY12", 12, C_B)]:
    arr = np.array([[cell("Fig. 7e", f"{cc}{r}") for cc in "BCDE"] for r in range(r0, r0+4)], float); rel = arr/arr[:, [0]]
    for i in range(4): ax.plot([0, 3, 7, 14], rel[i], color=c, lw=0.6, alpha=0.5)
    ax.plot([0, 3, 7, 14], 2**np.log2(rel).mean(0), color=c, lw=2.2, marker="s", ms=5, label=f"{lab} protein")
ax.axhline(1, color="k", lw=0.6, ls=":"); ax.set_xticks([0, 3, 7, 14]); ax.set_xlabel("day of creatine"); ax.set_ylabel("platelet protein / b-actin, fold of own day 0 (n=4)"); ax.legend(frameon=False, fontsize=7.5)
ax.set_title("Platelet GP6 and P2RY12 (immunoblot)", fontsize=8.5)
fig.tight_layout(); fig.savefig(os.path.join(FIGDIR, "fig4_human_platelets.png"), bbox_inches="tight"); plt.close(fig)

# Fig 5 – phospho volcano
fig, ax = plt.subplots(figsize=(6.2, 4.6))
ax.scatter(ph.log2fc, -np.log10(ph.p), s=4, color="#bbbbbb", rasterized=True)
scr = pd.concat([up, dn]); ax.scatter(scr.log2fc, -np.log10(scr.p), s=6, color="#6a9fd8", label=f"meets screening rule (P<0.05, fold>=1.2 or <=0.83): {len(scr)}")
ax.scatter([st.log2fc], [-np.log10(st.p)], s=60, color=C_CRE, edgecolor="k", zorder=5, label=f"Stat5b (P={st.p:.4f}, Q={st.q:.2f}, rank {int(st.rank_p)})")
for _, r in ph.sort_values("p").head(6).iterrows(): ax.annotate(r.gene, (r.log2fc, -np.log10(r.p)), fontsize=6.5, xytext=(3, 2), textcoords="offset points")
ax.axhline(-np.log10(0.05), color="k", lw=0.6, ls=":"); ax.set_xlabel("log2 fold change (creatine / vehicle), megakaryocyte phosphopeptides"); ax.set_ylabel("-log10 P (n = 3 mice per group)")
ax.set_title(f"No phosphopeptide passes FDR: min Q = {ph.q.min():.2f}; {int((ph.p<0.05).sum())}/{len(ph)} rows have P<0.05", fontsize=9); ax.legend(frameon=False, fontsize=7, loc="lower left")
fig.tight_layout(); fig.savefig(os.path.join(FIGDIR, "fig5_phosphoproteomics.png"), bbox_inches="tight"); plt.close(fig)

# ----------------------------------------------------------------------------------------------------------
# 11. Console digest
# ----------------------------------------------------------------------------------------------------------
pd.set_option("display.width", 260); pd.set_option("display.max_columns", 40); pd.set_option("display.max_rows", 300)
print("Two-group panels re-derived:", len(TT), "| all embedded t/df/P reproduced:", bool(TT.reported_matches_recomputed.all()))
print("qPCR arithmetic max relative deviation:", AR.max_rel_dev.max())
print(PHP.to_string(float_format=lambda v: f"{v:.3g}")); print(SURV.to_string(float_format=lambda v: f"{v:.3g}"))
print(FAT[["sheet","endpoint","perturbation","control_vehicle","control_creatine","perturbed_vehicle","perturbed_creatine","pct_increment_blocked","fieller_ci95_low","fieller_ci95_high","boot_ci95_low","boot_ci95_high","interaction_p","baseline_ratio_perturbed_over_control","p_baseline"]].to_string(float_format=lambda v: f"{v:.3g}"))
print(TRANSFER.to_string(float_format=lambda v: f"{v:.3g}"))
print(QP[["sheet","condition","median_gene_fold","composite_fold","genes_up_p_lt_0_05","composite_p_vs_control"]].to_string(float_format=lambda v: f"{v:.3g}"))
print(QC.to_string(float_format=lambda v: f"{v:.3g}")); print(G6.to_string(float_format=lambda v: f"{v:.3g}"))
print(HA[["agonist","metric","day","geo_mean_fold","median_fold","n_volunteers_up","sheet_dunnett_p_unpaired","p_one_sample_t_log2","p_wilcoxon_signed_rank","wilcoxon_BH_36_tests","wilcoxon_Holm_36_tests"]].to_string(float_format=lambda v: f"{v:.3g}"))
print(HO.to_string(float_format=lambda v: f"{v:.3g}"))
print(H7D[["gene","day","sheet_V1","sheet_V2","sheet_V3","sheet_V4","recalc_V4","max_rel_mismatch","geo_mean_fold_sheet","n_up_sheet","p_one_sample_t_log2_sheet","geo_mean_fold_from_mean_dCt","n_up_from_mean_dCt"]].to_string(float_format=lambda v: f"{v:.3g}"))
print(CH.to_string(float_format=lambda v: f"{v:.3g}")); print(MUT.to_string(float_format=lambda v: f"{v:.3g}")); print(DUN8.to_string(float_format=lambda v: f"{v:.3g}"))
print("max |Dunnett recomputed - sheet| (Fig. 7c):", np.nanmax(np.abs(HA.dunnett_p_recomputed - pd.to_numeric(HA.sheet_dunnett_p_unpaired.astype(str).str.replace(">", ""), errors="coerce"))))
print(PS.to_string()); print(DUP.to_string()); print(TRIP.to_string()); print(F2B.to_string()); print(PW.to_string(float_format=lambda v: f"{v:.2f}"))
print("written:", os.path.abspath(OUT_XLSX))
