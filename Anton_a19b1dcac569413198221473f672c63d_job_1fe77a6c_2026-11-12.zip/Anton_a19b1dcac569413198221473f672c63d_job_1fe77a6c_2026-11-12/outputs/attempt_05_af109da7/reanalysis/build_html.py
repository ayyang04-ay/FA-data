#!/usr/bin/env python
"""Render the proposal Markdown to a self-contained HTML file (figures embedded) and copy the two
hand-curated tables (cautions, panel inventory) into the evidence workbook.
Run after reanalysis.py:  micromamba run -n chem python build_html.py
"""
import os, re, base64, markdown, openpyxl
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = os.path.join(HERE, "..")
md_path = os.path.join(OUT, "CRE-MK-01_validation_proposal.md")
text = open(md_path, encoding="utf-8").read()

def embed(m):
    alt, path = m.group(1), m.group(2)
    with open(os.path.join(OUT, path), "rb") as fh:
        b64 = base64.b64encode(fh.read()).decode()
    return f'<img alt="{alt}" src="data:image/png;base64,{b64}" style="max-width:100%"/>'
body_md = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", embed, text)
html_body = markdown.markdown(body_md, extensions=["tables", "sane_lists"])
css = """
body{font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.45;max-width:1100px;margin:24px auto;padding:0 18px;color:#1a1a1a}
h1{font-size:22px;margin-top:22px} h2{font-size:18px;margin-top:26px;border-bottom:1px solid #ccc;padding-bottom:3px} h3{font-size:15px;margin-top:20px}
table{border-collapse:collapse;width:100%;margin:10px 0 16px 0;font-size:12.5px} th,td{border:1px solid #bbb;padding:5px 7px;vertical-align:top;text-align:left}
th{background:#f0f0f0} code{background:#f4f4f4;padding:1px 3px} em{color:#444}
"""
html = f"<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><title>CRE-MK-01 validation proposal</title><style>{css}</style></head><body>{html_body}</body></html>"
open(os.path.join(OUT, "CRE-MK-01_validation_proposal.html"), "w", encoding="utf-8").write(html)

# --- copy the two curated tables into the workbook
def md_table(after_heading):
    i = text.index(after_heading); lines = text[i:].split("\n"); rows = []; started = False
    for ln in lines[1:]:
        if ln.startswith("|"):
            started = True
            cells = [c.strip() for c in ln.strip().strip("|").split("|")]
            if set("".join(cells)) <= set("-: "): continue
            rows.append(cells)
        elif started: break
    return rows
xlsx = os.path.join(OUT, "CRE-MK-01_evidence_tables.xlsx"); wb = openpyxl.load_workbook(xlsx)
for name, head in [("cautions", "## 4. Cautions about the package"), ("panel_inventory", "## Appendix B. Panel inventory")]:
    if name in wb.sheetnames: del wb[name]
    ws = wb.create_sheet(name)
    for r in md_table(head): ws.append(r)
    for col in ws.columns: ws.column_dimensions[col[0].column_letter].width = min(90, max(12, max(len(str(c.value or "")) for c in col) + 2))
    ws.freeze_panes = "A2"
rd = wb["README"]; have = {r[0].value for r in rd.iter_rows()}
for nm, txt in [("cautions", "Section 4 of the proposal: data-integrity and design cautions (curated)."), ("panel_inventory", "Appendix B of the proposal: one line per panel of the source workbook (curated from the tables above and from reading the blot images).")]:
    if nm not in have: rd.append([nm, txt])
wb.save(xlsx)
print("html bytes:", len(html), "| sheets:", len(wb.sheetnames))
