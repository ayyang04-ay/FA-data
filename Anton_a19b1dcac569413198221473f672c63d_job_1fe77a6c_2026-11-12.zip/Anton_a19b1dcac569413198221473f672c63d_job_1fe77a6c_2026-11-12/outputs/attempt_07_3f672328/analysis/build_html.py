#!/usr/bin/env python
"""Render the proposal markdown to a single self-contained HTML file (figures embedded)."""
import markdown, base64, re, os
here = os.path.dirname(os.path.abspath(__file__)); root = os.path.join(here, '..')
md = open(os.path.join(root, 'CRE-MK-01_followup_proposal.md'), encoding='utf8').read()
html = markdown.markdown(md, extensions=['tables', 'sane_lists'])
def embed(m):
    path = os.path.join(root, m.group(1))
    b64 = base64.b64encode(open(path, 'rb').read()).decode()
    return f'src="data:image/png;base64,{b64}"'
html = re.sub(r'src="(figures/[^"]+)"', embed, html)
css = """
body{font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;font-size:14.5px;line-height:1.5;color:#1d1d1f;max-width:1080px;margin:28px auto;padding:0 22px}
h1{font-size:24px;margin-top:26px} h2{font-size:19px;margin-top:30px;border-bottom:1px solid #ddd;padding-bottom:4px} h3{font-size:16px;margin-top:22px}
table{border-collapse:collapse;width:100%;margin:10px 0 16px 0;font-size:13px}
th,td{border:1px solid #d0d0d0;padding:5px 8px;vertical-align:top;text-align:left} th{background:#f2f2f2}
img{max-width:100%;height:auto;margin:8px 0 2px 0;border:1px solid #eee}
body>p:first-child{font-size:17px;background:#f5f8f2;border-left:5px solid #2e8b57;padding:12px 14px}
code{background:#f4f4f4;padding:1px 4px;border-radius:3px;font-size:12.5px}
em{color:#444}
"""
out = f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>CRE-MK-01 follow-up proposal</title><style>{css}</style></head><body>{html}</body></html>'
open(os.path.join(root, 'CRE-MK-01_followup_proposal.html'), 'w', encoding='utf8').write(out)
print('written', len(out) // 1024, 'kB')
