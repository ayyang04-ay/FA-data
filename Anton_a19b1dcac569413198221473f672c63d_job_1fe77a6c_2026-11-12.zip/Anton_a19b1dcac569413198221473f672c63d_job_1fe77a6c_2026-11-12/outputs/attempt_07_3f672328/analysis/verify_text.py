"""Checks that the numbers quoted in the proposal are the ones the analysis produces."""
import re, math, numpy as np, pandas as pd
from scipy import stats
import reanalysis as R
doc = open('../CRE-MK-01_followup_proposal.md', encoding='utf8').read()
checks = []
def need(label, text):
    checks.append((label, text, text in doc))
P = R.POOL
need('pooled burden', f"pooled ratio {P['burden']['ratio']:.1f}, 95% CI {P['burden']['lo']:.1f}–{P['burden']['hi']:.1f}")
need('pooled burden table', f"pooled {P['burden']['ratio']:.1f} (95% CI {P['burden']['lo']:.1f}–{P['burden']['hi']:.1f}), n = {P['burden']['n_ctrl']} + {P['burden']['n_cre']}")
need('range', f"Ratio {P['burden']['min_ratio']:.1f}–{P['burden']['max_ratio']:.1f} in each of ten experiments")
need('pooled foci', f"Pooled ratio {P['foci']['ratio']:.1f} ({P['foci']['lo']:.1f}–{P['foci']['hi']:.1f})")
for tag, txt in [('Fig 1c', 'HR {:.1f} ({:.2f}–{:.1f})'), ('Fig 1l', 'HR {:.1f} ({:.1f}–{:.1f})')]:
    hr = R.SURV[tag][4]; need('HR ' + tag, txt.format(hr[0], hr[1], hr[2]))
M = R.METAD.set_index('experiment')
def mrow(name): return M.loc[name]
r = mrow('Fig 3i: MK-lineage Slc6a8 knock-out'); c = mrow('Fig 3i (Pf4-Cre;Slc6a8+/+ controls)')
need('KO ratio', f"×{r.burden_ratio:.1f}, against ×{c.burden_ratio:.1f} in Cre controls")
I = R.INTD
def inter(panel, ep, scale='log (ratio)'): return I[(I.panel == panel) & (I.endpoint == ep) & (I.scale == scale)].iloc[0]
need('KO interaction', f"interaction P = {inter('Fig 3i: MK-lineage Slc6a8 KO','metastatic burden (%)').P_interaction:.4f}")
need('KO foci interaction', f"P = {inter('Fig 3i: MK-lineage Slc6a8 KO','metastatic foci (n)').P_interaction:.3f} |")
need('KO lung wt interaction', f"P = {inter('Fig 3i: MK-lineage Slc6a8 KO','lung weight (g)').P_interaction:.4f} |")
need('tumour KD interaction', f"interaction P = {inter('Fig 1f: tumour-cell sh-Slc6a8','metastatic burden (%)').P_interaction:.2f}")
need('tumour KD foci interaction', f"interaction P = 0.44 and {inter('Fig 1f: tumour-cell sh-Slc6a8','metastatic foci (n)').P_interaction:.2f}")
t = mrow('Fig 1f: tumour-cell Slc6a8 knock-down'); tc = mrow('Fig 1f (sh-scrambled melanoma)')
need('tumour KD ratios', f"×{t.burden_ratio:.1f} vs ×{tc.burden_ratio:.1f}")
s6 = mrow('Fig 6b: + STAT5-IN-1 (pan-STAT5, systemic)'); c6 = mrow('Fig 6b (no inhibitor)')
need('STAT5i ratios', f"Creatine effect ×{c6.burden_ratio:.1f} → ×{s6.burden_ratio:.1f}; interaction P = {inter('Fig 6b: STAT5-IN-1','metastatic burden (%)').P_interaction:.4f}")
need('STAT5i sens', f"interaction P = {inter('Fig 6b: STAT5-IN-1, excluding the 3+3 animals duplicated in Supp 2d','metastatic burden (%)').P_interaction:.3f} with n = 2")
d = mrow('Supp 2d: platelets from creatine- vs vehicle-dosed donors'); h = mrow('Fig 7g: volunteer platelets, day 7 vs day 0, into mice')
need('transfer ratios brief', f"(×{d.burden_ratio:.1f} and ×{h.burden_ratio:.1f})")
need('transfer CI', f"×{d.burden_ratio:.1f}, 95% CI {d.burden_lo:.1f}–{d.burden_hi:.1f}")
need('human transfer CI', f"×{h.burden_ratio:.1f}, {h.burden_lo:.1f}–{h.burden_hi:.1f}")
# baseline
def ratio_ci(a, b):
    la, lb = np.log(a), np.log(b); dd = lb.mean() - la.mean(); va, vb = la.var(ddof=1) / len(la), lb.var(ddof=1) / len(lb); se = math.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(la) - 1) + vb ** 2 / (len(lb) - 1)); tq = stats.t.ppf(0.975, df)
    return math.exp(dd), math.exp(dd - tq * se), math.exp(dd + tq * se)
g = R.F3I['metastatic burden (%)']; x = ratio_ci(g[0], g[2]); need('baseline KO', f"Slc6a8 KO ×{x[0]:.1f}, 95% CI {x[1]:.1f}–{x[2]:.1f}")
g = R.F6B['metastatic burden (%)']; x = ratio_ci(g[0], g[2]); need('baseline STAT5i', f"STAT5 inhibitor ×{x[0]:.1f}, {x[1]:.1f}–{x[2]:.1f}")
S = R.PHS
need('stat5b', f"P = {S['stat5b_P']:.4f}, rank {S['stat5b_rank_by_P']} of {S['n_rows']:,} by P")
need('stat5b Q', f"Q = {S['stat5b_Q']:.2f}, and the smallest Q in the table is {S['min_Q']:.2f}")
need('n p<0.05', f"{S['n_P_lt_0_05']} rows reach P < 0.05")
onoff = (R.PH.p.round(5) == 0.42265).sum(); need('chance', f"about {0.05*(len(R.PH)-onoff):.0f} expected among the {len(R.PH)-onoff:,} rows")
need('second pep', f"P = {S['stat5b_second_peptide_P']:.2f}")
Q = R.QPD
def q(tag): return Q[Q.panel == tag]
need('3f median', f"1 → {q('Fig 3f').fold_stimulated.median():.1f} | {q('Fig 3f').fold_perturbed_baseline.median():.2f} → {q('Fig 3f').fold_perturbed_stimulated.median():.2f}")
need('3f interaction count', f"P < 0.05 for {(q('Fig 3f').P_interaction_log2 < 0.05).sum()} of 11 genes |")
need('4j', f"median ×{q('Fig 4j').fold_stimulated.median():.1f} to ×{q('Fig 4j').fold_perturbed_stimulated.median():.1f} (interaction P < 0.05 for {(q('Fig 4j').P_interaction_log2 < 0.05).sum()} of 11 genes")
need('4l', f"×{q('Fig 4l').fold_stimulated.min():.1f}–{q('Fig 4l').fold_stimulated.max():.1f} (Fig 4l)")
need('2f', f"Gene panel up ×{q('Fig 2f').fold_stimulated.min():.1f}–{q('Fig 2f').fold_stimulated.max():.1f}")
need('6a', f"median ×{q('Fig 6a').fold_stimulated.median():.1f} → ×{q('Fig 6a').fold_perturbed_stimulated.median():.2f}")
need('6a baseline', f"Inhibitor alone lowers {(q('Fig 6a').fold_perturbed_baseline <= 0.6).sum()} of 11 genes")
g6 = q('Fig 6g').set_index('gene'); need('6g', f"panel median ×{q('Fig 6g').fold_perturbed_stimulated.median():.1f} of wild-type vehicle, with P2ry12 ×{g6.loc['P2ry12'].fold_perturbed_stimulated:.1f} and Gp6 ×{g6.loc['Gp6'].fold_perturbed_stimulated:.1f}")
g3 = q('Fig 3f').set_index('gene'); need('3f genes', f"(×{g3.loc['P2ry12'].fold_perturbed_stimulated:.2f}, ×{g3.loc['Gp6'].fold_perturbed_stimulated:.2f} of control vehicle)")
s4 = q('Supp 4e'); need('S4e', f"(median ×{s4.fold_stimulated.median():.2f}), but liposomal creatine induced it (median ×{s4.fold_perturbed_stimulated.median():.1f}; {(s4.fold_perturbed_stimulated >= 2).sum()} of 11 genes at least 2-fold")
need('4h', f"Creatine induces the panel (median ×{q('Fig 4h').fold_stimulated.median():.1f}); phosphocreatine does not (×{q('Fig 4h').fold_perturbed_stimulated.median():.2f})")
H = R.HUM
def hh(ag, ep, d): return H[(H.agonist == ag) & (H.endpoint == ep) & (H.day == d)].iloc[0]
c14 = hh('collagen', 'max aggregation', 14); e14 = hh('epinephrine', 'max aggregation', 14); a14 = hh('arachidonic acid', 'max aggregation', 14); d14 = hh('ADP', 'max aggregation', 14)
need('collagen', f"Collagen: max aggregation ×{c14.geo_mean_FC:.1f} ({c14.ci_lo:.1f}–{c14.ci_hi:.1f}), {c14.n_increased} of 11 up")
need('epi', f"Epinephrine: ×{e14.geo_mean_FC:.1f} ({e14.ci_lo:.1f}–{e14.ci_hi:.1f}), {e14.n_increased} of 11 up")
need('aa', f"Arachidonic acid: ×{a14.geo_mean_FC:.1f} ({a14.ci_lo:.1f}–{a14.ci_hi:.1f})")
need('adp', f"ADP: ×{d14.geo_mean_FC:.2f} ({d14.ci_lo:.1f}–{d14.ci_hi:.1f}), {d14.n_increased} of 11 up")
need('holm', f"(P = {c14.Holm_wilcoxon:.3f} and {e14.Holm_wilcoxon:.3f})")
need('brief human', f"(×{c14.geo_mean_FC:.1f} and ×{e14.geo_mean_FC:.1f})")
need('serum human', f"{R.CRE_H[:,0].mean():.0f} → {R.CRE_H[:,1].mean():.0f} µM by day 3, {R.CRE_H[:,3].mean():.0f} µM at day 14")
for ep, key in [('GP6/beta-actin (platelet immunoblot)', 'GP6'), ('P2RY12/beta-actin (platelet immunoblot)', 'P2RY12')]:
    Mx = R.H7E[ep]; rel = np.exp(np.log(Mx / Mx[:, [0]]).mean(axis=0))
    need('7e ' + key, f"{key} ×{rel[2]:.1f} at day 7 and ×{rel[3]:.1f} at day 14" if key == 'GP6' else f"P2RY12 ×{rel[2]:.1f} and ×{rel[3]:.1f}")
Hs = R.H7Dsum.set_index(['gene', 'day'])
need('7d', f"ADRA2A ×{Hs.loc[('ADRA2A',7)].geo_mean_FC:.0f} (4 of 4), GP6 ×{Hs.loc[('GP6',7)].geo_mean_FC:.1f} ({int(Hs.loc[('GP6',7)].n_up_of_4)} of 4), P2RY12 ×{Hs.loc[('P2RY12',7)].geo_mean_FC:.1f} ({int(Hs.loc[('P2RY12',7)].n_up_of_4)} of 4). Day 14: RAB4A ×{Hs.loc[('RAB4A',14)].geo_mean_FC:.2f}")
a = R.H7C[('collagen', 'max aggregation')][:, 3]; b = R.H7C[('epinephrine', 'max aggregation')][:, 3]; need('spearman', f"(Spearman {stats.spearmanr(a, b)[0]:.2f})")
PW = R.PWD[(R.PWD.n_per_cell == 12) & (R.PWD.sigma_ln_burden.round(2) == 0.43)].iloc[0]
assert PW.power_interaction_100pct_abolition > 0.99
need('power', f"over 99% power to detect complete removal, {PW.power_interaction_70pct*100:.0f}% for removal of 70% or more, {PW.power_interaction_50pct*100:.0f}% for 50%")
need('power baseline', f"to {PW.smallest_baseline_ratio_detectable_80pct_power:.1f}-fold or lower")
need('power rank', f"({PW.power_to_separate_two_lines_differing_by_50_points*100:.0f}% power at 50 points)")
need('sd', f"({P['burden']['pooled_lnSD']:.2f}; range {P['burden']['lnSD_min']:.2f}–{P['burden']['lnSD_max']:.2f})")
need('audit n', f"all {len(R.AUD)} comparisons")
need('232', f"All {int((R.AUD.recorded_vs_recomputed=='yes').sum())} recorded P values agree")
# simple means
def m(x): return float(np.mean(x))
need('3c', f"{m(R.F3C[0]):.1f} → {m(R.F3C[1]):.1f} | {m(R.F3C[2]):.1f} → {m(R.F3C[3]):.1f}")
g = R.F3I['metastatic burden (%)']; need('3i burden', f"{m(g[0]):.1f} → {m(g[1]):.1f} | {m(g[2]):.1f} → {m(g[3]):.1f}")
g = R.F3I['metastatic foci (n)']; need('3i foci', f"{m(g[0]):.1f} → {m(g[1]):.1f} | {m(g[2]):.1f} → {m(g[3]):.1f}")
g = R.F3I['lung weight (g)']; need('3i lw', f"{m(g[0]):.3f} → {m(g[1]):.3f} | {m(g[2]):.3f} → {m(g[3]):.3f}")
g = R.S2D['metastatic burden (%)']; need('S2d', f"burden {m(g[0]):.1f} → {m(g[1]):.1f}%")
need('S2d aspirin', f"({m(g[2]):.1f}%)")
g = R.F6B['metastatic burden (%)']; need('6b app', f"Burden {m(g[0]):.1f} → {m(g[1]):.1f}% (vehicle); {m(g[2]):.1f} → {m(g[3]):.1f}% (inhibitor)")
need('6e', f"{m(R.F6E[2]):.0f} vs {m(R.F6E[1]):.0f} µmol/g")
pm = R.PERM
need('perm', f"(Slc6a8 KO P = {pm[('Fig 3i: MK-lineage Slc6a8 KO','metastatic burden (%)')]:.3f}; STAT5 inhibitor P = {pm[('Fig 6b: STAT5-IN-1','metastatic burden (%)')]:.4f}; tumour-cell knock-down P = {pm[('Fig 1f: tumour-cell sh-Slc6a8','metastatic burden (%)')]:.2f})")
need('std effect', f"({math.log(P['burden']['ratio'])/P['burden']['pooled_lnSD']:.1f} vs {math.log(P['foci']['ratio'])/P['foci']['pooled_lnSD']:.1f} SD on the log scale)")
N6 = R.POOL_NO6B['burden']; need('no6b', f"(×{N6['ratio']:.1f}, 95% CI {N6['lo']:.1f}–{N6['hi']:.1f} without it)")
bad = [c for c in checks if not c[2]]
print(f'{len(checks)-len(bad)} of {len(checks)} quoted strings found in the proposal')
for lab, txt, ok in bad: print('   MISSING:', lab, '->', txt)
