#!/usr/bin/env python
"""Figures for the CRE-MK-01 follow-up proposal. Run after reanalysis.py (imports its objects).
   micromamba run -n chem python figures.py"""
import math, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker
from matplotlib.patches import Rectangle
import reanalysis as R

OUT = R.OUT_F
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans', 'axes.titlesize': 10, 'axes.titleweight': 'bold'})
C_DIR, C_PERT, C_TR, C_POOL = '#4a4a4a', '#c0392b', '#1f6fb2', '#000000'

# ------------------------------------------------------------------ Fig 1: forest plot of the creatine effect on metastatic burden
M = R.METAD.copy(); P = R.POOL['burden']
rows = [('H', 'Creatine vs control, unmodified host and tumour')]
for _, r in M[M.kind == 'direct'].iterrows(): rows.append((r.experiment + f'  (n={r.n_ctrl}+{r.n_creatine})', r.burden_ratio, r.burden_lo, r.burden_hi, C_DIR, 'o'))
rows.append((f"Pooled, random effects  (10 experiments, n={P['n_ctrl']}+{P['n_cre']})", P['ratio'], P['lo'], P['hi'], C_POOL, 'D'))
rows.append(('H', 'Creatine vs control when one node is removed'))
for _, r in M[M.kind == 'perturbed'].iterrows(): rows.append((r.experiment + f'  (n={r.n_ctrl}+{r.n_creatine})', r.burden_ratio, r.burden_lo, r.burden_hi, C_PERT, 's'))
rows.append(('H', 'Platelet transfer into recipient mice (groups differ by donor exposure)'))
for _, r in M[M.kind == 'transfer'].iterrows(): rows.append((r.experiment + f'  (n={r.n_ctrl}+{r.n_creatine})', r.burden_ratio, r.burden_lo, r.burden_hi, C_TR, '^'))
fig, ax = plt.subplots(figsize=(10.2, 6.6))
y = len(rows); yt, yl = [], []
for i, rr in enumerate(rows):
    yy = y - i
    if rr[0] == 'H':
        ax.text(0.28, yy - 0.05, rr[1], fontsize=8.8, fontweight='bold', va='center'); continue
    lab, est, lo, hi, c, mk = rr
    ax.plot([lo, hi], [yy, yy], color=c, lw=1.6); ax.plot(est, yy, mk, color=c, ms=7 if mk != 'D' else 9)
    ax.text(10.2, yy, f'{est:.2f}  ({lo:.2f}–{hi:.2f})', va='center', ha='left', fontsize=8.5, color=c, clip_on=False)
    yt.append(yy); yl.append(lab)
ax.axvline(1, color='k', lw=0.8, ls='--'); ax.axvspan(P['lo'], P['hi'], color='#dddddd', alpha=0.6, zorder=0)
ax.set_xscale('log'); ax.set_xlim(0.27, 9.5); ax.set_xticks([0.5, 1, 2, 3, 5, 8]); ax.set_xticklabels(['0.5', '1', '2', '3', '5', '8'])
ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=8.5); ax.set_ylim(0.3, y + 0.7)
ax.set_xlabel('Ratio of geometric means, lung metastatic burden (creatine-exposed / control), 95% CI')
ax.text(10.2, y, 'ratio (95% CI)', fontsize=8.5, fontweight='bold', va='center', clip_on=False)
fig.suptitle('Creatine raises lung metastatic burden about 3-fold in every in-house experiment; the megakaryocyte transporter\nknock-out and the pan-STAT5 inhibitor remove the increment, tumour-cell Slc6a8 knock-down does not', x=0.01, ha='left', fontsize=10.5, fontweight='bold')
fig.text(0.01, 0.004, 'Recomputed from raw values on the log scale; t-based 95% CI per experiment; pooled = random effects with Hartung-Knapp CI (grey band).\nFig 6b and Supp 2d share three animals per arm (see data-integrity note).', fontsize=7.5, color='#444444')
fig.subplots_adjust(left=0.425, right=0.765, top=0.895, bottom=0.12); fig.savefig(f'{OUT}/fig2_creatine_effect_forest.png', dpi=200); plt.close(fig)

# ------------------------------------------------------------------ Fig 2: the three 2x2 experiments on the disease endpoint
fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.9), sharey=False)
specs = [('Tumour-cell Slc6a8 knock-down\n(Fig 1f, n=6/group)', R.F1F['metastatic burden (%)'], ['sh-scr', 'sh-Slc6a8'], 'Fig 1f: tumour-cell sh-Slc6a8', None),
         ('Megakaryocyte-lineage Slc6a8 knock-out\n(Fig 3i, n=4/group)', R.F3I['metastatic burden (%)'], ['Pf4-Cre;\nSlc6a8+/+', 'Pf4-Cre;\nSlc6a8fl/fl'], 'Fig 3i: MK-lineage Slc6a8 KO', None),
         ('Pan-STAT5 inhibitor, systemic\n(Fig 6b, n=5/group)', R.F6B['metastatic burden (%)'], ['DMSO', 'STAT5-IN-1'], 'Fig 6b: STAT5-IN-1', [1, 2, 3])]
rng = np.random.default_rng(3)
for ax, (title, g, labs, key, dup) in zip(axes, specs):
    pos = [0, 1, 2.6, 3.6]; cols = ['#7f8c8d', '#d35400', '#7f8c8d', '#d35400']
    for k, (x, vals, c) in enumerate(zip(pos, g, cols)):
        jit = rng.uniform(-0.13, 0.13, len(vals))
        ax.scatter(x + jit, vals, s=26, color=c, zorder=3, edgecolor='white', lw=0.5)
        if dup is not None and k in (0, 1):
            ax.scatter(x + jit[dup], vals[dup], s=70, facecolor='none', edgecolor='k', lw=1.1, zorder=4)
        ax.plot([x - 0.25, x + 0.25], [np.exp(np.mean(np.log(vals)))] * 2, color='k', lw=1.8, zorder=2)
    ax.set_xticks(pos); ax.set_xticklabels(['vehicle', 'creatine', 'vehicle', 'creatine'], fontsize=8)
    ymax = max(v.max() for v in g) * 1.22; ax.set_ylim(0, ymax)
    for xc, lab in zip([0.5, 3.1], labs): ax.text(xc, -0.19 * ymax, lab, ha='center', va='top', fontsize=8.5, fontweight='bold')
    I = R.INTD[(R.INTD.panel == key) & (R.INTD.endpoint == 'metastatic burden (%)') & (R.INTD.scale == 'log (ratio)')].iloc[0]
    ax.set_title(title, fontsize=9.5)
    ax.text(0.02, 0.98, f'creatine effect ×{I.creatine_effect_control_arm:.1f} → ×{I.creatine_effect_perturbed_arm:.1f}\ninteraction P = {I.P_interaction:.2g}', transform=ax.transAxes, va='top', fontsize=8.5)
    if dup is not None: ax.text(0.98, 0.80, 'circled: values also present\nin Supp 2d (platelet transfer)', transform=ax.transAxes, va='top', ha='right', fontsize=7.5, color='#333333')
axes[0].set_ylabel('Lung metastatic burden (%)')
fig.suptitle('What removes the creatine increment on the disease endpoint (individual animals; bar = geometric mean)', x=0.01, ha='left', fontsize=10.5, fontweight='bold')
fig.subplots_adjust(left=0.055, right=0.99, top=0.80, bottom=0.24, wspace=0.2); fig.savefig(f'{OUT}/fig3_interaction_experiments.png', dpi=200); plt.close(fig)

# ------------------------------------------------------------------ Fig 3: the megakaryocyte gene panel under each perturbation
Q = R.QPD
fig, axes = plt.subplots(1, 4, figsize=(12.4, 4.3), sharey=True)
for ax, (tag, ttl) in zip(axes, [('Fig 3f', 'MK-lineage Slc6a8 KO (Fig 3f)'), ('Fig 4j', 'si-Ckb, MKs in vitro (Fig 4j)'), ('Fig 6a', 'STAT5-IN-1 (Fig 6a)'), ('Fig 6g', 'MK-lineage Stat5b KO (Fig 6g)')]):
    sub = Q[Q.panel == tag].reset_index(drop=True); x = np.arange(len(sub))
    ax.axhline(1, color='k', lw=0.8, ls='--')
    h1 = ax.scatter(x - 0.12, sub.fold_stimulated, s=30, color='#d35400', zorder=3)
    h2 = ax.scatter(x + 0.12, sub.fold_perturbed_stimulated, s=30, color='#1f6fb2', marker='s', zorder=3)
    if 'fold_perturbed_baseline' in sub and sub.fold_perturbed_baseline.notna().any():
        h3 = ax.scatter(x + 0.12, sub.fold_perturbed_baseline, s=22, facecolor='none', edgecolor='#1f6fb2', marker='s', zorder=3)
    for xi, g in zip(x, sub.gene):
        if g in ('P2ry12', 'Gp6'): ax.axvspan(xi - 0.5, xi + 0.5, color='#f3e9c6', zorder=0)
    ax.set_yscale('log'); ax.set_ylim(0.13, 400); ax.set_xticks(x); ax.set_xticklabels(sub.gene, rotation=60, ha='right', fontsize=8); ax.set_title(ttl, fontsize=9.5)
    med = sub.fold_perturbed_stimulated.median()
    txt = f'creatine + perturbation, fold of vehicle:\nmedian ×{med:.2f};  P2ry12 ×{sub[sub.gene=="P2ry12"].fold_perturbed_stimulated.iloc[0]:.2f};  Gp6 ×{sub[sub.gene=="Gp6"].fold_perturbed_stimulated.iloc[0]:.2f}'
    if tag == 'Fig 6g': txt += '\n(no knock-out + vehicle arm was run)'
    ax.text(0.03, 0.97, txt, transform=ax.transAxes, fontsize=7.8, va='top')
axes[0].set_ylabel('mRNA, fold of unperturbed vehicle\n(geometric mean, n=3)'); axes[0].set_yticks([0.2, 0.5, 1, 2, 5, 10, 40]); axes[0].set_yticklabels(['0.2', '0.5', '1', '2', '5', '10', '40'])
fig.legend([h1, h2, h3], ['creatine', 'creatine + perturbation', 'perturbation alone'], ncol=3, fontsize=8.5, frameon=False, loc='upper right', bbox_to_anchor=(0.995, 0.915))
fig.suptitle('Platelet-activation gene panel in primary megakaryocytes: removing the transporter returns P2ry12 and Gp6 (shaded) to baseline;\ndeleting Stat5b leaves them 1.5–2-fold up', x=0.01, ha='left', fontsize=10.5, fontweight='bold')
fig.subplots_adjust(left=0.065, right=0.995, top=0.80, bottom=0.17, wspace=0.08); fig.savefig(f'{OUT}/fig4_mk_gene_panel.png', dpi=200); plt.close(fig)

# ------------------------------------------------------------------ Fig 4: phosphoproteomics
PH = R.PH; S = R.PHS
fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), gridspec_kw={'width_ratios': [1.35, 1]})
ax = axes[0]
onoff = PH.p.round(5) == 0.42265
ax.scatter(PH.lfc[~onoff], -np.log10(PH.p[~onoff]), s=4, color='#9aa0a6', alpha=0.6, rasterized=True, label='phosphopeptide')
ax.scatter(PH.lfc[onoff], -np.log10(PH.p[onoff]), s=4, color='#c9b37c', alpha=0.5, rasterized=True, label=f'{int(onoff.sum()):,} rows with identical P = 0.4227')
sc = PH[(PH.p < 0.05) & ((PH.lfc >= R.thr_up) | (PH.lfc <= R.thr_dn))]
ax.scatter(sc.lfc, -np.log10(sc.p), s=7, color='#1f6fb2', alpha=0.8, label=f'{len(sc)} pass the recorded screen (P<0.05, FC≥1.2 or ≤0.83)')
st = PH[PH.gene == 'Stat5b'].sort_values('p')
ax.scatter(st.lfc, -np.log10(st.p), s=70, facecolor='none', edgecolor='#c0392b', lw=1.6, zorder=5)
ax.annotate(f'Stat5b\nP = {S["stat5b_P"]:.4f}, Q = {S["stat5b_Q"]:.2f}\nrank {S["stat5b_rank_by_P"]} of {S["n_rows"]:,} by P', (st.lfc.iloc[0], -np.log10(st.p.iloc[0])), xytext=(2.1, 4.0), fontsize=8.5, color='#c0392b', arrowprops=dict(arrowstyle='-', color='#c0392b'))
ax.annotate('second Stat5b peptide\n(P = 0.47)', (st.lfc.iloc[1], -np.log10(st.p.iloc[1])), xytext=(-7.6, 1.0), fontsize=8, color='#c0392b', arrowprops=dict(arrowstyle='-', color='#c0392b'))
ax.axhline(-math.log10(0.05), color='k', lw=0.7, ls=':'); ax.set_xlabel('LOG_FOLDCHANGE (as supplied; base and direction not stated in the file)'); ax.set_ylabel('−log10 P (unpaired t, n = 3 vs 3 mice)')
ax.set_ylim(0, 4.6); ax.legend(fontsize=7.5, loc='upper left', frameon=False); ax.set_title(f'No phosphopeptide passes FDR: minimum Q = {S["min_Q"]:.2f}', loc='left')
ax = axes[1]
ax.hist(PH.p[~onoff], bins=np.linspace(0, 1, 21), color='#9aa0a6', edgecolor='white')
ax.axhline((~onoff).sum() / 20, color='k', ls='--', lw=0.8); ax.text(0.98, (~onoff).sum() / 20 * 1.03, 'uniform (null) expectation', ha='right', fontsize=8)
ax.set_xlabel(f'P value ({int((~onoff).sum()):,} rows; the {int(onoff.sum()):,} identical-P rows removed)'); ax.set_ylabel('phosphopeptides')
ax.set_title(f'P<0.05: {S["n_P_lt_0_05"]} observed vs ≈{0.05*(~onoff).sum():.0f} expected by chance', loc='left')
fig.tight_layout(); fig.savefig(f'{OUT}/fig5_phosphoproteomics.png', dpi=200); plt.close(fig)

# ------------------------------------------------------------------ Fig 5: human volunteers
fig, axes = plt.subplots(1, 4, figsize=(13.2, 3.9), gridspec_kw={'width_ratios': [0.9, 1.25, 1, 1.25]})
days = [0, 3, 7, 14]
ax = axes[0]
for i in range(11): ax.plot(days, R.CRE_H[i], color='#7f8c8d', lw=0.9, marker='o', ms=3)
ax.plot(days, R.CRE_H.mean(axis=0), color='k', lw=2.2); ax.set_xticks(days); ax.set_xlabel('day of 20 g/day creatine'); ax.set_ylabel('serum creatine (µM), fasting'); ax.set_title('Exposure (Fig 7b, n=11)', loc='left')
ax.text(0.97, 0.05, f'{R.CRE_H[:,0].mean():.0f} → {R.CRE_H[:,3].mean():.0f} µM\n11/11 increased', transform=ax.transAxes, ha='right', fontsize=8.5)
ax = axes[1]
ags = [('collagen', '#c0392b'), ('epinephrine', '#d35400'), ('arachidonic acid', '#7f8c8d'), ('ADP', '#1f6fb2')]
for k, (ag, c) in enumerate(ags):
    x = R.H7C[(ag, 'max aggregation')][:, 3]
    ax.scatter(np.full(11, k) + np.linspace(-0.18, 0.18, 11), x, s=22, color=c, zorder=3)
    g = 2 ** np.mean(np.log2(x)); ax.plot([k - 0.28, k + 0.28], [g, g], color='k', lw=1.8)
    pw = R.HUM[(R.HUM.agonist == ag) & (R.HUM.endpoint == 'max aggregation') & (R.HUM.day == 14)].iloc[0]
    ax.text(k, 15.5, f'×{g:.2f}\n{int(pw.n_increased)}/11 up\nP={pw.P_wilcoxon:.3f}', ha='center', fontsize=7.8)
ax.axhline(1, color='k', lw=0.8, ls='--'); ax.set_yscale('log'); ax.set_ylim(0.35, 40); ax.set_yticks([0.5, 1, 2, 5, 10]); ax.set_yticklabels(['0.5', '1', '2', '5', '10'])
ax.set_xticks(range(4)); ax.set_xticklabels(['collagen', 'epinephrine', 'arachidonic\nacid', 'ADP'], fontsize=8.5); ax.set_ylabel('max aggregation, day 14 / day 0'); ax.set_title('Platelet function (Fig 7c, n=11)', loc='left')
ax = axes[2]
for ep, c, lab in [('GP6/beta-actin (platelet immunoblot)', '#c0392b', 'GP6'), ('P2RY12/beta-actin (platelet immunoblot)', '#1f6fb2', 'P2RY12')]:
    Mx = R.H7E[ep]; rel = Mx / Mx[:, [0]]
    for i in range(4): ax.plot(days, rel[i], color=c, lw=0.9, alpha=0.55, marker='o', ms=3)
    ax.plot(days, np.exp(np.log(rel).mean(axis=0)), color=c, lw=2.2, label=lab)
ax.axhline(1, color='k', lw=0.8, ls='--'); ax.set_xticks(days); ax.set_xlabel('day'); ax.set_ylabel('platelet protein / β-actin, fold of day 0'); ax.legend(fontsize=8, frameon=False); ax.set_title('Platelet protein (Fig 7e, n=4)', loc='left')
ax = axes[3]
D = R.H7D
for gene, c in [('GP6', '#c0392b'), ('ADRA2A', '#d35400'), ('P2RY12', '#1f6fb2'), ('RAB4A', '#2c7a4b')]:
    sub = D[D.gene == gene]
    gmn = [1] + [float(np.exp(np.log(sub[sub.day == d].FC_recorded).mean())) for d in (3, 7, 14)]
    for v in range(1, 5):
        ax.plot(days, [1] + [float(sub[(sub.day == d) & (sub.volunteer == v)].FC_recorded.iloc[0]) for d in (3, 7, 14)], color=c, lw=0.7, alpha=0.4)
    ax.plot(days, gmn, color=c, lw=2.2, marker='o', ms=4, label=gene)
ax.axhline(1, color='k', lw=0.8, ls='--'); ax.set_yscale('log'); ax.set_yticks([0.1, 0.3, 1, 3, 10, 30]); ax.set_yticklabels(['0.1', '0.3', '1', '3', '10', '30']); ax.set_xticks(days); ax.set_xlabel('day')
ax.set_ylabel('mRNA, fold of day 0'); ax.legend(fontsize=7.5, frameon=False, ncol=2, loc='lower left'); ax.set_title('CD41+ cell mRNA (Fig 7d, n=4)', loc='left')
fig.suptitle('Healthy volunteers, single arm, 20 g/day for 14 days: the functional gain is in the collagen and epinephrine responses, not ADP; RAB4A falls', x=0.01, ha='left', fontsize=10.5, fontweight='bold')
fig.text(0.01, 0.012, 'Thin lines/points = individual volunteers; thick lines/bars = geometric means. P = Wilcoxon signed-rank test of day-14 fold-change against 1, unadjusted (Holm-adjusted values in tables/human_platelet_function_fig7c.csv).', fontsize=7.5, color='#444444')
fig.subplots_adjust(left=0.05, right=0.995, top=0.82, bottom=0.19, wspace=0.3); fig.savefig(f'{OUT}/fig6_human_volunteers.png', dpi=200); plt.close(fig)

# ------------------------------------------------------------------ Fig 6: evidence ladder by candidate
cands = ['Megakaryocyte SLC6A8\n(PRIMARY)', 'STAT5B\n(backup 1)', 'CKB\n(backup 2)', 'Platelet effectors\n(GP6 / P2RY12; aspirin\n= benchmark)', 'Tumour-cell SLC6A8\n(not supported)']
tiers = ['Lineage-specific\ngenetic loss →\nmetastasis in vivo', 'In vivo\npharmacology →\nmetastasis', 'Loss of function →\nplatelet function', 'Loss of function →\nMK gene panel', 'Mechanistic link\n(bypass / sufficiency)', 'Human\nvolunteers']
G, A, N, X = '#2e8b57', '#e0a526', '#d9d9d9', '#c0392b'
cells = [
 [(G, 'Fig 3i: increment abolished\ninteraction P=0.0009\nn=4/group, one experiment'), (N, 'no inhibitor tested'), (G, 'Fig 3d: gain lost\n(replicates, n=3)'), (G, 'Fig 3f: median residual\n×0.88'), (G, 'Supp 4e: liposomal\ncreatine restores panel'), (N, 'not measured')],
 [(N, 'KO line exists;\nno metastasis readout'), (A, 'Fig 6b: abolished, but pan-STAT5,\nsystemic; data overlap Supp 2d'), (N, 'not measured'), (A, 'Fig 6g: mRNA partly blocked\n(P2ry12 ×2.0, Gp6 ×1.5);\nno KO+vehicle arm'), (A, 'S127 mutants, ChIP: 293T, pan-phos;\nproteomics Q=0.25'), (N, 'not measured')],
 [(N, 'none'), (N, 'none'), (N, 'not measured'), (A, 'Fig 4j: si-Ckb, in vitro\nmedian residual ×1.32'), (A, 'Fig 4l: over-expression\ninduces panel (in vitro)'), (N, 'not measured')],
 [(N, 'none'), (A, 'Supp 2d: aspirin to donors only;\nno aspirin-alone arm'), (N, 'not measured'), (N, 'n/a'), (G, 'Supp 2d / Fig 7g: platelet\ntransfer carries the effect'), (A, 'Fig 7c/7e: collagen, EPI ↑;\nGP6 ↑; ADP flat; single arm')],
 [(X, 'Fig 1f: knock-down does not\nremove the effect (P=0.44)'), (N, 'none'), (N, 'n/a'), (N, 'n/a'), (N, 'n/a'), (N, 'n/a')]]
fig, ax = plt.subplots(figsize=(12.6, 5.4))
for i, rowc in enumerate(cells):
    for j, (c, t) in enumerate(rowc):
        ax.add_patch(Rectangle((j, len(cells) - 1 - i), 1, 1, facecolor=c, edgecolor='white', lw=2.5, alpha=0.9 if c != N else 1))
        ax.text(j + 0.5, len(cells) - 1 - i + 0.5, t, ha='center', va='center', fontsize=7.6, color='white' if c in (G, X) else '#222222')
ax.set_xlim(0, 6); ax.set_ylim(0, 5); ax.set_xticks(np.arange(6) + 0.5); ax.set_xticklabels(tiers, fontsize=8.5); ax.xaxis.tick_top()
ax.set_yticks(np.arange(5) + 0.5); ax.set_yticklabels(cands[::-1], fontsize=9); ax.tick_params(length=0)
for sp in ax.spines.values(): sp.set_visible(False)
handles = [Rectangle((0, 0), 1, 1, color=G), Rectangle((0, 0), 1, 1, color=A), Rectangle((0, 0), 1, 1, color=N), Rectangle((0, 0), 1, 1, color=X)]
ax.legend(handles, ['supportive in-house data', 'supportive with a material caveat', 'no in-house data', 'tested, negative'], ncol=4, loc='upper center', bbox_to_anchor=(0.5, -0.02), frameon=False, fontsize=8.5)
fig.suptitle('Evidence ladder in the CRE-MK-01 package, by candidate', x=0.01, ha='left', fontsize=11, fontweight='bold')
fig.tight_layout(rect=(0, 0, 1, 0.95)); fig.savefig(f'{OUT}/fig1_evidence_ladder.png', dpi=200); plt.close(fig)
print('figures written to', OUT)
