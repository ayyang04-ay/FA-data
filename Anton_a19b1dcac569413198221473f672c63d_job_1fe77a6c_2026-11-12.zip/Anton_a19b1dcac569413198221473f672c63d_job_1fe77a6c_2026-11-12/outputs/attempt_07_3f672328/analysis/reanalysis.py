#!/usr/bin/env python
"""
CRE-MK-01 -- independent re-derivation of every statistic cited in the proposal.

Inputs (read-only):
    /tmp/world/filesystem/CRE-MK-01_source_data.xlsx
    /tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx
Outputs:
    ../tables/*.csv   (panel-by-panel audit, qPCR panels, human data, meta-analysis, power, duplicates)
    ../figures/*.png

Run:  micromamba run -n chem python reanalysis.py
Only raw values in the workbooks are used; the Prism outputs pasted into the sheets are read
solely to compare "recorded" against "recomputed".
"""
import math, itertools, collections, re, warnings, os
import numpy as np, pandas as pd, openpyxl
from scipy import stats
from scipy.stats import studentized_range
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
warnings.filterwarnings('ignore')

SRC = '/tmp/world/filesystem/CRE-MK-01_source_data.xlsx'
PHOS = '/tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx'
OUT_T = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'tables')
OUT_F = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'figures')
os.makedirs(OUT_T, exist_ok=True); os.makedirs(OUT_F, exist_ok=True)
WB = openpyxl.load_workbook(SRC, data_only=True)

# ----------------------------------------------------------------------------- helpers
def col(sheet, c, r1, r2):
    ws = WB[sheet]
    return np.array([float(ws[f'{c}{r}'].value) for r in range(r1, r2 + 1) if ws[f'{c}{r}'].value is not None])

def row(sheet, r, c1, c2):
    ws = WB[sheet]
    a, b = openpyxl.utils.column_index_from_string(c1), openpyxl.utils.column_index_from_string(c2)
    return np.array([float(ws.cell(row=r, column=c).value) for c in range(a, b + 1) if ws.cell(row=r, column=c).value is not None])

def cell(sheet, addr):
    return WB[sheet][addr].value

def msd(a):
    a = np.asarray(a, float)
    return f'{a.mean():.4g} ± {a.std(ddof=1):.3g} (n={len(a)})'

def agree(rec, calc):
    """recorded P (possibly rounded / string) vs recomputed P"""
    if rec is None: return ''
    if isinstance(rec, str):
        if rec.startswith('>'): return 'yes' if calc > float(rec[1:]) - 1e-4 else 'NO'
        if rec.startswith('<'): return 'yes' if calc < float(rec[1:]) else 'NO'
        return '?'
    rec = float(rec)
    if rec == 0: return 'yes' if calc < 1e-10 else 'NO'
    if calc < 1e-11 and rec < 1e-11: return 'yes'         # below Prism's numeric floor
    if abs(rec - calc) <= 0.00006: return 'yes'                 # recorded values are rounded to 4 decimals
    return 'yes' if abs(rec - calc) / max(rec, calc) < 0.03 else 'NO'

def tukey(groups):
    k = len(groups); N = sum(len(g) for g in groups); dfw = N - k
    msw = sum(((np.asarray(g) - np.mean(g)) ** 2).sum() for g in groups) / dfw
    res = {}
    for i, j in itertools.combinations(range(k), 2):
        gi, gj = np.asarray(groups[i]), np.asarray(groups[j])
        diff = gi.mean() - gj.mean(); se = math.sqrt(msw / 2 * (1 / len(gi) + 1 / len(gj)))
        res[(i, j)] = (diff, float(studentized_range.sf(abs(diff) / se, k, dfw)))
    return res

def interaction(g, log=False):
    """2x2: g = [ctrl-veh, ctrl-cre, mod-veh, mod-cre]; returns dict"""
    g = [np.log(x) if log else np.asarray(x, float) for x in g]
    y = np.concatenate(g); n = [len(x) for x in g]
    a = np.array([0] * n[0] + [1] * n[1] + [0] * n[2] + [1] * n[3]); b = np.array([0] * n[0] + [0] * n[1] + [1] * n[2] + [1] * n[3])
    m = sm.OLS(y, sm.add_constant(np.column_stack([a, b, a * b]))).fit()
    ci = m.conf_int()[3]; e1 = g[1].mean() - g[0].mean(); e2 = g[3].mean() - g[2].mean()
    return dict(eff_ctrl=e1, eff_mod=e2, inter=m.params[3], lo=ci[0], hi=ci[1], p=m.pvalues[3], pct_abolished=100 * (1 - e2 / e1))

def dunnett_p(control, *samples, n_rep=25):
    """Dunnett P values; scipy integrates the multivariate t by randomised quasi-Monte Carlo, so average fixed-seed repeats for a stable answer."""
    return np.mean([stats.dunnett(*samples, control=control, rng=seed).pvalue for seed in range(n_rep)], axis=0)

def perm_interaction(g, n_perm=20000, seed=1):
    """Freedman-Lane permutation P for the 2x2 interaction on the log scale (residuals of the additive model permuted)."""
    rng = np.random.default_rng(seed)
    y = np.concatenate([np.log(x) for x in g]); n = [len(x) for x in g]
    a = np.array([0] * n[0] + [1] * n[1] + [0] * n[2] + [1] * n[3]); b = np.array([0] * n[0] + [0] * n[1] + [1] * n[2] + [1] * n[3])
    X0 = np.column_stack([np.ones_like(a), a, b]).astype(float); X1 = np.column_stack([X0, a * b]); XtXi = np.linalg.inv(X1.T @ X1)
    def tstat(yy):
        beta = XtXi @ X1.T @ yy; r = yy - X1 @ beta
        return beta[3] / math.sqrt(r @ r / (len(yy) - 4) * XtXi[3, 3])
    t_obs = tstat(y); fit0 = X0 @ np.linalg.lstsq(X0, y, rcond=None)[0]; r0 = y - fit0
    hits = sum(abs(tstat(fit0 + rng.permutation(r0))) >= abs(t_obs) for _ in range(n_perm))
    return (hits + 1) / (n_perm + 1)

def logrank(t1, t2):
    t1 = np.asarray(t1, float); t2 = np.asarray(t2, float)
    O1 = E1 = V = 0.0
    for t in np.unique(np.concatenate([t1, t2])):
        n1 = (t1 >= t).sum(); n2 = (t2 >= t).sum(); n = n1 + n2
        d1 = (t1 == t).sum(); d2 = (t2 == t).sum(); d = d1 + d2
        if n < 2: continue
        O1 += d1; E1 += d * n1 / n; V += d * (n1 / n) * (n2 / n) * (n - d) / (n - 1)
    chi2 = (O1 - E1) ** 2 / V
    return chi2, float(stats.chi2.sf(chi2, 1))

def cox_hr(t0, t1):
    """Cox PH for one binary covariate (group1 vs group0), Efron ties, all events observed."""
    t = np.concatenate([t0, t1]); x = np.concatenate([np.zeros(len(t0)), np.ones(len(t1))])
    def nll_grad_hess(b):
        ll = g = h = 0.0
        for tt in np.unique(t):
            risk = t >= tt; ev = t == tt; d = int(ev.sum())
            r = np.exp(b * x)
            S0 = r[risk].sum(); S1 = (r[risk] * x[risk]).sum(); S2 = (r[risk] * x[risk] ** 2).sum()
            D0 = r[ev].sum(); D1 = (r[ev] * x[ev]).sum(); D2 = (r[ev] * x[ev] ** 2).sum()
            ll += b * x[ev].sum()
            for l in range(d):
                f = l / d
                a0 = S0 - f * D0; a1 = S1 - f * D1; a2 = S2 - f * D2
                ll -= math.log(a0); g += -a1 / a0; h += -(a2 / a0 - (a1 / a0) ** 2)
            g += x[ev].sum()
        return ll, g, h
    b = 0.0
    for _ in range(50):
        ll, g, h = nll_grad_hess(b); step = g / h; b -= step
        if abs(step) < 1e-10: break
    se = math.sqrt(-1 / h)
    return math.exp(b), math.exp(b - 1.96 * se), math.exp(b + 1.96 * se), 2 * stats.norm.sf(abs(b / se))

AUDIT = []
def add(panel, endpoint, comparison, unit, summary, effect, rec_p, calc_p, test, robust='', note=''):
    AUDIT.append(dict(panel=panel, endpoint=endpoint, comparison=comparison, n_unit=unit, group_summaries=summary, effect=effect,
                      test=test, recorded_P=rec_p, recomputed_P=float(f'{calc_p:.4g}') if calc_p is not None else None,
                      recorded_vs_recomputed=agree(rec_p, calc_p) if calc_p is not None else '', robustness=robust, note=note))

def two(panel, endpoint, a, b, rec_p, la='vehicle', lb='creatine', unit='animal', note=''):
    t, p = stats.ttest_ind(a, b, equal_var=True); _, pw = stats.ttest_ind(a, b, equal_var=False)
    try: pm = stats.mannwhitneyu(a, b, alternative='two-sided').pvalue
    except Exception: pm = float('nan')
    add(panel, endpoint, f'{lb} vs {la}', unit, f'{la}: {msd(a)}; {lb}: {msd(b)}', f'ratio of means {np.mean(b)/np.mean(a):.2f}', rec_p, p,
        "Student t (as recorded)", f'Welch P={pw:.3g}; Mann-Whitney P={pm:.3g}', note)
    return p

def multi(panel, endpoint, groups, names, recs, unit='animal', note=''):
    """recs: list of (i, j, recorded P)"""
    res = tukey(groups)
    summ = '; '.join(f'{n}: {msd(g)}' for n, g in zip(names, groups))
    for i, j, rp in recs:
        d, p = res[(min(i, j), max(i, j))]
        add(panel, endpoint, f'{names[i]} vs {names[j]}', unit, summ, f'mean diff {groups[i].mean()-groups[j].mean():.4g}', rp, p, "one-way ANOVA + Tukey (as recorded)", '', note)
    return res

# ----------------------------------------------------------------------------- Figure 1 / Supp 1 : phenotype
s = 'Fig. 1a'; two('Fig 1a', 'lung weight (g)', col(s, 'B', 3, 8), col(s, 'C', 3, 8), cell(s, 'F4')); two('Fig 1a', 'PET SUV-BW', col(s, 'B', 12, 17), col(s, 'C', 12, 17), cell(s, 'F12'))
s = 'Fig. 1b'; two('Fig 1b', 'metastatic burden (%)', col(s, 'B', 3, 8), col(s, 'C', 3, 8), cell(s, 'F3')); two('Fig 1b', 'metastatic foci (n)', col(s, 'B', 12, 17), col(s, 'C', 12, 17), cell(s, 'F12'))
SURV = {}
for s, r1, r2, pc, tag in [('Fig. 1c', 4, 23, 'F8', 'Fig 1c'), ('Fig. 1l', 4, 41, 'F7', 'Fig 1l')]:
    ws = WB[s]
    tv = np.array([ws[f'A{r}'].value for r in range(r1, r2 + 1) if ws[f'B{r}'].value == 1], float)
    tc = np.array([ws[f'A{r}'].value for r in range(r1, r2 + 1) if ws[f'C{r}'].value == 1], float)
    chi2, p = logrank(tv, tc); hr = cox_hr(tv, tc); SURV[tag] = (tv, tc, chi2, p, hr)
    add(tag, 'survival (d)', 'creatine vs vehicle', 'animal', f'vehicle median {np.median(tv):g} d (n={len(tv)}); creatine median {np.median(tc):g} d (n={len(tc)})',
        f'Cox HR {hr[0]:.2f} (95% CI {hr[1]:.2f}-{hr[2]:.2f})', cell(s, pc), p, 'log-rank (as recorded)', f'chi2={chi2:.3f}', 'all animals reached the event; no censoring')
s = 'Fig. 1f'; nm = ['sh-scr veh', 'sh-scr cre', 'sh-Slc6a8 veh', 'sh-Slc6a8 cre']; F1F = {}
for ep, r1, r2, rr in [('lung weight (g)', 4, 9, (4, 5, 6)), ('PET SUV-BW', 13, 18, (13, 14, 15)), ('metastatic burden (%)', 22, 27, (22, 23, 24)), ('metastatic foci (n)', 31, 36, (31, 32, 33))]:
    g = [col(s, c, r1, r2) for c in 'BCDE']; F1F[ep] = g
    multi('Fig 1f', ep, g, nm, [(0, 1, cell(s, f'L{rr[0]}')), (1, 3, cell(s, f'L{rr[1]}')), (2, 3, cell(s, f'L{rr[2]}'))], note='tumour-cell Slc6a8 knock-down (melanoma)')
s = 'Fig. 1h'
for r, lab, pc in [(4, '0.25 h', 'B17'), (5, '6 h', 'E17'), (6, '12 h', 'H17'), (7, '24 h', 'K17')]:
    two('Fig 1h', f'time-course readout at {lab} (y-axis label absent from sheet)', row(s, r, 'B', 'G'), row(s, r, 'H', 'M'), cell(s, pc))
s = 'Fig. 1i'; two('Fig 1i', 'GFP+ cells per field', col(s, 'B', 4, 11), col(s, 'C', 4, 11), cell(s, 'F4'), unit='microscope field (8/group)', note='fields, not animals')
s = 'Fig. 1j'; two('Fig 1j', 'lung weight (g)', col(s, 'B', 4, 9), col(s, 'C', 4, 9), cell(s, 'F4')); two('Fig 1j', 'PET SUV-BW', col(s, 'B', 13, 18), col(s, 'C', 13, 18), cell(s, 'F13'))
s = 'Fig. 1k'; two('Fig 1k', 'metastatic burden (%)', col(s, 'B', 4, 9), col(s, 'C', 4, 9), cell(s, 'F4')); two('Fig 1k', 'metastatic foci (n)', col(s, 'B', 12, 17), col(s, 'C', 12, 17), cell(s, 'F12'))
s = 'Supplementary Fig  1a'; two('Supp 1a', 'body weight d0 (g)', row(s, 4, 'B', 'E'), row(s, 4, 'F', 'I'), cell(s, 'M11')); two('Supp 1a', 'body weight d7 (g)', row(s, 5, 'B', 'E'), row(s, 5, 'F', 'I'), cell(s, 'M25'))
s = 'Supplementary Fig  1b'; two('Supp 1b', 'food intake (g/d)', col(s, 'B', 4, 9), col(s, 'C', 4, 9), cell(s, 'F4'))
s = 'Supplementary Fig  1c'; two('Supp 1c', 'water intake (g/d)', col(s, 'B', 4, 9), col(s, 'C', 4, 9), cell(s, 'F4'))
s = 'Supplementary Fig  1d'; two('Supp 1d', 'serum creatine (uM), gavage', col(s, 'B', 4, 9), col(s, 'C', 4, 9), cell(s, 'F4'))
s = 'Supplementary Fig  1e'; two('Supp 1e', 'lung weight (g)', col(s, 'B', 4, 9), col(s, 'C', 4, 9), cell(s, 'F4')); two('Supp 1e', 'metastatic burden (%)', col(s, 'B', 13, 18), col(s, 'C', 13, 18), cell(s, 'F13')); two('Supp 1e', 'metastatic foci (n)', col(s, 'B', 22, 27), col(s, 'C', 22, 27), cell(s, 'F22'))
s = 'Supplementary Fig  1f'; two('Supp 1f', 'lung weight (g)', col(s, 'B', 4, 7), col(s, 'C', 4, 7), cell(s, 'F4')); two('Supp 1f', 'metastatic burden (%)', col(s, 'B', 12, 15), col(s, 'C', 12, 15), cell(s, 'F12')); two('Supp 1f', 'metastatic foci (n)', col(s, 'B', 20, 23), col(s, 'C', 20, 23), cell(s, 'F20'))
s = 'Supplementary Fig  1g'; two('Supp 1g', 'lung weight (g)', col(s, 'B', 3, 12), col(s, 'C', 3, 12), cell(s, 'F3')); two('Supp 1g', 'metastatic burden (%)', col(s, 'B', 15, 24), col(s, 'C', 15, 24), cell(s, 'F15')); two('Supp 1g', 'metastatic foci (n)', col(s, 'B', 28, 37), col(s, 'C', 28, 37), cell(s, 'F28'))
s = 'Supplementary Fig  1h'; two('Supp 1h', 'serum creatine (uM), 5% diet', col(s, 'C', 4, 7), col(s, 'D', 4, 7), cell(s, 'F4'), la='control diet', lb='creatine diet')
s = 'Supplementary Fig  1i'; two('Supp 1i', 'lung weight (g)', col(s, 'B', 3, 6), col(s, 'C', 3, 6), cell(s, 'F3'), la='control diet', lb='creatine diet'); two('Supp 1i', 'metastatic burden (%)', col(s, 'B', 11, 14), col(s, 'C', 11, 14), cell(s, 'F11'), la='control diet', lb='creatine diet'); two('Supp 1i', 'metastatic foci (n)', col(s, 'B', 18, 21), col(s, 'C', 18, 21), cell(s, 'F18'), la='control diet', lb='creatine diet')
s = 'Supplementary Fig  1k'; two('Supp 1k', 'lung weight (g)', col(s, 'B', 4, 13), col(s, 'C', 4, 13), cell(s, 'G4')); two('Supp 1k', 'metastatic burden (%)', col(s, 'B', 16, 25), col(s, 'C', 16, 25), cell(s, 'G16')); two('Supp 1k', 'metastatic foci (n)', col(s, 'B', 29, 38), col(s, 'C', 29, 38), cell(s, 'G29'))
s = 'Supplementary Fig  2a'; two('Supp 2a', 'tumour-cell Slc6a8 mRNA (relative)', row(s, 7, 'D', 'F'), row(s, 7, 'H', 'J'), cell(s, 'M4'), la='scrambled', lb='Slc6a8 knock-down', unit='replicate (n=3)')

# ----------------------------------------------------------------------------- Figure 2 / Supp 2-3 : platelets
s = 'Fig. 2a'
for ep, r1, pc in [('platelet count (10^9/L)', 4, 'F4'), ('plateletcrit (%)', 12, 'F12'), ('PDW (fl)', 19, 'F19'), ('MPV (fl)', 27, 'F27')]:
    two('Fig 2a', ep, col(s, 'B', r1, r1 + 2), col(s, 'C', r1, r1 + 2), cell(s, pc))
s = 'Fig. 2b'
for r, ag, pc in [(4, 'ADP', 'B18'), (5, 'collagen', 'B32'), (6, 'thrombin', 'B45')]:
    two('Fig 2b', f'platelet aggregation (%), {ag}', row(s, r, 'B', 'D'), row(s, r, 'E', 'G'), cell(s, pc), unit='replicate (n=3; SD 1-5 points)', note='n=3 vs 3 cannot reach P<0.05 by a rank test')
s = 'Fig. 2c'; two('Fig 2c', 'alpha-granules (n)', col(s, 'B', 4, 11), col(s, 'C', 4, 11), cell(s, 'F5'), unit='microscope field (8/group)', note='fields, not animals')
s = 'Fig. 2d'
for ep, r1, pc in [('TEG R (min)', 4, 'F4'), ('TEG K (min)', 12, 'F12'), ('TEG alpha (deg)', 20, 'F20'), ('TEG MA (mm)', 28, 'F28')]:
    two('Fig 2d', ep, col(s, 'B', r1, r1 + 4), col(s, 'C', r1, r1 + 4), cell(s, pc), note='4 TEG parameters, no multiplicity adjustment')
s = 'Fig. 2j'; two('Fig 2j', 'PKH-positive area (%)', col(s, 'B', 4, 11), col(s, 'C', 4, 11), cell(s, 'F4'), unit='microscope field (8/group)', note='fields, not animals')
s = 'Supplementary Fig  2d'; nm = ['vehicle-donor PLT', 'creatine-donor PLT', 'creatine+aspirin-donor PLT']; S2D = {}
for ep, r1, r2, rr in [('metastatic burden (%)', 5, 10, (5, 6, 7)), ('metastatic foci (n)', 14, 19, (14, 15, 16))]:
    g = [col(s, c, r1, r2) for c in 'CDE']; S2D[ep] = g
    multi('Supp 2d', ep, g, nm, [(0, 1, cell(s, f'L{rr[0]}')), (0, 2, cell(s, f'L{rr[1]}')), (1, 2, cell(s, f'L{rr[2]}'))], note='platelet transfer; rows 4-6 of vehicle and creatine arms are identical to Fig 6b rows 2-4')
s = 'Supplementary Fig  3a'
for ep, r1, pc in [('WBC', 4, 'F4'), ('lymphocytes', 12, 'F12'), ('monocytes', 20, 'F20'), ('RBC', 28, 'F28')]:
    two('Supp 3a', ep, col(s, 'B', r1, r1 + 4), col(s, 'C', r1, r1 + 4), cell(s, pc))

# ----------------------------------------------------------------------------- Figure 3 / Supp 4 : MK Slc6a8 KO
s = 'Fig. 3b'
two('Fig 3b', 'serum creatine (uM), Pf4-Cre;Slc6a8+/+', row(s, 4, 'B', 'F'), row(s, 4, 'G', 'K'), cell(s, 'B17')); two('Fig 3b', 'serum creatine (uM), Pf4-Cre;Slc6a8fl/fl', row(s, 5, 'B', 'F'), row(s, 5, 'G', 'K'), cell(s, 'B31'))
s = 'Fig. 3c'
F3C = [row(s, 4, 'B', 'D'), row(s, 4, 'E', 'G'), row(s, 5, 'B', 'D'), row(s, 5, 'E', 'G')]
two('Fig 3c', 'MK intracellular creatine (umol/g), Pf4-Cre;Slc6a8+/+', F3C[0], F3C[1], cell(s, 'B15')); two('Fig 3c', 'MK intracellular creatine (umol/g), Pf4-Cre;Slc6a8fl/fl', F3C[2], F3C[3], cell(s, 'B30'))
two('Fig 3c', 'MK intracellular creatine on creatine: KO vs control (not tested in sheet)', F3C[1], F3C[3], None, la='control+creatine', lb='KO+creatine')
s = 'Fig. 3d'; nm = ['ctrl veh', 'ctrl cre', 'KO veh', 'KO cre']; F3D = {}
for r, ag, rr in [(4, 'ADP', (4, 5)), (5, 'collagen', (10, 11)), (6, 'thrombin', (15, 16))]:
    g = [row(s, r, 'B', 'D'), row(s, r, 'E', 'G'), row(s, r, 'H', 'J'), row(s, r, 'K', 'M')]; F3D[ag] = g
    multi('Fig 3d', f'platelet aggregation (%), {ag}', g, nm, [(0, 1, cell(s, f'T{rr[0]}')), (2, 3, cell(s, f'T{rr[1]}'))], unit='replicate (n=3; SD ~1 point)')
s = 'Fig. 3i'; F3I = {}
for ep, r1, r2, rr in [('lung weight (g)', 3, 6, (3, 4, 5)), ('metastatic burden (%)', 10, 13, (10, 11, 12)), ('metastatic foci (n)', 17, 20, (17, 18, 19))]:
    g = [col(s, c, r1, r2) for c in 'BCDE']; F3I[ep] = g
    multi('Fig 3i', ep, g, nm, [(0, 1, cell(s, f'L{rr[0]}')), (1, 3, cell(s, f'L{rr[1]}')), (2, 3, cell(s, f'L{rr[2]}'))], note='megakaryocyte-lineage Slc6a8 knock-out; n=4/group')
s = 'Supplementary Fig  4b'; g = [col(s, c, 5, 7) for c in 'CDEF']
multi('Supp 4b', 'platelet count (10^9/L)', g, nm, [(0, 1, cell(s, 'M5')), (0, 2, cell(s, 'M6')), (1, 3, cell(s, 'M7')), (2, 3, cell(s, 'M8'))])
s = 'Supplementary Fig  4c'; S4C = [col(s, c, 6, 13) for c in 'CDEF']
multi('Supp 4c', 'alpha-granules (n)', S4C, nm, [(0, 1, cell(s, 'N7')), (1, 3, cell(s, 'N8')), (2, 3, cell(s, 'N9'))], unit='microscope field (8/group)', note='fields, not animals')

# ----------------------------------------------------------------------------- Figure 4 / Supp 5 : creatine, PCr, CKB
s = 'Fig. 4a'; two('Fig 4a', 'creatine (umol/g), MKs', col(s, 'B', 4, 6), col(s, 'C', 4, 6), cell(s, 'H10')); two('Fig 4a', 'creatine (umol/g), brain', col(s, 'D', 4, 6), col(s, 'E', 4, 6), cell(s, 'H24'))
s = 'Fig. 4c'; two('Fig 4c', 'phosphocreatine (ng/ug), MKs', col(s, 'B', 4, 6), col(s, 'C', 4, 6), cell(s, 'H10')); two('Fig 4c', 'phosphocreatine (ng/ug), brain', col(s, 'D', 4, 6), col(s, 'E', 4, 6), cell(s, 'H24'))
s = 'Fig. 4d'; two('Fig 4d', "MKs in vitro, sheet label 'Creatinine (umol/g)'", col(s, 'C', 4, 6), col(s, 'D', 4, 6), cell(s, 'G10'), la='control', note="label reads creatinine; the conventions list only a creatine assay - confirm analyte")
s = 'Fig. 4e'; two('Fig 4e', 'Ckb mRNA in MKs (relative)', row(s, 8, 'E', 'G'), row(s, 8, 'I', 'K'), cell(s, 'O5'), unit='replicate (n=3)')
s = 'Fig. 4f'; two('Fig 4f', 'phosphocreatine (ng/ug), MKs in vitro', col(s, 'B', 4, 6), col(s, 'C', 4, 6), cell(s, 'F4'), la='control')
s = 'Supplementary Fig  5a'; two('Supp 5a', 'Gatm mRNA in MKs', row(s, 6, 'C', 'E'), row(s, 6, 'G', 'I'), cell(s, 'N10')); two('Supp 5a', 'Gamt mRNA in MKs', row(s, 9, 'C', 'E'), row(s, 9, 'G', 'I'), cell(s, 'N24'))
s = 'Supplementary Fig  5c'; two('Supp 5c', 'MK creatine (umol/g)', col(s, 'B', 5, 7), col(s, 'C', 5, 7), cell(s, 'F5'), la='CKB-EV', lb='CKB-OE'); two('Supp 5c', 'MK phosphocreatine (ng/ug)', col(s, 'B', 13, 15), col(s, 'C', 13, 15), cell(s, 'F13'), la='CKB-EV', lb='CKB-OE')

# ----------------------------------------------------------------------------- Figure 5 / Supp 6 : STAT5B phosphorylation, ChIP
MUT = ['WT', 'S127A', '3A', 'S127D']; F5 = {}
for s, tag, vc, rv, rc in [('Fig. 5e', 'Fig 5e', 'R', (10, 11, 12, 13), (22, 23, 24)), ('Fig. 5f', 'Fig 5f', 'Q', (9, 10, 11, 12), (22, 23, 24))]:
    gv = [col(s, c, 4, 6) for c in 'NOPQ']; gc = [col(s, c, 17, 19) for c in 'NOPQ']; F5[tag] = (gv, gc)
    multi(tag, 'pan-phospho/FLAG, STAT5B-FLAG in 293T, vehicle', gv, MUT, [(0, 2, cell(s, f'{vc}{rv[0]}')), (0, 3, cell(s, f'{vc}{rv[1]}')), (1, 3, cell(s, f'{vc}{rv[2]}')), (2, 3, cell(s, f'{vc}{rv[3]}'))], unit='blot (n=3)')
    multi(tag, 'pan-phospho/FLAG, STAT5B-FLAG in 293T, creatine', gc, MUT, [(0, 1, cell(s, f'{vc}{rc[0]}')), (0, 3, cell(s, f'{vc}{rc[1]}')), (1, 2, cell(s, f'{vc}{rc[2]}'))], unit='blot (n=3)')
    for i, m in enumerate(MUT):
        two(tag, f'pan-phospho/FLAG, {m}: creatine vs vehicle (not tested in sheet; separate membranes)', gv[i], gc[i], None, unit='blot (n=3)')

def sidak(panel, sheet, label, rows_, a1, a2, b1, b2, recs):
    data = [(row(sheet, r, a1, a2), row(sheet, r, b1, b2)) for r in rows_]
    sse = sum(((a - a.mean()) ** 2).sum() + ((b - b.mean()) ** 2).sum() for a, b in data); dfe = sum(len(a) + len(b) - 2 for a, b in data); mse = sse / dfe; m = len(data)
    out = []
    for (a, b), lab, rp in zip(data, ['exon', '-2 kb', '-1 kb', '-0.2 kb'], recs):
        diff = a.mean() - b.mean(); se = math.sqrt(mse * (1 / len(a) + 1 / len(b))); p = 2 * stats.t.sf(abs(diff / se), dfe); padj = 1 - (1 - p) ** m
        add(panel, f'ChIP-qPCR % input, {label} {lab}', 'creatine vs vehicle', 'replicate (n=3)', f'vehicle: {msd(a)}; creatine: {msd(b)}', f'ratio of means {b.mean()/a.mean():.2f}', rp, padj, "two-way ANOVA + Sidak (as recorded)", '', 'no IgG / knock-out ChIP control in package')
        out.append((lab, a.mean(), b.mean(), padj))
    return out
s = 'Fig. 5j'
CHIP = {'P2ry12': sidak('Fig 5j', s, 'P2ry12', [5, 6, 7, 8], 'B', 'D', 'E', 'G', [cell(s, f'N{r}') for r in (7, 8, 9, 10)]),
        'Gp6': sidak('Fig 5j', s, 'Gp6', [15, 16, 17, 18], 'B', 'D', 'E', 'G', [cell(s, f'N{r}') for r in (17, 18, 19, 20)])}
s = 'Supplementary Fig  6i'
CHIP['Rab4a'] = sidak('Supp 6i', s, 'Rab4a', [7, 8, 9, 10], 'C', 'E', 'F', 'H', [cell(s, f'O{r}') for r in (10, 11, 12, 13)])

# ----------------------------------------------------------------------------- Figure 6 / Supp 7 : STAT5 inhibitor, Stat5b KO
s = 'Fig. 6b'; nm = ['vehicle', 'creatine', 'vehicle+STAT5-IN-1', 'creatine+STAT5-IN-1']; F6B = {}
for ep, r1, r2, rr in [('metastatic burden (%)', 4, 8, (4, 5, 6, 7)), ('metastatic foci (n)', 13, 17, (13, 14, 15, 16))]:
    g = [col(s, c, r1, r2) for c in 'BCDE']; F6B[ep] = g
    multi('Fig 6b', ep, g, nm, [(0, 1, cell(s, f'L{rr[0]}')), (0, 2, cell(s, f'L{rr[1]}')), (1, 3, cell(s, f'L{rr[2]}')), (2, 3, cell(s, f'L{rr[3]}'))], note='pan-STAT5 inhibitor, systemic; rows 2-4 of vehicle and creatine arms are identical to Supp 2d rows 4-6')
s = 'Fig. 6e'; F6E = [col(s, c, 5, 7) for c in 'CDE']
multi('Fig 6e', 'MK intracellular creatine (umol/g)', F6E, ['WT veh', 'WT cre', 'Stat5b-KO cre'], [(0, 1, cell(s, 'L5')), (0, 2, cell(s, 'L6')), (1, 2, cell(s, 'L7'))], note='no KO+vehicle arm; control labelled WT (not iCre)')
s = 'Supplementary Fig  7a'
for ep, r1 in [('platelet count', 4), ('plateletcrit', 11), ('MPV', 17), ('PDW', 23)]:
    g = [col(s, c, r1, r1 + 2) for c in 'BCDE']
    multi('Supp 7a', ep, g, nm, [(0, 1, cell(s, f'L{r1}')), (0, 2, cell(s, f'L{r1+1}')), (0, 3, cell(s, f'L{r1+2}'))])
s = 'Supplementary Fig  7b'
for ep, r1 in [('platelet count', 4), ('plateletcrit', 10), ('MPV', 16), ('PDW', 22)]:
    g = [col(s, c, r1, r1 + 2) for c in 'BCD']
    multi('Supp 7b', ep, g, ['WT veh', 'WT cre', 'Stat5b-KO cre'], [(0, 1, cell(s, f'K{r1}')), (0, 2, cell(s, f'K{r1+1}')), (1, 2, cell(s, f'K{r1+2}'))], note='no KO+vehicle arm')

# ----------------------------------------------------------------------------- Figure 7 / Supp 8 : human volunteers
s = 'Fig. 7b'; CRE_H = np.column_stack([col(s, c, 4, 14) for c in 'BCDE'])
res = tukey([CRE_H[:, i] for i in range(4)])
for j, d, pc in [(1, 3, 'L5'), (2, 7, 'L6'), (3, 14, 'L7')]:
    pp = stats.ttest_rel(CRE_H[:, j], CRE_H[:, 0]).pvalue
    add('Fig 7b', 'serum creatine (uM), volunteers', f'day {d} vs day 0', 'volunteer (n=11)', f'd0: {msd(CRE_H[:,0])}; d{d}: {msd(CRE_H[:,j])}', f'ratio of means {CRE_H[:,j].mean()/CRE_H[:,0].mean():.2f}; increased in {(CRE_H[:,j]>CRE_H[:,0]).sum()}/11',
        cell(s, pc), res[(0, j)][1], 'one-way ANOVA + Tukey, unpaired (as recorded)', f'paired t P={pp:.2g}; Wilcoxon P={stats.wilcoxon(CRE_H[:,j], CRE_H[:,0]).pvalue:.2g}', 'within-subject design analysed as unpaired in the sheet')
s = 'Fig. 7c'
blocks = [('collagen', 'max aggregation', 4, (4, 5, 6)), ('collagen', 'avg aggregation', 18, (18, 19, 20)), ('collagen', 'adhesion', 32, (32, 33, 34)),
          ('epinephrine', 'max aggregation', 46, (47, 48, 49)), ('epinephrine', 'avg aggregation', 60, (61, 62, 63)), ('epinephrine', 'adhesion', 74, (75, 76, 77)),
          ('arachidonic acid', 'max aggregation', 88, (88, 89, 90)), ('arachidonic acid', 'avg aggregation', 102, (103, 104, 105)), ('arachidonic acid', 'adhesion', 116, (117, 118, 119)),
          ('ADP', 'max aggregation', 130, (131, 132, 133)), ('ADP', 'avg aggregation', 144, (145, 146, 147)), ('ADP', 'adhesion', 157, (159, 160, 161))]
H7C = {}; hrows = []
for ag, ep, r1, rr in blocks:
    M = np.column_stack([col(s, c, r1, r1 + 10) for c in 'BCDE']); H7C[(ag, ep)] = M
    pd_ = dunnett_p(M[:, 0], M[:, 1], M[:, 2], M[:, 3])
    for j, d in [(1, 3), (2, 7), (3, 14)]:
        x = M[:, j]; ok = x > 0; lx = np.log2(x[ok]); n = int(ok.sum()); m_, sd_ = lx.mean(), lx.std(ddof=1); tc = stats.t.ppf(0.975, n - 1)
        pt = stats.ttest_1samp(lx, 0).pvalue; pw = stats.wilcoxon(x - 1).pvalue
        hrows.append(dict(agonist=ag, endpoint=ep, day=d, n=n, geo_mean_FC=2 ** m_, ci_lo=2 ** (m_ - tc * sd_ / math.sqrt(n)), ci_hi=2 ** (m_ + tc * sd_ / math.sqrt(n)), sd_log2=sd_, median_FC=np.median(x),
                          n_increased=int((x > 1).sum()), P_recorded_Dunnett=cell(s, f'L{rr[j-1]}'), P_recomputed_Dunnett=pd_[j - 1], P_one_sample_t_log2=pt, P_wilcoxon=pw))
        add('Fig 7c', f'platelet {ep}, {ag} (fold of own baseline)', f'day {d} vs day 0', 'volunteer (n=11)', f'geometric mean FC {2**m_:.2f} (95% CI {2**(m_-tc*sd_/math.sqrt(n)):.2f}-{2**(m_+tc*sd_/math.sqrt(n)):.2f}); increased in {(x>1).sum()}/11',
            f'geo-mean FC {2**m_:.2f}', cell(s, f'L{rr[j-1]}'), pd_[j - 1], "Dunnett vs day-0 column of 1s (as recorded)", f'one-sample t on log2 FC P={pt:.3g}; Wilcoxon signed-rank P={pw:.3g}', 'baseline fixed at 1 has zero variance; paired/one-sample tests are the appropriate check')
HUM = pd.DataFrame(hrows)
d14 = HUM[HUM.day == 14].copy(); d14['Holm_wilcoxon'] = multipletests(d14.P_wilcoxon, method='holm')[1]; d14['BH_wilcoxon'] = multipletests(d14.P_wilcoxon, method='fdr_bh')[1]
HUM = HUM.merge(d14[['agonist', 'endpoint', 'day', 'Holm_wilcoxon', 'BH_wilcoxon']], how='left', on=['agonist', 'endpoint', 'day'])
HUM.to_csv(f'{OUT_T}/human_platelet_function_fig7c.csv', index=False)
s = 'Fig. 7e'; H7E = {}
for ep, r1, rr in [('GP6/beta-actin (platelet immunoblot)', 4, (4, 5, 6)), ('P2RY12/beta-actin (platelet immunoblot)', 12, (12, 13, 14))]:
    M = np.column_stack([col(s, c, r1, r1 + 3) for c in 'BCDE']); H7E[ep] = M; res = tukey([M[:, i] for i in range(4)])
    for j, d in [(1, 3), (2, 7), (3, 14)]:
        pp = stats.ttest_rel(M[:, j], M[:, 0]).pvalue
        add('Fig 7e', ep, f'day {d} vs day 0', 'volunteer (n=4 of 11)', f'd0: {msd(M[:,0])}; d{d}: {msd(M[:,j])}', f'ratio of means {M[:,j].mean()/M[:,0].mean():.2f}; per-volunteer ratios {np.round(M[:,j]/M[:,0],2).tolist()}',
            cell(s, f'L{rr[j-1]}'), res[(0, j)][1], 'one-way ANOVA + Tukey, unpaired (as recorded)', f'paired t P={pp:.3g}', 'protein densitometry, not transcript; loading control on a separate gel')
s = 'Fig. 7g'
two('Fig 7g', 'lung weight (g)', col(s, 'B', 4, 8), col(s, 'C', 4, 8), cell(s, 'F4'), la='day-0 donor PLT', lb='day-7 donor PLT', unit='recipient mouse')
two('Fig 7g', 'metastatic burden (%)', col(s, 'B', 12, 16), col(s, 'C', 12, 16), cell(s, 'F12'), la='day-0 donor PLT', lb='day-7 donor PLT', unit='recipient mouse')
two('Fig 7g', 'metastatic foci (n)', col(s, 'B', 19, 23), col(s, 'C', 19, 23), cell(s, 'F19'), la='day-0 donor PLT', lb='day-7 donor PLT', unit='recipient mouse')
s = 'Supplementary Fig  8a'; a, b = col(s, 'C', 4, 14), col(s, 'D', 4, 14)
add('Supp 8a', 'BMI (kg/m2), volunteers', 'day 14 vs day 0', 'volunteer (n=11)', f'd0: {msd(a)}; d14: {msd(b)}', f'mean change {np.mean(b-a):+.2f}', cell(s, 'G5'), stats.ttest_ind(a, b).pvalue, 'Student t, unpaired (as recorded)', f'paired t P={stats.ttest_rel(a,b).pvalue:.3g}')
s = 'Supplementary Fig  8b'
for ep, r1 in [('platelet count (10^9/L)', 4), ('plateletcrit (%)', 19), ('MPV (fl)', 33), ('PDW (fl)', 48)]:
    M = np.column_stack([col(s, c, r1, r1 + 10) for c in 'BCDE']); pd_ = dunnett_p(M[:, 0], M[:, 1], M[:, 2], M[:, 3])
    for j, d in [(1, 3), (2, 7), (3, 14)]:
        add('Supp 8b', f'{ep}, volunteers', f'day {d} vs day 0', 'volunteer (n=11)', f'd0: {msd(M[:,0])}; d{d}: {msd(M[:,j])}', f'mean change {np.mean(M[:,j]-M[:,0]):+.3g}', cell(s, f'L{r1+j-1}'), pd_[j - 1], 'Dunnett, unpaired (as recorded)', f'paired t P={stats.ttest_rel(M[:,j],M[:,0]).pvalue:.3g}')
s = 'Supplementary Fig  8c'; g = [row(s, 9, 'E', 'G'), row(s, 9, 'I', 'K'), row(s, 9, 'M', 'O')]
multi('Supp 8c', 'CD41 mRNA (relative)', g, ['circulating CD41+ cells', 'monocytes', 'MEG-01'], [(0, 1, cell(s, 'I15'))], unit='replicate (n=3)')

AUD = pd.DataFrame(AUDIT)
AUD.to_csv(f'{OUT_T}/panel_audit_recorded_vs_recomputed.csv', index=False)

# ----------------------------------------------------------------------------- qPCR panels (11-gene activation panel in primary MKs)
def parse_qpcr(sheet, group_row):
    ws = WB[sheet]; groups = {c: str(ws.cell(row=group_row, column=c).value) for c in range(1, ws.max_column + 1) if ws.cell(row=group_row, column=c).value is not None}
    out = collections.OrderedDict(); gene = None
    for r in range(group_row + 1, ws.max_row + 1):
        a = ws.cell(row=r, column=1).value
        if isinstance(a, str) and not a.startswith('Graphs'): gene = a.strip(); out[gene] = collections.OrderedDict()
        if gene is None: continue
        for c in range(1, ws.max_column + 1):
            v = ws.cell(row=r, column=c).value
            if isinstance(v, str) and (v.startswith('After normalization') or v.startswith('2^(')):
                out[gene][groups.get(c + 1)] = np.array([float(ws.cell(row=r, column=c + k).value) for k in (1, 2, 3)])
    return out
def gm(x): return float(np.exp(np.mean(np.log(x))))
def plog(a, b): return float(stats.ttest_ind(np.log2(a), np.log2(b)).pvalue)
QP = []
PANELS = [('Fig 2f', 'Fig. 2f', 3, 'MKs from vehicle- vs creatine-dosed mice', 'Vehicle', 'Creatine', None, None),
          ('Fig 3f', 'Fig. 3f', 7, 'MK-lineage Slc6a8 knock-out', 'PF4 cre; Slc6a8+/+-vehicle', 'PF4 cre; Slc6a8+/+-creatine', 'PF4 cre; Slc6a8flox/flox-vehicle', 'PF4 cre; Slc6a8flox/flox-creatine'),
          ('Fig 4h', 'Fig. 4h', 6, 'MKs in vitro: creatine vs phosphocreatine', 'Control', 'Creatine', None, 'Phosphocreatine'),
          ('Fig 4j', 'Fig. 4j', 7, 'MKs in vitro: si-Ckb', 'Control+si-scrambled', 'Creatine+si-scrambled', 'Control+si-Ckb', 'Creatine+si-Ckb'),
          ('Fig 4l', 'Fig. 4l', 5, 'MKs in vitro: CKB over-expression', 'CKB-EV', 'CKB-OE', None, None),
          ('Fig 6a', 'Fig.6a', 6, 'MKs: STAT5-IN-1', 'Vehicle', 'Creatine', 'Vehicle+stat5 inhibitor', 'Creatine+stat5 inhibitor'),
          ('Fig 6g', 'Fig. 6g', 4, 'MK-lineage Stat5b knock-out (no KO+vehicle arm)', 'WT-Vehicle', 'WT-Creatine', None, 'PF4-cre;Stat5bflox/flox-creatine'),
          ('Supp 3c', 'Supplementary Fig  3c', 4, 'MK maturation genes', 'Vehicle', 'Creatine', None, None),
          ('Supp 4e', 'Supplementary Fig  4e', 7, 'Slc6a8-KO MKs in vitro: free vs liposomal creatine', 'Control', 'Creatine', None, 'Creatine@liposome')]
QD = {}
for tag, sheet, grow, desc, c0, c1, p0, p1 in PANELS:
    d = parse_qpcr(sheet, grow); QD[tag] = d
    for gene, gd in d.items():
        if not gd: continue
        base = gm(gd[c0]); rec = dict(panel=tag, design=desc, gene=gene, control_arm=c0, stimulated_arm=c1, fold_stimulated=gm(gd[c1]) / base, P_stimulated_vs_control_log2_t=plog(gd[c0], gd[c1]))
        if p0: rec.update(perturbed_baseline_arm=p0, fold_perturbed_baseline=gm(gd[p0]) / base, P_perturbed_baseline_vs_control=plog(gd[c0], gd[p0]))
        if p1:
            rec.update(perturbed_stimulated_arm=p1, fold_perturbed_stimulated=gm(gd[p1]) / base, P_perturbed_stim_vs_stim=plog(gd[c1], gd[p1]), P_perturbed_stim_vs_control=plog(gd[c0], gd[p1]))
            if rec['fold_stimulated'] != 1:
                rec['pct_of_log_induction_abolished'] = 100 * (1 - math.log(rec['fold_perturbed_stimulated']) / math.log(rec['fold_stimulated']))
        if p0 and p1:
            I = interaction([gd[c0], gd[c1], gd[p0], gd[p1]], log=True); rec['P_interaction_log2'] = I['p']
        QP.append(rec)
QPD = pd.DataFrame(QP); QPD.to_csv(f'{OUT_T}/mk_gene_panel_qpcr.csv', index=False)

# consistency of the sheets' fold-change cells with their own dCt rows (mouse / cell qPCR sheets)
def dct_check(sheet):
    ws = WB[sheet]; rows_ = []
    for r in range(1, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            v = ws.cell(row=r, column=c).value
            if not isinstance(v, str): continue
            m = re.match(r'^\(ΔCT(\d)-ΔCT1\)$', v.strip())
            if m:                                              # treated group: 2^(dCt_k - dCt_1), replicate by replicate
                k = m.group(1); r1 = rk = None
                for rr in range(r - 1, max(r - 6, 0), -1):
                    lab = ws.cell(row=rr, column=c).value
                    if lab == 'ΔCT1' and r1 is None: r1 = rr
                    if lab == f'ΔCT{k}' and rk is None: rk = rr
                for j in (1, 2, 3):
                    a, b, f = ws.cell(row=r1, column=c + j).value, ws.cell(row=rk, column=c + j).value, ws.cell(row=r + 1, column=c + j).value
                    rows_.append(dict(sheet=sheet, cell=ws.cell(row=r + 1, column=c + j).coordinate, recorded=f, recomputed=2 ** (b - a)))
            if v.strip() == '2^ΔCT1':                          # control group: 2^dCt_1 divided by the group mean
                d1 = None
                for rr in range(r - 1, max(r - 4, 0), -1):
                    for cc in range(1, ws.max_column + 1):
                        if ws.cell(row=rr, column=cc).value == 'ΔCT1': d1 = [ws.cell(row=rr, column=cc + j).value for j in (1, 2, 3)]; break
                    if d1: break
                lin = [2 ** x for x in d1]; mu = sum(lin) / 3
                for j in range(3):
                    rows_.append(dict(sheet=sheet, cell=ws.cell(row=r + 1, column=c + 1 + j).coordinate, recorded=ws.cell(row=r + 1, column=c + 1 + j).value, recomputed=lin[j] / mu))
    return rows_
DCT = pd.DataFrame(sum([dct_check(sh) for sh in ['Fig. 2f', 'Fig. 3f', 'Fig. 4e', 'Fig. 4h', 'Fig. 4j', 'Fig. 4l', 'Fig.6a', 'Fig. 6g', 'Supplementary Fig  2a', 'Supplementary Fig  3c', 'Supplementary Fig  4e', 'Supplementary Fig  8c']], []))
DCT['rel_diff'] = (DCT.recorded / DCT.recomputed - 1).abs()
DCT.to_csv(f'{OUT_T}/qpcr_fold_change_vs_dCt_check.csv', index=False)

# human CD41+ cell transcripts (Fig 7d): recompute from the triplicate dCt rows
s = 'Fig. 7d'; ws = WB[s]; H7D = []
for gene, c0, r0 in [('ITGA2B', 'C', 7), ('P2RY12', 'I', 7), ('GP6', 'C', 26), ('GPIBA', 'I', 26), ('F2R', 'C', 45), ('ADRA2A', 'I', 45), ('FCGR2A', 'C', 64), ('RUNX1', 'I', 64), ('RAB4A', 'C', 83), ('RAB27B', 'I', 83), ('PITPNB', 'C', 101)]:
    ci = openpyxl.utils.column_index_from_string(c0)
    raw = {d: np.array([[ws.cell(row=r0 + 3 * k + i, column=ci + v).value for v in range(4)] for i in range(3)], float) for k, d in enumerate([0, 3, 7, 14])}
    recd = {d: np.array([ws.cell(row=r0 + 12 + k, column=ci + v).value for v in range(4)], float) for k, d in enumerate([0, 3, 7, 14])}
    for d in (3, 7, 14):
        calc = (2 ** raw[d]).mean(axis=0) / (2 ** raw[0]).mean(axis=0)      # the sheet's own convention: mean of 2^dCt over triplicates, relative to day 0
        for v in range(4):
            H7D.append(dict(gene=gene, day=d, volunteer=v + 1, FC_recorded=recd[d][v], FC_recomputed_from_raw=calc[v], reproduces=bool(abs(calc[v] / recd[d][v] - 1) < 0.02)))
H7D = pd.DataFrame(H7D); H7D.to_csv(f'{OUT_T}/human_cd41_transcripts_fig7d.csv', index=False)
H7Dsum = H7D.groupby(['gene', 'day']).apply(lambda g: pd.Series(dict(geo_mean_FC=gm(g.FC_recorded), min_FC=g.FC_recorded.min(), max_FC=g.FC_recorded.max(), n_up_of_4=int((g.FC_recorded > 1).sum()),
                                                                  P_one_sample_t_log2=stats.ttest_1samp(np.log2(g.FC_recorded), 0).pvalue, n_not_reproducible=int((~g.reproduces).sum())))).reset_index()
H7Dsum.to_csv(f'{OUT_T}/human_cd41_transcripts_fig7d_summary.csv', index=False)

# ----------------------------------------------------------------------------- interactions (does the perturbation remove the creatine effect?)
INT = []
def addint(tag, ep, g, unit='animal'):
    for lg in (False, True):
        I = interaction(g, log=lg)
        INT.append(dict(panel=tag, endpoint=ep, scale='log (ratio)' if lg else 'linear', n_unit=unit,
                        creatine_effect_control_arm=math.exp(I['eff_ctrl']) if lg else I['eff_ctrl'], creatine_effect_perturbed_arm=math.exp(I['eff_mod']) if lg else I['eff_mod'],
                        interaction=math.exp(I['inter']) if lg else I['inter'], ci_lo=math.exp(I['lo']) if lg else I['lo'], ci_hi=math.exp(I['hi']) if lg else I['hi'], P_interaction=I['p'], pct_of_creatine_effect_abolished=I['pct_abolished']))
for ep, g in F1F.items(): addint('Fig 1f: tumour-cell sh-Slc6a8', ep, g)
for ep, g in F3I.items(): addint('Fig 3i: MK-lineage Slc6a8 KO', ep, g)
addint('Fig 3c: MK-lineage Slc6a8 KO', 'MK intracellular creatine', F3C)
for ag, g in F3D.items(): addint('Fig 3d: MK-lineage Slc6a8 KO', f'aggregation, {ag}', g, unit='replicate')
addint('Supp 4c: MK-lineage Slc6a8 KO', 'alpha-granules', S4C, unit='field')
for ep, g in F6B.items(): addint('Fig 6b: STAT5-IN-1', ep, g)
for ep, g in F6B.items():   # sensitivity: remove the three vehicle and three creatine animals that also appear in Supp 2d
    addint('Fig 6b: STAT5-IN-1, excluding the 3+3 animals duplicated in Supp 2d', ep, [np.delete(g[0], [1, 2, 3]), np.delete(g[1], [1, 2, 3]), g[2], g[3]])
INTD = pd.DataFrame(INT)
PERM = {('Fig 1f: tumour-cell sh-Slc6a8', ep): perm_interaction(g) for ep, g in F1F.items() if ep.startswith('metastatic')}
PERM.update({('Fig 3i: MK-lineage Slc6a8 KO', ep): perm_interaction(g) for ep, g in F3I.items() if ep.startswith('metastatic')})
PERM.update({('Fig 6b: STAT5-IN-1', ep): perm_interaction(g) for ep, g in F6B.items()})
INTD['P_interaction_permutation'] = [PERM.get((r.panel, r.endpoint)) if r.scale == 'log (ratio)' else None for r in INTD.itertuples()]
INTD.to_csv(f'{OUT_T}/interaction_tests.csv', index=False)

# ----------------------------------------------------------------------------- meta-analysis of the creatine effect, and planning SD
META = []
def addm(name, kind, bv, bc, fv, fc, note=''):
    rec = dict(experiment=name, kind=kind, n_ctrl=len(bv), n_creatine=len(bc), note=note)
    for lab, v, c in [('burden', bv, bc), ('foci', fv, fc)]:
        lv, lc = np.log(v), np.log(c); l = lc.mean() - lv.mean(); a_, b_ = lv.var(ddof=1) / len(lv), lc.var(ddof=1) / len(lc); se = math.sqrt(a_ + b_)
        dfw = (a_ + b_) ** 2 / (a_ ** 2 / (len(lv) - 1) + b_ ** 2 / (len(lc) - 1)); tq = stats.t.ppf(0.975, dfw)      # Welch-Satterthwaite, t-based CI
        rec.update({f'{lab}_ratio': math.exp(l), f'{lab}_lo': math.exp(l - tq * se), f'{lab}_hi': math.exp(l + tq * se), f'{lab}_lnratio': l, f'{lab}_se': se, f'{lab}_lnSD_ctrl': lv.std(ddof=1), f'{lab}_lnSD_cre': lc.std(ddof=1)})
    META.append(rec)
c_ = col
addm('Fig 1a/b', 'direct', c_('Fig. 1b', 'B', 3, 8), c_('Fig. 1b', 'C', 3, 8), c_('Fig. 1b', 'B', 12, 17), c_('Fig. 1b', 'C', 12, 17))
addm('Fig 1f (sh-scrambled melanoma)', 'direct', F1F['metastatic burden (%)'][0], F1F['metastatic burden (%)'][1], F1F['metastatic foci (n)'][0], F1F['metastatic foci (n)'][1])
addm('Fig 1j/k', 'direct', c_('Fig. 1k', 'B', 4, 9), c_('Fig. 1k', 'C', 4, 9), c_('Fig. 1k', 'B', 12, 17), c_('Fig. 1k', 'C', 12, 17))
s = 'Supplementary Fig  1e'; addm('Supp 1e', 'direct', c_(s, 'B', 13, 18), c_(s, 'C', 13, 18), c_(s, 'B', 22, 27), c_(s, 'C', 22, 27))
s = 'Supplementary Fig  1f'; addm('Supp 1f', 'direct', c_(s, 'B', 12, 15), c_(s, 'C', 12, 15), c_(s, 'B', 20, 23), c_(s, 'C', 20, 23))
s = 'Supplementary Fig  1g'; addm('Supp 1g', 'direct', c_(s, 'B', 15, 24), c_(s, 'C', 15, 24), c_(s, 'B', 28, 37), c_(s, 'C', 28, 37))
s = 'Supplementary Fig  1i'; addm('Supp 1i (5% creatine diet)', 'direct', c_(s, 'B', 11, 14), c_(s, 'C', 11, 14), c_(s, 'B', 18, 21), c_(s, 'C', 18, 21))
s = 'Supplementary Fig  1k'; addm('Supp 1k', 'direct', c_(s, 'B', 16, 25), c_(s, 'C', 16, 25), c_(s, 'B', 29, 38), c_(s, 'C', 29, 38))
addm('Fig 3i (Pf4-Cre;Slc6a8+/+ controls)', 'direct', F3I['metastatic burden (%)'][0], F3I['metastatic burden (%)'][1], F3I['metastatic foci (n)'][0], F3I['metastatic foci (n)'][1])
addm('Fig 6b (no inhibitor)', 'direct', F6B['metastatic burden (%)'][0], F6B['metastatic burden (%)'][1], F6B['metastatic foci (n)'][0], F6B['metastatic foci (n)'][1], '3 of 5 animals per arm also appear in Supp 2d')
addm('Fig 1f: tumour-cell Slc6a8 knock-down', 'perturbed', F1F['metastatic burden (%)'][2], F1F['metastatic burden (%)'][3], F1F['metastatic foci (n)'][2], F1F['metastatic foci (n)'][3])
addm('Fig 3i: MK-lineage Slc6a8 knock-out', 'perturbed', F3I['metastatic burden (%)'][2], F3I['metastatic burden (%)'][3], F3I['metastatic foci (n)'][2], F3I['metastatic foci (n)'][3])
addm('Fig 6b: + STAT5-IN-1 (pan-STAT5, systemic)', 'perturbed', F6B['metastatic burden (%)'][2], F6B['metastatic burden (%)'][3], F6B['metastatic foci (n)'][2], F6B['metastatic foci (n)'][3])
addm('Supp 2d: platelets from creatine- vs vehicle-dosed donors', 'transfer', S2D['metastatic burden (%)'][0], S2D['metastatic burden (%)'][1], S2D['metastatic foci (n)'][0], S2D['metastatic foci (n)'][1], '3 of 6 animals per arm also appear in Fig 6b')
addm('Supp 2d: creatine+aspirin donors vs vehicle donors', 'transfer', S2D['metastatic burden (%)'][0], S2D['metastatic burden (%)'][2], S2D['metastatic foci (n)'][0], S2D['metastatic foci (n)'][2])
s = 'Fig. 7g'; addm('Fig 7g: volunteer platelets, day 7 vs day 0, into mice', 'transfer', c_(s, 'B', 12, 16), c_(s, 'C', 12, 16), c_(s, 'B', 19, 23), c_(s, 'C', 19, 23))
METAD = pd.DataFrame(META)
def pool_direct(direct):
    out = {}
    for lab in ('burden', 'foci'):
        y, se = direct[f'{lab}_lnratio'].values, direct[f'{lab}_se'].values; w = 1 / se ** 2
        yf = (w * y).sum() / w.sum(); Q = (w * (y - yf) ** 2).sum(); k = len(y); C = w.sum() - (w ** 2).sum() / w.sum(); tau2 = max(0, (Q - (k - 1)) / C)
        wr = 1 / (se ** 2 + tau2); yr = (wr * y).sum() / wr.sum()
        hw = math.sqrt((wr * (y - yr) ** 2).sum() / ((k - 1) * wr.sum())) * stats.t.ppf(0.975, k - 1)      # DerSimonian-Laird estimate, Hartung-Knapp 95% half-width (t, k-1 df)
        sds = np.concatenate([direct[f'{lab}_lnSD_ctrl'].values, direct[f'{lab}_lnSD_cre'].values]); ns = np.concatenate([direct.n_ctrl.values, direct.n_creatine.values])
        out[lab] = dict(k=k, n_ctrl=int(direct.n_ctrl.sum()), n_cre=int(direct.n_creatine.sum()), ratio=math.exp(yr), lo=math.exp(yr - hw), hi=math.exp(yr + hw), I2=max(0, (Q - (k - 1)) / Q) * 100,
                        min_ratio=float(np.exp(y).min()), max_ratio=float(np.exp(y).max()), pooled_lnSD=math.sqrt(((ns - 1) * sds ** 2).sum() / (ns - 1).sum()), lnSD_min=float(sds.min()), lnSD_max=float(sds.max()))
    return out
direct = METAD[METAD.kind == 'direct']
POOL = pool_direct(direct)
POOL_NO6B = pool_direct(direct[~direct.experiment.str.startswith('Fig 6b')])      # sensitivity: Fig 6b shares animals with Supp 2d
METAD.to_csv(f'{OUT_T}/creatine_effect_by_experiment.csv', index=False)
pd.concat([pd.DataFrame(POOL).T.assign(set='all ten experiments'), pd.DataFrame(POOL_NO6B).T.assign(set='excluding Fig 6b')]).to_csv(f'{OUT_T}/creatine_effect_pooled.csv')

# ----------------------------------------------------------------------------- phosphoproteomics
PH = pd.read_excel(PHOS, sheet_name=0); PH.columns = ['gene', 'p', 'q', 'lfc']
thr_up, thr_dn = math.log2(1.2), math.log2(0.83)
screen = PH[(PH.p < 0.05) & ((PH.lfc >= thr_up) | (PH.lfc <= thr_dn))]
PH_bh = multipletests(PH.p.values, method='fdr_bh')[1]
st = PH[PH.gene == 'Stat5b'].sort_values('p').iloc[0]
PHS = dict(n_rows=len(PH), n_genes=int(PH.gene.nunique()), n_P_lt_0_05=int((PH.p < 0.05).sum()), expected_by_chance_at_0_05=0.05 * len(PH), n_screen_hits=len(screen), n_screen_up=int((screen.lfc > 0).sum()), n_screen_down=int((screen.lfc < 0).sum()),
           min_Q=float(PH.q.min()), n_Q_lt_0_05=int((PH.q < 0.05).sum()), n_Q_lt_0_10=int((PH.q < 0.10).sum()), min_BH=float(PH_bh.min()),
           n_rows_with_identical_P_0_4227=int((PH.p.round(5) == 0.42265).sum()), median_abs_lfc_of_those=float(PH[PH.p.round(5) == 0.42265].lfc.abs().median()),
           stat5b_P=float(st.p), stat5b_Q=float(st.q), stat5b_log2FC=float(st.lfc), stat5b_rank_by_P=int((PH.p < st.p).sum() + 1), stat5b_BH=float(PH_bh[st.name]),
           stat5b_rank_among_screen_up_by_P=int((screen[screen.lfc > 0].p < st.p).sum() + 1), stat5b_second_peptide_P=float(PH[PH.gene == 'Stat5b'].sort_values('p').iloc[1].p), stat5b_second_peptide_log2FC=float(PH[PH.gene == 'Stat5b'].sort_values('p').iloc[1].lfc),
           stat5a_P=float(PH[PH.gene == 'Stat5a'].p.min()), stat5a_log2FC=float(PH[PH.gene == 'Stat5a'].lfc.iloc[0]))
pd.Series(PHS).to_csv(f'{OUT_T}/phosphoproteomics_summary.csv', header=['value'])
PH.sort_values('p').head(40).to_csv(f'{OUT_T}/phosphoproteomics_top40_by_P.csv', index=False)

# ----------------------------------------------------------------------------- duplicated values across sheets
vals = collections.defaultdict(list)
for ws in WB.worksheets:
    for r in ws.iter_rows():
        for c in r:
            v = c.value
            if isinstance(v, (int, float)) and not isinstance(v, bool) and float(v) != int(v):
                digits = len(repr(float(v)).replace('.', '').replace('-', '').lstrip('0'))
                if digits >= 6: vals[float(v)].append((ws.title, c.coordinate))
DUP = []
qpcr_like = {'Fig. 2f', 'Fig. 3f', 'Fig. 4e', 'Fig. 4h', 'Fig. 4j', 'Fig. 4l', 'Fig.6a', 'Fig. 6g', 'Supplementary Fig  4e', 'Supplementary Fig  3c', 'Supplementary Fig  2a', 'Supplementary Fig  8c', 'Fig. 7d', 'Supplementary Fig  5a'}
for v, locs in vals.items():
    sh = sorted(set(l[0] for l in locs))
    if len(sh) > 1 and not set(sh) <= qpcr_like:       # qPCR sheets share values because Ct is rounded to 2 dp (stated in the sheets)
        DUP.append(dict(value=v, locations='; '.join(f'{a}!{b}' for a, b in locs)))
DUPD = pd.DataFrame(DUP); DUPD.to_csv(f'{OUT_T}/duplicated_values_across_experiments.csv', index=False)

# ----------------------------------------------------------------------------- power for the proposed in vivo study
def power_contrast(delta, sigma, n, coefs, df, alpha=0.05):
    se = sigma * math.sqrt(sum(x * x for x in coefs) / n); tcrit = stats.t.ppf(1 - alpha / 2, df); ncp = delta / se
    return float(1 - stats.nct.cdf(tcrit, df, ncp) + stats.nct.cdf(-tcrit, df, ncp))
L = math.log(POOL['burden']['ratio']); PW = []
for sigma in (POOL['burden']['pooled_lnSD'], 0.60):
    for n in (6, 8, 10, 12, 14, 16):
        df = 4 * n - 4; se2 = sigma * math.sqrt(2 / n)
        PW.append(dict(sigma_ln_burden=round(sigma, 3), n_per_cell=n, power_interaction_100pct_abolition=power_contrast(L, sigma, n, [1, -1, -1, 1], df), power_interaction_70pct=power_contrast(0.7 * L, sigma, n, [1, -1, -1, 1], df),
                       power_interaction_50pct=power_contrast(0.5 * L, sigma, n, [1, -1, -1, 1], df), smallest_baseline_ratio_detectable_80pct_power=math.exp(-(stats.t.ppf(0.975, 2 * n - 2) + stats.t.ppf(0.8, 2 * n - 2)) * se2),
                       power_to_separate_two_lines_differing_by_50_points=power_contrast(0.5 * L, sigma, n, [1] * 8, 8 * n - 8)))
PWD = pd.DataFrame(PW); PWD.to_csv(f'{OUT_T}/power_in_vivo_factorial.csv', index=False)
from statsmodels.stats.power import TTestPower
HP = []
for ag, ep in [('collagen', 'max aggregation'), ('epinephrine', 'max aggregation'), ('epinephrine', 'avg aggregation')]:
    lx = np.log2(H7C[(ag, ep)][:, 3]); m_, sd_ = lx.mean(), lx.std(ddof=1)
    for frac in (1.0, 0.5):
        HP.append(dict(endpoint=f'{ag} {ep}, day 14', mean_log2FC=m_, sd_log2FC=sd_, fraction_of_observed_effect=frac, sd_of_period_difference=sd_ * math.sqrt(2),
                       n_crossover_90pct_power=math.ceil(TTestPower().solve_power(effect_size=frac * m_ / (sd_ * math.sqrt(2)), alpha=0.05, power=0.9))))
pd.DataFrame(HP).to_csv(f'{OUT_T}/power_human_crossover.csv', index=False)

# ----------------------------------------------------------------------------- console summary
if __name__ == '__main__':
    pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 80)
    print('AUDIT rows:', len(AUD), '| recorded P available:', int((AUD.recorded_vs_recomputed != '').sum()), '| agree:', int((AUD.recorded_vs_recomputed == 'yes').sum()), '| disagree:', int((AUD.recorded_vs_recomputed == 'NO').sum()))
    print(AUD[AUD.recorded_vs_recomputed == 'NO'][['panel', 'endpoint', 'comparison', 'recorded_P', 'recomputed_P']].to_string())
    print('\nPOOLED creatine effect:', POOL)
    print('\nSURVIVAL:', {k: (float(np.median(v[0])), float(np.median(v[1])), round(v[2], 3), round(v[3], 4), tuple(round(x, 3) for x in v[4])) for k, v in SURV.items()})
    print('\nINTERACTIONS (log scale for metastasis endpoints):'); print(INTD[INTD.scale == 'log (ratio)'].round(4).to_string(index=False))
    print('\nPHOSPHO:', PHS)
    print('\nDUPLICATES across experiments:'); print(DUPD.to_string(index=False))
    print('\nPOWER:'); print(PWD.round(3).to_string(index=False))
    print('\nHUMAN d14:'); print(HUM[HUM.day == 14].round(4).to_string(index=False))
    print('\nqPCR fold-change cells vs their own dCt rows:', len(DCT), 'cells; max relative difference', round(float(DCT.rel_diff.max()), 4), '; cells differing by >1%:', int((DCT.rel_diff > 0.01).sum()))
    print('\nHUMAN transcripts not reproducible from raw:'); print(H7D[~H7D.reproduces].round(3).to_string(index=False))
    print('\nHuman crossover power:'); print(pd.DataFrame(HP).round(2).to_string(index=False))
