**Take megakaryocyte SLC6A8 — the transporter that loads megakaryocytes with creatine — forward as the primary target, keep megakaryocyte STAT5B as first backup and CKB as second, and use next quarter's in vivo slot for a blinded, powered head-to-head of the two existing megakaryocyte-lineage (Pf4-Cre) knock-out lines on lung metastatic burden.**

# CRE-MK-01: follow-up proposal for the portfolio committee

Scope. Written only from the uploaded package: the source-data workbook (87 sheets), the phosphoproteomics table and the study conventions. Every number below was recomputed from the raw values; all 232 P values recorded in the workbook reproduce from them. Outside literature is not used as evidence; the two places where outside knowledge enters the plan are marked. For metastatic burden, foci, the gene panel and the volunteer fold-changes, "×" is a ratio of geometric means, so it can differ slightly from the ratio of the arithmetic means quoted beside it.

Abbreviations: MK, megakaryocyte; KO, knock-out (both KO lines are Pf4-promoter Cre lines, i.e. megakaryocyte lineage); "gene panel", the 11 platelet-activation genes measured in primary MKs (Itga2b, P2ry12, Gp6, Gp1ba, F2r, Adra2a, Fcgr2a, Runx1, Rab4a, Rab27b, Pitpnb); HR, hazard ratio; ChIP, chromatin immunoprecipitation; Q, the false-discovery-adjusted value supplied with the phosphoproteomics table; TEG MA, maximum amplitude on thromboelastography.

## 1. The decision in brief

1. **The phenotype is solid.** Oral creatine raised lung metastatic burden in all ten in-house experiments (pooled ratio 3.2, 95% CI 2.6–3.8; 61 vs 61 mice) and shortened survival in both survival studies (hazard ratios 2.9 and 2.3).
2. **The effect is carried by platelets made in creatine-loaded megakaryocytes, not by the tumour cell.** Knocking down Slc6a8 in the tumour cells left the effect intact (interaction P = 0.44). Platelets from creatine-dosed donor mice, and platelets taken from volunteers after 7 days of creatine, reproduced it in recipient mice (×3.3 and ×2.8).
3. **MK SLC6A8 is the only candidate with lineage-specific genetics on the disease endpoint.** In Pf4-Cre;Slc6a8 fl/fl mice creatine no longer raised burden (×0.8, against ×3.6 in Cre controls; interaction P = 0.0009; n = 4 per group). MK creatine loading, platelet hyper-reactivity and the gene panel were lost with it, and liposomal creatine, which bypasses the transporter, restored the gene panel in KO megakaryocytes.
4. **STAT5B is a plausible effector but is not validated.** The Stat5b KO has no platelet-function or metastasis readout and no KO-plus-vehicle arm. The in vivo rescue comes from a systemic inhibitor of both STAT5A and STAT5B. The phosphoproteomic hit that nominated STAT5B has Q = 0.25. On creatine, Stat5b-deleted megakaryocytes still carried P2ry12 and Gp6 mRNA at 2.0 and 1.5 times the wild-type vehicle level (the proteins look blunted on a single blot), where transporter deletion returned the mRNA to baseline.
5. **The volunteer data show the platelet effect, not the target.** At 20 g/day, serum creatine reached the mouse exposure and platelet responses to collagen and epinephrine rose by day 14 (×2.5 and ×1.6). SLC6A8, CKB and STAT5B were not measured in any human cell, and there was no control arm.
6. **One condition applies to every candidate.** Nothing tested lowered metastasis in mice that were not given creatine (Slc6a8 KO ×1.5, 95% CI 0.8–3.0; STAT5 inhibitor ×1.0, 0.6–1.7, each against its own vehicle control). On present data, each candidate is a way to cancel a supplement effect, not an anti-metastatic target in its own right. Stopping creatine, and aspirin, are therefore the comparators any new agent has to beat, and both are built into the plan.

![Evidence ladder by candidate](figures/fig1_evidence_ladder.png)

*Figure 1. What the package contains for each candidate, by type of evidence.*

## 2. Evidence

### 2.1 Creatine exposure increases lung metastasis (mouse)

| Readout | Panels | Result (recomputed) |
|---|---|---|
| Lung metastatic burden, creatine vs control | Fig 1b, 1f, 1k, 3i, 6b; Supp 1e, 1f, 1g, 1i, 1k | Ratio 2.1–4.3 in each of ten experiments; pooled 3.2 (95% CI 2.6–3.8), n = 61 + 61 |
| Metastatic foci | same | Pooled ratio 2.0 (1.7–2.4) |
| Survival | Fig 1c; Fig 1l | Median 22 → 19 days, HR 2.9 (1.04–8.2), n = 10 + 10; median 16 → 14 days, HR 2.3 (1.2–4.5), n = 20 + 18 |
| Exposure | Supp 1d, 1h; Fig 3b | Serum creatine 66 → 178 µM by gavage, 78 → 227 µM on the 5% diet, 89 → 239 µM in Cre controls; food, water and body weight unchanged (Supp 1a–c) |
| Early tumour-cell retention | Fig 1h, 1i | Time-course readout 1.5- to 2.8-fold higher from 6 h onward (y-axis unlabelled in the sheet); GFP+ cells per field 9 → 20 (n = fields) |

The two regimens give similar serum levels (178 and 227 µM), and the diet effect (×3.5) sits inside the range of the gavage experiments (×2.1–4.3). The package therefore tests one exposure level and contains no dose–response.

![Creatine effect across experiments](figures/fig2_creatine_effect_forest.png)

*Figure 2. Creatine effect on lung metastatic burden in every in-house experiment, and with one node removed.*

### 2.2 Where the effect is carried

| Question | Panels | Result (recomputed) | Reading |
|---|---|---|---|
| Tumour-cell creatine uptake? | Fig 1f; Supp 2a | With Slc6a8 knocked down in the melanoma cells (mRNA −81%; protein visibly reduced, not absent) creatine still raised burden ×3.2 vs ×4.1 with scrambled hairpin; interaction P = 0.44 | Not required |
| Platelet number? | Fig 2a; Supp 3a | Count 789 vs 789 ×10⁹/L; plateletcrit, volume, white and red cells unchanged | No |
| Platelet reactivity? | Fig 2b, 2c, 2d, 2j | Aggregation: ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56%; α-granules 2.0 → 3.9 per field; clot strength (TEG MA) 39.7 → 54.0 mm, P = 0.049 | Yes, with the replicate caveats in section 3 |
| Are platelets sufficient? | Supp 2d; Fig 7g | Recipients of platelets from creatine-dosed donors: burden 5.9 → 17.9% (×3.3, 95% CI 1.8–5.9); lost when donors also received aspirin (4.4%). Volunteer platelets, day 7 vs day 0: 4.6 → 12.7% (×2.8, 1.6–4.8) | Yes |
| Set in the megakaryocyte or in the platelet? | Fig 2f, 2g, 2i, 4a, 4c | Gene panel up ×1.7–5.7 in MKs; 0.2 and 2 mM creatine raised GP6 and P2RY12 protein in cultured MKs but not in isolated platelets; MK creatine 42 → 129 µmol/g and phosphocreatine 0.37 → 1.46 ng/µg (brain 96 → 114 and 0.32 → 0.63) | Megakaryocyte |

### 2.3 The three candidates compared

**MK SLC6A8 (primary).** Pf4-Cre;Slc6a8 fl/fl versus Pf4-Cre;Slc6a8 +/+, each with vehicle or creatine:

| Readout | Panel | Cre control: vehicle → creatine | KO: vehicle → creatine | Interaction |
|---|---|---|---|---|
| Serum creatine (µM) | Fig 3b, n = 5 | 89 → 239 | 89 → 218 | P = 0.18 (exposure matched) |
| MK intracellular creatine (µmol/g) | Fig 3c, n = 3 | 13.7 → 72.1 | 13.7 → 21.1 | P = 0.045 (0.065 on the log scale) |
| Aggregation (%), ADP / collagen / thrombin | Fig 3d, n = 3 | 63 → 71 / 65 → 77 / 61 → 75 | 54 → 31 / 61 → 51 / 45 → 35 | all P < 0.0001 (replicate type unclear; section 3) |
| Gene panel, median fold of control vehicle | Fig 3f, n = 3 | 1 → 3.6 | 0.96 → 0.88 | P < 0.05 for 7 of 11 genes |
| Lung metastatic burden (%) | Fig 3i, n = 4 | 2.4 → 7.9 | 3.4 → 2.9 | P = 0.0009 (log scale) |
| Metastatic foci | Fig 3i, n = 4 | 29.8 → 56.5 | 26.5 → 24.8 | P = 0.023 |
| Lung weight (g) | Fig 3i, n = 4 | 0.206 → 0.249 | 0.222 → 0.225 | P = 0.0002 |

In KO megakaryocytes cultured with creatine the panel did not move (median ×1.05), but liposomal creatine induced it (median ×2.7; 9 of 11 genes at least 2-fold; Supp 4e; no empty-liposome arm). The defect is therefore the transport step, not a general inability of KO megakaryocytes to respond. Platelet count was unchanged by genotype (Supp 4b).

What is still weak for the primary:

- The metastasis result rests on one experiment with four mice per group. Burden in creatine-dosed KO mice does not overlap with creatine-dosed controls, and an exact rank test gives P = 0.029, the smallest value possible at that size.
- The deletion was checked on a single immunoblot lane, which shows SLC6A8 reduced, not absent (Supp 4a).
- KO platelets aggregated less than controls at baseline (ADP 54 vs 63%, thrombin 45 vs 61%) and less still on creatine. This may be a haemostasis liability and is unexplained.
- No SLC6A8 inhibitor was tested anywhere in the package, so tractability is open.

**STAT5B (first backup).**

| Step | Panels | Result (recomputed) | Limit |
|---|---|---|---|
| Nomination | Phosphoproteomics, n = 3 vs 3 mice | One Stat5b phosphopeptide: P = 0.0012, rank 17 of 5,812 by P | Q = 0.25, and the smallest Q in the table is 0.17. 238 rows reach P < 0.05, close to chance (about 206 expected among the 4,110 rows that are not presence/absence calls). The second Stat5b peptide has P = 0.47. The site is not identified in the table |
| Site | Fig 5e, 5f (FLAG-STAT5B over-expression; 293T, inferred from the conventions; n = 3 blots) | Under creatine, S127A lowers the pan-phospho/FLAG ratio by 17% (P = 0.029) and 34% (P = 0.016); no difference under vehicle | Pan-phospho antibody on an over-expressed protein in a non-megakaryocyte line; S127A removes a minority of the signal |
| Canonical activation | Supp 6a | Tyr694/699 phosphorylation not detectable in MKs with or without creatine (positive control works) | The modification is non-canonical; what the inhibitor engages in MKs is undefined |
| Nuclear localisation | Supp 6h (blot, 2 lanes per group) | Nuclear STAT5B is faint in one vehicle lane and similar to the creatine lanes in the other | Not quantified; does not by itself show translocation |
| Promoter occupancy | Fig 5j; Supp 6i (n = 3) | ChIP signal 2.7- to 12-fold higher at the −0.2 kb and −1 kb amplicons of P2ry12, Gp6 and Rab4a (and at −2 kb for P2ry12); exon amplicons unchanged | No IgG or KO control in the package; exon "background" is 5–11% of input |
| Pharmacology, gene panel | Fig 6a | STAT5-IN-1 removes induction (median ×4.2 → ×0.63) | Inhibitor alone lowers 6 of 11 genes to ≤0.6 of baseline |
| Pharmacology, metastasis | Fig 6b, n = 5 | Creatine effect ×4.1 → ×1.3; interaction P = 0.0004 | Inhibits STAT5A and STAT5B, given systemically; three animals per arm duplicated in Supp 2d (section 3) |
| Genetics | Fig 6d–g; Supp 7b | Pf4-iCre;Stat5b fl/fl on creatine: MK creatine uptake intact (98 vs 95 µmol/g); panel median ×1.3 of wild-type vehicle, with P2ry12 ×2.0 and Gp6 ×1.5. On the one blot (Fig 6f), GP6 and P2RY12 protein in KO + creatine sit at or below wild-type vehicle, and CKB is still raised | No KO + vehicle arm; controls are labelled "WT" (Cre status not stated); no aggregation, platelet-transfer or metastasis readout |

**CKB (second backup).** All evidence is in cultured cells. Creatine raised Ckb mRNA ×1.8 (Fig 4e) and CKB protein (Fig 4b, one lane per condition). Ckb knock-down cut the panel response from a median ×4.3 to ×1.3 (interaction P < 0.05 for 9 of 11 genes; Fig 4j). CKB over-expression alone raised the panel ×1.7–6.0 (Fig 4l) without changing creatine or phosphocreatine (Supp 5c), and added phosphocreatine did not induce it (Fig 4h). On the one blot available, phosphocreatine also raised CKB protein without raising GP6 or P2RY12 (Fig 4g), which sits awkwardly with over-expression being sufficient. One immunoblot shows His-tagged CKB plus ATP increasing the pan-phospho signal on FLAG-STAT5B in an in vitro reaction (Supp 6d). There is no in vivo loss of function and no kinase-dead control.

Placing the four perturbations side by side (Figure 4) shows the ordering. On creatine, transporter deletion returns P2ry12 and Gp6 mRNA to baseline (×1.07, ×0.92 of control vehicle). Stat5b deletion leaves them at ×2.0 and ×1.5, and without a KO + vehicle arm it is not possible to say how much of that is creatine. The pan-STAT5 inhibitor does more than the Stat5b KO, which points to STAT5A redundancy or to effects of the compound beyond STAT5B.

![Interaction experiments on the disease endpoint](figures/fig3_interaction_experiments.png)

*Figure 3. The three factorial experiments on metastatic burden. Circled points in the right panel also appear in Supp 2d.*

![Gene panel under each perturbation](figures/fig4_mk_gene_panel.png)

*Figure 4. The megakaryocyte gene panel under each of the four perturbations.*

![Phosphoproteomics](figures/fig5_phosphoproteomics.png)

*Figure 5. Megakaryocyte phosphoproteomics: no peptide passes false-discovery control; the Stat5b peptide is one of 209 nominal hits.*

### 2.4 Healthy volunteers (n = 11; 20 g/day for 14 days; single arm)

| Readout | Panel | Result (recomputed, paired) |
|---|---|---|
| Serum creatine, fasting | Fig 7b, n = 11 | 45 → 153 µM by day 3, 159 µM at day 14; rose in 11 of 11. Similar to the mouse exposure |
| Platelet count and indices, BMI | Supp 8a, 8b | Unchanged |
| Platelet function at day 14, fold of own baseline | Fig 7c, n = 11 | Collagen: max aggregation ×2.5 (1.5–4.3), 9 of 11 up. Epinephrine: ×1.6 (1.2–2.2), 10 of 11 up. Arachidonic acid: ×1.3 (0.9–1.8). ADP: ×1.07 (0.7–1.6), 6 of 11 up |
| Time course | Fig 7c | Nothing at day 3 although serum creatine is already at plateau; epinephrine response up at day 7; collagen at day 14 |
| Platelet protein | Fig 7e, n = 4 | GP6 ×2.0 at day 7 and ×2.6 at day 14 (4 of 4 up); P2RY12 ×1.3 and ×1.7 (4 of 4) |
| Circulating CD41+ cell mRNA | Fig 7d, n = 4 | Day 7: ADRA2A ×21 (4 of 4), GP6 ×6.4 (3 of 4), P2RY12 ×3.1 (3 of 4). Day 14: RAB4A ×0.38 (down in 4 of 4) |
| Volunteer platelets into mice | Fig 7g, n = 5 | Day-7 vs day-0 platelets: burden ×2.8, foci 22 → 39 |

What this adds: 20 g/day reproduces the mouse exposure and produces platelet hyper-reactivity within two weeks, with a delay consistent with new platelets being made rather than circulating platelets being changed. What it does not add: no measurement of SLC6A8, CKB or STAT5B in any human cell, no control arm, and no cancer patients. Two species differences matter for biomarkers. The human functional gain is in the collagen and epinephrine responses, which rise together across volunteers (Spearman 0.82), and not in the ADP response, despite higher P2RY12. And RAB4A, one of the three promoter targets mapped in mouse MKs, falls in human CD41+ cells. GP6 protein and collagen-induced aggregation are the readouts that hold in both species.

![Volunteer cohort](figures/fig6_human_volunteers.png)

*Figure 6. Volunteer cohort: exposure, platelet function, platelet protein and CD41+ cell transcripts.*

## 3. What limits the package

**Design (from the conventions).** Allocation and readout were not masked. Immunoblot loading controls were run on parallel gels, which matters for the densitometry panels (Fig 5e, 5f, 7e). No sample size was calculated; most groups have 3–6 animals. Sex was not analysed and is confounded with strain (male C57BL/6J, female BALB/cJ). Four panels count microscope fields as n (Fig 1i, 2c, 2j; Supp 4c). The normality test named in the conventions (D'Agostino–Pearson) needs at least 8 values per group, so the t tests at n = 3–6 rest on assumption; with 3 vs 3 no rank test can reach P < 0.05.

**Data items to resolve.**

- *Duplicated animals.* Three vehicle and three creatine animals have identical burden and foci values in Fig 6b (STAT5 inhibitor) and Supp 2d (platelet transfer). As labelled, the two designs should not share animals, and only part of each group overlaps, so at least one table is wrong for those rows. Without them the direction holds in both (Fig 6b interaction P = 0.014 with n = 2 in two arms; Supp 2d ×2.7 with n = 3), but these are the only in vivo data for STAT5 inhibition and for aspirin. The pooled creatine effect in 2.1 does not depend on Fig 6b (×3.0, 95% CI 2.5–3.7 without it).
- *Aggregation replicates.* In Fig 2b the third value of every group equals the mean of the other two (6 of 6 groups). In Fig 3d, 11 of 12 groups have the same SD (1.15 points). These look like repeat reads, not independent animals.
- *qPCR replicates.* Each gene-panel group has three values, and the conventions say each sample was run in triplicate. Whether the three values are three animals (or cultures) or three wells of one sample is not stated.
- *Volunteer transcripts.* For volunteer 4, the normalised RAB27B and PITPNB values cannot be reproduced from the listed raw values (the PITPNB entries are not ΔCt values).
- *Labels.* Fig 4d is headed "creatinine" although only a creatine assay is listed. Fig 1h has no y-axis label. The conventions list the same forward primer for the Rab4a −1 kb and −2 kb ChIP amplicons. Primers for Plcg1 and Orai1 are listed but no data are in the workbook.

**What is specific to the backups.** Covered in 2.3: no genetic test of STAT5B on platelet function or metastasis and none of CKB in vivo, a non-selective inhibitor, an incomplete Stat5b KO design, and a discovery data set with no peptide passing false-discovery control.

**What is specific to the volunteer data.** Single arm, eleven Asian volunteers aged 20–25, one dose (20 g/day), each value normalised to its own baseline; protein and transcripts in 4 of the 11; transcripts in circulating CD41+ cells, not bone-marrow megakaryocytes.

**Not recorded in the package.** Tumour lines other than melanoma (Fig 1f); route of tumour-cell delivery; which strain and sex each panel used; timing of creatine dosing relative to tumour challenge and to blood sampling; the creatine concentration in the cultured-MK gene-panel experiments (0.2 or 2 mM); how Fig 5e and 5f differ; and how many volunteers supplied the platelets for Fig 7g.

## 4. Follow-up studies

### Study 1 — the next-quarter in vivo slot: megakaryocyte-lineage knock-outs, head to head

| Item | Specification |
|---|---|
| Question | Does MK SLC6A8 loss reproducibly remove the creatine effect under masked, powered conditions? Does MK STAT5B loss do the same? Does either change metastasis or haemostasis without creatine? |
| Design | Two lines × genotype × exposure, eight cells. Pf4-Cre;Slc6a8 fl/fl vs Pf4-Cre;Slc6a8 +/+. Pf4-iCre;Stat5b fl/fl vs Pf4-iCre;Stat5b +/+ (the existing Stat5b panels used controls labelled "WT" and had no KO + vehicle arm) |
| Population | Both sexes of each line; littermate or co-housed age-matched Cre controls; creatine or vehicle randomised within litter and sex |
| Model and indication | The lung-metastasis model used for Fig 3i (tumour line and delivery route to be confirmed from the study record); indication addressed: lung metastasis in a creatine-exposed host |
| Exposure and comparator | Creatine by gavage on the in-house schedule (17 mg per dose, three times a week) vs vehicle (water) |
| Primary endpoint | Lung metastatic burden (%), read blind. Chosen over foci count because the creatine effect is larger relative to its scatter in our ten experiments (2.7 vs 2.0 SD on the log scale). Analysis, fixed before unmasking: genotype × creatine interaction on the log scale, within each line |
| Secondary endpoints | Foci count, lung weight, PET signal |
| Mechanism and safety readouts (satellite animals, animal as the unit) | Serum creatine; MK creatine and phosphocreatine; aggregation to ADP, collagen and thrombin, plus the volunteer agonists where feasible; platelet GP6 and P2RY12 protein; gene panel; MK STAT5B (total, nuclear, Ser127-resolved when available); platelet count and indices; a bleeding measure |
| Size and power | 12 per cell for the endpoint (96) plus 5 per cell satellites (40). With the pooled SD of ln(burden) from our ten experiments (0.43) and a 3.2-fold creatine effect: over 99% power to detect complete removal, 89% for removal of 70% or more, 63% for 50%; 80% power to detect a baseline reduction to 0.6-fold or lower. The study cannot rank two lines that differ by 50 points of removal or less (37% power at 50 points), so the ranking rule is categorical |
| Decision rule, per line | "Removes": at least 70% of the creatine log-effect gone and interaction P < 0.05. "Partial": 30–70%, which triggers a repeat, not a ranking. "Does not remove": under 30% |
| If animal supply limits the slot | Keep all eight cells, the masking and 12 per cell. Trim the satellite readouts first, then restrict to one sex and report the result as single-sex |

### Studies that follow or run alongside

| Study | Objective and indication | Population / system | Arms and comparators | Primary endpoint | Other readouts |
|---|---|---|---|---|---|
| 2. Pharmacology, benchmark and reversibility (second in vivo slot) | Can a drug remove the effect, and does it beat the simple options? Same indication as Study 1 | Wild-type mice, both sexes, model as Study 1 | On creatine: vehicle; STAT5-IN-1 5 mg/kg/day; aspirin 30 mg/kg/day given to the tumour-bearing animal; creatine stopped before tumour challenge (two intervals); an SLC6A8 inhibitor only after it is qualified in-house on MK creatine uptake. Each agent also without creatine. Separate arm: platelets from creatine-dosed Slc6a8-KO vs control donors into wild-type recipients | Lung metastatic burden | Target engagement (MK creatine; gene panel); platelet aggregation; brain and muscle creatine; bleeding; body weight |
| 3. Exposure–response | Serum creatine threshold for the platelet and metastasis effects; defines who is exposed enough to be at risk | Wild-type mice | Graded creatine doses below the current schedule; 5% diet as ceiling; vehicle | Lung metastatic burden against serum creatine | Aggregation; platelet GP6; gene panel |
| 4. Generality | Does it hold beyond one model, one sex per strain and lung? Extends the indication to a second tumour type and to spontaneous metastasis | The BALB/cJ model in the package, both sexes; an orthotopic primary with spontaneous metastasis | Creatine vs vehicle; MK Slc6a8 KO if the line can be bred onto that background; a lineage-restriction control for Pf4-Cre (marrow chimera or second driver) | Metastatic burden; metastasis-free survival | Sites other than lung; primary tumour growth |
| 5. Mechanism closure for the backups (cells and ex vivo; no animal slot) | Is Ser127 on STAT5B the creatine-responsive site in primary MKs, and does CKB act on it directly? | Primary MKs from control, Slc6a8-KO and Stat5b-KO mice | Site-resolved Ser127 measurement with and without creatine; phosphoproteomics repeated with at least 6 per group and false-discovery control; Stat5b-null MKs rebuilt with wild-type, S127A or S127D STAT5B; STAT5A vs STAT5B knock-down; kinase-dead CKB and S127A substrate in the in vitro reaction; ChIP with IgG and KO controls | Gene-panel induction; Ser127 occupancy | Nuclear STAT5B; GP6 and P2RY12 protein |
| H1. Controlled volunteer study | Confirm the platelet effect against placebo, find the dose at which it appears and how fast it reverses | Healthy adults of both sexes, wider age and ancestry than the first cohort, no antiplatelet or NSAID use; about 24 completers | Randomised, double-blind crossover: placebo, 3–5 g/day (a typical maintenance dose; outside knowledge) and 20 g/day, 14 days each, with washout long enough for platelet turnover | Collagen-induced maximum aggregation at day 14 relative to own baseline, 20 g/day vs placebo (19 completers give 90% power for the effect seen; the lower dose is sized for estimation) | Epinephrine response; ADP and arachidonic acid as expected-negative controls; platelet GP6 and P2RY12 in every participant; fasting serum creatine; counts; days to return to baseline |
| H2. Patient sampling (observational) | Is the platelet signature present in the people who would be advised or treated? | Patients with resected solid tumours, melanoma first (the only tumour type named in our models), who do and do not take creatine | Users vs non-users, matched for antiplatelet use | Collagen-induced aggregation | Platelet GP6; serum creatine |

Order. The items in section 6 come first, because they decide how Study 1 is specified and read. Study 1 takes the slot. Study 5 and H1 do not need the slot and can start now. Studies 2–4 are gated on the result of Study 1.

Indications. What the package supports is prevention of lung metastasis in a creatine-exposed host; the early retention readouts (Fig 1h, 1i) suggest the step affected is blood-borne seeding, but the delivery route is not recorded. It does not address established metastases, primary tumour growth, other organs, or hosts that do not take creatine; Studies 1–4 are designed to show whether any of these can be added. Whatever the target decision, the volunteer and platelet-transfer data already raise a practical question about high-dose creatine use by patients at risk of blood-borne spread. The package cannot size that risk in people; H1 and H2 are the studies that would.

## 5. What would move one candidate above another

| Finding | Consequence |
|---|---|
| Study 1: Stat5b KO "removes"; platelet function normal; Study 5 confirms creatine-dependent Ser127 phosphorylation in primary MKs, absent in Slc6a8-KO MKs | STAT5B becomes co-primary. The choice between the two then rests on tolerability: brain and muscle creatine and bleeding for SLC6A8; STAT5A cross-inhibition for STAT5B |
| Study 1: Slc6a8 KO "removes", Stat5b KO "partial" or "does not remove" | SLC6A8 stays primary. STAT5B is demoted; test STAT5A redundancy and STAT5B-independent outputs of CKB |
| Study 1: Slc6a8 KO fails to replicate | No candidate advances. Re-examine with the lineage-restriction control before any further spend |
| Study 1: either KO lowers burden without creatine | The indication widens beyond creatine users; that candidate gains priority |
| Studies 1–2: no baseline effect, and stopping creatine or aspirin fully normalises burden | The output is risk advice plus a repurposing question. A novel-target programme is hard to justify |
| Study 2: an SLC6A8 inhibitor at exposures that block MK uptake depletes brain or muscle creatine, or prolongs bleeding | SLC6A8 is demoted in favour of an MK-restricted node (STAT5B or CKB), if Study 1 supports one |
| Study 5: kinase-dead CKB and S127A substrate controls hold, then MK Ckb loss removes the effect in vivo | CKB moves above STAT5B |
| Study 3 and H1: effect present at the 20 g/day exposure but absent at the lower dose | The population at risk narrows to high-dose users; urgency drops |
| H1: no platelet effect against placebo | Human relevance is in doubt; priority drops whatever the mouse result |
| H1: GP6 blockade ex vivo normalises the volunteer platelet phenotype | A platelet-effector route (GP6) becomes a competing backup with a shorter path to patients |

## 6. Items to close with the study team before the meeting

1. Which rows are correct where Fig 6b and Supp 2d coincide, and the corrected statistics.
2. The tumour line, host strain, sex and cell-delivery route for each in vivo panel, including Fig 3i and 6b.
3. Whether the triplicates in the aggregation panels (Fig 2b, 3d) and in the gene-panel qPCR are independent animals or repeat measurements of one sample.
4. The genotype of the "WT" controls in Fig 6e, 6g and Supp 7b, and whether any Stat5b KO animals were run on vehicle.
5. The phosphosite behind the Stat5b peptide, and the direction and log base of LOG_FOLDCHANGE.
6. Raw values for volunteer 4 (RAB27B, PITPNB); the number of donors behind Fig 7g; data for Plcg1 and Orai1 if they were run.
7. Outside knowledge, to check: Slc6a8 is X-linked, so male KO mice would be hemizygous; genotype labels and the both-sexes design of Study 1 need to reflect this.

## 7. How the numbers were derived

- Raw values were read from each sheet and every recorded test was re-run (Student t, one-way ANOVA with Tukey, Dunnett, two-way ANOVA with Šidák, log-rank). All 232 recorded P values agree.
- Added analyses: ratios of geometric means with t-based confidence intervals; genotype × creatine or drug × creatine interaction tests on the log scale; random-effects pooling across the ten creatine experiments (DerSimonian–Laird with Hartung–Knapp interval); Cox hazard ratios; Welch and Mann–Whitney checks on every two-group panel. Permutation versions of the three interaction tests on burden give the same picture (Slc6a8 KO P = 0.001; STAT5 inhibitor P = 0.0006; tumour-cell knock-down P = 0.45).
- Volunteer data are within-subject, so they were re-tested as paired data (one-sample t on log fold-change; Wilcoxon signed-rank; Holm adjustment across the 12 function endpoints). The recorded tests treat the baseline column of 1s as a group. Collagen and epinephrine aggregation remain significant after Holm adjustment (P = 0.044 and 0.020); collagen adhesion and arachidonic acid do not.
- qPCR panels: all 900 fold-change cells in the qPCR sheets other than Fig 7d were recomputed from their ΔCt rows (largest difference 0.3%), and groups were compared on the log scale. Fig 7d was recomputed per volunteer from the triplicate rows.
- Phosphoproteomics: counts by the recorded screen (P < 0.05 and fold-change ≥1.2 or ≤0.83) against the supplied Q values; 1,702 rows share P = 0.4227 with very large fold-changes, which is the signature of presence/absence calls, and were set aside when comparing with chance. The 1% false-discovery rate quoted in the conventions applies to peptide identification, not to the creatine-versus-vehicle comparison.
- A search for values repeated across unrelated sheets found the Fig 6b / Supp 2d overlap.
- Immunoblot images without densitometry (for example Fig 2e, 2g, 2i, 3g, 4b, 6d, 6f; Supp 4a, 6a, 6d, 6h) were read by eye and are cited as qualitative support only.
- Power calculations use the pooled within-group SD of ln(burden) from the ten in-house experiments (0.43; range 0.14–0.71) and, for the volunteer study, the day-14 SD of log2 fold-change.

Files: `analysis/reanalysis.py` reproduces every table in `tables/`; `analysis/figures.py` draws the figures. `tables/panel_audit_recorded_vs_recomputed.csv` lists all 241 comparisons with recorded and recomputed P values.

## Appendix A. Panel register

Values are group means unless stated; n is animals unless stated. "Blot" means an immunoblot image without densitometry.

| Panel | System and n | Result (recomputed) |
|---|---|---|
| Fig 1a | Mice, n = 6 | Lung weight 0.227 → 0.324 g (P = 0.0003); PET SUV-BW 418 → 894 (P = 0.003) |
| Fig 1b | Mice, n = 6 | Burden 5.2 → 16.2% (P = 0.0005); foci 28 → 53 (P = 0.0006) |
| Fig 1c | Mice, n = 10 | Median survival 22 → 19 days; log-rank P = 0.032 |
| Fig 1f | Melanoma, scrambled vs Slc6a8 hairpin, n = 6 | Burden 4.6 → 15.9% and 5.8 → 18.3%; foci 11 → 27 and 14 → 31; interaction P = 0.44 and 0.60 |
| Fig 1h | Mice, n = 6; y-axis unlabelled | No difference at 0.25 h (P = 0.31); creatine higher at 6, 12 and 24 h (×1.5, ×1.8, ×2.8) |
| Fig 1i | 8 fields per group | GFP+ cells per field 9.1 → 20.4 |
| Fig 1j, 1k | Mice, n = 6 | Lung weight 0.185 → 0.302 g; SUV-BW 615 → 1,032; burden 7.2 → 16.4%; foci 26 → 42 |
| Fig 1l | Mice, n = 20 and 18 | Median survival 16 → 14 days; log-rank P = 0.011 |
| Fig 2a | Mice, n = 3 | Platelet count, plateletcrit, distribution width and mean volume unchanged (P ≥ 0.35) |
| Fig 2b | Platelets, 3 values per group | Aggregation: ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56% |
| Fig 2c | 8 fields per group | α-granules 2.0 → 3.9 |
| Fig 2d | Mice, n = 5 | Thromboelastography: R, K and α not different; MA 39.7 → 54.0 mm (P = 0.049; Welch 0.052) |
| Fig 2e | Blot, platelets, 3 lanes per group | Differences modest by eye (P2RY12 somewhat higher with creatine) |
| Fig 2f | Primary MKs, n = 3 | Gene panel ×1.7–5.7; 10 of 11 genes P < 0.05 |
| Fig 2g | Blot, MKs, 3 lanes per group | GP6 and P2RY12 higher with creatine |
| Fig 2i | Blot, cultured MKs and platelets, one lane per dose | 0.2 and 2 mM creatine raise GP6 and P2RY12 in MKs, not in platelets |
| Fig 2j | 8 fields per group | PKH-positive area 1.9 → 4.5% |
| Fig 3b | Serum, n = 5 | 89 → 239 µM (Cre control); 89 → 218 µM (Slc6a8 KO) |
| Fig 3c | MKs, n = 3 | Intracellular creatine 13.7 → 72.1 (control, P = 0.049); 13.7 → 21.1 µmol/g (KO, P = 0.20) |
| Fig 3d | Platelets, 3 values per group | See 2.3 |
| Fig 3f | MKs, n = 3 | Panel median ×3.6 (control + creatine), ×0.88 (KO + creatine) |
| Fig 3g | Blot, 2 lanes per group | GP6 and P2RY12 rise with creatine in control, not in KO |
| Fig 3i | Mice, n = 4 | See 2.3 |
| Fig 4a, 4c | MKs and brain, n = 3 | Creatine: MKs 42 → 129, brain 96 → 114 µmol/g. Phosphocreatine: MKs 0.37 → 1.46, brain 0.32 → 0.63 ng/µg |
| Fig 4b | Blot, one lane per condition | CKB higher in MKs after creatine; brain as reference |
| Fig 4d, 4f | Cultured MKs, n = 3 | "Creatinine" (label) 30 → 109 µmol/g; phosphocreatine 0.23 → 1.24 ng/µg |
| Fig 4e | MKs, n = 3 | Ckb mRNA ×1.8 (P = 0.011) |
| Fig 4g, 4h | Cultured MKs; blot and qPCR, n = 3 | Creatine induces the panel (median ×3.3); phosphocreatine does not (×0.65). Blot: CKB raised by both; GP6 and P2RY12 by creatine only |
| Fig 4i, 4j | Cultured MKs; blot and qPCR, n = 3 | Ckb knock-down: panel median ×4.3 → ×1.3 |
| Fig 4k, 4l | Cultured MKs; blot and qPCR, n = 3 | CKB over-expression: panel ×1.7–6.0 |
| Fig 5e, 5f | FLAG-STAT5B, densitometry of n = 3 blots | Creatine: wild-type 1.00, S127A 0.83, "3A" mutant 0.74, S127D 1.01 (5e); 0.97, 0.63, 0.67, 0.99 (5f). Vehicle: S127D above wild-type (P = 0.009, 0.037) |
| Fig 5g, 5h, 5i | Blots, one lane per condition | 5g: CKB over-expression raises the pan-phospho band on wild-type STAT5B, not S127A. 5h: nuclear pan-phospho signal rises with creatine for wild-type and, less, for S127A; lower with CKB knock-down. 5i: not interpretable by eye |
| Fig 5j | ChIP-qPCR, n = 3 | P2ry12: −0.2, −1, −2 kb ×12, ×4.7, ×4.8. Gp6: −0.2, −1 kb ×2.9, ×3.8; −2 kb and exon unchanged |
| Fig 6a | MKs, n = 3 | Panel median ×4.2 (creatine), ×0.63 (creatine + STAT5-IN-1), ×0.58 (inhibitor alone) |
| Fig 6b | Mice, n = 5 | Burden 3.4 → 13.9% (vehicle); 3.6 → 4.5% (inhibitor). Foci 30 → 58; 30 → 27 |
| Fig 6d | Blot, one lane each | STAT5B absent in Pf4-iCre;Stat5b fl/fl MKs |
| Fig 6e | MKs, n = 3 | Intracellular creatine 20 (WT vehicle), 95 (WT creatine), 98 µmol/g (KO creatine) |
| Fig 6f | Blot, one lane each | GP6 and P2RY12 in MKs and platelets: creatine rise absent in Stat5b KO; CKB still raised in KO MKs |
| Fig 6g | MKs, n = 3 | Panel median ×4.1 (WT creatine), ×1.3 (KO creatine) |
| Fig 7b–7g | Volunteers | See 2.4 |
| Supp 1a–1c | Mice, n = 4–6 | Body weight, food and water intake not different |
| Supp 1d, 1h | Serum, n = 6 and 4 | 66 → 178 µM (gavage); 78 → 227 µM (5% diet) |
| Supp 1e, 1f, 1g, 1k | Mice, n = 6, 4, 10, 10 | Burden ×2.1, ×2.8, ×3.4, ×3.5 (arithmetic); all P ≤ 0.009 |
| Supp 1i | Creatine diet, n = 4 | Burden 7.3 → 26.2% (P = 0.005); foci 17 → 26 |
| Supp 2a | Tumour cells, n = 3; blot | Slc6a8 mRNA 0.19 of control; protein reduced |
| Supp 2d | Recipient mice, n = 6 | Burden 5.9 (vehicle donors), 17.9 (creatine donors), 4.4% (creatine + aspirin donors) |
| Supp 3a | Mice, n = 5 | White cells, lymphocytes, monocytes, red cells unchanged |
| Supp 3c | MKs, n = 3 | Nine MK maturation genes: median ×0.98; three nominally changed (Hsd3b1 ×1.4, Casp12 ×1.9, Myl9 ×0.5) |
| Supp 4a | Blot, one lane each | SLC6A8 reduced in KO MKs |
| Supp 4b, 4c | Mice, n = 3; 8 fields | Platelet count unchanged by genotype; α-granule rise lost in KO |
| Supp 4e | Cultured KO MKs, n = 3 | Panel median ×1.05 (creatine), ×2.7 (liposomal creatine) |
| Supp 5a, 5c | MKs, n = 3 | Gatm, Gamt unchanged; CKB over-expression does not change creatine or phosphocreatine |
| Supp 5b, 6e–6g | Blots | Knock-down and over-expression controls |
| Supp 6a | Blot, 3 lanes per group | No Tyr694/699 phospho-STAT5 signal in MKs; total STAT5B unchanged |
| Supp 6d | Blot, one reaction each | His-tagged CKB plus ATP raises the pan-phospho signal on FLAG-STAT5B in vitro |
| Supp 6h | Blot, 2 lanes per group | Nuclear STAT5B faint in one vehicle lane, similar to the creatine lanes in the other |
| Supp 6i | ChIP-qPCR, n = 3 | Rab4a −0.2 kb ×5.5, −1 kb ×2.7; −2 kb and exon unchanged |
| Supp 7a, 7b | Mice, n = 3 | Platelet indices unchanged by STAT5-IN-1 or Stat5b KO |
| Supp 8a, 8b | Volunteers, n = 11 | BMI and platelet indices unchanged |
| Supp 8c, 8d | CD41+ cells; blots of 4 volunteers | CD41 mRNA 17-fold above monocytes; blots behind Fig 7e |
