'''Human volunteer cohort: serum creatine (Fig 7b), platelet function fold-changes (Fig 7c),
CD41+ transcripts (Fig 7d), platelet protein (Fig 7e), platelet transfer (Fig 7g).
Outputs: fig7c_reanalysis.csv, fig7d_summary.csv'''
from lib import *
import os
ws=sheet('Fig. 7b')
d=[col(ws,c,4,14) for c in 'BCDE']; nm=['d0','d3','d7','d14']
print('== Fig 7b serum creatine (uM), n=11 volunteers')
for n,x in zip(nm,d): print('  ',n,desc(x), 'range',x.min(),x.max())
F,p,tk=tukey(d,nm); print('  one-way ANOVA (unpaired) F=%.1f p=%.3g'%(F,p)); 
for k,v in tk.items(): print('    Tukey',k,round(v[0],1),'%.3g'%v[1])
for r in (5,6,7): print('    REPORTED', ws[f'G{r}'].value, ws[f'H{r}'].value, ws[f'L{r}'].value)
for i in (1,2,3):
    print(f"   paired t d0 vs {nm[i]}: p={stats.ttest_rel(d[0],d[i]).pvalue:.3g}; fold={d[i].mean()/d[0].mean():.2f}; min individual fold={np.min(d[i]/d[0]):.2f}")
ws=sheet('Fig. 7c')
blocks=[('collagen','max agg',4,14,'BCDE',(4,5,6)),('collagen','avg agg',18,28,'BCDE',(18,19,20)),('collagen','adhesion',32,42,'BCDE',(32,33,34)),
        ('EPI','max agg',46,56,'BCDE',(47,48,49)),('EPI','avg agg',60,70,'BCDE',(61,62,63)),('EPI','adhesion',74,84,'BCDE',(75,76,77)),
        ('AA','max agg',88,98,'BCDE',(88,89,90)),('AA','avg agg',102,112,'BCDE',(103,104,105)),('AA','adhesion',116,126,'BCDE',(117,118,119)),
        ('ADP','max agg',130,140,'BCDE',(131,132,133)),('ADP','avg agg',144,154,'BCDE',(145,146,147)),('ADP','adhesion',157,167,'BCDE',(159,160,161))]
print('== Fig 7c human platelet function fold-change vs d0 (n=11)')
rows=[]
for ag,meas,r0,r1,cols,rep in blocks:
    d=[col(ws,c,r0,r1) for c in cols]
    assert all(len(x)==11 for x in d), (ag,meas,[len(x) for x in d])
    assert np.allclose(d[0],1)
    dn=dunnett(d,nm)
    line=f"  {ag:8s} {meas:8s}"
    for i in (1,2,3):
        x=d[i]
        gm=np.exp(np.mean(np.log(np.clip(x,1e-3,None))))
        # one-sample tests
        if (x>0).all():
            p1=stats.ttest_1samp(np.log2(x),0).pvalue
        else:
            p1=np.nan
        try: pw=stats.wilcoxon(x-1).pvalue
        except Exception: pw=np.nan
        up=(x>1).sum()
        line+=f" | {nm[i]}: mean={x.mean():.2f} median={np.median(x):.2f} up={up}/11 Dunnett p={dn[('d0',nm[i])][1]:.3g} log-t p={p1:.3g} Wilcoxon p={pw:.3g}"
        rows.append((ag,meas,nm[i],x.mean(),np.median(x),up,dn[('d0',nm[i])][1],p1,pw,x.max()))
    print(line)
    print('        REPORTED', [(ws[f'G{r}'].value, ws[f'H{r}'].value, ws[f'L{r}'].value) for r in rep])
import pandas as pd
df=pd.DataFrame(rows,columns=['agonist','measure','day','mean','median','n_up','p_dunnett','p_logt','p_wilcoxon','max'])
df.to_csv(os.path.join(HERE,'fig7c_reanalysis.csv'),index=False)
print(df[df.day=='d14'].to_string())
# Without the largest responder at d14
print('== influence of single volunteer at d14 (collagen)')
for ag,meas,r0,r1,cols,rep in blocks[:3]:
    d=[col(ws,c,r0,r1) for c in cols]
    x=d[3]; i=np.argmax(x)
    print(f"  {ag} {meas}: d14 values {np.round(x,2)}; max={x[i]:.2f} (volunteer row {i+1}); mean w/o max={np.delete(x,i).mean():.2f}; Wilcoxon w/o max p={stats.wilcoxon(np.delete(x,i)-1).pvalue:.3g}")

print('\n== Fig 7d / 7e / 7g')
ws=sheet('Fig. 7d')
# blocks: gene label rows at A6 (ITGA2B) & H6 (P2RY12); A25 GP6 / H25 GPIBA; A44 F2R / H44 ADAR2A; A63 FCGR2A/H63 RUNX1; A82 RAB4A/H82 RAB27B; A100 PITPNB
blocks=[(6,'A','CDEF'),(6,'H','IJKL'),(25,'A','CDEF'),(25,'H','IJKL'),(44,'A','CDEF'),(44,'H','IJKL'),(63,'A','CDEF'),(63,'H','IJKL'),(82,'A','CDEF'),(82,'H','IJKL'),(100,'A','CDEF')]
import pandas as pd
res=[]
for r0,gc,cols in blocks:
    gene=ws[f'{gc}{r0}'].value
    # ΔCT rows: r0+1..r0+12 (3 tech reps x 4 days), norm rows r0+13..r0+16
    dct={}
    for di,day in enumerate(['0d','3d','7d','14d']):
        vals=np.array([[ws[f'{c}{r0+1+di*3+k}'].value for c in cols] for k in range(3)],float)  # 3 tech reps x 4 volunteers
        dct[day]=vals
    norm={day: np.array([ws[f'{c}{r0+13+di}'].value for c in cols],float) for di,day in enumerate(['0d','3d','7d','14d'])}
    # recompute fold from mean dCT (higher = more expr as in other sheets): 2^(mean dCT_day - mean dCT_0)
    rec={day: 2**(dct[day].mean(axis=0)-dct['0d'].mean(axis=0)) for day in dct}
    # alt: mean of 2^dCT
    rec2={day: (2**dct[day]).mean(axis=0)/(2**dct['0d']).mean(axis=0) for day in dct}
    print(f"== {gene}")
    for day in ['3d','7d','14d']:
        x=norm[day]
        p=stats.ttest_1samp(np.log2(x),0).pvalue
        print(f"   {day}: reported norm {np.round(x,2)} | recomputed(2^ΔΔ of mean ΔCT) {np.round(rec[day],2)} | alt(mean 2^ΔCT) {np.round(rec2[day],2)} | geo-mean={2**np.mean(np.log2(x)):.2f} up={int((x>1).sum())}/4 one-sample log-t p={p:.3g}")
        res.append((gene,day,*x,2**np.mean(np.log2(x)),int((x>1).sum()),p))
    print('   ΔCT d0 per volunteer (mean of 3):', np.round(dct['0d'].mean(axis=0),2))
df=pd.DataFrame(res,columns=['gene','day','V1','V2','V3','V4','geomean','n_up','p_logt'])
df.to_csv(os.path.join(HERE,'fig7d_summary.csv'),index=False)
print(df.to_string())
print('== Fig 7e densitometry (n=4)'); ws=sheet('Fig. 7e')
for title,r0,rep in [('GP6/ACTB',4,(4,5,6)),('P2RY12/ACTB',12,(12,13,14))]:
    d=[col(ws,c,r0,r0+3) for c in 'BCDE']; nm=['d0','d3','d7','d14']
    F,p,tk=tukey(d,nm)
    print('  ',title,[f"{n}: {np.round(x,2)} m={x.mean():.2f}" for n,x in zip(nm,d)],'ANOVA p=%.3g'%p)
    for k,v in tk.items():
        if k[0]=='d0': print('      Tukey',k,round(v[0],3),'%.3g'%v[1])
    for r in rep: print('      REPORTED', ws[f'G{r}'].value, ws[f'H{r}'].value, ws[f'L{r}'].value)
    for i in (1,2,3): print(f"      paired t d0 vs {nm[i]}: p={stats.ttest_rel(d[0],d[i]).pvalue:.3g}; ratio of means x{d[i].mean()/d[0].mean():.2f}; per-volunteer ratios {np.round(d[i]/d[0],2)}")
print('== Fig 7g human donor platelets -> mice'); ws=sheet('Fig. 7g')
for title,r0 in [('Lung weight',4),('Met burden',12),('Foci',19)]:
    a=col(ws,'B',r0,r0+4); b=col(ws,'C',r0,r0+4); r=ttest(a,b)
    print(f"   {title}: d0 donors {a} ({desc(a)}) | d7 donors {b} ({desc(b)}) x{b.mean()/a.mean():.2f} t={r['t']:.3f} p={r['p']:.3g} Welch {r['p_welch']:.3g} MWU {r['p_mwu']:.3g}")
