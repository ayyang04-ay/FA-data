#!/usr/bin/env bash
# Re-runs the whole re-analysis. Needs python with openpyxl, numpy, scipy, pandas, statsmodels, matplotlib.
# In the analysis sandbox:  PY="micromamba run -n singlecell python" bash run_all.sh
# Data location can be changed with CRE_DATA=/path/to/files (default /tmp/world/filesystem).
set -euo pipefail
cd "$(dirname "$0")"
PY=${PY:-python}
for s in 01_verify_reported_stats.py 02_metastasis_cohorts_interactions_power.py 03_gene_panels.py 04_human_cohort.py \
         05_phosphoproteomics.py 06_duplicate_scan.py 07_two_group_numbers.py 08_make_appendix.py 09_make_figures.py; do
  echo "=== $s"; $PY "$s" > "log_${s%.py}.txt" 2>&1 || { echo "FAILED: $s"; tail -5 "log_${s%.py}.txt"; exit 1; }
done
echo "all scripts completed"
