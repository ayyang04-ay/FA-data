'''Creatine effect on lung metastatic burden in every cohort, pooled estimate, 2x2 interactions,
survival hazard ratios and the sample-size basis. Output: creatine_effect_cohorts.csv'''
from lib import *
import pandas as pd, os
import statsmodels.api as sm
pd.set_option('display.width',250)
C=[]
def add(name, a, b, note=''):
    a=np.asarray(a,float); b=np.asarray(b,float)
    lr=np.log(b.mean()/a.mean()); se=np.sqrt(a.var(ddof=1)/(len(a)*a.mean()**2)+b.var(ddof=1)/(len(b)*b.mean()**2))
    t=stats.ttest_ind(a,b)
    # log-scale SDs
    C.append(dict(cohort=name,n_ctrl=len(a),n_cre=len(b),mean_ctrl=a.mean(),mean_cre=b.mean(),ratio=b.mean()/a.mean(),lo=np.exp(lr-1.96*se),hi=np.exp(lr+1.96*se),p=t.pvalue,g=hedges_g(a,b),sdlog_ctrl=np.log(a).std(ddof=1),sdlog_cre=np.log(b).std(ddof=1),lr=lr,se=se,note=note))
ws=sheet('Fig. 1b'); add('Fig 1b (oral creatine)', col(ws,'B',3,8), col(ws,'C',3,8))
ws=sheet('Fig. 1k'); add('Fig 1k (second model)', col(ws,'B',4,9), col(ws,'C',4,9))
ws=sheet('Fig. 1f'); add('Fig 1f melanoma sh-scrambled', col(ws,'B',22,27), col(ws,'C',22,27)); add('Fig 1f melanoma sh-Slc6a8', col(ws,'D',22,27), col(ws,'E',22,27))
ws=sheet('Fig. 3i'); add('Fig 3i Pf4-Cre;Slc6a8+/+', col(ws,'B',10,13), col(ws,'C',10,13)); add('Fig 3i Pf4-Cre;Slc6a8fl/fl', col(ws,'D',10,13), col(ws,'E',10,13),'MK-lineage KO')
ws=sheet('Fig. 6b'); add('Fig 6b no inhibitor', col(ws,'B',4,8), col(ws,'C',4,8),'3+3 values shared with S2d'); add('Fig 6b + STAT5-IN-1', col(ws,'D',4,8), col(ws,'E',4,8),'STAT5 inhibitor')
ws=sheet('Supplementary Fig  1e'); add('S1e', col(ws,'B',13,18), col(ws,'C',13,18))
ws=sheet('Supplementary Fig  1f'); add('S1f', col(ws,'B',12,15), col(ws,'C',12,15))
ws=sheet('Supplementary Fig  1g'); add('S1g', col(ws,'B',15,24), col(ws,'C',15,24))
ws=sheet('Supplementary Fig  1i'); add('S1i (5% creatine diet)', col(ws,'B',11,14), col(ws,'C',11,14))
ws=sheet('Supplementary Fig  1k'); add('S1k', col(ws,'B',16,25), col(ws,'C',16,25))
ws=sheet('Supplementary Fig  2d'); add('S2d donor platelets (veh vs creatine donors)', col(ws,'C',5,10), col(ws,'D',5,10),'3+3 values shared with Fig 6b'); add('S2d donor platelets (veh vs creatine+aspirin donors)', col(ws,'C',5,10), col(ws,'E',5,10),'aspirin')
ws=sheet('Fig. 7g'); add('Fig 7g human donor platelets d0 vs d7', col(ws,'B',12,16), col(ws,'C',12,16))
df=pd.DataFrame(C)
print(df[['cohort','n_ctrl','n_cre','mean_ctrl','mean_cre','ratio','lo','hi','p','g','sdlog_ctrl','sdlog_cre','note']].round(3).to_string())
# random-effects meta (DL) across unperturbed direct-dosing cohorts
sel=df[df.cohort.isin(['Fig 1b (oral creatine)','Fig 1k (second model)','Fig 1f melanoma sh-scrambled','Fig 3i Pf4-Cre;Slc6a8+/+','Fig 6b no inhibitor','S1e','S1f','S1g','S1i (5% creatine diet)','S1k'])]
w=1/sel.se**2; mu_f=(w*sel.lr).sum()/w.sum(); Q=(w*(sel.lr-mu_f)**2).sum(); k=len(sel); tau2=max(0,(Q-(k-1))/(w.sum()-(w**2).sum()/w.sum()))
wr=1/(sel.se**2+tau2); mu=(wr*sel.lr).sum()/wr.sum(); se=np.sqrt(1/wr.sum())
print(f"\nDL random-effects pooled ratio of metastatic burden (k={k} cohorts, {int(sel.n_ctrl.sum())} ctrl + {int(sel.n_cre.sum())} creatine mice): {np.exp(mu):.2f} [{np.exp(mu-1.96*se):.2f}, {np.exp(mu+1.96*se):.2f}], tau2={tau2:.3f}, Q={Q:.1f} (df {k-1}), I2={max(0,(Q-(k-1))/Q)*100:.0f}%")
print('range of ratios:', sel.ratio.min().round(2), sel.ratio.max().round(2))
# pooled log-SD (within-group) across all groups
sds=np.r_[df.sdlog_ctrl.values, df.sdlog_cre.values]; ns=np.r_[df.n_ctrl.values, df.n_cre.values]
pooled=np.sqrt(((ns-1)*sds**2).sum()/(ns-1).sum())
print('pooled within-group SD of ln(burden):', pooled.round(3), ' median', np.median(sds).round(3), ' 75th pct', np.quantile(sds,.75).round(3))
df.to_csv(os.path.join(HERE,'creatine_effect_cohorts.csv'),index=False)
# Power for 2x2 interaction on log scale
from scipy.stats import nct, t as tdist
def power_interaction(delta, sd, n, alpha=0.05):
    se=sd*np.sqrt(4/n); dfree=4*(n-1); ncp=delta/se; tc=tdist.ppf(1-alpha/2,dfree)
    return 1-nct.cdf(tc,dfree,ncp)+nct.cdf(-tc,dfree,ncp)
obs=np.log((7.911/2.365)/(2.875/3.391))
print('observed ratio-of-ratios Fig 3i:', np.exp(obs).round(2), 'ln=',obs.round(3))
for sd in (pooled, 0.5, 0.6):
    for rr in (np.exp(obs), 3.0, 2.5, 2.0):
        for target in (0.8,0.9):
            n=3
            while power_interaction(np.log(rr), sd, n)<target: n+=1
            print(f"  sd_ln={sd:.2f} ratio-of-ratios={rr:.2f} power>={target}: n={n}/group")
# power for simple 2-group comparison creatine-KO vs creatine-WT, ratio
def power_two(delta, sd, n, alpha=0.05):
    se=sd*np.sqrt(2/n); dfree=2*(n-1); ncp=delta/se; tc=tdist.ppf(1-alpha/2,dfree)
    return 1-nct.cdf(tc,dfree,ncp)+nct.cdf(-tc,dfree,ncp)
for rr in (2.75,2.0,1.5):
    for target in (0.8,0.9):
        n=3
        while power_two(np.log(rr), pooled, n)<target: n+=1
        print(f"  two-group ratio {rr}: power>={target}: n={n}/group (sd_ln {pooled:.2f})")

print('\n== 2x2 interactions on the log scale (ratio-of-ratios)')
def ror(g, label):
    a,b,c,d=[np.log(x) for x in g]
    y=np.concatenate([a,b,c,d]); cre=np.r_[np.zeros(len(a)),np.ones(len(b)),np.zeros(len(c)),np.ones(len(d))]; per=np.r_[np.zeros(len(a)+len(b)),np.ones(len(c)+len(d))]
    m=sm.OLS(y,sm.add_constant(np.c_[cre,per,cre*per])).fit()
    ci=m.conf_int()[3]
    # geometric-mean ratios
    e_ctrl=np.exp(b.mean()-a.mean()); e_per=np.exp(d.mean()-c.mean())
    # residual: perturbed+creatine vs control vehicle
    t=stats.ttest_ind(d,a); diff=d.mean()-a.mean(); se=np.sqrt(d.var(ddof=1)/len(d)+a.var(ddof=1)/len(a)); dfw=len(a)+len(d)-2
    sp=np.sqrt(((len(a)-1)*a.var(ddof=1)+(len(d)-1)*d.var(ddof=1))/dfw); se=sp*np.sqrt(1/len(a)+1/len(d)); tc=stats.t.ppf(.975,dfw)
    print(f"{label}: geo-mean creatine effect ctrl x{e_ctrl:.2f}, perturbed x{e_per:.2f}; ratio-of-ratios (ctrl/perturbed) = {np.exp(-m.params[3]):.2f} [{np.exp(-ci[1]):.2f}, {np.exp(-ci[0]):.2f}], interaction p(log)={m.pvalues[3]:.2g}; residual (perturbed+creatine vs ctrl vehicle) x{np.exp(diff):.2f} [{np.exp(diff-tc*se):.2f}, {np.exp(diff+tc*se):.2f}] p={t.pvalue:.2g}; resid sd_ln={np.sqrt(m.mse_resid):.2f}")
ws=sheet('Fig. 3i')
ror([col(ws,c,10,13) for c in 'BCDE'],'Fig 3i burden (Slc6a8 MK KO)')
ror([col(ws,c,17,20) for c in 'BCDE'],'Fig 3i foci   (Slc6a8 MK KO)')
ror([col(ws,c,3,6) for c in 'BCDE'],'Fig 3i lung wt (Slc6a8 MK KO)')
ws=sheet('Fig. 6b')
ror([col(ws,c,4,8) for c in 'BCDE'],'Fig 6b burden (STAT5-IN-1)')
ror([col(ws,c,13,17) for c in 'BCDE'],'Fig 6b foci   (STAT5-IN-1)')
ws=sheet('Fig. 1f')
ror([col(ws,c,22,27) for c in 'BCDE'],'Fig 1f burden (tumour sh-Slc6a8)')
ror([col(ws,c,31,36) for c in 'BCDE'],'Fig 1f foci   (tumour sh-Slc6a8)')
ror([col(ws,c,4,9) for c in 'BCDE'],'Fig 1f lung wt (tumour sh-Slc6a8)')
ror([col(ws,c,13,18) for c in 'BCDE'],'Fig 1f SUV (tumour sh-Slc6a8)')

print('\n== Survival (log-rank, Mantel-Haenszel hazard ratio)')
def logrank(t1, e1, t2, e2):
    t1=np.asarray(t1,float); t2=np.asarray(t2,float); e1=np.asarray(e1,int); e2=np.asarray(e2,int)
    times = np.unique(np.concatenate([t1[e1==1], t2[e2==1]]))
    O1=E1=V=0.0
    for t in times:
        n1=(t1>=t).sum(); n2=(t2>=t).sum(); n=n1+n2
        d1=((t1==t)&(e1==1)).sum(); d2=((t2==t)&(e2==1)).sum(); d=d1+d2
        O1+=d1; E1+=d*n1/n
        if n>1: V+=d*(n1/n)*(n2/n)*(n-d)/(n-1)
    chi=(O1-E1)**2/V
    return chi, stats.chi2.sf(chi,1), O1, E1, V
def med(t):
    t=np.sort(np.asarray(t,float)); 
    # KM median with all events: smallest t with S(t)<=0.5
    n=len(t)
    for i,x in enumerate(t):
        if (n-(i+1))/n <= 0.5: 
            # prism: if S hits exactly 0.5, average with next time
            if (n-(i+1))/n == 0.5 and i+1<n: return (x+t[i+1])/2
            return x
for name,(r0,r1,r2,r3),rep in [('Fig. 1c',(4,13,14,23),('F6','F8')),('Fig. 1l',(4,23,24,41),('F5','F7'))]:
    ws=sheet(name)
    tv=col(ws,'A',r0,r1); tc=col(ws,'A',r2,r3)
    # check event indicators
    ev=[ws[f'B{r}'].value for r in range(r0,r1+1)]; ec=[ws[f'C{r}'].value for r in range(r2,r3+1)]
    chi,p,O,E,V=logrank(tv,ev,tc,ec)
    # hazard ratio (Mantel-Haenszel) creatine vs vehicle
    chi2,p2,O2,E2,V2=logrank(tc,ec,tv,ev)
    hr=np.exp((O2-E2)/V2); lo=np.exp((O2-E2)/V2-1.96/np.sqrt(V2)); hi=np.exp((O2-E2)/V2+1.96/np.sqrt(V2))
    print(name, f"vehicle n={len(tv)} events={sum(ev)} median={med(tv)} range {tv.min()}-{tv.max()}; creatine n={len(tc)} events={sum(ec)} median={med(tc)} range {tc.min()}-{tc.max()}")
    print(f"   logrank chi2={chi:.3f} p={p:.4f} | reported chi2={ws[rep[0]].value} p={ws[rep[1]].value} | HR(MH) creatine vs vehicle={hr:.2f} [{lo:.2f},{hi:.2f}]")
    print('   vehicle times', tv, '\n   creatine times', tc)

print('\n== Cox proportional-hazards estimate (Efron ties), as quoted in the proposal')
from statsmodels.duration.hazard_regression import PHReg
for name,(r0,r1,r2,r3) in [('Fig. 1c',(4,13,14,23)),('Fig. 1l',(4,23,24,41))]:
    ws=sheet(name); tv=col(ws,'A',r0,r1); tc=col(ws,'A',r2,r3)
    t=np.r_[tv,tc]; g=np.r_[np.zeros(len(tv)),np.ones(len(tc))]
    m=PHReg(t,g[:,None],status=np.ones(len(t)),ties='efron').fit(); ci=m.conf_int()[0]
    print(name,'Cox HR creatine vs vehicle = %.2f [%.2f, %.2f], Wald p = %.4f'%(np.exp(m.params[0]),np.exp(ci[0]),np.exp(ci[1]),m.pvalues[0]))

print('\n== Residual-permutation (Freedman-Lane) check of the interactions, raw scale / log scale')
for nm,(r0,r1) in [('Fig. 3i',(10,13)),('Fig. 6b',(4,8)),('Fig. 1f',(22,27))]:
    ws=sheet(nm); g=[col(ws,c,r0,r1) for c in 'BCDE']
    print(nm,'burden: permutation P raw = %.5f, log = %.5f'%(freedman_lane(g,log=False),freedman_lane(g,log=True)))
