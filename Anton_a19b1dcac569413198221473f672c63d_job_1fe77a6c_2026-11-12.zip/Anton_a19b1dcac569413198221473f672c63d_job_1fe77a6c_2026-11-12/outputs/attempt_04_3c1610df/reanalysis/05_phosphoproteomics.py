'''Phosphoproteomics table (creatine vs vehicle megakaryocytes, n = 3 mice per group).
Counts at the study's screening criteria, Q-value range, Benjamini-Hochberg check, tied-P patterns,
and where Stat5b sits. Outputs: phos.pkl (cached table), phospho_summary.txt, phospho_top50.csv'''
from lib import *
import pandas as pd, os
from statsmodels.stats.multitest import multipletests
ws = openpyxl.load_workbook(PHOS).worksheets[0]
rows = list(ws.iter_rows(values_only=True))
df = pd.DataFrame(rows[1:], columns=['gene', 'p', 'q', 'lfc'])
df['row'] = np.arange(2, len(df) + 2)          # Excel row number
df.to_pickle(os.path.join(HERE, 'phos.pkl'))
L = []
def w(s=''):
    print(s); L.append(s)
w(f"header: {rows[0]}")
w(f"rows {len(df)}, gene names {df.gene.nunique()}, unnamed rows {int(df.gene.isna().sum())}")
fixed = np.isclose(df.p, 2 * stats.t.sf(1, 2))   # t = 1 on 2 df -> P = 0.42265
t = df[~fixed]
w(f"rows with P exactly 0.4226 (one-of-three-replicates pattern): {int(fixed.sum())} ({100*fixed.mean():.1f}%); |lfc| median {df.lfc[fixed].abs().median():.2f}")
band = t[(t.p > 0.17) & (t.p < 0.20) & (t.lfc.abs() > 2)]
w(f"rows in the P = 0.18-0.20 band with |lfc| > 2 (two-of-three pattern): {len(band)}")
w(f"testable rows: {len(t)}; P < 0.05: {int((t.p < 0.05).sum())}; expected by chance {0.05*len(t):.0f}")
w(f"Q column: min {df.q.min():.4f}, max {df.q.max():.4f}; rows with Q < 0.05: {int((df.q < 0.05).sum())}; Q < 0.25: {int((df.q < 0.25).sum())}")
bh = multipletests(df.p, method='fdr_bh')[1]
w(f"Benjamini-Hochberg recomputed from the P column: min {bh.min():.3f}")
for base, nm in [(2, 'log2'), (10, 'log10'), (np.e, 'ln')]:
    up = np.log(1.2) / np.log(base); dn = np.log(0.83) / np.log(base)
    w(f"screening criteria (P < 0.05, FC >= 1.2 or <= 0.83) if {nm}: up {int(((df.p < 0.05) & (df.lfc >= up)).sum())}, down {int(((df.p < 0.05) & (df.lfc <= dn)).sum())}")
sig = t[t.p < 0.05]
w(f"P < 0.05: up {int((sig.lfc > 0).sum())}, down {int((sig.lfc < 0).sum())}")
big = sig[sig.lfc.abs() >= 3]
w(f"P < 0.05 and |lfc| >= 3 (three-of-three versus none pattern): {len(big)} rows; up {int((big.lfc > 0).sum())}, down {int((big.lfc < 0).sum())}")
df['rank_p'] = df.p.rank(method='min').astype(int)
for g in ['Stat5b', 'Stat5a', 'Ckb', 'Slc6a8', 'Gp6', 'P2ry12', 'Rab4a']:
    r = df[df.gene == g]
    w(f"{g}: {len(r)} row(s) " + '; '.join(f"[Excel row {int(x.row)}: P={x.p:.5f}, Q={x.q:.3f}, lfc={x.lfc:.2f}, rank by P {x.rank_p}]" for _, x in r.iterrows()))
up = sig[sig.lfc > 0].sort_values('lfc', ascending=False).reset_index()
w(f"Stat5b rank by fold-change among nominal 'up' rows: {int(up.index[up.gene == 'Stat5b'][0]) + 1} of {len(up)}")
# presence/absence patterns reproduce the tied P values
for a, b, lab in [([5, 0, 0], [0, 0, 0], 'one of three'), ([5, 5, 0], [0, 0, 0], 'two of three'), ([5, 5.6, 5.3], [0, 0, 0], 'three of three')]:
    w(f"Welch t test, {lab} replicates quantified vs none: P = {stats.ttest_ind(a, b, equal_var=False).pvalue:.4f}")
df.sort_values('p').head(50).to_csv(os.path.join(HERE, 'phospho_top50.csv'), index=False)
open(os.path.join(HERE, 'phospho_summary.txt'), 'w').write('\n'.join(L) + '\n')
