'''Builds the three figures in ../figures from the raw workbook and the CSV outputs of scripts 02-05.'''
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, NullLocator, NullFormatter
from lib import *
import pandas as pd, os
os.chdir(HERE)
os.makedirs(os.path.join(OUT,'figures'),exist_ok=True)
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
rng=np.random.default_rng(1)
BLUE='#1f4e79'; RED='#c0392b'; GREEN='#2e8b57'; GREY='#7f8c8d'; ORANGE='#e67e22'; PURPLE='#8e44ad'

def dots(ax, groups, labels, colors, title, ylabel, mark=None):
    for i,(g,c) in enumerate(zip(groups,colors)):
        x=i+rng.uniform(-0.13,0.13,len(g))
        ax.scatter(x,g,s=30,color=c,alpha=0.9,zorder=3,edgecolor='k',linewidth=0.3)
        if mark is not None and mark[i] is not None:
            m=np.isin(np.round(g,4),np.round(mark[i],4))
            ax.scatter(x[m],np.asarray(g)[m],s=90,facecolor='none',edgecolor='k',linewidth=1.2,zorder=4)
        ax.plot([i-0.28,i+0.28],[np.mean(g)]*2,color='k',lw=1.6,zorder=5)
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(labels,fontsize=8)
    ax.set_ylabel(ylabel); ax.set_title(title,loc='left',fontsize=9.5); ax.set_ylim(bottom=0)

# ================= FIGURE 1 =================
fig=plt.figure(figsize=(15.5,6.2))
gs=fig.add_gridspec(1,3,width_ratios=[2.6,1.25,1.25],wspace=0.32)
ax=fig.add_subplot(gs[0,0])
df=pd.read_csv('creatine_effect_cohorts.csv')
order=['Fig 1b (oral creatine)','Fig 1k (second model)','S1e','S1f','S1g','S1k','S1i (5% creatine diet)','Fig 1f melanoma sh-scrambled','Fig 1f melanoma sh-Slc6a8','Fig 3i Pf4-Cre;Slc6a8+/+','Fig 6b no inhibitor','S2d donor platelets (veh vs creatine donors)','Fig 7g human donor platelets d0 vs d7','Fig 3i Pf4-Cre;Slc6a8fl/fl','Fig 6b + STAT5-IN-1','S2d donor platelets (veh vs creatine+aspirin donors)']
lab={'Fig 1b (oral creatine)':'Fig 1b  oral creatine (6+6)','Fig 1k (second model)':'Fig 1k  second cohort (6+6)','S1e':'Supp 1e (6+6)','S1f':'Supp 1f (4+4)','S1g':'Supp 1g (10+10)','S1k':'Supp 1k (10+10)','S1i (5% creatine diet)':'Supp 1i  5% creatine diet (4+4)',
     'Fig 1f melanoma sh-scrambled':'Fig 1f  melanoma, sh-scrambled (6+6)','Fig 1f melanoma sh-Slc6a8':'Fig 1f  melanoma, tumour sh-Slc6a8 (6+6)','Fig 3i Pf4-Cre;Slc6a8+/+':'Fig 3i  Pf4-Cre;Slc6a8+/+ (4+4)','Fig 6b no inhibitor':'Fig 6b  no-inhibitor arms (5+5)*',
     'S2d donor platelets (veh vs creatine donors)':'Supp 2d  platelets: creatine vs vehicle donors (6+6)*','Fig 7g human donor platelets d0 vs d7':'Fig 7g  human platelets: day-7 vs day-0 donors (5+5)',
     'Fig 3i Pf4-Cre;Slc6a8fl/fl':'Fig 3i  Pf4-Cre;Slc6a8fl/fl (4+4)','Fig 6b + STAT5-IN-1':'Fig 6b  + STAT5-IN-1 arms (5+5)','S2d donor platelets (veh vs creatine+aspirin donors)':'Supp 2d  platelets: creatine+aspirin vs vehicle donors (6+6)'}
cols={k:BLUE for k in order}
for k in ['Fig 3i Pf4-Cre;Slc6a8fl/fl','Fig 6b + STAT5-IN-1','S2d donor platelets (veh vs creatine+aspirin donors)']: cols[k]=RED
for k in ['S2d donor platelets (veh vs creatine donors)','Fig 7g human donor platelets d0 vs d7']: cols[k]=GREEN
y=np.arange(len(order))[::-1]
for yi,k in zip(y,order):
    r=df[df.cohort==k].iloc[0]
    ax.plot([r.lo,r.hi],[yi,yi],color=cols[k],lw=1.8); ax.plot(r.ratio,yi,'o',color=cols[k],ms=6.5)
    ax.text(8.6,yi,f"{r.ratio:.2f} [{r.lo:.2f}-{r.hi:.2f}]",va='center',fontsize=8,family='monospace')
ax.axvline(1,color='k',lw=0.8,ls='--'); ax.axvline(3.02,color=BLUE,lw=0.9,ls=':')
ax.set_xscale('log'); ax.set_xlim(0.38,18)
ax.xaxis.set_major_locator(FixedLocator([0.5,1,2,3,5,8])); ax.xaxis.set_minor_locator(NullLocator()); ax.set_xticklabels(['0.5','1','2','3','5','8'])
ax.set_yticks(y); ax.set_yticklabels([lab[k] for k in order],fontsize=8.3)
ax.set_ylim(-0.8,len(order)-0.3)
ax.set_xlabel('Creatine (or creatine-conditioned platelets) vs control: ratio of mean lung metastatic burden, 95% CI\n'
              'blue = unperturbed host, direct dosing (pooled 3.02, dotted)   green = platelet transfer   red = pathway perturbed\n'
              '* Fig 6b and Supp 2d share 3+3 identical animal values (data-integrity flag)',fontsize=8)
ax.set_title('a  Creatine effect on metastatic burden, every cohort in the package',loc='left',fontsize=10)
ws=sheet('Fig. 3i'); g=[col(ws,c,10,13) for c in 'BCDE']
ax=fig.add_subplot(gs[0,1])
dots(ax,g,['Cre ctrl\nvehicle','Cre ctrl\ncreatine','Slc6a8 KO\nvehicle','Slc6a8 KO\ncreatine'],[GREY,BLUE,GREY,RED],'b  Fig 3i: MK-lineage Slc6a8 deletion\n   n=4/group; interaction P=0.0003','Metastatic burden (%)')
ax.set_ylim(0,12.5); ax.text(0.03,0.97,'creatine: x3.35 in Cre control\n          x0.85 in KO',transform=ax.transAxes,fontsize=8,va='top',family='monospace')
ws=sheet('Fig. 6b'); g=[col(ws,c,4,8) for c in 'BCDE']
ax=fig.add_subplot(gs[0,2])
dots(ax,g,['vehicle','creatine','vehicle\n+inhibitor','creatine\n+inhibitor'],[GREY,BLUE,GREY,RED],'c  Fig 6b: STAT5-IN-1 (STAT5A+B, systemic)\n   n=5/group; interaction P=7e-6','Metastatic burden (%)',mark=[[3.29136,3.733544,2.886353],[11.13465,13.22011,14.12619],None,None])
ax.set_ylim(0,21.5); ax.text(0.03,0.97,'creatine: x4.02 without inhibitor\n          x1.24 with inhibitor\ncircled = values also in Supp 2d',transform=ax.transAxes,fontsize=8,va='top',family='monospace')
fig.savefig(os.path.join(OUT,'figures')+'/fig1_metastasis_evidence.png',dpi=170,bbox_inches='tight'); plt.close(fig)

# ================= FIGURE 2 =================
fig=plt.figure(figsize=(15.5,5.8))
gs=fig.add_gridspec(1,2,width_ratios=[1.25,1],wspace=0.2)
ax=fig.add_subplot(gs[0,0])
b=pd.read_csv('gene_block_summary.csv').set_index('gene')
genes=list(b.index); x=np.arange(len(genes)); w=0.2
series=[('Slc6a8KO_cre','MK-Slc6a8 KO + creatine (Fig 3f, in vivo)',RED),('Stat5bKO_cre','MK-Stat5b KO + creatine (Fig 6g, in vivo)',ORANGE),('Cre_inh','STAT5-IN-1 + creatine (Fig 6a, in vivo)',PURPLE),('Cre_siCkb','si-Ckb + creatine (Fig 4j, in vitro)',GREEN)]
for i,(c,l,colr) in enumerate(series):
    ax.bar(x+(i-1.5)*w,b[c],w,color=colr,label=l,edgecolor='k',linewidth=0.3)
ax.plot(x,np.c_[b.WTcre_3f,b.WTcre_6g,b.Cre_siScr].mean(axis=1),linestyle='none',marker='_',color='k',ms=16,mew=2,label='creatine, unperturbed control (mean of Fig 3f, 6g, 4j)')
ax.axhline(1,color='k',lw=0.8,ls='--')
ax.set_xticks(x); ax.set_xticklabels(genes,fontsize=9,style='italic'); ax.set_ylabel('Megakaryocyte mRNA, fold of untreated control (n=3 per group)')
ax.set_ylim(0,7.4); ax.legend(fontsize=8,frameon=False,ncol=2,loc='upper left')
ax.set_title('a  Residual platelet-gene induction under creatine, by node perturbed',loc='left',fontsize=10)
ax=fig.add_subplot(gs[0,1])
p=pd.read_pickle('phos.pkl'); fixed=np.isclose(p.p,0.422649730810374)
ax.scatter(p.lfc[fixed],-np.log10(p.p[fixed]),s=3,color='#d5d8dc',label=f'fixed P=0.4226, untestable (n={fixed.sum():,})',rasterized=True)
t=p[~fixed]
ax.scatter(t.lfc,-np.log10(t.p),s=4,color='#85929e',label=f'testable rows (n={len(t):,})',rasterized=True)
sig=t[t.p<0.05]; ax.scatter(sig.lfc,-np.log10(sig.p),s=7,color=BLUE,label=f'P<0.05 (n={len(sig)}; ~{0.05*len(t):.0f} expected by chance)',rasterized=True)
s=p.loc[1507]; ax.scatter([s.lfc],[-np.log10(s.p)],s=80,color=RED,edgecolor='k',zorder=5)
ax.annotate(f"Stat5b: P={s.p:.4f}, q={s.q:.2f}\nrank 17 of 5,812; site not in file",(s.lfc,-np.log10(s.p)),xytext=(0.2,4.0),fontsize=8.5,arrowprops=dict(arrowstyle='-',lw=0.6))
s2=p.loc[1506]; ax.scatter([s2.lfc],[-np.log10(s2.p)],s=45,color=RED,edgecolor='k',zorder=5,marker='s')
ax.annotate('2nd Stat5b row, P=0.47',(s2.lfc,-np.log10(s2.p)),xytext=(1.6,0.05),fontsize=8,arrowprops=dict(arrowstyle='-',lw=0.6))
s3=p[p.gene=='Stat5a'].iloc[0]; ax.scatter([s3.lfc],[-np.log10(s3.p)],s=45,color=ORANGE,edgecolor='k',zorder=5,marker='^'); ax.annotate('Stat5a, P=0.40',(s3.lfc,-np.log10(s3.p)),xytext=(-4.6,0.05),fontsize=8,arrowprops=dict(arrowstyle='-',lw=0.6))
ax.axhline(-np.log10(0.05),color='k',lw=0.6,ls='--'); ax.text(-8.6,-np.log10(0.05)+0.05,'P = 0.05',fontsize=8)
ax.set_xlabel('LOG_FOLDCHANGE, creatine vs vehicle megakaryocytes (n=3 mice per group)'); ax.set_ylabel('-log10 P (unpaired two-tailed t-test)')
ax.set_ylim(0,5.2); ax.legend(fontsize=8,frameon=False,loc='upper left')
ax.set_title(f'b  Phosphoproteomics: minimum q = {p.q.min():.2f}; no row passes FDR',loc='left',fontsize=10)
fig.savefig(os.path.join(OUT,'figures')+'/fig2_node_comparison_phospho.png',dpi=170,bbox_inches='tight'); plt.close(fig)

# ================= FIGURE 3 (human) =================
fig=plt.figure(figsize=(16.5,6.0))
gs=fig.add_gridspec(1,3,width_ratios=[0.75,1.75,1.35],wspace=0.27)
ws=sheet('Fig. 7b'); d=[col(ws,c,4,14) for c in 'BCDE']
ax=fig.add_subplot(gs[0,0])
for i in range(11): ax.plot([0,3,7,14],[d[k][i] for k in range(4)],color=GREY,lw=0.8,alpha=0.8,marker='o',ms=3)
ax.plot([0,3,7,14],[x.mean() for x in d],color=BLUE,lw=2.2,marker='o')
ax.set_xticks([0,3,7,14]); ax.set_xlabel('Day of 20 g/day creatine'); ax.set_ylabel('Serum creatine (uM)'); ax.set_ylim(0,230)
ax.set_title('a  Fig 7b: exposure, n=11\n   x3.4-3.5 from day 3',loc='left',fontsize=10)
ws=sheet('Fig. 7c')
blocks=[('Collagen',[(4,14),(18,28),(32,42)]),('Epinephrine',[(46,56),(60,70),(74,84)]),('Arachidonic acid',[(88,98),(102,112),(116,126)]),('ADP',[(130,140),(144,154),(157,167)])]
ax=fig.add_subplot(gs[0,1])
pos=0; xt=[]; xl=[]
from scipy import stats as st
for ag,rr in blocks:
    for (r0,r1),m in zip(rr,['max agg.','mean agg.','adhesion']):
        x14=col(ws,'E',r0,r1)
        pw=st.wilcoxon(x14-1).pvalue
        xx=pos+rng.uniform(-0.16,0.16,len(x14))
        ax.scatter(xx,np.clip(x14,0.2,None),s=18,color=BLUE if pw<0.05 else GREY,alpha=0.85,edgecolor='k',linewidth=0.2)
        ax.plot([pos-0.3,pos+0.3],[np.median(x14)]*2,color='k',lw=1.6)
        ax.text(pos,62,f"{int((x14>1).sum())}/11 up, P={pw:.3f}",ha='center',va='bottom',fontsize=7.5,rotation=90)
        xt.append(pos); xl.append(m); pos+=1
    ax.text(pos-2,0.135,ag,ha='center',fontsize=9,weight='bold')
    pos+=0.7
ax.axhline(1,color='k',lw=0.8,ls='--'); ax.set_yscale('log'); ax.set_ylim(0.12,900)
ax.yaxis.set_major_locator(FixedLocator([0.25,0.5,1,2,4,8,16,32])); ax.yaxis.set_minor_locator(NullLocator()); ax.set_yticklabels(['0.25','0.5','1','2','4','8','16','32'])
ax.set_xticks(xt); ax.set_xticklabels(xl,fontsize=7.5,rotation=30,ha='right')
ax.set_ylabel('Day 14 / day 0 (fold, log scale; bar = median;\nP = Wilcoxon signed-rank vs no change)')
ax.set_title('b  Fig 7c: platelet function, day 14 vs day 0, n=11\n   collagen and epinephrine responses rise; ADP does not',loc='left',fontsize=10)
ax=fig.add_subplot(gs[0,2])
h=pd.read_csv('fig7d_summary.csv')
genes=['GP6','P2RY12','RAB4A','ITGA2B','GPIBA','F2R','ADAR2A','FCGR2A','RUNX1','RAB27B','PITPNB']
M=[]
for g in genes:
    rowv=[]
    for day in ['3d','7d','14d']:
        r=h[(h.gene==g)&(h.day==day)].iloc[0]; rowv+= [r.V1,r.V2,r.V3,r.V4]
    M.append(rowv)
M=np.log2(np.array(M))
im=ax.imshow(M,cmap='RdBu_r',vmin=-4,vmax=4,aspect='auto')
ax.set_yticks(range(len(genes))); ax.set_yticklabels([g if g!='ADAR2A' else 'ADRA2A*' for g in genes],fontsize=8.5,style='italic')
ax.set_xticks(range(12)); ax.set_xticklabels(['V1','V2','V3','V4']*3,fontsize=7.5)
for k,dd in enumerate(['day 3','day 7','day 14']): ax.text(1.5+4*k,-0.75,dd,ha='center',fontsize=9)
ax.axvline(3.5,color='k',lw=1); ax.axvline(7.5,color='k',lw=1)
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        ax.text(j,i,f"{2**M[i,j]:.1f}",ha='center',va='center',fontsize=6.5,color='k' if abs(M[i,j])<2.6 else 'w')
ax.spines['top'].set_visible(True); ax.spines['right'].set_visible(True)
cb=fig.colorbar(im,ax=ax,fraction=0.04,pad=0.02); cb.set_label('log2 fold vs own day 0',fontsize=8)
ax.set_title('c  Fig 7d: CD41+ cell transcripts, 4 volunteers\n',loc='left',fontsize=10)
ax.set_xlabel('RAB4A falls in 4/4 at day 14; V2 is a non-responder for most genes.\n*sheet label "ADAR2A". PITPNB and RAB27B V4 folds are not reproducible from the listed dCT values.',fontsize=7.5)
fig.savefig(os.path.join(OUT,'figures')+'/fig3_human_cohort.png',dpi=170,bbox_inches='tight'); plt.close(fig)
print('saved')
