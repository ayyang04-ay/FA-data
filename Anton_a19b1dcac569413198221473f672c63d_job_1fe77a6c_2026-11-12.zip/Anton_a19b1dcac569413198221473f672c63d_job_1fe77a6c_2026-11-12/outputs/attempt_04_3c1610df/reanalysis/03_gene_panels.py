'''MK platelet-gene panels (qPCR sheets): fold by group, t tests on log2 values, and residual induction
under creatine when each node is perturbed. Outputs: qpcr_reanalysis.csv, gene_block_summary.csv'''
from lib import *
import pandas as pd, os
pd.set_option('display.width',250)
rows=[]
def comp(panel, gene, b, x, y):
    t=stats.ttest_ind(np.log2(b[x]),np.log2(b[y]))
    rows.append(dict(panel=panel,gene=gene,ref=x,test=y,ref_mean=b[x].mean(),test_mean=b[y].mean(),fold=b[y].mean()/b[x].mean(),p_log2_t=t.pvalue,n_ref=len(b[x]),n_test=len(b[y])))
o,_=parse_qpcr('Fig. 2f',3)
for g,b in o.items(): comp('Fig 2f',g,b,'Vehicle','Creatine')
o,_=parse_qpcr('Fig. 3f',7)
ks=['PF4 cre; Slc6a8+/+-vehicle','PF4 cre; Slc6a8+/+-creatine','PF4 cre; Slc6a8flox/flox-vehicle','PF4 cre; Slc6a8flox/flox-creatine']
for g,b in o.items():
    comp('Fig 3f',g,b,ks[0],ks[1]); comp('Fig 3f',g,b,ks[2],ks[3]); comp('Fig 3f',g,b,ks[1],ks[3]); comp('Fig 3f',g,b,ks[0],ks[2])
o,_=parse_qpcr('Supplementary Fig  3c',4)
for g,b in o.items(): comp('Supp 3c',g,b,'Vehicle','Creatine')
o,_=parse_qpcr('Supplementary Fig  4e',7)
for g,b in o.items(): comp('Supp 4e',g,b,'Control','Creatine'); comp('Supp 4e',g,b,'Control','Creatine@liposome')
o,_=parse_qpcr('Fig. 4h',6)
for g,b in o.items(): comp('Fig 4h',g,b,'Control','Creatine'); comp('Fig 4h',g,b,'Control','Phosphocreatine')
o,_=parse_qpcr('Fig. 4j',7)
for g,b in o.items(): comp('Fig 4j',g,b,'Control+si-scrambled','Creatine+si-scrambled'); comp('Fig 4j',g,b,'Creatine+si-scrambled','Creatine+si-Ckb'); comp('Fig 4j',g,b,'Control+si-scrambled','Control+si-Ckb'); comp('Fig 4j',g,b,'Control+si-Ckb','Creatine+si-Ckb'); comp('Fig 4j',g,b,'Control+si-scrambled','Creatine+si-Ckb')
o,_=parse_qpcr('Fig. 4l',5)
for g,b in o.items(): comp('Fig 4l',g,b,'CKB-EV','CKB-OE')
o,_=parse_qpcr('Fig.6a',6)
for g,b in o.items(): comp('Fig 6a',g,b,'Vehicle','Creatine'); comp('Fig 6a',g,b,'Vehicle','Vehicle+stat5 inhibitor'); comp('Fig 6a',g,b,'Creatine','Creatine+stat5 inhibitor'); comp('Fig 6a',g,b,'Vehicle','Creatine+stat5 inhibitor')
o,_=parse_qpcr('Fig. 6g',4)
for g,b in o.items(): comp('Fig 6g',g,b,'WT-Vehicle','WT-Creatine'); comp('Fig 6g',g,b,'WT-Creatine','PF4-cre;Stat5bflox/flox-creatine'); comp('Fig 6g',g,b,'WT-Vehicle','PF4-cre;Stat5bflox/flox-creatine')
df=pd.DataFrame(rows); df.to_csv(os.path.join(HERE,'qpcr_reanalysis.csv'),index=False)
def summ(panel,ref,test):
    s=df[(df.panel==panel)&(df.ref==ref)&(df.test==test)]
    print(f"{panel:8s} {test} vs {ref}: fold range {s.fold.min():.2f}-{s.fold.max():.2f} (median {s.fold.median():.2f}); genes p<0.05: {(s.p_log2_t<0.05).sum()}/{len(s)}; up&sig {((s.p_log2_t<0.05)&(s.fold>1)).sum()}, down&sig {((s.p_log2_t<0.05)&(s.fold<1)).sum()}")
summ('Fig 2f','Vehicle','Creatine')
summ('Fig 3f',ks[0],ks[1]); summ('Fig 3f',ks[2],ks[3]); summ('Fig 3f',ks[1],ks[3]); summ('Fig 3f',ks[0],ks[2])
summ('Supp 3c','Vehicle','Creatine')
summ('Supp 4e','Control','Creatine'); summ('Supp 4e','Control','Creatine@liposome')
summ('Fig 4h','Control','Creatine'); summ('Fig 4h','Control','Phosphocreatine')
summ('Fig 4j','Control+si-scrambled','Creatine+si-scrambled'); summ('Fig 4j','Creatine+si-scrambled','Creatine+si-Ckb'); summ('Fig 4j','Control+si-scrambled','Control+si-Ckb'); summ('Fig 4j','Control+si-Ckb','Creatine+si-Ckb'); summ('Fig 4j','Control+si-scrambled','Creatine+si-Ckb')
summ('Fig 4l','CKB-EV','CKB-OE')
summ('Fig 6a','Vehicle','Creatine'); summ('Fig 6a','Vehicle','Vehicle+stat5 inhibitor'); summ('Fig 6a','Creatine','Creatine+stat5 inhibitor'); summ('Fig 6a','Vehicle','Creatine+stat5 inhibitor')
summ('Fig 6g','WT-Vehicle','WT-Creatine'); summ('Fig 6g','WT-Creatine','PF4-cre;Stat5bflox/flox-creatine'); summ('Fig 6g','WT-Vehicle','PF4-cre;Stat5bflox/flox-creatine')
print(df[(df.panel=='Supp 3c')].round(3).to_string())
print(df[(df.panel=='Supp 4e')].round(3).to_string())
print(df[(df.panel=='Fig 3f')&(df.ref==ks[0])&(df.test==ks[2])].round(3).to_string())

print('\n== Residual induction under creatine, by node perturbed')
pd.set_option('display.width',250)
o3,_=parse_qpcr('Fig. 3f',7); o6g,_=parse_qpcr('Fig. 6g',4); o6a,_=parse_qpcr('Fig.6a',6); o4j,_=parse_qpcr('Fig. 4j',7)
rows=[]
for g in o3:
    a=o3[g]; wv,wc,kv,kc=[a[k].mean() for k in ['PF4 cre; Slc6a8+/+-vehicle','PF4 cre; Slc6a8+/+-creatine','PF4 cre; Slc6a8flox/flox-vehicle','PF4 cre; Slc6a8flox/flox-creatine']]
    b=o6g[g]; sv,sc,skc=[b[k].mean() for k in ['WT-Vehicle','WT-Creatine','PF4-cre;Stat5bflox/flox-creatine']]
    c=o6a[g]; iv,ic,ivi,ici=[c[k].mean() for k in ['Vehicle','Creatine','Vehicle+stat5 inhibitor','Creatine+stat5 inhibitor']]
    d=o4j[g]; cs,ck,crs,crk=[d[k].mean() for k in ['Control+si-scrambled','Control+si-Ckb','Creatine+si-scrambled','Creatine+si-Ckb']]
    # residual vs WT vehicle and p for residual>1 (log scale t-test vs WT vehicle)
    p_slc=stats.ttest_ind(np.log2(a['PF4 cre; Slc6a8flox/flox-creatine']),np.log2(a['PF4 cre; Slc6a8+/+-vehicle'])).pvalue
    p_st=stats.ttest_ind(np.log2(b['PF4-cre;Stat5bflox/flox-creatine']),np.log2(b['WT-Vehicle'])).pvalue
    p_in=stats.ttest_ind(np.log2(c['Creatine+stat5 inhibitor']),np.log2(c['Vehicle'])).pvalue
    rows.append(dict(gene=g, WTcre_3f=wc, Slc6a8KO_cre=kc, Slc6a8KO_veh=kv, pct_block_Slc6a8=100*(wc-kc)/(wc-1), p_resid_slc=p_slc,
                     WTcre_6g=sc, Stat5bKO_cre=skc, pct_block_Stat5b=100*(sc-skc)/(sc-1), p_resid_stat5b=p_st,
                     Cre_6a=ic, Cre_inh=ici, Veh_inh=ivi, pct_block_inh=100*(ic-ici)/(ic-1), p_resid_inh=p_in,
                     Cre_siScr=crs, Cre_siCkb=crk, Ctl_siCkb=ck, pct_block_siCkb=100*(crs-crk)/(crs-1)))
df=pd.DataFrame(rows).set_index('gene')
print(df.round(2).to_string())
print()
print('median pct block: Slc6a8 KO %.0f | Stat5b KO %.0f | STAT5 inhibitor %.0f | si-Ckb %.0f' % (df.pct_block_Slc6a8.median(), df.pct_block_Stat5b.median(), df.pct_block_inh.median(), df.pct_block_siCkb.median()))
print('genes with residual > WT vehicle at p<0.05: Slc6a8KO', list(df.index[(df.p_resid_slc<0.05)&(df.Slc6a8KO_cre>1)]), '| Stat5bKO', list(df.index[(df.p_resid_stat5b<0.05)&(df.Stat5bKO_cre>1)]), '| inhibitor', list(df.index[(df.p_resid_inh<0.05)&(df.Cre_inh>1)]))
print('geometric mean residual fold (KO/inh + creatine vs WT vehicle): Slc6a8KO %.2f | Stat5bKO %.2f | inhibitor %.2f | siCkb %.2f' % (np.exp(np.log(df.Slc6a8KO_cre).mean()), np.exp(np.log(df.Stat5bKO_cre).mean()), np.exp(np.log(df.Cre_inh).mean()), np.exp(np.log(df.Cre_siCkb).mean())))
core=['P2ry12','Gp6','Rab4a']
print(df.loc[core,['WTcre_3f','Slc6a8KO_cre','pct_block_Slc6a8','WTcre_6g','Stat5bKO_cre','pct_block_Stat5b','p_resid_stat5b','Cre_6a','Cre_inh','pct_block_inh','Cre_siScr','Cre_siCkb','pct_block_siCkb']].round(2).to_string())
df.round(3).to_csv(os.path.join(HERE,'gene_block_summary.csv'))
