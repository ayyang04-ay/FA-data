# Re-analysis code and outputs

Everything in `proposal.md` and `appendix_evidence_tables.md` is computed here from the three files in the package
(`CRE-MK-01_source_data.xlsx`, `CRE-MK-01_phosphoproteomics.xlsx`, `study_conventions.pdf`). No external data.

Run: `PY="micromamba run -n singlecell python" bash run_all.sh` (any Python with openpyxl, numpy, scipy, pandas,
statsmodels and matplotlib works). Set `CRE_DATA` if the files are not in `/tmp/world/filesystem`.

| Script | What it does | Output |
|---|---|---|
| `lib.py` | cell-range readers, t test / Tukey / Dunnett helpers, qPCR-sheet parser | — |
| `01_verify_reported_stats.py` | recomputes all 232 tests reported in the source file and compares with the reported P | `verification_reported_vs_recomputed.csv` |
| `02_metastasis_cohorts_interactions_power.py` | creatine effect per cohort, random-effects pooling, 2×2 interactions (ratio-of-ratios), survival hazard ratios, power | `creatine_effect_cohorts.csv`, log |
| `03_gene_panels.py` | megakaryocyte gene panels by perturbation; residual induction per node | `qpcr_reanalysis.csv`, `gene_block_summary.csv` |
| `04_human_cohort.py` | volunteer cohort: Fig 7b, 7c (signed-rank re-analysis), 7d, 7e, 7g | `fig7c_reanalysis.csv`, `fig7d_summary.csv` |
| `05_phosphoproteomics.py` | screening counts, Q range, Benjamini–Hochberg check, tied-P patterns, Stat5b rank | `phospho_summary.txt`, `phospho_top50.csv`, `phos.pkl` |
| `06_duplicate_scan.py` | exact-duplicate scan across sheets; Fig 6b / Supp 2d overlap and sensitivity | `duplicate_scan.txt` |
| `07_two_group_numbers.py` | means, ratios and t tests for every two-group panel | `numbers.json` |
| `08_make_appendix.py` | writes `../appendix_evidence_tables.md` | — |
| `09_make_figures.py` | writes the three figures in `../figures/` | — |

`log_*.txt` hold the full console output of each script (group means, SDs, alternative tests).
