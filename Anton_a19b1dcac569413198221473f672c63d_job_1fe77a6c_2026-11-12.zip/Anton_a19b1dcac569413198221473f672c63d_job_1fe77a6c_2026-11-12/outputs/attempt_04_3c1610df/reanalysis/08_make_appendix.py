'''Builds ../appendix_evidence_tables.md from the raw workbook and the CSV/JSON outputs of scripts 01-07.'''
from lib import *
import pandas as pd, json, statsmodels.api as sm, warnings, os
os.chdir(HERE)
warnings.filterwarnings('ignore')
N=json.load(open('numbers.json'))
S=sheet
out=[]
def P(p):
    if p<0.0001: return f"{p:.1e}".replace('e-0','e-')
    if p<0.001: return f"{p:.4f}"
    if p<0.01: return f"{p:.3f}"
    return f"{p:.2f}" if p>=0.095 else f"{p:.3f}"
def w(s=''): out.append(s)
def fmt(x):
    ax=abs(x)
    if ax>=100: return f"{x:.0f}"
    if ax>=10: return f"{x:.1f}"
    if ax>=1: return f"{x:.2f}"
    return f"{x:.3f}"
def line(k, unit=''):
    v=N[k]; return f"{fmt(v['m1'])} → {fmt(v['m2'])}{unit} (×{v['ratio']:.2f}; P = {P(v['p'])}; n = {v['n1']}+{v['n2']})"

w('# CRE-MK-01 — evidence appendix (re-analysis tables)')
w()
w('Companion to `proposal.md`. Every number below was recomputed from the raw cells of `CRE-MK-01_source_data.xlsx` (87 sheets, 26 embedded blot images) and `CRE-MK-01_phosphoproteomics.xlsx` (5,812 rows); conventions are from `study_conventions.pdf`. Nothing external was used.')
w()
w('## A. How the numbers were derived')
w()
ver=pd.read_csv('verification_reported_vs_recomputed.csv')
w(f"- **Reproduction of the file's own statistics.** All {len(ver)} reported tests were recomputed from the raw values next to them: {int((ver.test=='unpaired t').sum())} unpaired two-tailed t tests, {int((ver.test=='Tukey').sum())} Tukey comparisons (one-way ANOVA), {int((ver.test=='Dunnett').sum())} Dunnett comparisons, {int((ver.test=='Sidak').sum())} Sidak comparisons (two-way ANOVA) and 2 log-rank tests. {int(ver.match.sum())} of {len(ver)} match the reported P values (`reanalysis/verification_reported_vs_recomputed.csv`). The arithmetic in the package is sound; the issues in section J are about design, units of replication and labelling.")
w('- **Added analyses.** (i) Creatine × perturbation interaction for every 2×2 design (ordinary least squares on the raw scale, as the file analyses them, and on the natural-log scale to give a ratio-of-ratios with 95% CI). (ii) Ratio of group means with 95% CI (log response ratio, delta method) for every metastasis cohort, pooled by DerSimonian–Laird random effects. (iii) Cox hazard ratios (Efron handling of ties) for the two survival panels. (iv) qPCR: group means of the fold values given in the sheets; P values from unpaired t tests on log2 fold values (n = 3 per group). (v) Human fold-change data: Wilcoxon signed-rank test against no change and responder counts, because the file normalises each volunteer to 1.0 at day 0 (a zero-variance reference group) and then applies Dunnett. (vi) Exact-duplicate scan of all numeric cells across sheets. (vii) Phosphoproteomics: counts at the study screening criteria, q-value range, Benjamini–Hochberg check, and the pattern of tied P values. (viii) Sample size: non-central t for a 2×2 interaction on ln(burden).')
w('- **Units.** n is given as in the file. Where the conventions state that n is a microscope field (Fig 1i, 2c, 2j, Supp 4c) or where the replicate type is not stated (aggregation, qPCR), this is flagged rather than corrected.')
w('- **In vivo versus culture.** Megakaryocyte sheets labelled Vehicle / Creatine are read as cells isolated from treated mice, and sheets labelled Control / Creatine as cells treated in culture. This follows the blot captions ("Isolated MKs" versus "MKs (in vitro)") and the dosing table in the conventions; the sheets themselves do not state it.')
w()

# ---------------- B
w('## B. Creatine and lung metastatic burden: every cohort in the package')
w()
df=pd.read_csv('creatine_effect_cohorts.csv')
w('| Panel | Context | n (control + creatine) | Burden %, control → creatine | Ratio of means (95% CI) | P (t test) |')
w('|---|---|---|---|---|---|')
ctx={'Fig 1b (oral creatine)':('Fig 1b','oral creatine, three times a week'),'Fig 1k (second model)':('Fig 1k','second cohort (model not named in file)'),'Fig 1f melanoma sh-scrambled':('Fig 1f','melanoma, sh-scrambled tumour cells'),'Fig 1f melanoma sh-Slc6a8':('Fig 1f','melanoma, tumour-cell sh-Slc6a8'),
     'Fig 3i Pf4-Cre;Slc6a8+/+':('Fig 3i','Pf4-Cre;Slc6a8+/+ (Cre control)'),'Fig 3i Pf4-Cre;Slc6a8fl/fl':('Fig 3i','**Pf4-Cre;Slc6a8fl/fl (MK-lineage knockout)**'),'Fig 6b no inhibitor':('Fig 6b','no inhibitor †'),'Fig 6b + STAT5-IN-1':('Fig 6b','**+ STAT5-IN-1**'),
     'S1e':('Supp 1e','model not named'),'S1f':('Supp 1f','model not named'),'S1g':('Supp 1g','model not named'),'S1i (5% creatine diet)':('Supp 1i','5% creatine diet vs control diet'),'S1k':('Supp 1k','model not named'),
     'S2d donor platelets (veh vs creatine donors)':('Supp 2d','recipients of platelets from creatine- vs vehicle-treated donors †'),'S2d donor platelets (veh vs creatine+aspirin donors)':('Supp 2d','**recipients of platelets from creatine + aspirin donors** vs vehicle donors'),'Fig 7g human donor platelets d0 vs d7':('Fig 7g','mice given human platelets, volunteer day 7 vs day 0')}
for _,r in df.iterrows():
    a,b=ctx[r.cohort]
    w(f"| {a} | {b} | {int(r.n_ctrl)} + {int(r.n_cre)} | {r.mean_ctrl:.2f} → {r.mean_cre:.2f} | {r.ratio:.2f} ({r.lo:.2f}–{r.hi:.2f}) | {P(r.p)} |")
w()
w('Pooled estimate for the ten directly dosed, unperturbed cohorts (Fig 1b, 1k, 1f sh-scrambled, 3i Cre control, 6b no inhibitor, Supp 1e, 1f, 1g, 1i, 1k; 61 + 61 mice): **ratio 3.02 (95% CI 2.54–3.58)**, range 2.07–4.02, I² = 51%. † Fig 6b and Supp 2d share three vehicle and three creatine animals (section J).')
w()
w('Other metastasis readouts in the same cohorts:')
w()
w('| Panel | Readout | Control → creatine |')
w('|---|---|---|')
for k,lab,rd in [('1a_lw','Fig 1a','lung weight (g)'),('1a_suv','Fig 1a','SUV-BW'),('1b_foci','Fig 1b','metastatic foci'),('1j_lw','Fig 1j','lung weight (g)'),('1j_suv','Fig 1j','SUV-BW'),('1k_foci','Fig 1k','metastatic foci'),
                 ('S1e_lw','Supp 1e','lung weight (g)'),('S1e_foci','Supp 1e','metastatic foci'),('S1f_lw','Supp 1f','lung weight (g)'),('S1f_foci','Supp 1f','metastatic foci'),('S1g_lw','Supp 1g','lung weight (g)'),('S1g_foci','Supp 1g','metastatic foci'),
                 ('S1i_lw','Supp 1i','lung weight (g)'),('S1i_foci','Supp 1i','metastatic foci'),('S1k_lw','Supp 1k','lung weight (g)'),('S1k_foci','Supp 1k','metastatic foci'),('7g_lw','Fig 7g','lung weight (g), human-platelet recipients'),('7g_foci','Fig 7g','metastatic foci, human-platelet recipients')]:
    w(f"| {lab} | {rd} | {line(k)} |")
w()
from statsmodels.duration.hazard_regression import PHReg
def cox(name,r0,r1,r2,r3):
    ws=S(name); tv=col(ws,'A',r0,r1); tc=col(ws,'A',r2,r3); t=np.r_[tv,tc]; g=np.r_[np.zeros(len(tv)),np.ones(len(tc))]
    m=PHReg(t,g[:,None],status=np.ones(len(t)),ties='efron').fit(); ci=m.conf_int()[0]
    return f"{np.exp(m.params[0]):.1f} (95% CI {np.exp(ci[0]):.1f}–{np.exp(ci[1]):.1f})"
w(f"Survival: Fig 1c, median 22 → 19 days, log-rank χ² = 4.58, P = 0.032, Cox hazard ratio {cox('Fig. 1c',4,13,14,23)}, n = 10 + 10. Fig 1l, median 16 → 14 days, χ² = 6.47, P = 0.011, Cox hazard ratio {cox('Fig. 1l',4,23,24,41)}, n = 20 + 18. Event times are heavily tied, so the hazard ratio depends on the estimator (Mantel–Haenszel gives 3.3 and 2.8).")
w()
w('Early lung signal after tumour-cell injection (Fig 1h; y-axis not labelled in the file), control → creatine: ' + '; '.join(f"{h} h {N['1h_'+h]['m1']:.2f} → {N['1h_'+h]['m2']:.2f} (×{N['1h_'+h]['ratio']:.2f}, P = {P(N['1h_'+h]['p'])})" for h in ['0.25','6','12','24']) + f"; n = 6 + 6. GFP+ cells per field (Fig 1i): {line('1i')} — n is 8 microscope fields per group.")
w()
w('Exposure and tolerability: serum creatine ' + line('S1d',' µM') + ' on oral dosing (Supp 1d) and ' + line('S1h',' µM') + ' on the 5% diet (Supp 1h). Body weight at day 7 ' + line('S1a_d7',' g') + ' (Supp 1a); food intake ' + line('S1b',' g/day') + '; water intake ' + line('S1c',' g/day') + '. Blood counts unchanged (Supp 3a: WBC P = ' + P(N['S3a_wbc']['p']) + ', lymphocytes ' + P(N['S3a_lym']['p']) + ', monocytes ' + P(N['S3a_mono']['p']) + ', RBC ' + P(N['S3a_rbc']['p']) + '; n = 5 + 5).')
w()

# ---------------- C
w('## C. Factorial analyses: which perturbation removes the creatine effect')
w()
def fact(name, g):
    a,b,c,d=g
    y=np.concatenate(g); cre=np.r_[np.zeros(len(a)),np.ones(len(b)),np.zeros(len(c)),np.ones(len(d))]; per=np.r_[np.zeros(len(a)+len(b)),np.ones(len(c)+len(d))]
    X=sm.add_constant(np.c_[cre,per,cre*per]); m=sm.OLS(y,X).fit(); ml=sm.OLS(np.log(y),X).fit(); ci=ml.conf_int()[3]
    return dict(a=a.mean(),b=b.mean(),c=c.mean(),d=d.mean(),r1=b.mean()/a.mean(),r2=d.mean()/c.mean(),p_raw=m.pvalues[3],ror=np.exp(-ml.params[3]),lo=np.exp(-ci[1]),hi=np.exp(-ci[0]),p_log=ml.pvalues[3],base=c.mean()/a.mean(),p_base=stats.ttest_ind(a,c).pvalue,n=len(a))
w('| Panel | Perturbation | Readout | n/group | Creatine effect, control arm | Creatine effect, perturbed arm | Interaction P (raw scale) | Ratio-of-ratios (95% CI), log scale | Perturbation alone vs control |')
w('|---|---|---|---|---|---|---|---|---|')
ws=S('Fig. 3i')
F={}
for lab,r0,r1 in [('burden %',10,13),('foci',17,20),('lung weight',3,6)]:
    f=fact('3i',[col(ws,c,r0,r1) for c in 'BCDE']); F['3i_'+lab]=f
    w(f"| Fig 3i | MK-lineage Slc6a8 knockout | {lab} | {f['n']} | {fmt(f['a'])} → {fmt(f['b'])} (×{f['r1']:.2f}) | {fmt(f['c'])} → {fmt(f['d'])} (×{f['r2']:.2f}) | {P(f['p_raw'])} | {f['ror']:.2f} ({f['lo']:.2f}–{f['hi']:.2f}) | ×{f['base']:.2f} (P = {P(f['p_base'])}) |")
ws=S('Fig. 6b')
for lab,r0,r1 in [('burden %',4,8),('foci',13,17)]:
    f=fact('6b',[col(ws,c,r0,r1) for c in 'BCDE']); F['6b_'+lab]=f
    w(f"| Fig 6b | STAT5-IN-1 (STAT5A + STAT5B, systemic) | {lab} | {f['n']} | {fmt(f['a'])} → {fmt(f['b'])} (×{f['r1']:.2f}) | {fmt(f['c'])} → {fmt(f['d'])} (×{f['r2']:.2f}) | {P(f['p_raw'])} | {f['ror']:.2f} ({f['lo']:.2f}–{f['hi']:.2f}) | ×{f['base']:.2f} (P = {P(f['p_base'])}) |")
ws=S('Fig. 1f')
for lab,r0,r1 in [('burden %',22,27),('foci',31,36),('lung weight',4,9),('SUV-BW',13,18)]:
    f=fact('1f',[col(ws,c,r0,r1) for c in 'BCDE']); F['1f_'+lab]=f
    w(f"| Fig 1f | tumour-cell Slc6a8 knockdown (melanoma) | {lab} | {f['n']} | {fmt(f['a'])} → {fmt(f['b'])} (×{f['r1']:.2f}) | {fmt(f['c'])} → {fmt(f['d'])} (×{f['r2']:.2f}) | {P(f['p_raw'])} | {f['ror']:.2f} ({f['lo']:.2f}–{f['hi']:.2f}) | ×{f['base']:.2f} (P = {P(f['p_base'])}) |")
w()
_fl={}
for _nm,(_r0,_r1) in [('Fig. 3i',(10,13)),('Fig. 6b',(4,8)),('Fig. 1f',(22,27))]:
    _ws=S(_nm); _g=[col(_ws,c,_r0,_r1) for c in 'BCDE']; _fl[_nm]=freedman_lane(_g,log=False)
w(f"Robustness: a residual-permutation (Freedman–Lane) test of the burden interaction, which does not assume normal errors, gives P = {P(_fl['Fig. 3i'])} for Fig 3i, {P(_fl['Fig. 6b'])} for Fig 6b and {P(_fl['Fig. 1f'])} for Fig 1f (50,000 permutations, raw scale). In Fig 3i the creatine arms of the two genotypes do not overlap (control 6.9–10.3%, knockout 1.9–4.9%).")
w()
w('Reading: a ratio-of-ratios of 1 means the perturbation does not change the creatine effect. MK-lineage Slc6a8 deletion and STAT5-IN-1 both remove it; knocking Slc6a8 down in the tumour cells (19% of control mRNA remaining, Supp 2a, P = 0.0008) does not.')
w()
w('Sensitivity of Fig 6b to the shared animals: dropping the three vehicle and three creatine values that also appear in Supp 2d leaves n = 2 + 2 in the no-inhibitor arms; creatine vs creatine + inhibitor is still separated (Tukey P = 9e-5), but the control arms then rest on two animals each.')
w()
w('Megakaryocyte and platelet readouts in the Slc6a8 knockout (Fig 3b–3d), vehicle → creatine:')
w()
w('| Readout | Pf4-Cre;Slc6a8+/+ | Pf4-Cre;Slc6a8fl/fl | Note |')
w('|---|---|---|---|')
w(f"| Serum creatine, µM (Fig 3b, n = 5) | {N['3b_wt']['m1']:.0f} → {N['3b_wt']['m2']:.0f} (×{N['3b_wt']['ratio']:.2f}) | {N['3b_ko']['m1']:.0f} → {N['3b_ko']['m2']:.0f} (×{N['3b_ko']['ratio']:.2f}) | exposure is the same in both genotypes (creatine arms, P = 0.18) |")
ws=S('Fig. 3c'); g=[row(ws,4,'B','D'),row(ws,4,'E','G'),row(ws,5,'B','D'),row(ws,5,'E','G')]
y=np.concatenate(g); X=sm.add_constant(np.c_[[0,0,0,1,1,1,0,0,0,1,1,1],[0]*6+[1]*6,[0]*9+[1]*3]); m=sm.OLS(y,X).fit()
w(f"| MK intracellular creatine, µmol/g (Fig 3c, n = 3) | {N['3c_wt']['m1']:.1f} → {N['3c_wt']['m2']:.1f} (×{N['3c_wt']['ratio']:.2f}; P = {P(N['3c_wt']['p'])}, Welch {P(stats.ttest_ind(g[0],g[1],equal_var=False).pvalue)}) | {N['3c_ko']['m1']:.1f} → {N['3c_ko']['m2']:.1f} (×{N['3c_ko']['ratio']:.2f}; P = {P(N['3c_ko']['p'])}) | interaction P = {P(m.pvalues[3])} |")
ws=S('Fig. 3d')
for r,ag in zip([4,5,6],['ADP','collagen','thrombin']):
    g=[row(ws,r,'B','D'),row(ws,r,'E','G'),row(ws,r,'H','J'),row(ws,r,'K','M')]
    from scipy.stats import tukey_hsd
    tk=tukey_hsd(*g)
    w(f"| Aggregation, {ag}, % (Fig 3d, n = 3) | {g[0].mean():.1f} → {g[1].mean():.1f} (Tukey P = {P(tk.pvalue[0,1])}) | {g[2].mean():.1f} → {g[3].mean():.1f} (Tukey P = {P(tk.pvalue[2,3])}) | knockout + vehicle vs control + vehicle: {g[2].mean()-g[0].mean():+.1f} points (P = {P(tk.pvalue[0,2])}) |")
ws=S('Supplementary Fig  4b'); g=[col(ws,c,5,7) for c in 'CDEF']
w(f"| Platelet count, ×10⁹/L (Supp 4b, n = 3) | {g[0].mean():.0f} → {g[1].mean():.0f} | {g[2].mean():.0f} → {g[3].mean():.0f} | one-way ANOVA P = {P(stats.f_oneway(*g).pvalue)} |")
w()
w('In the knockout, creatine lowers aggregation below the knockout baseline, and the knockout baseline is itself below the Cre-control baseline. Within-group SDs in Fig 3d are 1–1.2 percentage points, which looks like run-to-run precision; the file does not say whether the three values are three animals.')
w()

# ---------------- D
w('## D. Megakaryocyte platelet-gene panel (11 genes), by perturbation')
w()
q=pd.read_csv('qpcr_reanalysis.csv')
def summ(panel,ref,test):
    s=q[(q.panel==panel)&(q.ref==ref)&(q.test==test)]
    return f"{s.fold.min():.2f}–{s.fold.max():.2f} (median {s.fold.median():.2f})", int(((s.p_log2_t<0.05)&(s.fold>1)).sum()), int(((s.p_log2_t<0.05)&(s.fold<1)).sum()), len(s)
ks=['PF4 cre; Slc6a8+/+-vehicle','PF4 cre; Slc6a8+/+-creatine','PF4 cre; Slc6a8flox/flox-vehicle','PF4 cre; Slc6a8flox/flox-creatine']
rows=[('Fig 2f','MKs from creatine- vs vehicle-treated mice','Fig 2f','Vehicle','Creatine'),
      ('Fig 3f','Cre control: creatine vs vehicle','Fig 3f',ks[0],ks[1]),
      ('Fig 3f','Slc6a8 knockout: creatine vs knockout vehicle','Fig 3f',ks[2],ks[3]),
      ('Fig 3f','Slc6a8 knockout vehicle vs Cre-control vehicle','Fig 3f',ks[0],ks[2]),
      ('Supp 4e','Slc6a8-knockout MKs in culture: free creatine vs control','Supp 4e','Control','Creatine'),
      ('Supp 4e','Slc6a8-knockout MKs in culture: liposomal creatine vs control','Supp 4e','Control','Creatine@liposome'),
      ('Fig 4h','cultured MKs: creatine vs control','Fig 4h','Control','Creatine'),
      ('Fig 4h','cultured MKs: phosphocreatine vs control','Fig 4h','Control','Phosphocreatine'),
      ('Fig 4j','si-scrambled: creatine vs control','Fig 4j','Control+si-scrambled','Creatine+si-scrambled'),
      ('Fig 4j','creatine: si-Ckb vs si-scrambled','Fig 4j','Creatine+si-scrambled','Creatine+si-Ckb'),
      ('Fig 4j','no creatine: si-Ckb vs si-scrambled','Fig 4j','Control+si-scrambled','Control+si-Ckb'),
      ('Fig 4j','si-Ckb: creatine vs control','Fig 4j','Control+si-Ckb','Creatine+si-Ckb'),
      ('Fig 4l','CKB overexpression vs empty vector (no added creatine)','Fig 4l','CKB-EV','CKB-OE'),
      ('Fig 6a','creatine vs vehicle','Fig 6a','Vehicle','Creatine'),
      ('Fig 6a','creatine: + STAT5-IN-1 vs none','Fig 6a','Creatine','Creatine+stat5 inhibitor'),
      ('Fig 6a','no creatine: STAT5-IN-1 vs vehicle','Fig 6a','Vehicle','Vehicle+stat5 inhibitor'),
      ('Fig 6g','wild type: creatine vs vehicle','Fig 6g','WT-Vehicle','WT-Creatine'),
      ('Fig 6g','creatine: Stat5b knockout vs wild type','Fig 6g','WT-Creatine','PF4-cre;Stat5bflox/flox-creatine'),
      ('Fig 6g','Stat5b knockout + creatine vs wild-type vehicle','Fig 6g','WT-Vehicle','PF4-cre;Stat5bflox/flox-creatine')]
w('| Panel | Comparison | Fold range across the 11 genes | Genes up, P < 0.05 | Genes down, P < 0.05 |')
w('|---|---|---|---|---|')
for a,b,p,r,t in rows:
    rng,u,d,n=summ(p,r,t); w(f"| {a} | {b} | {rng} | {u}/{n} | {d}/{n} |")
w()
w('Per-gene residual expression under creatine when each node is perturbed (fold of the untreated control; 1.0 = back to baseline):')
w()
b=pd.read_csv('gene_block_summary.csv')
w('| Gene | Creatine, unperturbed (Fig 3f / 6g / 6a / 4j) | Slc6a8 knockout + creatine (Fig 3f) | Stat5b knockout + creatine (Fig 6g) | STAT5-IN-1 + creatine (Fig 6a) | si-Ckb + creatine, in vitro (Fig 4j) |')
w('|---|---|---|---|---|---|')
for _,r in b.iterrows():
    st=lambda v,p: f"{v:.2f}" + (' *' if (p<0.05 and v>1) else '')
    w(f"| *{r.gene}* | {r.WTcre_3f:.2f} / {r.WTcre_6g:.2f} / {r.Cre_6a:.2f} / {r.Cre_siScr:.2f} | {st(r.Slc6a8KO_cre,r.p_resid_slc)} | {st(r.Stat5bKO_cre,r.p_resid_stat5b)} | {st(r.Cre_inh,r.p_resid_inh)} | {r.Cre_siCkb:.2f} |")
w()
w(f"\\* still above the untreated control at P < 0.05. Median share of the creatine-induced increment removed: Slc6a8 knockout {b.pct_block_Slc6a8.median():.0f}%, Stat5b knockout {b.pct_block_Stat5b.median():.0f}%, STAT5-IN-1 {b.pct_block_inh.median():.0f}%, si-Ckb {b.pct_block_siCkb.median():.0f}%. For the two receptor genes with human follow-up, the Stat5b knockout removes 72% (*P2ry12*) and 75% (*Gp6*) of the increment; the Slc6a8 knockout removes 92% and 101%. *Fcgr2a* is high in Slc6a8-knockout MKs with or without creatine (2.27 and 3.36). The Stat5b-knockout experiment has no knockout + vehicle arm, so residuals are expressed against wild-type vehicle.")
w()
q2=q[q.panel=='Supp 3c']
w('MK maturation genes (Supp 3c, creatine vs vehicle, n = 3): ' + '; '.join(f"*{r.gene}* ×{r.fold:.2f} (P = {P(r.p_log2_t)})" for _,r in q2.iterrows()) + '.')
w()

# ---------------- E
w('## E. Creatine, phosphocreatine and CKB in megakaryocytes')
w()
w('| Panel | Measurement | Control → treated |')
w('|---|---|---|')
w(f"| Fig 4a | MK creatine, µmol/g, vehicle → creatine in vivo | {line('4a_mk')} |")
w(f"| Fig 4a | brain creatine, µmol/g | {line('4a_brain')} |")
w(f"| Fig 4c | MK phosphocreatine, ng/µg | {line('4c_mk')} |")
w(f"| Fig 4c | brain phosphocreatine, ng/µg | {line('4c_brain')} |")
w(f"| Fig 4d | cultured MKs, creatine (sheet label reads 'Creatinine'), µmol/g | {line('4d')} |")
w(f"| Fig 4f | cultured MKs, phosphocreatine, ng/µg | {line('4f')} |")
w(f"| Fig 4e | *Ckb* mRNA in MKs, fold | {line('4e')} |")
w(f"| Supp 5a | *Gatm* mRNA, fold | {line('S5a_gatm')} |")
w(f"| Supp 5a | *Gamt* mRNA, fold | {line('S5a_gamt')} |")
w(f"| Supp 5c | MK creatine, µmol/g, empty vector → CKB overexpression | {line('S5c_cre')} |")
w(f"| Supp 5c | MK phosphocreatine, ng/µg, empty vector → CKB overexpression | {line('S5c_pcr')} |")
ws=S('Fig. 6e'); g=[col(ws,c,5,7) for c in 'CDE']; tk=tukey_hsd(*g)
w(f"| Fig 6e | MK creatine, µmol/g: wild-type vehicle / wild-type creatine / Stat5b knockout creatine | {g[0].mean():.1f} / {g[1].mean():.1f} / {g[2].mean():.1f}; wild type vs knockout on creatine, Tukey P = {P(tk.pvalue[1,2])}; n = 3 |")
w()
w('Blot-only evidence (no densitometry in the file): CKB protein rises in MKs from creatine-treated mice and is far more abundant in brain, where it changes little (Fig 4b); CKB rises in cultured MKs with creatine (Fig 4e, 4g); GP6 and P2RY12 rise with creatine but not with phosphocreatine (Fig 4g), are blunted by si-Ckb (Fig 4i) and rise with CKB overexpression (Fig 4k); knockdown and overexpression are confirmed in Supp 5b.')
w()

# ---------------- F
w('## F. STAT5B phosphorylation and promoter occupancy')
w()
w('Pan-phospho / FLAG densitometry of FLAG-STAT5B constructs (Fig 5e and 5f; three blots each; the cell system for each panel is not stated in the file):')
w()
w('| Panel | Construct | Vehicle | Creatine | Creatine / vehicle |')
w('|---|---|---|---|---|')
for nm in ['Fig. 5e','Fig. 5f']:
    ws=S(nm)
    for c,lab in zip('NOPQ',['WT','S127A','3A','S127D']):
        v=col(ws,c,4,6); cr=col(ws,c,17,19)
        w(f"| {nm.replace('. ',' ')} | {lab} | {v.mean():.3f} | {cr.mean():.3f} | ×{cr.mean()/v.mean():.2f} (P = {P(stats.ttest_ind(v,cr).pvalue)}) |")
w()
for nm in ['Fig. 5e','Fig. 5f']:
    ws=S(nm); veh=[col(ws,c,4,6) for c in 'NOPQ']; cre=[col(ws,c,17,19) for c in 'NOPQ']
    y=np.r_[veh[0],cre[0],veh[1],cre[1]]; tr=np.r_[0,0,0,1,1,1,0,0,0,1,1,1]; mu=np.r_[0,0,0,0,0,0,1,1,1,1,1,1]
    m=sm.OLS(y,sm.add_constant(np.c_[tr,mu,tr*mu])).fit(); tk=tukey_hsd(*cre)
    w(f"- {nm.replace('. ',' ')}: under creatine, WT exceeds S127A by {cre[0].mean()-cre[1].mean():.3f} (Tukey P = {P(tk.pvalue[0,1])}, as reported); construct × creatine interaction (WT vs S127A) P = {P(m.pvalues[3])}. S127D reads high with or without creatine.")
w('- The vehicle-versus-creatine comparison is not tested in the file, and in the third replicate of both panels ("Duplicate 2") vehicle and creatine samples are on separate blots. The antibody is pan-phospho, not site-specific; "3A" is not defined in the file.')
w('- Canonical phospho-STAT5A/B (Y694/699) is not detectable in MKs from vehicle- or creatine-treated mice, while the Jurkat + IL-2 positive control is positive and total STAT5B is unchanged (Supp 6a, blot).')
w('- Other blot-only evidence: CKB overexpression raises the pan-phospho signal on WT STAT5B in si-GATM cells, with S127A faint throughout (Fig 5g; Fig 5i shows the same comparison on separate blots); nuclear pan-phospho STAT5B rises with creatine and not after si-CKB (Fig 5h); recombinant His-CKB + ATP raises pan-phospho signal on FLAG-STAT5B in vitro (Supp 6d; signal is present without CKB); nuclear STAT5B appears modestly higher in MKs from creatine-treated mice (Supp 6h, two lanes per group).')
w()
w('ChIP-qPCR, % input, vehicle → creatine, n = 3 (Fig 5j, Supp 6i; the antibody is not named in the file):')
w()
w('| Gene | Exon | −2 kb | −1 kb | −0.2 kb |')
w('|---|---|---|---|---|')
def chip(ws, rows, vc, cc):
    V=[row(ws,r,*vc) for r in rows]; C=[row(ws,r,*cc) for r in rows]
    sse=sum(((v-v.mean())**2).sum()+((c-c.mean())**2).sum() for v,c in zip(V,C)); dfe=sum(len(v)+len(c)-2 for v,c in zip(V,C)); mse=sse/dfe; k=len(rows); res=[]
    for v,c in zip(V,C):
        t=(v.mean()-c.mean())/np.sqrt(mse*(1/len(v)+1/len(c))); p=2*stats.t.sf(abs(t),dfe); res.append(f"{v.mean():.1f} → {c.mean():.1f} (×{c.mean()/v.mean():.1f}; Sidak P = {P(1-(1-p)**k)})")
    return res
ws=S('Fig. 5j'); r=chip(ws,[5,6,7,8],('B','D'),('E','G')); w('| *P2ry12* | '+' | '.join(r)+' |')
r=chip(ws,[15,16,17,18],('B','D'),('E','G')); w('| *Gp6* | '+' | '.join(r)+' |')
ws=S('Supplementary Fig  6i'); r=chip(ws,[7,8,9,10],('C','E'),('F','H')); w('| *Rab4a* | '+' | '.join(r)+' |')
w()
w('The conventions list the same forward primer for the *Rab4a* −1 kb and −2 kb amplicons (ACCTCTGCACTTGGCAGTTT), so those two "regions" start at the same position yet give different enrichments.')
w()

# ---------------- G
ph=pd.read_pickle('phos.pkl'); fixed=np.isclose(ph.p,0.422649730810374); t=ph[~fixed]
w('## G. Phosphoproteomics (creatine vs vehicle megakaryocytes, n = 3 mice per group)')
w()
w(f"- {len(ph):,} phosphopeptide rows, {ph.gene.nunique():,} gene names (14 rows unnamed). Columns: gene, P, Q, log fold-change. No site, peptide or intensity columns, so the Ser127 assignment cannot be checked in this file.")
w(f"- {fixed.sum():,} rows ({100*fixed.mean():.0f}%) carry the identical P = 0.4226 with |log fold-change| of 0.4–7.6 (median 3.6). That is exactly what an unequal-variance t test returns (t = 1 on 2 degrees of freedom) when a peptide is quantified in one of three replicates of one group and in none of the other. A further {int(((t.p>0.17)&(t.p<0.20)&(t.lfc.abs()>2)).sum())} rows sit in a second band at P = 0.18–0.20 with |log fold-change| > 2, the value for two of three replicates. Large fold-changes in this table therefore mostly reflect presence or absence, not graded change. Rows quantified in three of three replicates of one group and none of the other return small P values; the Stat5b row is in that class. This is an inference from the pattern, because intensities are not in the file. (The column header names an unpaired Student's t test; the tied values are what the unequal-variance form returns for these patterns, and Student's form would give 0.374 for the first.)")
w(f"- Of the {len(t):,} other rows, {int((t.p<0.05).sum())} have P < 0.05; about {0.05*len(t):.0f} are expected by chance alone. By the study's screening criteria (P < 0.05 and fold-change ≥ 1.2 or ≤ 0.83), {int(((ph.p<0.05)&(ph.lfc>=np.log2(1.2))).sum())} rows are up and {int(((ph.p<0.05)&(ph.lfc<=np.log2(0.83))).sum())} down if the log is base 2.")
w(f"- No row passes a false-discovery threshold: the smallest Q in the file is {ph.q.min():.3f}; the smallest Benjamini–Hochberg value recomputed from the P column is 0.25.")
s=ph.loc[1507]; s2=ph.loc[1506]; s3=ph[ph.gene=='Stat5a'].iloc[0]
w(f"- **Stat5b**: two rows. Row {int(s.row)}: P = {s.p:.5f}, Q = {s.q:.3f}, log fold-change {s.lfc:.2f}; rank 17 of {len(ph):,} by P, 9th of 84 among nominal 'up' rows by fold-change. Row {int(s2.row)}: P = {s2.p:.2f}, log fold-change {s2.lfc:.2f}. **Stat5a** (one row): P = {s3.p:.2f}, log fold-change {s3.lfc:.2f}. Ckb and Slc6a8 are not in the table.")
big=t[(t.lfc.abs()>=3)&(t.p<0.05)]
w(f"- Stat5b's profile (|log fold-change| ≥ 3 with P < 0.05) is shared by {len(big)} rows: {int((big.lfc>0).sum())} 'on in creatine', {int((big.lfc<0).sum())} 'off in creatine'.")
w()
w('Twenty smallest P values in the table:')
w()
w('| Rank | Gene | P | Q | Log fold-change |')
w('|---|---|---|---|---|')
for i,(_,r) in enumerate(ph.sort_values('p').head(20).iterrows(),1):
    w(f"| {i} | {r.gene} | {r.p:.5f} | {r.q:.3f} | {r.lfc:+.2f} |")
w()

# ---------------- H
w('## H. Human volunteer cohort (11 healthy volunteers, 20 g/day creatine for 14 days, no control arm)')
w()
ws=S('Fig. 7b'); d=[col(ws,c,4,14) for c in 'BCDE']
w(f"Serum creatine (Fig 7b), µM, mean ± SD: day 0 {d[0].mean():.0f} ± {d[0].std(ddof=1):.0f}; day 3 {d[1].mean():.0f} ± {d[1].std(ddof=1):.0f}; day 7 {d[2].mean():.0f} ± {d[2].std(ddof=1):.0f}; day 14 {d[3].mean():.0f} ± {d[3].std(ddof=1):.0f}; every volunteer at least ×{min(np.min(d[k]/d[0]) for k in (1,2,3)):.1f} (paired t, day 0 vs day 14, P = {P(stats.ttest_rel(d[0],d[3]).pvalue)}). BMI unchanged (Supp 8a, paired P = 0.24); platelet count and indices unchanged (Supp 8b, all Dunnett P ≥ 0.88).")
w()
w('Platelet function (Fig 7c), fold of each volunteer\'s own day 0, n = 11. Cells: median fold; volunteers increased; Wilcoxon signed-rank P against no change. The file\'s Dunnett P is given for day 14.')
w()
w('| Agonist | Measure | Day 3 | Day 7 | Day 14 | Dunnett P, day 14 (file) |')
w('|---|---|---|---|---|---|')
ws=S('Fig. 7c')
blocks=[('Collagen','max aggregation',4,14,6),('Collagen','mean aggregation',18,28,20),('Collagen','adhesion',32,42,34),('Epinephrine','max aggregation',46,56,49),('Epinephrine','mean aggregation',60,70,63),('Epinephrine','adhesion',74,84,77),('Arachidonic acid','max aggregation',88,98,90),('Arachidonic acid','mean aggregation',102,112,105),('Arachidonic acid','adhesion',116,126,119),('ADP','max aggregation',130,140,133),('ADP','mean aggregation',144,154,147),('ADP','adhesion',157,167,161)]
for ag,m,r0,r1,rp in blocks:
    cells=[]
    for c in 'CDE':
        x=col(ws,c,r0,r1); cells.append(f"{np.median(x):.2f}; {int((x>1).sum())}/11; P = {P(stats.wilcoxon(x-1).pvalue)}")
    w(f"| {ag} | {m} | {cells[0]} | {cells[1]} | {cells[2]} | {ws[f'L{rp}'].value} |")
w()
_ws7=S('Fig. 7c'); _c14=col(_ws7,'E',4,14); _e14=col(_ws7,'E',60,70); _ws7b=S('Fig. 7b'); _sf=col(_ws7b,'E',4,14)/col(_ws7b,'B',4,14)
_r=np.corrcoef(np.log2(_c14),np.log2(_e14))[0,1]; _rho=stats.spearmanr(_sf,_c14)
w(f"Exploratory, and only valid if row order is the same volunteer across blocks (the sheet does not say): day-14 collagen and epinephrine responses are correlated across rows (r = {_r:.2f} on log2 fold), so response looks like a property of the volunteer, with three to four non-responders; it does not track the rise in serum creatine (Spearman ρ = {_rho.statistic:.2f}, P = {_rho.pvalue:.2f}; every volunteer rose at least two-fold).")
w()
w('CD41+ cell transcripts (Fig 7d), 4 volunteers, fold of own day 0 as given in the sheet (geometric mean; volunteers increased; one-sample t on log2):')
w()
h=pd.read_csv('fig7d_summary.csv')
w('| Gene | Day 3 | Day 7 | Day 14 |')
w('|---|---|---|---|')
for g in ['GP6','P2RY12','RAB4A','ITGA2B','GPIBA','F2R','ADAR2A','FCGR2A','RUNX1','RAB27B','PITPNB']:
    cells=[]
    for dd in ['3d','7d','14d']:
        r=h[(h.gene==g)&(h.day==dd)].iloc[0]; cells.append(f"×{r.geomean:.2f}; {int(r.n_up)}/4; P = {P(r.p_logt)}")
    w(f"| *{g if g!='ADAR2A' else 'ADRA2A (sheet label ADAR2A)'}* | "+' | '.join(cells)+' |')
w()
ws=S('Fig. 7e')
g6=[col(ws,c,4,7) for c in 'BCDE']; p2=[col(ws,c,12,15) for c in 'BCDE']; t6=tukey_hsd(*g6); t2=tukey_hsd(*p2)
w(f"Platelet protein by immunoblot densitometry, ratio to β-actin (Fig 7e, 4 volunteers): GP6 {g6[0].mean():.2f} → {g6[1].mean():.2f} / {g6[2].mean():.2f} / {g6[3].mean():.2f} at days 3 / 7 / 14 (Tukey vs day 0: P = {P(t6.pvalue[0,1])}, {P(t6.pvalue[0,2])}, {P(t6.pvalue[0,3])}); P2RY12 {p2[0].mean():.2f} → {p2[1].mean():.2f} / {p2[2].mean():.2f} / {p2[3].mean():.2f} (P = {P(t2.pvalue[0,1])}, {P(t2.pvalue[0,2])}, {P(t2.pvalue[0,3])}). Blots for all four volunteers are in Supp 8d.")
w()
w(f"Human platelets transferred into mice (Fig 7g, n = 5 recipient mice per group; number of donors not stated): burden {line('7g_burden',' %')}; foci {line('7g_foci')}; lung weight {line('7g_lw',' g')}.")
w()
w('Data notes for Fig 7d: PITPNB volunteer 4 is entered as values of +26 to +28 (raw Ct scale, not ΔCt); the reported folds for volunteer 4 in PITPNB (1.89, 6.84, 6.26) and RAB27B (2.52, 4.44, 2.36) cannot be reproduced from the listed ΔCt values (0.79–0.80, 1.9, 0.59 and 4.0–4.3, 5.7–6.1, 0.49–0.54). Eleven ΔCt cells (volunteer 3 day 14 for RUNX1, RAB27B, PITPNB; two PITPNB volunteer 4 cells) carry a different numeric precision from the instrument-export values around them.')
w()

# ---------------- I
w('## I. Panel index (every sheet in the source file)')
w()
w('| Sheet(s) | Content | n | Where analysed |')
w('|---|---|---|---|')
idx=[
('Fig 1a, 1b','creatine vs vehicle: lung weight, SUV-BW, burden, foci','6 + 6','B'),
('Fig 1c','survival','10 + 10','B'),
('Fig 1f','melanoma sh-scrambled vs sh-Slc6a8 × vehicle/creatine: lung weight, SUV-BW, burden, foci','6 per group','B, C'),
('Fig 1h','lung signal 0.25–24 h after tumour-cell injection (y-axis unlabelled)','6 + 6','B'),
('Fig 1i','GFP+ cells per field','8 fields per group','B'),
('Fig 1j, 1k','second cohort: lung weight, SUV-BW, burden, foci','6 + 6','B'),
('Fig 1l','survival, second cohort','20 + 18','B'),
('Fig 2a','platelet count and indices: PLT 789 vs 789 ×10⁹/L (P = 1.00); PCT P = 0.97, PDW P = 0.35, MPV P = 0.91','3 + 3','—'),
('Fig 2b','platelet aggregation: ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56% (P = 0.0003–0.001)','3 + 3 (replicate type not stated)','proposal §2'),
('Fig 2c','α-granules per field: 2.0 → 3.9 (P = 0.008)','8 fields per group','—'),
('Fig 2d','thromboelastography: MA 39.7 → 54.0 mm (P = 0.049; Welch 0.052); R, K, α P = 0.90, 0.17, 0.15','5 + 5','—'),
('Fig 2e, 2g','blots: GP6, P2RY12 in platelets and MKs from vehicle- vs creatine-treated mice','3 lanes per group','image only'),
('Fig 2f','MK platelet-gene panel, vehicle vs creatine','3 + 3','D'),
('Fig 2i','blot: creatine 0 / 0.2 / 2 mM raises GP6 and P2RY12 in cultured MKs, not in platelets treated directly','1 lane per dose','image only'),
('Fig 2j','PKH-positive area: 1.87 → 4.47% (P = 0.001)','8 fields per group','—'),
('Fig 3b, 3c, 3d','Slc6a8 knockout × creatine: serum creatine, MK creatine, aggregation','5, 3, 3 per group','C'),
('Fig 3f','Slc6a8 knockout × creatine: MK gene panel','3 per group','D'),
('Fig 3g','blot: GP6, P2RY12 in control vs knockout ± creatine','2 lanes per group','image only'),
('Fig 3i','Slc6a8 knockout × creatine: lung weight, burden, foci','4 per group','B, C'),
('Fig 4a, 4c','creatine and phosphocreatine in MKs and brain','3 + 3','E'),
('Fig 4b','blot: CKB in MKs and brain ± creatine','1 lane each','image only'),
('Fig 4d, 4f','cultured MKs: creatine and phosphocreatine content','3 + 3','E'),
('Fig 4e','Ckb mRNA (and blot) in MKs ± creatine','3 + 3','E'),
('Fig 4g, 4h','cultured MKs: control / creatine / phosphocreatine — blot and gene panel','3 per group (qPCR)','D'),
('Fig 4i, 4j','cultured MKs: si-Ckb × creatine — blot and gene panel','3 per group (qPCR)','D'),
('Fig 4k, 4l','cultured MKs: CKB overexpression — blot and gene panel','3 per group (qPCR)','D'),
('Fig 5e, 5f','FLAG-STAT5B WT / S127A / 3A / S127D ± creatine: pan-phospho / FLAG densitometry and blots','3 blots per panel','F'),
('Fig 5g, 5h, 5i','blots: CKB overexpression or knockdown and STAT5B phosphorylation; nuclear fraction','single blots','F'),
('Fig 5j','ChIP-qPCR at P2ry12 and Gp6','3 + 3','F'),
('Fig 6a','MK gene panel: vehicle / creatine ± STAT5-IN-1','3 per group','D'),
('Fig 6b','burden and foci: vehicle / creatine ± STAT5-IN-1','5 per group','B, C, J'),
('Fig 6d','blot: STAT5B absent in Pf4-iCre;Stat5bfl/fl MKs','1 lane each','image only'),
('Fig 6e','MK creatine: wild-type vehicle, wild-type creatine, Stat5b knockout creatine','3 per group','E'),
('Fig 6f','blot: CKB, GP6, P2RY12 in MKs and platelets, same three groups','1 lane each','image only'),
('Fig 6g','MK gene panel, same three groups','3 per group','D'),
('Fig 7b','human serum creatine, days 0, 3, 7, 14','11','H'),
('Fig 7c','human platelet aggregation and adhesion (collagen, epinephrine, arachidonic acid, ADP)','11','H'),
('Fig 7d','human CD41+ cell transcripts','4','H'),
('Fig 7e','human platelet GP6 and P2RY12 protein','4','H'),
('Fig 7g','mice given human day-0 vs day-7 platelets: lung weight, burden, foci','5 + 5 mice','B, H'),
('Supp 1a–1d','body weight, food, water, serum creatine','4–6 per group','B'),
('Supp 1e, 1f, 1g, 1k','further cohorts (models not named): lung weight, burden, foci','4–10 per group','B'),
('Supp 1h, 1i','5% creatine diet: serum creatine; lung weight, burden, foci','4 + 4','B'),
('Supp 2a','Slc6a8 knockdown in tumour cells: mRNA 19% of control; blot','3 + 3','C'),
('Supp 2d','platelet transfer: vehicle, creatine, creatine + aspirin donors — burden, foci','6 per group','B, J'),
('Supp 3a','white cells, lymphocytes, monocytes, red cells','5 + 5','B'),
('Supp 3c','MK maturation genes','3 + 3','D'),
('Supp 4a','blot: SLC6A8 reduced, with a residual band, in knockout MKs','1 lane each','image only'),
('Supp 4b, 4c','Slc6a8 knockout × creatine: platelet count; α-granules per field (2.6 → 5.1 in controls, 2.3 → 2.3 in knockouts)','3 per group; 8 fields per group','C'),
('Supp 4e','Slc6a8-knockout MKs in culture: control / creatine / liposomal creatine, gene panel','3 per group','D'),
('Supp 5a','Gatm, Gamt mRNA','3 + 3','E'),
('Supp 5b','blots: si-Ckb and CKB overexpression in MKs','1 lane each','image only'),
('Supp 5c','CKB overexpression: MK creatine and phosphocreatine','3 + 3','E'),
('Supp 6a','blot: phospho-STAT5A/B (Y694/699) not detected in MKs; Jurkat + IL-2 control positive','3 lanes per group','F'),
('Supp 6d–6h','blots: in vitro kinase assay (His-CKB), CKB / GATM manipulation in 293T, nuclear STAT5B in MKs','single blots','F'),
('Supp 6i','ChIP-qPCR at Rab4a','3 + 3','F'),
('Supp 7a','platelet count and indices, vehicle / creatine ± STAT5-IN-1: all reported Tukey P ≥ 0.41','3 per group','—'),
('Supp 7b','platelet count and indices, wild-type vehicle / creatine, Stat5b knockout creatine: all reported Tukey P ≥ 0.055','3 per group','—'),
('Supp 8a, 8b','human BMI; platelet count and indices','11','H'),
('Supp 8c','CD41 mRNA: CD41+ cells vs monocytes (5–7% of CD41+ cells) vs MEG-01','3 per group','—'),
('Supp 8d','blots: GP6, P2RY12 in platelets of volunteers 1–4, days 0–14','4 volunteers','H'),
]
for a,b,c,d in idx: w(f"| {a} | {b} | {c} | {d} |")
w()
w('Fig 2e, 2g, 2i, 3g, 4b, 4g, 4i, 4k, 5g–5i, 6d, 6f and Supp 2a, 4a, 5b, 6a, 6d–6h, 8d are images only (no densitometry in the file); they were read qualitatively.')
w()
# ---------------- J
w('## J. Data-integrity, design and labelling flags')
w()
w('1. **Identical animals in two different experiments.** Fig 6b (STAT5 inhibitor study) cells B5:B7 and C5:C7 (burden 3.29136, 3.733544, 2.886353 and 11.13465, 13.22011, 14.12619) and B14:B16, C14:C16 (foci 37, 25, 33 and 53, 62, 47) are identical, value for value, to Supp 2d (platelet-transfer study) cells C8:C10, D8:D10 and C17:C19, D17:D19. Three of five animals in each no-inhibitor arm of Fig 6b are therefore also three of six animals in the "vehicle donor" and "creatine donor" arms of Supp 2d, although one design doses mice directly and the other transfers donor platelets. In Supp 2d the shared animals form a visibly lower cluster (vehicle 2.9–3.7 vs 6.4–9.5; creatine 11.1–14.1 vs 18.0–25.8). Conclusions survive removing them (Supp 2d: creatine vs vehicle donors, Tukey P = 0.0002 with n = 3 + 3; Fig 6b: see section C), but the animal records need to be reconciled before either panel is used as decision-grade evidence.')
w('2. **Study-wide design facts (conventions).** Allocation was randomised but not masked, during the work or at readout. Group sizes were not set by a sample-size calculation. Sex was not analysed; the animals were male C57BL/6J and female BALB/cJ, so sex is confounded with strain and tumour model. Tumour models are not named in the source file apart from "Melanoma" (Fig 1f).')
w('3. **Units of replication.** n is 8 microscope fields per group in Fig 1i, 2c, 2j and Supp 4c (number of animals not given). Aggregation values (Fig 2b, 3d) are triplicates with within-group SD of 1–5 percentage points and no statement that they are separate animals. Fig 7g reports 5 recipient mice per group, not the number of human donors. Fig 7d and 7e use 4 of the 11 volunteers.')
w('4. **Missing arms and controls.** The Stat5b-knockout experiments (Fig 6e–6g, Supp 7b) have three groups and no knockout + vehicle arm; their control is "WT", not a Cre-matched Pf4-iCre control (the Slc6a8 experiments use Pf4-Cre;Slc6a8+/+). There is no metastasis or platelet-function readout for the Stat5b knockout and no in vivo perturbation of CKB. Supp 2d has no vehicle + aspirin arm, and its label ("Creatine+aspirin donor PLT") does not say how or when the aspirin was given. The human study has no control arm.')
w('5. **Inhibitor attribution.** STAT5-IN-1 inhibits STAT5A and STAT5B (conventions) and was dosed orally to the whole animal; the package has no readout of target engagement in megakaryocytes, and the canonical phospho-tyrosine signal is undetectable there (Supp 6a). Without creatine the inhibitor lowers 7 of 11 platelet genes (×0.22–0.69, Fig 6a).')
w('6. **Labels.** Fig 1f, cell G5 labels a comparison "WT-creatine vs. si-Slc6a8-creatine"; numerically it is sh-scrambled-creatine vs sh-Slc6a8-creatine (difference −0.0008667). Supp 2a table says "Si-", its blot says "Sh-". Fig 4d is labelled "Creatinine (umol/g)" although the assay listed is the creatine kit. Fig 7d labels ADRA2A as "ADAR2A". Supp 5a analysis header reads "Vehicle-7". Fig 1h has no y-axis label. Stat5b sheets write "PF4-cre" where the conventions say Pf4-iCre. The ChIP antibody and the "3A" construct are not defined in the file.')
w('7. **Borderline results.** Fig 3c, MK creatine in controls: P = 0.049 (Welch 0.10), n = 3; supported by Fig 4a (×3.05, P = 0.0004) and Fig 6e (×4.7, Tukey P = 0.008) and by the genotype × creatine interaction (P = 0.045). Fig 2d, TEG-MA: P = 0.049 (Welch 0.052). Fig 1l has 20 vehicle and 18 creatine animals with no exclusions recorded.')
w('8. **Immunoblots.** Target and β-actin bands come from different gels (conventions), so ratios to β-actin (Fig 7e) and pan-phospho / FLAG (Fig 5e, 5f) do not control for lane loading on the target gel. Supp 4a shows a reduced but still visible SLC6A8 band in knockout megakaryocytes (one lane each).')
w('9. **Phosphoproteomics.** See section G: screening used unadjusted P; no row reaches Q < 0.05; site information is absent.')
w('10. **Human qPCR.** See section H: volunteer 4 anomalies in PITPNB and RAB27B.')
w('11. **Not counted as flags.** Repeated values inside the qPCR sheets (two-decimal rounding of ΔCt, as the sheets note) and three coincident % input values in the ChIP sheets, which are consistent with the same rounding.')
w()
# ---------------- K
w('## K. Sample-size basis for the proposed in vivo study')
w()
w('- Variability: pooled within-group SD of ln(metastatic burden) across the 31 groups in section B is 0.43 (median 0.33, upper quartile 0.45).')
w('- Observed effect to be confirmed: ratio-of-ratios 4.5 (Fig 3i, log scale; 3.95 on arithmetic means). Unblinded small studies overstate effects, so the design is powered for a ratio-of-ratios of 2.0, roughly half the observed log effect.')
w('- Power for the genotype × creatine interaction (two-sided α = 0.05, four equal groups):')
w()
from scipy.stats import nct, t as tdist
def pw(rr, sd, n):
    se=sd*np.sqrt(4/n); dfree=4*(n-1); ncp=np.log(rr)/se; tc=tdist.ppf(0.975,dfree); return 1-nct.cdf(tc,dfree,ncp)+nct.cdf(-tc,dfree,ncp)
w('| n per group | True ratio-of-ratios 2.0, SD 0.43 | 2.0, SD 0.50 | 3.0, SD 0.43 | 4.5, SD 0.43 |')
w('|---|---|---|---|---|')
for n in (4,8,12,16,20):
    w(f"| {n} | {pw(2.0,0.43,n):.2f} | {pw(2.0,0.50,n):.2f} | {pw(3.0,0.43,n):.2f} | {pw(4.5,0.43,n):.2f} |")
w()
w('The existing experiment (n = 4) had 32% power for a ratio-of-ratios of 2.0. Sixteen per group (8 per sex) gives 89% (78% if the SD is 0.50). For a two-group contrast such as creatine + aspirin vs creatine, 16 per group gives 99% power for a two-fold difference and 73% for 1.5-fold.')
w()
open(os.path.join(OUT,'appendix_evidence_tables.md'),'w').write('\n'.join(out)+'\n')
print('written', len(out))

