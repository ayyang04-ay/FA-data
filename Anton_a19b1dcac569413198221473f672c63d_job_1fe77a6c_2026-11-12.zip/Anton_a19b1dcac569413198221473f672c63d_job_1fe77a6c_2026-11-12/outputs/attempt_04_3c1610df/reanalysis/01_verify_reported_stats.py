'''Recompute every statistical test reported in CRE-MK-01_source_data.xlsx from the raw cells next to it
and compare with the reported P value. Output: verification_reported_vs_recomputed.csv'''
from lib import *
import pandas as pd, re, warnings, os
warnings.filterwarnings('ignore')
R=[]
def rec(sheetname, comp, test, rep, calc):
    try: repf=float(rep)
    except Exception:
        repf=np.nan
    if isinstance(rep,str) and rep.strip().startswith('>'): repf=0.99995
    if isinstance(rep,str) and rep.strip().startswith('<'): repf=5e-5
    ok = (abs(calc-repf)<=max(0.02*max(repf,1e-12), 6e-5)) or (repf<1e-9 and calc<1e-9) or (isinstance(rep,str) and rep.startswith('>') and calc>0.9999) or (isinstance(rep,str) and rep.startswith('<') and calc<1e-4)
    R.append(dict(sheet=sheetname, comparison=comp, test=test, reported_P=rep, recomputed_P=calc, match=bool(ok)))
def tt(name, comp, a, b, rep): rec(name, comp, 'unpaired t', rep, stats.ttest_ind(a,b).pvalue)
# --- two-group sheets
S=sheet
ws=S('Fig. 1a'); tt('Fig. 1a','Lung weight',col(ws,'B',3,8),col(ws,'C',3,8),ws['F4'].value); tt('Fig. 1a','SUV-BW',col(ws,'B',12,17),col(ws,'C',12,17),ws['F12'].value)
ws=S('Fig. 1b'); tt('Fig. 1b','Burden',col(ws,'B',3,8),col(ws,'C',3,8),ws['F3'].value); tt('Fig. 1b','Foci',col(ws,'B',12,17),col(ws,'C',12,17),ws['F12'].value)
ws=S('Fig. 1i'); tt('Fig. 1i','GFP+ cells/field',col(ws,'B',4,11),col(ws,'C',4,11),ws['F4'].value)
ws=S('Fig. 1j'); tt('Fig. 1j','Lung weight',col(ws,'B',4,9),col(ws,'C',4,9),ws['F4'].value); tt('Fig. 1j','SUV-BW',col(ws,'B',13,18),col(ws,'C',13,18),ws['F13'].value)
ws=S('Fig. 1k'); tt('Fig. 1k','Burden',col(ws,'B',4,9),col(ws,'C',4,9),ws['F4'].value); tt('Fig. 1k','Foci',col(ws,'B',12,17),col(ws,'C',12,17),ws['F12'].value)
ws=S('Fig. 1h')
for r,pc in zip([4,5,6,7],['B17','E17','H17','K17']): tt('Fig. 1h',f"t={ws[f'A{r}'].value}h",row(ws,r,'B','G'),row(ws,r,'H','M'),ws[pc].value)
# survival
def logrank(t1,t2):
    times=np.unique(np.r_[t1,t2]); O=E=V=0.0
    for t in times:
        n1=(t1>=t).sum(); n2=(t2>=t).sum(); n=n1+n2; d1=(t1==t).sum(); d=d1+(t2==t).sum()
        O+=d1; E+=d*n1/n
        if n>1: V+=d*(n1/n)*(n2/n)*(n-d)/(n-1)
    return stats.chi2.sf((O-E)**2/V,1)
ws=S('Fig. 1c'); rec('Fig. 1c','Survival','log-rank',ws['F8'].value,logrank(col(ws,'A',4,13),col(ws,'A',14,23)))
ws=S('Fig. 1l'); rec('Fig. 1l','Survival','log-rank',ws['F7'].value,logrank(col(ws,'A',4,23),col(ws,'A',24,41)))
ws=S('Fig. 2a')
for lab,r0,pc in [('PLT',4,'F4'),('PCT',12,'F12'),('PDW',19,'F19'),('MPV',27,'F27')]: tt('Fig. 2a',lab,col(ws,'B',r0,r0+2),col(ws,'C',r0,r0+2),ws[pc].value)
ws=S('Fig. 2b')
for r,pc in zip([4,5,6],['B18','B32','B45']): tt('Fig. 2b',ws[f'A{r}'].value,row(ws,r,'B','D'),row(ws,r,'E','G'),ws[pc].value)
ws=S('Fig. 2c'); tt('Fig. 2c','a-granules',col(ws,'B',4,11),col(ws,'C',4,11),ws['F5'].value)
ws=S('Fig. 2d')
for lab,r0,pc in [('R',4,'F4'),('K',12,'F12'),('alpha',20,'F20'),('MA',28,'F28')]: tt('Fig. 2d','TEG-'+lab,col(ws,'B',r0,r0+4),col(ws,'C',r0,r0+4),ws[pc].value)
ws=S('Fig. 2j'); tt('Fig. 2j','PKH area',col(ws,'B',4,11),col(ws,'C',4,11),ws['F4'].value)
ws=S('Fig. 3b'); tt('Fig. 3b','WT',row(ws,4,'B','F'),row(ws,4,'G','K'),ws['B17'].value); tt('Fig. 3b','KO',row(ws,5,'B','F'),row(ws,5,'G','K'),ws['B31'].value)
ws=S('Fig. 3c'); tt('Fig. 3c','WT',row(ws,4,'B','D'),row(ws,4,'E','G'),ws['B15'].value); tt('Fig. 3c','KO',row(ws,5,'B','D'),row(ws,5,'E','G'),ws['B30'].value)
ws=S('Fig. 4a'); tt('Fig. 4a','MKs',col(ws,'B',4,6),col(ws,'C',4,6),ws['H10'].value); tt('Fig. 4a','Brain',col(ws,'D',4,6),col(ws,'E',4,6),ws['H24'].value)
ws=S('Fig. 4c'); tt('Fig. 4c','MKs',col(ws,'B',4,6),col(ws,'C',4,6),ws['H10'].value); tt('Fig. 4c','Brain',col(ws,'D',4,6),col(ws,'E',4,6),ws['H24'].value)
ws=S('Fig. 4d'); tt('Fig. 4d','MK in vitro',col(ws,'C',4,6),col(ws,'D',4,6),ws['G10'].value)
ws=S('Fig. 4e'); tt('Fig. 4e','Ckb mRNA',row(ws,8,'E','G'),row(ws,8,'I','K'),ws['O5'].value)
ws=S('Fig. 4f'); tt('Fig. 4f','PCr',col(ws,'B',4,6),col(ws,'C',4,6),ws['F4'].value)
ws=S('Fig. 7g')
for lab,r0,pc in [('Lung weight',4,'F4'),('Burden',12,'F12'),('Foci',19,'F19')]: tt('Fig. 7g',lab,col(ws,'B',r0,r0+4),col(ws,'C',r0,r0+4),ws[pc].value)
ws=S('Supplementary Fig  1a'); tt('Supp 1a','d0',row(ws,4,'B','E'),row(ws,4,'F','I'),ws['M11'].value); tt('Supp 1a','d7',row(ws,5,'B','E'),row(ws,5,'F','I'),ws['M25'].value)
for nm,short,r0,r1,pc in [('Supplementary Fig  1b','Supp 1b',4,9,'F4'),('Supplementary Fig  1c','Supp 1c',4,9,'F4'),('Supplementary Fig  1d','Supp 1d',4,9,'F4')]:
    ws=S(nm); tt(short,'',col(ws,'B',r0,r1),col(ws,'C',r0,r1),ws[pc].value)
ws=S('Supplementary Fig  1e')
for lab,r0,r1,pc in [('Lung weight',4,9,'F4'),('Burden',13,18,'F13'),('Foci',22,27,'F22')]: tt('Supp 1e',lab,col(ws,'B',r0,r1),col(ws,'C',r0,r1),ws[pc].value)
ws=S('Supplementary Fig  1f')
for lab,r0,r1,pc in [('Lung weight',4,7,'F4'),('Burden',12,15,'F12'),('Foci',20,23,'F20')]: tt('Supp 1f',lab,col(ws,'B',r0,r1),col(ws,'C',r0,r1),ws[pc].value)
ws=S('Supplementary Fig  1g')
for lab,r0,r1,pc in [('Lung weight',3,12,'F3'),('Burden',15,24,'F15'),('Foci',28,37,'F28')]: tt('Supp 1g',lab,col(ws,'B',r0,r1),col(ws,'C',r0,r1),ws[pc].value)
ws=S('Supplementary Fig  1h'); tt('Supp 1h','serum creatine',col(ws,'C',4,7),col(ws,'D',4,7),ws['F4'].value)
ws=S('Supplementary Fig  1i')
for lab,r0,r1,pc in [('Lung weight',3,6,'F3'),('Burden',11,14,'F11'),('Foci',18,21,'F18')]: tt('Supp 1i',lab,col(ws,'B',r0,r1),col(ws,'C',r0,r1),ws[pc].value)
ws=S('Supplementary Fig  1k')
for lab,r0,r1,pc in [('Lung weight',4,13,'G4'),('Burden',16,25,'G16'),('Foci',29,38,'G29')]: tt('Supp 1k',lab,col(ws,'B',r0,r1),col(ws,'C',r0,r1),ws[pc].value)
ws=S('Supplementary Fig  2a'); tt('Supp 2a','Slc6a8 KD',row(ws,7,'D','F'),row(ws,7,'H','J'),ws['M4'].value)
ws=S('Supplementary Fig  3a')
for lab,r0,pc in [('WBC',4,'F4'),('Lymph',12,'F12'),('Mono',20,'F20'),('RBC',28,'F28')]: tt('Supp 3a',lab,col(ws,'B',r0,r0+4),col(ws,'C',r0,r0+4),ws[pc].value)
ws=S('Supplementary Fig  5a'); tt('Supp 5a','Gatm',row(ws,6,'C','E'),row(ws,6,'G','I'),ws['N10'].value); tt('Supp 5a','Gamt',row(ws,9,'C','E'),row(ws,9,'G','I'),ws['N24'].value)
ws=S('Supplementary Fig  5c'); tt('Supp 5c','MK creatine',col(ws,'B',5,7),col(ws,'C',5,7),ws['F5'].value); tt('Supp 5c','PCr',col(ws,'B',13,15),col(ws,'C',13,15),ws['F13'].value)
ws=S('Supplementary Fig  8a'); tt('Supp 8a','BMI',col(ws,'C',4,14),col(ws,'D',4,14),ws['G5'].value)
# --- Tukey sheets: map reported label -> pair by matching mean diff
def tukey_sheet(name, short, groups, labcol, diffcol, pcol, rows):
    from scipy.stats import tukey_hsd
    res=tukey_hsd(*groups); ws=S(name)
    for r in rows:
        lab=ws[f'{labcol}{r}'].value; d=ws[f'{diffcol}{r}'].value; rp=ws[f'{pcol}{r}'].value
        if lab is None or d is None: continue
        best=None
        for i in range(len(groups)):
            for j in range(len(groups)):
                if i==j: continue
                dd=np.mean(groups[i])-np.mean(groups[j])
                if abs(dd-d)<=max(6e-4*max(abs(d),1e-9)+5e-5*abs(d), abs(d)*2e-3+1e-6):
                    best=(i,j)
        if best is None:
            R.append(dict(sheet=short, comparison=lab, test='Tukey', reported_P=rp, recomputed_P=np.nan, match=False)); continue
        rec(short, str(lab).strip(), 'Tukey', rp, res.pvalue[best])
ws=S('Fig. 1f')
for lab,r0,r1,rr in [('LW',4,9,(4,5,6)),('SUV',13,18,(13,14,15)),('Burden',22,27,(22,23,24)),('Foci',31,36,(31,32,33))]:
    tukey_sheet('Fig. 1f','Fig. 1f '+lab,[col(ws,c,r0,r1) for c in 'BCDE'],'G','H','L',rr)
ws=S('Fig. 3d')
for lab,r,rr in [('ADP',4,(4,5)),('Collagen',5,(10,11)),('Thrombin',6,(15,16))]:
    tukey_sheet('Fig. 3d','Fig. 3d '+lab,[row(ws,r,'B','D'),row(ws,r,'E','G'),row(ws,r,'H','J'),row(ws,r,'K','M')],'O','P','T',rr)
ws=S('Fig. 3i')
for lab,r0,r1,rr in [('LW',3,6,(3,4,5)),('Burden',10,13,(10,11,12)),('Foci',17,20,(17,18,19))]:
    tukey_sheet('Fig. 3i','Fig. 3i '+lab,[col(ws,c,r0,r1) for c in 'BCDE'],'G','H','L',rr)
ws=S('Fig. 5e'); tukey_sheet('Fig. 5e','Fig. 5e vehicle',[col(ws,c,4,6) for c in 'NOPQ'],'M','N','R',(10,11,12,13)); tukey_sheet('Fig. 5e','Fig. 5e creatine',[col(ws,c,17,19) for c in 'NOPQ'],'M','N','R',(22,23,24))
ws=S('Fig. 5f'); tukey_sheet('Fig. 5f','Fig. 5f vehicle',[col(ws,c,4,6) for c in 'NOPQ'],'L','M','Q',(9,10,11,12)); tukey_sheet('Fig. 5f','Fig. 5f creatine',[col(ws,c,17,19) for c in 'NOPQ'],'L','M','Q',(22,23,24))
ws=S('Fig. 6b'); tukey_sheet('Fig. 6b','Fig. 6b burden',[col(ws,c,4,8) for c in 'BCDE'],'G','H','L',(4,5,6,7)); tukey_sheet('Fig. 6b','Fig. 6b foci',[col(ws,c,13,17) for c in 'BCDE'],'G','H','L',(13,14,15,16))
ws=S('Fig. 6e'); tukey_sheet('Fig. 6e','Fig. 6e',[col(ws,c,5,7) for c in 'CDE'],'G','H','L',(5,6,7))
ws=S('Fig. 7b'); tukey_sheet('Fig. 7b','Fig. 7b',[col(ws,c,4,14) for c in 'BCDE'],'G','H','L',(5,6,7))
ws=S('Fig. 7e'); tukey_sheet('Fig. 7e','Fig. 7e GP6',[col(ws,c,4,7) for c in 'BCDE'],'G','H','L',(4,5,6)); tukey_sheet('Fig. 7e','Fig. 7e P2RY12',[col(ws,c,12,15) for c in 'BCDE'],'G','H','L',(12,13,14))
ws=S('Supplementary Fig  2d'); tukey_sheet('Supplementary Fig  2d','Supp 2d burden',[col(ws,c,5,10) for c in 'CDE'],'G','H','L',(5,6,7)); tukey_sheet('Supplementary Fig  2d','Supp 2d foci',[col(ws,c,14,19) for c in 'CDE'],'G','H','L',(14,15,16))
ws=S('Supplementary Fig  4b'); tukey_sheet('Supplementary Fig  4b','Supp 4b',[col(ws,c,5,7) for c in 'CDEF'],'H','I','M',(5,6,7,8))
ws=S('Supplementary Fig  4c'); tukey_sheet('Supplementary Fig  4c','Supp 4c',[col(ws,c,6,13) for c in 'CDEF'],'I','J','N',(7,8,9))
ws=S('Supplementary Fig  7a')
for lab,r0 in [('PLT',4),('PCT',11),('MPV',17),('PDW',23)]: tukey_sheet('Supplementary Fig  7a','Supp 7a '+lab,[col(ws,c,r0,r0+2) for c in 'BCDE'],'G','H','L',(r0,r0+1,r0+2))
ws=S('Supplementary Fig  7b')
for lab,r0 in [('PLT',4),('PCT',10),('MPV',16),('PDW',22)]: tukey_sheet('Supplementary Fig  7b','Supp 7b '+lab,[col(ws,c,r0,r0+2) for c in 'BCD'],'F','G','K',(r0,r0+1,r0+2))
ws=S('Supplementary Fig  8c'); 
from scipy.stats import tukey_hsd
g=[row(ws,9,'E','G'),row(ws,9,'I','K'),row(ws,9,'M','O')]; rec('Supp 8c','CD41+ vs monocyte','Tukey',ws['I15'].value,tukey_hsd(*g).pvalue[0,1])
# --- Dunnett sheets
def dunnett_sheet(name, short, groups, labcol, pcol, rows):
    from scipy.stats import dunnett as dn
    ws=S(name); res=dn(*groups[1:],control=groups[0],random_state=0)
    for k,r in enumerate(rows): rec(short, ws[f'{labcol}{r}'].value, 'Dunnett', ws[f'{pcol}{r}'].value, res.pvalue[k])
ws=S('Fig. 7c')
for lab,r0,r1,rr in [('collagen max',4,14,(4,5,6)),('collagen avg',18,28,(18,19,20)),('collagen adh',32,42,(32,33,34)),('EPI max',46,56,(47,48,49)),('EPI avg',60,70,(61,62,63)),('EPI adh',74,84,(75,76,77)),('AA max',88,98,(88,89,90)),('AA avg',102,112,(103,104,105)),('AA adh',116,126,(117,118,119)),('ADP max',130,140,(131,132,133)),('ADP avg',144,154,(145,146,147)),('ADP adh',157,167,(159,160,161))]:
    dunnett_sheet('Fig. 7c','Fig. 7c '+lab,[col(ws,c,r0,r1) for c in 'BCDE'],'G','L',rr)
ws=S('Supplementary Fig  8b')
for lab,r0,rr in [('PLT',4,(4,5,6)),('PCT',19,(19,20,21)),('MPV',33,(33,34,35)),('PDW',48,(48,49,50))]:
    dunnett_sheet('Supplementary Fig  8b','Supp 8b '+lab,[col(ws,c,r0,r0+10) for c in 'BCDE'],'G','L',rr)
# --- Sidak
def sidak(name, short, rows, vc, cc, labcol, pcol, reprows):
    ws=S(name); V=[row(ws,r,*vc) for r in rows]; C=[row(ws,r,*cc) for r in rows]
    sse=sum(((v-v.mean())**2).sum()+((c-c.mean())**2).sum() for v,c in zip(V,C)); dfe=sum(len(v)+len(c)-2 for v,c in zip(V,C)); mse=sse/dfe; k=len(rows)
    for r,v,c,rr in zip(rows,V,C,reprows):
        t=(v.mean()-c.mean())/np.sqrt(mse*(1/len(v)+1/len(c))); p=2*stats.t.sf(abs(t),dfe); rec(short, ws[f'{labcol}{r}'].value, 'Sidak', ws[f'{pcol}{rr}'].value, 1-(1-p)**k)
sidak('Fig. 5j','Fig. 5j P2ry12',[5,6,7,8],('B','D'),('E','G'),'A','N',[7,8,9,10]); sidak('Fig. 5j','Fig. 5j Gp6',[15,16,17,18],('B','D'),('E','G'),'A','N',[17,18,19,20])
sidak('Supplementary Fig  6i','Supp 6i Rab4a',[7,8,9,10],('C','E'),('F','H'),'B','O',[10,11,12,13])
df=pd.DataFrame(R)
df.to_csv(os.path.join(HERE,'verification_reported_vs_recomputed.csv'),index=False)
print('tests checked:', len(df), ' matched:', int(df.match.sum()), ' not matched:', int((~df.match).sum()))
print(df.groupby('test').match.agg(['count','sum']))
pd.set_option('display.width',250); pd.set_option('display.max_rows',400)
print(df[~df.match].to_string())
