"""Shared helpers for the CRE-MK-01 re-analysis.
Reads the source workbook with openpyxl (cached values), exposes cell-range readers,
basic statistics and the parser for the qPCR sheets."""
import os, itertools
import numpy as np
import openpyxl
from scipy import stats

DATA = os.environ.get('CRE_DATA', '/tmp/world/filesystem')
SRC = os.path.join(DATA, 'CRE-MK-01_source_data.xlsx')
PHOS = os.path.join(DATA, 'CRE-MK-01_phosphoproteomics.xlsx')
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.dirname(HERE)          # /tmp/outputs
_wb = None

def wb():
    global _wb
    if _wb is None:
        _wb = openpyxl.load_workbook(SRC, data_only=True)
    return _wb

def sheet(name):
    return wb()[name]

def col(ws, c, r0, r1):
    """numeric values in column c, rows r0..r1 (blanks and strings skipped)"""
    out = []
    for r in range(r0, r1 + 1):
        v = ws[f'{c}{r}'].value
        if v is not None and not isinstance(v, str):
            out.append(float(v))
    return np.array(out)

def row(ws, r, c0, c1):
    """numeric values in row r, columns c0..c1"""
    from openpyxl.utils import column_index_from_string, get_column_letter
    out = []
    for ci in range(column_index_from_string(c0), column_index_from_string(c1) + 1):
        v = ws[f'{get_column_letter(ci)}{r}'].value
        if v is not None and not isinstance(v, str):
            out.append(float(v))
    return np.array(out)

def desc(x):
    x = np.asarray(x, float)
    return f"n={len(x)} mean={x.mean():.4g} sd={x.std(ddof=1) if len(x) > 1 else float('nan'):.4g}"

def ttest(a, b):
    t, p = stats.ttest_ind(a, b)
    tw, pw = stats.ttest_ind(a, b, equal_var=False)
    try:
        u, pu = stats.mannwhitneyu(a, b, alternative='two-sided')
    except Exception:
        pu = np.nan
    return dict(t=abs(t), df=len(a) + len(b) - 2, p=p, p_welch=pw, p_mwu=pu)

def hedges_g(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    sp = np.sqrt(((len(a) - 1) * a.var(ddof=1) + (len(b) - 1) * b.var(ddof=1)) / (len(a) + len(b) - 2))
    d = (b.mean() - a.mean()) / sp
    return d * (1 - 3 / (4 * (len(a) + len(b)) - 9))

def tukey(groups, names):
    """one-way ANOVA + Tukey HSD; returns F, p, {(name_i, name_j): (mean_i - mean_j, adjusted p)}"""
    from scipy.stats import tukey_hsd, f_oneway
    F, p = f_oneway(*groups)
    res = tukey_hsd(*groups)
    out = {}
    for i, j in itertools.combinations(range(len(groups)), 2):
        out[(names[i], names[j])] = (np.mean(groups[i]) - np.mean(groups[j]), res.pvalue[i, j])
    return F, p, out

def dunnett(groups, names, control=0):
    from scipy.stats import dunnett as dn
    others = [g for k, g in enumerate(groups) if k != control]
    res = dn(*others, control=groups[control])
    out = {}; k = 0
    for i, g in enumerate(groups):
        if i == control:
            continue
        out[(names[control], names[i])] = (np.mean(groups[control]) - np.mean(g), res.pvalue[k]); k += 1
    return out

def parse_qpcr(name, header_row, gene_col='A'):
    """Parse a qPCR sheet. Returns ({gene: {group: fold values}}, raw).
    Control group = 'After normalization' row (2^dCT / mean); treated groups = '2^(dCTx - dCT1)' rows."""
    ws = sheet(name)
    hdr = {c.column: str(c.value) for c in ws[header_row] if c.value is not None}
    out = {}; raw = {}
    genes = []
    for r in range(header_row + 1, ws.max_row + 1):
        g = ws[f'{gene_col}{r}'].value
        if isinstance(g, str) and g.strip() and not g.startswith('Graphs') and not g.startswith('Note'):
            genes.append((g.strip(), r))
    for gi, (g, r0) in enumerate(genes):
        r1 = genes[gi + 1][1] - 1 if gi + 1 < len(genes) else min(ws.max_row, r0 + 4)
        block = {}; rawb = {}
        for rr in range(r0, r1 + 1):
            for c in ws[rr]:
                v = c.value
                if isinstance(v, str):
                    lab = v.strip(); vals = []; ci = c.column + 1
                    while ci <= ws.max_column:
                        vv = ws.cell(row=rr, column=ci).value
                        if vv is None or isinstance(vv, str):
                            break
                        vals.append(float(vv)); ci += 1
                    if vals:
                        cands = [k for k in hdr if k <= c.column + 1]
                        grp = hdr[max(cands)] if cands else '?'
                        if lab.startswith('After normalization'):
                            block.setdefault(grp, np.array(vals))
                        elif lab.startswith('2^('):
                            block[grp] = np.array(vals)
                        rawb[(lab, grp, rr)] = np.array(vals)
        out[g] = block; raw[g] = rawb
    return out, raw

def freedman_lane(groups, nperm=50000, log=False, seed=11):
    """Residual-permutation (Freedman-Lane) test of the 2x2 interaction: robustness check on the least-squares P."""
    rng=np.random.default_rng(seed)
    y=np.concatenate([np.log(g) if log else g for g in groups]); n=[len(g) for g in groups]
    cre=np.r_[np.zeros(n[0]),np.ones(n[1]),np.zeros(n[2]),np.ones(n[3])]; per=np.r_[np.zeros(n[0]+n[1]),np.ones(n[2]+n[3])]
    X0=np.c_[np.ones(len(y)),cre,per]; X1=np.c_[X0,cre*per]; XtXi=np.linalg.inv(X1.T@X1); H=XtXi@X1.T
    def tstat(v):
        b=H@v; r=v-X1@b; return b[3]/np.sqrt((r@r)/(len(v)-4)*XtXi[3,3])
    fit=X0@np.linalg.lstsq(X0,y,rcond=None)[0]; r0=y-fit
    obs=abs(tstat(y)); cnt=sum(abs(tstat(fit+rng.permutation(r0)))>=obs-1e-12 for _ in range(nperm))
    return (cnt+1)/(nperm+1)
