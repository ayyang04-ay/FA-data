'''Exact-duplicate scan of numeric cells across sheets, and the Fig 6b / Supp Fig 2d overlap with sensitivity analyses.
Output: duplicate_scan.txt'''
from lib import *
import collections, re, os
QPCR = {'Fig. 2f', 'Fig. 3f', 'Fig. 4h', 'Fig. 4j', 'Fig. 4l', 'Fig.6a', 'Fig. 6g', 'Supplementary Fig  3c', 'Supplementary Fig  4e',
        'Fig. 4e', 'Supplementary Fig  2a', 'Supplementary Fig  5a', 'Supplementary Fig  8c', 'Fig. 7d'}
L = []
def w(s=''):
    print(s); L.append(s)
occ = collections.defaultdict(list)
for ws in wb().worksheets:
    for r in ws.iter_rows():
        for c in r:
            v = c.value
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                occ[round(float(v), 10)].append((ws.title, c.coordinate))
def sig_digits(v):
    return len(re.sub(r'[^0-9]', '', repr(v).split('e')[0]).strip('0'))
w('--- identical non-integer values (>= 4 significant digits) in two or more non-qPCR sheets')
for v, locs in sorted(occ.items()):
    loc2 = [l for l in locs if l[0] not in QPCR]
    if len(set(s for s, _ in loc2)) > 1 and v != int(v) and sig_digits(v) >= 4:
        w(f"{v}: {loc2}")
w('\n--- identical values (>= 5 significant digits) repeated within a non-qPCR sheet')
for v, locs in sorted(occ.items()):
    by = collections.defaultdict(list)
    for s, c in locs:
        if s not in QPCR:
            by[s].append(c)
    for s, cs in by.items():
        if len(cs) > 1 and v != int(v) and sig_digits(v) >= 5:
            w(f"{s}: {v} at {cs}")
w('\n--- Fig 6b vs Supp Fig 2d')
a = sheet('Fig. 6b'); b = sheet('Supplementary Fig  2d')
w('Fig 6b burden (Vehicle, Creatine, Vehicle+inhibitor, Creatine+inhibitor), rows 4-8:')
for r in range(4, 9): w(f"   {[a[f'{c}{r}'].value for c in 'BCDE']}")
w('Fig 6b foci, rows 13-17:')
for r in range(13, 18): w(f"   {[a[f'{c}{r}'].value for c in 'BCDE']}")
w('Supp 2d burden (Vehicle donor, Creatine donor, Creatine+aspirin donor), rows 5-10:')
for r in range(5, 11): w(f"   {[b[f'{c}{r}'].value for c in 'CDE']}")
w('Supp 2d foci, rows 14-19:')
for r in range(14, 20): w(f"   {[b[f'{c}{r}'].value for c in 'CDE']}")
names = ['Veh', 'Cre', 'Veh+S5i', 'Cre+S5i']
g = [col(a, c, 4, 8) for c in 'BCDE']
shared_v = (3.29136, 3.733544, 2.886353); shared_c = (11.13465, 13.22011, 14.12619)
g2 = [np.array([x for x in g[0] if x not in shared_v]), np.array([x for x in g[1] if x not in shared_c]), g[2], g[3]]
F, p, tk = tukey(g2, names)
w(f"Fig 6b burden without the shared animals: n = {[len(x) for x in g2]}; ANOVA P = {p:.2g}")
for k, v in tk.items(): w(f"   Tukey {k}: diff {v[0]:.2f}, P = {v[1]:.2g}")
n2 = ['VehPLT', 'CrePLT', 'Cre+AspPLT']
h = [col(b, c, 5, 10) for c in 'CDE']
for lab, hh in [('all animals', h), ('without the shared animals (rows 8-10 of the first two columns)', [h[0][:3], h[1][:3], h[2]])]:
    F, p, tk = tukey(hh, n2)
    w(f"Supp 2d burden, {lab}: n = {[len(x) for x in hh]}; means {[round(float(x.mean()), 2) for x in hh]}; ANOVA P = {p:.2g}")
    for k, v in tk.items(): w(f"   Tukey {k}: diff {v[0]:.2f}, P = {v[1]:.2g}")
open(os.path.join(HERE, 'duplicate_scan.txt'), 'w').write('\n'.join(L) + '\n')
