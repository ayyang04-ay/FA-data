# CRE-MK-01 — evidence appendix (re-analysis tables)

Companion to `proposal.md`. Every number below was recomputed from the raw cells of `CRE-MK-01_source_data.xlsx` (87 sheets, 26 embedded blot images) and `CRE-MK-01_phosphoproteomics.xlsx` (5,812 rows); conventions are from `study_conventions.pdf`. Nothing external was used.

## A. How the numbers were derived

- **Reproduction of the file's own statistics.** All 232 reported tests were recomputed from the raw values next to them: 71 unpaired two-tailed t tests, 99 Tukey comparisons (one-way ANOVA), 48 Dunnett comparisons, 12 Sidak comparisons (two-way ANOVA) and 2 log-rank tests. 232 of 232 match the reported P values (`reanalysis/verification_reported_vs_recomputed.csv`). The arithmetic in the package is sound; the issues in section J are about design, units of replication and labelling.
- **Added analyses.** (i) Creatine × perturbation interaction for every 2×2 design (ordinary least squares on the raw scale, as the file analyses them, and on the natural-log scale to give a ratio-of-ratios with 95% CI). (ii) Ratio of group means with 95% CI (log response ratio, delta method) for every metastasis cohort, pooled by DerSimonian–Laird random effects. (iii) Cox hazard ratios (Efron handling of ties) for the two survival panels. (iv) qPCR: group means of the fold values given in the sheets; P values from unpaired t tests on log2 fold values (n = 3 per group). (v) Human fold-change data: Wilcoxon signed-rank test against no change and responder counts, because the file normalises each volunteer to 1.0 at day 0 (a zero-variance reference group) and then applies Dunnett. (vi) Exact-duplicate scan of all numeric cells across sheets. (vii) Phosphoproteomics: counts at the study screening criteria, q-value range, Benjamini–Hochberg check, and the pattern of tied P values. (viii) Sample size: non-central t for a 2×2 interaction on ln(burden).
- **Units.** n is given as in the file. Where the conventions state that n is a microscope field (Fig 1i, 2c, 2j, Supp 4c) or where the replicate type is not stated (aggregation, qPCR), this is flagged rather than corrected.
- **In vivo versus culture.** Megakaryocyte sheets labelled Vehicle / Creatine are read as cells isolated from treated mice, and sheets labelled Control / Creatine as cells treated in culture. This follows the blot captions ("Isolated MKs" versus "MKs (in vitro)") and the dosing table in the conventions; the sheets themselves do not state it.

## B. Creatine and lung metastatic burden: every cohort in the package

| Panel | Context | n (control + creatine) | Burden %, control → creatine | Ratio of means (95% CI) | P (t test) |
|---|---|---|---|---|---|
| Fig 1b | oral creatine, three times a week | 6 + 6 | 5.19 → 16.17 | 3.12 (2.02–4.81) | 0.0005 |
| Fig 1k | second cohort (model not named in file) | 6 + 6 | 7.24 → 16.40 | 2.27 (1.87–2.74) | 5.8e-5 |
| Fig 1f | melanoma, sh-scrambled tumour cells | 6 + 6 | 4.55 → 15.94 | 3.50 (2.03–6.04) | 0.0003 |
| Fig 1f | melanoma, tumour-cell sh-Slc6a8 | 6 + 6 | 5.81 → 18.30 | 3.15 (2.49–3.99) | 1.6e-5 |
| Fig 3i | Pf4-Cre;Slc6a8+/+ (Cre control) | 4 + 4 | 2.36 → 7.91 | 3.35 (2.10–5.33) | 0.001 |
| Fig 3i | **Pf4-Cre;Slc6a8fl/fl (MK-lineage knockout)** | 4 + 4 | 3.39 → 2.88 | 0.85 (0.51–1.42) | 0.53 |
| Fig 6b | no inhibitor † | 5 + 5 | 3.45 → 13.86 | 4.02 (2.99–5.41) | 3.7e-5 |
| Fig 6b | **+ STAT5-IN-1** | 5 + 5 | 3.63 → 4.49 | 1.24 (0.86–1.78) | 0.26 |
| Supp 1e | model not named | 6 + 6 | 16.23 → 33.56 | 2.07 (1.50–2.86) | 0.001 |
| Supp 1f | model not named | 4 + 4 | 3.89 → 10.78 | 2.77 (1.74–4.42) | 0.009 |
| Supp 1g | model not named | 10 + 10 | 7.59 → 26.20 | 3.45 (2.18–5.46) | 2.5e-7 |
| Supp 1i | 5% creatine diet vs control diet | 4 + 4 | 7.29 → 26.22 | 3.60 (2.40–5.39) | 0.005 |
| Supp 1k | model not named | 10 + 10 | 3.77 → 13.36 | 3.54 (2.26–5.55) | 0.0008 |
| Supp 2d | recipients of platelets from creatine- vs vehicle-treated donors † | 6 + 6 | 5.86 → 17.92 | 3.06 (1.86–5.04) | 0.002 |
| Supp 2d | **recipients of platelets from creatine + aspirin donors** vs vehicle donors | 6 + 6 | 5.86 → 4.36 | 0.74 (0.43–1.27) | 0.33 |
| Fig 7g | mice given human platelets, volunteer day 7 vs day 0 | 5 + 5 | 4.65 → 12.66 | 2.72 (1.57–4.72) | 0.014 |

Pooled estimate for the ten directly dosed, unperturbed cohorts (Fig 1b, 1k, 1f sh-scrambled, 3i Cre control, 6b no inhibitor, Supp 1e, 1f, 1g, 1i, 1k; 61 + 61 mice): **ratio 3.02 (95% CI 2.54–3.58)**, range 2.07–4.02, I² = 51%. † Fig 6b and Supp 2d share three vehicle and three creatine animals (section J).

Other metastasis readouts in the same cohorts:

| Panel | Readout | Control → creatine |
|---|---|---|
| Fig 1a | lung weight (g) | 0.227 → 0.324 (×1.43; P = 0.0003; n = 6+6) |
| Fig 1a | SUV-BW | 418 → 894 (×2.14; P = 0.003; n = 6+6) |
| Fig 1b | metastatic foci | 27.7 → 53.2 (×1.92; P = 0.0006; n = 6+6) |
| Fig 1j | lung weight (g) | 0.185 → 0.302 (×1.63; P = 0.001; n = 6+6) |
| Fig 1j | SUV-BW | 614 → 1032 (×1.68; P = 0.0008; n = 6+6) |
| Fig 1k | metastatic foci | 25.5 → 42.2 (×1.65; P = 5.7e-5; n = 6+6) |
| Supp 1e | lung weight (g) | 0.220 → 0.294 (×1.34; P = 0.027; n = 6+6) |
| Supp 1e | metastatic foci | 40.7 → 66.8 (×1.64; P = 0.0003; n = 6+6) |
| Supp 1f | lung weight (g) | 0.147 → 0.180 (×1.22; P = 0.023; n = 4+4) |
| Supp 1f | metastatic foci | 7.00 → 18.5 (×2.64; P = 0.002; n = 4+4) |
| Supp 1g | lung weight (g) | 0.207 → 0.278 (×1.34; P = 0.032; n = 10+10) |
| Supp 1g | metastatic foci | 14.8 → 44.7 (×3.02; P = 1.2e-5; n = 10+10) |
| Supp 1i | lung weight (g) | 0.253 → 0.362 (×1.44; P = 0.002; n = 4+4) |
| Supp 1i | metastatic foci | 17.0 → 25.5 (×1.50; P = 0.003; n = 4+4) |
| Supp 1k | lung weight (g) | 0.153 → 0.199 (×1.30; P = 0.036; n = 10+10) |
| Supp 1k | metastatic foci | 3.40 → 8.30 (×2.44; P = 2.5e-5; n = 10+10) |
| Fig 7g | lung weight (g), human-platelet recipients | 0.186 → 0.236 (×1.27; P = 0.020; n = 5+5) |
| Fig 7g | metastatic foci, human-platelet recipients | 21.8 → 39.4 (×1.81; P = 0.012; n = 5+5) |

Survival: Fig 1c, median 22 → 19 days, log-rank χ² = 4.58, P = 0.032, Cox hazard ratio 2.9 (95% CI 1.0–8.2), n = 10 + 10. Fig 1l, median 16 → 14 days, χ² = 6.47, P = 0.011, Cox hazard ratio 2.3 (95% CI 1.2–4.5), n = 20 + 18. Event times are heavily tied, so the hazard ratio depends on the estimator (Mantel–Haenszel gives 3.3 and 2.8).

Early lung signal after tumour-cell injection (Fig 1h; y-axis not labelled in the file), control → creatine: 0.25 h 7.31 → 6.25 (×0.86, P = 0.31); 6 h 0.35 → 0.53 (×1.51, P = 0.0002); 12 h 0.28 → 0.49 (×1.79, P = 0.026); 24 h 0.15 → 0.40 (×2.76, P = 0.004); n = 6 + 6. GFP+ cells per field (Fig 1i): 9.12 → 20.4 (×2.23; P = 5.5e-7; n = 8+8) — n is 8 microscope fields per group.

Exposure and tolerability: serum creatine 65.9 → 179 µM (×2.71; P = 3.8e-10; n = 6+6) on oral dosing (Supp 1d) and 78.2 → 227 µM (×2.91; P = 2.0e-5; n = 4+4) on the 5% diet (Supp 1h). Body weight at day 7 21.8 → 23.1 g (×1.06; P = 0.084; n = 4+4) (Supp 1a); food intake 2.86 → 2.86 g/day (×1.00; P = 0.99; n = 6+6); water intake 5.10 → 5.02 g/day (×0.98; P = 0.83; n = 6+6). Blood counts unchanged (Supp 3a: WBC P = 0.36, lymphocytes 0.84, monocytes 0.54, RBC 0.11; n = 5 + 5).

## C. Factorial analyses: which perturbation removes the creatine effect

| Panel | Perturbation | Readout | n/group | Creatine effect, control arm | Creatine effect, perturbed arm | Interaction P (raw scale) | Ratio-of-ratios (95% CI), log scale | Perturbation alone vs control |
|---|---|---|---|---|---|---|---|---|
| Fig 3i | MK-lineage Slc6a8 knockout | burden % | 4 | 2.36 → 7.91 (×3.35) | 3.39 → 2.88 (×0.85) | 0.0003 | 4.48 (2.13–9.43) | ×1.43 (P = 0.14) |
| Fig 3i | MK-lineage Slc6a8 knockout | foci | 4 | 29.8 → 56.5 (×1.90) | 26.5 → 24.8 (×0.93) | 0.004 | 2.22 (1.14–4.31) | ×0.89 (P = 0.57) |
| Fig 3i | MK-lineage Slc6a8 knockout | lung weight | 4 | 0.206 → 0.249 (×1.21) | 0.222 → 0.225 (×1.01) | 0.0002 | 1.19 (1.11–1.28) | ×1.08 (P = 0.030) |
| Fig 6b | STAT5-IN-1 (STAT5A + STAT5B, systemic) | burden % | 5 | 3.45 → 13.9 (×4.02) | 3.63 → 4.49 (×1.24) | 6.7e-6 | 3.15 (1.84–5.39) | ×1.05 (P = 0.81) |
| Fig 6b | STAT5-IN-1 (STAT5A + STAT5B, systemic) | foci | 5 | 30.2 → 58.2 (×1.93) | 29.6 → 27.2 (×0.92) | 0.0007 | 2.07 (1.37–3.13) | ×0.98 (P = 0.89) |
| Fig 1f | tumour-cell Slc6a8 knockdown (melanoma) | burden % | 6 | 4.55 → 15.9 (×3.50) | 5.81 → 18.3 (×3.15) | 0.68 | 1.29 (0.66–2.54) | ×1.28 (P = 0.35) |
| Fig 1f | tumour-cell Slc6a8 knockdown (melanoma) | foci | 6 | 10.7 → 27.3 (×2.56) | 13.8 → 30.8 (×2.23) | 0.95 | 1.16 (0.66–2.03) | ×1.30 (P = 0.25) |
| Fig 1f | tumour-cell Slc6a8 knockdown (melanoma) | lung weight | 6 | 0.187 → 0.309 (×1.66) | 0.230 → 0.310 (×1.35) | 0.21 | 1.23 (0.96–1.58) | ×1.23 (P = 0.010) |
| Fig 1f | tumour-cell Slc6a8 knockdown (melanoma) | SUV-BW | 6 | 967 → 1250 (×1.29) | 964 → 1284 (×1.33) | 0.66 | 0.97 (0.83–1.13) | ×1.00 (P = 0.97) |

Robustness: a residual-permutation (Freedman–Lane) test of the burden interaction, which does not assume normal errors, gives P = 0.0005 for Fig 3i, 4.0e-5 for Fig 6b and 0.69 for Fig 1f (50,000 permutations, raw scale). In Fig 3i the creatine arms of the two genotypes do not overlap (control 6.9–10.3%, knockout 1.9–4.9%).

Reading: a ratio-of-ratios of 1 means the perturbation does not change the creatine effect. MK-lineage Slc6a8 deletion and STAT5-IN-1 both remove it; knocking Slc6a8 down in the tumour cells (19% of control mRNA remaining, Supp 2a, P = 0.0008) does not.

Sensitivity of Fig 6b to the shared animals: dropping the three vehicle and three creatine values that also appear in Supp 2d leaves n = 2 + 2 in the no-inhibitor arms; creatine vs creatine + inhibitor is still separated (Tukey P = 9e-5), but the control arms then rest on two animals each.

Megakaryocyte and platelet readouts in the Slc6a8 knockout (Fig 3b–3d), vehicle → creatine:

| Readout | Pf4-Cre;Slc6a8+/+ | Pf4-Cre;Slc6a8fl/fl | Note |
|---|---|---|---|
| Serum creatine, µM (Fig 3b, n = 5) | 89 → 239 (×2.70) | 89 → 218 (×2.44) | exposure is the same in both genotypes (creatine arms, P = 0.18) |
| MK intracellular creatine, µmol/g (Fig 3c, n = 3) | 13.7 → 72.1 (×5.27; P = 0.049, Welch 0.10) | 13.7 → 21.1 (×1.54; P = 0.20) | interaction P = 0.045 |
| Aggregation, ADP, % (Fig 3d, n = 3) | 63.3 → 70.7 (Tukey P = 0.0010) | 54.0 → 31.3 (Tukey P = 2.2e-7) | knockout + vehicle vs control + vehicle: -9.3 points (P = 0.0002) |
| Aggregation, collagen, % (Fig 3d, n = 3) | 64.7 → 76.7 (Tukey P = 6.4e-6) | 60.7 → 50.7 (Tukey P = 2.6e-5) | knockout + vehicle vs control + vehicle: -4.0 points (P = 0.012) |
| Aggregation, thrombin, % (Fig 3d, n = 3) | 61.3 → 74.7 (Tukey P = 2.9e-6) | 45.3 → 35.3 (Tukey P = 2.6e-5) | knockout + vehicle vs control + vehicle: -16.0 points (P = 7.0e-7) |
| Platelet count, ×10⁹/L (Supp 4b, n = 3) | 890 → 909 | 1042 → 992 | one-way ANOVA P = 0.66 |

In the knockout, creatine lowers aggregation below the knockout baseline, and the knockout baseline is itself below the Cre-control baseline. Within-group SDs in Fig 3d are 1–1.2 percentage points, which looks like run-to-run precision; the file does not say whether the three values are three animals.

## D. Megakaryocyte platelet-gene panel (11 genes), by perturbation

| Panel | Comparison | Fold range across the 11 genes | Genes up, P < 0.05 | Genes down, P < 0.05 |
|---|---|---|---|---|
| Fig 2f | MKs from creatine- vs vehicle-treated mice | 1.67–5.73 (median 3.13) | 10/11 | 0/11 |
| Fig 3f | Cre control: creatine vs vehicle | 2.06–5.62 (median 3.79) | 10/11 | 0/11 |
| Fig 3f | Slc6a8 knockout: creatine vs knockout vehicle | 0.39–1.53 (median 1.00) | 0/11 | 3/11 |
| Fig 3f | Slc6a8 knockout vehicle vs Cre-control vehicle | 0.34–2.27 (median 0.97) | 0/11 | 1/11 |
| Supp 4e | Slc6a8-knockout MKs in culture: free creatine vs control | 0.18–1.50 (median 1.05) | 2/11 | 2/11 |
| Supp 4e | Slc6a8-knockout MKs in culture: liposomal creatine vs control | 0.80–3.98 (median 2.76) | 9/11 | 0/11 |
| Fig 4h | cultured MKs: creatine vs control | 1.90–12.13 (median 3.36) | 10/11 | 0/11 |
| Fig 4h | cultured MKs: phosphocreatine vs control | 0.32–1.12 (median 0.66) | 0/11 | 2/11 |
| Fig 4j | si-scrambled: creatine vs control | 1.75–7.43 (median 4.26) | 11/11 | 0/11 |
| Fig 4j | creatine: si-Ckb vs si-scrambled | 0.10–0.50 (median 0.29) | 0/11 | 10/11 |
| Fig 4j | no creatine: si-Ckb vs si-scrambled | 0.55–0.91 (median 0.72) | 0/11 | 5/11 |
| Fig 4j | si-Ckb: creatine vs control | 0.58–3.18 (median 1.55) | 5/11 | 0/11 |
| Fig 4l | CKB overexpression vs empty vector (no added creatine) | 1.76–6.36 (median 2.44) | 10/11 | 0/11 |
| Fig 6a | creatine vs vehicle | 1.93–44.09 (median 4.39) | 10/11 | 0/11 |
| Fig 6a | creatine: + STAT5-IN-1 vs none | 0.01–0.57 (median 0.14) | 0/11 | 11/11 |
| Fig 6a | no creatine: STAT5-IN-1 vs vehicle | 0.22–1.03 (median 0.56) | 0/11 | 7/11 |
| Fig 6g | wild type: creatine vs vehicle | 2.07–4.57 (median 4.08) | 11/11 | 0/11 |
| Fig 6g | creatine: Stat5b knockout vs wild type | 0.13–0.60 (median 0.31) | 0/11 | 11/11 |
| Fig 6g | Stat5b knockout + creatine vs wild-type vehicle | 0.35–2.01 (median 1.34) | 3/11 | 1/11 |

Per-gene residual expression under creatine when each node is perturbed (fold of the untreated control; 1.0 = back to baseline):

| Gene | Creatine, unperturbed (Fig 3f / 6g / 6a / 4j) | Slc6a8 knockout + creatine (Fig 3f) | Stat5b knockout + creatine (Fig 6g) | STAT5-IN-1 + creatine (Fig 6a) | si-Ckb + creatine, in vitro (Fig 4j) |
|---|---|---|---|---|---|
| *Itga2b* | 2.15 / 4.01 / 4.80 / 4.26 | 0.78 | 1.04 | 0.57 | 1.33 |
| *P2ry12* | 2.06 / 4.57 / 4.39 / 5.23 | 1.08 | 2.01 | 1.25 | 1.34 |
| *Gp6* | 3.79 / 2.78 / 44.09 / 4.32 | 0.96 | 1.44 * | 0.65 | 1.42 |
| *Gpiba* | 5.62 / 2.74 / 2.27 / 4.54 | 0.81 | 1.66 | 0.60 | 1.37 |
| *F2r* | 3.00 / 4.08 / 10.51 / 2.89 | 1.84 | 1.60 * | 0.18 | 0.84 |
| *Adra2a* | 2.36 / 4.28 / 17.70 / 4.54 | 0.51 | 1.89 * | 0.52 | 1.78 |
| *Fcgr2a* | 3.27 / 4.18 / 4.59 / 3.42 | 3.36 * | 0.55 | 0.63 | 0.91 |
| *Runx1* | 3.86 / 4.53 / 3.35 / 2.61 | 0.51 | 1.03 | 0.86 | 0.57 |
| *Rab4a* | 3.81 / 4.33 / 3.54 / 2.79 | 1.08 | 1.34 | 0.25 | 1.38 |
| *Rab27b* | 4.96 / 2.07 / 1.93 / 1.75 | 0.88 | 0.34 | 1.09 | 0.48 |
| *Pitpnb* | 4.84 / 3.79 / 4.10 / 7.43 | 0.37 | 0.76 | 0.65 | 0.76 |

\* still above the untreated control at P < 0.05. Median share of the creatine-induced increment removed: Slc6a8 knockout 103%, Stat5b knockout 90%, STAT5-IN-1 109%, si-Ckb 92%. For the two receptor genes with human follow-up, the Stat5b knockout removes 72% (*P2ry12*) and 75% (*Gp6*) of the increment; the Slc6a8 knockout removes 92% and 101%. *Fcgr2a* is high in Slc6a8-knockout MKs with or without creatine (2.27 and 3.36). The Stat5b-knockout experiment has no knockout + vehicle arm, so residuals are expressed against wild-type vehicle.

MK maturation genes (Supp 3c, creatine vs vehicle, n = 3): *Nfe2* ×0.79 (P = 0.28); *Gata1* ×0.79 (P = 0.43); *Zfpm1* ×1.30 (P = 0.53); *Hsd3b1* ×1.44 (P = 0.016); *Itgb3* ×1.01 (P = 0.93); *Tubb1* ×0.90 (P = 0.72); *Lims1* ×1.28 (P = 0.32); *Myl9* ×0.52 (P = 0.019); *Casp12* ×1.88 (P = 0.011).

## E. Creatine, phosphocreatine and CKB in megakaryocytes

| Panel | Measurement | Control → treated |
|---|---|---|
| Fig 4a | MK creatine, µmol/g, vehicle → creatine in vivo | 42.2 → 129 (×3.05; P = 0.0004; n = 3+3) |
| Fig 4a | brain creatine, µmol/g | 95.7 → 114 (×1.19; P = 0.027; n = 3+3) |
| Fig 4c | MK phosphocreatine, ng/µg | 0.375 → 1.46 (×3.90; P = 0.0006; n = 3+3) |
| Fig 4c | brain phosphocreatine, ng/µg | 0.321 → 0.627 (×1.95; P = 0.031; n = 3+3) |
| Fig 4d | cultured MKs, creatine (sheet label reads 'Creatinine'), µmol/g | 29.8 → 109 (×3.64; P = 0.005; n = 3+3) |
| Fig 4f | cultured MKs, phosphocreatine, ng/µg | 0.230 → 1.24 (×5.40; P = 0.023; n = 3+3) |
| Fig 4e | *Ckb* mRNA in MKs, fold | 1.000 → 1.82 (×1.82; P = 0.011; n = 3+3) |
| Supp 5a | *Gatm* mRNA, fold | 1.00 → 1.15 (×1.15; P = 0.37; n = 3+3) |
| Supp 5a | *Gamt* mRNA, fold | 1.000 → 0.876 (×0.88; P = 0.61; n = 3+3) |
| Supp 5c | MK creatine, µmol/g, empty vector → CKB overexpression | 33.7 → 32.7 (×0.97; P = 0.61; n = 3+3) |
| Supp 5c | MK phosphocreatine, ng/µg, empty vector → CKB overexpression | 0.170 → 0.213 (×1.25; P = 0.16; n = 3+3) |
| Fig 6e | MK creatine, µmol/g: wild-type vehicle / wild-type creatine / Stat5b knockout creatine | 20.3 / 95.2 / 98.2; wild type vs knockout on creatine, Tukey P = 0.98; n = 3 |

Blot-only evidence (no densitometry in the file): CKB protein rises in MKs from creatine-treated mice and is far more abundant in brain, where it changes little (Fig 4b); CKB rises in cultured MKs with creatine (Fig 4e, 4g); GP6 and P2RY12 rise with creatine but not with phosphocreatine (Fig 4g), are blunted by si-Ckb (Fig 4i) and rise with CKB overexpression (Fig 4k); knockdown and overexpression are confirmed in Supp 5b.

## F. STAT5B phosphorylation and promoter occupancy

Pan-phospho / FLAG densitometry of FLAG-STAT5B constructs (Fig 5e and 5f; three blots each; the cell system for each panel is not stated in the file):

| Panel | Construct | Vehicle | Creatine | Creatine / vehicle |
|---|---|---|---|---|
| Fig 5e | WT | 0.716 | 0.997 | ×1.39 (P = 0.009) |
| Fig 5e | S127A | 0.785 | 0.829 | ×1.06 (P = 0.50) |
| Fig 5e | 3A | 0.774 | 0.736 | ×0.95 (P = 0.46) |
| Fig 5e | S127D | 1.045 | 1.009 | ×0.97 (P = 0.66) |
| Fig 5f | WT | 0.755 | 0.966 | ×1.28 (P = 0.086) |
| Fig 5f | S127A | 0.720 | 0.634 | ×0.88 (P = 0.35) |
| Fig 5f | 3A | 0.762 | 0.671 | ×0.88 (P = 0.30) |
| Fig 5f | S127D | 1.019 | 0.994 | ×0.98 (P = 0.73) |

- Fig 5e: under creatine, WT exceeds S127A by 0.168 (Tukey P = 0.029, as reported); construct × creatine interaction (WT vs S127A) P = 0.024. S127D reads high with or without creatine.
- Fig 5f: under creatine, WT exceeds S127A by 0.332 (Tukey P = 0.016, as reported); construct × creatine interaction (WT vs S127A) P = 0.043. S127D reads high with or without creatine.
- The vehicle-versus-creatine comparison is not tested in the file, and in the third replicate of both panels ("Duplicate 2") vehicle and creatine samples are on separate blots. The antibody is pan-phospho, not site-specific; "3A" is not defined in the file.
- Canonical phospho-STAT5A/B (Y694/699) is not detectable in MKs from vehicle- or creatine-treated mice, while the Jurkat + IL-2 positive control is positive and total STAT5B is unchanged (Supp 6a, blot).
- Other blot-only evidence: CKB overexpression raises the pan-phospho signal on WT STAT5B in si-GATM cells, with S127A faint throughout (Fig 5g; Fig 5i shows the same comparison on separate blots); nuclear pan-phospho STAT5B rises with creatine and not after si-CKB (Fig 5h); recombinant His-CKB + ATP raises pan-phospho signal on FLAG-STAT5B in vitro (Supp 6d; signal is present without CKB); nuclear STAT5B appears modestly higher in MKs from creatine-treated mice (Supp 6h, two lanes per group).

ChIP-qPCR, % input, vehicle → creatine, n = 3 (Fig 5j, Supp 6i; the antibody is not named in the file):

| Gene | Exon | −2 kb | −1 kb | −0.2 kb |
|---|---|---|---|---|
| *P2ry12* | 4.7 → 5.9 (×1.3; Sidak P = 0.70) | 2.1 → 10.0 (×4.8; Sidak P = 9.0e-6) | 2.9 → 13.3 (×4.6; Sidak P = 2.5e-7) | 0.6 → 7.1 (×12.1; Sidak P = 9.3e-5) |
| *Gp6* | 9.1 → 8.8 (×1.0; Sidak P = 1.00) | 16.2 → 13.0 (×0.8; Sidak P = 0.41) | 4.1 → 15.5 (×3.8; Sidak P = 0.0001) | 3.5 → 9.9 (×2.9; Sidak P = 0.018) |
| *Rab4a* | 11.0 → 8.1 (×0.7; Sidak P = 0.97) | 7.7 → 10.7 (×1.4; Sidak P = 0.97) | 9.1 → 24.9 (×2.7; Sidak P = 0.039) | 7.5 → 41.0 (×5.5; Sidak P = 5.2e-5) |

The conventions list the same forward primer for the *Rab4a* −1 kb and −2 kb amplicons (ACCTCTGCACTTGGCAGTTT), so those two "regions" start at the same position yet give different enrichments.

## G. Phosphoproteomics (creatine vs vehicle megakaryocytes, n = 3 mice per group)

- 5,812 phosphopeptide rows, 2,033 gene names (14 rows unnamed). Columns: gene, P, Q, log fold-change. No site, peptide or intensity columns, so the Ser127 assignment cannot be checked in this file.
- 1,702 rows (29%) carry the identical P = 0.4226 with |log fold-change| of 0.4–7.6 (median 3.6). That is exactly what an unequal-variance t test returns (t = 1 on 2 degrees of freedom) when a peptide is quantified in one of three replicates of one group and in none of the other. A further 255 rows sit in a second band at P = 0.18–0.20 with |log fold-change| > 2, the value for two of three replicates. Large fold-changes in this table therefore mostly reflect presence or absence, not graded change. Rows quantified in three of three replicates of one group and none of the other return small P values; the Stat5b row is in that class. This is an inference from the pattern, because intensities are not in the file. (The column header names an unpaired Student's t test; the tied values are what the unequal-variance form returns for these patterns, and Student's form would give 0.374 for the first.)
- Of the 4,110 other rows, 238 have P < 0.05; about 206 are expected by chance alone. By the study's screening criteria (P < 0.05 and fold-change ≥ 1.2 or ≤ 0.83), 75 rows are up and 134 down if the log is base 2.
- No row passes a false-discovery threshold: the smallest Q in the file is 0.167; the smallest Benjamini–Hochberg value recomputed from the P column is 0.25.
- **Stat5b**: two rows. Row 1509: P = 0.00123, Q = 0.246, log fold-change 5.70; rank 17 of 5,812 by P, 9th of 84 among nominal 'up' rows by fold-change. Row 1508: P = 0.47, log fold-change 0.49. **Stat5a** (one row): P = 0.40, log fold-change 0.13. Ckb and Slc6a8 are not in the table.
- Stat5b's profile (|log fold-change| ≥ 3 with P < 0.05) is shared by 68 rows: 31 'on in creatine', 37 'off in creatine'.

Twenty smallest P values in the table:

| Rank | Gene | P | Q | Log fold-change |
|---|---|---|---|---|
| 1 | Hcar2 | 0.00006 | 0.167 | -0.77 |
| 2 | H3-5 | 0.00013 | 0.167 | -0.87 |
| 3 | H3-3a | 0.00013 | 0.167 | -0.87 |
| 4 | Ppp1r12a | 0.00020 | 0.192 | +4.60 |
| 5 | Itsn2 | 0.00034 | 0.214 | -5.51 |
| 6 | Itsn2 | 0.00034 | 0.214 | -5.51 |
| 7 | Dap | 0.00043 | 0.221 | +6.61 |
| 8 | Ccdc88b | 0.00046 | 0.223 | +1.32 |
| 9 | Add3 | 0.00061 | 0.232 | -6.40 |
| 10 | Cnot2 | 0.00065 | 0.233 | +0.52 |
| 11 | Gmip | 0.00083 | 0.239 | -4.90 |
| 12 | Rnf20 | 0.00097 | 0.242 | -5.95 |
| 13 | Lmnb1 | 0.00102 | 0.243 | -1.29 |
| 14 | Nhsl2 | 0.00112 | 0.244 | -0.46 |
| 15 | Atp7a | 0.00115 | 0.245 | -6.32 |
| 16 | Wbp11 | 0.00115 | 0.245 | +4.92 |
| 17 | Stat5b | 0.00123 | 0.246 | +5.70 |
| 18 | Suco | 0.00123 | 0.246 | -0.53 |
| 19 | Nfkb2 | 0.00123 | 0.246 | -5.72 |
| 20 | Aak1 | 0.00144 | 0.248 | +6.19 |

## H. Human volunteer cohort (11 healthy volunteers, 20 g/day creatine for 14 days, no control arm)

Serum creatine (Fig 7b), µM, mean ± SD: day 0 45 ± 13; day 3 153 ± 17; day 7 156 ± 20; day 14 159 ± 24; every volunteer at least ×2.1 (paired t, day 0 vs day 14, P = 4.3e-8). BMI unchanged (Supp 8a, paired P = 0.24); platelet count and indices unchanged (Supp 8b, all Dunnett P ≥ 0.88).

Platelet function (Fig 7c), fold of each volunteer's own day 0, n = 11. Cells: median fold; volunteers increased; Wilcoxon signed-rank P against no change. The file's Dunnett P is given for day 14.

| Agonist | Measure | Day 3 | Day 7 | Day 14 | Dunnett P, day 14 (file) |
|---|---|---|---|---|---|
| Collagen | max aggregation | 1.20; 6/11; P = 0.64 | 1.14; 8/11; P = 0.10 | 2.25; 9/11; P = 0.005 | 0.0051 |
| Collagen | mean aggregation | 1.16; 6/11; P = 0.46 | 1.16; 7/11; P = 0.10 | 1.97; 9/11; P = 0.005 | 0.1242 |
| Collagen | adhesion | 0.79; 3/11; P = 0.76 | 0.91; 4/11; P = 0.92 | 1.37; 9/11; P = 0.032 | 0.0337 |
| Epinephrine | max aggregation | 0.79; 5/11; P = 0.37 | 1.21; 10/11; P = 0.005 | 1.40; 10/11; P = 0.002 | 0.0061 |
| Epinephrine | mean aggregation | 0.89; 5/11; P = 0.76 | 1.31; 10/11; P = 0.005 | 1.72; 11/11; P = 0.0010 | 0.0023 |
| Epinephrine | adhesion | 0.89; 5/11; P = 0.90 | 1.47; 11/11; P = 0.0010 | 1.80; 11/11; P = 0.0010 | 0.0184 |
| Arachidonic acid | max aggregation | 0.89; 5/11; P = 0.76 | 1.31; 7/11; P = 0.24 | 1.13; 9/11; P = 0.042 | 0.3316 |
| Arachidonic acid | mean aggregation | 0.90; 4/11; P = 0.83 | 1.28; 8/11; P = 0.12 | 1.25; 9/11; P = 0.042 | 0.1612 |
| Arachidonic acid | adhesion | 0.69; 5/11; P = 0.97 | 1.63; 7/11; P = 0.083 | 1.79; 9/11; P = 0.019 | 0.1451 |
| ADP | max aggregation | 0.69; 5/11; P = 0.70 | 1.03; 6/11; P = 0.64 | 1.02; 6/11; P = 0.46 | 0.6821 |
| ADP | mean aggregation | 0.70; 5/11; P = 0.64 | 1.03; 6/11; P = 0.70 | 1.00; 5/11; P = 0.32 | 0.5303 |
| ADP | adhesion | 0.80; 3/11; P = 0.24 | 1.02; 6/11; P = 0.97 | 1.32; 6/11; P = 0.32 | 0.3202 |

Exploratory, and only valid if row order is the same volunteer across blocks (the sheet does not say): day-14 collagen and epinephrine responses are correlated across rows (r = 0.89 on log2 fold), so response looks like a property of the volunteer, with three to four non-responders; it does not track the rise in serum creatine (Spearman ρ = 0.05, P = 0.87; every volunteer rose at least two-fold).

CD41+ cell transcripts (Fig 7d), 4 volunteers, fold of own day 0 as given in the sheet (geometric mean; volunteers increased; one-sample t on log2):

| Gene | Day 3 | Day 7 | Day 14 |
|---|---|---|---|
| *GP6* | ×1.09; 2/4; P = 0.91 | ×6.36; 3/4; P = 0.075 | ×3.16; 3/4; P = 0.19 |
| *P2RY12* | ×0.72; 2/4; P = 0.64 | ×3.13; 3/4; P = 0.083 | ×4.97; 3/4; P = 0.10 |
| *RAB4A* | ×1.11; 3/4; P = 0.51 | ×1.24; 2/4; P = 0.49 | ×0.38; 0/4; P = 0.005 |
| *ITGA2B* | ×0.76; 2/4; P = 0.73 | ×3.84; 3/4; P = 0.15 | ×1.54; 2/4; P = 0.57 |
| *GPIBA* | ×0.51; 1/4; P = 0.37 | ×10.42; 4/4; P = 0.018 | ×2.33; 3/4; P = 0.26 |
| *F2R* | ×0.82; 2/4; P = 0.82 | ×6.49; 4/4; P = 0.028 | ×3.57; 3/4; P = 0.16 |
| *ADRA2A (sheet label ADAR2A)* | ×0.99; 2/4; P = 0.99 | ×20.64; 4/4; P = 0.0006 | ×4.14; 4/4; P = 0.034 |
| *FCGR2A* | ×0.40; 1/4; P = 0.43 | ×1.44; 3/4; P = 0.79 | ×1.91; 3/4; P = 0.47 |
| *RUNX1* | ×2.41; 3/4; P = 0.17 | ×2.29; 3/4; P = 0.29 | ×2.59; 3/4; P = 0.17 |
| *RAB27B* | ×4.49; 4/4; P = 0.032 | ×1.75; 3/4; P = 0.30 | ×2.90; 4/4; P = 0.007 |
| *PITPNB* | ×2.05; 4/4; P = 0.18 | ×6.08; 4/4; P = 0.011 | ×4.93; 4/4; P = 0.011 |

Platelet protein by immunoblot densitometry, ratio to β-actin (Fig 7e, 4 volunteers): GP6 0.42 → 0.52 / 0.83 / 1.08 at days 3 / 7 / 14 (Tukey vs day 0: P = 0.86, 0.041, 0.002); P2RY12 0.73 → 1.19 / 0.94 / 1.21 (P = 0.053, 0.56, 0.044). Blots for all four volunteers are in Supp 8d.

Human platelets transferred into mice (Fig 7g, n = 5 recipient mice per group; number of donors not stated): burden 4.65 → 12.7 % (×2.72; P = 0.014; n = 5+5); foci 21.8 → 39.4 (×1.81; P = 0.012; n = 5+5); lung weight 0.186 → 0.236 g (×1.27; P = 0.020; n = 5+5).

Data notes for Fig 7d: PITPNB volunteer 4 is entered as values of +26 to +28 (raw Ct scale, not ΔCt); the reported folds for volunteer 4 in PITPNB (1.89, 6.84, 6.26) and RAB27B (2.52, 4.44, 2.36) cannot be reproduced from the listed ΔCt values (0.79–0.80, 1.9, 0.59 and 4.0–4.3, 5.7–6.1, 0.49–0.54). Eleven ΔCt cells (volunteer 3 day 14 for RUNX1, RAB27B, PITPNB; two PITPNB volunteer 4 cells) carry a different numeric precision from the instrument-export values around them.

## I. Panel index (every sheet in the source file)

| Sheet(s) | Content | n | Where analysed |
|---|---|---|---|
| Fig 1a, 1b | creatine vs vehicle: lung weight, SUV-BW, burden, foci | 6 + 6 | B |
| Fig 1c | survival | 10 + 10 | B |
| Fig 1f | melanoma sh-scrambled vs sh-Slc6a8 × vehicle/creatine: lung weight, SUV-BW, burden, foci | 6 per group | B, C |
| Fig 1h | lung signal 0.25–24 h after tumour-cell injection (y-axis unlabelled) | 6 + 6 | B |
| Fig 1i | GFP+ cells per field | 8 fields per group | B |
| Fig 1j, 1k | second cohort: lung weight, SUV-BW, burden, foci | 6 + 6 | B |
| Fig 1l | survival, second cohort | 20 + 18 | B |
| Fig 2a | platelet count and indices: PLT 789 vs 789 ×10⁹/L (P = 1.00); PCT P = 0.97, PDW P = 0.35, MPV P = 0.91 | 3 + 3 | — |
| Fig 2b | platelet aggregation: ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56% (P = 0.0003–0.001) | 3 + 3 (replicate type not stated) | proposal §2 |
| Fig 2c | α-granules per field: 2.0 → 3.9 (P = 0.008) | 8 fields per group | — |
| Fig 2d | thromboelastography: MA 39.7 → 54.0 mm (P = 0.049; Welch 0.052); R, K, α P = 0.90, 0.17, 0.15 | 5 + 5 | — |
| Fig 2e, 2g | blots: GP6, P2RY12 in platelets and MKs from vehicle- vs creatine-treated mice | 3 lanes per group | image only |
| Fig 2f | MK platelet-gene panel, vehicle vs creatine | 3 + 3 | D |
| Fig 2i | blot: creatine 0 / 0.2 / 2 mM raises GP6 and P2RY12 in cultured MKs, not in platelets treated directly | 1 lane per dose | image only |
| Fig 2j | PKH-positive area: 1.87 → 4.47% (P = 0.001) | 8 fields per group | — |
| Fig 3b, 3c, 3d | Slc6a8 knockout × creatine: serum creatine, MK creatine, aggregation | 5, 3, 3 per group | C |
| Fig 3f | Slc6a8 knockout × creatine: MK gene panel | 3 per group | D |
| Fig 3g | blot: GP6, P2RY12 in control vs knockout ± creatine | 2 lanes per group | image only |
| Fig 3i | Slc6a8 knockout × creatine: lung weight, burden, foci | 4 per group | B, C |
| Fig 4a, 4c | creatine and phosphocreatine in MKs and brain | 3 + 3 | E |
| Fig 4b | blot: CKB in MKs and brain ± creatine | 1 lane each | image only |
| Fig 4d, 4f | cultured MKs: creatine and phosphocreatine content | 3 + 3 | E |
| Fig 4e | Ckb mRNA (and blot) in MKs ± creatine | 3 + 3 | E |
| Fig 4g, 4h | cultured MKs: control / creatine / phosphocreatine — blot and gene panel | 3 per group (qPCR) | D |
| Fig 4i, 4j | cultured MKs: si-Ckb × creatine — blot and gene panel | 3 per group (qPCR) | D |
| Fig 4k, 4l | cultured MKs: CKB overexpression — blot and gene panel | 3 per group (qPCR) | D |
| Fig 5e, 5f | FLAG-STAT5B WT / S127A / 3A / S127D ± creatine: pan-phospho / FLAG densitometry and blots | 3 blots per panel | F |
| Fig 5g, 5h, 5i | blots: CKB overexpression or knockdown and STAT5B phosphorylation; nuclear fraction | single blots | F |
| Fig 5j | ChIP-qPCR at P2ry12 and Gp6 | 3 + 3 | F |
| Fig 6a | MK gene panel: vehicle / creatine ± STAT5-IN-1 | 3 per group | D |
| Fig 6b | burden and foci: vehicle / creatine ± STAT5-IN-1 | 5 per group | B, C, J |
| Fig 6d | blot: STAT5B absent in Pf4-iCre;Stat5bfl/fl MKs | 1 lane each | image only |
| Fig 6e | MK creatine: wild-type vehicle, wild-type creatine, Stat5b knockout creatine | 3 per group | E |
| Fig 6f | blot: CKB, GP6, P2RY12 in MKs and platelets, same three groups | 1 lane each | image only |
| Fig 6g | MK gene panel, same three groups | 3 per group | D |
| Fig 7b | human serum creatine, days 0, 3, 7, 14 | 11 | H |
| Fig 7c | human platelet aggregation and adhesion (collagen, epinephrine, arachidonic acid, ADP) | 11 | H |
| Fig 7d | human CD41+ cell transcripts | 4 | H |
| Fig 7e | human platelet GP6 and P2RY12 protein | 4 | H |
| Fig 7g | mice given human day-0 vs day-7 platelets: lung weight, burden, foci | 5 + 5 mice | B, H |
| Supp 1a–1d | body weight, food, water, serum creatine | 4–6 per group | B |
| Supp 1e, 1f, 1g, 1k | further cohorts (models not named): lung weight, burden, foci | 4–10 per group | B |
| Supp 1h, 1i | 5% creatine diet: serum creatine; lung weight, burden, foci | 4 + 4 | B |
| Supp 2a | Slc6a8 knockdown in tumour cells: mRNA 19% of control; blot | 3 + 3 | C |
| Supp 2d | platelet transfer: vehicle, creatine, creatine + aspirin donors — burden, foci | 6 per group | B, J |
| Supp 3a | white cells, lymphocytes, monocytes, red cells | 5 + 5 | B |
| Supp 3c | MK maturation genes | 3 + 3 | D |
| Supp 4a | blot: SLC6A8 reduced, with a residual band, in knockout MKs | 1 lane each | image only |
| Supp 4b, 4c | Slc6a8 knockout × creatine: platelet count; α-granules per field (2.6 → 5.1 in controls, 2.3 → 2.3 in knockouts) | 3 per group; 8 fields per group | C |
| Supp 4e | Slc6a8-knockout MKs in culture: control / creatine / liposomal creatine, gene panel | 3 per group | D |
| Supp 5a | Gatm, Gamt mRNA | 3 + 3 | E |
| Supp 5b | blots: si-Ckb and CKB overexpression in MKs | 1 lane each | image only |
| Supp 5c | CKB overexpression: MK creatine and phosphocreatine | 3 + 3 | E |
| Supp 6a | blot: phospho-STAT5A/B (Y694/699) not detected in MKs; Jurkat + IL-2 control positive | 3 lanes per group | F |
| Supp 6d–6h | blots: in vitro kinase assay (His-CKB), CKB / GATM manipulation in 293T, nuclear STAT5B in MKs | single blots | F |
| Supp 6i | ChIP-qPCR at Rab4a | 3 + 3 | F |
| Supp 7a | platelet count and indices, vehicle / creatine ± STAT5-IN-1: all reported Tukey P ≥ 0.41 | 3 per group | — |
| Supp 7b | platelet count and indices, wild-type vehicle / creatine, Stat5b knockout creatine: all reported Tukey P ≥ 0.055 | 3 per group | — |
| Supp 8a, 8b | human BMI; platelet count and indices | 11 | H |
| Supp 8c | CD41 mRNA: CD41+ cells vs monocytes (5–7% of CD41+ cells) vs MEG-01 | 3 per group | — |
| Supp 8d | blots: GP6, P2RY12 in platelets of volunteers 1–4, days 0–14 | 4 volunteers | H |

Fig 2e, 2g, 2i, 3g, 4b, 4g, 4i, 4k, 5g–5i, 6d, 6f and Supp 2a, 4a, 5b, 6a, 6d–6h, 8d are images only (no densitometry in the file); they were read qualitatively.

## J. Data-integrity, design and labelling flags

1. **Identical animals in two different experiments.** Fig 6b (STAT5 inhibitor study) cells B5:B7 and C5:C7 (burden 3.29136, 3.733544, 2.886353 and 11.13465, 13.22011, 14.12619) and B14:B16, C14:C16 (foci 37, 25, 33 and 53, 62, 47) are identical, value for value, to Supp 2d (platelet-transfer study) cells C8:C10, D8:D10 and C17:C19, D17:D19. Three of five animals in each no-inhibitor arm of Fig 6b are therefore also three of six animals in the "vehicle donor" and "creatine donor" arms of Supp 2d, although one design doses mice directly and the other transfers donor platelets. In Supp 2d the shared animals form a visibly lower cluster (vehicle 2.9–3.7 vs 6.4–9.5; creatine 11.1–14.1 vs 18.0–25.8). Conclusions survive removing them (Supp 2d: creatine vs vehicle donors, Tukey P = 0.0002 with n = 3 + 3; Fig 6b: see section C), but the animal records need to be reconciled before either panel is used as decision-grade evidence.
2. **Study-wide design facts (conventions).** Allocation was randomised but not masked, during the work or at readout. Group sizes were not set by a sample-size calculation. Sex was not analysed; the animals were male C57BL/6J and female BALB/cJ, so sex is confounded with strain and tumour model. Tumour models are not named in the source file apart from "Melanoma" (Fig 1f).
3. **Units of replication.** n is 8 microscope fields per group in Fig 1i, 2c, 2j and Supp 4c (number of animals not given). Aggregation values (Fig 2b, 3d) are triplicates with within-group SD of 1–5 percentage points and no statement that they are separate animals. Fig 7g reports 5 recipient mice per group, not the number of human donors. Fig 7d and 7e use 4 of the 11 volunteers.
4. **Missing arms and controls.** The Stat5b-knockout experiments (Fig 6e–6g, Supp 7b) have three groups and no knockout + vehicle arm; their control is "WT", not a Cre-matched Pf4-iCre control (the Slc6a8 experiments use Pf4-Cre;Slc6a8+/+). There is no metastasis or platelet-function readout for the Stat5b knockout and no in vivo perturbation of CKB. Supp 2d has no vehicle + aspirin arm, and its label ("Creatine+aspirin donor PLT") does not say how or when the aspirin was given. The human study has no control arm.
5. **Inhibitor attribution.** STAT5-IN-1 inhibits STAT5A and STAT5B (conventions) and was dosed orally to the whole animal; the package has no readout of target engagement in megakaryocytes, and the canonical phospho-tyrosine signal is undetectable there (Supp 6a). Without creatine the inhibitor lowers 7 of 11 platelet genes (×0.22–0.69, Fig 6a).
6. **Labels.** Fig 1f, cell G5 labels a comparison "WT-creatine vs. si-Slc6a8-creatine"; numerically it is sh-scrambled-creatine vs sh-Slc6a8-creatine (difference −0.0008667). Supp 2a table says "Si-", its blot says "Sh-". Fig 4d is labelled "Creatinine (umol/g)" although the assay listed is the creatine kit. Fig 7d labels ADRA2A as "ADAR2A". Supp 5a analysis header reads "Vehicle-7". Fig 1h has no y-axis label. Stat5b sheets write "PF4-cre" where the conventions say Pf4-iCre. The ChIP antibody and the "3A" construct are not defined in the file.
7. **Borderline results.** Fig 3c, MK creatine in controls: P = 0.049 (Welch 0.10), n = 3; supported by Fig 4a (×3.05, P = 0.0004) and Fig 6e (×4.7, Tukey P = 0.008) and by the genotype × creatine interaction (P = 0.045). Fig 2d, TEG-MA: P = 0.049 (Welch 0.052). Fig 1l has 20 vehicle and 18 creatine animals with no exclusions recorded.
8. **Immunoblots.** Target and β-actin bands come from different gels (conventions), so ratios to β-actin (Fig 7e) and pan-phospho / FLAG (Fig 5e, 5f) do not control for lane loading on the target gel. Supp 4a shows a reduced but still visible SLC6A8 band in knockout megakaryocytes (one lane each).
9. **Phosphoproteomics.** See section G: screening used unadjusted P; no row reaches Q < 0.05; site information is absent.
10. **Human qPCR.** See section H: volunteer 4 anomalies in PITPNB and RAB27B.
11. **Not counted as flags.** Repeated values inside the qPCR sheets (two-decimal rounding of ΔCt, as the sheets note) and three coincident % input values in the ChIP sheets, which are consistent with the same rounding.

## K. Sample-size basis for the proposed in vivo study

- Variability: pooled within-group SD of ln(metastatic burden) across the 31 groups in section B is 0.43 (median 0.33, upper quartile 0.45).
- Observed effect to be confirmed: ratio-of-ratios 4.5 (Fig 3i, log scale; 3.95 on arithmetic means). Unblinded small studies overstate effects, so the design is powered for a ratio-of-ratios of 2.0, roughly half the observed log effect.
- Power for the genotype × creatine interaction (two-sided α = 0.05, four equal groups):

| n per group | True ratio-of-ratios 2.0, SD 0.43 | 2.0, SD 0.50 | 3.0, SD 0.43 | 4.5, SD 0.43 |
|---|---|---|---|---|
| 4 | 0.32 | 0.25 | 0.65 | 0.89 |
| 8 | 0.60 | 0.47 | 0.94 | 1.00 |
| 12 | 0.78 | 0.65 | 0.99 | 1.00 |
| 16 | 0.89 | 0.78 | 1.00 | 1.00 |
| 20 | 0.95 | 0.86 | 1.00 | 1.00 |

The existing experiment (n = 4) had 32% power for a ratio-of-ratios of 2.0. Sixteen per group (8 per sex) gives 89% (78% if the SD is 0.50). For a two-group contrast such as creatine + aspirin vs creatine, 16 per group gives 99% power for a two-fold difference and 73% for 1.5-fold.

