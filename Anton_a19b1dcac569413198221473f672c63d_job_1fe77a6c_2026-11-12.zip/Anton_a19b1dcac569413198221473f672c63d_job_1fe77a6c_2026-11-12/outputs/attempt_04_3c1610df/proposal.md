Take megakaryocyte creatine uptake through the SLC6A8 transporter forward as the primary target for next quarter's in vivo slot; hold megakaryocyte STAT5B as the first backup and CKB as a second, conditional backup, and carry aspirin in the study as the benchmark to beat, not as a target.

# CRE-MK-01 validation proposal: exogenous creatine, megakaryocytes and metastasis

**Basis.** Everything here is derived from the three files in the package: the source data (87 sheets, 26 blot images), the phosphoproteomics table (5,812 rows) and the study conventions. All 232 statistical tests reported in the source file were recomputed from the raw values beside them and all 232 match. The analyses I added (interaction terms, pooled effects, human re-analysis, duplicate scan, power) are described in section 7 and tabulated in `appendix_evidence_tables.md`. No external data were used.

## 1. The decision in brief

| Node | Call | Strongest support in the package | Main gap |
|---|---|---|---|
| **SLC6A8 in the megakaryocyte (MK) lineage** | **Primary; takes the slot** | The only node where an MK-lineage knockout was tested against metastasis, in a full 2×2: creatine raises burden ×3.35 in Cre-only controls and ×0.85 in knockouts (interaction P = 0.0003; Fig 3i) | n = 4 per group, one unblinded experiment; knockout platelets are hypo-reactive; no pharmacological tool in the package |
| **STAT5B in MKs (Ser127 axis)** | First backup | STAT5-IN-1 removes the creatine effect on metastasis (×4.02 without, ×1.24 with; Fig 6b) | The inhibitor hits STAT5A and STAT5B and was dosed systemically; the MK Stat5b knockout was never tested against metastasis |
| **CKB in MKs** | Second backup, conditional | Knockdown blocks and overexpression reproduces the platelet-gene programme in cultured MKs (Fig 4j, 4l) | In vitro only |
| Platelet activation (aspirin) | Comparator, not a target | Platelets from creatine-fed donors transfer the excess metastasis; platelets from creatine + aspirin donors do not (Supp 2d) | No vehicle + aspirin arm; shares animals with Fig 6b |

One limit applies to every node. None of the perturbations lowers metastasis when no creatine is given (Slc6a8 knockout + vehicle ×1.43 vs control, P = 0.14; inhibitor alone ×1.05). The package therefore supports one narrow indication: preventing the excess metastasis that comes with supplemental creatine. The obvious non-drug alternative, stopping creatine, has not been tested and is built into the study below.

Not taken forward: tumour-cell SLC6A8 (knockdown in the tumour cells changes nothing; Fig 1f) and phosphocreatine supply as the mechanism (Fig 4h, Supp 5c).

Confidence in the ranking is moderate. SLC6A8 leads because it is the only node tested where it counts, not because it won a head-to-head. STAT5B could overtake it once its own knockout is run against metastasis (Study 2).

**Ask of the committee.** Allocate the slot to Study 1 (section 4): 80 tumour-bearing mice for arms 1–5, 96 with the withdrawal arm, plus satellite animals for the mechanism readouts. Approve expansion of the Pf4-iCre;Stat5b colony now, so that Study 2 can follow without a gap.

![Metastasis evidence](figures/fig1_metastasis_evidence.png)

## 2. Evidence

The chain the package's experiments test: supplemental creatine → uptake into megakaryocytes through SLC6A8 → CKB induced → STAT5B phosphorylated at Ser127 → platelet-receptor genes induced → more reactive platelets → more lung metastasis. The three candidate nodes sit in that order.

Numbers are recomputed from the sheets named in brackets. "Ratio-of-ratios" is the creatine effect in the control arm divided by the creatine effect in the perturbed arm, estimated on the log scale; 1 means the perturbation changes nothing. Interaction P values are on the raw scale, the scale on which the file analyses these data.

### 2.1 The phenotype the target has to explain

- **Creatine raises lung metastatic burden about three-fold, every time it was tested.** Pooled ratio 3.02 (95% CI 2.54–3.58) across ten directly dosed cohorts, 61 + 61 mice, each cohort between ×2.07 and ×4.02, by oral dosing or by diet (Fig 1b, 1k, 1f, 3i, 6b; Supp 1e, 1f, 1g, 1i, 1k). Survival shortens: median 22 → 19 days (log-rank P = 0.032; hazard ratio 2.9, 95% CI 1.0–8.2; Fig 1c) and 16 → 14 days (P = 0.011; 2.3, 1.2–4.5; Fig 1l).
- **Mouse exposure is in the human range.** Serum creatine 66 → 178 µM in mice (Supp 1d) and 45 → 153–159 µM in the volunteers on 20 g/day (Fig 7b).
- **The effect sits in the host, not the tumour cell.** Knocking Slc6a8 down in the melanoma cells (19% of mRNA remaining; Supp 2a) leaves the creatine effect intact: ×3.15 against ×3.50 with scrambled control, ratio-of-ratios 1.29 (0.66–2.54), interaction P = 0.68 (Fig 1f).
- **Megakaryocytes take up the extra creatine.** MK creatine rises ×3.05 (42 → 129 µmol/g) where brain, the only other tissue measured, rises ×1.19 (96 → 114 µmol/g; Fig 4a).
- **Platelets carry it, and the programme is set in the megakaryocyte.** Platelet count is unchanged (789 vs 789 ×10⁹/L; Fig 2a) while aggregation rises (ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56%; Fig 2b). Platelets from creatine-fed donors raise burden ×3.06 in recipient mice (Supp 2d). Creatine induces 10 of 11 platelet-activation genes in MKs (×1.7–5.7; Fig 2f) and raises GP6 and P2RY12 protein in cultured MKs but not in platelets exposed directly (Fig 2i, blot).

### 2.2 SLC6A8: why it leads

| Readout in Pf4-Cre;Slc6a8 mice, vehicle → creatine | Cre control | MK-lineage knockout | Genotype × creatine |
|---|---|---|---|
| Metastatic burden, % (Fig 3i, n = 4) | 2.36 → 7.91 (×3.35) | 3.39 → 2.88 (×0.85) | P = 0.0003; ratio-of-ratios 4.5 (2.1–9.4) |
| Metastatic foci (Fig 3i) | 29.8 → 56.5 | 26.5 → 24.8 | P = 0.004 |
| Serum creatine, µM (Fig 3b, n = 5) | 89 → 239 | 89 → 218 | same exposure (P = 0.18 between creatine arms) |
| MK intracellular creatine, µmol/g (Fig 3c, n = 3) | 13.7 → 72.1 (×5.3) | 13.7 → 21.1 (×1.5) | P = 0.045 |
| Platelet genes induced, of 11 (Fig 3f, n = 3) | 10 (×2.1–5.6) | 0 (median ×1.00) | — |
| Aggregation, ADP / collagen / thrombin, % (Fig 3d, n = 3) | 63 → 71 / 65 → 77 / 61 → 75 | 54 → 31 / 61 → 51 / 45 → 35 | all P < 1e-6 |

- **It is the only node with cell-specific genetics on the disease endpoint**, with all four arms and a Cre-matched control.
- **The chain is coherent.** Same blood creatine in both genotypes, but little creatine loading of the MK, no gene induction, no rise in aggregation and no excess metastasis.
- **The on-target check is in the package.** In knockout MKs free creatine has little effect (median ×1.05 across the gene panel), while liposomal creatine, which bypasses the transporter, restores induction (median ×2.76, 9 of 11 genes; Supp 4e). The requirement is for creatine entry.
- **It is the most upstream node**, so blocking it removes the whole response: residual gene expression under creatine is back at baseline for *P2ry12* (1.08), *Gp6* (0.96) and *Rab4a* (1.08).

What is weak: four animals per group in one unblinded experiment; deletion is constitutive; a residual SLC6A8 band is visible in knockout MKs (Supp 4a); and the knockout has its own platelet phenotype. Knockout platelets aggregate less than control platelets without creatine (by 4 to 16 percentage points) and less again on creatine (by a further 10 to 23 points; Fig 3d, triplicates of unstated unit). That is a haemostasis question the next study must answer. The package contains no SLC6A8 inhibitor, so tractability is not evidenced here.

### 2.3 STAT5B: why it is the backup and not the lead

For:

- STAT5-IN-1 removes the creatine effect on burden (ratio-of-ratios 3.2, 95% CI 1.8–5.4; Fig 6b) and on all 11 MK genes (Fig 6a).
- MK Stat5b knockout leaves creatine uptake intact (95 vs 98 µmol/g; Fig 6e) yet lowers all 11 genes relative to wild type on creatine (Fig 6g), which places STAT5B downstream of SLC6A8.
- Creatine raises the pan-phospho signal on wild-type STAT5B but not on S127A (construct × creatine interaction P = 0.024 and 0.043; Fig 5e, 5f), and promoter occupancy rises at *P2ry12*, *Gp6* and *Rab4a* (Fig 5j, Supp 6i).

Against:

- **The in vivo result cannot be assigned to STAT5B or to the megakaryocyte.** STAT5-IN-1 inhibits both STAT5A and STAT5B (conventions) and was given orally to the whole animal. There is no readout of target engagement in MKs, and the canonical phospho-tyrosine signal is undetectable there with or without creatine (Supp 6a).
- **The specific experiment was not run.** The Pf4-iCre;Stat5b knockout has no metastasis data and no platelet-function data. It has three arms with no knockout + vehicle group, and its control is wild type rather than Cre-matched (Fig 6e–6g, Supp 7b).
- **The knockout block is partial where it matters.** On creatine, knockout MKs still express *P2ry12* ×2.0, *Gp6* ×1.44, *Gpiba* ×1.66, *F2r* ×1.60 and *Adra2a* ×1.89 relative to untreated wild type (P < 0.05 for *Gp6*, *F2r*, *Adra2a*). The inhibitor, which also hits STAT5A, takes them to baseline or below.
- **The inhibitor is not creatine-specific.** Without creatine it lowers 7 of 11 platelet genes (×0.22–0.69; Fig 6a).
- **The phosphoproteomic nomination does not stand alone.** No row in the table passes a false-discovery threshold (smallest Q = 0.17). The Stat5b row has P = 0.0012 and Q = 0.25, ranks 17th of 5,812, and is one of 31 "on in creatine" rows (log fold-change ≥ 3, P < 0.05) matched by 37 "off in creatine" rows. Of 4,110 testable rows, 238 have P < 0.05 against about 206 expected by chance. The file gives no site, so Ser127 cannot be checked in it.
- **Fig 6b shares animals with another experiment** (section 3).

![Node comparison and phosphoproteomics](figures/fig2_node_comparison_phospho.png)

### 2.4 CKB: why it is conditional

- Creatine raises *Ckb* mRNA ×1.82 in MKs (P = 0.011; Fig 4e) and CKB protein (Fig 4b, blot).
- si-Ckb removes a median 92% of the creatine-induced gene increment (Fig 4j). CKB overexpression alone induces 10 of 11 genes (×1.8–6.4; Fig 4l).
- The effect does not run through phosphocreatine supply: added phosphocreatine induces none of the 11 genes (Fig 4h), and CKB overexpression changes neither MK creatine (×0.97) nor phosphocreatine (×1.25, P = 0.16; Supp 5c).
- CKB still appears raised by creatine in Stat5b-knockout MKs (Fig 6f, single lanes), consistent with a position between SLC6A8 and STAT5B.

Every perturbation of CKB is in cultured MKs at n = 3. There is no in vivo perturbation of CKB, and the one tissue comparison in the package shows far more CKB in brain than in MKs (Fig 4b). CKB moves up only if an in vivo loss-of-function exists.

### 2.5 The volunteer cohort: what carries over

Eleven healthy volunteers, 20 g/day for 14 days, each compared with their own day 0; no control arm. The file analyses fold-changes with Dunnett against a reference fixed at 1.0; I re-tested them with Wilcoxon signed-rank.

- **Platelet function rises by day 14 for collagen and epinephrine, not for ADP.** Collagen maximal aggregation: median ×2.25, 9 of 11 up, P = 0.005. Epinephrine: 10–11 of 11 up, P ≤ 0.002. ADP: 5–6 of 11, P ≥ 0.32. Nothing moves at day 3 (Fig 7c).
- **Platelet GP6 protein rises** ×2.0 at day 7 and ×2.6 at day 14 in 4 volunteers (Fig 7e). Transcripts in CD41+ cells are variable (one of four volunteers is a non-responder), and *RAB4A* falls in all four by day 14 (×0.38), the opposite of the mouse (Fig 7d).
- **Human platelets taken at day 7 raise burden ×2.72 in recipient mice** (P = 0.014; 5 mice per group, number of donors not stated; Fig 7g).
- **Nothing in the human data separates SLC6A8, CKB and STAT5B.** It supports the exposure-to-platelet link only. Collagen response with platelet GP6 is the read-through marker that behaves the same in both species.

![Volunteer cohort](figures/fig3_human_cohort.png)

### 2.6 Considered and not ranked: the effector receptors GP6 and P2RY12

Both receptors are induced in mouse MKs and platelets, bound at their promoters after creatine (Fig 5j), and raised in human platelets (Fig 7e). Neither was perturbed in any experiment, so in this package they are readouts, not validated targets. If an effector is wanted later, the human data point to GP6: the collagen response rises while the ADP response, which runs through P2RY12, does not (Fig 7c).

## 3. What lowers confidence

1. **Identical animals appear in two different experiments.** Three vehicle and three creatine animals in Fig 6b (STAT5 inhibitor) have the same burden and foci values, digit for digit, as three "vehicle donor" and three "creatine donor" animals in Supp 2d (platelet transfer). Both conclusions survive removing them, but Fig 6b's control arms then rest on two animals each. These are the only metastasis data for STAT5 inhibition and for aspirin.
2. **Design.** Allocation was not masked, group sizes were not powered, and sex was not analysed. Males were C57BL/6J and females BALB/cJ, so sex is confounded with strain and tumour model. Tumour models are not named in the file apart from "Melanoma".
3. **Units of replication.** n is microscope fields in Fig 1i, 2c, 2j and Supp 4c. Aggregation triplicates have SDs of 1–5 percentage points and are not stated to be separate animals, so their very small P values overstate the evidence.
4. **Immunoblots** show one to three lanes per group, with target and loading control on different gels; only Fig 5e, 5f and 7e are quantified.
5. **Human data** are single-arm, from eleven healthy Asian volunteers aged 20–25, at one dose; molecular readouts are from four of them. Volunteer 4's fold values for two genes in Fig 7d cannot be reproduced from the listed ΔCt values.

None of this reverses the ranking. It means the SLC6A8 result is a strong lead that still needs one decision-grade confirmation.

## 4. Proposed studies

**Indication the package can support.** Prevention of excess lung metastasis in hosts taking supplemental creatine. Melanoma is the only tumour named in the file; the other cohorts show the same direction but their models are not named. Not supported: primary tumour growth (not measured), metastasis to other organs, hosts not taking creatine, or any clinical outcome. The human data are platelet readouts in healthy volunteers.

### Study 1 (the in vivo slot): MK-lineage Slc6a8 deletion against creatine-driven metastasis

| Item | Specification |
|---|---|
| Question | Does loss of MK SLC6A8 remove the creatine-driven excess metastasis under blinded, powered conditions, in both sexes, and how does it compare with aspirin and with simply stopping creatine? |
| Population | Pf4-Cre;Slc6a8 knockout and Pf4-Cre;Slc6a8+/+ littermates (the control used in Fig 3), both sexes, randomised within sex and litter. Record Slc6a8 genotype by sex; the file labels every knockout flox/flox and does not give sex. |
| Model and indication | The melanoma lung-metastasis model of Fig 1f, the one model in which tumour-cell SLC6A8 was shown to be dispensable. |
| Core arms (16 per arm, 8 per sex) | 1. control + vehicle. 2. control + creatine. 3. knockout + vehicle. 4. knockout + creatine. Creatine as in the package: 17 mg orally three times a week (42.5 mg/mL, 400 µL). |
| Comparator arms (16 each) | 5. control + creatine + aspirin 30 mg/kg daily (package dose). 6. control + creatine, withdrawn at least one platelet turnover before tumour-cell inoculation. |
| Optional arm | 7. knockout + 5% creatine diet: does higher exposure (serum 227 µM on diet vs 178 µM on oral dosing) get round the block? If the colony limits numbers, arms 1–5 are the minimum set. |
| Primary endpoint | Lung metastatic burden (% area), scored blind. Primary test: genotype × creatine interaction on ln(burden), two-sided α = 0.05, sex as a factor. |
| Secondary endpoints | Foci number, lung weight, SUV-BW (the PET readout of Fig 1a); arms 5 and 6 against arm 2; arm 4 against arm 5. Survival in a separate cohort if capacity allows. |
| Mechanism readouts (satellite animals, animal as the unit) | SLC6A8 protein in MKs (deletion efficiency); serum creatine; MK creatine and phosphocreatine; aggregation to ADP, collagen and thrombin; platelet GP6 and P2RY12 protein; the 11-gene MK panel; MK CKB; nuclear and phospho-STAT5B; early lung retention of tumour cells (as Fig 1h). |
| Safety readouts | Platelet count and indices, a bleeding-time measure, body weight. |
| Size | Pooled SD of ln(burden) in the package is 0.43. Sixteen per group gives 89% power for a ratio-of-ratios of 2.0, about half the observed log effect (4.5). The existing n = 4 design had 32%. |
| Confirms SLC6A8 | Creatine effect in controls at least two-fold (package range 2.07–4.02); interaction significant; knockout + creatine within 1.5-fold of knockout + vehicle at the upper 95% limit; same direction in both sexes; mechanism readouts concordant. |
| Stops or demotes | No creatine effect in controls under blinding stops the programme. A preserved effect in knockouts demotes SLC6A8. |

Arm 6 matters for the portfolio case. If stopping creatine returns burden to baseline, it sets the ceiling for any late upstream blockade and defines the lag, but it also means dietary advice may do the job a drug would.

Why this study takes the slot rather than Study 2. It is the one experiment whose failure would stop everything: arms 1 and 2 are also the first blinded, powered test of the creatine effect itself, on which both backups depend. Study 2 fills STAT5B's biggest gap but cannot confirm or refute the lead. If the colonies allow, adding Study 2's four core arms to the same run is the best upgrade, because it turns the ranking into a head-to-head.

### Study 2 (first backup, next slot, or added to Study 1 if capacity allows): MK-lineage Stat5b deletion

| Item | Specification |
|---|---|
| Question | Is MK STAT5B required for creatine-driven metastasis, and does STAT5-IN-1 act through it? |
| Population | Pf4-iCre;Stat5b knockout and Pf4-iCre;Stat5b+/+ controls (Cre-matched, unlike Fig 6), both sexes, 16 per arm. |
| Arms | Six arms. Control or knockout × vehicle or creatine, all with DMSO (this adds the missing knockout + vehicle group); plus creatine + STAT5-IN-1 5 mg/kg daily in each genotype. |
| Endpoints | As Study 1. Adds the readouts never collected for this node: aggregation, bleeding, and STAT5A expression. Ser127 phosphorylation in MKs by a site-resolved method. |
| Reading | Effect lost in the knockout: STAT5B confirmed. Effect kept in the knockout but lost when inhibitor is added: the inhibitor works through STAT5A or outside the megakaryocyte, and "STAT5B" is the wrong label for the druggable node. |

### Study 3 (second backup): CKB

No in vivo slot until an in vivo loss-of-function exists. Two gating questions can be answered in cultured MKs first: whether a kinase-inactive CKB rescues si-Ckb (catalytic role versus scaffold), and whether CKB overexpression still induces the gene panel in Stat5b-knockout MKs (is STAT5B required downstream?). If both support the model, run MK-lineage Ckb loss-of-function × creatine with Study 1's endpoints.

### Study 4 (translational, outside the in vivo slot): controlled volunteer study

| Item | Specification |
|---|---|
| Design | Randomised, placebo-controlled, blinded; 14 days on, then sampling after stopping to measure reversal. |
| Population | Healthy adults of both sexes across a wider age range and more than one ancestry. The existing cohort was eleven Asian volunteers aged 20–25 (6 women, 5 men), none on NSAIDs. |
| Arms | Placebo; creatine 20 g/day (the only dose with data); one lower dose. |
| Primary endpoint | Collagen-induced maximal aggregation at day 14 against placebo. |
| Secondary | Epinephrine response; platelet GP6 and P2RY12 protein; the CD41+ transcript panel in every participant; serum creatine; ADP response as the expected negative. |
| Exploratory | Platelet transfer into mice with the donor as the unit of analysis. Creatine loading and gene induction in human megakaryocytic cells with and without SLC6A8 blockade: the package has no human data on any of the three nodes. |

This study tests whether the exposure-to-platelet link holds under control. It does not choose between the three nodes.

### Sequence

1. Before the meeting: the record checks in section 6.
2. Next quarter: Study 1 in the slot. In parallel, at the bench and desk: the two CKB gating questions, a site-resolved re-read of the phosphoproteomics, and the volunteer-study protocol.
3. Following slot: Study 2, or its four core arms inside Study 1 if the colonies allow.

## 5. What would move one choice above another

| New information | Effect on the ranking |
|---|---|
| Study 1 confirms the interaction in both sexes, with no bleeding signal beyond aspirin | SLC6A8 stays primary; next step is a second tumour model and a reversible (non-genetic) means of blockade, with brain creatine as a safety readout (brain holds 96 µmol/g; Fig 4a) |
| Knockout mice bleed, or the diet arm overrides the block | SLC6A8 is demoted; the downstream nodes move up, subject to the same bleeding test |
| Study 2: Stat5b knockout removes the creatine effect as fully as the Slc6a8 knockout, with normal baseline platelet function | STAT5B becomes co-primary, and primary if SLC6A8 carries the bleeding liability |
| Study 2: effect kept in the Stat5b knockout, lost with inhibitor | STAT5B is dropped as the named target; the question becomes STAT5A or a non-megakaryocyte site of action |
| Site-resolved phosphoproteomics confirms Ser127 at a controlled false-discovery rate, in MKs from treated mice | Strengthens STAT5B's mechanism; does not substitute for the knockout metastasis experiment |
| An MK-lineage Ckb loss-of-function removes the effect in vivo | CKB moves from conditional to full backup |
| Aspirin arm matches the knockout | The benchmark is met by an existing agent; a new target must then win on bleeding or on breadth |
| Withdrawal arm returns burden to baseline | The case for any drug narrows to people who cannot or will not stop creatine |
| Human megakaryocytic cells do not need SLC6A8 to load creatine or induce the gene panel | SLC6A8 is demoted on translation, whatever the mouse shows |
| The animal records show Fig 6b and Supp 2d are not independent experiments | STAT5B's in vivo support and the aspirin result both weaken further |

## 6. Questions the existing records can answer before the meeting

These need no new experiments and would firm up the ranking.

1. Animal identities for Fig 6b and Supp 2d: which experiment do the six shared animals belong to?
2. Does any metastasis or platelet-function readout exist for the Pf4-iCre;Stat5b mice that is not in the source file?
3. The site-level phosphoproteomics output, with per-replicate intensities: is the Stat5b peptide the Ser127 peptide, and in how many replicates was it detected?
4. Tumour model, strain and sex for each cohort in Fig 1 and Supp Fig 1, and the timing of creatine relative to tumour-cell inoculation.
5. Whether the aggregation and qPCR triplicates are separate animals.
6. Exclusions in Fig 1l (20 vehicle, 18 creatine), and what the "3A" STAT5B construct is.

## 7. How the numbers were derived

- **Reproduction.** Every reported test was recomputed from the raw cells: 71 unpaired t tests, 99 Tukey, 48 Dunnett and 12 Sidak comparisons and 2 log-rank tests; 232 of 232 match.
- **Interactions.** For each 2×2 design (Fig 1f, 3c, 3d, 3i, 6b), least squares with a creatine × perturbation term on the raw scale, as the file analyses the data, and on ln-transformed values to give a ratio-of-ratios with a 95% CI. A residual-permutation test that does not assume normal errors agrees (burden interaction P = 0.0005 for Fig 3i, 4e-5 for Fig 6b, 0.69 for Fig 1f).
- **Pooled creatine effect.** Ratio of group means per cohort with a delta-method CI, combined by DerSimonian–Laird random effects (I² = 51%).
- **Gene panels.** Group means of the fold values in the sheets; P values from t tests on log2 values; "increment removed" is (creatine − perturbed) / (creatine − 1).
- **Human data.** Wilcoxon signed-rank against no change and responder counts for Fig 7c; one-sample t on log2 for Fig 7d.
- **Phosphoproteomics.** Counts at the study's screening criteria, the Q column as supplied, a Benjamini–Hochberg check, and the pattern of tied P values (1,702 rows share P = 0.4226).
- **Duplicate scan.** Exact matching of every numeric cell across sheets; repeats explained by two-decimal qPCR rounding were set aside.
- **Survival.** Log-rank tests reproduced; hazard ratios from Cox regression. Event times are heavily tied, so the estimate depends on the method (appendix B).
- **Power.** Non-central t for a 2×2 interaction on ln(burden), using the pooled within-group SD across all metastasis groups in the package.
- **Images.** The 26 embedded blots were read qualitatively; the file holds densitometry only for Fig 5e, 5f and 7e.

## Files

- `proposal.md` — this document
- `appendix_evidence_tables.md` — all re-analysis tables, a panel index of every sheet, and the full list of data flags
- `figures/` — the three figures above
- `reanalysis/` — scripts (`run_all.sh` regenerates every number, table and figure), CSV outputs and the 232-test verification table
