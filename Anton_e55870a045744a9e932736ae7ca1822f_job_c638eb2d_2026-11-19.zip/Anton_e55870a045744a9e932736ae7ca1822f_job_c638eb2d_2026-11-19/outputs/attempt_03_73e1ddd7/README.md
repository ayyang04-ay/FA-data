# Outputs — MGAT1 programme review (1 Nov 2026)

Start with **`MGAT1_recommendation_memo.md`** (same content, single file with the figure embedded: `MGAT1_recommendation_memo.html`).

| Path | What it is |
|---|---|
| `MGAT1_recommendation_memo.md` / `.html` | Recommendation, the case behind it, next studies and bring-back criteria, what was set aside, and a number-to-source ledger (section 7) |
| `figures/evidence_summary.png` | One-page, six-panel summary built only from the re-analysis tables |
| `figures/readoff_overlays/` | The client's own figure panels with calibrated value gridlines, so every number read from a figure can be checked by eye |
| `figures/source_panels/` | Images and text extracted unchanged from the three client PDFs (inputs to the read-offs and curve digitisation) |
| `tables/` | Re-analysis results (CSV). File names are cited in memo section 7 |
| `analysis/` | Scripts that regenerate every table, log and figure from the 16 client files; `run_all.sh` runs them in order (about 3 minutes); `logs/` holds the console output of the last run |

## Tables

| File | Content |
|---|---|
| `invivo_sample_qc.csv` | Per-sample QC for the in vivo screen (reads, zero fraction, Gini, run/barcode, nearest-neighbour correlation, flags) |
| `invivo_group_inference_markers.csv` | Marker-gene behaviour used to infer the unlabelled group key |
| `invivo_gene_by_group.csv` | Every gene × group: log2 fold change vs baseline, z against the non-targeting null, rank |
| `invivo_mgat1_by_group.csv` | Mgat1 per guide and per group, with bootstrap 95 % CI |
| `invivo_mgat1_contrasts.csv` | Mgat1 in the seven decision-relevant contrasts (effect, CI, permutation and rank tests, rank among 795 genes) |
| `invivo_contrasts_all_genes.csv` | The same contrasts for all genes |
| `invivo_interaction_immune_x_stk11.csv` | Immune-dependence in Stk11-KO minus immune-dependence in Stk11-intact, all genes |
| `invivo_mgat1_limma_crosscheck.csv` | Orthogonal limma-voom / fry analysis of the same contrasts |
| `coculture_gene_scores.csv` | Genome-wide gene scores for the T-cell co-culture screen |
| `coculture_selected_genes.csv` | MGAT1, pathway neighbours and controls with UMI-bootstrap 95 % CI |
| `glyco_class_summary.csv` | Knockout vs control by glycan class, both cell lines |
| `glyco_site_paired.csv` | Within-site Man5 vs complex glycoform shift (105 sites) |
| `glyco_igp_log2fc.csv` | Per-glycopeptide log2 fold change and FDR |
| `structure_quality_summary.csv` | Resolution, R-factors, disordered regions and ligand B-factors for the five structures |
| `structure_ligand_contacts.csv` | Residues within 4 Å of each ligand (symmetry mates flagged) |
| `structure_inhibitor_distances.csv` | Distances from ANT-3744 to UDP, Mn, Asp211, Asp289 and the GlcNAc of UDP-GlcNAc |
| `biochem_dose_response_digitised_points.csv`, `biochem_dose_response_refit.csv` | Points digitised from the client's dose-response plots and four-parameter re-fits |
| `biochem_kd_vs_ic50_digitised.csv` | Points digitised from the SPR Kd vs IC50 plot |
| `biochem_efficiency_metrics.csv` | Ligand efficiency, LLE, IC50 relative to solubility |
| `figure_readoffs.csv` | Every value read from a client figure, with panel, series and notes |
| `figure_readoff_automated_checks.csv` | Automated marker-centroid checks of the key tumour-volume read-offs |
| `blot_stk11_densitometry.csv` | Rough densitometry of the Stk11 immunoblot |

## Method notes

- In vivo screen: counts → CPM; each tumour expressed as log2 ratio to the mean baseline of its own background (pseudocount 10 CPM), centred on the 400 non-targeting guides; gene score = mean of four guides; null = random four-guide sets of non-targeting guides; tumour-level bootstrap, permutation and rank tests for Mgat1. One failed library and one duplicated library were excluded. Effect sizes are conservative because of the pseudocount; the limma-voom cross-check gives the same directions and ranks with larger magnitudes.
- Co-culture screen: one sample per arm, so uncertainty comes from four guides per gene, ~100 UMIs per guide (bootstrap) and 989 non-targeting guides.
- Glycoproteomics: class-level and within-site ratios only; no total-proteome normalisation was available.
- Structures: coordinates only (no structure factors supplied), so electron density could not be re-examined.
- Figure read-offs are approximate (about ±5 %).
