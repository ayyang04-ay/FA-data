#!/usr/bin/env python
"""Independent re-analysis of the genome-wide T-cell co-culture screen (NCI-H1703, NY-ESO-1 TCR-T, 24 h, E:T 0.5).
One sample per arm, so replication is taken from (i) 4 guides/gene, (ii) ~100 UMIs (clones) per guide (bootstrap),
(iii) 989 non-targeting guides as an empirical null.
Input : coculture_screen_umi_counts.csv.gz      Outputs: tables/coculture_*.csv
Run   : micromamba run -n core python 02_coculture_screen.py
"""
import pandas as pd, numpy as np
from statsmodels.stats.multitest import multipletests
SRC = "/tmp/world/filesystem/"; OUT = "/tmp/outputs/tables/"
rng = np.random.default_rng(20261101)
d = pd.read_csv(SRC + "coculture_screen_umi_counts.csv.gz", keep_default_na=False)
d.columns = ["gene", "sgrna", "seq", "genetype", "umi", "ctrl", "tcell"]
print("rows (UMI x guide):", len(d), "| guides:", d.sgrna.nunique(), "| genes:", d.gene.nunique(), "| reads ctrl/T:", d.ctrl.sum(), d.tcell.sum())
g = d.groupby(["gene", "sgrna", "genetype"], sort=False).agg(ctrl=("ctrl", "sum"), tcell=("tcell", "sum"), n_umi=("umi", "size"),
        umi_ctrl=("ctrl", lambda x: int((x > 0).sum())), umi_tcell=("tcell", lambda x: int((x > 0).sum()))).reset_index()
print(g.groupby("genetype").agg(guides=("sgrna", "size"), median_ctrl_reads=("ctrl", "median"), median_umis=("n_umi", "median")))
nc = (g.genetype == "NegCtrl").values
sf = g.tcell[nc].sum() / g.ctrl[nc].sum()                      # size factor from non-targeting guides
PS = 20
raw = np.log2((g.tcell + PS) / (g.ctrl * sf + PS)); off = np.median(raw[nc]); g["lfc"] = raw - off
u = np.log2((g.umi_tcell + 3) / (g.umi_ctrl + 3)); g["lfc_umi_count"] = u - np.median(u[nc])   # clone-count based (robust to PCR/jackpot clones)
g.to_csv("/tmp/coculture_guide_level.csv", index=False)   # large; written to /tmp, not shipped

t = g[g.genetype == "other"].groupby("gene").agg(lfc=("lfc", "mean"), lfc_median=("lfc", "median"), lfc_umi_count=("lfc_umi_count", "mean"),
        n_guides=("lfc", "size"), guides_negative=("lfc", lambda x: int((x < 0).sum())), reads_ctrl=("ctrl", "sum"), reads_tcell=("tcell", "sum"))
idx = np.array([rng.choice(nc.sum(), 4, replace=False) for _ in range(200000)])
nul = np.sort(g.lfc[nc].values[idx].mean(1))
t["z"] = (t.lfc - nul.mean()) / nul.std()
t["p_depleted"] = (np.searchsorted(nul, t.lfc.values, side="right") + 1) / (len(nul) + 1)
t["p_enriched"] = (len(nul) - np.searchsorted(nul, t.lfc.values, side="left") + 1) / (len(nul) + 1)
t["fdr_depleted"] = multipletests(t.p_depleted, method="fdr_bh")[1]; t["fdr_enriched"] = multipletests(t.p_enriched, method="fdr_bh")[1]
t["rank_sensitiser"] = t.lfc.rank().astype(int); t["rank_resistance"] = (-t.lfc).rank().astype(int)
t["rank_sensitiser_median"] = t.lfc_median.rank().astype(int); t["rank_sensitiser_umi_count"] = t.lfc_umi_count.rank().astype(int)
t["fold"] = 2 ** t.lfc
t.sort_values("lfc").to_csv(OUT + "coculture_gene_scores.csv")
print("genes scored:", len(t), "| NegCtrl 4-guide null sd:", round(nul.std(), 3))

def boot(gene, nb=2000):
    sub = d[d.gene == gene]; arrs = [x[["ctrl", "tcell"]].values for _, x in sub.groupby("sgrna")]
    out = []
    for _ in range(nb):
        v = []
        for a in arrs:
            c, tt = a[rng.integers(0, len(a), len(a))].sum(0); v.append(np.log2((tt + PS) / (c * sf + PS)) - off)
        out.append(np.mean(v))
    return np.percentile(out, [2.5, 97.5])
sel = ["MGAT1", "MGAT2", "MAN2A1", "MGAT5", "SLC35A3", "B4GALT1", "SLC35A1", "SLC35A2", "CMAS", "GALE", "GFPT1", "UAP1", "MOGS",
       "PTPN2", "CFLAR", "B2M", "CTAG1B", "IFNGR1", "JAK1", "TNFRSF1A", "STK11", "CD274", "CD276"]
rows = []
for s in sel:
    lo, hi = boot(s); r = t.loc[s]
    rows.append(dict(gene=s, lfc=round(r.lfc, 2), ci95_lo=round(lo, 2), ci95_hi=round(hi, 2), fold=round(r.fold, 2), z=round(r.z, 1),
                     guides_negative=f"{int(r.guides_negative)}/{int(r.n_guides)}", rank_sensitiser=f"{int(r.rank_sensitiser)}/{len(t)}", rank_resistance=f"{int(r.rank_resistance)}/{len(t)}",
                     rank_sens_median=int(r.rank_sensitiser_median), rank_sens_umi_count=int(r.rank_sensitiser_umi_count), fdr_depleted=round(r.fdr_depleted, 4), fdr_enriched=round(r.fdr_enriched, 4)))
s = pd.DataFrame(rows); s.to_csv(OUT + "coculture_selected_genes.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
print(s.to_string(index=False))
print("\nTop 25 sensitisers:", list(t.sort_values("lfc").index[:25]))
print("Top 15 resistance :", list(t.sort_values("lfc", ascending=False).index[:15]))
