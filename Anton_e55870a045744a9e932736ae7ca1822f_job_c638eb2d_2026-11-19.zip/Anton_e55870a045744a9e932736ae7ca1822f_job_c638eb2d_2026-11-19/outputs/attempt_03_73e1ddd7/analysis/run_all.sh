#!/usr/bin/env bash
# Regenerates every table, log and figure in outputs/ from the 16 client files. ~5 min (the co-culture file is 8M rows).
set -euo pipefail
cd "$(dirname "$0")"
mm() { micromamba run -n "$@"; }
mm genomics   python  00_extract_pdf_content.py        2>/dev/null | tee logs/00_extract_pdf_content.log
mm core       python  01_invivo_screen.py                          | tee logs/01_invivo_screen.log
mm renv       Rscript 01b_invivo_limma_crosscheck.R    2>/dev/null | tee logs/01b_invivo_limma_crosscheck.log
mm core       python  02_coculture_screen.py                       | tee logs/02_coculture_screen.log
mm singlecell python  03_glycoproteomics.py            2>/dev/null | tee logs/03_glycoproteomics.log
mm core       python  04_structures.py                             | tee logs/04_structures.log
mm core       python  05_biochem_biophys.py                        | tee logs/05_biochem_biophys.log
mm core       python  07_figure_readoffs.py                        | tee logs/07_figure_readoffs.log
mm core       python  06_summary_figure.py                         | tee logs/06_summary_figure.log
mm core       python  08_render_memo_html.py
