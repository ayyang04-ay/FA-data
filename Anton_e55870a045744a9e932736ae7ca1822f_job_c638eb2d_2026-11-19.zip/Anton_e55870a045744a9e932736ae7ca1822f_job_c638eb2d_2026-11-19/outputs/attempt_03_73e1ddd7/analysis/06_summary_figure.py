#!/usr/bin/env python
"""One-page evidence figure built only from the re-analysis tables. Run after scripts 01-05:
micromamba run -n core python 06_summary_figure.py"""
import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
import gemmi
T = "/tmp/outputs/tables/"; SRC = "/tmp/world/filesystem/"
plt.rcParams.update({"font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False, "axes.titlesize": 9.5, "axes.titleweight": "bold"})
fig, ax = plt.subplots(2, 3, figsize=(17.5, 10.2)); ax = ax.ravel()
C_NTC, C_STK, C_HI = "#8a8a8a", "#c0392b", "#1f5fa8"

# A ---------------------------------------------------------------- Mgat1 in the in vivo screen
m = pd.read_csv(T + "invivo_mgat1_by_group.csv").set_index("group")
order = [("Endpoint_NTC", "in vitro"), ("Group1_NTC", "G1\nnude"), ("Group2_NTC", "G2\nB6\nisotype"), ("Group3_NTC", "G3\nB6\nPD-1\nblocked"), ("Group4_NTC", "G4\nB6\nPD-1\nblocked"),
         ("Endpoint_STK11", "in vitro"), ("Group5_STK11", "G5\nnude"), ("Group6_STK11", "G6\nB6\nisotype"), ("Group7_STK11", "G7\nB6\nPD-1\nblocked"), ("Group8_STK11", "G8\nB6\nPD-1\nblocked")]
x = np.r_[np.arange(5), np.arange(5) + 5.8]
for xi, (g, lab) in zip(x, order):
    r = m.loc[g]; col = C_NTC if "NTC" in g else C_STK
    ax[0].bar(xi, r.gene_lfc, color=col, width=0.75, alpha=0.85)
    ax[0].errorbar(xi, r.gene_lfc, yerr=[[r.gene_lfc - r.ci95_lo], [r.ci95_hi - r.gene_lfc]], color="k", capsize=2.5, lw=1)
    ax[0].text(xi, min(r.ci95_lo, 0) - 0.12, f"n={r.n}", ha="center", va="top", fontsize=7)
ax[0].set_xticks(x); ax[0].set_xticklabels([l for _, l in order], fontsize=7); ax[0].axhline(0, color="k", lw=0.6)
ax[0].set_ylabel("Mgat1 log2 fold change vs baseline\n(mean of 4 guides; 95% CI over tumours)"); ax[0].set_ylim(-3.75, 0.6)
ax[0].text(2, 0.42, "Stk11-intact (sgNTC)", ha="center", color=C_NTC, weight="bold"); ax[0].text(7.8, 0.42, "Stk11-knockout", ha="center", color=C_STK, weight="bold")
ax[0].set_title("A  In vivo screen: Mgat1 guides are lost from Stk11-KO tumours -\n    more with adaptive immunity, no further with PD-1 blockade", loc="left")
ax[0].text(0.01, 0.015, "Group key is not in the records: inferred from animal-ID blocks and\nCd274 / IFN-pathway guides (tables/invivo_group_inference_markers.csv)", transform=ax[0].transAxes, fontsize=6.3, color="#444")

# B ---------------------------------------------------------------- STK11-selective dependencies
bg = pd.read_csv(T + "invivo_gene_by_group.csv")
pv = bg.pivot(index="gene", columns="group", values="lfc")
xN = pv[["Group2_NTC", "Group3_NTC", "Group4_NTC"]].mean(1); yS = pv[["Group6_STK11", "Group7_STK11", "Group8_STK11"]].mean(1)
ax[1].scatter(xN, yS, s=7, color="#bdbdbd"); lim = [-3.9, 1.6]; ax[1].plot(lim, lim, color="k", lw=0.6, ls="--")
for g, col, dx, dy in [("Mgat1", C_STK, 0.35, -0.35), ("B4galt1", C_HI, 0.45, -0.1), ("Mgat2", "k", 0.25, 0.45), ("Cd274", "k", -0.9, 0.75), ("B2m", "#555", -0.75, 0.25), ("Cd47", "#555", 0.45, -0.25)]:
    ax[1].scatter(xN[g], yS[g], s=40, color=col, zorder=5)
    ax[1].annotate(g, (xN[g], yS[g]), xytext=(xN[g] + dx, yS[g] + dy), fontsize=8, color=col, arrowprops=dict(arrowstyle="-", color=col, lw=0.6), va="center")
ax[1].set_xlim(lim); ax[1].set_ylim(lim); ax[1].set_aspect("equal")
ax[1].set_xlabel("LFC vs baseline, Stk11-intact tumours (C57BL/6 arms G2-4)"); ax[1].set_ylabel("LFC vs baseline, Stk11-KO tumours (C57BL/6 arms G6-8)")
ax[1].text(0.03, 0.95, "Mgat1: rank 1 of 795 for Stk11-selective depletion\n(delta LFC -1.90, z -7.4); B4galt1 rank 2; Mgat2 not depleted", transform=ax[1].transAxes, fontsize=7.5, va="top")
ax[1].set_title("B  In vivo screen: Mgat1 is the top Stk11-selective\n    dependency among 795 genes", loc="left")

# C ---------------------------------------------------------------- co-culture screen
s = pd.read_csv(T + "coculture_gene_scores.csv").sort_values("lfc").reset_index(drop=True)
ax[2].scatter(np.arange(len(s)) + 1, s.lfc, s=3, color="#cfcfcf", rasterized=True)
lab = {"MGAT1": (C_STK, 2500, -0.95), "MGAT2": ("k", 5000, -0.45), "SLC35A1": (C_HI, 2500, -1.55), "SLC35A2": (C_HI, 2500, -1.25), "PTPN2": ("#555", 5200, -1.35), "CFLAR": ("#555", 2500, -1.85),
       "B2M": ("#555", 12500, 1.42), "CTAG1B": ("#555", 12500, 1.68), "STK11": ("k", 11000, 0.55), "CD276": ("k", 12500, 0.95), "CD274": ("k", 500, 0.5)}
for g, (col, tx, ty) in lab.items():
    i = s.index[s.gene == g][0]; ax[2].scatter(i + 1, s.lfc[i], s=30, color=col, zorder=5)
    ax[2].annotate(f"{g} ({i+1})", (i + 1, s.lfc[i]), xytext=(tx, ty), fontsize=7.5, color=col, arrowprops=dict(arrowstyle="-", color=col, lw=0.5), va="center")
ax[2].axhline(0, color="k", lw=0.5); ax[2].set_xlabel("gene rank (18,681 genes)"); ax[2].set_ylabel("log2 fold change, T-cell arm vs tumour-only\n(mean of 4 guides)")
ax[2].set_title("C  Human T-cell co-culture screen (NCI-H1703, 1 sample/arm):\n    MGAT1 rank 19 of 18,681; MGAT2 silent", loc="left")

# D ---------------------------------------------------------------- single-gene tumour studies (figure read-offs)
f = pd.read_csv(T + "figure_readoffs.csv"); f = f[f.source.str.contains("p1") & (f.unit == "mm3")].copy(); f["value"] = f.value.astype(float)
labs = ["NTC", "MGAT1\nKO", "NTC", "MGAT1\nKO", "NTC\nIgG2a", "NTC\naPD-1", "KO\nIgG2a", "KO\naPD-1"]
xs = [0, 1, 2.6, 3.6, 5.2, 6.2, 7.2, 8.2]; cols = [C_NTC, C_NTC, C_STK, C_STK, C_STK, C_STK, C_STK, C_STK]; hatch = ["", "//", "", "//", "", "", "//", "//"]
for xi, (_, r), cc, hh in zip(xs, f.iterrows(), cols, hatch):
    ax[3].bar(xi, r.value, color=cc, alpha=0.85, hatch=hh, edgecolor="white", width=0.8)
    ax[3].errorbar(xi, r.value, yerr=[[r.value - r.error_bar_low], [r.error_bar_high - r.value]], color="k", capsize=2.5, lw=0.9)
    ax[3].text(xi, 40, f"{r.value:.0f}", ha="center", fontsize=7.5, color="white", weight="bold")
ax[3].set_xticks(xs); ax[3].set_xticklabels(labs, fontsize=7); ax[3].set_ylabel("tumour volume, last time point (mm$^3$)\nread from phenotype_figures p1; error bars as drawn")
for xm, t in [(0.5, "Stk11-intact\nday 25"), (3.1, "Stk11-KO\nday 19"), (6.7, "Stk11-KO + antibody\nday 9 of treatment")]: ax[3].text(xm, 2780, t, ha="center", fontsize=7.5)
ax[3].set_ylim(0, 3000)
ax[3].set_title("D  MC38 single-gene tumours: full MGAT1 knockout ~halves growth in\n    Stk11-KO, adds to (does not synergise with) anti-PD-1", loc="left")

# E ---------------------------------------------------------------- dose-response re-fits
p = pd.read_csv(T + "biochem_dose_response_digitised_points.csv"); fit = pd.read_csv(T + "biochem_dose_response_refit.csv").set_index("compound")
f4 = lambda lc, top, bottom, lic50, h: bottom + (top - bottom) / (1 + 10 ** ((lc - lic50) * h))
from scipy.optimize import curve_fit
for name, col in [("ANT-0592", "#999999"), ("ANT-3744", C_HI), ("ANT-4267", C_STK)]:
    d = p[p["compound"] == name]; lc = np.log10(d.conc_uM)
    po, _ = curve_fit(f4, lc, d.activity_pct, p0=[100, 5, np.log10(fit.loc[name, "registry_ic50_uM"]), 1], bounds=([80, -20, -4, 0.3], [120, 40, 4, 4]))
    xx = np.linspace(lc.min() - 0.2, lc.max() + 0.2, 200); ax[4].plot(10 ** xx, f4(xx, *po), color=col, lw=1.2); ax[4].scatter(d.conc_uM, d.activity_pct, s=18, color=col, label=f"{name} (registry IC50 {fit.loc[name,'registry_ic50_uM']:g} µM)")
ax[4].axhspan(7.5, 10.5, color="#f5c542", alpha=0.35, lw=0); ax[4].text(0.0035, 1.0, "plateau at 8-10% residual signal", fontsize=7.5, color="#8a6d00")
ax[4].axvline(11.8, color="#999999", ls=":", lw=1); ax[4].text(13, 104, "ANT-0592 kinetic\nsolubility 11.8 µM", fontsize=7, color="#777")
ax[4].set_xscale("log"); ax[4].set_xlabel("compound (µM)"); ax[4].set_ylabel("MGAT1 activity (%), digitised from assay_figures p1"); ax[4].set_ylim(-4, 115); ax[4].legend(frameon=False, fontsize=7, loc="center right")
ax[4].set_title("E  Enzyme assay re-fit: potency confirmed (lead 43 nM);\n    inhibition plateaus at ~90-92%", loc="left")

# F ---------------------------------------------------------------- where the inhibitor sits
st = gemmi.read_structure(SRC + "MGAT1_C3744_UDP.cif"); st.setup_entities()
ca, lig, udp, mn, d289 = [], [], [], [], []
for ch in st[0]:
    if ch.name != "A": continue
    for r in ch:
        P = [[a.pos.x, a.pos.y, a.pos.z] for a in r]
        if r.name == "C3744": lig += P
        elif r.name == "UDP": udp += P
        elif r.name == "MN": mn += P
        elif r.find_atom("CA", "*") and r.name not in ("HOH",):
            ca.append([r["CA"][0].pos.x, r["CA"][0].pos.y, r["CA"][0].pos.z, r.seqid.num])
            if r.seqid.num == 289: d289 += P
ca = np.array(ca); lig, udp, mn, d289 = map(np.array, (lig, udp, mn, d289))
v1 = lig.mean(0) - udp.mean(0); v1 /= np.linalg.norm(v1)                       # view: inhibitor-UDP axis horizontal
cen = ca[:, :3].mean(0); X = ca[:, :3] - cen; X = X - np.outer(X @ v1, v1); v2 = np.linalg.svd(X, full_matrices=False)[2][0]
pr = lambda A: np.c_[(A - cen) @ v1, (A - cen) @ v2]
pc = pr(ca[:, :3]); cter = ca[:, 3] >= 354
ax[5].plot(pc[:, 0], pc[:, 1], color="#d0d0d0", lw=0.8, zorder=1)
ax[5].scatter(pc[~cter, 0], pc[~cter, 1], s=7, color="#9aa7b5", label="residues 99-353 (contain all donor-site residues), Cα", zorder=2)
ax[5].scatter(pc[cter, 0], pc[cter, 1], s=7, color="#d9b38c", label="residues 354-445 (contain the ANT-3744 pocket), Cα", zorder=2)
for A, col, lab_, sz in [(udp, "#c0392b", "UDP", 26), (mn, "#7d3c98", "Mn$^{2+}$", 60), (d289, "#1e8449", "Asp289 (mutated in dead enzyme)", 26), (lig, "#1f5fa8", "ANT-3744", 26)]:
    q = pr(A); ax[5].scatter(q[:, 0], q[:, 1], s=sz, color=col, label=lab_, zorder=4, edgecolor="white", lw=0.3)
a_, b_ = pr(lig).mean(0), pr(udp).mean(0)
ax[5].annotate("", xy=a_, xytext=b_, arrowprops=dict(arrowstyle="<->", color="k", lw=1)); ax[5].text((a_[0] + b_[0]) / 2, max(a_[1], b_[1]) + 4.5, "23.9 Å closest approach\n(33 Å centre-to-centre)", ha="center", fontsize=8)
ax[5].set_aspect("equal"); ax[5].set_xticks([]); ax[5].set_yticks([]); ax[5].spines[:].set_visible(False); ax[5].legend(frameon=False, fontsize=7, loc="lower left", ncol=2, bbox_to_anchor=(-0.12, -0.2))
ax[5].set_title("F  Ternary crystal structure (2.0 Å): ANT-3744 sits in a C-terminal\n    pocket, remote from the donor site and catalytic residues", loc="left")
fig.tight_layout(h_pad=2.2, w_pad=1.6)
fig.savefig("/tmp/outputs/figures/evidence_summary.png", dpi=170, bbox_inches="tight"); print("saved")
