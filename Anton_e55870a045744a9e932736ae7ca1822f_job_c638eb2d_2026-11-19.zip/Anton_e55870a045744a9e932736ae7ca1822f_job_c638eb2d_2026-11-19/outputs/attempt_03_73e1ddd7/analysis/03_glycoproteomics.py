#!/usr/bin/env python
"""Re-analysis of the TMT intact-glycopeptide dataset (A375 and NCI-H1703; sgNTC vs MGAT1-KO population; n = 4 each).
Input : glycoproteomics_site_quant.xlsx (sheet IGP_quant)     Outputs: tables/glyco_*.csv
Run   : micromamba run -n singlecell python 03_glycoproteomics.py
Caveats handled: no total-proteome normalisation (KO channels carry 1.5-1.7x more glycopeptide signal) -> class medians are
reported on raw ratios AND as within-site glycoform fractions, which are independent of loading / protein abundance.
"""
import pandas as pd, numpy as np, re
from scipy import stats
from statsmodels.stats.multitest import multipletests
SRC = "/tmp/world/filesystem/"; OUT = "/tmp/outputs/tables/"
igp = pd.read_excel(SRC + "glycoproteomics_site_quant.xlsx", sheet_name="IGP_quant")
igp.columns = [c.replace("Intensity ", "") for c in igp.columns]
A_KO = [f"AM_KO{i}" for i in range(1, 5)]; A_N = [f"AM_N{i}" for i in range(1, 5)]
H_KO = [f"NH_M_KO{i}" for i in range(1, 5)]; H_N = [f"NH_N{i}" for i in range(1, 5)]
ch = A_KO + A_N + H_KO + H_N
print("intact glycopeptides:", len(igp), "| sites:", igp.groupby(["Protein accession", "Position"]).ngroups, "| proteins:", igp["Protein accession"].nunique())
print("channel sums (x1e9):", (igp[ch].sum() / 1e9).round(2).to_dict())
L = np.log2(igp[ch] + 1e3); Lc = L.sub(L.mean(1), axis=0)
print("replicate clustering (min within-condition r / max between-condition r):",
      round(min(Lc[g].corr().values[np.triu_indices(4, 1)].min() for g in (A_KO, A_N, H_KO, H_N)), 2), "/",
      round(max(Lc[a + b].corr().loc[a, b].values.max() for a, b in ((A_KO, A_N), (H_KO, H_N))), 2))

def comp(s):
    c = dict(HexNAc=0, Hex=0, Fuc=0, NeuAc=0)
    for n, k in re.findall(r"([A-Za-z]+)\((\d+)\)", str(s)):
        if n in c: c[n] += int(k)
    return c
def cls(s):
    c = comp(s); extra = "Phospho" in str(s)
    if c["HexNAc"] == 2 and c["Hex"] == 5 and c["Fuc"] == 0 and not extra: return "Man5 (MGAT1 substrate)"
    if c["HexNAc"] == 2 and 6 <= c["Hex"] <= 9 and c["Fuc"] == 0 and not extra: return "Man6-9 (upstream)"
    if c["HexNAc"] >= 4 and c["NeuAc"] > 0: return "complex, sialylated (HexNAc>=4, NeuAc>=1)"
    if c["HexNAc"] >= 4: return "complex, non-sialylated (HexNAc>=4)"
    if c["HexNAc"] == 3: return "hybrid / mono-antennary (HexNAc3)"
    return "other (paucimannose, truncated, phospho, Hex10+)"
igp["class"] = igp["Observed Modification"].map(cls)
for lab, (k, n) in {"A375": (A_KO, A_N), "H1703": (H_KO, H_N)}.items():
    igp[f"lfc_{lab}"] = np.log2((igp[k].mean(1) + 1e3) / (igp[n].mean(1) + 1e3))
    p = stats.ttest_ind(np.log2(igp[k] + 1e3), np.log2(igp[n] + 1e3), axis=1).pvalue
    igp[f"q_{lab}"] = multipletests(np.nan_to_num(p, nan=1.0), method="fdr_bh")[1]
rows = []
for c, s in igp.groupby("class"):
    r = dict(glycan_class=c, n_glycopeptides=len(s))
    for lab in ("A375", "H1703"):
        l, q = s[f"lfc_{lab}"], s[f"q_{lab}"]
        r[f"{lab}_median_log2FC_KO_vs_NTC"] = round(l.median(), 2)
        r[f"{lab}_pct_up_>=1.5x_FDR5"] = round(100 * ((l > 0.585) & (q < 0.05)).mean(), 1)
        r[f"{lab}_pct_down_>=1.5x_FDR5"] = round(100 * ((l < -0.585) & (q < 0.05)).mean(), 1)
    rows.append(r)
cs = pd.DataFrame(rows); cs.to_csv(OUT + "glyco_class_summary.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30); pd.set_option("display.max_colwidth", 50)
print(cs.to_string(index=False))

# within-site analysis: sites carrying both Man5 and complex-type glycoforms
rows = []
for (acc, pos), s in igp.groupby(["Protein accession", "Position"]):
    m5 = s[s["class"].str.startswith("Man5")]; cx = s[s["class"].str.startswith("complex")]
    if len(m5) and len(cx):
        r = dict(gene=s["Gene name"].iloc[0], site=pos, n_complex_glycoforms=len(cx))
        for lab, (k, n) in {"A375": (A_KO, A_N), "H1703": (H_KO, H_N)}.items():
            m5k, m5n, cxk, cxn = m5[k].values.sum() / 4, m5[n].values.sum() / 4, cx[k].values.sum() / 4, cx[n].values.sum() / 4
            r.update({f"{lab}_Man5_FC": round(m5k / m5n, 2), f"{lab}_complex_FC": round(cxk / cxn, 2),
                      f"{lab}_complex_fraction_NTC": round(cxn / (cxn + m5n), 3), f"{lab}_complex_fraction_KO": round(cxk / (cxk + m5k), 3)})
        rows.append(r)
site = pd.DataFrame(rows); site.to_csv(OUT + "glyco_site_paired.csv", index=False)
print("\nsites with both Man5 and complex glycoforms:", len(site))
for lab in ("A375", "H1703"):
    print(f"  {lab}: median Man5 FC {site[f'{lab}_Man5_FC'].median():.2f}x | median complex FC {site[f'{lab}_complex_FC'].median():.2f}x | "
          f"median complex fraction NTC {site[f'{lab}_complex_fraction_NTC'].median():.2f} -> KO {site[f'{lab}_complex_fraction_KO'].median():.2f} | "
          f"sites with fraction falling: {(site[f'{lab}_complex_fraction_KO'] < site[f'{lab}_complex_fraction_NTC']).sum()}/{len(site)}")
print("\nCD276 (B7-H3) N91:\n", igp[(igp["Gene name"] == "CD276") & (igp.Position == 91)][["Observed Modification", "class", "lfc_A375", "q_A375", "lfc_H1703", "q_H1703"]].round(3).to_string(index=False))
implausible = igp[igp["Gene name"].isin(["SP9", "PHOX2B", "PLK4", "HNRNPA1L3", "HNRNPC", "POLR1B"])]
print("\nexamples of implausible (nuclear) 'N-glycoprotein' identifications (search false positives):", sorted(implausible["Gene name"].unique()),
      "| their median |log2FC|:", round(implausible[["lfc_A375", "lfc_H1703"]].abs().median().mean(), 2))
igp.drop(columns=ch).to_csv(OUT + "glyco_igp_log2fc.csv", index=False)
