#!/usr/bin/env Rscript
# Orthogonal check of the in vivo screen conclusions: limma-voom on raw guide counts (normalised on the 400 non-targeting
# guides) + rotation gene-set test (fry) treating each gene's 4 guides as a set.
# Run: micromamba run -n renv Rscript 01b_invivo_limma_crosscheck.R
suppressMessages({library(edgeR); library(limma)})
d <- read.csv(gzfile("/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz"), check.names=FALSE)
cnt <- as.matrix(d[, -(1:3)]); rownames(cnt) <- d$gene_sgrna_id
drop <- c("Group7_STK11_82431", "Group3_NTC_82364")           # failed library; duplicate library
cnt <- cnt[, grepl("^Group", colnames(cnt)) & !(colnames(cnt) %in% drop)]
grp <- factor(sub("_[^_]+$", "", colnames(cnt)))
isctrl <- grepl("^NegCtrl", rownames(cnt))
y <- DGEList(cnt, group=grp)
yc <- calcNormFactors(y[isctrl, , keep.lib.sizes=FALSE], method="TMMwsp")
nf <- yc$samples$norm.factors * colSums(cnt[isctrl,]) / colSums(cnt); y$samples$norm.factors <- nf / exp(mean(log(nf)))
design <- model.matrix(~0+grp); colnames(design) <- levels(grp)
v <- voom(y, design, plot=FALSE); fit <- lmFit(v, design)
cm <- makeContrasts(
  "STK11: C57BL/6 (G6-8) vs nude (G5)"           = (Group6_STK11+Group7_STK11+Group8_STK11)/3 - Group5_STK11,
  "STK11: PD-1-blocked (G7+8) vs isotype (G6)"   = (Group7_STK11+Group8_STK11)/2 - Group6_STK11,
  "NTC: C57BL/6 (G2-4) vs nude (G1)"             = (Group2_NTC+Group3_NTC+Group4_NTC)/3 - Group1_NTC,
  "NTC: PD-1-blocked (G3+4) vs isotype (G2)"     = (Group3_NTC+Group4_NTC)/2 - Group2_NTC,
  "C57BL/6: STK11 (G6-8) vs NTC (G2-4)"          = (Group6_STK11+Group7_STK11+Group8_STK11)/3 - (Group2_NTC+Group3_NTC+Group4_NTC)/3,
  "interaction: immune-dependence STK11 - NTC"   = ((Group6_STK11+Group7_STK11+Group8_STK11)/3 - Group5_STK11) - ((Group2_NTC+Group3_NTC+Group4_NTC)/3 - Group1_NTC),
  levels=design)
fit2 <- eBayes(contrasts.fit(fit, cm), robust=TRUE)
genes <- d$gene_symbol; genes[isctrl] <- "NegCtrl"; idx <- split(seq_along(genes), genes); idx <- idx[names(idx) != "NegCtrl"]
out <- NULL
for (cn in colnames(cm)) {
  fr <- fry(v, index=idx, design=design, contrast=cm[, cn]); tt <- topTable(fit2, coef=cn, number=Inf, sort.by="none")
  m <- tt[grep("^Mgat1_", rownames(tt)), "logFC"]; fr$rank <- rank(ifelse(fr$Direction=="Down", fr$PValue, 2 - fr$PValue)); o <- fr[order(fr$rank), ]
  out <- rbind(out, data.frame(contrast=cn, mgat1_guide_logFC=paste(sprintf("%.2f", m), collapse=" / "), mgat1_mean_logFC=round(mean(m), 2), fry_direction=fr["Mgat1","Direction"],
               fry_P=signif(fr["Mgat1","PValue"], 2), fry_FDR=signif(fr["Mgat1","FDR"], 2), rank_depleted=sprintf("%d/%d", fr["Mgat1","rank"], nrow(fr)), top5_depleted=paste(rownames(o)[1:5], collapse=", ")))
}
write.csv(out, "/tmp/outputs/tables/invivo_mgat1_limma_crosscheck.csv", row.names=FALSE); print(out, row.names=FALSE)
