#!/usr/bin/env python
"""Extract text and embedded figure images from the three client PDFs (needed by 05_biochem_biophys.py and for figure read-offs).
Run: micromamba run -n genomics python 00_extract_pdf_content.py
"""
import pypdf, os
SRC = "/tmp/world/filesystem/"; OUT = "/tmp/outputs/figures/source_panels/"
os.makedirs(OUT, exist_ok=True)
for f in ["experimental_records.pdf", "assay_figures.pdf", "phenotype_figures.pdf"]:
    r = pypdf.PdfReader(SRC + f); stem = f[:-4]
    with open(OUT + stem + ".txt", "w") as fh:
        for i, p in enumerate(r.pages):
            fh.write(f"\n--- page {i+1} ---\n" + p.extract_text())
            for im in p.images:
                open(f"{OUT}{stem}_p{i+1}.png", "wb").write(im.data)
    print(f, "pages:", len(r.pages), "| metadata:", {k: str(v) for k, v in r.metadata.items() if k in ("/Title", "/CreationDate")})
