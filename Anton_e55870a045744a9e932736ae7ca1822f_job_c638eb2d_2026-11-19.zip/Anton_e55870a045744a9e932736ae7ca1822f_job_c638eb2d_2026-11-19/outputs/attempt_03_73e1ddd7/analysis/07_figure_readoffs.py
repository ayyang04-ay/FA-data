#!/usr/bin/env python
"""Provenance for every number read from a client figure.
 (a) writes pixel-calibrated overlays (value gridlines drawn on the client's own panels) to figures/readoff_overlays/
     so each read-off in tables/figure_readoffs.csv can be checked by eye;
 (b) automated marker-centroid checks for the key tumour-volume numbers;
 (c) rough densitometry of the Stk11 immunoblot (phenotype_figures p6).
Axis calibrations were measured from the tick marks of each panel (pixel positions listed below).
Run after 00_extract_pdf_content.py:  micromamba run -n core python 07_figure_readoffs.py
"""
import os, numpy as np, pandas as pd
from PIL import Image, ImageDraw
from scipy import ndimage
PAN = "/tmp/outputs/figures/source_panels/"; OV = "/tmp/outputs/figures/readoff_overlays/"; OUT = "/tmp/outputs/tables/"
os.makedirs(OV, exist_ok=True)

def overlay(page, name, box, xcal, ycal, xgrid, ygrid, scale=3):
    """xcal/ycal = (pixel_a, value_a, pixel_b, value_b); box = (x0, y0, x1, y1) in source pixels."""
    im = Image.open(f"{PAN}phenotype_figures_p{page}.png").convert("RGB"); x0, y0, x1, y1 = box
    cr = im.crop(box).resize(((x1 - x0) * scale, (y1 - y0) * scale), Image.LANCZOS); d = ImageDraw.Draw(cr)
    fx = lambda v: ((xcal[0] + (v - xcal[1]) * (xcal[2] - xcal[0]) / (xcal[3] - xcal[1])) - x0) * scale
    fy = lambda v: ((ycal[0] + (v - ycal[1]) * (ycal[2] - ycal[0]) / (ycal[3] - ycal[1])) - y0) * scale
    for v in ygrid: d.line([(0, fy(v)), (cr.size[0], fy(v))], fill=(255, 0, 255), width=1); d.text((2, fy(v) - 10), str(v), fill=(255, 0, 255))
    for v in xgrid: d.line([(fx(v), 0), (fx(v), cr.size[1])], fill=(0, 170, 255), width=1); d.text((fx(v) + 2, 2), str(v), fill=(0, 110, 255))
    cr.save(f"{OV}p{page}_{name}.png")
r = lambda a, b, s: [round(x, 3) for x in np.arange(a, b + 1e-9, s)]
OVERLAYS = [
 (1, "MC38_WT",             (230, 220, 860, 640),   (240.5, 0, 826.5, 25), (628.5, 0, 238, 3000),  [7, 9, 11, 13, 15, 18, 20, 22, 25], r(0, 2800, 200), 3),
 (1, "MC38_sgSTK11",        (1090, 240, 1720, 640), (1099, 0, 1688, 20),   (628.5, 0, 292.5, 1500), [0, 8, 10, 12, 15, 17, 19],       r(0, 1600, 100), 3),
 (1, "MC38_sgSTK11_antiPD1",(2030, 230, 2640, 640), (2044, 0, 2615, 10),   (629, 0, 248, 2000),    [0, 2, 4, 7, 9],                   r(0, 1900, 100), 3),
 (8, "library_sgNTC",       (310, 230, 1110, 775),  (325.5, 0, 1084.5, 10),(756.5, 0, 250.5, 1500),[0, 2, 4, 6, 8],                   r(0, 1400, 100), 2),
 (8, "library_sgSTK11",     (1500, 230, 2300, 775), (1512.5, 0, 2268.5, 10),(755.5, 0, 252.5, 2000),[0, 2, 4, 6, 7],                  r(0, 1800, 100), 2),
 (4, "ACT_control_T",       (150, 95, 500, 375),    (158.5, 0, 472.5, 20), (363.5, 0, 107.5, 2500),[0, 4, 7, 9, 12, 15, 19],          r(0, 2250, 250), 4),
 (4, "ACT_NYESO_1e6",       (150, 527, 500, 807),   (156.5, 0, 472, 20),   (795.5, 0, 539.5, 2500),[0, 4, 7, 9, 12, 15, 19],          r(0, 2250, 250), 4),
 (4, "ACT_NYESO_2e6",       (150, 959, 500, 1239),  (156.5, 0, 472, 20),   (1227.5, 0, 971.5, 2500),[0, 4, 7, 9, 12, 15, 19],         r(0, 2250, 250), 4),
 (7, "rescue_sgNTC",        (355, 230, 830, 655),   (368, 0, 803, 20),     (638, 0, 245, 1500),    [0, 5, 7, 10, 12],                 r(0, 1400, 100), 3),
 (7, "rescue_sgMGAT1",      (1050, 230, 1530, 655), (1064.5, 0, 1499, 20), (642, 0, 240, 1500),    [0, 5, 7, 10, 12, 14, 17, 19],     r(0, 1400, 100), 3),
 (3, "coculture_H1703",     (215, 100, 660, 500),   (0, 0, 100, 1),        (485.5, 0, 116.5, 2.5), [],                                r(0, 2.1, 0.1), 3),
 (3, "coculture_H1755",     (210, 795, 660, 1200),  (0, 0, 100, 1),        (1183.5, 0, 810.5, 2.0),[],                                r(0, 1.9, 0.1), 3),
 (5, "rescue_PHAL_MFI_1e6", (260, 330, 900, 780),   (0, 0, 100, 1),        (758, 0, 350, 10),      [],                                [0, 0.5, 1, 2, 3, 4, 5, 5.5, 6, 6.5, 7, 7.5, 8], 2),
 (5, "rescue_viability",    (1370, 250, 2200, 790), (0, 0, 100, 1),        (772.5, 0, 267, 1.5),   [],                                r(0, 1.4, 0.1), 2),
 (2, "PHAL_A375",           (155, 380, 400, 460),   (0, 0, 100, 1),        (449.5, 0, 175.5, 1.5), [],                                [0, 0.02, 0.04, 0.06, 0.08, 0.1, 0.2], 5),
 (2, "PHAL_H1703",          (160, 880, 400, 960),   (0, 0, 100, 1),        (946.5, 0, 662.5, 1.5), [],                                [0, 0.02, 0.04, 0.06, 0.08, 0.1, 0.2], 5),
 (2, "GNA_A375",            (555, 190, 800, 450),   (0, 0, 100, 1),        (440.5, 0, 161.5, 10),  [],                                [0, 1, 2, 7, 7.5, 8, 8.5, 9], 3),
 (2, "GNA_H1703",           (560, 680, 800, 950),   (0, 0, 100, 1),        (941.5, 0, 664.5, 10),  [],                                [0, 1, 2, 7, 7.5, 8, 8.5, 9], 3),
]
for o in OVERLAYS: overlay(*o)
print("overlays written:", len(os.listdir(OV)))

# ---- (b) automated centroid checks (series drawn in black have symmetric bars, so blob centroid = plotted mean)
def blobs(a, xpix, halfw, ylo, yhi, cond, minsize):
    sub = a[ylo:yhi, int(xpix - halfw):int(xpix + halfw)]; m = cond(sub[..., 0], sub[..., 1], sub[..., 2]); lab, n = ndimage.label(m)
    return [(np.where(lab == i)[0].mean() + ylo, (lab == i).sum()) for i in range(1, n + 1) if (lab == i).sum() >= minsize]
black = lambda r, g, b: (r < 40) & (g < 40) & (b < 40)
green = lambda r, g, b: (g > 140) & (r < 90) & (b < 110)
blue = lambda r, g, b: (b > 120) & (r < 80) & (g < 90)
gray = lambda r, g, b: (abs(r - g) < 12) & (abs(g - b) < 12) & (r > 130) & (r < 180)
navy = lambda r, g, b: (b > 110) & (r < 90) & (g < 100) & (b - r > 50)
p1 = np.array(Image.open(PAN + "phenotype_figures_p1.png").convert("RGB")).astype(int); p7 = np.array(Image.open(PAN + "phenotype_figures_p7.png").convert("RGB")).astype(int)
rows = []
def add(lab, img, x, ylo, yhi, cond, yfun, minsize, pick):
    b = sorted(blobs(img, x, 14, ylo, yhi, cond, minsize), key=lambda t: -t[1]); v = [round(yfun(y)) for y, s in b]
    rows.append(dict(read_off=lab, automated_centroid_mm3=pick(v) if v else None, all_blobs=v))
yC = lambda y: (629 - y) / (629 - 248) * 2000; xC = lambda d: 2044 + 57.1 * d
add("p1 sgSTK11 NTC;IgG2a day 9 (manual 1135)", p1, xC(9), 240, 625, black, yC, 100, lambda v: v[0])
add("p1 sgSTK11 NTC;anti-PD1 day 9 (manual 757)", p1, xC(9), 440, 520, gray, yC, 30, lambda v: v[0])
add("p1 sgSTK11 sgMGAT1;IgG2a day 9 (manual 613)", p1, xC(9), 480, 540, green, yC, 40, lambda v: v[0])
add("p1 sgSTK11 sgMGAT1;anti-PD1 day 9 (manual 402)", p1, xC(9), 530, 570, blue, yC, 20, lambda v: round(np.mean(v)))
yA = lambda y: (628.5 - y) / (628.5 - 238) * 3000; add("p1 MC38 WT sgNTC day 25 (manual 1160)", p1, 826.5, 230, 625, black, yA, 100, lambda v: v[0])
yB = lambda y: (628.5 - y) / (628.5 - 292.5) * 1500; add("p1 MC38 sgSTK11 sgNTC day 19 (manual 1085)", p1, 1099 + (1688 - 1099) / 20 * 19, 250, 625, black, yB, 100, lambda v: v[0])
y7 = lambda y: (642 - y) / (642 - 240) * 1500; x7 = lambda d: 1064.5 + (1499 - 1064.5) / 20 * d
add("p7 sgSTK11+sgMGAT1 WT cDNA day 19 (manual 860)", p7, x7(19), 240, 635, black, y7, 100, lambda v: v[0])
add("p7 sgSTK11+sgMGAT1 D211A+D289A day 19 (manual 425)", p7, x7(19), 240, 645, navy, y7, 100, lambda v: v[0])
chk = pd.DataFrame(rows); chk.to_csv(OUT + "figure_readoff_automated_checks.csv", index=False); print(chk.to_string(index=False))

# ---- (c) Stk11 immunoblot densitometry (9 lanes; local background from the strip just above the band)
im = np.array(Image.open(PAN + "phenotype_figures_p6.png").convert("L")).astype(float)
stk, vin = im[325:520, 335:1100], im[532:672, 335:1100]; edges = np.linspace(0, stk.shape[1], 10).astype(int)
by = (255 - stk).mean(1).argmax(); bv = (255 - vin).mean(1).argmax()
lanes = ["parental", "MGAT1+ Stk11+", "MGAT1-KO", "Stk11-KO", "MGAT1-KO Stk11-KO", "Stk11-KO + WT cDNA", "Stk11-KO + mut cDNA", "MGAT1-KO Stk11-KO + WT cDNA", "MGAT1-KO Stk11-KO + mut cDNA"]
rows = []
for i in range(9):
    s = 255 - stk[:, edges[i]:edges[i + 1]]; v = 255 - vin[:, edges[i]:edges[i + 1]]
    rows.append(dict(lane=i + 1, sample=lanes[i], stk11=s[by - 12:by + 12].mean() - s[by - 47:by - 27].mean(), vinculin=v[bv - 14:bv + 14].mean() - v[:20].mean()))
b = pd.DataFrame(rows); b["stk11_per_vinculin"] = b.stk11 / b.vinculin; b["relative_to_Stk11_intact_lanes"] = (b.stk11_per_vinculin / b.stk11_per_vinculin[:3].mean()).round(2)
b.round(2).to_csv(OUT + "blot_stk11_densitometry.csv", index=False); print(b.round(2).to_string(index=False))
