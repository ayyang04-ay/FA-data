#!/usr/bin/env python
"""Independent re-analysis of the in vivo pooled CRISPR screen (MC38 +/- Stk11 KO).
Inputs : crispr_invivo_guide_counts.csv.gz, crispr_invivo_ngs_demux.csv.gz
Outputs: tables/invivo_*.csv
Run    : micromamba run -n core python 01_invivo_screen.py
"""
import pandas as pd, numpy as np, re
from scipy import stats
from statsmodels.stats.multitest import multipletests
SRC = "/tmp/world/filesystem/"; OUT = "/tmp/outputs/tables/"
rng = np.random.default_rng(20261101)

df = pd.read_csv(SRC + "crispr_invivo_guide_counts.csv.gz")
demux = pd.read_csv(SRC + "crispr_invivo_ngs_demux.csv.gz")
cols = list(df.columns[3:])
is_ctrl = df.gene_sgrna_id.str.startswith("NegCtrl").values
df["gene"] = np.where(is_ctrl, "NegCtrl", df.gene_symbol)
X = df[cols].astype(float)
cpm = X / X.sum(0) * 1e6

# ---------------------------------------------------------------- 1. sample QC
def gini(x):
    x = np.sort(np.asarray(x, float)); n = len(x)
    return (2 * np.sum(np.arange(1, n + 1) * x) / (n * x.sum())) - (n + 1) / n
qc = pd.DataFrame({"sample": cols})
qc["group"] = qc["sample"].str.replace(r"_[^_]+$", "", regex=True)
qc["total_reads"] = X.sum(0).values
qc["frac_guides_zero"] = (X == 0).mean(0).values
qc["median_count"] = X.median(0).values
qc["gini"] = [gini(X[c]) for c in cols]
qc = qc.merge(demux.rename(columns={"sample_name": "sample"}), on="sample", how="left")
l = np.log2(cpm + 10); C = l.corr()
np.fill_diagonal(C.values, np.nan)
qc["max_r_with_other_sample"] = C.max().values
qc["most_similar_sample"] = C.idxmax().values
qc["flag"] = ""
qc.loc[qc.total_reads < 1e5, "flag"] = "FAILED (no reads) - excluded"
tum = qc["sample"].str.startswith("Group")
qc.loc[tum & (qc.max_r_with_other_sample > 0.95), "flag"] = "DUPLICATE library (r>0.95 with another tumour)"
qc.loc[tum & (qc.frac_guides_zero > 0.3) & (qc.total_reads > 1e5), "flag"] = "low complexity (>30% guides at zero) - kept, sensitivity-tested"
qc.to_csv(OUT + "invivo_sample_qc.csv", index=False)
print(qc[qc.flag != ""][["sample", "ngs_sample_id", "first_10nt_id", "total_reads", "frac_guides_zero", "max_r_with_other_sample", "most_similar_sample", "flag"]].to_string())
print("barcode collisions within a run:", int((demux.groupby(["ngs_sample_id", "first_10nt_id"]).size() > 1).sum()))
print("background x sequencing batch:\n", pd.crosstab(qc["sample"].str.extract(r"_(NTC|STK11)_")[0], qc.ngs_sample_id.str.extract(r"(SG0\d)")[0]))

DROP = ["Group7_STK11_82431",   # 349 reads
        "Group3_NTC_82364"]     # same library as Group3_NTC_82346 (r = 0.99)
samples = [c for c in cols if c not in DROP]
groups = {}
for s in samples: groups.setdefault(re.sub(r"_[^_]+$", "", s), []).append(s)
G = lambda *names: sum([groups[n] for n in names], [])

# ---------------------------------------------- 2. per-tumour log-ratio vs own-background baseline
PS = 10.0
base = {bg: cpm[groups[f"Baseline_{bg}"]].mean(1) for bg in ["NTC", "STK11"]}
plas = cpm[groups["Plasmid"]].mean(1)
LR = {}
for s in samples:
    if s.startswith("Plasmid"): continue
    bg = "NTC" if "_NTC_" in s else "STK11"
    ref = plas if s.startswith("Baseline") else base[bg]
    LR[s] = np.log2((cpm[s] + PS) / (ref + PS))
LR = pd.DataFrame(LR)
LR = LR - LR[is_ctrl].median(0)               # centre every sample on the 400 non-targeting guides
LR.insert(0, "gene", df.gene); LR.insert(1, "guide", df.gene_sgrna_id)

def null_sets(v, n=50000):                     # empirical null: random 4-guide sets of non-targeting guides
    idx = np.array([rng.choice(len(v), 4, replace=False) for _ in range(n)])
    return v[idx].mean(1)

# ---------------------------------------------- 3. gene x group table (LFC vs baseline, z, rank)
rows = []
for g, ss in groups.items():
    if g == "Plasmid": continue
    gm = LR[ss].mean(1)
    gene = gm.groupby(LR.gene).mean()
    nul = null_sets(gm[is_ctrl].values)
    z = (gene - nul.mean()) / nul.std()
    t = pd.DataFrame({"group": g, "n_samples": len(ss), "lfc": gene, "z": z}).drop(index="NegCtrl")
    t["rank_depleted"] = t.z.rank().astype(int); t["n_genes"] = len(t)
    rows.append(t.reset_index())
bygroup = pd.concat(rows)
bygroup.to_csv(OUT + "invivo_gene_by_group.csv", index=False)

markers = ["Mgat1", "Mgat2", "B4galt1", "Cd274", "Jak1", "Jak2", "Stat1", "Ifngr1", "Ifngr2", "Ptpn2", "Adar", "B2m", "H2-K1", "Tap1", "Cd47", "Cflar"]
piv = bygroup[bygroup.gene.isin(markers)].pivot(index="gene", columns="group", values="lfc").loc[markers].round(2)
piv.to_csv(OUT + "invivo_group_inference_markers.csv")
print("\nMarker-gene LFC vs baseline by group (used to infer the unlabelled group key):\n", piv.to_string())

# ---------------------------------------------- 4. Mgat1 by group (per guide, bootstrap CI over tumours)
m = LR[LR.gene == "Mgat1"].set_index("guide").drop(columns="gene")
rows = []
for g, ss in groups.items():
    if g == "Plasmid": continue
    per_t = m[ss].mean(0).values
    bs = [rng.choice(per_t, len(per_t)).mean() for _ in range(5000)]
    b = bygroup[(bygroup.group == g) & (bygroup.gene == "Mgat1")].iloc[0]
    rows.append(dict(group=g, n=len(ss), **{k: round(v, 2) for k, v in m[ss].mean(1).items()}, gene_lfc=round(per_t.mean(), 2),
                     ci95_lo=round(np.percentile(bs, 2.5), 2), ci95_hi=round(np.percentile(bs, 97.5), 2), fold=round(2 ** per_t.mean(), 2),
                     z=round(b.z, 1), rank=f"{b.rank_depleted}/{b.n_genes}"))
mg = pd.DataFrame(rows); mg.to_csv(OUT + "invivo_mgat1_by_group.csv", index=False)
print("\nMgat1 log2 fold change vs baseline by group:\n", mg.to_string())

# ---------------------------------------------- 5. contrasts (all genes) + Mgat1 tumour-level permutation tests
def contrast(A, B, label):
    a = LR[A].values; b = LR[B].values
    d = a.mean(1) - b.mean(1)
    t = d / np.sqrt(a.var(1, ddof=1) / a.shape[1] + b.var(1, ddof=1) / b.shape[1])
    o = pd.DataFrame({"gene": LR.gene, "d": d, "t": t})
    g = o.groupby("gene").agg(delta_lfc=("d", "mean"), t=("t", "mean"), guides_negative=("d", lambda x: int((x < 0).sum())))
    nul = null_sets(o.t[is_ctrl].values)
    g["z"] = (g.t - nul.mean()) / nul.std()
    g["p_emp_depleted"] = [(np.sum(nul <= x) + 1) / (len(nul) + 1) for x in g.t]
    g = g.drop(index="NegCtrl")
    g["fdr_depleted"] = multipletests(g.p_emp_depleted, method="fdr_bh")[1]
    g["rank_depleted"] = g.z.rank().astype(int)
    g.insert(0, "contrast", label)
    return g.sort_values("z")
def perm(A, B, n=20000):
    sa = m[A].mean(0).values; sb = m[B].mean(0).values; obs = sa.mean() - sb.mean()
    allv = np.concatenate([sa, sb]); k = len(sa); c = 0
    for _ in range(n):
        p = rng.permutation(allv); c += abs(p[:k].mean() - p[k:].mean()) >= abs(obs)
    bs = [rng.choice(sa, len(sa)).mean() - rng.choice(sb, len(sb)).mean() for _ in range(5000)]
    return obs, np.percentile(bs, [2.5, 97.5]), (c + 1) / (n + 1), stats.mannwhitneyu(sa, sb).pvalue
CONTRASTS = {
 "STK11: C57BL/6 all arms (G6-8) vs nude (G5)":                (G("Group6_STK11", "Group7_STK11", "Group8_STK11"), G("Group5_STK11")),
 "STK11: C57BL/6 isotype (G6) vs nude (G5)":                   (G("Group6_STK11"), G("Group5_STK11")),
 "STK11: PD-1-blocked (G7+G8) vs isotype (G6)":                (G("Group7_STK11", "Group8_STK11"), G("Group6_STK11")),
 "NTC: C57BL/6 all arms (G2-4) vs nude (G1)":                  (G("Group2_NTC", "Group3_NTC", "Group4_NTC"), G("Group1_NTC")),
 "NTC: PD-1-blocked (G3+G4) vs isotype (G2)":                  (G("Group3_NTC", "Group4_NTC"), G("Group2_NTC")),
 "C57BL/6 all arms: STK11 (G6-8) vs NTC (G2-4)":               (G("Group6_STK11", "Group7_STK11", "Group8_STK11"), G("Group2_NTC", "Group3_NTC", "Group4_NTC")),
 "nude: STK11 (G5) vs NTC (G1)":                               (G("Group5_STK11"), G("Group1_NTC")),
}
rows = []; alltabs = []
for k, (A, B) in CONTRASTS.items():
    g = contrast(A, B, k); alltabs.append(g.reset_index())
    obs, ci, pperm, pmw = perm(A, B); r = g.loc["Mgat1"]
    rows.append(dict(contrast=k, nA=len(A), nB=len(B), mgat1_delta_lfc=round(obs, 2), ci95_lo=round(ci[0], 2), ci95_hi=round(ci[1], 2),
                     perm_p=float(f'{pperm:.2g}'), mannwhitney_p=float(f'{pmw:.2g}'), gene_z_vs_NegCtrl_null=round(r.z, 2), fdr_depleted=float(f'{r.fdr_depleted:.2g}'),
                     rank_depleted=f"{r.rank_depleted}/{len(g)}", guides_negative=f"{r.guides_negative}/4", top5_depleted=", ".join(g.index[:5])))
ct = pd.DataFrame(rows); ct.to_csv(OUT + "invivo_mgat1_contrasts.csv", index=False)
pd.concat(alltabs).to_csv(OUT + "invivo_contrasts_all_genes.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
print("\nMgat1 contrasts:\n", ct.drop(columns="top5_depleted").to_string())
for k in ["C57BL/6 all arms: STK11 (G6-8) vs NTC (G2-4)", "STK11: C57BL/6 all arms (G6-8) vs nude (G5)"]:
    print("\nTop 10 |", k, "\n", pd.concat(alltabs).query("contrast == @k").head(10)[["gene", "delta_lfc", "z", "fdr_depleted", "guides_negative"]].round(3).to_string(index=False))

# interaction: immune dependence in STK11 minus immune dependence in NTC
a1, b1 = CONTRASTS["STK11: C57BL/6 all arms (G6-8) vs nude (G5)"]; a2, b2 = CONTRASTS["NTC: C57BL/6 all arms (G2-4) vs nude (G1)"]
d = (LR[a1].mean(1) - LR[b1].mean(1)) - (LR[a2].mean(1) - LR[b2].mean(1))
se = np.sqrt(sum(LR[s].var(1, ddof=1) / len(s) for s in (a1, b1, a2, b2)))
o = pd.DataFrame({"gene": LR.gene, "d": d, "t": d / se}); gi = o.groupby("gene").agg(delta=("d", "mean"), t=("t", "mean"))
nul = null_sets(o.t[is_ctrl].values); gi["z"] = (gi.t - nul.mean()) / nul.std(); gi = gi.drop(index="NegCtrl").sort_values("z"); gi["rank"] = np.arange(1, len(gi) + 1)
gi.to_csv(OUT + "invivo_interaction_immune_x_stk11.csv")
print("\nInteraction (immune-dependence STK11 minus NTC): Mgat1", gi.loc["Mgat1"].round(2).to_dict(), "| top 6:", list(gi.index[:6]))

# ---------------------------------------------- 6. in vitro arms: Cas9 activity and Mgat1 cell-intrinsic effect
for bg in ["NTC", "STK11"]:
    lr = np.log2((cpm[groups[f"Endpoint_{bg}"]].mean(1) + PS) / (plas + PS)); lr = lr - np.median(lr[is_ctrl])
    gene = lr.groupby(df.gene).mean(); nul = null_sets(lr[is_ctrl].values)
    ess = [g for g in gene.index if re.match(r"^Rpl\d|^Plk1$|^Pcna$|^Kif11$|^Psmb1$", g)]
    print(f"in vitro {bg}: plasmid->endpoint  core-essential median LFC {gene[ess].median():.2f} (n={len(ess)} genes);  Mgat1 {gene['Mgat1']:.2f} (z {(gene['Mgat1']-nul.mean())/nul.std():.1f})")
