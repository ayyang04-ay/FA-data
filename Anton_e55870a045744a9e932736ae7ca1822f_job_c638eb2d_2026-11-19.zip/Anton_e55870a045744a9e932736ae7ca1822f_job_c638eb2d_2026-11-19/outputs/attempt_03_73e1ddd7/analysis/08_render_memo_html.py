#!/usr/bin/env python
"""Render the memo to a single self-contained HTML file (figure embedded). Run: micromamba run -n core python 08_render_memo_html.py"""
import base64, re
from markdown_it import MarkdownIt
md = open("/tmp/outputs/MGAT1_recommendation_memo.md").read()
html = MarkdownIt("commonmark").enable("table").render(md)
img = base64.b64encode(open("/tmp/outputs/figures/evidence_summary.png", "rb").read()).decode()
html = html.replace('src="figures/evidence_summary.png"', f'src="data:image/png;base64,{img}" style="max-width:100%"')
css = """body{font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:1.45;max-width:1180px;margin:28px auto;padding:0 22px;color:#1c1c1c}
h1{font-size:22px}h2{font-size:17px;margin-top:26px;border-bottom:1px solid #ccc;padding-bottom:3px}
table{border-collapse:collapse;width:100%;margin:10px 0;font-size:12.5px}th,td{border:1px solid #c9c9c9;padding:5px 7px;vertical-align:top;text-align:left}
th{background:#f0f0f0}code{background:#f4f4f4;padding:1px 3px;font-size:12px}hr{border:0;border-top:1px solid #ddd;margin:18px 0}"""
open("/tmp/outputs/MGAT1_recommendation_memo.html", "w").write(f"<!doctype html><html><head><meta charset='utf-8'><title>MGAT1 programme - recommendation</title><style>{css}</style></head><body>{html}</body></html>")
print("html written; tables:", len(re.findall("<table", html)))
