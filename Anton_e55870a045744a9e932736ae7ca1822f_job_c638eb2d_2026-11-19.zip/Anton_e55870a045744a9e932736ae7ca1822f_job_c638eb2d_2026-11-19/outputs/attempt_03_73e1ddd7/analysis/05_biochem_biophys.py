#!/usr/bin/env python
"""Independent checks on the compound data.
 (a) digitise the six UDP-Glo dose-response panels (assay_figures.pdf p1) and re-fit 4-parameter curves
 (b) digitise the SPR-Kd vs IC50 scatter (assay_figures.pdf p5)
 (c) SPR stoichiometry sanity check, competition arithmetic, DSF additivity, ligand-efficiency metrics
Inputs : figures/source_panels/assay_figures_p1.png, _p5.png (from 00_extract_pdf_content.py); the four small CSVs
Outputs: tables/biochem_*.csv       Run: micromamba run -n core python 05_biochem_biophys.py
"""
import numpy as np, pandas as pd, math
from PIL import Image
from scipy import ndimage
from scipy.optimize import curve_fit, brentq
from scipy.stats import f as fdist, pearsonr
SRC = "/tmp/world/filesystem/"; PAN = "/tmp/outputs/figures/source_panels/"; OUT = "/tmp/outputs/tables/"
reg = pd.read_csv(SRC + "compound_properties.csv"); print(reg.to_string(index=False))
yy, xx = np.mgrid[-7:8, -7:8]; DISK = (xx ** 2 + yy ** 2) <= 36
def markers(img, box, minsize=80):
    a = np.array(Image.open(img).convert("RGB")).astype(int); dark = a.sum(2) < 330
    sub = np.zeros_like(dark); x0, y0, x1, y1 = box; sub[y0:y1, x0:x1] = dark[y0:y1, x0:x1]
    lab, n = ndimage.label(ndimage.binary_opening(sub, structure=DISK))      # opening removes curves / error bars, keeps filled circles
    return [(np.where(lab == i)[1].mean(), np.where(lab == i)[0].mean(), (lab == i).sum()) for i in range(1, n + 1) if (lab == i).sum() >= minsize]

# ---------------- (a) dose-response panels: axis calibration measured from tick marks (pixels)
PX_PER_DECADE = 101.17
panels = {  # x pixel of first x tick, its log10(uM); y pixel of 100 % and 0 %; plot box
 "ANT-0592": (215.5, -2, 161.5, 529.5, (225, 120, 860, 522)), "ANT-1476": (998.5, -2, 161.5, 529.5, (1008, 120, 1640, 522)),
 "ANT-2118": (1782.5, -2, 161.5, 529.5, (1792, 120, 2430, 540)), "ANT-3105": (215.5, -2, 807.5, 1174.5, (225, 770, 860, 1167)),
 "ANT-3744": (998.5, -2, 807.5, 1174.5, (1008, 770, 1640, 1167)), "ANT-4267": (1782.5, -3, 807.5, 1174.5, (1792, 770, 2430, 1167))}
f4 = lambda lc, top, bottom, lic50, h: bottom + (top - bottom) / (1 + 10 ** ((lc - lic50) * h))
rows, pts_all = [], []
for name, (x0, lx0, y100, y0, box) in panels.items():
    pts = sorted((10 ** (lx0 + (cx - x0) / PX_PER_DECADE), 100 * (y0 - cy) / (y0 - y100)) for cx, cy, _ in markers(PAN + "assay_figures_p1.png", box))
    c = np.array([p[0] for p in pts]); y = np.array([p[1] for p in pts]); lc = np.log10(c)
    pts_all += [dict(compound=name, conc_uM=round(a, 4), activity_pct=round(b, 1)) for a, b in pts]
    ic = float(reg.loc[reg["compound"] == name, "udpglo_ic50_um"].iloc[0])
    p4, cov = curve_fit(f4, lc, y, p0=[100, 5, np.log10(ic), 1], bounds=([80, -20, -4, 0.3], [120, 40, 4, 4]))
    p3, _ = curve_fit(lambda l, t, i, h: f4(l, t, 0, i, h), lc, y, p0=[100, np.log10(ic), 1], bounds=([80, -4, 0.3], [120, 4, 4]))
    rss4 = ((y - f4(lc, *p4)) ** 2).sum(); rss3 = ((y - f4(lc, p3[0], 0, p3[1], p3[2])) ** 2).sum()
    F = (rss3 - rss4) / (rss4 / (len(y) - 4))
    try: absic = 10 ** brentq(lambda x: f4(x, *p4) - 50, -4, 4)
    except ValueError: absic = np.nan
    rows.append(dict(compound=name, n_points=len(y), top_conc_plotted_uM=round(c.max()), registry_ic50_uM=ic, refit_ic50_midpoint_uM=round(10 ** p4[2], 3),
                     refit_conc_at_50pct_activity_uM=round(absic, 3), hill=round(p4[3], 2), fitted_bottom_pct=round(p4[1], 1), bottom_se=round(np.sqrt(cov[1, 1]), 1),
                     mean_activity_3_highest_conc_pct=round(y[-3:].mean(), 1), p_bottom_is_zero_Ftest=float(f"{1 - fdist.cdf(F, 1, len(y) - 4):.2g}"),
                     kinetic_solubility_uM=reg.loc[reg["compound"] == name, "kinetic_solubility_um"].iloc[0]))
dr = pd.DataFrame(rows); dr.to_csv(OUT + "biochem_dose_response_refit.csv", index=False); pd.DataFrame(pts_all).to_csv(OUT + "biochem_dose_response_digitised_points.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
print("\n(a) dose-response re-fits from digitised points:\n", dr.to_string(index=False))

# ---------------- (b) Kd vs IC50 scatter (p5): x: log10 = -2 at px 233, 172.4 px/decade; y: log10 = 3 at px 233.5, 114.6 px/decade
m = markers(PAN + "assay_figures_p5.png", (240, 225, 1100, 800), minsize=150)
sc = pd.DataFrame([dict(ic50_uM=10 ** (-2 + (cx - 233) / 172.4), spr_kd_uM=10 ** (3 - (cy - 233.5) / 114.6), n_merged=max(1, round(a / 225))) for cx, cy, a in sorted(m)])
sc.round(4).to_csv(OUT + "biochem_kd_vs_ic50_digitised.csv", index=False)
w = np.repeat(np.arange(len(sc)), sc.n_merged); r, p = pearsonr(np.log10(sc.ic50_uM.values[w]), np.log10(sc.spr_kd_uM.values[w]))
ratio = (sc.ic50_uM / sc.spr_kd_uM).values[w]
print(f"\n(b) SPR Kd vs IC50: ~{sc.n_merged.sum()} compounds ({len(sc)} resolved markers); log-log Pearson r = {r:.2f}; median IC50/Kd = {np.median(ratio):.1f} (IQR {np.percentile(ratio,25):.1f}-{np.percentile(ratio,75):.1f}); "
      f"IC50 range {sc.ic50_uM.min():.3f}-{sc.ic50_uM.max():.0f} uM")

# ---------------- (c) biophysics arithmetic
comp = pd.read_csv(SRC + "spr_competition.csv"); dsf = pd.read_csv(SRC + "dsf_thermal_shift.csv"); print("\n", comp.to_string(index=False)); print(dsf.to_string(index=False))
kd_udp, kd_cpd = 32.0, 0.4
print(f"(c) if ANT-3744 were UDP-competitive, 5000 uM UDP would raise its apparent Kd {1 + 5000 / kd_udp:.0f}-fold to ~{kd_cpd * (1 + 5000 / kd_udp):.0f} uM; observed 0.2 uM (ratio {0.2 / kd_cpd:.1f}x)")
print(f"    if UDP were displaced by 20 uM ANT-3744, its apparent Kd would rise {1 + 20 / kd_cpd:.0f}-fold to ~{kd_udp * (1 + 20 / kd_cpd):.0f} uM; observed 20 uM (ratio {20 / kd_udp:.2f}x)")
print(f"    DSF: dTm UDP {dsf.delta_tm_c[0]} + ANT-3744 {dsf.delta_tm_c[1]} = {dsf.delta_tm_c[0] + dsf.delta_tm_c[1]} C; observed together {dsf.delta_tm_c[2]} C (additive -> simultaneous binding)")
MW_PROT = 41648 + 1800 + 1000 + 226      # crystallographic construct (entity weight in the CIF) + Avi tag + (GS)7 + biotin, approx.
for lab, ru, mw, obs in [("ANT-3744, ~9000 RU surface", 9000, 419.5, 115), ("UDP, ~9000 RU surface", 9000, 404.2, 8.7 * (31 + 250) / 250), ("ANT-3744 (+UDP), ~3500 RU surface", 3500, 419.5, 33)]:
    th = ru * mw / MW_PROT; print(f"    SPR Rmax {lab}: theoretical 1:1 = {th:.0f} RU; observed ~{obs:.0f} RU ({obs / th:.2f} of theoretical)")
rows = []
for _, x in reg.dropna(subset=["mw"]).iterrows():
    hac = 31 if x["compound"] == "ANT-3744" else round(x.mw / 13.6); pic = -math.log10(x.udpglo_ic50_um * 1e-6)
    rows.append(dict(compound=x["compound"], ic50_uM=x.udpglo_ic50_um, pIC50=round(pic, 2), heavy_atoms=hac, heavy_atoms_source="CIF component" if x["compound"] == "ANT-3744" else "estimated MW/13.6",
                     LE_kcal_per_heavy_atom=round(1.37 * pic / hac, 2), LLE_pIC50_minus_logD=round(pic - x.logd, 1), ic50_over_kinetic_solubility=round(x.udpglo_ic50_um / x.kinetic_solubility_um, 3)))
le = pd.DataFrame(rows); le.to_csv(OUT + "biochem_efficiency_metrics.csv", index=False); print("\n", le.to_string(index=False))
