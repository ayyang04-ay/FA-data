#!/usr/bin/env python
"""Where does ANT-3744 (component C3744) bind on MGAT1, relative to the donor site and catalytic residues?
Inputs : the five coordinate files (no structure factors supplied, so electron density could not be re-examined)
Outputs: tables/structure_*.csv        Run: micromamba run -n core python 04_structures.py
"""
import gemmi, numpy as np, pandas as pd, collections
SRC = "/tmp/world/filesystem/"; OUT = "/tmp/outputs/tables/"
FILES = ["MGAT1_apo", "MGAT1_UDP", "MGAT1_UDP_GlcNAc", "MGAT1_C3744", "MGAT1_C3744_UDP"]
AA = set("ALA ARG ASN ASP CYS GLN GLU GLY HIS ILE LEU LYS MET PHE PRO SER THR TRP TYR VAL".split())
S, B = {}, {}
for f in FILES:
    B[f] = gemmi.cif.read(SRC + f + ".cif").sole_block(); S[f] = gemmi.make_structure_from_block(B[f]); S[f].setup_entities()
xyz = lambda a: np.array([a.pos.x, a.pos.y, a.pos.z])
def residues(st, chain, name=None, num=None):
    return [r for ch in st[0] if ch.name == chain for r in ch if (name is None or r.name == name) and (num is None or r.seqid.num == num)]
def mind(r1, r2): return min(a.pos.dist(b.pos) for a in r1 for b in r2)
def superpose(mob, ref, mc, rc, sel=None):
    ca = lambda st, c: {r.seqid.num: xyz(r["CA"][0]) for ch in st[0] if ch.name == c for r in ch if r.name in AA and r.find_atom("CA", "*")}
    a, b = ca(mob, mc), ca(ref, rc); common = sorted(set(a) & set(b) & (set(sel) if sel else set(a)))
    P = np.array([a[i] for i in common]); Q = np.array([b[i] for i in common]); Pc, Qc = P.mean(0), Q.mean(0)
    U, _, Vt = np.linalg.svd((P - Pc).T @ (Q - Qc)); D = np.diag([1, 1, np.sign(np.linalg.det(Vt.T @ U.T))]); R = Vt.T @ D @ U.T
    dev = np.linalg.norm((P - Pc) @ R.T + Qc - Q, axis=1)
    return R, Pc, Qc, common, dev

# ---- 1. data-quality summary
rows = []
for f in FILES:
    b, st = B[f], S[f]; v = lambda t: (b.find_value(t) or "?").strip("'")
    r = dict(file=f + ".cif", resolution_A=v("_reflns.d_resolution_high"), Rwork=v("_refine.ls_R_factor_R_work"), Rfree=v("_refine.ls_R_factor_R_free"),
             completeness_pct=v("_reflns.percent_possible_obs"), space_group=st.spacegroup_hm, cell_abc=f"{st.cell.a:.1f}/{st.cell.b:.1f}/{st.cell.c:.1f}")
    for c in "AB":
        prot = [x for x in residues(st, c) if x.name in AA]; nums = [x.seqid.num for x in prot]
        gaps = [f"{nums[i]+1}-{nums[i+1]-1}" for i in range(len(nums) - 1) if nums[i + 1] - nums[i] > 1]
        het = [f"{x.name}(B={np.mean([a.b_iso for a in x]):.0f},occ={np.mean([a.occ for a in x]):.2f})" for x in residues(st, c) if x.name not in AA and x.name not in ("HOH", "EDO", "GOL", "PG6")]
        r[f"chain{c}_disordered_residues"] = ";".join(gaps) or "none"; r[f"chain{c}_protein_meanB"] = round(np.mean([a.b_iso for x in prot for a in x]), 1); r[f"chain{c}_ligands"] = " ".join(het) or "-"
    rows.append(r)
q = pd.DataFrame(rows); q.to_csv(OUT + "structure_quality_summary.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30); pd.set_option("display.max_colwidth", 70)
print(q.to_string(index=False))

# ---- 2. ligand contacts (<= 4.0 A, including crystal-symmetry mates)
def contacts(st, resname, cutoff=4.0):
    model = st[0]; ns = gemmi.NeighborSearch(model, st.cell, 6).populate(include_h=False); out = []
    for ch in model:
        for r in ch:
            if r.name != resname: continue
            best = collections.defaultdict(lambda: 99.0)
            for a in r:
                for mk in ns.find_atoms(a.pos, "\0", radius=cutoff):
                    cra = mk.to_cra(model)
                    if cra.residue is r or cra.residue.name == "HOH": continue
                    k = (cra.chain.name, cra.residue.name, cra.residue.seqid.num, mk.image_idx != 0)
                    best[k] = min(best[k], a.pos.dist(mk.pos))
            for (c2, n2, i2, sym), dd in sorted(best.items(), key=lambda kv: (kv[0][3], kv[0][2])):
                out.append(dict(ligand=resname, ligand_chain=ch.name, partner_chain=c2, partner=f"{n2}{i2}", symmetry_mate=sym, min_dist_A=round(dd, 2)))
    return out
rows = []
for f, lig in [("MGAT1_C3744", "C3744"), ("MGAT1_C3744_UDP", "C3744"), ("MGAT1_C3744_UDP", "UDP"), ("MGAT1_UDP", "UDP"), ("MGAT1_UDP_GlcNAc", "UD1")]:
    for c in contacts(S[f], lig): rows.append(dict(file=f, **c))
ct = pd.DataFrame(rows); ct.to_csv(OUT + "structure_ligand_contacts.csv", index=False)
site = lambda f, lig: set(ct[(ct.file == f) & (ct.ligand == lig) & (~ct.symmetry_mate)].partner)
inh = site("MGAT1_C3744_UDP", "C3744") | site("MGAT1_C3744", "C3744"); don = site("MGAT1_UDP_GlcNAc", "UD1") | site("MGAT1_C3744_UDP", "UDP")
key = lambda s: int("".join(ch for ch in s if ch.isdigit()))
print("\nANT-3744 pocket residues (<=4 A, own chain):", sorted(inh, key=key))
print("donor-site residues (UDP / UDP-GlcNAc, <=4 A):", sorted(don - {"MN501", "MN502"}, key=key))
print("residues shared by the two sites:", sorted(inh & don) or "NONE")
print("symmetry-mate contacts of ANT-3744:", sorted(set(ct[(ct.ligand == "C3744") & ct.symmetry_mate].partner)))

# ---- 3. distances from ANT-3744 to the catalytic machinery
ter = S["MGAT1_C3744_UDP"]; rows = []
R, Pc, Qc, common, dev = superpose(S["MGAT1_UDP_GlcNAc"], ter, "A", "A")
ud1 = residues(S["MGAT1_UDP_GlcNAc"], "A", "UD1")[0]
glc = np.array([(xyz(a) - Pc) @ R.T + Qc for a in ud1 if a.name.endswith("'") and a.name != "O2'"])     # GlcNAc atoms, moved into the ternary frame
c1 = [(xyz(a) - Pc) @ R.T + Qc for a in ud1 if a.name == "C1'"][0]
for c in "AB":
    lig = residues(ter, c, "C3744")[0]; L = np.array([xyz(a) for a in lig])
    r = dict(chain=c, to_UDP_A=round(mind(lig, residues(ter, c, "UDP")[0]), 1), to_Mn_A=round(mind(lig, residues(ter, c, "MN")[0]), 1),
             to_Asp289_A=round(mind(lig, residues(ter, c, "ASP", 289)[0]), 1), to_Asp211_A=round(mind(lig, residues(ter, c, "ASP", 211)[0]), 1),
             ligand_meanB=round(np.mean([a.b_iso for a in lig]), 1))
    if c == "A":
        r["to_nearest_GlcNAc_atom_of_UDP-GlcNAc_superposed_A"] = round(np.linalg.norm(L[:, None] - glc[None], axis=2).min(), 1)
        r["to_GlcNAc_anomeric_C1_of_UDP-GlcNAc_superposed_A"] = round(np.linalg.norm(L - c1, axis=1).min(), 1)
    rows.append(r)
dd = pd.DataFrame(rows); dd.to_csv(OUT + "structure_inhibitor_distances.csv", index=False); print("\n", dd.to_string(index=False))

# ---- 4. induced fit: CA shifts of pocket residues vs ligand-free structures; pose reproducibility
pocket = sorted(key(x) for x in inh)
for f in ["MGAT1_apo", "MGAT1_UDP", "MGAT1_UDP_GlcNAc"]:
    R, Pc, Qc, common, dev = superpose(S[f], ter, "B", "A")
    print(f"{f} chain B -> ternary chain A: global CA RMSD {np.sqrt((dev**2).mean()):.2f} A; largest shifts:", {common[i]: round(float(dev[i]), 1) for i in np.argsort(-dev)[:5]})
ref = residues(ter, "A", "C3744")[0]; names = [a.name for a in ref]; Lr = np.array([xyz(a) for a in ref])
for f, c in [("MGAT1_C3744", "A"), ("MGAT1_C3744", "B"), ("MGAT1_C3744_UDP", "B")]:
    R, Pc, Qc, common, dev = superpose(S[f], ter, c, "A", sel=pocket); lg = {a.name: (xyz(a) - Pc) @ R.T + Qc for a in residues(S[f], c, "C3744")[0]}
    print(f"pose reproducibility {f}:{c} vs ternary:A  ligand RMSD {np.sqrt(((np.array([lg[n] for n in names]) - Lr) ** 2).sum(1).mean()):.2f} A")
