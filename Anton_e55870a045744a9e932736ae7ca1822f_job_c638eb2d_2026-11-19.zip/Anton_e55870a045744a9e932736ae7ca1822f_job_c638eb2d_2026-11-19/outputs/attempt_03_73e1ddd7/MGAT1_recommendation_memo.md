# MGAT1 small-molecule programme (Antera Therapeutics) — independent verification and recommendation

**Date:** 1 Nov 2026  **Basis:** the 16 client files only (records compiled 18 Aug 2026). Every number below is taken from a client file or recomputed from one; section 7 maps each number to its source. No outside data are used as evidence; where I rely on general reasoning rather than a client measurement, I say so.

---

## 1. Recommendation

**Do not advance the asset now.** By "advance" I mean committing to in vivo pharmacology and candidate-directed optimisation. Hold ANT-4267 and its series where they are. Release only a small, staged package whose first gate is one question the client can answer with tools it already has: *does the compound do in an intact cell what the knockout does?* If it cannot, stop this series.

**Why, in one paragraph.** The client has established two ends of a chain and nothing in between. (1) Deleting the MGAT1 gene in tumour cells sensitises them to T cells and is selected against in Stk11-knockout tumours — I reproduced both screens from the raw counts and the result is solid. (2) ANT-4267 inhibits a truncated recombinant MGAT1 at 43 nM — also solid. But there is not one measurement of what any compound does to MGAT1 in a cell, and no compound has been in an animal; and three features of the client's own data say that this missing link is the hard part: the compound binds an allosteric pocket 16–24 Å from the catalytic residues and donor site, with no demonstrated mechanism on the native enzyme; its inhibition appears to level off at ~90–92 % in the client's own curves; and the biology looks like it needs near-complete loss of enzyme function. On top of that, complete genetic knockout only roughly halves tumour growth, and the "checkpoint-resistant, STK11-mutant NSCLC" positioning is only partly what the data show.

---

## 2. The case for not advancing

LFC = log2 fold change in guide abundance; negative means cells carrying that knockout were lost. PHA-L and GNA are the client's two lectin read-outs of the glycan change.

**A. The compound has not been shown to work where it matters, and the data predict that this will be hard**

| # | Finding | Key numbers | Confidence |
|---|---|---|---|
| 1 | **No compound has been shown to do anything to MGAT1 in a cell, and none has been dosed to an animal.** The registry has enzyme IC50, SPR, solubility and hepatocyte stability; every phenotype figure is genetic. No lectin shift, no T-cell killing, no permeability, no selectivity, no PK, no mouse-enzyme potency. | 0 cellular-pharmacology or in vivo data points for 8 registered compounds | Fact |
| 2 | **The binding site is allosteric and the inhibition mechanism is unproven.** In the ternary crystal structure ANT-3744 sits in a pocket at the C-terminal end of the protein (residues 388–444) that shares no residue with the donor site. SPR and DSF agree: UDP does not compete. This avoids competing with the nucleotide-sugar (a genuine plus), but inhibition has only been shown for a truncated soluble enzyme acting on a synthetic pentasaccharide. | 23.9 Å to UDP; 22.3 Å to the GlcNAc anomeric carbon of bound UDP-GlcNAc; 16.1 Å to Asp289 (one of the two residues mutated to kill catalysis). Kd 0.4 → 0.2 µM with 5 mM UDP (a competitive binder would shift to ~63 µM). ΔTm +2 / +6 / +8 °C (additive) | High |
| 3 | **Inhibition is incomplete at saturation.** All four potent analogues level off at 8–10 % residual signal and stay there up to more than 1,000-fold above IC50. One weaker analogue reads ~1 % at its top concentration in the same format, so 8–10 % is not obviously the assay floor. | Fitted bottoms 8.0–9.8 % (ANT-1476, -3105, -3744, -4267); "bottom = 0" rejected, p = 0.002 to 4×10⁻⁶. ANT-4267: 9–10 % from 3.7 to 100 µM | Medium (my re-fit of digitised curves) |
| 4 | **The biology appears to need near-total loss of MGAT1 function.** Every positive result is a knockout or a catalytically dead enzyme; nothing shows that partial loss is enough. Knocking out MGAT2 — to my understanding the next enzyme in the same pathway, so its loss truncates N-glycans only partly — does nothing in either screen. | KO: PHA-L signal −97 %, GNA 8–9×. MGAT2: co-culture LFC −0.17 (rank 2,400 of 18,681); in vivo +0.1 to +0.8 in all 8 groups | Medium (inference) |
| 5 | **Single chemical series, characterised through a weaker analogue.** The package documents one weak hit from a ~500,000-compound screen and one series derived from it; the two "acquired" compounds are not real binders. Competition SPR, DSF and both inhibitor structures are on ANT-3744 (0.81 µM), not the lead. Crystal data are human; the efficacy models are mouse. | ANT-0592 IC50 197 µM vs solubility 11.8 µM; ANT-1938 no SPR binding; ANT-2214 non-saturable SPR | Fact |

**B. The biology is real but supports a narrower claim than the one being made**

| # | Finding | Key numbers | Confidence |
|---|---|---|---|
| 6 | **The genetic ceiling is modest.** Complete knockout roughly halves tumour volume in Stk11-KO MC38; no regressions; error bars overlap; n, error-bar type and statistics are not reported. A drug cannot beat the knockout. (The effect is larger, −53 % to −72 %, in the adoptive-transfer study, but that model is undocumented and depends on infused engineered T cells.) | 545 vs 1,085 mm³ (−50 %, day 19); 613 vs 1,135 mm³ (−46 %, day 9 of treatment). For scale, in the human screen MGAT1 loss is about 60 % of the PTPN2 effect (LFC −0.83 vs −1.32) | High for direction, low for precision |
| 7 | **"Overcomes checkpoint resistance" is not what the data show.** MGAT1 loss adds to anti-PD-1; it does not restore sensitivity. PD-1 blockade did not deepen the Mgat1 dependency in the screen. The model itself is blunted rather than resistant: anti-PD-1 alone still cut Stk11-KO tumour volume by 33–49 % across the two studies (75 % in Stk11-intact). | Screen: Mgat1 LFC −2.54 / −2.63 / −2.51 across the three C57BL/6 arms; PD-1-blocked vs isotype Δ −0.03 (p = 0.87). Single-gene: anti-PD-1 −33 % in control vs −34 % in MGAT1-KO tumours; combination 0.35 of control vs 0.36 expected if independent | High |
| 8 | **STK11-selectivity rests on one engineered mouse line.** It is strong there (Mgat1 is rank 1 of 795 genes), but that line is an Stk11-knockout pool of MC38 — to my knowledge colon-derived; the records do not describe it — not a lung or naturally STK11-mutant tumour. In Stk11-intact MC38 the knockout tumours grew *larger*. No human STK11-isogenic comparison exists, and the STK11 genotype of the human lines is not documented, so the human data neither support nor test the STK11 claim. | Stk11-intact: 1,775 vs 1,160 mm³ (+53 %). Human screen: STK11 guides LFC +0.13 (CI −0.17 to +0.38), uninterpretable without the genotype | High |
| 9 | **The effect is not purely T-cell mediated, and as an immune-dependent hit Mgat1 is mid-table.** In the screen, about two-thirds of the dependency (log scale) is already present in the group that behaves as T-cell-deficient, and there is a small cell-intrinsic cost in culture. The extra depletion in immunocompetent mice is real but ranks 36th of 795, behind Jak1, B2m, Ptpn2 and Adar. No single-gene MC38 study is labelled as run in an immunodeficient host. (Against this: in the adoptive-transfer model knockout alone changed little without antigen-specific T cells, 0.85 of control.) | Stk11-KO: nude −1.66 vs C57BL/6 −2.56 (difference −0.89, permutation p ≤ 5×10⁻⁵); in vitro −0.81 vs plasmid | Medium (group identity inferred) |
| 10 | **Only tumour cells ever lost MGAT1.** A systemic drug also hits T cells and host tissue. Glycoproteomics shows the glycan change is proteome-wide. There are no data on T-cell function or tolerability under MGAT1 loss or inhibition. | 910 sites on 524 proteins quantified; Man5 glycoforms up on 60–68 %, sialylated complex glycoforms down on 42–50 %; complex share falls at 93–97 of 105 paired sites | Fact (gap) |

An in vivo study run today could not be interpreted whichever way it came out: a negative result could be exposure, permeability, mechanism, species or biology; a positive result could not be attributed to MGAT1.

---

## 3. What I verified and would stand behind

These are real strengths and are why the call is "hold and gate", not "terminate the target".

- **In vivo pooled screen (re-analysed from raw counts, two independent statistical pipelines).** Cas9 was active in both arms (core-essential genes −3.8 to −3.9 log2). In C57BL/6 tumours Mgat1 is the single most Stk11-selective dependency of 795 genes (ΔLFC −1.90, 95 % CI −2.20 to −1.59; 4/4 guides; limma/fry rank 1, FDR 6×10⁻¹⁶), with B4galt1 second. Within Stk11-KO tumours, Mgat1 ranks 7–10 of 795 in every in vivo group.
- **Genome-wide human co-culture screen (NCI-H1703 + NY-ESO-1 TCR-T).** MGAT1 ranks 19 of 18,681 genes (LFC −0.83, bootstrap CI −1.10 to −0.62; 4/4 guides). Controls behave: CTAG1B and B2M are the top two resistance genes, PTPN2 rank 3 and CFLAR rank 1 for sensitisation.
- **Arrayed confirmation.** Four further guides in two human lines (NCI-H1703, NCI-H1755): relative viability with T cells 0.35–0.38 (MGAT1-KO) vs 0.78–0.91 (control). In an adoptive-transfer model the effect scales with T-cell dose (0.85 → 0.47 → 0.28 of control).
- **Catalysis is the relevant function — an inhibitor is the right modality in principle.** Wild-type cDNA restores PHA-L and T-cell resistance (1.15); D289A and D211A+D289A do neither (0.56, 0.54) despite equal protein expression. In vivo the catalytically dead rescue halves growth relative to wild-type (425 vs 860 mm³).
- **A ready-made pharmacodynamic readout exists.** PHA-L −97 %, GNA 8–9× by flow; matching glycopeptide signature by mass spectrometry (e.g., CD276 N91 sialylated complex glycan −2.3 / −3.2 log2, Man5 +2.4 / +1.9).
- **The chemistry is real on the isolated enzyme.** My re-fits of the plotted curves reproduce the registry IC50s within 2-fold. IC50 tracks SPR Kd across ~25 analogues (r = 0.95, median IC50/Kd 1.8). Four crystallographic copies of ANT-3744 give the same pose (RMSD 0.3–0.6 Å; 2.0 Å resolution, Rfree 0.20–0.21). ANT-4267: LLE 4.8, solubility 96 µM, hepatocyte CLint < 1.35 µl/min/10⁶ cells.

![Evidence summary](figures/evidence_summary.png)

*Figure: one-page summary built only from the re-analysis tables (`figures/evidence_summary.png`).*

---

## 4. What would bring it back — next studies, what each must establish, and the comparisons each must contain

Pass criteria are my proposals, anchored to the client's own knockout benchmarks; the threshold in Gate 1 should be set by the titration described there. Gate 1 needs no new reagents or models: the client already holds the knockout and rescue lines, the lectin read-out and the co-culture assay. A clean pass at Gate 1 would remove points 1–4 of the case above and move the programme straight to Gate 2.

| Gate | Must establish | Comparisons the data must include | Proposed pass criterion |
|---|---|---|---|
| **0. Close the record** (no new experiments) | That the package is complete and correctly labelled | Group key for the eight screen groups; n, error-bar type and statistics for every tumour study; STK11 genotype of NCI-H1703, NCI-H1755, A375, A549; model used in the adoptive-transfer study; the recombinant mutant-enzyme activity data described in the records but not supplied; any compound cell data already in hand | All supplied |
| **1. Cellular pharmacodynamics** (decisive; uses existing lines and assays) | That ANT-4267 reaches MGAT1 in intact human *and* mouse cells and converts the surface glycome to the knockout state, on target, without toxicity. How much MGAT1 activity must be removed for the phenotype | Same experiment, side by side: sgNTC (0 %) and sgMGAT1 (100 %: PHA-L −97 %, GNA 8–9×); compound in sgMGAT1 cells (any further change is off-target); wild-type-rescue over-expressing line (expect right-shift); a weak synthesised analogue as chemotype control (e.g., ANT-2118, 25.6 µM); ANT-3744 alongside the lead; NCI-H1703, NCI-H1755 and MC38; exposure long enough for glycoprotein turnover; viability counter-screen; a graded series (compound concentration-response, and partial restoration of MGAT1 in knockout cells) relating the size of the lectin shift to T-cell sensitisation, to set the PD threshold. In parallel on the enzyme: mode of inhibition against a native acceptor, whether the 8–10 % plateau is real, ANT-4267 co-structure, mouse Mgat1 potency, selectivity against MGAT2 and related transferases | ≥ 90 % loss of PHA-L signal at ≤ 1 µM and ≥ 10-fold below any cytotoxic concentration; no added effect in knockout cells; glycopeptide signature matches knockout |
| **2. Functional phenocopy** | That compound-treated tumour cells are killed by T cells to a degree comparable with knockout, and that T cells tolerate the compound | Client's own competition assay at E:T 0.2–0.4. Benchmarks: sgMGAT1 (ceiling), sgB2M (resistance), sgPTPN2 (rank 3 sensitiser in their screen; guide already in hand), sgMGAT2 (pathway-negative), sgSLC35A1/A2 (stronger glyco nodes — is MGAT1 the best entry point?). Exposure split three ways: tumour pre-treated then washed; compound present throughout; T cells pre-treated alone. T-cell viability, proliferation and killing of control targets; ≥ 3 donors. STK11-null vs STK11-restored isogenic pairs in ≥ 2 human lung lines | ≥ 50 % of the knockout effect at a Gate-1 concentration; T-cell function unchanged; no effect in knockout cells; STK11-dependence shown or the indication claim dropped |
| **3. In vivo: PK/PD first, efficacy second** | An exposure → tumour glycan change → efficacy chain; immune dependence; therapeutic index | Tumour and host (lymphocyte, normal tissue) lectin/glycopeptide PD against plasma exposure over the dosing interval. Efficacy in MC38-sgSTK11 as a 2×2 (vehicle / compound × isotype / anti-PD-1) with a pre-specified interaction test; in-study sgMGAT1 arm (genetic ceiling) and sgMGAT1 + compound (on-target control); Stk11-intact MC38 (watch for the growth acceleration seen with knockout); nude or CD8-depleted hosts; a second, lung-derived STK11-mutant model. Pre-specified n: on the variability drawn in the client's figure, about 17 mice per arm to detect a knockout-sized effect (80 % power) if the bars are SD, about 36 for two-thirds of it, more if they are SEM | Tumour PD at the Gate-1 threshold through the dosing interval at a tolerated dose; significant growth inhibition ≥ two-thirds of the knockout benchmark; no effect in sgMGAT1 tumours; no acceleration in Stk11-intact tumours |

**Stop rule.** If Gate 1 shows no concentration-dependent glycan shift despite confirmed exposure, or a maximal effect well short of knockout, stop this series. The target could be revisited only with different chemical matter.

---

## 5. What I set aside or discounted, and why

| Item | Treatment | Reason |
|---|---|---|
| ANT-0592 (screening hit) potency and Kd | Not used quantitatively | IC50 197 µM is 17× its kinetic solubility (11.8 µM); Kd carries an unexplained "*" flag and also exceeds solubility |
| ANT-1938, ANT-2214 ("acquired") | Discounted as comparators or back-ups | ANT-1938: 40 % inhibition at 100 µM, no SPR binding. ANT-2214: 60 % at 100 µM, non-saturating SPR with no concentration dependence, catechol/hydrazone motif |
| Screen sample Group7_STK11_82431 | Excluded | 349 reads in total |
| Screen sample Group3_NTC_82364 | Excluded | Same library as Group3_NTC_82346 (r = 0.988; next-highest tumour pair 0.76) although logged as a different animal in a different run; effective n for Group 3 is 14 |
| Two low-complexity tumours (82276, 82321) | Kept; conclusions unchanged without them | 45 % and 33 % of guides at zero |
| Screen group labels | Used an inferred key; flagged | Records give no key. Groups 1 and 5 have separate animal-ID blocks and lack adaptive-immunity signatures (nude); Groups 2 and 6 show strong Cd274-guide depletion (PD-1 axis intact, isotype); Groups 3, 4, 7, 8 lose it (PD-1 blocked). The "no PD-1 effect" conclusion does not depend on which C57BL/6 group is which — all three are identical for Mgat1 |
| Animal numbers in the records (30 C57BL/6, 15 nude) | Not reconciled | The file contains 141 tumours in 8 groups of 15–21 |
| Stk11-KO vs Stk11-intact comparisons in the screen | Used, with caveat | Background is confounded with sequencing batch and each arm is one transduction. Plasmid controls sequenced in both batches agree (r ≥ 0.988), and the within-background contrasts do not depend on it |
| Mgat1 guide 3 | Noted, not removed | Much weaker than the other three in every group; the other three agree. Removing it strengthens every conclusion |
| "Opposite" Mgat1 trend under PD-1 blockade in Stk11-intact tumours (Δ +0.61) | Not relied on | p = 0.03 in one analysis, 0.18 in the other |
| Co-culture screen significance calls | Used ranks and bootstrap intervals only | One sample per arm; the non-targeting null is narrow (555 genes pass FDR 5 %) |
| Glycoproteomics magnitudes | Used for direction and breadth, not stoichiometry | No total-proteome normalisation (knockout channels carry 1.5–1.7× more signal); reporter-ion ratio compression; 72 % of assignments rest on one spectrum; some identifications are implausible (nuclear proteins) |
| All tumour-volume numbers | Descriptive only | Read from images (±5 %); n, error-bar type and statistics not given |
| Adoptive-transfer study (phenotype p4) | Supportive only | Cell line, host strain and n are not documented anywhere |
| Stk11 immunoblot (phenotype p6) | Minor caveat on the in vivo rescue | A faint Stk11 band returns in the cDNA-transduced "knockout" pools, more in the two mutant-cDNA lines (≈ 17–18 % of control by my rough densitometry) than the wild-type lines (≈ 0–8 %). The same imbalance exists in the MGAT1-intact pair, which showed no growth difference, so it is unlikely to explain the result; clonal, sequence-verified lines would remove the doubt |
| ANT-3744 SPR stoichiometry | Noted | Response is ~1.4× the 1:1 expectation on the 9,000 RU surface (1.0× on the 3,500 RU surface); UDP reaches only ~12 % of its expectation. Does not change the conclusion because the ternary crystal structure shows co-occupancy directly |
| Which glycoprotein mediates the effect | Not assumed | Not established in the package. PD-L1 and CD276, which the client blotted for, are not hits in its own human screen (LFC −0.14 and +0.16), although CD276 N91 does lose its complex glycan |
| CCLE NY-ESO-1 expression plot (phenotype p9) | Not used | Public dataset, not client-generated |
| Electron density, raw sensorgrams, raw mass spectra | Could not be checked | No structure factors or raw files supplied |
| Record inconsistencies | Listed for the client; none changes a conclusion | Captions of phenotype p1 and p8 appear transposed; potency-assay top concentration is 100 µM in the records but 1,000 µM on five of six plots; "1 mM BSA"; "18.6 nM … (9.3 µM final)"; reaction volumes do not give the stated final concentrations; DSF legend calls ANT-3744 "HTS"; vinculin blotted but not in the antibody list; D211A single mutant listed but never shown; registry IC50 for ANT-3744 (0.814 µM) is 1.4–1.9× my re-fit of the plotted curve; the PDFs' internal creation dates (18 Nov 2026) are later than the stated data cut (1 Nov 2026) |

---

## 6. Questions to put to the client now

1. Has any compound been run in the PHA-L/GNA assay or the co-culture assay? If so, where are the data; if not, why not?
2. What are Groups 1–8, and what is the fourth group in each background?
3. What are n, the error-bar definition and the statistics for each tumour-volume figure?
4. What is the STK11 genotype of NCI-H1703, NCI-H1755, A375 and A549?
5. Is the 8–10 % floor in the enzyme assay background or residual turnover?
6. Does ANT-4267 inhibit mouse Mgat1?

---

## 7. Where each number comes from

Client files are in `/tmp/world/filesystem/`. "Re-analysis" tables are in `outputs/tables/` and are regenerated by the scripts in `outputs/analysis/`. "Read-off" means read from a client figure with pixel-calibrated axes (`tables/figure_readoffs.csv`).

| Number | Client source | Re-analysis output |
|---|---|---|
| 3,580 guides = 795 genes × 4 + 400 non-targeting; 141 tumours + 18 controls | `crispr_invivo_guide_counts.csv.gz`; records §2 | `invivo_sample_qc.csv` |
| Failed sample (349 reads); duplicate pair r = 0.988; low-complexity tumours | same; `crispr_invivo_ngs_demux.csv.gz` | `invivo_sample_qc.csv` |
| Core-essential dropout −3.9 / −3.8 log2; Mgat1 in vitro −0.12 / −0.81 | `crispr_invivo_guide_counts.csv.gz` | `analysis/logs/01_invivo_screen.log` |
| Mgat1 LFC by group: Stk11-KO −1.66 (nude), −2.54 / −2.63 / −2.51; Stk11-intact −0.81, −1.07, −0.57, −0.38; ranks 7–10 and 36–142 of 795 | same | `invivo_mgat1_by_group.csv` |
| Stk11-KO vs intact ΔLFC −1.90 (CI −2.20 to −1.59), rank 1/795; B4galt1 rank 2 | same | `invivo_mgat1_contrasts.csv`, `invivo_contrasts_all_genes.csv` |
| limma/fry cross-check: rank 1/795, FDR 6×10⁻¹⁶; C57BL/6 vs nude FDR 0.004; PD-1 vs isotype P = 0.96 | same | `invivo_mgat1_limma_crosscheck.csv` |
| C57BL/6 vs nude Δ −0.89 (CI −1.27 to −0.51), p ≤ 5×10⁻⁵; PD-1-blocked vs isotype Δ −0.03 (p = 0.87); Stk11-intact Δ +0.15 and +0.61 | same | `invivo_mgat1_contrasts.csv` |
| Mgat2 +0.10 to +0.82 in all groups; Cd274, Stat1 and other marker guides used for the group key | same | `invivo_group_inference_markers.csv` |
| 7,960,054 UMI rows; 77,079 guides; 18,681 genes; 555 genes at FDR 5 % | `coculture_screen_umi_counts.csv.gz` | `analysis/logs/02_coculture_screen.log`, `coculture_gene_scores.csv` |
| MGAT1 −0.83 (CI −1.10 to −0.62), rank 19; MGAT2 −0.17, rank 2,400; SLC35A1 −1.43 (rank 2), SLC35A2 −1.09 (6); PTPN2 −1.32 (3); CFLAR −1.81 (1); B2M +1.42; CTAG1B +1.61; STK11 +0.13; CD274 −0.14; CD276 +0.16 | same | `coculture_selected_genes.csv`, `coculture_gene_scores.csv` |
| Tumour volumes: 1,160 / 1,775; 1,085 / 545; 1,135 / 757 / 613 / 402 mm³ | `phenotype_figures.pdf` p1 | read-off; `figure_readoff_automated_checks.csv`; overlays in `figures/readoff_overlays/` |
| Library-population growth: Stk11-intact 930 / 380 / 95; Stk11-KO 965 / 1,270 / 650 mm³ | `phenotype_figures.pdf` p8 | read-off |
| Adoptive transfer ratios 0.85 / 0.47 / 0.28 | `phenotype_figures.pdf` p4 | read-off |
| In vivo rescue 860 vs 425 mm³ (Stk11-KO + MGAT1-KO); 890 vs 795 (MGAT1 intact) | `phenotype_figures.pdf` p7 | read-off |
| PHA-L 0.03 of control; GNA 8.2× / 8.7× | `phenotype_figures.pdf` p2 | read-off |
| Co-culture viability: control 0.91 / 0.85 / 0.78; MGAT1-KO means 0.37 / 0.35 / 0.38; rescue 0.72 / 1.15 / 0.56 / 0.54 | `phenotype_figures.pdf` p3, p5 | read-off |
| Equal expression of wild-type and mutant MGAT1 | `phenotype_figures.pdf` p11 | visual |
| Residual Stk11 band ≈ 0–8 % (wild-type cDNA lines) vs 17–18 % (mutant cDNA lines) | `phenotype_figures.pdf` p6 | `blot_stk11_densitometry.csv` |
| Sample sizes for future studies (about 17 and 36 per arm) | `phenotype_figures.pdf` p1 read-offs | two-sample t-test power calculation on the drawn bars, assumed SD |
| 2,687 glycopeptides / 910 sites / 524 proteins; Man5 up on 68 % / 60 %; sialylated complex down on 42 % / 50 %; within-site complex fraction 0.37 → 0.12 and 0.36 → 0.10; CD276 N91 | `glycoproteomics_site_quant.xlsx` (IGP_quant) | `glyco_class_summary.csv`, `glyco_site_paired.csv`, `glyco_igp_log2fc.csv` |
| Resolution 1.55–2.01 Å, Rfree 0.18–0.22; distances 23.9 / 25.8 / 16.1 / 22.3 Å; pocket residues; no residue shared with donor site; loop shift 4.5 Å; ligand B-factor 35 vs 60 Å² | the five `.cif` files | `structure_quality_summary.csv`, `structure_inhibitor_distances.csv`, `structure_ligand_contacts.csv` |
| IC50 197 / 0.814 / 0.043 µM; solubility 11.8 / 178 / 96.4 µM; CLint 54.4 / 3.2 / < 1.35; Kd 0.38 and 0.07 (steady-state), 0.03 (kinetic) | `compound_properties.csv` | `biochem_efficiency_metrics.csv` |
| Re-fit IC50s; plateaus 8.0–9.8 %; ANT-2118 0.7 % at 1 mM | `assay_figures.pdf` p1 | `biochem_dose_response_refit.csv`, `biochem_dose_response_digitised_points.csv` |
| Kd 0.4 → 0.2 µM with 5 mM UDP; UDP 32 → 20 µM with 20 µM ANT-3744; ΔTm 2 / 6 / 8 °C; SPR response vs 1:1 expectation | `spr_competition.csv`, `spr_binding.csv`, `dsf_thermal_shift.csv`; `assay_figures.pdf` p2–p4 | `analysis/logs/05_biochem_biophys.log` |
| ~25 analogues, r = 0.95, median IC50/Kd 1.8 | `assay_figures.pdf` p5 | `biochem_kd_vs_ic50_digitised.csv` |
| ANT-1938 40 %, ANT-2214 60 % inhibition at 100 µM; SPR traces; SPR response levels | `assay_figures.pdf` p2, p3 | read-off |
| Construct boundaries, assay conditions, screen design, "approximately 500,000 compounds" | `experimental_records.pdf` §1–7 | — |

To regenerate everything: `outputs/analysis/run_all.sh` (about 3 minutes).
