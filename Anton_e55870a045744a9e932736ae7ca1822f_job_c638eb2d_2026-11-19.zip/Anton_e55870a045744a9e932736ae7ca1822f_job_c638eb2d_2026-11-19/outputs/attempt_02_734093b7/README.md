# MGAT1 programme review: contents of this folder

Start with `MGAT1_recommendation_memo.md` (or the self-contained `MGAT1_recommendation_memo.html`).

| Path | What it is |
|---|---|
| `MGAT1_recommendation_memo.md` / `.html` | Recommendation, supporting case, next-step study specifications, re-entry criteria, items set aside, record issues, evidence ledger |
| `evidence_ledger.csv` | 78 entries: each number quoted in the memo, with client source file and location, how it was obtained, the script and the output table |
| `figures/` | Six figures used in the memo |
| `tables/` | Result tables and the console log of each analysis (`*_analysis_log.txt`) |
| `scripts/` | Analysis code, numbered in run order |
| `extracted_figures/` | Page text and images extracted from the three client PDFs (inputs to the digitisation steps) |

## Re-running the analysis

Inputs are read from `/tmp/world/filesystem`; outputs are written to `/tmp/outputs`.

```
micromamba run -n genomics python scripts/00_extract_pdf_text_and_images.py
micromamba run -n core     python scripts/01_invivo_screen.py
micromamba run -n renv     Rscript scripts/01b_invivo_screen_edgeR_crosscheck.R
micromamba run -n core     python scripts/02_coculture_screen.py
micromamba run -n chem     python scripts/03_glycoproteomics.py
micromamba run -n core     python scripts/04_structures.py
micromamba run -n core     python scripts/05_biochem_biophys.py
micromamba run -n core     python scripts/06_phenotype_figures_digitised.py
micromamba run -n core     python scripts/06b_cell_assay_and_immunoblot_reads.py
micromamba run -n core     python scripts/07_build_evidence_ledger.py
micromamba run -n chem     python scripts/08_render_memo.py
micromamba run -n core     python scripts/09_verify_memo_numbers.py   # asserts the headline numbers against the tables
```

## Things to know before quoting numbers

- The eight tumour groups of the in vivo screen are not defined in the client records. Group identities used here are inferred from control genes (memo section 3.3) and must be confirmed by the client.
- Tumour-growth and cell-assay values were re-read from the client's plots (about ±2–3% reading error); the client supplied no animal numbers, error-bar definitions or statistics.
- Immunoblot densitometry is semi-quantitative.
- The only external reference used is the public human genome sequence, to confirm that the sgRNA sequences in the records target MGAT1.
