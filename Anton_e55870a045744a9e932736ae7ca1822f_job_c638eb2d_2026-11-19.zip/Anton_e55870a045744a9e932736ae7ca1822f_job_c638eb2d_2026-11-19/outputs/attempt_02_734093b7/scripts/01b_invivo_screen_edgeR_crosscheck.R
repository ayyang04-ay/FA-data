# Cross-check of the in vivo screen with a count-based negative-binomial GLM (edgeR quasi-likelihood).
# NB: a mean-based model is sensitive to jackpot clones, which are common in vivo (BCV ~1); the rank/median-based
#     analysis in 01_invivo_screen.py is the primary analysis. This script is a robustness check only.
# Run: micromamba run -n renv Rscript 01b_invivo_screen_edgeR_crosscheck.R
suppressMessages({library(edgeR)})
cnt <- read.csv(gzfile('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz'), check.names=FALSE)
ann <- cnt[,1:3]; m <- as.matrix(cnt[,-(1:3)]); rownames(m) <- ann$gene_sgrna_id
excl <- c('Group7_STK11_82431','Group3_NTC_82276','Group4_NTC_82321','Group3_NTC_82364')
samp <- colnames(m); grp <- sub('_.*','',samp); bg <- sapply(strsplit(samp,'_'), function(x) x[2])
bg[samp %in% c('Plasmid_1','Plasmid_2','Plasmid_3')] <- 'NTC'; bg[samp %in% c('Plasmid_4','Plasmid_5','Plasmid_6')] <- 'STK11'
cond <- ifelse(grp %in% c('Baseline','Endpoint','Plasmid'), paste0(grp,'_',bg), grp)
keep <- !(samp %in% excl); m <- m[,keep]; cond <- factor(cond[keep])
is_ntc <- grepl('^BRDN', ann$gene_symbol)
y <- DGEList(counts=m, group=cond)
yn <- calcNormFactors(DGEList(counts=m[is_ntc,], lib.size=colSums(m)), method='TMMwsp')   # normalise on non-targeting guides
y$samples$norm.factors <- yn$samples$norm.factors
design <- model.matrix(~0+cond); colnames(design) <- levels(cond)
y <- estimateDisp(y, design, robust=TRUE); cat('common BCV:', round(sqrt(y$common.dispersion),2), '\n')
fit <- glmQLFit(y, design, robust=TRUE)
con <- makeContrasts(
  G5_Tdef_vs_baseline = Group5 - Baseline_STK11, G6_iso_vs_baseline = Group6 - Baseline_STK11, G7_vs_baseline = Group7 - Baseline_STK11, G8_vs_baseline = Group8 - Baseline_STK11,
  G1_Tdef_vs_baseline = Group1 - Baseline_NTC, G2_iso_vs_baseline = Group2 - Baseline_NTC, G3_vs_baseline = Group3 - Baseline_NTC, G4_vs_baseline = Group4 - Baseline_NTC,
  STK11_iso_vs_Tdef = Group6 - Group5, STK11_PD1blocked_vs_iso = (Group7+Group8)/2 - Group6,
  NTC_iso_vs_Tdef = Group2 - Group1, NTC_PD1blocked_vs_iso = (Group3+Group4)/2 - Group2,
  BG_iso = (Group6 - Baseline_STK11) - (Group2 - Baseline_NTC),
  BG_PD1blocked = ((Group7+Group8)/2 - Baseline_STK11) - ((Group3+Group4)/2 - Baseline_NTC), levels=design)
idx <- split(seq_len(nrow(m)), ann$gene_symbol); idx <- idx[!grepl('^BRDN', names(idx))]
out <- NULL
for (cn in colnames(con)) {
  tt <- glmQLFTest(fit, contrast=con[,cn])$table
  glfc <- sapply(idx, function(i) mean(tt$logFC[i]))
  set.seed(1); ln <- tt$logFC[is_ntc]; nulll <- replicate(5000, mean(sample(ln,4)))
  mg <- tt[ann$gene_symbol=='Mgat1',]
  out <- rbind(out, data.frame(contrast=cn, Mgat1_guide_logFC=paste(round(mg$logFC,2),collapse=' / '), Mgat1_gene_mean_logFC=round(glfc['Mgat1'],2),
        z_vs_nontargeting_null=round((glfc['Mgat1']-mean(nulll))/sd(nulll),1), rank_of_795=rank(glfc)['Mgat1']))
}
rownames(out) <- NULL; options(width=200); print(out)
write.csv(out, '/tmp/outputs/tables/invivo_mgat1_edgeR_crosscheck.csv', row.names=FALSE)
