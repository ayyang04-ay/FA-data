#!/usr/bin/env python
"""Re-reads the output tables and asserts the headline numbers quoted in the memo. Run after scripts 01-06.
Run: micromamba run -n core python 09_verify_memo_numbers.py"""
import pandas as pd, numpy as np
T = '/tmp/outputs/tables/'; ok = []
def chk(name, got, exp, tol=0.011):
    good = abs(got-exp) <= tol; ok.append(good); print(('OK   ' if good else 'FAIL ')+'%-78s got %-10.4g expected %s'%(name, got, exp))
# co-culture screen
f = pd.read_csv(T+'coculture_focus_genes.csv').set_index('gene')
chk('A3 MGAT1 log2FC', f.loc['MGAT1','lfc_mean'], -0.84); chk('A3 MGAT1 CI low', f.loc['MGAT1','ci95_lo'], -1.12, 0.03); chk('A3 MGAT1 CI high', f.loc['MGAT1','ci95_hi'], -0.63, 0.03)
chk('A3 MGAT1 rank', f.loc['MGAT1','rank_sensitiser'], 23, 0); chk('A6 CTAG1B', f.loc['CTAG1B','lfc_mean'], 1.64); chk('A6 B2M', f.loc['B2M','lfc_mean'], 1.43); chk('A6 CFLAR rank', f.loc['CFLAR','rank_sensitiser'], 1, 0)
chk('A8 MGAT2', f.loc['MGAT2','lfc_mean'], -0.18); chk('A9 STK11', f.loc['STK11','lfc_mean'], 0.12); chk('A9 CD274', f.loc['CD274','lfc_mean'], -0.14)
g = pd.read_csv(T+'coculture_gene_level.csv', index_col=0); chk('A1 genes analysed', len(g), 19114, 0)
top40 = set(g.sort_values('lfc_mean').index[:40]); chk('A7 glyco genes in top 40', len(top40 & {'SLC35A1','GFPT1','ALG2','SLC35A2','UGP2','GALE','MGAT1','UAP1','CMAS','DAD1','MOGS','TMEM165'}), 12, 0)
chk('A10 guides mapped to MGAT1 locus', len(pd.read_csv(T+'guide_identity_check_human_MGAT1.csv')), 8, 0)
# in vivo screen
m = pd.read_csv(T+'invivo_mgat1_by_group.csv').set_index('group')
for k,v in {'G5':-2.10,'G6':-2.92,'G7':-2.76,'G8':-2.60,'G1':-1.24,'G2':-1.12,'G3':-0.61,'G4':-0.29,'vitro_NTC':0.20,'vitro_STK11':-0.29}.items(): chk('D6-D8 Mgat1 median log2FC '+k, m.loc[k,'gene_median_lfc'], v)
for k,v in {'G5':8,'G6':6,'G7':8,'G8':11}.items(): chk('D7 Mgat1 rank '+k, m.loc[k,'rank_of_795'], v, 0)
chk('D7 z G5', m.loc['G5','z_vs_nontargeting_null'], -8.6, 0.11); chk('D7 z G8', m.loc['G8','z_vs_nontargeting_null'], -12.2, 0.11)
c = pd.read_csv(T+'invivo_mgat1_contrasts.csv').set_index('contrast')
chk('D10 G6 minus G5', c.loc['STK11_immunocompetent_iso_vs_Tcell_deficient','mgat1_delta'], -0.82); chk('D10 G7+G8 minus G5', c.loc['STK11_G7G8_vs_Tcell_deficient','mgat1_delta'], -0.55)
chk('D10 NTC G2 minus G1', c.loc['NTC_immunocompetent_iso_vs_Tcell_deficient','mgat1_delta'], 0.12); chk('D10 NTC all minus G1', c.loc['NTC_all_immunocompetent_vs_Tcell_deficient','mgat1_delta'], 0.63)
chk('D11 (G7+G8) minus G6', c.loc['STK11_PD1_blocked_vs_iso','mgat1_delta'], 0.26); chk('D11 p', c.loc['STK11_PD1_blocked_vs_iso','mwu_p'], 0.67)
print('     D11 CI:', c.loc['STK11_PD1_blocked_vs_iso','ci95_boot'], '(memo: -0.34 to 0.50)')
chk('D12 STK11 vs NTC iso', c.loc['STK11_vs_NTC_background_iso','mgat1_delta'], -1.80); chk('D12 rank', c.loc['STK11_vs_NTC_background_iso','rank_of_795'], 1, 0)
s = pd.read_csv(T+'invivo_mgat1_sensitivity.csv'); v = s.STK11_PD1blocked_vs_iso.str.split(' ').str[0].astype(float); chk('D13 sensitivity min', v.min(), 0.11); chk('D13 sensitivity max', v.max(), 0.30)
e = pd.read_csv(T+'invivo_mgat1_edgeR_crosscheck.csv').set_index('contrast'); chk('D14 edgeR G5', e.loc['G5_Tdef_vs_baseline','Mgat1_gene_mean_logFC'], -0.67)
q = pd.read_csv(T+'invivo_sample_qc.csv', index_col=0); chk('D2 excluded samples', q.flag.fillna('').str.startswith('EXCLUDED').sum(), 4, 0); chk('D1 tumour samples', q.group.str.startswith('Group').sum(), 141, 0)
p = pd.read_csv(T+'invivo_top_sample_pair_correlations.csv'); chk('D2 duplicate pair rho', p.spearman_ntc_guide_lfc.iloc[0], 0.98); chk('D2 next highest pair rho', p.spearman_ntc_guide_lfc.iloc[1], 0.29)
mk = pd.read_csv(T+'invivo_group_inference_marker_genes.csv', index_col=0); chk('D4 Cd274 G2', mk.loc['Cd274','G2'], -3.22); chk('D4 Cd274 G6', mk.loc['Cd274','G6'], -0.78); chk('D17 Itgb1 G5', mk.loc['Itgb1','G5'], -2.88)
for f_ in ['replicate_arms_G3_vs_G4','replicate_arms_G7_vs_G8']: chk('D5 genes FDR<0.05 '+f_, (pd.read_csv(T+'invivo_contrast_%s.csv'%f_).fdr_bh<0.05).sum(), 0, 0)
# glycoproteomics
sh = pd.read_csv(T+'glyco_class_share_per_channel.csv', index_col=0); ko = [c for c in sh.columns if 'KO' in c]; nn = [c for c in sh.columns if 'KO' not in c]
chk('C2 Man5 share control (mean)', sh.loc['Man5',nn].mean(), 19.3, 0.3); chk('C2 Man5 share KO (mean)', sh.loc['Man5',ko].mean(), 40.3, 0.3); chk('C2 complex control', sh.loc['complex (HexNAc>=4)',nn].mean(), 6.4, 0.15); chk('C2 complex KO', sh.loc['complex (HexNAc>=4)',ko].mean(), 3.6, 0.15)
cs = pd.read_csv(T+'glyco_class_summary.csv', index_col=0); chk('C3 Man5 median A375', cs.loc['Man5','A375_median_log2fc'], 1.20); chk('C3 complex >2x down H1703', cs.loc['complex (HexNAc>=4)','H1703_n_gt2fold_down'], 113, 0)
# structures
d = pd.read_csv(T+'structure_ANT3744_distances_to_active_site.csv'); chk('F3 to UDP chain A', d.to_UDP_closest_atoms[0], 23.9, 0.06); chk('F3 to Mn', d.to_Mn[0], 25.8, 0.06); chk('F3 to Asp289', d.to_Asp289[0], 16.1, 0.06); chk('F3 to GlcNAc C1', d.to_GlcNAc_C1_anomeric_carbon[0], 22.3, 0.06)
# biochemistry
r = pd.read_csv(T+'biochem_dose_response_refits.csv').set_index('compound')
for k,v in {'ANT-1476':8.6,'ANT-3105':9.0,'ANT-3744':8.5,'ANT-4267':9.1}.items(): chk('G3 plateau '+k, r.loc[k,'bottom_pct'], v, 0.06)
chk('G2 max ratio client/re-fit IC50', (r.client_ic50_uM/r.refit_abs_ic50_uM_bottom0).max(), 1.16, 0.05)
sc = pd.read_csv(T+'biochem_ic50_vs_kd_digitised.csv'); chk('G7 n points', len(sc), 24, 0); chk('G7 median IC50/KD', sc.ic50_over_kd.median(), 1.8, 0.06); chk('G7 IC50>KD count', (sc.ic50_over_kd>1).sum(), 20, 0)
cm = pd.read_csv(T+'biochem_compound_metrics.csv').set_index('compound'); chk('H2 fold vs hit', cm.loc['ANT-4267','fold_more_potent_than_hit'], 4581, 1); chk('H2 LLE ANT-4267', cm.loc['ANT-4267','LLE_pIC50_minus_logD'], 4.77, 0.01)
# digitised endpoints
E = pd.read_csv(T+'digitised_tumour_endpoints.csv'); mean = lambda p,a: E[(E.panel.str.startswith(p))&(E.arm==a)]['mean'].iloc[0]
chk('E3 KO alone', mean('C','sgMGAT1\nIgG2a')/mean('C','NTC\nIgG2a'), 0.55); chk('E3 aPD-1 alone', mean('C','NTC\naPD-1')/mean('C','NTC\nIgG2a'), 0.67); chk('E3 combination', mean('C','sgMGAT1\naPD-1')/mean('C','NTC\nIgG2a'), 0.35)
chk('E3 Bliss expectation', (mean('C','sgMGAT1\nIgG2a')/mean('C','NTC\nIgG2a'))*(mean('C','NTC\naPD-1')/mean('C','NTC\nIgG2a')), 0.37); chk('E1 ratio', mean('A','sgMGAT1')/mean('A','sgNTC'), 1.53); chk('E2 ratio', mean('B','sgMGAT1')/mean('B','sgNTC'), 0.50); chk('E4 ratio', mean('D','D211A\n+D289A')/mean('D','MGAT1\nWT'), 0.49)
print('\n%d of %d checks passed'%(sum(ok), len(ok)))
