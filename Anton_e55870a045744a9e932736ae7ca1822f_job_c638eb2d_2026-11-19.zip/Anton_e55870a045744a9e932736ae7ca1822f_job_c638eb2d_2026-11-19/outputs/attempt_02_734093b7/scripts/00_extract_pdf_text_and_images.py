#!/usr/bin/env python
"""
Extract page text and embedded images from the three client PDFs (needed for the digitisation scripts).
Run: micromamba run -n genomics python 00_extract_pdf_text_and_images.py
"""
import pypdf, os
SRC = '/tmp/world/filesystem/'; OUT = '/tmp/outputs/extracted_figures/'
os.makedirs(OUT, exist_ok=True)
for f in ['experimental_records.pdf','assay_figures.pdf','phenotype_figures.pdf']:
    r = pypdf.PdfReader(SRC+f); base = f.replace('.pdf','')
    with open(OUT+base+'.txt','w') as out:
        for i,p in enumerate(r.pages):
            out.write('--- page %d ---\n%s\n'%(i+1, p.extract_text()))
            for j,im in enumerate(p.images):
                open(OUT+'%s_p%d.png'%(base,i+1),'wb').write(im.data)
    print(f, 'pages', len(r.pages), 'metadata', {k:str(v) for k,v in (r.metadata or {}).items() if k in ('/Title','/CreationDate')})
