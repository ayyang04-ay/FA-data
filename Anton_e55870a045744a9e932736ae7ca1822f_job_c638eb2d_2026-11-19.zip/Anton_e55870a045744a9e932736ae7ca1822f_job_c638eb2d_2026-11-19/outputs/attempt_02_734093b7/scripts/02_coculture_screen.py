#!/usr/bin/env python
"""
Independent re-analysis of the genome-wide T-cell co-culture screen (NCI-H1703 + NY-ESO-1 TCR CD8 T cells, 24 h).
Input  : /tmp/world/filesystem/coculture_screen_umi_counts.csv.gz (one row per UMI per sgRNA; two conditions, one sample each)
Outputs: /tmp/outputs/tables/coculture_*.csv, /tmp/outputs/figures/fig2_coculture_screen.png
Run    : micromamba run -n core python 02_coculture_screen.py
"""
import numpy as np, pandas as pd, matplotlib, re
matplotlib.use('Agg')
import matplotlib.pyplot as plt
SRC = '/tmp/world/filesystem/'; OUT = '/tmp/outputs/tables/'; FIG = '/tmp/outputs/figures/'
A, B = 'tumor_only_untreated', 'MSCV_TCR_high_24hr'
PC = 16
rng = np.random.default_rng(20261101)
d = pd.read_csv(SRC+'coculture_screen_umi_counts.csv.gz')
print('UMI rows %d; sgRNAs %d; gene symbols %d; reads: tumour-only %.2f M, +T cells %.2f M; median reads per UMI %d / %d'%(len(d), d.sgrna_id.nunique(), d.gene_symbol.nunique(), d[A].sum()/1e6, d[B].sum()/1e6, d[A].median(), d[B].median()))
print(d.drop_duplicates('sgrna_id').genetype.value_counts().to_dict())
g = d.groupby('sgrna_id').agg(gene=('gene_symbol','first'), seq=('sgrna_sequence','first'), genetype=('genetype','first'), n_umi=('umi_barcode','size'), a=(A,'sum'), b=(B,'sum'))
neg = g[g.genetype=='NegCtrl']
sf = neg.b.sum()/neg.a.sum()                                  # library-size factor from the 989 non-targeting guides
g['lfc'] = np.log2((g.b/sf+PC)/(g.a+PC))
mu, sd = g[g.genetype=='NegCtrl'].lfc.mean(), g[g.genetype=='NegCtrl'].lfc.std()
g['z'] = (g.lfc-mu)/sd
print('size factor (non-targeting) %.4f; non-targeting guide LFC mean %.3f sd %.3f (n=%d)'%(sf, mu, sd, len(neg)))
G = g[g.genetype.isin(['other','ESG'])].groupby('gene').agg(n_guides=('lfc','size'), lfc_mean=('lfc','mean'), lfc_min=('lfc','min'), lfc_max=('lfc','max'), reads_tumour_only=('a','sum'), reads_T=('b','sum'), n_umi=('n_umi','sum'), zsum=('z','sum'))
G['z_stouffer'] = G.zsum/np.sqrt(G.n_guides); G['rank_sensitiser'] = G.lfc_mean.rank().astype(int)
G = G.drop(columns='zsum').sort_values('lfc_mean'); G.to_csv(OUT+'coculture_gene_level.csv')
pg = np.array([rng.choice(neg.index.map(g.lfc).values, 4, replace=False).mean() for _ in range(200000)])
print('null (4 random non-targeting guides): sd %.3f; most extreme of 200,000 draws %.3f'%(pg.std(), pg.min()))
print('genes analysed: %d'%len(G))
def boot(gene, n=2000):
    m = d[d.gene_symbol==gene]; gs = [x for _,x in m.groupby('sgrna_id')]
    bs = []
    for _ in range(n):
        v = []
        for x in gs:
            i = rng.integers(0,len(x),len(x)); v.append(np.log2((x[B].values[i].sum()/sf+PC)/(x[A].values[i].sum()+PC)))
        bs.append(np.mean(v))
    return np.percentile(bs,[2.5,97.5])
focus = ['MGAT1','CFLAR','SLC35A1','PTPN2','GFPT1','SLC35A2','UGP2','GALE','UAP1','CMAS','MOGS','TMEM165','MGAT2','MAN2A1','MGAT5','B4GALT1','CD274','STK11','B2M','CTAG1B','CTAG1A','IFNGR2','STAT1','TNFRSF1A','JAK1','CD58']
rows = []
for k in focus:
    lo,hi = boot(k); r = G.loc[k]
    rows.append(dict(gene=k, lfc_mean=round(r.lfc_mean,2), ci95_lo=round(lo,2), ci95_hi=round(hi,2), guides_lfc=' / '.join('%.2f'%v for v in g[g.gene==k].lfc), rank_sensitiser=int(r.rank_sensitiser), z=round(r.z_stouffer,1), relative_survival_pct=round(100*2**r.lfc_mean)))
F = pd.DataFrame(rows); F.to_csv(OUT+'coculture_focus_genes.csv', index=False)
pd.set_option('display.width',250); print(F.to_string(index=False))
g[g.gene=='MGAT1'].to_csv(OUT+'coculture_mgat1_guides.csv')
print(g[g.gene=='MGAT1'][['seq','n_umi','a','b','lfc','z']].round(2).to_string())

# ---- representation in the no-T-cell arm (no plasmid reference is supplied, so this is only a hint about in vitro fitness effects)
o = g[g.genetype=='other']; rep = []
for gene in ['MGAT1','STK11']:
    x = g[g.gene==gene]
    rep.append(dict(gene=gene, umis_per_guide=' / '.join(str(v) for v in x.n_umi), umi_percentile_among_targeting_guides=' / '.join('%.0f'%(100*(o.n_umi<v).mean()) for v in x.n_umi),
                    gene_rank_lowest_read_representation=int(o.assign(p=o.a.rank(pct=True)).groupby('gene').p.mean().rank()[gene]), n_genes=o.gene.nunique()))
rep.append(dict(gene='(median guide) essential-gene set / non-targeting / all targeting', umis_per_guide='%d / %d / %d'%(g[g.genetype=='ESG'].n_umi.median(), g[g.genetype=='NegCtrl'].n_umi.median(), o.n_umi.median())))
RP = pd.DataFrame(rep); RP.to_csv(OUT+'coculture_guide_representation_no_Tcell_arm.csv', index=False); print(RP.to_string(index=False))

# ---- guide identity: do the 8 human MGAT1 guides (4 library + 4 validation guides listed in the records) map to the MGAT1 locus?
try:
    import subprocess
    REFFA = '/opt/refdbs/vep/homo_sapiens/116_GRCh38/Homo_sapiens.GRCh38.dna.toplevel.fa.gz'
    fa = subprocess.run(['samtools','faidx',REFFA,'5:180780000-180820000'], capture_output=True, text=True).stdout
    seq = ''.join(fa.split('\n')[1:]).upper()
    rc = lambda s: s[::-1].translate(str.maketrans('ACGT','TGCA'))
    guides = {'records MGAT1_1':'GTTCCGAGAGCTGGCTACCG','records MGAT1_2':'ACTGGAAGGTGACAATACCC','records MGAT1_3':'GCCCGACCTGAGCAGCATTG','records MGAT1_4':'GGCCAGGGAAAAAGTCGGTG'}
    for sid,row in g[g.gene=='MGAT1'].iterrows(): guides['library '+sid] = row.seq
    out = []
    for k,q in guides.items():
        for strand,qq in [('+',q),('-',rc(q))]:
            for mm in re.finditer(qq, seq):
                pam = seq[mm.end():mm.end()+3] if strand=='+' else rc(seq[mm.start()-3:mm.start()])
                out.append(dict(guide=k, sequence=q, chr5_GRCh38_pos=180780000+mm.start(), strand=strand, PAM=pam))
    GI = pd.DataFrame(out); GI.to_csv(OUT+'guide_identity_check_human_MGAT1.csv', index=False); print(GI.to_string(index=False))
except Exception as e:
    print('guide mapping skipped:', e)

# ---- figure 2
Gs = G.copy(); x = np.arange(1,len(Gs)+1); rank = pd.Series(x, index=Gs.index)
fig, axes = plt.subplots(1,2, figsize=(15,6), gridspec_kw=dict(width_ratios=[1.6,1]))
ax = axes[0]; ax.scatter(x, Gs.lfc_mean, s=3, color='0.75', rasterized=True)
ax.axhspan(-3.29*pg.std(), 3.29*pg.std(), color='#fff2cc', zorder=0, label='99.9% null range (4 random non-targeting guides)')
groups = {'MGAT1':(['MGAT1'],'#d7191c',70),
 'other N-glycan / sugar-nucleotide / sialylation genes':(['SLC35A1','GFPT1','ALG2','SLC35A2','UGP2','GALE','UAP1','CMAS','DAD1','MOGS','TMEM165','GNPNAT1','PGM3'],'#fdae61',28),
 'N-glycan branching beyond MGAT1 (not hits)':(['MGAT2','MAN2A1','MAN2A2','MGAT5','MGAT4A','MGAT4B','B4GALT1'],'#2c7bb6',28),
 'known sensitisers':(['CFLAR','PTPN2','TRAF2','ATG9A'],'#7b3294',28),
 'known resistance genes (antigen / MHC-I / IFNg / TNF)':(['CTAG1B','CTAG1A','B2M','TAP1','TAP2','JAK1','JAK2','STAT1','IFNGR1','IFNGR2','TNFRSF1A','CD58','FAS','CASP8'],'#1a9641',28),
 'STK11, CD274':(['STK11','CD274'],'k',28)}
for lab,(gl,cc,s) in groups.items(): ax.scatter(rank[gl], Gs.loc[gl,'lfc_mean'], s=s, color=cc, edgecolor='k', linewidth=0.4, zorder=5, label=lab)
def lab(gene, tx, ty, ha='left', **kw): ax.annotate(gene, (rank[gene], Gs.loc[gene,'lfc_mean']), xytext=(tx,ty), fontsize=8.5, ha=ha, va='center', arrowprops=dict(arrowstyle='-', lw=0.5, color='0.3'), **kw)
lab('MGAT1',2300,-0.66,weight='bold',color='#d7191c'); lab('GALE',4300,-0.76); lab('CMAS',6100,-0.86); lab('SLC35A2',2300,-1.00); lab('GFPT1',4300,-1.12); lab('PTPN2',2300,-1.28); lab('SLC35A1',2300,-1.47); lab('CFLAR',1500,-1.92)
lab('MGAT2',4200,-0.47); lab('CD274',5600,-0.30); lab('MAN2A1',17200,-0.20,'right'); lab('STK11',14800,-0.25,'right')
lab('CTAG1B',17600,1.67,'right'); lab('B2M',17600,1.40,'right'); lab('IFNGR2',16600,1.13,'right'); lab('TNFRSF1A',15600,0.90,'right'); lab('CD58',14600,0.60,'right')
ax.set_xlabel('gene rank (of %s) by mean log2FC'%format(len(Gs),',')); ax.set_ylabel('mean log2FC of 4 sgRNAs:  + NY-ESO-1 TCR-T (24 h)  vs  tumour only'); ax.axhline(0,color='k',lw=0.5); ax.legend(fontsize=7.5, loc='upper left')
mg = F.set_index('gene').loc['MGAT1']
ax.set_title('A. Genome-wide T-cell co-culture screen, NCI-H1703: MGAT1 = rank %d of %s sensitisers\n(log2FC %.2f, bootstrap 95%% CI %.2f to %.2f)'%(mg.rank_sensitiser, format(len(Gs),','), mg.lfc_mean, mg.ci95_lo, mg.ci95_hi), fontsize=10.5)
ax2 = axes[1]; genes = ['CFLAR','SLC35A1','PTPN2','SLC35A2','MGAT1','CMAS','MGAT2','MAN2A1','STK11','CD274','B2M','CTAG1B']
for pos,gene in enumerate(genes):
    v = g[g.gene==gene].lfc.values; cc = '#d7191c' if gene=='MGAT1' else '0.35'
    ax2.scatter([pos]*len(v), v, s=34, color=cc, edgecolor='k', linewidth=0.4, zorder=3); ax2.plot([pos-0.3,pos+0.3],[v.mean()]*2, color=cc, lw=2)
ax2.axhspan(-1.96*sd, 1.96*sd, color='#fff2cc', zorder=0); ax2.axhline(0,color='k',lw=0.5)
ax2.set_xticks(range(len(genes))); ax2.set_xticklabels(genes, rotation=60, ha='right', fontsize=9); ax2.set_ylabel('log2FC per sgRNA')
ax2.set_title('B. Individual sgRNAs (bar = gene mean; band = 95% range\nof 989 non-targeting guides)', fontsize=10.5)
fig.text(0.5,-0.02,'Source: coculture_screen_umi_counts.csv.gz (7.96 M UMI rows, 77,079 sgRNAs; one sample per arm). Counts summed over UMIs per sgRNA; normalised to the 989 non-targeting guides.', ha='center', fontsize=8.5)
fig.tight_layout(); fig.savefig(FIG+'fig2_coculture_screen.png', dpi=170, bbox_inches='tight')
print('Done.')
