#!/usr/bin/env python
"""
Independent re-analysis of the in vivo pooled CRISPR screen (MC38, NTC vs Stk11-KO backgrounds).
Inputs : /tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz, crispr_invivo_ngs_demux.csv.gz
Outputs: /tmp/outputs/tables/invivo_*.csv, /tmp/outputs/figures/fig1_invivo_screen_mgat1.png
Run    : micromamba run -n core python 01_invivo_screen.py
"""
import numpy as np, pandas as pd, matplotlib, zlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from scipy import stats
from statsmodels.stats.multitest import multipletests

SRC = '/tmp/world/filesystem/'; OUT = '/tmp/outputs/tables/'; FIG = '/tmp/outputs/figures/'
PC = 10.0                      # pseudocount (in baseline-CPM units)
rng = np.random.default_rng(20261101)

c = pd.read_csv(SRC+'crispr_invivo_guide_counts.csv.gz')
demux = pd.read_csv(SRC+'crispr_invivo_ngs_demux.csv.gz')
samples = list(c.columns[3:])
is_ntc = c.gene_symbol.str.startswith('BRDN').values
X = c[samples].astype(float)

# ---------------------------------------------------------------- sample annotation
meta = pd.DataFrame(index=samples)
meta['group'] = [s.split('_')[0] for s in samples]
meta['background'] = [s.split('_')[1] for s in samples]
meta.loc[['Plasmid_1','Plasmid_2','Plasmid_3'],'background'] = 'NTC'      # sequenced in run set SG02 with the NTC samples
meta.loc[['Plasmid_4','Plasmid_5','Plasmid_6'],'background'] = 'STK11'    # sequenced in run set SG01 with the STK11 samples
d = demux.set_index('sample_name')
meta['run'] = d.loc[samples,'ngs_sample_id'].values
meta['run_set'] = meta.run.str.extract(r'(SG\d+)')[0].values
meta['barcode10'] = d.loc[samples,'first_10nt_id'].values
meta['animal_id'] = [s.split('_')[-1] if s.startswith('Group') else '' for s in samples]

def gini(x):
    x = np.sort(np.asarray(x,float)); n=len(x); cum=np.cumsum(x); return (n+1-2*np.sum(cum)/cum[-1])/n
meta['total_reads'] = X.sum().values
meta['guides_zero'] = (X==0).sum().values
meta['gini'] = [gini(X[s].values) for s in samples]
meta['top1pct_share'] = [np.sort(X[s].values)[-36:].sum()/X[s].sum() for s in samples]

# ---------------------------------------------------------------- background-identity check
# The NTC and Stk11-KO populations were infected separately, so their pre-implant guide compositions differ slightly. Each tumour should
# carry the composition fingerprint of the population it is labelled with (this also coincides with sequencing run set).
lc0 = np.log2(X/X.sum()*1e6+5)
bn0 = lc0[['Baseline_NTC_b1','Baseline_NTC_b2','Baseline_NTC_b3']].mean(axis=1); bs0 = lc0[['Baseline_STK11_b1','Baseline_STK11_b2','Baseline_STK11_b3']].mean(axis=1)
dvec = bs0-bn0; mid0 = (bs0+bn0)/2; okg = mid0>np.log2(50)
meta['background_fingerprint_r'] = [np.corrcoef((lc0[s]-mid0)[okg], dvec[okg])[0,1] if meta.loc[s,'total_reads']>1e4 else np.nan for s in samples]
tumf = meta[meta.group.str.startswith('Group') & meta.background_fingerprint_r.notna()]
wrong = tumf[((tumf.background=='NTC')&(tumf.background_fingerprint_r>0))|((tumf.background=='STK11')&(tumf.background_fingerprint_r<0))]
print('Background fingerprint (correlation with the Stk11-KO-minus-NTC baseline difference): NTC-labelled tumours %.3f to %.3f; Stk11-KO-labelled %.3f to %.3f; tumours on the wrong side of zero: %s'%(
      tumf[tumf.background=='NTC'].background_fingerprint_r.min(), tumf[tumf.background=='NTC'].background_fingerprint_r.max(), tumf[tumf.background=='STK11'].background_fingerprint_r.min(), tumf[tumf.background=='STK11'].background_fingerprint_r.max(), list(wrong.index)))

# ---------------------------------------------------------------- exclusions
meta['flag'] = ''
meta.loc['Group7_STK11_82431','flag'] = 'EXCLUDED: failed library (349 reads)'
meta.loc['Group3_NTC_82276','flag'] = 'EXCLUDED: bottlenecked (1,595/3,580 guides at zero; Gini 0.92)'
meta.loc['Group4_NTC_82321','flag'] = 'EXCLUDED: bottlenecked (1,181/3,580 guides at zero; Gini 0.88)'
meta.loc['Group3_NTC_82364','flag'] = 'EXCLUDED: duplicate library of Group3_NTC_82346 (Spearman 0.98 on non-targeting guides; sequenced in a different run under a different animal ID)'
meta.loc['Group2_NTC_82360','flag'] = 'kept; immune-gene profile fits the PD-1-blocked arms better than its labelled arm (possible label/treatment discrepancy)'
EXCL = [s for s in samples if meta.loc[s,'flag'].startswith('EXCLUDED')]

# ---------------------------------------------------------------- normalisation and log2 fold-change vs own-background pre-implant baseline
def make_lfc(norm='ntc_median', pc=PC, ref_group='Baseline'):
    lfc = {}; ref = {}
    for bg in ['NTC','STK11']:
        rc = list(meta[(meta.group==ref_group)&(meta.background==bg)].index)
        rcpm = X[rc]/X[rc].sum()*1e6
        r = np.exp(np.log(rcpm+0.5).mean(axis=1)); r = r/r.sum()*1e6
        ref[bg] = r
        for s in meta[(meta.background==bg)].index:
            if meta.loc[s,'total_reads'] < 1e4: continue
            x = X[s]
            if   norm=='ntc_median': sf = np.median(x[is_ntc]/r[is_ntc])          # median-of-ratios on non-targeting guides (robust to jackpot clones)
            elif norm=='total':      sf = x.sum()/1e6
            elif norm=='all_median': sf = np.median(x/r)
            lfc[s] = np.log2((x/sf+pc)/(r+pc))
    out = pd.DataFrame(lfc); out.index = c.gene_sgrna_id
    return out, ref
LFC, REF = make_lfc()
genes = c.gene_symbol.values
LFC.insert(0,'gene',genes)
LFC.to_csv(OUT+'invivo_guide_lfc_per_sample.csv.gz')

# ---------------------------------------------------------------- duplicate / identity check on non-targeting guides
# (clonal drift of non-targeting guides is tumour-specific, so independent tumours should be essentially uncorrelated)
tum = [s for s in LFC.columns if s.startswith('Group')]
C = LFC.loc[is_ntc, tum].corr(method='spearman')
pairs = [(a,b,C.loc[a,b]) for i,a in enumerate(tum) for b in tum[i+1:]]
P = pd.DataFrame(pairs, columns=['a','b','spearman_ntc_guide_lfc']).sort_values('spearman_ntc_guide_lfc', ascending=False)
P.head(20).to_csv(OUT+'invivo_top_sample_pair_correlations.csv', index=False)
print('Top sample-pair correlations on the 400 non-targeting guides (independent tumours should be ~0):')
print(P.head(4).to_string(index=False)); print('median of all %d pairs: %.3f ; maximum excluding the top pair: %.3f'%(len(P), P.spearman_ntc_guide_lfc.median(), P.spearman_ntc_guide_lfc.iloc[1]))
ra, rb = X['Group3_NTC_82346'], X['Group3_NTC_82364']
print('Group3_NTC_82346 vs Group3_NTC_82364 raw counts: Pearson r (log2+1) = %.3f; read-depth ratio %.2f; median per-guide count ratio %.2f; sequenced in runs %s / %s'%(np.corrcoef(np.log2(ra+1),np.log2(rb+1))[0,1], ra.sum()/rb.sum(), np.median((ra+1)/(rb+1)), meta.loc['Group3_NTC_82346','run'], meta.loc['Group3_NTC_82364','run']))


cond = {'vitro_NTC':list(meta[(meta.group=='Endpoint')&(meta.background=='NTC')].index), 'vitro_STK11':list(meta[(meta.group=='Endpoint')&(meta.background=='STK11')].index)}
for i in range(1,9): cond['G%d'%i] = [s for s in meta[meta.group=='Group%d'%i].index if s not in EXCL]
INFERRED = {'G1':'NTC bg; T-cell-deficient host (inferred nude)','G2':'NTC bg; immunocompetent, PD-1 axis intact (inferred C57BL/6 + isotype)','G3':'NTC bg; immunocompetent, PD-1 axis blocked (inferred C57BL/6 + anti-PD-1)','G4':'NTC bg; immunocompetent, PD-1 axis blocked (inferred C57BL/6 + anti-PD-1)',
            'G5':'Stk11-KO bg; T-cell-deficient host (inferred nude)','G6':'Stk11-KO bg; immunocompetent, PD-1 axis intact (inferred C57BL/6 + isotype)','G7':'Stk11-KO bg; immunocompetent, PD-1 axis blocked (inferred C57BL/6 + anti-PD-1)','G8':'Stk11-KO bg; immunocompetent, PD-1 axis blocked (inferred C57BL/6 + anti-PD-1)',
            'vitro_NTC':'NTC bg; in vitro endpoint','vitro_STK11':'Stk11-KO bg; in vitro endpoint'}
meta['inferred_condition'] = [INFERRED.get('G'+g[5:], '') if g.startswith('Group') else '' for g in meta.group]
meta.to_csv(OUT+'invivo_sample_qc.csv')

# ---------------------------------------------------------------- gene-level statistics per group (per-tumour gene score = mean of 4 guides; group = median across tumours)
allS = sum(cond.values(), [])
G = LFC.loc[~is_ntc].groupby('gene')[allS].mean()
ntcv = LFC.loc[is_ntc, allS].values
idx = np.array([rng.choice(ntcv.shape[0], 4, replace=False) for _ in range(5000)])
NULL = pd.DataFrame(ntcv[idx].mean(axis=1), columns=allS)         # 5000 pseudo-genes of 4 random non-targeting guides
rows = {}
for k,cs in cond.items():
    obs = G[cs].median(axis=1); nul = NULL[cs].median(axis=1)
    rows[k+'_median_lfc'] = obs; rows[k+'_z'] = (obs-nul.mean())/nul.std(); rows[k+'_rank'] = obs.rank()
T = pd.DataFrame(rows); T.to_csv(OUT+'invivo_gene_level_by_group.csv')
markers = ['Cd274','Jak2','Ifngr1','Ifngr2','Stat1','Jak1','Ptpn2','Socs1','Adar','B2m','H2-K1','Tap1','Cd47','Cflar','Itgb1','Mgat1','B4galt1','Mgat2']
keys = ['vitro_NTC','G1','G2','G3','G4','vitro_STK11','G5','G6','G7','G8']
MK = T.loc[markers, [k+'_median_lfc' for k in keys]].round(2); MK.columns = keys
MK.to_csv(OUT+'invivo_group_inference_marker_genes.csv')
print('\nMarker genes used to infer group identity (median log2FC vs baseline):'); print(MK.to_string())

# ---------------------------------------------------------------- Mgat1 detail
m = LFC[LFC.gene=='Mgat1'].drop(columns='gene')
act = ['Mgat1_1','Mgat1_2','Mgat1_4']
normc = {}
rowsM = []
for k in keys:
    cs = cond[k]; bg = 'NTC' if k in ('vitro_NTC','G1','G2','G3','G4') else 'STK11'
    pa = m[cs].mean(axis=0).values; pa3 = m.loc[act, cs].mean(axis=0).values
    rb = np.random.default_rng(zlib.crc32(('group'+k).encode()))          # bootstrap stream fixed per group, independent of call order
    bs = [np.median(rb.choice(pa, len(pa))) for _ in range(5000)]
    raw = c.set_index('gene_sgrna_id').loc[act, cs].values
    # typical-tumour representation of each guide relative to its pre-implant baseline (2^median LFC, i.e. median normalised count / baseline)
    remaining = ' / '.join('%.2f'%(2**v) for v in m[cs].median(axis=1))
    dep4 = float((m.loc[act, cs].values < -2).mean()); dep4_ntc = float((LFC.loc[is_ntc, cs].values < -2).mean())
    rowsM.append(dict(group=k, inferred_condition=INFERRED[k], n_tumours=len(cs),
        guide_median_lfc=' / '.join('%.2f'%v for v in m[cs].median(axis=1)),
        gene_median_lfc=round(np.median(pa),2), ci95_boot='%.2f to %.2f'%tuple(np.percentile(bs,[2.5,97.5])),
        z_vs_nontargeting_null=round(T.loc['Mgat1',k+'_z'],1), rank_of_795=int(T.loc['Mgat1',k+'_rank']),
        active3_median_lfc=round(np.median(pa3),2), tumours_with_gene_lfc_below_minus1=int((pa<-1).sum()),
        zero_count_fraction_active_guides='%d/%d'%((raw==0).sum(), raw.size), typical_fraction_of_input_per_guide=remaining, pct_active_guide_obs_gt4x_depleted=round(100*dep4), pct_nontargeting_obs_gt4x_depleted=round(100*dep4_ntc,1)))
M = pd.DataFrame(rowsM); M.to_csv(OUT+'invivo_mgat1_by_group.csv', index=False)
print('\nMgat1 by group:'); print(M.drop(columns='inferred_condition').to_string(index=False))

# ---------------------------------------------------------------- contrasts (tumours are the replicates)
def contrast(name, A, B, genome=True):
    a = G[A]; b = G[B]
    dmed = a.median(axis=1)-b.median(axis=1)
    p = pd.Series([stats.mannwhitneyu(a.loc[g], b.loc[g]).pvalue for g in G.index], index=G.index)
    nd = NULL[A].median(axis=1)-NULL[B].median(axis=1)
    out = pd.DataFrame({'delta_median_lfc':dmed, 'z_vs_null':(dmed-nd.mean())/nd.std(), 'mwu_p':p})
    out['fdr_bh'] = multipletests(out.mwu_p, method='fdr_bh')[1]; out['rank_most_depleted_in_A'] = out.delta_median_lfc.rank()
    out.sort_values('delta_median_lfc').to_csv(OUT+'invivo_contrast_%s.csv'%name)
    # Mgat1 bootstrap CI
    x = G.loc['Mgat1',A].values; y = G.loc['Mgat1',B].values
    rb = np.random.default_rng(zlib.crc32(name.encode()))                  # bootstrap stream fixed per contrast
    bs = [np.median(rb.choice(x,len(x)))-np.median(rb.choice(y,len(y))) for _ in range(5000)]
    x3 = m.loc[act,A].mean(axis=0).values; y3 = m.loc[act,B].mean(axis=0).values
    r = out.loc['Mgat1']
    return dict(contrast=name, nA=len(A), nB=len(B), mgat1_delta=round(r.delta_median_lfc,2), ci95_boot='%.2f to %.2f'%tuple(np.percentile(bs,[2.5,97.5])), mwu_p=float('%.2g'%r.mwu_p),
                rank_of_795=int(r.rank_most_depleted_in_A), active3_delta=round(np.median(x3)-np.median(y3),2), active3_mwu_p=float('%.2g'%stats.mannwhitneyu(x3,y3).pvalue),
                top5_most_depleted_in_A=', '.join(out.sort_values('delta_median_lfc').index[:5]), top5_least=', '.join(out.sort_values('delta_median_lfc').index[-5:][::-1]))
CT = pd.DataFrame([
  contrast('STK11_immunocompetent_iso_vs_Tcell_deficient', cond['G6'], cond['G5']),
  contrast('STK11_all_immunocompetent_vs_Tcell_deficient', cond['G6']+cond['G7']+cond['G8'], cond['G5']),
  contrast('STK11_G7G8_vs_Tcell_deficient', cond['G7']+cond['G8'], cond['G5']),
  contrast('STK11_PD1_blocked_vs_iso', cond['G7']+cond['G8'], cond['G6']),
  contrast('NTC_immunocompetent_iso_vs_Tcell_deficient', cond['G2'], cond['G1']),
  contrast('NTC_all_immunocompetent_vs_Tcell_deficient', cond['G2']+cond['G3']+cond['G4'], cond['G1']),
  contrast('NTC_PD1_blocked_vs_iso', cond['G3']+cond['G4'], cond['G2']),
  contrast('STK11_vs_NTC_background_iso', cond['G6'], cond['G2']),
  contrast('STK11_vs_NTC_background_PD1_blocked', cond['G7']+cond['G8'], cond['G3']+cond['G4']),
  contrast('STK11_vs_NTC_background_Tcell_deficient', cond['G5'], cond['G1']),
  contrast('STK11_vs_NTC_background_all_in_vivo', cond['G5']+cond['G6']+cond['G7']+cond['G8'], cond['G1']+cond['G2']+cond['G3']+cond['G4']),
  contrast('replicate_arms_G7_vs_G8', cond['G7'], cond['G8']),
  contrast('replicate_arms_G3_vs_G4', cond['G3'], cond['G4']),
])
CT.to_csv(OUT+'invivo_mgat1_contrasts.csv', index=False)
pw = []
for a,b in [('G6','G7'),('G6','G8'),('G7','G8'),('G2','G3'),('G2','G4'),('G3','G4')]:
    x = G.loc['Mgat1',cond[a]].values; y = G.loc['Mgat1',cond[b]].values
    pw.append(dict(pair=a+' minus '+b, delta_median_lfc=round(np.median(x)-np.median(y),2), mwu_p=float('%.2g'%stats.mannwhitneyu(x,y).pvalue)))
PW = pd.DataFrame(pw); PW.to_csv(OUT+'invivo_mgat1_pairwise_immunocompetent_arms.csv', index=False)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',70)
print('\nMgat1 contrasts (A minus B; negative = more depleted in A):'); print(CT.to_string(index=False))
print('\nMgat1, pairwise differences among the immunocompetent arms:'); print(PW.to_string(index=False))

# ---------------------------------------------------------------- sensitivity analysis
def sens(label, norm='ntc_median', pc=PC, ref_group='Baseline', excl=EXCL, guides=None):
    L,_ = make_lfc(norm, pc, ref_group)
    g = {i:[s for s in L.columns if s.startswith('Group%d_'%i) and s not in excl] for i in range(1,9)}
    pa = L.loc[guides or ['Mgat1_1','Mgat1_2','Mgat1_3','Mgat1_4']].mean(axis=0)
    med = {i:np.median(pa[g[i]]) for i in g}
    dd = lambda A,B: '%.2f (p=%.2g)'%(np.median(pa[A])-np.median(pa[B]), stats.mannwhitneyu(pa[A],pa[B]).pvalue)
    return dict(analysis=label, **{'G%d'%i: round(med[i],2) for i in range(1,9)}, STK11_iso_vs_Tdef=dd(g[6],g[5]), STK11_PD1blocked_vs_iso=dd(g[7]+g[8],g[6]), NTC_PD1blocked_vs_iso=dd(g[3]+g[4],g[2]), STK11_vs_NTC_iso=dd(g[6],g[2]), STK11_vs_NTC_Tdef=dd(g[5],g[1]))
S = pd.DataFrame([
  sens('primary: NTC-guide median normalisation, pseudocount 10, 4 exclusions'),
  sens('no exclusions other than the failed library', excl=['Group7_STK11_82431']),
  sens('pseudocount 1', pc=1.0), sens('pseudocount 50', pc=50.0),
  sens('total-count normalisation', norm='total'), sens('all-guide median normalisation', norm='all_median'),
  sens('reference = plasmid instead of pre-implant baseline', ref_group='Plasmid'),
  sens('three active guides only (drop Mgat1_3)', guides=act),
  sens('also drop Group2_NTC_82360', excl=EXCL+['Group2_NTC_82360']),
])
S.to_csv(OUT+'invivo_mgat1_sensitivity.csv', index=False)
print('\nSensitivity:'); print(S.to_string(index=False))

# ---------------------------------------------------------------- editing parity between backgrounds (pre-implant dropout vs plasmid)
def lcpm(cols): x = X[cols]/X[cols].sum()*1e6; return np.log2(x+5).mean(axis=1)
dn = lcpm(['Baseline_NTC_b1','Baseline_NTC_b2','Baseline_NTC_b3'])-lcpm(['Plasmid_1','Plasmid_2','Plasmid_3'])
ds = lcpm(['Baseline_STK11_b1','Baseline_STK11_b2','Baseline_STK11_b3'])-lcpm(['Plasmid_4','Plasmid_5','Plasmid_6'])
print('\nPre-implant dropout (baseline vs plasmid), NTC vs Stk11-KO populations: r=%.3f, slope=%.2f; guides >4x depleted: %d (mean %.2f vs %.2f)'%(np.corrcoef(dn,ds)[0,1], np.polyfit(dn,ds,1)[0], (dn<-2).sum(), dn[dn<-2].mean(), ds[dn<-2].mean()))
print('Implantation coverage: 1e5 cells / %d guides = %.0f cells per guide per tumour'%(len(c), 1e5/len(c)))
print('Sequencing-run confound: ', pd.crosstab(meta.background, meta.run_set).to_dict())

# ---------------------------------------------------------------- figure 1
labels = ['in\nvitro','G1\nnude*','G2\niso*','G3\naPD1*','G4\naPD1*','in\nvitro','G5\nnude*','G6\niso*','G7\naPD1*','G8\naPD1*']
hm_genes = ['Cd274','Jak2','Ifngr1','Ifngr2','Stat1','Jak1','Ptpn2','Socs1','Adar','B2m','H2-K1','Tap1','Cd47','Cflar','Mgat1','B4galt1','Mgat2']
Mx = T.loc[hm_genes, [k+'_median_lfc' for k in keys]].values
fig = plt.figure(figsize=(16,7)); gs = GridSpec(1,2, width_ratios=[1.0,1.3], wspace=0.25)
ax = fig.add_subplot(gs[0]); im = ax.imshow(Mx, cmap='RdBu', vmin=-4, vmax=4, aspect='auto')
ax.set_xticks(range(len(keys))); ax.set_xticklabels(labels, fontsize=8); ax.set_yticks(range(len(hm_genes))); ax.set_yticklabels(hm_genes, fontsize=9, style='italic')
for i in range(Mx.shape[0]):
    for j in range(Mx.shape[1]): ax.text(j,i,'%.1f'%Mx[i,j], ha='center', va='center', fontsize=7.5, color='white' if abs(Mx[i,j])>2.4 else 'black')
ax.axvline(4.5,color='k',lw=2); ax.axhline(8.5,color='k',lw=0.8,ls='--'); ax.axhline(13.5,color='k',lw=0.8,ls='--')
ax.text(2,-0.75,'NTC background (Stk11-WT)',ha='center',fontsize=9.5,weight='bold'); ax.text(7,-0.75,'Stk11-KO background',ha='center',fontsize=9.5,weight='bold')
ax.set_title('A. Gene-level median log2FC vs pre-implant baseline\n', fontsize=10.5)
cb = plt.colorbar(im, ax=ax, fraction=0.035, pad=0.02); cb.set_label('median log2FC', fontsize=8)
ax2 = fig.add_subplot(gs[1])
colr = {'vitro_NTC':'#888888','G1':'#e08214','G2':'#4575b4','G3':'#1a9850','G4':'#66bd63','vitro_STK11':'#888888','G5':'#e08214','G6':'#4575b4','G7':'#1a9850','G8':'#66bd63'}
for j,k in enumerate(keys):
    cs = cond[k]; y = G.loc['Mgat1', cs].values
    ax2.scatter(j+rng.uniform(-0.18,0.18,len(y)), y, s=24, color=colr[k], alpha=0.85, edgecolor='k', linewidth=0.3, zorder=3)
    ax2.plot([j-0.3,j+0.3],[np.median(y)]*2, color='k', lw=2.4, zorder=4)
    lo,hi = np.percentile(NULL[cs].median(axis=1),[2.5,97.5]); ax2.fill_between([j-0.38,j+0.38],[lo,lo],[hi,hi], color='0.8', zorder=1)
    ax2.text(j,-5.15,'n=%d'%len(y),ha='center',fontsize=8); ax2.text(j,-5.5,'%.2f'%np.median(y),ha='center',fontsize=8,weight='bold')
ax2.text(9.68,-5.15,'tumours',ha='left',fontsize=8,clip_on=False); ax2.text(9.68,-5.5,'median',ha='left',fontsize=8,weight='bold',clip_on=False)
ax2.axhline(0,color='k',lw=0.6); ax2.axvline(4.5,color='k',lw=2); ax2.set_xticks(range(len(keys))); ax2.set_xticklabels(labels, fontsize=8)
ax2.set_xlim(-0.7,9.6); ax2.set_ylim(-5.8,2.3); ax2.set_ylabel('Mgat1 log2FC vs baseline (per tumour; mean of 4 sgRNAs)')
ax2.set_title('B. Mgat1 depletion per tumour (black bar = group median;\ngrey = 95% null band for the group median, from random sets of 4 non-targeting guides)', fontsize=10.5)
ax2.text(2,1.95,'NTC background (Stk11-WT)',ha='center',fontsize=9.5,weight='bold'); ax2.text(7,1.95,'Stk11-KO background',ha='center',fontsize=9.5,weight='bold')
fig.text(0.5,-0.04,'Rows above the first dashed line: T-cell / IFNg / PD-1-axis genes; middle block: MHC-I and innate-evasion genes; bottom: N-glycan genes.  iso* / aPD1* = C57BL/6 + isotype / + anti-PD-1 (inferred).\n*Group identities are NOT defined in the client records; they are inferred here from the marker genes in panel A (loss of Cd274/Jak2/Ifngr dependence = PD-1 axis blocked; loss of all T-cell/IFNg-axis dependence = T-cell-deficient host)\nand from the animal-ID blocks. The iso*/aPD1* labels could be the other way round; the Mgat1 values in those arms are the same either way. 4 of 141 tumour samples excluded (1 failed, 2 bottlenecked, 1 duplicate). Source: crispr_invivo_guide_counts.csv.gz.', ha='center', fontsize=8.5)
fig.suptitle('In vivo pooled CRISPR screen in MC38 - independent re-analysis', fontsize=12.5, y=1.0)
fig.savefig(FIG+'fig1_invivo_screen_mgat1.png', dpi=170, bbox_inches='tight')
print('\nDone.')
