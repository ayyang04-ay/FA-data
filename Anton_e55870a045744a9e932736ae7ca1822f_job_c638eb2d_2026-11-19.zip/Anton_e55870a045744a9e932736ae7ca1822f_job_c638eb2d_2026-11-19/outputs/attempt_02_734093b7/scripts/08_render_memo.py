#!/usr/bin/env python
"""Insert the evidence ledger into the memo and render a self-contained HTML copy (figures embedded).
Run: micromamba run -n chem python 08_render_memo.py"""
import pandas as pd, markdown, base64, re, os
root = '/tmp/outputs/'
L = pd.read_csv(root+'evidence_ledger.csv').fillna('')
def esc(x): return str(x).replace('|','\\|').replace('\n',' ')
rows = ['| ID | Statement | Value | Client source | How obtained | Script | Output |','|---|---|---|---|---|---|---|']
for _,r in L.iterrows(): rows.append('| %s | %s | %s | %s | %s | %s | %s |'%tuple(esc(r[c]) for c in ['id','statement','value','client_source','how_obtained','script','output']))
md = open(root+'MGAT1_recommendation_memo.md').read()
if 'LEDGER_TABLE_PLACEHOLDER' in md:
    md = md.replace('LEDGER_TABLE_PLACEHOLDER', '\n'.join(rows)); open(root+'MGAT1_recommendation_memo.md','w').write(md)
else:   # refresh an existing ledger table
    a = md.index('## Appendix A. Evidence ledger'); b = md.index('## Appendix B.')
    md = md[:a] + '## Appendix A. Evidence ledger\n\n' + '\n'.join(rows) + '\n\n---\n\n' + md[b:]; open(root+'MGAT1_recommendation_memo.md','w').write(md)
html = markdown.markdown(md, extensions=['tables','sane_lists'])
def embed(m):
    p = root+m.group(1)
    return 'src="data:image/png;base64,%s"'%base64.b64encode(open(p,'rb').read()).decode()
html = re.sub(r'src="(figures/[^"]+)"', embed, html)
css = """body{font-family:Helvetica,Arial,sans-serif;max-width:1100px;margin:30px auto;padding:0 20px;line-height:1.45;color:#1a1a1a;font-size:15px}
h1{font-size:26px}h2{font-size:20px;border-bottom:1px solid #bbb;padding-bottom:4px;margin-top:34px}h3{font-size:16px;margin-top:22px}
table{border-collapse:collapse;width:100%;font-size:13px;margin:12px 0}th,td{border:1px solid #c8c8c8;padding:5px 7px;vertical-align:top;text-align:left}th{background:#f0f0f0}
img{max-width:100%;border:1px solid #ddd;margin-top:10px}code{background:#f4f4f4;padding:1px 4px;font-size:12.5px}hr{border:0;border-top:1px solid #ccc;margin:26px 0}"""
open(root+'MGAT1_recommendation_memo.html','w').write('<!DOCTYPE html><html><head><meta charset="utf-8"><title>MGAT1 programme - independent verification and recommendation</title><style>%s</style></head><body>%s</body></html>'%(css, html))
print('memo words:', len(re.findall(r'\w+', md.split('## Appendix A')[0])), '| html bytes', os.path.getsize(root+'MGAT1_recommendation_memo.html'))
