#!/usr/bin/env python
"""
Biochemistry / biophysics verification:
  (a) digitise the UDP-Glo dose-response curves (assay_figures.pdf p1) and re-fit 4-parameter logistic models
  (b) digitise the IC50-vs-KD scatter (assay_figures.pdf p5)
  (c) SPR / DSF arithmetic (cooperativity with UDP, expected Rmax, additivity of thermal shifts)
  (d) ligand-efficiency metrics from compound_properties.csv
Inputs : /tmp/outputs/extracted_figures/assay_figures_p1.png, _p5.png (from 00_extract_pdf_text_and_images.py); the four CSVs
Outputs: /tmp/outputs/tables/biochem_*.csv, /tmp/outputs/figures/fig3_dose_response_refit.png
Run    : micromamba run -n core python 05_biochem_biophys.py
"""
import numpy as np, pandas as pd, json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from scipy import ndimage as ndi
from scipy.optimize import curve_fit
SRC = '/tmp/world/filesystem/'; IMG = '/tmp/outputs/extracted_figures/'; OUT = '/tmp/outputs/tables/'; FIG = '/tmp/outputs/figures/'
props = pd.read_csv(SRC+'compound_properties.csv'); spr = pd.read_csv(SRC+'spr_binding.csv'); comp = pd.read_csv(SRC+'spr_competition.csv'); dsf = pd.read_csv(SRC+'dsf_thermal_shift.csv')

# ---------------- (a) dose-response digitisation. Axis calibration was read from the tick marks of the image:
# x: decade ticks every 101.17 px starting at x0+3.5 (=0.01 uM; 0.001 uM for ANT-4267); y: 0% at y0+3.5, 3.68 px per 1%.
im = np.array(Image.open(IMG+'assay_figures_p1.png').convert('L')).astype(float); dark = im<128
panels = {'ANT-0592':(212,526,0.01),'ANT-1476':(995,526,0.01),'ANT-2118':(1779,526,0.01),'ANT-3105':(212,1171,0.01),'ANT-3744':(995,1171,0.01),'ANT-4267':(1779,1171,0.001)}
yy,xx = np.mgrid[-7:8,-7:8]; disc = (xx**2+yy**2)<=6.5**2
DR = {}
for name,(x0,y0,xmin) in panels.items():
    sub = dark[y0-440:y0-2, x0+10:x0+640]; lab,n = ndi.label(ndi.binary_erosion(sub, structure=disc)); pts = []
    for i in range(1,n+1):
        ys,xs = np.where(lab==i); cx,cy = xs.mean()+x0+10, ys.mean()+y0-440
        col = dark[y0-440:y0+2, int(round(cx))-1:int(round(cx))+2].all(axis=1); idx = np.where(col)[0]+y0-440
        segs = np.split(idx, np.where(np.diff(idx)>1)[0]+1); top = bot = cy
        for s in segs:
            if len(s) and s[0]<=cy<=s[-1]: top,bot = s[0],s[-1]
        pts.append((xmin*10**((cx-(x0+3.5))/101.17), (y0+3.5-cy)/3.68, (cy-top)/3.68, (bot-cy)/3.68))
    DR[name] = sorted(pts)
DR['ANT-2118'].append((1000.0, 0.7, 2.0, 2.0))      # the 1000 uM point sits on the x-axis and is not picked up by the blob detector; read by eye
rows = [dict(compound=k, conc_uM=round(p[0],4), activity_pct=round(p[1],1), err_up=round(p[2],1), err_down=round(p[3],1)) for k,v in DR.items() for p in v]
pd.DataFrame(rows).to_csv(OUT+'biochem_dose_response_digitised.csv', index=False)
f4 = lambda lc,top,bot,lic,h: bot+(top-bot)/(1+10**((lc-lic)*h))
csv_ic50 = props.set_index('compound').udpglo_ic50_um.to_dict(); sol = props.set_index('compound').kinetic_solubility_um.dropna().to_dict(); kd = props.set_index('compound').spr_steady_state_kd_um.dropna().to_dict()
fits = []
for k,v in DR.items():
    c = np.array([p[0] for p in v]); a = np.array([p[1] for p in v]); lc = np.log10(c)
    p1,cov1 = curve_fit(lambda l,bot,lic,h: f4(l,100,bot,lic,h), lc, a, p0=[5,np.log10(csv_ic50[k]),1], maxfev=20000); se1 = np.sqrt(np.diag(cov1))
    p0,_ = curve_fit(lambda l,lic,h: f4(l,100,0,lic,h), lc, a, p0=[np.log10(csv_ic50[k]),1], maxfev=20000)
    fits.append(dict(compound=k, client_ic50_uM=csv_ic50[k], refit_abs_ic50_uM_bottom0=round(10**p0[0],3), refit_midpoint_uM_bottom_free=round(10**p1[1],3), hill=round(p1[2],2), bottom_pct=round(p1[0],1), bottom_se=round(se1[0],1),
                     lowest_observed_activity_pct=round(a.min(),1), top_conc_plotted_uM=round(c.max()), kinetic_solubility_uM=sol.get(k,np.nan), n_points_above_solubility=int((c>sol[k]).sum()) if k in sol else np.nan))
F = pd.DataFrame(fits); F.to_csv(OUT+'biochem_dose_response_refits.csv', index=False); pd.set_option('display.width',250); print(F.to_string(index=False))

# ---------------- (b) IC50 vs KD scatter (p5): x decades 172.3 px from x=233 (0.01 uM); y decades 114.7 px from y=806.5 (0.01 uM)
im5 = np.array(Image.open(IMG+'assay_figures_p5.png').convert('L')).astype(float); d5 = im5<110; d5[:, :240] = False; d5[800:, :] = False; d5[:215, :] = False
y8,x8 = np.mgrid[-8:9,-8:9]; lab,n = ndi.label(ndi.binary_erosion(d5, structure=(x8**2+y8**2)<=36)); sc = []
for i in range(1,n+1):
    ys,xs = np.where(lab==i); sc.append((0.01*10**((xs.mean()-233)/172.3), 0.01*10**((806.5-ys.mean())/114.7)))
SC = pd.DataFrame(sorted(sc), columns=['ic50_uM','spr_kd_uM']); SC['ic50_over_kd'] = SC.ic50_uM/SC.spr_kd_uM; SC.round(3).to_csv(OUT+'biochem_ic50_vs_kd_digitised.csv', index=False)
print('\nIC50-vs-KD scatter: %d resolved points; log-log Pearson r=%.2f; median IC50/KD=%.1f (IQR %.1f-%.1f); IC50>KD for %d/%d'%(len(SC), np.corrcoef(np.log10(SC.ic50_uM),np.log10(SC.spr_kd_uM))[0,1], SC.ic50_over_kd.median(), SC.ic50_over_kd.quantile(.25), SC.ic50_over_kd.quantile(.75), (SC.ic50_over_kd>1).sum(), len(SC)))

# ---------------- (c) SPR / DSF arithmetic
print('\nSPR (spr_binding.csv / spr_competition.csv):'); print(comp.to_string(index=False))
a_udp = comp[(comp.analyte=='UDP')&comp.co_incubated_species.notna()].kd_um.iloc[0]/comp[(comp.analyte=='UDP')&comp.co_incubated_species.isna()].kd_um.iloc[0]
a_cpd = comp[(comp.analyte=='ANT-3744')&comp.co_incubated_species.notna()].kd_um.iloc[0]/comp[(comp.analyte=='ANT-3744')&comp.co_incubated_species.isna()].kd_um.iloc[0]
print('KD ratio with/without partner: UDP %.2f (with 20 uM ANT-3744 = %.0fx its KD); ANT-3744 %.2f (with 5 mM UDP = %.0fx its KD) -> binding is not competitive; mild positive cooperativity'%(a_udp, 20/0.4, a_cpd, 5000/32))
mw_prot = 41648 + 2900   # crystallographic construct (CIF entity weight) + approx. Avi tag and (GS)7 linker of the SPR construct
for lab_,ru,mw,obs in [('ANT-3744, ~9000 RU surface',9000,419.5,115),('ANT-3744 in 5 mM UDP, ~3500 RU surface',3500,419.5,33),('UDP, ~9000 RU surface (level for this run not stated)',9000,404.2,10)]:
    print('  expected Rmax for 1:1 binding, %s: %.0f RU; observed plateau ~%d RU (read from assay_figures.pdf p2/p3) -> %.0f%%'%(lab_, ru*mw/mw_prot, obs, 100*obs/(ru*mw/mw_prot)))
print('\nDSF (dsf_thermal_shift.csv):'); print(dsf.to_string(index=False)); print('sum of single-ligand shifts = %d C; observed with both = %d C'%(dsf.delta_tm_c.iloc[0]+dsf.delta_tm_c.iloc[1], dsf.delta_tm_c.iloc[2]))

# ---------------- (d) efficiency metrics
P = props.copy(); P['pIC50'] = -np.log10(P.udpglo_ic50_um*1e-6); hac = {'ANT-3744':31}
P['LLE_pIC50_minus_logD'] = P.pIC50-P.logd; P['heavy_atoms'] = P.compound.map(hac); P['LE_kcal_per_heavy_atom'] = 1.37*P.pIC50/P.heavy_atoms
P['fold_more_potent_than_hit'] = P.udpglo_ic50_um[P.compound=='ANT-0592'].iloc[0]/P.udpglo_ic50_um
P['ic50_over_solubility'] = P.udpglo_ic50_um/P.kinetic_solubility_um
P.round(3).to_csv(OUT+'biochem_compound_metrics.csv', index=False); print('\n', P[['compound','origin','mw','logd','tpsa','udpglo_ic50_um','ic50_qualifier','spr_steady_state_kd_um','spr_kinetic_kd_um','kinetic_solubility_um','hepatocyte_clint_ul_min_per_1e6_cells','pIC50','LLE_pIC50_minus_logD','LE_kcal_per_heavy_atom','fold_more_potent_than_hit','ic50_over_solubility']].round(2).to_string(index=False))

# ---------------- figure 3
fig, axes = plt.subplots(2,3, figsize=(15,8.2), sharey=True); order = ['ANT-0592','ANT-2118','ANT-1476','ANT-3105','ANT-3744','ANT-4267']; Fi = F.set_index('compound')
for ax,k in zip(axes.ravel(), order):
    v = DR[k]; c = np.array([p[0] for p in v]); a = np.array([p[1] for p in v]); eu = np.array([p[2] for p in v]); ed = np.array([p[3] for p in v]); r = Fi.loc[k]
    ax.errorbar(c, a, yerr=[ed,eu], fmt='o', color='k', ms=5, capsize=2, lw=0.8, label='digitised from assay_figures.pdf p1')
    xs = np.logspace(np.log10(c.min())-0.3, np.log10(c.max())+0.3, 200); ax.plot(xs, f4(np.log10(xs),100,r.bottom_pct,np.log10(r.refit_midpoint_uM_bottom_free),r.hill), color='#d7191c', lw=1.5, label='re-fit (top=100, bottom free)')
    if r.bottom_se<3:
        ax.axhline(r.bottom_pct, color='#d7191c', ls=':', lw=1); ax.text(xs.min()*1.2, r.bottom_pct-7.5, 'plateau: %.1f%% (+/-%.1f) residual activity'%(r.bottom_pct, r.bottom_se), color='#d7191c', fontsize=8.5)
    if k in sol:
        left = k=='ANT-0592'; ax.axvline(sol[k], color='#2c7bb6', ls='--', lw=1.2); ax.text(sol[k]*(1.12 if left else 0.88), 114, 'kinetic solubility\n%.4g uM'%sol[k], color='#2c7bb6', fontsize=8, va='top', ha='left' if left else 'right')
    ax.set_xscale('log'); ax.set_ylim(-8,118); ax.axhline(0,color='k',lw=0.4); ax.axhline(50,color='0.7',lw=0.5)
    txt = 'client IC50 (CSV): %s uM\nre-fit: abs. IC50 %.3g / midpoint %.3g uM\nHill %.2f'%(r.client_ic50_uM, r.refit_abs_ic50_uM_bottom0, r.refit_midpoint_uM_bottom_free, r.hill)
    if k in kd: txt += '\nSPR KD %.3g uM'%kd[k]
    weak = k in ('ANT-0592','ANT-2118'); ax.text(0.03 if weak else 0.97, 0.46 if weak else 0.62, txt, transform=ax.transAxes, ha='left' if weak else 'right', va='top', fontsize=8.5, bbox=dict(fc='white', ec='0.7', lw=0.5))
    ax.set_title(k+('  (HTS hit, purchased)' if k=='ANT-0592' else ''), fontsize=11, weight='bold'); ax.set_xlabel('concentration (uM) - as plotted by client')
for ax in axes[:,0]: ax.set_ylabel('MGAT1 activity (% of control)')
axes[0,0].legend(fontsize=7.5, loc='lower left')
fig.suptitle('UDP-Glo dose-response: digitised client curves with independent 4-parameter re-fits', fontsize=12.5)
fig.text(0.5,0.005,'Note: the records state a top concentration of 100 uM (experimental_records.pdf s6.3); five of six curves are plotted to 1000 uM. Values re-read from the figure (+/-1-2% digitisation error; error bars smaller than the symbol cannot be read).\nAll four sub-uM/low-uM analogues level off at 8-10% residual activity; the package contains no no-enzyme baseline, so assay floor vs true residual turnover cannot be distinguished.', ha='center', fontsize=8.5)
fig.tight_layout(rect=[0,0.04,1,0.97]); fig.savefig(FIG+'fig3_dose_response_refit.png', dpi=170, bbox_inches='tight'); print('Done.')
