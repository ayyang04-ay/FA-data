#!/usr/bin/env python
"""
Re-analysis of the TMT glycoproteomics workbook (A375 and NCI-H1703, MGAT1-KO population vs non-targeting, n=4 each).
Input  : /tmp/world/filesystem/glycoproteomics_site_quant.xlsx (sheets Site_quant, IGP_quant, IGP_Pep_quant)
Outputs: /tmp/outputs/tables/glyco_*.csv, /tmp/outputs/figures/fig5_glycoproteomics.png
Run    : micromamba run -n chem python 03_glycoproteomics.py
"""
import numpy as np, pandas as pd, re, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
SRC = '/tmp/world/filesystem/glycoproteomics_site_quant.xlsx'; OUT = '/tmp/outputs/tables/'; FIG = '/tmp/outputs/figures/'
x = pd.ExcelFile(SRC); site = x.parse('Site_quant'); igp = x.parse('IGP_quant'); pep = x.parse('IGP_Pep_quant')
ch = [c for c in igp.columns if c.startswith('Intensity ')]; short = [c.replace('Intensity ','') for c in ch]
print('IGP rows %d; sites %d; proteins %d; distinct compositions %d; PSM-level rows %d'%(len(igp), igp.groupby(['Protein accession','Position']).ngroups, igp['Protein accession'].nunique(), igp['Observed Modification'].nunique(), len(pep)))
# internal consistency of the three sheets
s2 = igp.groupby(['Protein accession','Position'])[ch].sum(); s1 = site.set_index(['Protein accession','Position'])[ch]
r = (s1/s2.loc[s1.index]).values; print('Site_quant / sum(IGP_quant): min %.4f max %.4f'%(np.nanmin(r), np.nanmax(r)))
def parse(s):
    dct = dict(HexNAc=0,Hex=0,Fuc=0,NeuAc=0,NeuGc=0,Phospho=0,Sulfo=0)
    for m in re.finditer(r'([A-Za-z]+)\((\d+)\)', s): dct[m.group(1)] = dct.get(m.group(1),0)+int(m.group(2))
    return dct
comp = igp['Observed Modification'].apply(parse).apply(pd.Series).fillna(0).astype(int); igp = pd.concat([igp, comp], axis=1)
def cls(r):
    n,h,f = r.HexNAc, r.Hex, r.Fuc
    if n<=1: return 'truncated (HexNAc<=1)'
    if n==2:
        if h==0: return 'truncated (HexNAc2)'
        if r.Phospho>0: return 'oligomannose-P'
        if h<=4: return 'paucimannose+Fuc' if f>0 else 'Man1-4'
        if f>0: return 'Man5+ with Fuc'
        if h==5: return 'Man5'
        if h<=9: return 'Man6-9'
        return 'Man10+ (Glc)'
    if n==3: return 'hybrid (HexNAc3)'
    return 'complex (HexNAc>=4)'
igp['glycan_class'] = igp.apply(cls, axis=1)
L = np.log2(igp[ch].replace(0,np.nan))
for line, ko, n in [('A375',['Intensity AM_KO%d'%i for i in range(1,5)], ['Intensity AM_N%d'%i for i in range(1,5)]), ('H1703',['Intensity NH_M_KO%d'%i for i in range(1,5)], ['Intensity NH_N%d'%i for i in range(1,5)])]:
    igp['log2fc_'+line] = L[ko].mean(axis=1)-L[n].mean(axis=1)
    igp['p_'+line] = stats.ttest_ind(L[ko], L[n], axis=1, nan_policy='omit').pvalue
igp.drop(columns=['Protein description']).to_csv(OUT+'glyco_igp_annotated.csv.gz', index=False)
S = igp.groupby('glycan_class').agg(n_glycopeptides=('log2fc_A375','size'), A375_median_log2fc=('log2fc_A375','median'), H1703_median_log2fc=('log2fc_H1703','median'),
        A375_n_gt2fold_down=('log2fc_A375', lambda v:(v<-1).sum()), A375_n_gt2fold_up=('log2fc_A375', lambda v:(v>1).sum()),
        H1703_n_gt2fold_down=('log2fc_H1703', lambda v:(v<-1).sum()), H1703_n_gt2fold_up=('log2fc_H1703', lambda v:(v>1).sum())).round(2)
S.to_csv(OUT+'glyco_class_summary.csv'); pd.set_option('display.width',250); print(S.to_string())
frac = igp.groupby('glycan_class')[ch].sum(); frac = (frac/frac.sum()*100); frac.columns = short; frac.round(1).to_csv(OUT+'glyco_class_share_per_channel.csv')
print((frac.loc[['Man5','Man6-9','complex (HexNAc>=4)','hybrid (HexNAc3)','paucimannose+Fuc']]).round(1).to_string())
Lc = L.copy(); Lc.columns = short
for line, cols in [('A375',[c for c in short if c.startswith('AM')]), ('H1703',[c for c in short if c.startswith('NH')])]:
    cc = Lc[cols].corr(); ko = [c for c in cols if 'KO' in c]; nn = [c for c in cols if 'KO' not in c]
    within = [cc.loc[a,b] for g in (ko,nn) for i,a in enumerate(g) for b in g[i+1:]]; between = [cc.loc[a,b] for a in ko for b in nn]
    print('%s channel correlations (log2 intensity): within-condition %.3f-%.3f; KO vs N %.3f-%.3f'%(line, min(within), max(within), min(between), max(between)))
print('A375 vs H1703 log2FC correlation across glycopeptides: r=%.2f'%igp[['log2fc_A375','log2fc_H1703']].corr().iloc[0,1])
print('largest decreases: A375 %.2f, H1703 %.2f'%(igp.log2fc_A375.min(), igp.log2fc_H1703.min()))
cols = ['Gene name','Position','Observed Modification','glycan_class','log2fc_A375','p_A375','log2fc_H1703','p_H1703']
ex = igp[igp['Gene name'].isin(['CD276','LAMP1','ITGB1','ITGA3','SLC3A2','FAS','IFNGR1','CD47','CD59','PVR','MICA','ICAM1','HLA-C','MET','EGFR','NT5E'])].sort_values(['Gene name','Position','HexNAc','Hex'])[cols].round(3)
ex.to_csv(OUT+'glyco_selected_surface_proteins.csv', index=False)
print(ex[ex['Gene name'].isin(['CD276'])].to_string(index=False))
print('CD274 (PD-L1) glycopeptides detected:', (igp['Gene name']=='CD274').sum(), '; TNFRSF1A:', (igp['Gene name']=='TNFRSF1A').sum())
# ---- figure 5
cls_order = ['Man5','Man6-9','Man1-4','Man5+ with Fuc','paucimannose+Fuc','hybrid (HexNAc3)','complex (HexNAc>=4)']; cls_lab = ['Man5','Man6-9','Man1-4','Man5+Fuc','pauci+Fuc','hybrid','complex']
fig, axes = plt.subplots(1,3, figsize=(17,5.6), gridspec_kw=dict(width_ratios=[1.25,1.4,1]))
order = ['AM_N1','AM_N2','AM_N3','AM_N4','AM_KO1','AM_KO2','AM_KO3','AM_KO4','NH_N1','NH_N2','NH_N3','NH_N4','NH_M_KO1','NH_M_KO2','NH_M_KO3','NH_M_KO4']
ax = axes[0]; bottom = np.zeros(len(order)); colr = {'Man5':'#d7191c','Man6-9':'#fdae61','complex (HexNAc>=4)':'#2c7bb6','hybrid (HexNAc3)':'#abd9e9','paucimannose+Fuc':'#7b3294'}
for k,c in colr.items():
    v = frac.loc[k, order].values; ax.bar(range(len(order)), v, bottom=bottom, color=c, edgecolor='k', lw=0.3, label=k.split(' (')[0]); bottom += v
ax.bar(range(len(order)), 100-bottom, bottom=bottom, color='0.85', edgecolor='k', lw=0.3, label='other')
ax.set_xticks(range(len(order))); ax.set_xticklabels(order, rotation=90, fontsize=8); ax.set_ylabel('% of summed glycopeptide reporter intensity')
ax.axvline(7.5,color='k',lw=1.5); ax.text(3.5,103,'A375',ha='center',weight='bold'); ax.text(11.5,103,'NCI-H1703',ha='center',weight='bold'); ax.set_ylim(0,132); ax.legend(fontsize=7.5, ncol=3, loc='upper center')
ax.set_title('A. Glycan-class composition per TMT channel\n(N = non-targeting, KO = MGAT1 knockout population)', fontsize=10)
ax = axes[1]; pos = 0; xt = []
for cl in cls_order:
    for j,(line,c) in enumerate([('A375','#f4a582'),('H1703','#92c5de')]):
        v = igp.loc[igp.glycan_class==cl,'log2fc_'+line].dropna().values
        bp = ax.boxplot([v], positions=[pos+j*0.8], widths=0.7, patch_artist=True, showfliers=False, medianprops=dict(color='k')); bp['boxes'][0].set_facecolor(c)
        ax.text(pos+j*0.8, 4.45, '%d'%len(v), ha='center', fontsize=7)
    xt.append(pos+0.4); pos += 2.2
ax.axhline(0,color='k',lw=0.6); ax.set_xticks(xt); ax.set_xticklabels(cls_lab, fontsize=9); ax.set_ylabel('log2 (KO / non-targeting) per glycopeptide'); ax.set_ylim(-4.2,4.8)
ax.plot([],[],'s',color='#f4a582',label='A375'); ax.plot([],[],'s',color='#92c5de',label='NCI-H1703'); ax.legend(fontsize=8, loc='lower left')
ax.set_title('B. KO vs control by glycan class (boxes = IQR, whiskers 1.5xIQR;\nnumbers = glycopeptides). TMT ratios are compressed.', fontsize=10)
ax = axes[2]; s = igp[(igp['Gene name']=='CD276')&(igp.Position==91)].sort_values(['HexNAc','Hex','Fuc','NeuAc']); y = np.arange(len(s))
ax.barh(y-0.2, s.log2fc_A375, height=0.4, color='#f4a582', edgecolor='k', lw=0.3, label='A375'); ax.barh(y+0.2, s.log2fc_H1703, height=0.4, color='#92c5de', edgecolor='k', lw=0.3, label='NCI-H1703')
ax.set_yticks(y); ax.set_yticklabels(s['Observed Modification'], fontsize=7.5); ax.axvline(0,color='k',lw=0.6); ax.set_xlabel('log2 (KO / non-targeting)'); ax.set_title('C. Example site: CD276 (B7-H3) Asn91', fontsize=10); ax.legend(fontsize=8)
fig.suptitle('Glycoproteomics (glycoproteomics_site_quant.xlsx, IGP_quant: 2,687 intact glycopeptides, 910 sites, 524 proteins): MGAT1 knockout shifts N-glycans from complex/hybrid to Man5 in both lines', fontsize=11)
fig.text(0.5,-0.02,'Classes by composition: Man5 = HexNAc2Hex5 (the MGAT1 substrate); Man1-4 = HexNAc2Hex1-4 without fucose; Man5+Fuc = HexNAc2Hex>=5 with fucose; pauci+Fuc = HexNAc2Hex1-4Fuc; hybrid = HexNAc3; complex = HexNAc>=4.', ha='center', fontsize=8.5)
fig.tight_layout(rect=[0,0,1,0.95]); fig.savefig(FIG+'fig5_glycoproteomics.png', dpi=170, bbox_inches='tight')
print('Done.')
