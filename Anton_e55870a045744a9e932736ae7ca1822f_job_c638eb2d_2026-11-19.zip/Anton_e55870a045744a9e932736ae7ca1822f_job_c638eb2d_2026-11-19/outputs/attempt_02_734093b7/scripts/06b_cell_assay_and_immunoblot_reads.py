#!/usr/bin/env python
"""
Image read-outs behind ledger entries B1-B3, B6 and E6:
  (a) lectin flow bars (phenotype_figures.pdf p2), (b) competition-assay dots (p3),
  (c) semi-quantitative densitometry of the STK11 immunoblot (p6) and the MGAT1 immunoblot (p11).
Densitometry on compressed, contrast-adjusted figure images is indicative only (several MGAT1 bands are saturated).
Inputs : /tmp/outputs/extracted_figures/phenotype_figures_p2.png, _p3.png, _p6.png, _p11.png
Outputs: /tmp/outputs/tables/digitised_lectin_and_competition_assays.csv, tables/immunoblot_densitometry.csv
Run    : micromamba run -n core python 06b_cell_assay_and_immunoblot_reads.py
"""
import numpy as np, pandas as pd
from PIL import Image
from scipy import ndimage as ndi
IMG = '/tmp/outputs/extracted_figures/'; OUT = '/tmp/outputs/tables/'
rows = []
# ---------------- (a) lectin bars, p2. y calibration from tick marks (row of 0 and px per unit) for each panel; red = sgMGAT1 bar incl. replicate dots (radius ~6 px)
im = np.array(Image.open(IMG+'phenotype_figures_p2.png').convert('RGB')).astype(int); R,G,B = im[...,0],im[...,1],im[...,2]
red = (R>140)&(G<60)&(B<60); lab,n = ndi.label(ndi.binary_closing(red, iterations=3))
cal = {'A375 PHA-L':(449.5,183.0,(0,500),(150,470)), 'A375 GNA':(440.5,27.9,(500,850),(130,470)), 'NCI-H1703 PHA-L':(946.5,189.5,(0,500),(640,970)), 'NCI-H1703 GNA':(941.5,27.65,(500,850),(640,970))}
for name,(y0,px,xr,yr) in cal.items():
    best = None
    for i in range(1,n+1):
        ys,xs = np.where(lab==i)
        if len(ys)>200 and xr[0]<=xs.mean()<xr[1] and yr[0]<=ys.mean()<yr[1]: best = ys.min()
    val = (y0-(best+6))/px          # top of the dot cluster + one dot radius = mean of replicates
    rows.append(dict(figure='p2', assay=name, arm='sgMGAT1 relative to sgNTC (=1)', value=round(val,2)))
# ---------------- (b) competition assay dots, p3. colours sampled from the legend; y: 0 at row 485.5 / 1183.5; 147.8 / 186.5 px per 1.0
im = np.array(Image.open(IMG+'phenotype_figures_p3.png').convert('RGB')).astype(int)
near = lambda c,tol=22: (np.abs(im-np.array(c)).max(axis=2)<tol)
yy,xx = np.mgrid[-4:5,-4:5]; disc = (xx**2+yy**2)<=3.5**2
labels = ['sgNTC','sgB2M','sgMGAT1_1','sgMGAT1_2','sgMGAT1_3','sgMGAT1_4']
for pname,(r0,r1,y0,px1) in {'NCI-H1703':(90,484,485.5,147.8), 'NCI-H1755':(790,1182,1183.5,186.5)}.items():
    for cname,c in {'E:T 0.2':(112,154,209), 'E:T 0.4':(90,88,162)}.items():
        m = near(c); mm = np.zeros_like(m); mm[r0:r1, 230:640] = m[r0:r1, 230:640]
        lb,k = ndi.label(ndi.binary_opening(mm, structure=disc)); pts = []
        for i in range(1,k+1):
            ys,xs = np.where(lb==i)
            if len(ys)>=40 and not (430<xs.mean()<460 and pname=='NCI-H1703') and not (500<xs.mean()<530 and pname=='NCI-H1755'):   # drop legend dots
                pts.append((xs.mean(), (y0-(ys.min()+6))/px1))
        pts.sort()
        # group dots by bar (x position): six bars per panel
        if not pts: continue
        xs_ = np.array([p[0] for p in pts]); order = np.argsort(xs_); groups = np.split(order, np.where(np.diff(xs_[order])>30)[0]+1)
        for lab_,gi in zip(labels, groups):
            rows.append(dict(figure='p3', assay=pname+' competition assay, '+cname, arm=lab_, value=' / '.join('%.2f'%pts[i][1] for i in gi)))
D = pd.DataFrame(rows); D.to_csv(OUT+'digitised_lectin_and_competition_assays.csv', index=False); pd.set_option('display.width',200); print(D.to_string(index=False))

# ---------------- (c) immunoblot densitometry: per lane, locate the band (darkest row in a window), subtract local background, integrate
def lane_band(img, xc, y_lo, y_hi, xhalf, half):
    inv = 255-img[:, int(xc-xhalf):int(xc+xhalf)+1]; prof = inv[y_lo:y_hi].mean(axis=1); bg = np.percentile(prof, 20); yc = int(np.argmax(prof))
    return float((prof[max(0,yc-half):yc+half+1]-bg).clip(min=0).sum()), float(prof.max())
b6 = np.array(Image.open(IMG+'phenotype_figures_p6.png').convert('L')).astype(float)
lanes6 = [377,462,547,632,720,800,887,972,1057]          # lane centres (px) read from the image
lab6 = ['parental','MGAT1 KO - / STK11 KO - / no cDNA','MGAT1 KO + / STK11 KO -','MGAT1 KO - / STK11 KO +','MGAT1 KO + / STK11 KO +','STK11 KO + WT cDNA','STK11 KO + mutant cDNA','MGAT1 KO + STK11 KO + WT cDNA','MGAT1 KO + STK11 KO + mutant cDNA']
out = []; ref = None
for x,l in zip(lanes6, lab6):
    s,_ = lane_band(b6, x, 395, 445, 32, 9); v,_ = lane_band(b6, x, 570, 635, 32, 14); out.append(dict(blot='p6 STK11 / vinculin (MC38 panel)', lane=l, target_band=round(s), loading_band=round(v), ratio=s/v))
ref = out[1]['ratio']
for o in out: o['relative_to_reference_lane'] = round(o.pop('ratio')/ref, 2)
b11 = np.array(Image.open(IMG+'phenotype_figures_p11.png').convert('L')).astype(float); sc = 2680/2061
lanes11 = [137,207,272,350,415,487,548,630,695]          # lane centres in the 2061-px-wide rendering; scaled to native pixels below
lab11 = ['sgNTC parental','sgNTC vector','sgNTC WT','sgNTC D289A','sgNTC D211A+D289A','sgMGAT1 vector','sgMGAT1 WT','sgMGAT1 D289A','sgMGAT1 D211A+D289A']
o11 = []
for x,l in zip(lanes11, lab11):
    s,peak = lane_band(b11, x*sc, int(470*sc), int(600*sc), 28, 16); a,_ = lane_band(b11, x*sc, int(700*sc), int(775*sc), 28, 12)
    o11.append(dict(blot='p11 MGAT1 / beta-actin (NCI-H1703 panel)', lane=l, target_band=round(s), loading_band=round(a), ratio=s/a, note='band saturated' if peak>190 else ('no discrete band visible; value is background / halo from adjacent saturated lanes' if l=='sgMGAT1 vector' else '')))
ref = o11[1]['ratio']
for o in o11: o['relative_to_reference_lane'] = round(o.pop('ratio')/ref, 2)
W = pd.DataFrame(out+o11); W.to_csv(OUT+'immunoblot_densitometry.csv', index=False); print(W.to_string(index=False))
