#!/usr/bin/env python
"""
Digitisation of the client's phenotype figures (phenotype_figures.pdf) and derived quantities.
The client supplied these data only as plots (no underlying tables, no n, no statistics), so every number here was re-read from the image:
  - automated colour-mask read-out against axis calibration taken from the tick marks (method = 'auto'), or
  - a manual read from a 3-4x enlarged crop where markers of two series overlap (method = 'manual').
Expect +/-2-3% of axis range as reading error. Error-bar ends are reported as plotted (the client does not say SD or SEM).
Inputs : /tmp/outputs/extracted_figures/phenotype_figures_p*.png
Outputs: /tmp/outputs/tables/digitised_*.csv, /tmp/outputs/figures/fig4_single_gene_invivo_digitised.png
Run    : micromamba run -n core python 06_phenotype_figures_digitised.py
"""
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from scipy import stats
IMG = '/tmp/outputs/extracted_figures/'; OUT = '/tmp/outputs/tables/'; FIG = '/tmp/outputs/figures/'
def load(p): 
    im = np.array(Image.open(IMG+'phenotype_figures_p%d.png'%p).convert('RGB')).astype(int); return im[...,0],im[...,1],im[...,2]
def read_series(mask, x0, px_per_day, y0, px_per_unit, unit, days, xr, yr, halfwidth=10, minw=10):
    """for each day: marker centre (widest run of coloured pixels) and the vertical extent of the error bar"""
    mm = np.zeros_like(mask); mm[yr[0]:yr[1], xr[0]:xr[1]] = mask[yr[0]:yr[1], xr[0]:xr[1]]; y2v = lambda y: (y0-y)/px_per_unit*unit; out = []
    for day in days:
        xc = int(round(x0+px_per_day*day)); ys = np.where(mm[:, xc-1:xc+2].any(axis=1))[0]
        wy = np.where(mm[:, xc-halfwidth:xc+halfwidth+1].sum(axis=1)>=minw)[0]
        if len(ys)==0 or len(wy)==0: out.append((day,np.nan,np.nan,np.nan)); continue
        segs = np.split(wy, np.where(np.diff(wy)>1)[0]+1); s = max(segs, key=len)
        out.append((day, y2v((s[0]+s[-1])/2), y2v(ys.max()), y2v(ys.min())))
    return out
rows = []
def add(fig, panel, series, res, method='auto'):
    for day,m,lo,hi in res: rows.append(dict(figure=fig, panel=panel, series=series, day=day, mean=None if np.isnan(m) else round(m), err_low=None if np.isnan(lo) else round(lo), err_high=None if np.isnan(hi) else round(hi), method=method))
# ---- page 1: MC38 +/- sgMGAT1 (calibration: see tick positions in comments)
R,G,B = load(1); black = (R<70)&(G<70)&(B<70); green = (G>R+40)&(G>B+40); grey = (abs(R-G)<18)&(abs(G-B)<18)&(R>110)&(R<190); blue = (B>R+40)&(B>G+25)
# panel a: x 0 at col 240.5, 23.44 px/day; y 0 at row 628.5, 130.2 px per 1000 mm3
add('p1','MC38 WT','sgNTC', read_series(black,240.5,23.44,628.5,130.2,1000,[7,9,11,13,15,18,20,22,25],(246,860),(220,626)))
add('p1','MC38 WT','sgMGAT1', read_series(green,240.5,23.44,628.5,130.2,1000,[13,15,18,20,22,25],(246,860),(220,626)))
# panel b: x 0 at col 1099, 29.45 px/day; y 0 at row 628.5, 112 px per 500 mm3
add('p1','MC38 sgSTK11','sgNTC', read_series(black,1099,29.45,628.5,112,500,[8,10,12,15,17,19],(1104,1720),(220,626)))
add('p1','MC38 sgSTK11','sgMGAT1', read_series(green,1099,29.45,628.5,112,500,[10,12,15,17,19],(1104,1720),(220,626)))
# panel c: x 0 at col 1780+264, 57.1 px/day; y 0 at row 629, 95.25 px per 500 mm3
for nm,mk in [('NTC; IgG2a',black),('NTC; anti-PD1',grey),('sgMGAT1; IgG2a',green),('sgMGAT1; anti-PD1',blue)]:
    add('p1','MC38 sgSTK11 +/- anti-PD1',nm, read_series(mk,1780+264,57.1,629,95.25,500,[2,4,7,9],(1780+267,1780+850),(230,627),halfwidth=9,minw=8))
# ---- page 7: cDNA rescue in vivo. left: x0 368, 21.75 px/day, y0 638, 131 px/500; right: x0 1064.5, 21.7 px/day, y0 642, 134 px/500
R,G,B = load(7); black = (R<70)&(G<70)&(B<70); blue = (B>R+40)&(B>G+25)
add('p7','sgSTK11+sgNTC','MGAT1 WT', read_series(black,368,21.75,638,131,500,[5,7,10,12],(375,820),(215,634),minw=12))
add('p7','sgSTK11+sgMGAT1','MGAT1 WT', read_series(black,1064.5,21.7,642,134,500,[5,7,10,12,14,17,19],(1071,1520),(215,638),minw=12))
add('p7','sgSTK11+sgMGAT1','MGAT1 D211A+D289A', read_series(blue,1064.5,21.7,642,134,500,[7,10,12,14,17,19],(1071,1520),(215,638),minw=12))
rows.append(dict(figure='p7', panel='sgSTK11+sgNTC', series='MGAT1 D211A+D289A', day=12, mean=800, err_low=510, err_high=1090, method='manual (hidden behind WT series)'))
# ---- page 8: library populations in nude / B6 / B6 + anti-PD1. left: x0 325.5, 76 px/day, y0 756.5, 168 px/500; right: x0 1512.5, 75.6 px/day, y0 755.5, 126 px/500
R,G,B = load(8); black = (R<70)&(G<70)&(B<70); grey = (abs(R-G)<18)&(abs(G-B)<18)&(R>100)&(R<175); green = (G>R+40)&(G>B+30)
for nm,mk in [('Nude',black),('C57BL/6',grey),('C57BL/6 + anti-PD1',green)]:
    add('p8','MC38 sgNTC',nm, read_series(mk,325.5,76.0,756.5,168,500,[4,6,8],(335,1100),(215,750),halfwidth=12,minw=14))
    add('p8','MC38 sgSTK11',nm, read_series(mk,1512.5,75.6,755.5,126,500,[4,6,7],(1522,2300),(215,749),halfwidth=12,minw=14))
# ---- page 4: adoptive T-cell transfer; y0 = axis row + 2.5, 51.2 px per 500 mm3; red series overlaps blue error bars -> manual reads from 3x crops
for panel,vals in {'Control T cells':[('sgNTC',1929,1538,2329),('sgMGAT1',1645,1457,1847)], 'NYESO T cells, 1e6':[('sgNTC',1297,770,1821),('sgMGAT1',617,233,991)], 'NYESO T cells, 2e6':[('sgNTC',598,188,1001),('sgMGAT1',171,0,373)]}.items():
    for s,m,lo,hi in vals: rows.append(dict(figure='p4', panel=panel, series=s, day=19, mean=m, err_low=lo, err_high=hi, method='manual (3x crop)'))
D = pd.DataFrame(rows)
# NOTE: automated reads are unreliable wherever markers/error bars of two series overlap (mostly early time points), so only the last time point
# of each series is carried forward, and each of those was checked by eye on an enlarged crop (curated table E below).
last = D.sort_values('day').groupby(['figure','panel','series']).tail(1).sort_values(['figure','panel','series'])
print('Automated read-out at the last time point of each series (for comparison with the curated endpoint table):'); print(last.to_string(index=False))
# ---- non-tumour read-outs (manual/auto reads; see memo)
other = pd.DataFrame([
 dict(figure='p2', readout='PHA-L relative signal, sgMGAT1 vs sgNTC', A375=0.02, NCI_H1703=0.03, note='see 06b script for the automated read; n=3-4 dots per bar'),
 dict(figure='p2', readout='GNA relative signal, sgMGAT1 vs sgNTC', A375=8.2, NCI_H1703=8.8, note=''),
 dict(figure='p3', readout='NCI-H1703 competition assay, relative viability E:T 0.2 / 0.4', A375=None, NCI_H1703=None, note='sgNTC 0.92/0.86; sgB2M 1.86/1.96; sgMGAT1_1 0.42/0.31; _2 0.41/0.27; _3 0.46/0.54; _4 0.27/0.30'),
 dict(figure='p3', readout='NCI-H1755 competition assay, relative viability E:T 0.2', A375=None, NCI_H1703=None, note='sgNTC 0.80; sgB2M 1.85; sgMGAT1_1 ~0.45 (0.37, 0.52); _2 0.17; _3 ~0.42 (0.25, 0.58); _4 0.50'),
 dict(figure='p5', readout='PHA-L MFI (x1e6), cDNA panel', A375=None, NCI_H1703=None, note='sgNTC: parental 6.8, vector 6.7, WT 6.4, D289A 5.8, D211A+D289A 5.6; sgMGAT1: vector ~0, WT 5.3, D289A ~0, D211A+D289A ~0 (n=2 each)'),
 dict(figure='p5', readout='relative viability with T cells (donor 1 / donor 2)', A375=None, NCI_H1703=None, note='approximate reads (+/-0.03): sgNTC background - all four constructs ~1.1-1.2; sgMGAT1 background - vector ~0.7, WT ~1.15, D289A ~0.55, D211A+D289A ~0.5-0.55'),
 dict(figure='p10', readout='48 h viability at E:T 1:1 with NY-ESO TCR-T vs untransduced CD8', A375=None, NCI_H1703=None, note='HEK293 1.15 vs 1.33; A549 1.08 vs 1.08 (not killed); NCI-H1703 ~0.10 vs 1.07; NCI-H1755 ~0.05 vs 0.92'),
]); other.to_csv(OUT+'digitised_other_readouts.csv', index=False)

# ---- endpoint table + derived quantities
E = pd.DataFrame([
 ('A. MC38 Stk11-WT\n(day 25)','sgNTC',1160,346,1982,'0.25','p1 left'),('A. MC38 Stk11-WT\n(day 25)','sgMGAT1',1774,910,2638,'#2ca25f','p1 left'),
 ('B. MC38 sgSTK11\n(day 19)','sgNTC',1085,578,1598,'0.25','p1 middle'),('B. MC38 sgSTK11\n(day 19)','sgMGAT1',545,105,996,'#2ca25f','p1 middle'),
 ('C. MC38 sgSTK11 +/- anti-PD-1\n(day 9 of treatment)','NTC\nIgG2a',1131,467,1806,'0.25','p1 right'),('C. MC38 sgSTK11 +/- anti-PD-1\n(day 9 of treatment)','NTC\naPD-1',756,87,1430,'0.6','p1 right'),
 ('C. MC38 sgSTK11 +/- anti-PD-1\n(day 9 of treatment)','sgMGAT1\nIgG2a',619,310,927,'#2ca25f','p1 right'),('C. MC38 sgSTK11 +/- anti-PD-1\n(day 9 of treatment)','sgMGAT1\naPD-1',400,129,656,'#3b4cc0','p1 right'),
 ('D. sgSTK11+sgMGAT1 clone,\ncDNA rescue (day 19)','MGAT1\nWT',860,616,1112,'0.25','p7 right'),('D. sgSTK11+sgMGAT1 clone,\ncDNA rescue (day 19)','D211A\n+D289A',422,257,590,'#3b4cc0','p7 right'),
 ('E. ACT model: tumour + human T cells (day 19)','sgNTC\nctrl T',1929,1538,2329,'#3b4cc0','p4'),('E. ACT model: tumour + human T cells (day 19)','sgMGAT1\nctrl T',1645,1457,1847,'#d7191c','p4'),
 ('E. ACT model: tumour + human T cells (day 19)','sgNTC\nNYESO 1e6',1297,770,1821,'#3b4cc0','p4'),('E. ACT model: tumour + human T cells (day 19)','sgMGAT1\nNYESO 1e6',617,233,991,'#d7191c','p4'),
 ('E. ACT model: tumour + human T cells (day 19)','sgNTC\nNYESO 2e6',598,188,1001,'#3b4cc0','p4'),('E. ACT model: tumour + human T cells (day 19)','sgMGAT1\nNYESO 2e6',171,0,373,'#d7191c','p4')],
 columns=['panel','arm','mean','lo','hi','color','source'])
E.to_csv(OUT+'digitised_tumour_endpoints.csv', index=False)
g = lambda p,a: E[(E.panel.str.startswith(p))&(E.arm==a)].iloc[0]
tc_ko, tc_pd1, tc_combo = g('C','sgMGAT1\nIgG2a')['mean']/g('C','NTC\nIgG2a')['mean'], g('C','NTC\naPD-1')['mean']/g('C','NTC\nIgG2a')['mean'], g('C','sgMGAT1\naPD-1')['mean']/g('C','NTC\nIgG2a')['mean']
print('MC38 Stk11-WT: sgMGAT1/sgNTC = %.2f'%(1774/1160)); print('MC38 sgSTK11: sgMGAT1/sgNTC = %.2f'%(545/1085))
print('MC38 sgSTK11 +/- aPD-1 (day 9): KO alone %.2f; aPD-1 alone %.2f; Bliss-additive expectation %.2f (= %.0f mm3); observed combination %.2f; aPD-1 effect within sgMGAT1 = %.2f vs within NTC = %.2f'%(tc_ko, tc_pd1, tc_ko*tc_pd1, tc_ko*tc_pd1*1131, tc_combo, 400/619, 756/1131))
print('cDNA rescue in vivo (sgSTK11+sgMGAT1 clone): D211A+D289A / WT = %.2f ; for reference the sgSTK11+sgNTC pool reached ~893 mm3 at day 12 vs 414 mm3 for the WT-rescued clone'%(422/860))
print('ACT: sgMGAT1/sgNTC = %.2f (control T), %.2f (1e6), %.2f (2e6)'%(1645/1929, 617/1297, 171/598))
print('page-8 cohorts (manual reads from 2x crops): sgNTC day 8 - nude 935 (609-1257), B6 384 (250-516), B6+aPD-1 ~94 (42-150) -> aPD-1 T/C %.2f; sgSTK11 day 7 - nude 964 (667-1256), B6 ~1262 (770-1756), B6+aPD-1 ~640 (286-1020) -> aPD-1 T/C %.2f'%(94/384, 640/1262))
pd.DataFrame([('MC38 sgNTC, day 8','Nude',935,609,1257),('MC38 sgNTC, day 8','C57BL/6',384,250,516),('MC38 sgNTC, day 8','C57BL/6 + anti-PD1',94,42,150),
              ('MC38 sgSTK11, day 7','Nude',964,667,1256),('MC38 sgSTK11, day 7','C57BL/6',1262,770,1756),('MC38 sgSTK11, day 7','C57BL/6 + anti-PD1',640,286,1020)], columns=['panel','arm','mean','lo','hi']).to_csv(OUT+'digitised_page8_cohorts.csv', index=False)
# illustrative significance / power, treating the plotted error bars as SD (if they were SEM the SDs would exceed the means)
def welch(m1,s1,m2,s2,n):
    se = np.sqrt(s1**2/n+s2**2/n); t = (m1-m2)/se; df = (s1**2/n+s2**2/n)**2/((s1**2/n)**2/(n-1)+(s2**2/n)**2/(n-1)); return 2*stats.t.sf(abs(t),df)
for n in (5,8,10):
    print('if n=%d/arm and bars are SD: p(NTC vs sgMGAT1, IgG2a) = %.2f; p(aPD-1 effect in NTC) = %.2f; p(aPD-1 effect in sgMGAT1) = %.2f; p(WT vs catalytic-dead rescue) = %.4f'%(n, welch(1131,670,619,308,n), welch(1131,670,756,670,n), welch(619,308,400,263,n), welch(860,248,422,166,n)))
sd_pool = np.sqrt((670**2+308**2)/2); dcoh = (1131-619)/sd_pool
print('power: to detect the observed KO effect (T/C 0.55) with 80%% power, two-sided alpha 0.05, pooled SD %.0f (d=%.2f): n = %.0f per arm'%(sd_pool, dcoh, 2*((1.96+0.84)/dcoh)**2+1))

# ---- figure 4
panels = list(dict.fromkeys(E.panel)); fig, axes = plt.subplots(1,5, figsize=(18,5.2), gridspec_kw=dict(width_ratios=[2,2,4,2,6]))
for ax,p in zip(axes,panels):
    s = E[E.panel==p].reset_index(drop=True); x = np.arange(len(s)); ax.bar(x, s['mean'], color=s.color, edgecolor='k', width=0.7)
    ax.errorbar(x, s['mean'], yerr=[s['mean']-s.lo, s.hi-s['mean']], fmt='none', ecolor='k', capsize=4, lw=1)
    for i,r in s.iterrows(): ax.text(i, r.hi+40, '%d'%r['mean'], ha='center', fontsize=9)
    ax.set_xticks(x); ax.set_xticklabels(s.arm, fontsize=8.5); ax.set_title(p, fontsize=10); ax.set_ylim(0,3200)
axes[0].set_ylabel('tumour volume, mm3 (digitised mean; bars = plotted error bars)')
axes[0].text(0.5,0.93,'T/C = 1.53\n(KO tumours larger)',transform=axes[0].transAxes,ha='center',va='top',fontsize=8.5,color='#b2182b'); axes[1].text(0.5,0.90,'T/C = 0.50',transform=axes[1].transAxes,ha='center',fontsize=9.5)
axes[2].text(0.5,0.79,'KO alone T/C 0.55;  aPD-1 alone 0.67\nBliss-additive expectation 0.37 (= 414 mm3)\nobserved combination 0.35 (~400 mm3)\n-> additive, no synergy',transform=axes[2].transAxes,ha='center',fontsize=9,bbox=dict(fc='white',ec='0.6',lw=0.5))
axes[2].plot([2.6,3.4],[414,414],color='#d7191c',lw=2,ls='--'); axes[2].text(3.45,414,'Bliss',color='#d7191c',fontsize=8,va='center')
axes[3].text(0.5,0.90,'T/C = 0.49',transform=axes[3].transAxes,ha='center',fontsize=9.5)
axes[4].text(0.5,0.90,'sgMGAT1 / sgNTC:   0.85 (control T)     0.48 (1e6 TCR-T)     0.29 (2e6 TCR-T)',transform=axes[4].transAxes,ha='center',fontsize=9.5)
fig.suptitle('Single-gene in vivo studies - endpoint values digitised from phenotype_figures.pdf (client reports no n, no statistics; error bars overlap in A-C)', fontsize=11.5)
fig.tight_layout(rect=[0,0,1,0.95]); fig.savefig(FIG+'fig4_single_gene_invivo_digitised.png', dpi=170, bbox_inches='tight'); print('Done.')
