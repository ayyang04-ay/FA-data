#!/usr/bin/env python
"""
Analysis of the five client crystal structures (apo, UDP, UDP-GlcNAc, ANT-3744 binary, ANT-3744/UDP ternary).
Inputs : /tmp/world/filesystem/MGAT1_*.cif
Outputs: /tmp/outputs/tables/structure_*.csv, /tmp/outputs/figures/fig6_structure_site.png
Run    : micromamba run -n core python 04_structures.py
"""
import gemmi, numpy as np, pandas as pd, matplotlib, warnings
matplotlib.use('Agg'); warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
from rdkit import Chem
from rdkit.Chem import Descriptors, Crippen, rdMolDescriptors, Lipinski
SRC = '/tmp/world/filesystem/'; OUT = '/tmp/outputs/tables/'; FIG = '/tmp/outputs/figures/'
names = ['MGAT1_apo','MGAT1_UDP','MGAT1_UDP_GlcNAc','MGAT1_C3744','MGAT1_C3744_UDP']
S = {}; rows = []
for n in names:
    st = gemmi.read_structure(SRC+n+'.cif'); st.setup_entities(); S[n] = st
    b = gemmi.cif.read(SRC+n+'.cif').sole_block()
    for chn in st[0]:
        pol = chn.get_polymer(); nums = sorted(r.seqid.num for r in pol)
        gaps = [(nums[i]+1, nums[i+1]-1) for i in range(len(nums)-1) if nums[i+1]-nums[i]>1]
        rows.append(dict(file=n+'.cif', chain=chn.name, resolution_A=st.resolution, Rwork=b.find_value('_refine.ls_R_factor_R_work'), Rfree=b.find_value('_refine.ls_R_factor_R_free'), space_group=st.spacegroup_hm,
            residues_modelled='%d-%d'%(nums[0],nums[-1]), disordered_segments=str(gaps), ligands=', '.join('%s%d'%(r.name,r.seqid.num) for r in chn if r.het_flag=='H' and r.name!='HOH')))
Q = pd.DataFrame(rows); Q.to_csv(OUT+'structure_summary.csv', index=False); pd.set_option('display.width',250); pd.set_option('display.max_colwidth',60); print(Q.to_string(index=False))

def xyz(res): return np.array([[a.pos.x,a.pos.y,a.pos.z] for a in res])
def get(st, ch, name): return [r for r in st[0][ch] if r.name==name][0]
def getres(st, ch, num): return [r for r in st[0][ch] if r.seqid.num==num and r.het_flag!='H'][0]
def mind(a,b): return float(np.linalg.norm(xyz(a)[:,None,:]-xyz(b)[None,:,:], axis=2).min())
def kabsch(P,Qm):
    Pc,Qc = P.mean(0),Qm.mean(0); H=(P-Pc).T@(Qm-Qc); U,s,Vt=np.linalg.svd(H); dd=np.sign(np.linalg.det(Vt.T@U.T)); R=Vt.T@np.diag([1,1,dd])@U.T
    return R,Pc,Qc

# ---- contacts of ANT-3744 (incl. symmetry mates) in all four copies
def contacts(st, ch, resname, cutoff=4.0):
    model = st[0]; ns = gemmi.NeighborSearch(model, st.cell, 6).populate(include_h=False); lig = get(st,ch,resname); res = {}
    for a in lig:
        for mk in ns.find_atoms(a.pos, '\0', radius=cutoff):
            cra = mk.to_cra(model)
            if cra.residue is lig or cra.residue.name=='HOH': continue
            dd = st.cell.find_nearest_pbc_image(a.pos, cra.atom.pos, mk.image_idx).dist()
            key = (cra.chain.name, cra.residue.name, cra.residue.seqid.num, 'symmetry mate' if mk.image_idx!=0 else 'same molecule')
            if key not in res or dd<res[key][0]: res[key] = (round(dd,2), a.name, cra.atom.name)
    return res
crow = []
for n in ['MGAT1_C3744','MGAT1_C3744_UDP']:
    for ch in 'AB':
        for k,v in contacts(S[n],ch,'C3744').items(): crow.append(dict(file=n+'.cif', ligand_chain=ch, partner_chain=k[0], residue='%s%d'%(k[1],k[2]), location=k[3], min_dist_A=v[0], ligand_atom=v[1], protein_atom=v[2]))
CT = pd.DataFrame(crow); CT.to_csv(OUT+'structure_ANT3744_contacts.csv', index=False)
piv = CT[CT.location=='same molecule'].assign(copy=lambda x: x.file.str.replace('.cif','')+':'+x.ligand_chain).pivot_table(index='residue', columns='copy', values='min_dist_A')
print('\nPocket residues within 4 A of ANT-3744 (min distance, A), four independent copies:'); print(piv.sort_index(key=lambda s: s.str[3:].astype(int)).round(2).to_string())
print('\nCrystal-lattice (symmetry-mate) contacts of ANT-3744:'); print(CT[CT.location=='symmetry mate'][['file','ligand_chain','residue','min_dist_A','ligand_atom','protein_atom']].to_string(index=False))

# ---- distances from ANT-3744 to the catalytic centre
drow = []
t = S['MGAT1_C3744_UDP']; u = S['MGAT1_UDP_GlcNAc']
for ch in 'AB':
    lig = get(t,ch,'C3744')
    # superpose the UDP-GlcNAc complex on the ternary complex (CA atoms of residues 105-315) to place the donor sugar
    ca_t = {r.seqid.num: r['CA'][0].pos for r in t[0][ch].get_polymer() if r.find_atom('CA','*')}; ca_u = {r.seqid.num: r['CA'][0].pos for r in u[0][ch].get_polymer() if r.find_atom('CA','*')}
    com = [i for i in sorted(set(ca_t)&set(ca_u)) if 105<=i<=315]
    R,Pc,Qc = kabsch(np.array([[ca_u[i].x,ca_u[i].y,ca_u[i].z] for i in com]), np.array([[ca_t[i].x,ca_t[i].y,ca_t[i].z] for i in com]))
    ud1 = get(u,ch,'UD1'); L = xyz(lig)
    dsug = {a.name: float(np.linalg.norm(L-((R@(np.array([a.pos.x,a.pos.y,a.pos.z])-Pc))+Qc),axis=1).min()) for a in ud1}
    drow.append(dict(chain=ch, to_UDP_closest_atoms=round(mind(lig,get(t,ch,'UDP')),1), to_Mn=round(mind(lig,get(t,ch,'MN')),1), to_Asp211=round(mind(lig,getres(t,ch,211)),1), to_Asp289=round(mind(lig,getres(t,ch,289)),1),
        centroid_to_centroid_UDP=round(float(np.linalg.norm(xyz(lig).mean(0)-xyz(get(t,ch,'UDP')).mean(0))),1), to_nearest_UDP_GlcNAc_atom_after_superposition=round(min(dsug.values()),1), to_GlcNAc_C1_anomeric_carbon=round(dsug["C1'"],1)))
D = pd.DataFrame(drow); D.to_csv(OUT+'structure_ANT3744_distances_to_active_site.csv', index=False); print('\nDistances (A) from ANT-3744 in the ternary complex:'); print(D.to_string(index=False))
# Mn2+ coordination and donor-site residues
for n,lg in [('MGAT1_UDP_GlcNAc','UD1'),('MGAT1_C3744_UDP','UDP')]:
    st = S[n]; c = contacts(st,'A','MN',2.7); print('\n%s chain A Mn2+ ligands (<2.7 A, protein/ligand only):'%n, sorted('%s%d %.2f'%(k[1],k[2],v[0]) for k,v in c.items()))
    c = contacts(st,'A',lg,3.6); print('%s chain A donor-site residues within 3.6 A of %s:'%(n,lg), ', '.join(sorted(set('%s%d'%(k[1],k[2]) for k in c if k[1]!='MN'), key=lambda s:int(s[3:]))))

# ---- B-factors / occupancy
brow = []
for n in names[1:]:
    st = S[n]; model = st[0]; ns = gemmi.NeighborSearch(model, st.cell, 5).populate(include_h=False)
    for chn in model:
        pb = np.mean([a.b_iso for r in chn.get_polymer() for a in r])
        for r in chn:
            if r.name in ('C3744','UDP','UD1','MN'):
                nb = [mk.to_cra(model).atom.b_iso for a in r for mk in ns.find_atoms(a.pos,'\0',radius=4.0) if mk.to_cra(model).residue is not r and mk.to_cra(model).residue.name!='HOH']
                brow.append(dict(file=n+'.cif', chain=chn.name, ligand=r.name, mean_B=round(np.mean([a.b_iso for a in r]),1), mean_occupancy=round(np.mean([a.occ for a in r]),2), neighbours_mean_B=round(np.mean(nb),1), chain_protein_mean_B=round(pb,1)))
BF = pd.DataFrame(brow); BF.to_csv(OUT+'structure_ligand_bfactors.csv', index=False); print('\n', BF.to_string(index=False))

# ---- pose reproducibility and induced fit
pocket = [388,389,390,394,410,412,434,437,438,439,440,441,442,444]
copies = [('MGAT1_C3744','A'),('MGAT1_C3744','B'),('MGAT1_C3744_UDP','A'),('MGAT1_C3744_UDP','B')]
def pk(n,ch):
    c = S[n][0][ch]; P = np.array([[a.pos.x,a.pos.y,a.pos.z] for r in c.get_polymer() if r.seqid.num in pocket for a in r if a.name in ('N','CA','C','O')])
    return P, {a.name: np.array([a.pos.x,a.pos.y,a.pos.z]) for a in get(S[n],ch,'C3744')}
Pr,Lr = pk(*copies[0]); print()
for k in copies[1:]:
    P,Lg = pk(*k); R,Pc,Qc = kabsch(P,Pr); nm = sorted(Lr); Lt = np.array([(R@(Lg[x]-Pc))+Qc for x in nm]); dv = np.sqrt(((Lt-np.array([Lr[x] for x in nm]))**2).sum(1))
    print('pose %s:%s vs %s:%s - ligand heavy-atom RMSD after pocket superposition %.2f A (largest deviation %.1f A at atom %s)'%(k[0],k[1],copies[0][0],copies[0][1], np.sqrt((dv**2).mean()), dv.max(), nm[int(dv.argmax())]))
def ca(n,ch): return {r.seqid.num: np.array([r['CA'][0].pos.x,r['CA'][0].pos.y,r['CA'][0].pos.z]) for r in S[n][0][ch].get_polymer() if r.find_atom('CA','*')}
def sup(k1,k2):
    a,b = ca(*k1), ca(*k2); com = sorted(set(a)&set(b)); P = np.array([a[i] for i in com]); Qm = np.array([b[i] for i in com]); R,Pc,Qc = kabsch(P,Qm)
    for _ in range(3):
        dv = np.linalg.norm((R@(P-Pc).T).T+Qc-Qm, axis=1); R,Pc,Qc = kabsch(P[dv<1.5],Qm[dv<1.5])
    dv = np.linalg.norm((R@(P-Pc).T).T+Qc-Qm, axis=1); return com, dv
for k1,k2 in [(('MGAT1_C3744','A'),('MGAT1_apo','A')),(('MGAT1_C3744_UDP','A'),('MGAT1_UDP','A')),(('MGAT1_UDP_GlcNAc','A'),('MGAT1_apo','A'))]:
    com,dv = sup(k1,k2); print('%s:%s vs %s:%s  CA RMSD %.2f A over %d residues; residues moving >1.5 A: %s'%(k1[0],k1[1],k2[0],k2[1], np.sqrt((dv**2).mean()), len(com), [(i, round(float(x),1)) for i,x in zip(com,dv) if x>1.5]))

# ---- ligand burial (Shrake-Rupley solvent-accessible surface; protein chain + ligand only, no symmetry mates)
from Bio.PDB import MMCIFParser, ShrakeRupley
from Bio.PDB.Structure import Structure as BStructure
from Bio.PDB.Model import Model as BModel
from Bio.PDB.Chain import Chain as BChain
def sasa_lig(residues):
    stt = BStructure('x'); mdl = BModel(0); chx = BChain('X'); stt.add(mdl); mdl.add(chx)
    for i,r in enumerate(residues):
        rr = r.copy(); rr.id = (rr.id[0], i+1, ' '); chx.add(rr)
    ShrakeRupley().compute(stt[0], level='A'); per = {}
    for r in chx:
        if r.get_resname()=='C3744': per = {a.get_id(): a.sasa for a in r}
    return per
burial = []
for n,ch in copies:
    bs = MMCIFParser(QUIET=True).get_structure(n, SRC+n+'.cif'); chain = bs[0][ch]
    lig = [r for r in chain if r.get_resname()=='C3744'][0]
    alone = sasa_lig([lig]); cx = sasa_lig([r for r in chain if r.id[0]==' ']+[lig])
    burial.append(dict(file=n+'.cif', chain=ch, ligand_sasa_free_A2=round(sum(alone.values())), ligand_sasa_bound_A2=round(sum(cx.values())), pct_buried=round(100*(1-sum(cx.values())/sum(alone.values()))),
                       solvent_exposed_atoms=', '.join(k for k,v in sorted(cx.items(), key=lambda kv:-kv[1]) if v>20)))
BU = pd.DataFrame(burial); BU.to_csv(OUT+'structure_ANT3744_burial.csv', index=False); print('\n', BU.to_string(index=False))

# ---- ligand chemistry from the CIF chemical-component definition
b = gemmi.cif.read(SRC+'MGAT1_C3744_UDP.cif').sole_block()
bonds = [list(r) for r in b.find('_chem_comp_bond.', ['comp_id','atom_id_1','atom_id_2','value_order']) if r[0]=='C3744']
rw = Chem.RWMol(); idx = {}
for x in bonds:
    for nm in x[1:3]:
        if nm not in idx: idx[nm] = rw.AddAtom(Chem.Atom(''.join(ch for ch in nm if ch.isalpha())))
for x in bonds: rw.AddBond(idx[x[1]], idx[x[2]], {'sing':Chem.BondType.SINGLE,'doub':Chem.BondType.DOUBLE}[x[3]])
mol = rw.GetMol(); Chem.SanitizeMol(mol); mol = Chem.RemoveHs(mol)
name = [list(r) for r in b.find('_chem_comp.', ['id','name','formula','formula_weight']) if r[0]=='C3744'][0]
print('\nANT-3744 (component C3744):', name[1], name[2], name[3]); print('SMILES', Chem.MolToSmiles(mol), '| MW %.1f, heavy atoms %d, TPSA %.1f, cLogP(Crippen) %.2f, HBD %d, HBA %d, rotatable bonds %d'%(Descriptors.MolWt(mol), mol.GetNumHeavyAtoms(), rdMolDescriptors.CalcTPSA(mol), Crippen.MolLogP(mol), Lipinski.NumHDonors(mol), Lipinski.NumHAcceptors(mol), Lipinski.NumRotatableBonds(mol)))

# ---- figure 6 (2-D projection of the ternary complex, chain A)
st = S['MGAT1_C3744_UDP']; chn = st[0]['A']
CA = np.array([[r['CA'][0].pos.x,r['CA'][0].pos.y,r['CA'][0].pos.z] for r in chn.get_polymer() if r.find_atom('CA','*')]); nums = np.array([r.seqid.num for r in chn.get_polymer() if r.find_atom('CA','*')])
udp, mn, lig, d211, d289 = xyz(get(st,'A','UDP')), xyz(get(st,'A','MN')), xyz(get(st,'A','C3744')), xyz(getres(st,'A',211)), xyz(getres(st,'A',289))
ex = lig.mean(0)-udp.mean(0); ex /= np.linalg.norm(ex); Xc = CA-CA.mean(0); Xc = Xc-np.outer(Xc@ex,ex); ey = np.linalg.svd(Xc, full_matrices=False)[2][0]; o = CA.mean(0)
Pj = lambda A: np.c_[(A-o)@ex, (A-o)@ey]
fig, ax = plt.subplots(figsize=(10.5,6.8)); p = Pj(CA); nt = nums<=330
ax.plot(p[:,0],p[:,1],color='0.8',lw=0.8,zorder=1)
ax.scatter(p[nt,0],p[nt,1],s=9,color='#a6cee3',zorder=2,label='N-terminal catalytic region, res. 99-330 (CA trace)'); ax.scatter(p[~nt,0],p[~nt,1],s=9,color='#b2df8a',zorder=2,label='C-terminal region, res. 331-445')
pm = np.isin(nums,pocket); ax.scatter(p[pm,0],p[pm,1],s=28,color='#33a02c',edgecolor='k',lw=0.4,zorder=3,label='residues within 4 Å of ANT-3744')
for Aat,c,l,sz in [(udp,'#ff7f00','UDP (donor-nucleotide site)',40),(mn,'#6a3d9a','Mn2+',90),(lig,'#e31a1c','ANT-3744 (C3744)',40),(d211,'#1f78b4','Asp211 (binds Mn2+) / Asp289 (at donor sugar)',26),(d289,'#1f78b4',None,26)]:
    q = Pj(Aat); ax.scatter(q[:,0],q[:,1],s=sz,color=c,edgecolor='k',lw=0.4,zorder=5,label=l)
dm = np.linalg.norm(udp[:,None,:]-lig[None,:,:],axis=2); i,j = np.unravel_index(dm.argmin(), dm.shape)
ax.annotate('', xy=Pj(lig[j:j+1])[0], xytext=Pj(udp[i:i+1])[0], arrowprops=dict(arrowstyle='<->',color='k',lw=1.4), zorder=6)
mid = (Pj(lig[j:j+1])[0]+Pj(udp[i:i+1])[0])/2; ax.text(mid[0], mid[1]+1.3, '%.0f Å'%dm.min(), ha='center', fontsize=12, weight='bold', bbox=dict(fc='white',ec='none',alpha=0.85,pad=1))
q289 = Pj(d289).mean(0); q211 = Pj(d211).mean(0); d2 = np.linalg.norm(d289[:,None,:]-lig[None,:,:],axis=2).min()
ax.annotate('Asp289\n(%.0f Å from ANT-3744)'%d2, xy=q289, xytext=(2,21), ha='center', fontsize=9, color='#1f78b4', arrowprops=dict(arrowstyle='-',color='#1f78b4',lw=0.8), bbox=dict(fc='white',ec='none',alpha=0.85,pad=1))
ax.annotate('Asp211', xy=q211, xytext=(-24,-14), ha='center', fontsize=9, color='#1f78b4', arrowprops=dict(arrowstyle='-',color='#1f78b4',lw=0.8), bbox=dict(fc='white',ec='none',alpha=0.85,pad=1))
ax.set_aspect('equal'); ax.set_xlabel('Å (axis through the UDP and ANT-3744 centroids)'); ax.set_ylabel('Å'); ax.legend(fontsize=8, loc='upper left', bbox_to_anchor=(1.01,1.0))
ax.set_title('MGAT1 - ANT-3744 - UDP - Mn2+ ternary complex (MGAT1_C3744_UDP.cif, chain A, 2.01 Å):\nthe inhibitor occupies a pocket in the C-terminal region, remote from the catalytic centre (2-D projection)', fontsize=10.5)
fig.savefig(FIG+'fig6_structure_site.png', dpi=170, bbox_inches='tight'); print('Done.')
