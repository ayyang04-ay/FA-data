# Antera MGAT1 inhibitor programme: independent verification and recommendation

**Bottom line.** Do not advance the asset now. Hold it behind a short set of gating studies. No compound has been tested in a cell, the client's own in vivo data do not support the checkpoint-resistance positioning, and the inhibition mechanism leaves open whether the series can reproduce a knockout. The target genetics and the chemistry are real enough to justify answering those questions before stopping.

**Scope.** Independent re-analysis of the 16 files supplied (data cut 1 Nov 2026). Every number below comes from the client's own files. Tags such as [D11] point to the evidence ledger (Appendix A and `evidence_ledger.csv`), which gives the source file, the script and the output table for each number.

**Two caveats that apply throughout.**

- The eight tumour groups in the in vivo screen are not defined anywhere in the records. I inferred what each group is from control genes in the data (section 3.3). The inferred labels are marked † in the text (and with an asterisk in Figure 1) and the client must confirm them.
- All tumour-growth and cell-assay results were supplied only as plots, with no animal numbers, no error-bar definition and no statistics. I re-read the values from the images (about ±2–3% reading error). I report effect sizes from them and make no significance claims.

---

## 1. Recommendation

**Do not advance the asset now. Put it on a gated hold.**

In practice: no lead-optimisation scale-up, no compound efficacy studies in animals, and no positioning of the asset as a drug that reverses checkpoint-inhibitor resistance in STK11-mutant NSCLC. Keep a small effort on the gating studies in section 4. The first two can be run with reagents the client already has. Revisit the decision when the criteria in section 5 are met.

Three findings drive the call.

1. **No compound has been tested in a cell.** For the chemistry, the package contains purified-enzyme potency, SPR, thermal shift, crystal structures, solubility and hepatocyte clearance, and nothing else [H3]. There is no lectin or glycan readout, no T-cell assay, no permeability, selectivity, pharmacokinetic or tolerability data for any compound. The biological thesis (what a knockout does) and the asset (ANT-3744 / ANT-4267) have never been in the same experiment.

2. **The client's own in vivo data do not support the checkpoint-resistance positioning.**

    - In the pooled screen, Mgat1 is depleted to the same degree with and without PD-1 blockade† in Stk11-knockout tumours. The difference is 0.26 log2 (95% CI −0.34 to +0.50, p = 0.67) [D11].
    - In the single-gene study, MGAT1 loss and anti-PD-1 are additive. The combination reached 0.35 of control against 0.37 expected for independent effects [E3].
    - Part of the dependency is already present in the arm that shows no T-cell selection (inferred nude†) [D7, D9].
    - The STK11 link comes from one engineered mouse colon line made with a single Stk11 guide [D12, I5]. It has not been tested in human cells [A9, B8].

3. **The chemistry has open mechanism questions that bear directly on whether it can reproduce a knockout.** ANT-3744 binds outside the active site, 24 Å from the bound nucleotide [F3]. All four potent analogues with curves in the package level off at about 91% inhibition [G3]. Inhibition has not been characterised against the acceptor substrate. Neither of the two acquired comparator compounds is a usable reference [G8].

**Why hold rather than stop.** The target genetics are solid in human cells [A3, B2–B5] and depend on catalytic activity [B4–B6], which is what an enzyme inhibitor needs. The series is a genuine binder with a 43 nM lead, five crystal structures and sensible early properties [G1, G5, G7, H1]. The decisive questions are inexpensive to answer compared with what has already been spent.

**How sure I am.** High confidence that no cellular compound data exist (I inventoried all 16 files) and that anti-PD-1 does not interact with Mgat1 loss (the screen result holds whichever of the three immunocompetent arms received anti-PD-1, across nine analysis variants, and the explicitly labelled single-gene study agrees). Moderate confidence in the size of the T-cell-independent component, which depends on my inferred group labels and on the estimator. The 91% ceiling needs one control experiment before it can be interpreted.

---

## 2. Scorecard

| # | What the programme needs to be true | Verdict | Key evidence |
|---|---|---|---|
| 1 | Loss of MGAT1 sensitises human NSCLC cells to T-cell killing | **Supported** | Genome-wide screen: rank 23 of 19,114, log2FC −0.84 (CI −1.12 to −0.63), 4 of 4 guides [A3, A4]. Four further guides in two lines: relative viability 0.17–0.54 against 0.80–0.92 for control [B2, B3]. |
| 2 | The effect needs MGAT1 catalytic activity | **Supported in vitro** | Wild-type cDNA restores lectin signal and resistance; D289A and D211A/D289A do neither despite expression [B4–B6]. In vivo result agrees but has design caveats [E4]. |
| 3 | Knockout changes glycans as expected | **Supported** | Man5 share of glycopeptide signal roughly doubles (from 19% to 40%); complex and hybrid roughly halve, in both lines [C2, C3]. |
| 4 | The effect operates in tumours in vivo | **Supported, with limits** | Mgat1 is a top-11 dependency of 795 genes in every Stk11-knockout in vivo arm and neutral in vitro [D6, D7]. Adoptive-transfer model: tumour ratio falls from 0.85 to 0.48 to 0.29 as the T-cell dose rises [B7]. |
| 5 | The in vivo effect is T-cell mediated | **Partly** | Stk11-knockout tumours: extra −0.6 to −0.8 log2 in immunocompetent† versus T-cell-deficient† hosts (p ≤ 0.002), but −2.10 is already present without T cells† [D7, D10]. |
| 6 | The effect is selective for STK11-deficient tumours | **One mouse model only** | Mgat1 is the top-ranked background-selective gene (−1.8 log2), but the two backgrounds were sequenced in separate run sets [D3, D12]. MGAT1-knockout Stk11-wild-type tumours were larger, not smaller (error bars overlap) [E1]. No human test [A9]. |
| 7 | MGAT1 loss restores or adds to anti-PD-1 | **Not supported** | No interaction in the screen [D11]; additive in the single-gene study [E3]. |
| 8 | The compounds bind and inhibit purified MGAT1 | **Supported** | IC50s confirmed by re-fit (within 1.2×) [G2]; SPR KD 0.4 µM and 0.03–0.07 µM [G5]; inhibition tracks binding across 24 analogues (r = 0.95) [G7]; pose identical in four crystal copies [F5]. |
| 9 | The inhibition mechanism is understood | **No** | Pocket is remote from the active site [F3]; about 91% ceiling [G3]; not competitive with UDP [G6]; nothing measured against acceptor or UDP-GlcNAc. |
| 10 | The compounds inhibit MGAT1 in cells and reproduce the knockout | **No data** | [H3] |
| 11 | Selectivity, exposure, tolerability | **No data** beyond solubility and hepatocyte clearance | [H1, H3] |

---

## 3. The case in detail

### 3.1 What holds up

**Human target genetics.** The genome-wide co-culture screen in NCI-H1703 is technically clean. The strongest resistance genes are the antigen itself (CTAG1B, +1.64), B2M (+1.43) and the interferon-γ and TNF receptors; the strongest sensitisers include CFLAR and PTPN2 [A6]. MGAT1 knockout leaves about 44% fewer surviving cells than controls after 24 h with T cells [A3]. The hit is not isolated: twelve genes of N-glycan assembly, sugar-nucleotide supply and sialylation sit in the top 40 [A7]. See Figure 2.

**Independent confirmation.** The four validation guides differ from the four library guides, and all eight map to the MGAT1 locus [A10]. They reproduce the effect in NCI-H1703 and NCI-H1755 [B2, B3]. Knockout efficiency is high by lectin flow (PHA-L down to 2–3% of control, GNA up 8–9-fold) [B1].

**Catalytic dependence.** In knockout cells, wild-type cDNA restores PHA-L signal to 5.3 × 10⁶ (control 6.7 × 10⁶) and restores resistance (relative viability about 1.15). D289A and D211A/D289A restore neither (PHA-L about 0; viability about 0.5–0.55) although the immunoblot shows them expressed at the level of the wild-type construct [B4–B6]. The crystal structures are consistent with these being dead enzymes: Asp211 binds the catalytic Mn²⁺ and Asp289 sits at the donor sugar [F4].

**In vivo.** In the pooled screen Mgat1 has no effect in vitro (+0.20 / −0.29) but is depleted in every Stk11-knockout in vivo arm (median −2.1 to −2.9 log2; z −8.6 to −12.2; rank 6–11 of 795) [D6, D7]. B4galt1, which acts later in building complex N-glycans, is the second-ranked background-selective gene, which supports a pathway effect rather than a guide artefact [D12]. Figure 1 shows the per-tumour data.

**Chemistry.** Potency improved 4,581-fold from the screening hit to ANT-4267, with lipophilic efficiency rising from 1.1 to 4.8 [H2]. SPR data fit a 1:1 model with matching steady-state and kinetic KD [G5]. Structures are at 1.55–2.0 Å with Rfree 0.18–0.22 [F1], and the ligand pose is the same in four independent copies (RMSD 0.5–0.8 Å) [F5].

**Verification checks that came back clean.**

- All eight human MGAT1 guide sequences target MGAT1 [A10].
- Every analysable tumour in the screen carries the guide-composition fingerprint of the background it is labelled with [D18], and Cas9 editing was equivalent in the two backgrounds before implantation [D15].
- The three sheets of the glycoproteomics workbook reconcile exactly, and replicate channels correlate at 0.99 or better [C4].
- My re-fits of the dose-response curves reproduce the client's IC50s within 1.2-fold [G2].
- The screen controls behave as expected in both screens [A6, D4].

### 3.2 Gap 1: no cellular pharmacology

This is the decisive gap. Four features of the client's own data make it more than a routine missing step.

- **The assay enzyme is a soluble fragment.** Potency was measured on MGAT1(T30–N445), with the membrane anchor removed, using a free pentasaccharide acceptor [I3]. Nothing shows the compounds reach or inhibit the native enzyme in a cell.
- **The required depth of inhibition is unknown.** Knocking out the enzymes that act after MGAT1 does not sensitise cells (MGAT2 −0.18, MAN2A1 +0.28, MGAT5 −0.15) [A8], so the phenotype depends on shutting the MGAT1 step itself. Every genetic comparison in the package is full knockout against wild type, so nothing says how complete that shut-down must be.
- **The compounds may not be able to give complete inhibition.** All four potent analogues plateau at 8.5–9.1% residual activity (standard error 0.6–1.2) [G3]; ANT-4267 stays at 9–11.5% from 1.2 µM to 100 µM. The package has no no-enzyme baseline, so I cannot tell whether this is assay background or residual turnover. See Figure 3.
- **The binding site is allosteric.** ANT-3744 sits in a pocket formed by residues 388–444, 24 Å from UDP, 26 Å from Mn²⁺ and 22 Å from the donor sugar's reactive carbon [F2, F3]. A residual-activity ceiling is a plausible property of such a site. See Figure 6.

Taken together: the genetics only compare all against nothing, and the only evidence on how far the compounds can go says about 91%. Whether that is enough is unknown. A cell experiment answers it directly.

### 3.3 Gap 2: the STK11 / checkpoint-resistance positioning

**How I read the screen groups.** The records name eight groups but never define them [I1]. The data show three selection regimes in each background (Figure 1A, [D4]):

- Groups 1 and 5 show no selection on T-cell and interferon-γ pathway genes (Cd274, Stat1 and Ptpn2 all near zero) but keep MHC-I selection, and their animal IDs form separate blocks. I read them as the T-cell-deficient hosts (nude†). Page 8 of the phenotype figures shows nude, C57BL/6 and C57BL/6 + anti-PD-1 cohorts for both backgrounds, which fits three regimes.
- Groups 2 and 6 show selection against Cd274 loss (−3.2 and −0.8) together with the strongest selection on interferon-γ sensing genes. I read them as immunocompetent with the PD-1 axis intact (C57BL/6 + isotype†).
- Groups 3, 4, 7 and 8 lose the Cd274 dependency but keep or increase the Ptpn2 dependency. I read them as immunocompetent with PD-1 blocked (C57BL/6 + anti-PD-1†). Groups 3 and 4 are indistinguishable from each other, as are 7 and 8 (no gene differs at FDR < 0.05) [D5].

The T-cell-deficient assignment is the firmer one. For the immunocompetent groups the opposite reading is possible: Groups 2 and 6 received anti-PD-1 and the paired groups are two control arms. The data alone cannot exclude it, so I checked that each conclusion below holds under both readings.

**Anti-PD-1 adds nothing to the Mgat1 dependency.**

- Screen: Mgat1 is equally depleted in Groups 6, 7 and 8 (−2.92, −2.76, −2.60; pairwise differences 0.16–0.32 log2, p ≥ 0.46) [D7, D11]. Whichever of these arms received anti-PD-1, the difference is 0.26 log2 and not significant. The screen can detect PD-1-dependent changes: Cd274, Jak2 and Ptpn11 differ at FDR < 0.05 in the same comparison. The result holds across nine analysis variants (0.11 to 0.30 log2) [D13].
- Single-gene study: at day 9, MGAT1 knockout alone gave 0.55 of control and anti-PD-1 alone 0.67. The combination gave about 0.35, against 0.37 expected from independent effects. Anti-PD-1 reduced tumours by the same proportion with or without MGAT1 (0.65 versus 0.67) [E3]. See Figure 4.
- The model itself is only partly anti-PD-1 resistant: anti-PD-1 alone still reduces Stk11-knockout tumours to 0.51 of control in the page-8 cohorts and 0.67 in the single-gene study [E5, E3].

**The dependency is only partly T-cell mediated.** In the T-cell-deficient arm† the three active Mgat1 guides already fall to 14–32% of input (3–7-fold), and to 7–13% (8–14-fold) in immunocompetent arms† [D9]. A mean-based model, which is sensitive to rare clonal outgrowths, puts the T-cell-independent part lower (−0.67 against −2.10) [D14]. Both analyses agree there are two components. The T-cell-dependent increment (−0.55 to −0.82 log2 depending on the arm, p ≤ 0.002) is specific to the Stk11-knockout background; in the wild-type background the same comparison gives +0.12 to +0.63 [D10]. This is the best support in the package for the thesis. The T-cell-independent component is unexplained; Itgb1 is the second-strongest dependency in the same arm [D17], so a non-immune mechanism cannot be excluded.

**STK11 selectivity rests on one mouse line and one Stk11 guide** [I5].

- The cross-background comparison is confounded with sequencing run set: all Stk11-knockout samples were sequenced in one set and all controls in the other [D3]. Editing efficiency was the same in both populations before implantation (r = 0.98) [D15], which helps but does not remove the confound.
- In the single-gene study, MGAT1-knockout tumours in Stk11-wild-type MC38 were larger than controls (1,774 versus 1,160 mm³) [E1], while the screen shows mild depletion in the same background [D8]. The two readouts disagree in direction.
- No human data tie the MGAT1 effect to STK11 status. The package gives no STK11 genotype or immunoblot for any human line. In the human screen, STK11 knockout is neutral (+0.12) [A9]: either the line already lacks functional STK11 or STK11 loss does not protect cells in this assay. The STK11 guides are under-represented in the no-T-cell arm (8th–29th percentile of guides) [A11], which hints that the line has a working STK11 gene, but without a plasmid reference that is only a hint. A549 could not be used because the T cells do not kill it [B8].

**The genetic ceiling is a growth delay, not regression.** Complete knockout in every tumour cell from the day of implantation gives tumours about half the size of controls (0.50 for knockout, 0.49 for the catalytic-dead rescue) [E2, E4]. The pooled screen shows 8–14-fold depletion [D9], but that measures knockout cells competing against wild-type neighbours in the same tumour and overstates what inhibiting every cell would deliver. Larger effects (0.29 of control) were seen only with adoptively transferred, TCR-engineered T cells at the higher dose [B7]. A drug given to established tumours starts from this ceiling.

**Statistical robustness of the single-gene studies is unknown.** Error bars overlap in every panel of the MC38 figure (phenotype figures, page 1). Treating the plotted bars as standard deviations, the MGAT1 effect in Stk11-knockout tumours would reach p = 0.05 only at ten mice per arm, and about 17 per arm would be needed for 80% power [E7]. The strongest in vivo result is the catalytic-dead rescue (422 versus 860 mm³) [E4], but it uses a single knockout clone, and the wild-type-rescued clone still grew at half the rate of the control pool (414 versus 893 mm³ at day 12).

### 3.4 Gap 3: mechanism and assay questions on the chemistry

- **Not competitive with UDP, which is well established.** UDP and ANT-3744 each bind slightly tighter in the other's presence (KD from 32 to 20 µM and from 0.4 to 0.2 µM), thermal shifts add (+2, +6, +8 °C), and the ternary crystal structure shows both bound [G6, F3].
- **Nothing has been measured against the acceptor or against UDP-GlcNAc.** IC50 exceeds KD for 20 of 24 analogues (median ratio 1.8) [G7]. That could reflect substrate competition, or simply the different protein constructs used for activity (T30–N445) and SPR (A104–N445) [I3]. If inhibition depends on the acceptor, potency against native glycoprotein substrates could differ from the pentasaccharide assay.
- **Concentration records do not reconcile.** The records give a top concentration of 100 µM; five of six curves are plotted to 1,000 µM [G4]. The agreement between IC50 and SPR KD suggests the plotted axes are right, but a tenfold error would move every IC50.
- **No usable reference compound.** ANT-1938 shows no SPR binding; ANT-2214 shows non-saturating, concentration-independent binding [G8]. The screening hit's IC50 (197 µM) and KD (32 µM) both exceed its solubility (11.8 µM) [G9].
- **ANT-4267 is characterised only by numbers.** The package has no structure or crystal complex for the lead, so I could not confirm it binds the same pocket.
- **The ligand touches a neighbouring molecule in all four crystal copies** [F6]. The pose is the same with two different lattice neighbours, so I do not think packing dictates it.

---

## 4. Next steps: what the studies must establish

Gates 0–2 decide whether there is an asset. Gate 4 decides what it is an asset for, needs no compound and can run in parallel. The numeric thresholds are my proposals, anchored to the client's own knockout benchmarks. The 10 µM limit in Gate 1 is about 230 times the biochemical IC50 of ANT-4267 and about a tenth of its kinetic solubility [G1, H1].

| Gate | Question | What it must establish | Comparisons the data must include | Decision rule |
|---|---|---|---|---|
| **0. Records** | Can the existing data be read unambiguously? | Group key for the screen; animal numbers, error-bar definitions and individual-animal data for every in vivo figure; STK11 status of each human line by the client's own immunoblot; ANT-4267 structure; actual concentration ranges. | Not applicable | If the group key contradicts my inference, section 3.3 must be re-run before any positioning decision. |
| **1. Cellular target inhibition** | Does the series switch off MGAT1 in intact cells? | Dose- and time-dependent loss of complex N-glycans to near-knockout depth at non-toxic concentrations, attributable to MGAT1. | Knockout cells as the ceiling (PHA-L 0.02–0.03 of control, GNA 8–9-fold [B1]) and control cells as the floor, in the same run. A potency ladder of at least five analogues spanning the 4,600-fold biochemical range; cellular rank order must match. Knockout cells re-expressing wild-type MGAT1 versus a pocket mutant designed from the crystal structure; the mutant should resist the compound. Compound on knockout cells (no further change expected). An MS glycan readout against the knockout signature (Man5 share from 19% to 40% [C2]). A direct readout of target binding in intact cells. Human and mouse cells. A mechanism-distinct glycosylation-pathway inhibitor as pharmacological positive control. | **Go:** at least 90% of the knockout lectin shift at ≤ 10 µM with a ≥ 10-fold margin to cytotoxicity, rank order preserved, pocket mutant resistant. **Stop this chemotype:** response saturates short of that, or appears only at cytotoxic concentrations. |
| **2. Functional phenocopy** | Does pharmacological inhibition reproduce the T-cell phenotype? | Compound-treated tumour cells become as sensitive to antigen-specific T cells as knockout cells, without harming the T cells. | Compound-treated control cells versus knockout cells (benchmark 0.27–0.54 versus 0.86–0.92 [B2]). Compound on knockout cells (no added effect). B2M knockout as resistance control. An antigen-negative line. Tumour-only pre-treatment versus compound present during co-culture. T-cell viability and function under compound. At least two donors. | **Go:** at least two-thirds of the knockout effect at concentrations that meet Gate 1, with T-cell function intact. |
| **3. Depth and mechanism** | How much inhibition is enough, and can this mechanism deliver it? | Whether the 8–10% floor is real turnover; mode of inhibition against acceptor and donor using a physiological glycoprotein acceptor and the full luminal enzyme; selectivity against related transferases; activity on mouse MGAT1. The residual MGAT1 activity at which T-cell protection returns. | No-enzyme and catalytic-dead enzyme controls; an orthogonal product-detection assay. Graded MGAT1 re-expression or partial knockdown against knockout and catalytic-dead cells. | **Stop this chemotype** if the phenotype needs more inhibition than the series' ceiling. |
| **4. Indication** | Is the STK11 / anti-PD-1 hypothesis right? | An STK11-by-MGAT1 interaction in human cells. In mice, the size of the T-cell, innate and non-immune components, and whether anti-PD-1 interacts. | Human: isogenic STK11 knockout and re-expression pairs with and without MGAT1 knockout; STK11-mutant NSCLC lines made recognisable by the T cells. Mouse: at least two Mgat1 guides as pools or multiple clones, in Stk11-knockout and wild-type versions of at least two syngeneic models including a lung model; immunocompetent, T-cell-deficient and fully immunodeficient hosts; a 2 × 2 design with anti-PD-1; about 17 or more animals per arm [E7]; prespecified analysis. Screen: both backgrounds sequenced in the same runs. | Positive interaction: the claim "restores anti-PD-1 sensitivity" stands. Additive: the claim becomes "PD-1-independent activity in STK11-mutant tumours", a different development path. Effect persists in fully immunodeficient hosts: it is not an immuno-oncology mechanism. |
| **5. In vivo pharmacology** (only after Gates 1–2) | Does the compound do in a tumour what the knockout does? | Exposure linked to a tumour glycan marker at the depth set by Gate 3; efficacy; host tolerability including the T-cell compartment. | Compound versus vehicle in control tumours; compound in Mgat1-knockout tumours (should add nothing); with and without anti-PD-1. Genetic benchmarks: 0.50 (knockout) and 0.49 (catalytic-dead) of control [E2, E4]. | **Advance** if tumour growth is ≤ 0.6 of control at a tolerated exposure that achieves the marker target, with no effect in Mgat1-knockout tumours. |

---

## 5. What would bring it back to "advance"

All of the following, shown in the client's own hands:

1. A lead compound removes complex N-glycans in human tumour cells to near-knockout depth at non-toxic concentrations, and a pocket-mutant MGAT1 proves the effect is on target (Gate 1).
2. The same concentrations reproduce most of the knockout's T-cell sensitisation and do not impair the T cells (Gate 2).
3. The inhibition ceiling is explained, and is compatible with the depth the phenotype needs (Gate 3).
4. The indication claim matches the data: either a demonstrated interaction with anti-PD-1, or a restated claim of PD-1-independent activity; plus an STK11 dependence shown in human cells (Gate 4).
5. The screen group key and the missing study records are supplied and agree with the analysis here (Gate 0).

If items 1 and 2 pass but item 4 does not, the asset may still have value where the T-cell effect was actually shown, namely antigen-specific T-cell killing [B7], but that is a different proposition from the one being pitched. If item 1 fails, the target may remain valid but this series is not the asset.

---

## 6. What I set aside or discounted, and why

1. **NY-ESO-1 expression across CCLE lines** (phenotype figures, page 9). Public data, not generated by the client. Not used.
2. **Four screen samples excluded** [D2]: one failed library (349 reads), two bottlenecked tumours (a third to a half of guides at zero), and one library sequenced twice, in different runs, under two animal IDs (82346 and 82364). Keeping them changes no conclusion [D13].
3. **Group identities in the screen.** Inferred, so every statement about T-cell-deficient or PD-1-blocked arms is provisional.
4. **Cross-background comparisons.** Reported but down-weighted because background and sequencing run set are confounded [D3].
5. **Mean-based screen statistics** [D14]. Kept as a sensitivity check only; a few clonal outgrowths dominate means in vivo.
6. **Guide Mgat1_3.** Clearly weaker than the other three. Kept in the primary analysis, which makes the estimates conservative.
7. **Significance of tumour-growth differences.** Not claimed anywhere; the inputs needed are not in the package.
8. **Potency of the screening hit and the two acquired compounds** [G8, G9]. Above solubility or not confirmed by SPR.
9. **Dose-response points above kinetic solubility** (ANT-3744 at 333 and 1,000 µM). The plateau is already established below the solubility limit.
10. **Glycoproteomics as a measure of knockout completeness.** Used only for direction and class-level shifts; TMT ratios are compressed and some assignments look doubtful (for example complex glycans assigned to nuclear transcription factors).
11. **SPR response levels** [G10]. UDP gives about 12% of the expected response where ANT-3744 gives 100–136%. Immobilisation levels per run are not recorded, so I raise it as a query, not a finding.
12. **Immunoblot densitometry** [B6, E6]. Semi-quantitative, from compressed images.
13. **Outside knowledge.** I did not use published cell-line genotypes, MGAT1 literature or target-class precedent as evidence. The one external reference used was the public human genome sequence, to confirm the sgRNA sequences in the records target MGAT1 [A10].

---

## 7. Record and data-integrity points to resolve with the client

| Issue | Where | Why it matters |
|---|---|---|
| Screen group codes undefined; records say 30 C57BL/6 and 15 nude mice, file holds 141 tumours in eight groups | Records §2; count matrix [I1] | Determines every immune-dependence conclusion |
| Same library under two animal IDs (82346 / 82364) | Count matrix [D2] | Sample tracking |
| Background confounded with sequencing run set | Demultiplexing file [D3] | Limits the STK11-selectivity claim |
| One Group 2 tumour (82360) has the immune profile of the PD-1-blocked arms | Count matrix | Possible label or dosing error; no effect on conclusions |
| About 28 cells per guide at implantation | Records §2 [D16] | Explains heavy per-tumour noise; results rely on pooling 13–20 tumours |
| No animal numbers, error-bar definitions or statistics on any in vivo figure; models not named on pages 4 and 5 | Phenotype figures | Effect sizes cannot be tested |
| Anti-PD-1 and isotype curves are superimposed up to day 4 of "treatment" | Phenotype figures p1 | Unclear when dosing began |
| The page-1 caption ("library-containing populations") describes the page-8 cohorts, not the single-gene curves printed above it | Phenotype figures [I4] | Traceability |
| Anti-PD-1 at 5 mg/kg in the screen, 10 mg/kg in single-gene studies | Records §2 [I2] | Comparability |
| In vivo rescue uses one knockout clone; no MGAT1 immunoblot for the MC38 lines; residual STK11 ranges from 4% to 19% across lines | Phenotype figures p6, p7, p11 [E4, E6] | Clonal and knockout-efficiency confounds |
| Mutant-enzyme activity assay described but no data supplied | Records §6.2 | Biochemical proof that the mutants are dead |
| Reagents listed with no data in the package: PD-L1 and PTPN2 guides, antibodies to PD-L1 and CD276, D211A single mutant | Records §1, §8 [I6] | Suggests experiments exist that I have not seen |
| One Stk11 guide and one mouse Mgat1 guide for all MC38 single-gene work | Records §1 [I5] | Off-target effects of the Stk11 guide cannot be excluded |
| Top concentration 100 µM in records, 1,000 µM on five plots | Records §6.3; assay figures p1 [G4] | Could shift every IC50 tenfold |
| No no-enzyme baseline for the activity assay | Assay figures p1 | Needed to interpret the 8–10% floor |
| Unit and label slips: "18.6 nM (9.3 µM final)", "1 mM BSA", "HTS ANT-3744" | Records §6.2, §6.5; assay figures p4 [I4] | Minor |
| PDF metadata dated 18 Nov 2026; records headed "Compiled 18 August 2026"; data cut given to me as 1 Nov 2026 | File properties | Confirm we hold the same version |

---

## Figures

![Figure 1](figures/fig1_invivo_screen_mgat1.png)

**Figure 1.** In vivo pooled screen. A: control genes used to infer the group identities, and the N-glycan genes. B: Mgat1 depletion per tumour.

![Figure 2](figures/fig2_coculture_screen.png)

**Figure 2.** Human genome-wide T-cell co-culture screen.

![Figure 3](figures/fig3_dose_response_refit.png)

**Figure 3.** Enzyme dose-response curves re-read from the client's figure and re-fitted.

![Figure 4](figures/fig4_single_gene_invivo_digitised.png)

**Figure 4.** Single-gene in vivo studies, endpoint values re-read from the client's figures.

![Figure 5](figures/fig5_glycoproteomics.png)

**Figure 5.** Glycoproteomics of MGAT1-knockout and control cells.

![Figure 6](figures/fig6_structure_site.png)

**Figure 6.** Position of ANT-3744 relative to the catalytic centre in the ternary crystal structure.

---

## Appendix A. Evidence ledger

| ID | Statement | Value | Client source | How obtained | Script | Output |
|---|---|---|---|---|---|---|
| A1 | Co-culture screen size | 7,960,054 UMI rows; 77,079 sgRNAs; 19,114 genes analysed; 989 non-targeting guides; one sample per arm | coculture_screen_umi_counts.csv.gz; experimental_records.pdf s3 | re-computed | 02_coculture_screen.py | tables/coculture_analysis_log.txt |
| A2 | Read depth per arm | 56.33 M (tumour only) vs 49.95 M (+T cells); scaling factor 0.889 from non-targeting guides | coculture_screen_umi_counts.csv.gz | re-computed | 02_coculture_screen.py | tables/coculture_analysis_log.txt |
| A3 | MGAT1 gene-level effect | log2FC -0.84 (bootstrap 95% CI -1.12 to -0.63); rank 23 of 19,114; z = -8.2; ~44% fewer surviving cells than controls | coculture_screen_umi_counts.csv.gz (rows gene_symbol=MGAT1) | re-computed; CI by resampling UMIs within guides | 02_coculture_screen.py | tables/coculture_focus_genes.csv; figures/fig2 |
| A4 | MGAT1 per-sgRNA effects | -1.17, -1.10, -0.65, -0.46 (4 of 4 below the 95% range of non-targeting guides, +/-0.40) | coculture_screen_umi_counts.csv.gz | re-computed | 02_coculture_screen.py | tables/coculture_mgat1_guides.csv |
| A5 | Null distribution | non-targeting guide SD 0.204; 4-guide pseudo-gene SD 0.102; most extreme of 200,000 null draws -0.455 | coculture_screen_umi_counts.csv.gz (genetype=NegCtrl) | re-computed | 02_coculture_screen.py | tables/coculture_analysis_log.txt |
| A6 | Screen positive controls behave as expected | resistance: CTAG1B +1.64, B2M +1.43, IFNGR2 +1.19, STAT1 +1.08, TNFRSF1A +1.07; sensitisers: CFLAR -1.92 (rank 1), SLC35A1 -1.45 (rank 2), PTPN2 -1.33 (rank 3) | coculture_screen_umi_counts.csv.gz | re-computed | 02_coculture_screen.py | tables/coculture_focus_genes.csv |
| A7 | N-glycan / sugar-nucleotide / sialylation genes among the top 40 sensitisers | SLC35A1 (2), GFPT1 (4), ALG2 (5), SLC35A2 (7), UGP2 (9), GALE (22), MGAT1 (23), UAP1 (24), CMAS (25), DAD1 (26), MOGS (33), TMEM165 (36) | coculture_screen_umi_counts.csv.gz | re-computed | 02_coculture_screen.py | tables/coculture_gene_level.csv |
| A8 | Branching enzymes downstream of MGAT1 are not hits | MGAT2 -0.18 (CI -0.48 to 0.06; rank 2,627); MAN2A1 +0.28; MGAT5 -0.15; B4GALT1 -0.25 | coculture_screen_umi_counts.csv.gz | re-computed | 02_coculture_screen.py | tables/coculture_focus_genes.csv |
| A9 | STK11 and PD-L1 knockouts are neutral in the human co-culture system | STK11 +0.12 (CI -0.17 to 0.37); CD274 -0.14 (CI -0.33 to 0.02) | coculture_screen_umi_counts.csv.gz | re-computed | 02_coculture_screen.py | tables/coculture_focus_genes.csv |
| A10 | All 8 human MGAT1 sgRNAs (4 library + 4 validation) target the MGAT1 locus; the two sets share no guide | chr5:180,791,702-180,792,841 (GRCh38), NGG PAM for all 8 | coculture_screen_umi_counts.csv.gz (sgrna_sequence); experimental_records.pdf s1 | sequence search against a public reference genome (only use of an external reference) | 02_coculture_screen.py | tables/guide_identity_check_human_MGAT1.csv |
| A11 | Guide representation in the no-T-cell arm (hint only; no plasmid reference supplied) | MGAT1 guides 87-185 UMIs (38th-94th percentile of targeting guides): no sign of an in vitro fitness cost. STK11 guides 38-76 UMIs (8th-29th percentile; gene rank 1,630 of 18,681 for low representation). Median guide: essential-gene set 16, non-targeting 119, all targeting 102 UMIs | coculture_screen_umi_counts.csv.gz | re-computed | 02_coculture_screen.py | tables/coculture_guide_representation_no_Tcell_arm.csv |
| B1 | Knockout efficiency by lectin flow | PHA-L 0.02 (A375) and 0.03 (NCI-H1703) of control; GNA 8.2x and 8.8x | phenotype_figures.pdf p2 | digitised (bar heights vs axis ticks) | 06b_cell_assay_and_immunoblot_reads.py | tables/digitised_lectin_and_competition_assays.csv |
| B2 | Competition assay, NCI-H1703 (relative viability at E:T 0.2 / 0.4) | sgNTC 0.92/0.86; sgB2M 1.86/1.96; four MGAT1 guides 0.27-0.46 / 0.27-0.54 | phenotype_figures.pdf p3 | digitised (dot positions vs axis ticks) | 06b_cell_assay_and_immunoblot_reads.py | tables/digitised_lectin_and_competition_assays.csv |
| B3 | Competition assay, NCI-H1755 (E:T 0.2) | sgNTC 0.80; sgB2M 1.85; four MGAT1 guides 0.17-0.58 (replicate dots; guide means 0.17-0.50) | phenotype_figures.pdf p3 | digitised (dot positions vs axis ticks) | 06b_cell_assay_and_immunoblot_reads.py | tables/digitised_lectin_and_competition_assays.csv |
| B4 | cDNA rescue - PHA-L MFI | sgMGAT1+vector ~0; +WT 5.3e6 (sgNTC+vector 6.7e6); +D289A ~0; +D211A/D289A ~0 (n=2) | phenotype_figures.pdf p5 left | read from figure | 06_phenotype_figures_digitised.py | tables/digitised_other_readouts.csv |
| B5 | cDNA rescue - T-cell killing (relative viability, two donors) | sgMGAT1 background: vector ~0.7; WT ~1.15; D289A ~0.55; D211A+D289A ~0.5-0.55. sgNTC background: all four constructs ~1.1-1.2 (n=2 per donor; +/-0.03 reading error) | phenotype_figures.pdf p5 right | read from figure | 06_phenotype_figures_digitised.py | tables/digitised_other_readouts.csv |
| B6 | Mutant MGAT1 proteins are expressed | WT, D289A and D211A+D289A cDNA bands of similar intensity, all far above endogenous (bands saturated); no band in sgMGAT1+vector | phenotype_figures.pdf p11 (NCI-H1703 immunoblot) | visual + densitometry (semi-quantitative) | 06b_cell_assay_and_immunoblot_reads.py | tables/immunoblot_densitometry.csv |
| B7 | Adoptive T-cell transfer model, day 19 tumour volume (sgNTC vs sgMGAT1) | control T 1929 vs 1645 (ratio 0.85); 1e6 TCR-T 1297 vs 617 (0.48); 2e6 TCR-T 598 vs 171 (0.29) | phenotype_figures.pdf p4 | digitised (manual read of 3x crops) | 06_phenotype_figures_digitised.py | tables/digitised_tumour_endpoints.csv; figures/fig4 |
| B8 | A549 is not killed by the NY-ESO-1 TCR-T cells | viable cells 1.08 with TCR-T vs 1.08 with untransduced T; NCI-H1703 ~0.10, NCI-H1755 ~0.05 | phenotype_figures.pdf p10 | read from figure | 06_phenotype_figures_digitised.py | tables/digitised_other_readouts.csv |
| C1 | Glycoproteomics coverage | 2,687 intact glycopeptides; 910 sites; 524 proteins; 150 glycan compositions; 16 TMT channels | glycoproteomics_site_quant.xlsx (sheet IGP_quant) | re-computed | 03_glycoproteomics.py | tables/glyco_analysis_log.txt |
| C2 | Glycan-class share of summed intensity, control -> KO | Man5 18.2-20.4% -> 39.5-40.8%; complex 6.3-6.5% -> 3.4-3.9%; hybrid 2.6-3.5% -> 1.6-1.9% | glycoproteomics_site_quant.xlsx (sheet IGP_quant) | re-computed | 03_glycoproteomics.py | tables/glyco_class_share_per_channel.csv; figures/fig5 |
| C3 | Per-glycopeptide KO/control log2 ratio by class | Man5 median +1.20 (A375) / +1.03 (H1703), 298 and 270 of 532 >2-fold up; complex median -0.11 / -0.39, 77 and 113 of 379 >2-fold down | glycoproteomics_site_quant.xlsx (sheet IGP_quant) | re-computed | 03_glycoproteomics.py | tables/glyco_class_summary.csv |
| C4 | Replicate and cross-line consistency | within-condition channel r 0.992-0.998; KO vs control r 0.87-0.90; A375 vs H1703 log2FC r = 0.63 | glycoproteomics_site_quant.xlsx (sheet IGP_quant) | re-computed | 03_glycoproteomics.py | tables/glyco_analysis_log.txt |
| C5 | Example site CD276 (B7-H3) Asn91 | complex glycoforms: three of four -1.5 to -2.4 log2 in A375 (fourth -0.2, n.s.); all four -0.8 to -3.3 in H1703; Man5 +2.4 / +1.9 | glycoproteomics_site_quant.xlsx (sheet IGP_quant) | re-computed | 03_glycoproteomics.py | tables/glyco_selected_surface_proteins.csv |
| C6 | PD-L1 (CD274) not observed in the glycoproteome | 0 glycopeptides | glycoproteomics_site_quant.xlsx (sheet IGP_quant) | re-computed | 03_glycoproteomics.py | tables/glyco_analysis_log.txt |
| D1 | In vivo screen design as found in the files | 3,580 sgRNAs = 795 genes x 4 + 400 non-targeting; 159 samples = 141 tumours + 6 baseline + 6 in vitro endpoint + 6 plasmid; 8 tumour groups of 15-21 | crispr_invivo_guide_counts.csv.gz; crispr_invivo_ngs_demux.csv.gz; experimental_records.pdf s2 | re-computed | 01_invivo_screen.py | tables/invivo_sample_qc.csv |
| D2 | Samples excluded | Group7_STK11_82431 (349 reads); Group3_NTC_82276 (1,595 guides at zero, Gini 0.92); Group4_NTC_82321 (1,181 at zero, Gini 0.88); Group3_NTC_82364 = duplicate of Group3_NTC_82346 (Spearman 0.98 on non-targeting guides vs <=0.29 for the other 9,729 pairs, median 0.06) | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_sample_qc.csv; tables/invivo_top_sample_pair_correlations.csv |
| D3 | Background is confounded with sequencing run set | all 79 Stk11-KO-background samples in run set SG01; all 80 NTC-background samples in SG02 | crispr_invivo_ngs_demux.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_sample_qc.csv |
| D4 | Marker genes used to infer the undefined group codes (median log2FC; G1/G2/G3/G4 \| G5/G6/G7/G8) | Cd274 +0.74/-3.22/-0.39/+0.15 \| +0.64/-0.78/-0.27/+0.13; Ptpn2 +0.47/-1.47/-2.21/-2.39 \| -0.17/-0.94/-1.67/-1.56; Stat1 +0.76/-2.38/-1.04/-1.19 \| +0.41/-1.38/-0.78/-0.92; B2m -2.77/-3.54/-3.01/-3.43 \| -2.32/-3.70/-3.25/-3.31 | crispr_invivo_guide_counts.csv.gz | re-computed; group identity INFERRED | 01_invivo_screen.py | tables/invivo_group_inference_marker_genes.csv; figures/fig1 |
| D5 | G3 vs G4 and G7 vs G8 are indistinguishable | 0 of 795 genes at FDR<0.05 in either comparison (minimum FDR 1.0 and 0.65) | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_contrast_replicate_arms_*.csv |
| D6 | Mgat1 has no fitness effect in vitro | median log2FC +0.20 (NTC) and -0.29 (Stk11-KO) vs pre-implant baseline (n=3 each) | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_mgat1_by_group.csv |
| D7 | Mgat1 depletion in vivo, Stk11-KO background (median per-tumour log2FC; 95% CI; z vs non-targeting null; rank of 795) | G5 -2.10 (-2.37 to -1.26; z -8.6; rank 8); G6 -2.92 (-3.16 to -2.38; z -10.9; rank 6); G7 -2.76 (z -11.6; rank 8); G8 -2.60 (z -12.2; rank 11) | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_mgat1_by_group.csv; figures/fig1 |
| D8 | Mgat1 depletion in vivo, NTC (Stk11-WT) background | G1 -1.24 (z -3.3; rank 76); G2 -1.12 (z -3.9; rank 79); G3 -0.61 (rank 171); G4 -0.29 (rank 263) | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_mgat1_by_group.csv |
| D9 | Typical-tumour representation of the three active Mgat1 guides (fraction of input) | G5 0.14-0.32 (3-7-fold depleted); G6-G8 0.07-0.13 (8-14-fold); 59% of active-guide observations >4-fold depleted in G5 vs 3.9% of non-targeting; 82-87% in G6-G8 | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_mgat1_by_group.csv |
| D10 | T-cell-dependent increment in Stk11-KO tumours (immunocompetent arms minus G5) | G6 minus G5: -0.82 log2 (95% CI -1.66 to -0.14; Mann-Whitney p = 0.0019; rank 17 of 795); G7+G8 minus G5: -0.55 (CI -1.40 to -0.19; p = 0.0004); all three minus G5: -0.61 (CI -1.49 to -0.21; p = 0.0002). Three active guides only: -1.10 to -1.21. Same contrasts in NTC background: +0.12 (G2 minus G1; p = 0.96) and +0.63 (all minus G1; p = 0.08) | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_mgat1_contrasts.csv |
| D11 | No difference between the PD-1-axis-intact and PD-1-blocked arms ((G7+G8) minus G6; (G3+G4) minus G2) | Stk11-KO: +0.26 (95% CI -0.34 to +0.50; p = 0.67; rank 715 of 795 for extra depletion in G7+G8); pairwise G6-G7 -0.16 (p = 0.97), G6-G8 -0.32 (p = 0.50), G7-G8 -0.16 (p = 0.46). NTC: +0.73 (CI 0.13 to 1.42; p = 0.03). Zero-count frequency of active guides unchanged (10/51 vs 20/105). Sign depends on which arm is anti-PD-1 (inferred); magnitude does not | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_mgat1_contrasts.csv; tables/invivo_mgat1_pairwise_immunocompetent_arms.csv; tables/invivo_mgat1_by_group.csv |
| D12 | Stk11-KO vs NTC background (batch-confounded) | isotype arms -1.80 (p = 0.0002; rank 1 of 795); PD-1-blocked arms -2.26 (p = 7e-11; rank 1); T-cell-deficient arms -0.87 (p = 0.02; rank 52); all in vivo -1.73 (rank 1; B4galt1 rank 2) | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_mgat1_contrasts.csv |
| D13 | Sensitivity of the Mgat1 conclusions to analysis choices (9 variants) | PD-1-blocked vs isotype +0.11 to +0.30 in every variant (p 0.52-0.95); immunocompetent vs T-cell-deficient -0.46 to -1.21 (p 0.0003-0.025); Stk11-KO vs NTC in isotype arms -1.08 to -2.29 | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_mgat1_sensitivity.csv |
| D14 | Mean-based cross-check (edgeR negative-binomial GLM) | G5 -0.67 (z -4.0; rank 43); G6 -2.25 (rank 12); G7 -2.54 (rank 6); G8 -2.65 (rank 8); G6 vs G5 -1.58; PD-1-blocked vs isotype -0.34 (z -1.5; rank 130) | crispr_invivo_guide_counts.csv.gz | re-computed | 01b_invivo_screen_edgeR_crosscheck.R | tables/invivo_mgat1_edgeR_crosscheck.csv |
| D15 | Cas9 editing parity between the two backgrounds before implantation | guide dropout baseline-vs-plasmid: r = 0.978, slope 0.97 (200 guides >4-fold depleted: mean -3.39 vs -3.30) | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_analysis_log.txt |
| D16 | Library coverage at implantation | 1e5 cells / 3,580 guides = 28 cells per guide per tumour | experimental_records.pdf s2; crispr_invivo_guide_counts.csv.gz | arithmetic | 01_invivo_screen.py | tables/invivo_analysis_log.txt |
| D17 | Itgb1 is a co-dependency in the same arm | Itgb1 median log2FC -2.88 in G5 (rank 2 of 795); -3.25 / -2.74 / -2.60 in G6-G8; -1.07 to -1.91 in NTC arms | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_group_inference_marker_genes.csv |
| D18 | No tumour appears to be assigned to the wrong background | each tumour carries the guide-composition fingerprint of its labelled population: correlation with the (Stk11-KO minus NTC) baseline difference is negative for 70 of 71 NTC-labelled tumours and positive for all 69 analysable Stk11-KO-labelled tumours; the one exception (Group4_NTC_82321, r = +0.01) is a bottlenecked sample already excluded | crispr_invivo_guide_counts.csv.gz | re-computed | 01_invivo_screen.py | tables/invivo_sample_qc.csv (column background_fingerprint_r); tables/invivo_analysis_log.txt |
| E1 | MC38 Stk11-WT: MGAT1-KO tumours are not smaller | day 25: sgNTC 1160 (346-1982) vs sgMGAT1 1774 (910-2638) mm3; ratio 1.53 | phenotype_figures.pdf p1 left | digitised | 06_phenotype_figures_digitised.py | tables/digitised_tumour_endpoints.csv; figures/fig4 |
| E2 | MC38 sgSTK11: MGAT1-KO tumours are smaller | day 19: sgNTC 1085 (578-1598) vs sgMGAT1 545 (105-996) mm3; ratio 0.50 | phenotype_figures.pdf p1 middle | digitised | 06_phenotype_figures_digitised.py | tables/digitised_tumour_endpoints.csv |
| E3 | MC38 sgSTK11 +/- anti-PD-1, day 9 of treatment | NTC IgG2a 1131; NTC anti-PD-1 756 (0.67); sgMGAT1 IgG2a 619 (0.55); sgMGAT1 anti-PD-1 ~400 (0.35); Bliss-additive expectation 0.37 = 414 mm3; anti-PD-1 effect 0.65 within sgMGAT1 vs 0.67 within NTC | phenotype_figures.pdf p1 right | digitised; arithmetic | 06_phenotype_figures_digitised.py | tables/digitised_tumour_endpoints.csv; tables/phenotype_digitisation_log.txt |
| E4 | In vivo cDNA rescue (sgSTK11 + sgMGAT1 clone A-F5) | day 19: WT 860 (616-1112) vs D211A+D289A 422 (257-590) mm3; ratio 0.49. sgSTK11+sgNTC pool: 893 (WT cDNA) vs ~800 (mutant) at day 12; WT-rescued clone only 414 at day 12 | phenotype_figures.pdf p7, p11 (schematic) | digitised | 06_phenotype_figures_digitised.py | tables/digitised_tumour_endpoints.csv |
| E5 | Page-8 cohorts: MC38 sgNTC and sgSTK11 in nude / C57BL/6 / C57BL/6 + anti-PD-1 | MC38 sgNTC day 8: 935 / 384 / ~94 mm3 (anti-PD-1 T/C 0.24); MC38 sgSTK11 day 7: 964 / ~1262 / ~640 (T/C 0.51) | phenotype_figures.pdf p8 | digitised (manual read of 2x crops) | 06_phenotype_figures_digitised.py | tables/digitised_page8_cohorts.csv |
| E6 | Residual STK11 protein in the MC38 engineered panel (relative to sgNTC line) | STK11-KO 0.04; double KO 0.06; STK11-KO+WT cDNA 0.11; STK11-KO+mutant cDNA 0.19; double KO+WT 0.04; double KO+mutant 0.14 | phenotype_figures.pdf p6 (immunoblot) | densitometry of the image (semi-quantitative) | 06b_cell_assay_and_immunoblot_reads.py | tables/immunoblot_densitometry.csv |
| E7 | Illustrative power | treating plotted bars as SD (670 and 308 mm3): p = 0.05-0.17 for the sgMGAT1 effect at n = 10-5 per arm; ~17 mice per arm needed for 80% power at the observed effect size | phenotype_figures.pdf p1 right | arithmetic on digitised values | 06_phenotype_figures_digitised.py | tables/phenotype_digitisation_log.txt |
| F1 | Structure quality | apo 1.65 A (Rfree 0.207); UDP 1.55 A (0.177); UDP-GlcNAc 2.00 A (0.220); ANT-3744 2.00 A (0.208); ANT-3744+UDP 2.01 A (0.203); two molecules per asymmetric unit in each | MGAT1_*.cif (_refine, _reflns) | read from files | 04_structures.py | tables/structure_summary.csv |
| F2 | ANT-3744 pocket | Tyr388, Thr389, Gly390, Phe394, Gly410, Pro412, Pro434, Trp437, Glu438, Gly439, Tyr440, Asp441, (Pro442), Trp444; amide N-H to Gly439 O 2.7-2.8 A; 67% of ligand surface buried | MGAT1_C3744.cif; MGAT1_C3744_UDP.cif | re-computed (4 A cutoff; Shrake-Rupley surface) | 04_structures.py | tables/structure_ANT3744_contacts.csv; tables/structure_ANT3744_burial.csv |
| F3 | Distance from ANT-3744 to the catalytic centre (ternary complex, chains A/B) | to UDP 23.9/24.2 A (closest atoms), 33 A centroid-centroid; to Mn2+ 25.8/26.2 A; to Asp289 16.1/16.2 A; to Asp211 27.4/27.6 A; to the donor GlcNAc anomeric carbon 22.3/22.4 A (after superposing the UDP-GlcNAc complex) | MGAT1_C3744_UDP.cif; MGAT1_UDP_GlcNAc.cif | re-computed | 04_structures.py | tables/structure_ANT3744_distances_to_active_site.csv; figures/fig6 |
| F4 | Catalytic residues targeted by the rescue mutants | Asp211 coordinates Mn2+ (2.15-2.21 A); Asp289 lies at the donor GlcNAc (3.5 A from C6) | MGAT1_UDP_GlcNAc.cif; MGAT1_C3744_UDP.cif | re-computed | 04_structures.py | tables/structure_analysis_log.txt |
| F5 | Pose reproducibility | ligand heavy-atom RMSD 0.5-0.8 A across 4 independent copies (2 crystal forms); only the aminomethyl N moves (2.5-2.7 A) | MGAT1_C3744.cif; MGAT1_C3744_UDP.cif | re-computed | 04_structures.py | tables/structure_analysis_log.txt |
| F6 | Lattice contacts at the ligand | symmetry-mate Glu274/Glu278 (3.0-3.2 A) in two copies and Glu133 (3.8-3.9 A) in the other two | MGAT1_C3744.cif; MGAT1_C3744_UDP.cif | re-computed | 04_structures.py | tables/structure_ANT3744_contacts.csv |
| F7 | Induced fit is local | residues 435-441 shift up to 4.4-4.5 A (Glu438) on ligand binding; rest of the protein CA RMSD 0.5-0.6 A; active-site loop 315/316-331/332 disordered in apo and binary complex, ordered with UDP-GlcNAc and in the ternary complex | all five CIFs | re-computed | 04_structures.py | tables/structure_analysis_log.txt; tables/structure_summary.csv |
| F8 | Ligand order | B-factor 30-38 A2 (neighbours 24-35) in 3 copies; 60 (neighbours 52) in ternary chain B; occupancy 1.0 | MGAT1_C3744.cif; MGAT1_C3744_UDP.cif | re-computed | 04_structures.py | tables/structure_ligand_bfactors.csv |
| F9 | ANT-3744 identity | N-[2-(aminomethyl)-6-(N-methylacetamido)pyridin-4-yl]-2-(cyclobutyloxy)quinoline-4-carboxamide; C23H25N5O3; MW 419.5; 31 heavy atoms; TPSA 110 | MGAT1_C3744_UDP.cif (_chem_comp); compound_properties.csv | read from file; descriptors re-computed | 04_structures.py | tables/structure_analysis_log.txt |
| G1 | Client IC50s (UDP-Glo) | ANT-0592 197 uM; ANT-2118 25.6; ANT-1476 2.02; ANT-3744 0.814; ANT-3105 0.543; ANT-4267 0.043 uM; ANT-1938 >100; ANT-2214 74 | compound_properties.csv | read from file | - | tables/biochem_compound_metrics.csv |
| G2 | Independent re-fit of the digitised curves | absolute IC50 (bottom fixed at 0): 204 / 24.4 / 2.08 / 0.70 / 0.50 / 0.039 uM - within 1.2x of the client values; Hill slopes 0.81-1.23 | assay_figures.pdf p1 | digitised + 4PL fit | 05_biochem_biophys.py | tables/biochem_dose_response_refits.csv; figures/fig3 |
| G3 | Residual-activity plateau | fitted lower asymptote 8.6% (ANT-1476), 9.0% (ANT-3105), 8.5% (ANT-3744), 9.1% (ANT-4267), SE 0.6-1.2; i.e. ~91% maximal inhibition; ANT-4267 flat at 9-11.5% from 1.2 to 100 uM | assay_figures.pdf p1 | digitised + 4PL fit | 05_biochem_biophys.py | tables/biochem_dose_response_refits.csv; tables/biochem_dose_response_digitised.csv |
| G4 | Concentration range inconsistency | records: top concentration 100 uM, 0.5 ul of 10 mM stock; five of six curves plotted to 1,000 uM (ANT-4267 to 100 uM) | experimental_records.pdf s6.3; assay_figures.pdf p1 | comparison | 05_biochem_biophys.py | tables/biochem_dose_response_refits.csv |
| G5 | SPR affinities | UDP KD 31-32 uM; ANT-3744 KD 0.4 uM (steady-state 0.38 = kinetic 0.38); ANT-4267 0.07 (steady-state) / 0.03 (kinetic) | spr_binding.csv; spr_competition.csv; compound_properties.csv | read from files | - | tables/biochem_analysis_log.txt |
| G6 | Binding is not competitive with UDP | UDP KD 32 -> 20 uM with 20 uM ANT-3744 (50x KD); ANT-3744 KD 0.4 -> 0.2 uM with 5 mM UDP (156x KD); DSF dTm +2 C (UDP), +6 C (ANT-3744), +8 C (both) = additive | spr_competition.csv; dsf_thermal_shift.csv; assay_figures.pdf p3-p4 | read from files; arithmetic | 05_biochem_biophys.py | tables/biochem_analysis_log.txt |
| G7 | Series SAR: inhibition tracks binding | 24 resolved points: log-log r = 0.95; median IC50/KD 1.8 (IQR 1.2-3.8); IC50 > KD for 20 of 24 | assay_figures.pdf p5 | digitised | 05_biochem_biophys.py | tables/biochem_ic50_vs_kd_digitised.csv |
| G8 | The two acquired compounds are not validated binders | ANT-1938: IC50 >100 uM (40% inhibition at 100 uM, n=2), flat SPR response; ANT-2214: 74 uM (60% inhibition, n=2), non-saturating, concentration-independent SPR response with no dissociation | assay_figures.pdf p2; compound_properties.csv | read from figure | 05_biochem_biophys.py | memo s3.4 |
| G9 | HTS hit ANT-0592 values exceed its solubility | IC50 197 uM and KD 32.2 uM (flagged *) vs kinetic solubility 11.8 uM; 85% and 72% activity remaining at 37 and 109 uM (screen was run at 50 uM) | compound_properties.csv; assay_figures.pdf p1; experimental_records.pdf s6.3 | read from files; digitised | 05_biochem_biophys.py | tables/biochem_compound_metrics.csv; tables/biochem_dose_response_digitised.csv |
| G10 | SPR response levels | ANT-3744 plateau ~115 RU on ~9,000 RU surface (136% of the 1:1 expectation, 85 RU); ~33 RU on ~3,500 RU in 5 mM UDP (100%); UDP plateau ~10 RU (12% of expectation if on a ~9,000 RU surface) | assay_figures.pdf p2-p3; experimental_records.pdf s6.4 | read from figure; arithmetic | 05_biochem_biophys.py | tables/biochem_analysis_log.txt |
| H1 | Lead properties | ANT-3744: MW 419, logD 2.2, TPSA 110, solubility 178 uM, hepatocyte CLint 3.2; ANT-4267: MW 478, logD 2.6, TPSA 108, solubility 96.4 uM, CLint <1.35 ul/min/1e6 cells | compound_properties.csv | read from file | - | tables/biochem_compound_metrics.csv |
| H2 | Optimisation efficiency | ANT-4267 is 4,581-fold more potent than the hit; LLE (pIC50 - logD) 1.1 (hit) -> 3.9 (ANT-3744) -> 4.8 (ANT-4267); LE of ANT-3744 0.27 kcal/mol per heavy atom | compound_properties.csv | arithmetic | 05_biochem_biophys.py | tables/biochem_compound_metrics.csv |
| H3 | Cellular, selectivity, permeability, PK, PD, efficacy and safety data for any compound | none in the package | compound_properties.csv; assay_figures.pdf; phenotype_figures.pdf; experimental_records.pdf | inventory of all 16 files | - | memo s3.2 |
| I1 | Animal numbers in the records do not reconcile with the count matrix | records: C57BL/6 n = 30, nude n = 15; file: 141 tumour samples in 8 groups (18/17/15/21 and 17/17/18/18); group codes not defined | experimental_records.pdf s2, s2.1; crispr_invivo_guide_counts.csv.gz | comparison | 01_invivo_screen.py | tables/invivo_sample_qc.csv |
| I2 | Anti-PD-1 dose differs between studies | 5 mg/kg (pooled screen) vs 10 mg/kg (single-gene studies) | experimental_records.pdf s2 | read from file | - | memo s7 |
| I3 | Assay conditions | 5 nM MGAT1(T30-N445), 50 uM 3a,6a-mannopentaose, 130 uM UDP-GlcNAc, 60 min; SPR and crystallography on A104-N445; HTS of ~500,000 compounds at 50 uM | experimental_records.pdf s6 | read from file | - | memo s3.4 |
| I4 | Unit / labelling slips | DSF protein "18.6 nM (9.3 uM final)"; "1 mM BSA"; DSF legend "HTS ANT-3744"; the phenotype_figures.pdf p1 caption (library-containing populations) describes the p8 cohorts rather than the single-gene curves on p1 | experimental_records.pdf s6.2, s6.5; assay_figures.pdf p4; phenotype_figures.pdf | read from files | - | memo s7 |
| I5 | Mouse studies use one guide per gene | one mouse Stk11 guide (sgSTK11) and one mouse Mgat1 guide (sgMGAT1_4 = library guide Mgat1_4) are listed for all single-gene MC38 work; the Stk11-knockout screen background was made with a single Stk11 guide | experimental_records.pdf s1, s2; crispr_invivo_guide_counts.csv.gz | read from file; sequence match | 01_invivo_screen.py | memo s3.3 |
| I6 | Reagents listed in the records with no corresponding data in the package | PD-L1 and PTPN2 guides (human); antibodies to PD-L1, CD276, GAPDH; D211A single mutant; activity data for the three mutant enzymes | experimental_records.pdf s1, s6.2, s8 | inventory | - | memo s7 |

---

## Appendix B. Methods in brief

- **In vivo screen** (`scripts/01_invivo_screen.py`). Counts were normalised per sample to the median non-targeting guide, and log2 fold-change was taken against the pre-implant baseline of the same background (pseudocount 10). The gene score per tumour is the mean of its four guides; the group value is the median across tumours. The null comes from 5,000 random sets of four non-targeting guides. Contrasts use tumours as replicates (Mann-Whitney; bootstrap confidence intervals). Duplicate libraries were sought by correlating non-targeting guides between tumours. `scripts/01b_invivo_screen_edgeR_crosscheck.R` repeats the key contrasts with a negative-binomial model.
- **Co-culture screen** (`scripts/02_coculture_screen.py`). Reads were summed over UMIs per guide and scaled to the 989 non-targeting guides; the gene score is the mean log2 fold-change of four guides. Confidence intervals come from resampling UMIs within guides.
- **Glycoproteomics** (`scripts/03_glycoproteomics.py`). Glycan compositions were classed by HexNAc and hexose count; log2 ratios are knockout over control from the reporter intensities as supplied.
- **Structures** (`scripts/04_structures.py`). Contacts (4 Å, including symmetry mates), distances, B-factors, superpositions and ligand chemistry were computed from the five coordinate files.
- **Biochemistry** (`scripts/05_biochem_biophys.py`). Dose-response points and the IC50-versus-KD scatter were read from the figures by image analysis against the axis ticks and re-fitted with a four-parameter logistic.
- **Phenotype figures** (`scripts/06_phenotype_figures_digitised.py`). Endpoint values were read by colour-mask analysis against the axis ticks and checked by eye on enlarged crops.
- **Cell assays and immunoblots** (`scripts/06b_cell_assay_and_immunoblot_reads.py`). Lectin bars and competition-assay points were read the same way; immunoblot bands were integrated per lane after local background subtraction.
- **Consistency check** (`scripts/09_verify_memo_numbers.py`). Re-reads the output tables and confirms 76 headline numbers quoted in this memo.

## Appendix C. Files delivered

- `MGAT1_recommendation_memo.md` / `.html`: this memo.
- `evidence_ledger.csv`: 78 entries linking each number to its source and analysis.
- `figures/`: the six figures above.
- `tables/`: all result tables and analysis logs.
- `scripts/`: the scripts that produce them (numbered in run order).
- `extracted_figures/`: page images and text extracted from the three client PDFs, as used for digitisation.
