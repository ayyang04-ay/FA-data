"""Re-fit of the UDP-Glo dose-response curves from points digitised off assay_figures.pdf p.1
(points: tables/ic50_points_digitised.json, produced by digitisation/ic50_digit.py via blob detection on the embedded figure; +-1-2 % activity accuracy).
4-parameter logistic, free top/bottom/Hill; compare to the registry IC50 (compound_properties.csv).
"""
import json, numpy as np, pandas as pd
from scipy.optimize import curve_fit
pts = json.load(open("/tmp/outputs/tables/ic50_points_digitised.json"))
# last ANT-2118 point (1000 uM) sits on the x-axis (approx 0-1 %) and is not picked up by blob detection; add it by hand
pts['ANT-2118'].append(dict(conc=1000.0, act=0.8, caps=[]))
reg = pd.read_csv("/tmp/world/filesystem/compound_properties.csv").set_index('compound')
def f4(logc, top, bottom, logic50, hill): return bottom + (top-bottom)/(1+10**((logc-logic50)*hill))
rows=[]
for name, p in pts.items():
    c = np.array([q['conc'] for q in p]); a = np.array([q['act'] for q in p])
    try:
        popt, pcov = curve_fit(f4, np.log10(c), a, p0=[100, 5, np.log10(np.median(c)), 1], maxfev=20000)
        se = np.sqrt(np.diag(pcov))
    except Exception as e:
        popt=[np.nan]*4; se=[np.nan]*4
    # constrained fit bottom=0 for comparison
    f3 = lambda logc, top, logic50, hill: f4(logc, top, 0, logic50, hill)
    p3,_ = curve_fit(f3, np.log10(c), a, p0=[100, np.log10(np.median(c)), 1], maxfev=20000)
    rss4 = np.sum((a-f4(np.log10(c),*popt))**2); rss3 = np.sum((a-f3(np.log10(c),*p3))**2)
    sol = reg.loc[name,'kinetic_solubility_um']
    rows.append(dict(compound=name, registry_ic50_uM=reg.loc[name,'udpglo_ic50_um'], refit_ic50_uM=10**popt[2], refit_abs_ic50_uM=np.nan, hill=popt[3], hill_se=se[3], top=popt[0], bottom=popt[1], bottom_se=se[1],
                     max_conc_tested=c.max(), activity_at_max_conc=a[np.argmax(c)], mean_activity_top3_conc=np.mean(a[np.argsort(c)][-3:]), rss_free_bottom=rss4, rss_bottom0=rss3,
                     ic50_bottom0=10**p3[1], kinetic_solubility_uM=sol, n_points_above_solubility=int((c>sol).sum()) if sol==sol else np.nan))
T = pd.DataFrame(rows)
pd.set_option('display.width',250); pd.set_option('display.max_columns',30)
print(T.round(3).to_string())
T.to_csv("/tmp/outputs/tables/ic50_refit.csv", index=False)
