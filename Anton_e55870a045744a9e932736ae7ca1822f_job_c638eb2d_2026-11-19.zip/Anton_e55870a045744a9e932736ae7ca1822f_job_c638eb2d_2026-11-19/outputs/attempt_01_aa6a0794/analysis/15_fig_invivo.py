"""Figure 1: in vivo pooled screen. Per-tumour gene scores by group for Mgat1, its pathway neighbour Mgat2,
and the internal controls used to infer group identity (Cd274, B2m)."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
ALL = pd.read_csv("/tmp/work/invivo_gene_scores_permouse.csv", index_col=0)
grp = pd.Series([c.split('_')[0]+'_'+c.split('_')[1] for c in ALL.columns], index=ALL.columns)
order = ['Endpoint_NTC','Group1_NTC','Group2_NTC','Group3_NTC','Group4_NTC','Endpoint_STK11','Group5_STK11','Group6_STK11','Group7_STK11','Group8_STK11']
arm = ['in\nvitro','G1\nnude*','G2\niso*','G3\naPD-1*','G4\naPD-1*','in\nvitro','G5\nnude*','G6\niso*','G7\naPD-1*','G8\naPD-1*']
rng = np.random.default_rng(0)
fig, axes = plt.subplots(2,2, figsize=(14,9))
for ax, gene in zip(axes.ravel(), ['Mgat1','Mgat2','Cd274','B2m']):
    labs=[]
    for i,g in enumerate(order):
        v = ALL.loc[gene, grp.index[grp==g]].values
        col = '#3b6fb6' if i<5 else '#c0392b'
        ax.scatter(i+rng.uniform(-0.2,0.2,len(v)), v, s=18, color=col, alpha=0.6, linewidths=0)
        ax.hlines(v.mean(), i-0.32, i+0.32, color='k', lw=2.2, zorder=5)
        labs.append(f"{arm[i]}\n{v.mean():+.2f}\nn={len(v)}")
    ax.axhline(0, color='grey', lw=0.8, ls='--'); ax.axvline(4.5, color='grey', lw=0.8)
    ax.set_xticks(range(10)); ax.set_xticklabels(labs, fontsize=8.5)
    ax.set_ylabel('gene score per tumour\n(log2 fold-change vs baseline)', fontsize=9)
    ymin,ymax = ax.get_ylim(); ax.set_ylim(ymin, ymax+0.12*(ymax-ymin))
    ax.text(0.02, 0.97, gene, transform=ax.transAxes, fontsize=13, fontweight='bold', va='top')
    ax.text(2.2, ax.get_ylim()[1], 'Stk11 wild-type background', ha='center', va='bottom', fontsize=9.5, color='#3b6fb6')
    ax.text(7.2, ax.get_ylim()[1], 'Stk11-knockout background', ha='center', va='bottom', fontsize=9.5, color='#c0392b')
fig.suptitle("In vivo pooled CRISPR screen in MC38 tumours: one dot = one tumour, black bar = group mean\n"
             "Under each group: arm (*inferred - not stated in the client's records; iso = isotype, aPD-1 = anti-PD-1), group mean, number of tumours", fontsize=10.5)
fig.tight_layout(rect=(0,0,1,0.95))
fig.savefig("/tmp/outputs/figures/fig1_invivo_screen_mgat1_by_group.png", dpi=160)
