load /tmp/world/filesystem/MGAT1_C3744_UDP.cif, ter
remove not chain A
remove resn HOH+EDO+GOL
hide everything
bg_color white
set ray_opaque_background, 1
show cartoon, polymer
set cartoon_transparency, 0.35
color grey85, polymer and resi 99-353
color wheat, polymer and resi 354-445
show spheres, resn UDP or resn MN or resn C3744
show sticks, (resi 211+289) and not name N+C+O
set stick_radius, 0.4
color orange, resn C3744
color forest, resn UDP
color purple, resn MN
color red, (resi 211+289) and not name N+C+O
# closest atom pair between ligand and UDP
python
from pymol import cmd
import itertools
la = cmd.get_model("resn C3744").atom; ua = cmd.get_model("resn UDP").atom
best = min(((sum((a.coord[i]-b.coord[i])**2 for i in range(3))**0.5, a.name, b.name) for a in la for b in ua))
print("closest pair", best)
cmd.distance("dmin", f"resn C3744 and name {best[1]}", f"resn UDP and name {best[2]}")
da = cmd.get_model("resi 289 and not name N+C+O+CA").atom
best2 = min(((sum((a.coord[i]-b.coord[i])**2 for i in range(3))**0.5, a.name, b.name) for a in la for b in da))
print("closest pair to D289", best2)
cmd.distance("d289", f"resn C3744 and name {best2[1]}", f"resi 289 and name {best2[2]}")
python end
hide labels
set dash_color, black
set dash_width, 3.5
set dash_gap, 0.5
orient resn C3744 or resn UDP
turn x, -20
zoom polymer, 2
set ray_trace_mode, 0
set antialias, 2
set ray_shadows, 0
png /tmp/work/structure_render.png, width=2000, height=1500, dpi=200, ray=1
