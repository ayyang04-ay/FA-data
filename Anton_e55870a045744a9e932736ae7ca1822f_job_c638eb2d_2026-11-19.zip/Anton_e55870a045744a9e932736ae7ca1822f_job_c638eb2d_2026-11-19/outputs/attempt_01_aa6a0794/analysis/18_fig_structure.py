"""Figure 4: annotate the PyMOL render (render.pml; MGAT1_C3744_UDP.cif chain A) showing that ANT-3744 binds a
pocket in the C-terminal lobe, remote from the UDP/Mn catalytic site. Distances computed from the deposited coordinates
(analysis/08_structure_geometry.py and the PyMOL script)."""
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
im = Image.open("/tmp/work/structure_render.png")
fig, ax = plt.subplots(figsize=(11,8.25))
ax.imshow(im); ax.axis('off')
def lab(txt, xy, xytext, col):
    ax.annotate(txt, xy=xy, xytext=xytext, fontsize=10.5, color=col, ha='center', va='center',
                arrowprops=dict(arrowstyle='-', color=col, lw=1.0), bbox=dict(facecolor='white', edgecolor=col, boxstyle='round,pad=0.3', lw=0.8))
lab("ANT-3744\n(pocket in C-terminal lobe,\nresidues 388-444)", (500,900), (300,1240), '#b9610a')
lab("UDP (donor-nucleotide site)", (1270,900), (1560,1250), '#1e6b2b')
lab("Mn2+", (1205,795), (1330,600), '#7d3c98')
lab("D211 (coordinates Mn2+;\nmutated in the inactive mutant)", (1275,745), (1640,450), '#c0392b')
lab("D289 (contacts the donor sugar;\nmutated in the inactive mutant)", (1020,940), (1010,1300), '#c0392b')
ax.text(880, 770, "23.9 A  (closest ANT-3744 atom to closest UDP atom)", fontsize=10, rotation=-9, ha='center', va='bottom')
ax.text(850, 890, "18.1 A to D289 side chain", fontsize=10, rotation=-11, ha='center', va='top')
ax.text(1000, 120, "MGAT1 - ANT-3744 - UDP - Mn2+ ternary complex (MGAT1_C3744_UDP.cif, chain A, 2.01 A)\n"
        "grey = catalytic domain; wheat = C-terminal lobe (residues 354-445)", fontsize=11, ha='center', va='center')
fig.tight_layout(pad=0.2); fig.savefig("/tmp/outputs/figures/fig4_structure_binding_site.png", dpi=150)
