"""Where does ANT-3744 sit relative to the catalytic machinery?
- minimum / centroid distances between C3744 and UDP, Mn, and catalytic residues D211, D289 in the ternary complex
- same after superposing binary C3744 complex on the UDP-GlcNAc complex (distance to the GlcNAc being transferred)
- per-residue CA displacement between structures (does C3744 binding re-shape the active site?)
- burial of C3744 (fraction of SASA lost on binding, with and without symmetry mates)
"""
import gemmi, numpy as np, pandas as pd
D = "/tmp/world/filesystem/"
def load(f):
    st = gemmi.read_structure(D+f); st.setup_entities(); return st
def lig_atoms(chain, name):
    return [(r, a) for r in chain for a in r if r.name==name]
def mind(A, B):
    return min(a.pos.dist(b.pos) for _,a in A for _,b in B)
def centroid(A):
    return np.mean([[a.pos.x,a.pos.y,a.pos.z] for _,a in A], axis=0)
st = load("MGAT1_C3744_UDP.cif")
for ch in st[0]:
    L = lig_atoms(ch,'C3744'); U = lig_atoms(ch,'UDP'); M = lig_atoms(ch,'MN')
    if not L: continue
    res = {r.seqid.num:r for r in ch if r.het_flag=='A'}
    def dres(n): 
        R=[(res[n],a) for a in res[n]]; return mind(L,R)
    print(f"ternary chain {ch.name}: C3744-UDP min {mind(L,U):.1f} A, centroid-centroid {np.linalg.norm(centroid(L)-centroid(U)):.1f} A; C3744-Mn {mind(L,M):.1f} A; "
          f"C3744-D211 {dres(211):.1f} A; C3744-D289 {dres(289):.1f} A; C3744-R115 {dres(115):.1f}; W288 {dres(288):.1f}")
# superpose UDP-GlcNAc complex chain A on ternary chain A (CA atoms of residues 110-350)
def ca_map(ch): return {r.seqid.num: r['CA'][0].pos for r in ch if r.het_flag=='A' and r.find_atom('CA','*')}
def superpose(mob_ch, ref_ch, sel=range(105,446)):
    a, b = ca_map(mob_ch), ca_map(ref_ch)
    common = [n for n in sel if n in a and n in b]
    sup = gemmi.superpose_positions([b[n] for n in common], [a[n] for n in common])
    return sup, common
ref = st[0]['A']
ud = load("MGAT1_UDP_GlcNAc.cif")
sup, common = superpose(ud[0]['A'], ref)
print(f"UDP-GlcNAc complex (A) onto ternary (A): rmsd {sup.rmsd:.2f} A over {len(common)} CA")
L = lig_atoms(ref,'C3744')
ud1 = [(r,a) for r in ud[0]['A'] for a in r if r.name=='UD1']
glcnac_atoms = [ (r,a) for r,a in ud1 if a.name.endswith("'") and a.name[0] in 'CON' and a.name not in ("C1'","C2'","C3'","C4'","C5'","O2'","O3'","O4'","O5'")]
print("UD1 atom names:", [a.name for _,a in ud1])
dmin = 1e9
for _,a in ud1:
    p = gemmi.Position(*sup.transform.apply(a.pos).tolist())
    for _,b in L:
        d = p.dist(b.pos)
        if d<dmin: dmin=d; who=(a.name,b.name)
print(f"closest approach C3744 (ternary) to superposed UDP-GlcNAc: {dmin:.1f} A  ({who})")
# per-residue CA displacement: apo vs C3744 ; UDP vs ternary ; UDP-GlcNAc vs ternary
pairs = [("MGAT1_apo.cif","MGAT1_C3744.cif"),("MGAT1_UDP.cif","MGAT1_C3744_UDP.cif"),("MGAT1_UDP_GlcNAc.cif","MGAT1_C3744_UDP.cif"),("MGAT1_apo.cif","MGAT1_UDP.cif"),("MGAT1_apo.cif","MGAT1_UDP_GlcNAc.cif")]
out = {}
for f1,f2 in pairs:
    s1, s2 = load(f1), load(f2)
    for c in ('A','B'):
        sup, common = superpose(s1[0][c], s2[0][c])
        a, b = ca_map(s1[0][c]), ca_map(s2[0][c])
        d = {n: gemmi.Position(*sup.transform.apply(a[n]).tolist()).dist(b[n]) for n in common}
        out[(f1.replace('MGAT1_','').replace('.cif',''), f2.replace('MGAT1_','').replace('.cif',''), c)] = d
        big = sorted([(n, round(v,1)) for n,v in d.items() if v>1.5])
        obs1 = sorted(a); obs2 = sorted(b)
        miss1 = [n for n in range(104,446) if n not in a]; miss2 = [n for n in range(104,446) if n not in b]
        print(f"\n{f1} vs {f2} chain {c}: rmsd {sup.rmsd:.2f} A ({len(common)} CA); residues with CA shift >1.5 A: {big}")
        print(f"    disordered (no CA) in {f1}: {miss1}")
        print(f"    disordered (no CA) in {f2}: {miss2}")
