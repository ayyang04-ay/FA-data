"""In vivo pooled CRISPR screen: normalisation and per-sample gene-level log2 fold changes.
- CPM normalise, log2(CPM+pseudocount)
- LFC of each sample vs mean of the 3 matched-background Baseline samples
- centre each sample on the median of the 400 non-targeting guides
- gene score per sample = mean / median of the 4 guide LFCs
Outputs: /tmp/work/invivo_guide_lfc.parquet-like csvs
"""
import pandas as pd, numpy as np
D = "/tmp/world/filesystem/"
df = pd.read_csv(D+"crispr_invivo_guide_counts.csv.gz")
meta = df[['sgrna','gene_sgrna_id','gene_symbol']].copy()
meta['is_ntc'] = meta.gene_symbol.str.startswith('BRDN')
meta['gene'] = np.where(meta.is_ntc, 'NTC', meta.gene_symbol)
X = df.drop(columns=['sgrna','gene_sgrna_id','gene_symbol'])
X.index = meta.gene_sgrna_id
# exclusions decided in 01_invivo_qc.py (failed library, two severely bottlenecked tumours, one duplicated library)
fail = pd.read_csv('/tmp/outputs/tables/invivo_excluded_samples.csv').sample_name.tolist()
X = X.drop(columns=fail)
cpm = X/X.sum()*1e6
PC = 5.0  # pseudocount in CPM units
L = np.log2(cpm+PC)
samples = pd.DataFrame({'sample':X.columns})
samples['group'] = samples['sample'].str.split('_').str[0]
samples['bg'] = samples['sample'].str.split('_').str[1]
samples.loc[samples.group=='Plasmid','bg'] = 'Plasmid'
base = {bg: L[[f'Baseline_{bg}_b{i}' for i in (1,2,3)]].mean(axis=1) for bg in ('NTC','STK11')}
lfc = {}
for _,r in samples.iterrows():
    if r.bg in base and r.group!='Baseline':
        v = L[r['sample']] - base[r.bg]
        v = v - v[meta.is_ntc.values].median()
        lfc[r['sample']] = v
lfc = pd.DataFrame(lfc)
lfc.to_csv("/tmp/work/invivo_guide_lfc.csv")
gl = lfc.copy(); gl['gene'] = meta.gene.values
gmean = gl[gl.gene!='NTC'].groupby('gene').mean()
gmed  = gl[gl.gene!='NTC'].groupby('gene').median()
gmean.to_csv("/tmp/work/invivo_gene_lfc_mean.csv"); gmed.to_csv("/tmp/work/invivo_gene_lfc_median.csv")
samples.to_csv("/tmp/work/invivo_samples.csv", index=False)
meta.to_csv("/tmp/work/invivo_guide_meta.csv", index=False)
print(lfc.shape, gmean.shape)
