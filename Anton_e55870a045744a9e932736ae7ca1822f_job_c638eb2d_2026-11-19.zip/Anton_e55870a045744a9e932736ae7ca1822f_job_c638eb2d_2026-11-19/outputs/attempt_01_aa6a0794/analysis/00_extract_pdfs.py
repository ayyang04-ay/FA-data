"""Extract the text layer and the embedded figure images from the three client PDFs.
Run with the `genomics` env (pypdf).  Outputs: /tmp/work/*.pdf.txt and /tmp/work/figs/<pdf>_p<page>.png
(Everything downstream that 'digitises' a figure works on these PNGs.)"""
import pypdf, os, io
D = "/tmp/world/filesystem/"; os.makedirs("/tmp/work/figs", exist_ok=True)
for f in ["experimental_records.pdf","assay_figures.pdf","phenotype_figures.pdf"]:
    r = pypdf.PdfReader(D+f)
    with open(f"/tmp/work/{f}.txt","w") as out:
        for i,p in enumerate(r.pages):
            out.write(f"\n--- page {i+1} ---\n"); out.write(p.extract_text())
            for img in p.images:
                img.image.convert('RGB').save(f"/tmp/work/figs/{f.replace('.pdf','')}_p{i+1}.png")
    print(f, len(r.pages), "pages;", r.metadata.get('/Title'), "| created", r.metadata.get('/CreationDate'))
