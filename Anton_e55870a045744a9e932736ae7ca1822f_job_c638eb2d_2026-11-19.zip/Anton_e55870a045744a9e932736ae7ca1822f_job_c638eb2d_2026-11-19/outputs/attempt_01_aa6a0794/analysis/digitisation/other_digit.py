"""Remaining automatic figure measurements:
 (1) DSF derivative peaks (assay_figures.pdf p4)  -> Tm and delta-Tm per condition
 (2) cDNA-rescue viability dots (phenotype_figures.pdf p5, right panel)
 (3) rough STK11 / vinculin band densitometry (phenotype_figures.pdf p6)
"""
import sys, os; sys.dont_write_bytecode = True; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from axis import *
from PIL import Image
# ---- (1) DSF: lower (derivative) panel; vertical gridlines every 5 C, 20 C at px 151.5, 58.5 px per 5 C
img = load("/tmp/work/figs/assay_figures_p4.png"); r,g,b = img[...,0],img[...,1],img[...,2]
masks = {'5% DMSO': (r>140)&(r<215)&(g<150)&(b>120)&(b<200)&(r-g>40)&(b-g>25), 'UDP 5000 uM': (r>220)&(g>190)&(b<180)&(r-b>60),
         'ANT-3744 100 uM': (g>r+20)&(g>b+35)&(g>120), 'ANT-3744 + UDP': (b>r+30)&(b>g+15)&(b>130)&(r<140)}
tm = {}
for k,mk in masks.items():
    ys,xs = np.where(mk[600:930, 300:800]); top = ys.min(); xpk = xs[ys<=top+4].mean()+300
    tm[k] = 20 + (xpk-151.5)/58.5*5
for k,v in tm.items(): print(f"DSF | {k}: derivative peak {v:.1f} C; dTm {v-tm['5% DMSO']:+.1f}")
# ---- (2) p5 right panel: y axis 1.5 at px 267.0, 0 at px 772.5 ; two dots per bar -> report top-of-upper and bottom-of-lower dot centres
img = load("/tmp/work/figs/phenotype_figures_p5.png"); r,g,b = img[...,0],img[...,1],img[...,2]
yv = lambda py: (772.5-py)/(772.5-267.0)*1.5; rad = 0.029
cols = {'donor 1 (blue dots)': (abs(r-48)<30)&(abs(g-48)<30)&(abs(b-136)<35), 'donor 2 (red dots)': (r>200)&(g<40)&(b<50), 'black dots (sgMGAT1 half of panel)': (r<30)&(g<30)&(b<30)}
for k,mk in cols.items():
    lab,n = ndi.label(ndi.binary_opening(mk[240:770,1385:2200], structure=np.ones((9,9),bool))); out=[]
    for i in range(1,n+1):
        ys,xs = np.where(lab==i)
        if len(ys)>150: out.append((int(xs.mean()+1385), round(yv(ys.min()+240)-rad,2), round(yv(ys.max()+240)+rad,2)))
    print(f"p5 | {k}: (x px, upper dot, lower dot) {sorted(out)}")
# ---- (3) p6 immunoblot: integrated band darkness above local background, nine lanes
im = np.asarray(Image.open("/tmp/work/figs/phenotype_figures_p6.png").convert('L')).astype(float)
lanes = ['parental','MGAT1 KO- STK11 KO-','MGAT1 KO+ STK11 KO-','MGAT1 KO- STK11 KO+','MGAT1 KO+ STK11 KO+','STK11 KO+ WT cDNA','STK11 KO+ mut cDNA','MGAT1 KO+ STK11 KO+ WT cDNA','MGAT1 KO+ STK11 KO+ mut cDNA']
def band(y0,y1,c,hw=32):
    roi = 255-im[y0:y1, c-hw:c+hw]
    bg = np.median(np.concatenate([(255-im[y0-22:y0-8, c-hw:c+hw]).ravel(), (255-im[y1+8:y1+22, c-hw:c+hw]).ravel()]))
    return (roi-bg).clip(min=0).sum()
vals = [band(405,440,c)/band(585,625,c) for c in [377,465,550,632,717,802,887,970,1055]]
for l,v in zip(lanes, vals): print(f"p6 | {l}: STK11/vinculin relative to parental {v/vals[0]:.2f}")
