"""Automatic part of the figure digitisation for phenotype_figures.pdf (images extracted by 00_extract_pdfs.py).
For each panel: axis calibration (pixel positions of two labelled ticks, found with axis.ticks) and colour-segmented
marker centroids.  Prints (x, y) per series.  Series whose markers are small and overdrawn by other series
(p1 right panel: grey circles and blue triangles; p4 red squares in two panels; p7 blue squares in the left panel;
p8 green triangles) were read by eye from 3-5x zooms of the same images; those values are flagged 'manual' in
tables/figure_digitisation.csv.  Typical agreement between the two approaches where both were possible: within 10 mm3.
"""
import sys, os; sys.dont_write_bytecode = True; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from axis import *
F = "/tmp/work/figs/phenotype_figures_p%d.png"
def run(page, name, cal, region, series, fmt="{:.0f}"):
    img = load(F % page); to_data, to_px = mk_cal(*cal); x0,y0,x1,y1 = region
    r,g,b = img[...,0],img[...,1],img[...,2]
    masks = {'black': mask_color(img,'black'), 'green': (g>r+40)&(g>b+25), 'blue': (b>110)&(r<110)&(b>r+40), 'red': (r>180)&(g<90)&(b<90),
             'grey': (abs(r-g)<14)&(abs(g-b)<14)&(r>100)&(r<175)}
    for label,(colour,op,amin) in series.items():
        bl = blobs(masks[colour][y0:y1, x0:x1], open_size=op, min_area=amin, max_area=5000)
        pts = [(round(to_data(x+x0,0)[0],1), fmt.format(to_data(0,y+y0)[1])) for x,y,n,*_ in bl]
        print(f"p{page} | {name} | {label}: {pts}")
# p1: tumour growth, single-gene MC38 studies
run(1,'MC38 WT',(240.5,0,826.5,25, 628.5,0,238.0,3000),(246,200,900,624),{'sgNTC (black)':('black',7,40),'sgMGAT1 (green)':('green',7,40)})
run(1,'MC38 sgSTK11',(1099,0,1688,20, 628.5,0,292.5,1500),(1104,200,1760,624),{'sgNTC (black)':('black',7,40),'sgMGAT1 (green)':('green',7,40)})
run(1,'MC38 sgSTK11 +/- anti-PD-1',(2044,0,2615,10, 629,0,248,2000),(2030,200,2680,640),{'NTC; IgG2a (black)':('black',5,20),'sgMGAT1; IgG2a (green)':('green',5,20)})
# p4: adoptive transfer
for nm,yc,yr in (('Control T cells',(363.5,0,107.5,2500),(100,370)),('NY-ESO T 1e6',(795.5,0,539.5,2500),(530,802)),('NY-ESO T 2e6',(1227.5,0,971.5,2500),(960,1234))):
    xa = 158.5 if nm.startswith('Control') else 156.5; xb = 472.5 if nm.startswith('Control') else 472.0
    run(4,nm,(xa,0,xb,20)+yc,(150,yr[0],500,yr[1]),{'sgNTC (blue)':('blue',6,30),'sgMGAT1 (red)':('red',6,30)})
# p7: cDNA rescue in vivo
run(7,'sgSTK11+sgNTC',(368.0,0,803.0,20, 638.0,0,245.0,1500),(372,230,830,632),{'MGAT1 WT (black)':('black',11,40),'D211A+D289A (blue)':('blue',7,40)})
run(7,'sgSTK11+sgMGAT1',(1064.5,0,1499.0,20, 642.0,0,240.0,1500),(1069,230,1520,636),{'MGAT1 WT (black)':('black',11,40),'D211A+D289A (blue)':('blue',7,40)})
# p8: library populations
run(8,'MC38 sgNTC',(325.5,0,1084.5,10, 756.5,0,250.5,1500),(332,230,1100,748),{'Nude (black)':('black',11,40),'C57BL/6 (grey)':('grey',9,40),'C57BL/6+aPD1 (green)':('green',7,40)})
run(8,'MC38 sgSTK11',(1512.5,0,2268.5,10, 755.5,0,252.5,2000),(1519,230,2300,747),{'Nude (black)':('black',11,40),'C57BL/6 (grey)':('grey',9,40),'C57BL/6+aPD1 (green)':('green',7,40)})
# p3: co-culture dots (y axis: 0 at px 485.5, 2.5 at px 116.5 ; lower panel 0 at 1183.5, 2.0 at 810.5)
img = load(F % 3); r,g,b = img[...,0],img[...,1],img[...,2]
d02 = (abs(r-112)<22)&(abs(g-152)<22)&(abs(b-208)<22); d04 = (abs(r-88)<22)&(abs(g-88)<22)&(abs(b-160)<24)
for nm,yr,f in (('NCI-H1703',(100,484),lambda py:(485.5-py)/(485.5-116.5)*2.5),('NCI-H1755',(800,1182),lambda py:(1183.5-py)/(1183.5-810.5)*2.0)):
    for lab,mk in (('E:T 0.2',d02),('E:T 0.4',d04)):
        bl = blobs(mk[yr[0]:yr[1],235:660], open_size=5, min_area=25, max_area=600)
        print(f"p3 | {nm} | {lab} dots (x px, value): {[(round(x+235), round(f(y+yr[0]),2)) for x,y,n,*_ in bl if abs(x+235-444)>8 and abs(x+235-514)>8]}")
# p2: lectin bars (red sgMGAT1 bar top / dots)
img = load(F % 2); r,g,b = img[...,0],img[...,1],img[...,2]; red = (r>140)&(g<60)&(b<60)
for nm,(y0v,y0p,y1v,y1p,ys,xs) in {'A375 PHA-L':(0,449.5,1.5,175.5,(160,460),(160,350)),'H1703 PHA-L':(0,946.5,1.5,662.5,(650,955),(160,350)),'A375 GNA':(0,440.5,10,161.5,(150,450),(560,760)),'H1703 GNA':(0,941.5,10,664.5,(650,950),(560,760))}.items():
    sub = red[ys[0]:ys[1]+10, xs[0]:xs[1]]; yy,xx = np.where(sub)
    if 'PHA' in nm: val = y0v+(y0p-(yy.mean()+ys[0]))*(y1v-y0v)/(y0p-y1p); print(f"p2 | {nm} | sgMGAT1 dots centre: {val:.3f}")
    else:
        top = yy.min()+ys[0]; val = y0v+(y0p-top)*(y1v-y0v)/(y0p-y1p); print(f"p2 | {nm} | sgMGAT1 top of dots: {val:.2f} (bar ~0.2-0.3 lower)")
