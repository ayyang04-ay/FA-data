import sys, os; sys.dont_write_bytecode = True; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from digit import *
import numpy as np
def ticks(img, axis, pos, span, offs=(6,8,10,12,14,16,18,20,24)):
    m = mask_color(img,'black'); res={}
    for o in offs:
        if axis=='y':   # ticks to the left of a vertical axis at x=pos
            line = m[span[0]:span[1], pos-o]
        else:           # ticks below a horizontal axis at y=pos
            line = m[pos+o, span[0]:span[1]]
        lab,n = ndi.label(line)
        res[o] = [(round(float(np.where(lab==i)[0].mean()+span[0]),1), int(np.sum(lab==i))) for i in range(1,n+1)]
    return res
def mk_cal(xpix0,xval0,xpix1,xval1,ypix0,yval0,ypix1,yval1):
    def to_data(px,py): return xval0+(px-xpix0)*(xval1-xval0)/(xpix1-xpix0), yval0+(py-ypix0)*(yval1-yval0)/(ypix1-ypix0)
    def to_px(xv,yv): return xpix0+(xv-xval0)*(xpix1-xpix0)/(xval1-xval0), ypix0+(yv-yval0)*(ypix1-ypix0)/(yval1-yval0)
    return to_data, to_px
def caps(img, colour, xpix, yrange, halfw=12, minrun=14, maxthick=7):
    mk = mask_color(img, colour) if isinstance(colour,str) else colour
    rows = mk[yrange[0]:yrange[1], int(round(xpix))-halfw:int(round(xpix))+halfw+1].sum(axis=1)
    ys = np.where(rows>=minrun)[0]+yrange[0]; groups=[]
    for y in ys:
        if groups and y-groups[-1][-1]<=1: groups[-1].append(y)
        else: groups.append([y])
    return [float(np.mean(g)) for g in groups if len(g)<=maxthick]
