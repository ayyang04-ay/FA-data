"""Digitise the six UDP-Glo dose-response panels of assay_figures.pdf p.1 (embedded PNG extracted by 00_extract_pdfs.py).
Axis calibration from detected tick marks; points = centroids of filled-circle blobs; caps = error-bar ends as drawn.
Output: tables/ic50_points_digitised.json"""
import sys, os; sys.dont_write_bytecode = True; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from axis import *
import json
img = load("/tmp/work/figs/assay_figures_p1.png")
panels = {'ANT-0592':(215.5,529.5,161.5,-2),'ANT-1476':(998.5,529.5,161.5,-2),'ANT-2118':(1782.5,529.5,161.5,-2),'ANT-3105':(215.5,1174.5,807.5,-2),'ANT-3744':(998.5,1174.5,807.5,-2),'ANT-4267':(1782.5,1174.5,807.5,-3)}
dec = (822.5-215.5)/6
black = mask_color(img,'black')
out = {}
for name,(x0,y0,y100,log0) in panels.items():
    reg = (int(x0)+6, int(y100)-60, int(x0)+640, int(y0)-5)
    sub = black[reg[1]:reg[3], reg[0]:reg[2]]
    bl = blobs(sub, open_size=11, min_area=80, max_area=1500)
    pts = []
    for x,y,n,xmin,xmax,ymin,ymax in bl:
        px, py = x+reg[0], y+reg[1]
        conc = 10**(log0 + (px-x0)/dec); act = (y0-py)/(y0-y100)*100
        pts.append((conc, act, n))
    # error bars: for each point, caps
    res=[]
    for (conc,act,n) in pts:
        px = x0 + (np.log10(conc)-log0)*dec
        cp = caps(img,'black', px, (reg[1]-20, reg[3]), halfw=9, minrun=13, maxthick=6)
        cv = sorted([(y0-c)/(y0-y100)*100 for c in cp])
        res.append(dict(conc=round(conc,4), act=round(act,1), caps=[round(c,1) for c in cv]))
    out[name]=res
    print(name)
    for r in res: print("   ", r)
json.dump(out, open("/tmp/outputs/tables/ic50_points_digitised.json","w"), indent=1)
