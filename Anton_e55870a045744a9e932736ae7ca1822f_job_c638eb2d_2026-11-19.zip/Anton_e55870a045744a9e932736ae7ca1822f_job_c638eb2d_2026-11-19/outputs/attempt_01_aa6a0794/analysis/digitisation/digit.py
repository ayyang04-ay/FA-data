import numpy as np
from PIL import Image
from scipy import ndimage as ndi

def load(path): return np.asarray(Image.open(path).convert('RGB')).astype(int)

def mask_color(img, kind):
    r,g,b = img[...,0], img[...,1], img[...,2]
    if kind=='black': return (r<70)&(g<70)&(b<70)
    if kind=='green': return (g>r+40)&(g>b+25)
    if kind=='red':   return (r>g+80)&(r>b+80)
    if kind=='blue':  return (b>r+40)&(b>g+20)
    if kind=='gray':  return (abs(r-g)<15)&(abs(g-b)<15)&(r>110)&(r<190)
    raise ValueError(kind)

def blobs(mask, open_size=9, min_area=60, max_area=5000):
    st = np.ones((open_size,open_size),bool)
    m = ndi.binary_opening(mask, structure=st)
    lab,n = ndi.label(m)
    out=[]
    for i in range(1,n+1):
        ys,xs = np.where(lab==i)
        if min_area<=len(ys)<=max_area:
            out.append((xs.mean(), ys.mean(), len(ys), xs.min(), xs.max(), ys.min(), ys.max()))
    return sorted(out)

def find_axis_lines(img, region=None):
    """return x of the vertical axis line and y of the horizontal axis line (longest black runs)"""
    m = mask_color(img,'black')
    if region: 
        x0,y0,x1,y1 = region; mm = np.zeros_like(m); mm[y0:y1,x0:x1]=m[y0:y1,x0:x1]; m=mm
    col = m.sum(axis=0); row = m.sum(axis=1)
    return col, row

def ticks_on_axis(img, axis, pos, span, side, length=8):
    """detect tick marks as black runs perpendicular to axis.  axis='x': horizontal axis at y=pos, ticks below (side=+1)"""
    m = mask_color(img,'black')
    if axis=='x':
        y = pos + side*length
        line = m[y, span[0]:span[1]]
    else:
        x = pos + side*length
        line = m[span[0]:span[1], x]
    lab,n = ndi.label(line)
    cents = [np.where(lab==i)[0].mean()+span[0] for i in range(1,n+1)]
    widths = [np.sum(lab==i) for i in range(1,n+1)]
    return list(zip(cents,widths))
