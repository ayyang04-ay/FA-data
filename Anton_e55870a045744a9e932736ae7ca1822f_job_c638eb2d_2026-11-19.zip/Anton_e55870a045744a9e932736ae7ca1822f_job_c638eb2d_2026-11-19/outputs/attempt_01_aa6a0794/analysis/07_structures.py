"""Crystal structure verification: data/refinement statistics from the mmCIF headers, ligand inventory,
ligand B-factors/occupancies vs surrounding protein, binding-site residues (<=4.0 A), and overlap of the
ANT-3744 (C3744) site with the UDP / UDP-GlcNAc (donor) site after superposition.
"""
import gemmi, numpy as np, pandas as pd, sys
D = "/tmp/world/filesystem/"
files = ["MGAT1_apo.cif","MGAT1_UDP.cif","MGAT1_UDP_GlcNAc.cif","MGAT1_C3744.cif","MGAT1_C3744_UDP.cif"]
rows = []
for f in files:
    b = gemmi.cif.read(D+f).sole_block()
    g = lambda tag: b.find_value(tag)
    st = gemmi.read_structure(D+f)
    rows.append(dict(file=f, space_group=g('_symmetry.space_group_name_H-M'), a=g('_cell.length_a'), b=g('_cell.length_b'), c=g('_cell.length_c'),
        beta=g('_cell.angle_beta'), res_high=g('_reflns.d_resolution_high'), completeness=g('_reflns.percent_possible_obs'), redundancy=g('_reflns.pdbx_redundancy'),
        I_sigI=g('_reflns.pdbx_netI_over_sigmaI'), CC_half=g('_reflns.pdbx_CC_half'), Rmerge=g('_reflns.pdbx_Rmerge_I_obs'),
        Rwork=g('_refine.ls_R_factor_R_work'), Rfree=g('_refine.ls_R_factor_R_free'), mean_B=g('_refine.B_iso_mean'), wilson_B=g('_reflns.B_iso_Wilson_estimate'),
        n_chains=len([ch for ch in st[0] if any(r.het_flag=='A' for r in ch)]), grow=g('_exptl_crystal_grow.pdbx_details')))
T = pd.DataFrame(rows)
pd.set_option('display.width',300); pd.set_option('display.max_columns',50); pd.set_option('display.max_colwidth',90); pd.set_option('display.max_rows',500)
print(T.T.to_string())
T.to_csv("/tmp/outputs/tables/structure_stats.csv", index=False)

def lig_table(f):
    st = gemmi.read_structure(D+f); st.setup_entities()
    model = st[0]
    ns = gemmi.NeighborSearch(model, st.cell, 6).populate(include_h=False)
    out=[]
    for ch in model:
        for res in ch:
            if res.het_flag=='H' and res.name not in ('HOH',):
                B = np.mean([a.b_iso for a in res]); occ = np.mean([a.occ for a in res]); nat = len(res)
                # surrounding protein atoms within 4.0 A
                near = {}
                Bprot=[]
                for a in res:
                    for m in ns.find_atoms(a.pos, '\0', radius=4.0):
                        cra = m.to_cra(model)
                        if cra.residue.het_flag=='A':
                            # consider symmetry mates: check image
                            key = (cra.chain.name, cra.residue.name, cra.residue.seqid.num, m.image_idx!=0)
                            near[key] = near.get(key,0)+1
                            Bprot.append(cra.atom.b_iso)
                out.append(dict(file=f, chain=ch.name, lig=res.name, seq=res.seqid.num, n_atoms=nat, occ=round(occ,2), B_lig=round(B,1),
                                B_contact_protein=round(np.mean(Bprot),1) if Bprot else np.nan,
                                contacts_same_asu=sorted(set(f"{k[1]}{k[2]}({k[0]})" for k in near if not k[3])),
                                contacts_symmetry=sorted(set(f"{k[1]}{k[2]}({k[0]})" for k in near if k[3]))))
    return pd.DataFrame(out)
allL = pd.concat([lig_table(f) for f in files if f!="MGAT1_apo.cif"])
allL.to_csv("/tmp/outputs/tables/structure_ligands.csv", index=False)
for _,r in allL.iterrows():
    print(f"\n{r.file} chain {r.chain} {r.lig} {r.seq}: atoms={r.n_atoms} occ={r.occ} B_lig={r.B_lig} B_contacts={r.B_contact_protein}")
    print("   contacts (ASU):", ", ".join(r.contacts_same_asu))
    if r.contacts_symmetry: print("   contacts (SYMMETRY MATE):", ", ".join(r.contacts_symmetry))
