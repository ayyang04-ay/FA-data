"""Figure 3: UDP-Glo dose-response curves re-plotted from points digitised off assay_figures.pdf p.1,
with free 4-parameter fits. Highlights: (i) residual-activity plateau of the potent analogues, (ii) ANT-0592 inhibition
occurring only above its kinetic solubility."""
import json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
pts = json.load(open("/tmp/outputs/tables/ic50_points_digitised.json")); pts['ANT-2118'].append(dict(conc=1000.0, act=0.8, caps=[]))
reg = pd.read_csv("/tmp/world/filesystem/compound_properties.csv").set_index('compound')
def f4(logc, top, bottom, logic50, hill): return bottom + (top-bottom)/(1+10**((logc-logic50)*hill))
order = ['ANT-0592','ANT-2118','ANT-1476','ANT-3105','ANT-3744','ANT-4267']
potent = ('ANT-1476','ANT-3105','ANT-3744','ANT-4267')
fig, axes = plt.subplots(2,3, figsize=(14,7.8), sharey=True)
for ax,name in zip(axes.ravel(), order):
    c = np.array([q['conc'] for q in pts[name]]); a = np.array([q['act'] for q in pts[name]])
    popt,_ = curve_fit(f4, np.log10(c), a, p0=[100,5,np.log10(np.median(c)),1], maxfev=20000)
    xx = np.linspace(np.log10(c.min())-0.3, np.log10(c.max())+0.3, 200)
    ax.plot(10**xx, f4(xx,*popt), color='#444', lw=1.3)
    ax.scatter(c, a, s=34, color='#c0392b' if name in ('ANT-3744','ANT-4267') else '#1f77b4', zorder=4)
    ax.axhline(0, color='k', lw=0.6)
    if name in potent:
        ax.axhline(popt[1], color='#e67e22', ls='--', lw=1)
        ax.text(0.97, 27, f"plateau at {popt[1]:.0f}% residual activity", transform=ax.get_yaxis_transform(), color='#e67e22', fontsize=9, va='bottom', ha='right', bbox=dict(facecolor='white', edgecolor='none', pad=1.5), zorder=6)
    sol = reg.loc[name,'kinetic_solubility_um']
    if sol==sol:
        ax.axvline(sol, color='#7d3c98', ls=':', lw=1.6)
        ax.text(sol*0.82, 70, f"kinetic solubility {sol:g} uM", color='#7d3c98', fontsize=8.5, rotation=90, va='center', ha='right')
    ax.set_xscale('log'); ax.set_ylim(-6,115)
    ax.set_title(f"{name}", fontsize=11.5, fontweight='bold', loc='left')
    ax.set_title(f"IC50: registry {reg.loc[name,'udpglo_ic50_um']:g} uM | re-fit {10**popt[2]:.2g} uM | Hill {popt[3]:.2f}", fontsize=8.6, loc='right')
    ax.set_xlabel("compound (uM)")
for ax in axes[:,0]: ax.set_ylabel("MGAT1 activity (% of control)")
fig.suptitle("UDP-Glo enzyme inhibition - points digitised from assay_figures.pdf p.1, free four-parameter re-fit.\n"
             "The four potent analogues level off at ~8-10% residual signal; ANT-0592 inhibits only above its solubility limit.", fontsize=10.5)
fig.tight_layout(rect=(0,0,1,0.93)); fig.savefig("/tmp/outputs/figures/fig3_dose_response_refit.png", dpi=160)
