"""TMT glycoproteomics (A375 and NCI-H1703; non-targeting vs MGAT1-KO population; n=4 each).
- classify each intact-glycopeptide composition (paucimannose / high-mannose / hybrid / complex)
- log2 KO/NT per intact glycopeptide (IGP_quant), Welch t-test, BH FDR
- class-level summaries and channel QC
Outputs: tables/glyco_igp_stats.csv, tables/glyco_class_summary.csv
"""
import pandas as pd, numpy as np, re
from scipy import stats
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',300); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',80); pd.set_option('display.max_colwidth',50)
igp = pd.read_excel("/tmp/world/filesystem/glycoproteomics_site_quant.xlsx", sheet_name="IGP_quant")
ch = [c for c in igp.columns if c.startswith('Intensity ')]
grp = {'A375_KO':[f'Intensity AM_KO{i}' for i in range(1,5)], 'A375_NT':[f'Intensity AM_N{i}' for i in range(1,5)],
       'H1703_KO':[f'Intensity NH_M_KO{i}' for i in range(1,5)], 'H1703_NT':[f'Intensity NH_N{i}' for i in range(1,5)]}
def parse(comp):
    d = dict((k,int(v)) for k,v in re.findall(r'([A-Za-z]+)\((\d+)\)', comp))
    return d.get('HexNAc',0), d.get('Hex',0), d.get('Fuc',0), d.get('NeuAc',0), d.get('NeuGc',0), {k:v for k,v in d.items() if k not in ('HexNAc','Hex','Fuc','NeuAc','NeuGc')}
def classify(comp):
    n,h,f,s,g,other = parse(comp)
    if n==2 and h>=5 and f==0 and s==0: return 'high-mannose' if h>5 else 'Man5'
    if n<=2 and h<=4: return 'paucimannose/truncated'
    if n==2: return 'other(HexNAc2)'
    if n==3: return 'hybrid/mono-antennary'
    if n>=4: return 'complex'
    return 'other'
igp['class'] = igp['Observed Modification'].apply(classify)
print(igp['Observed Modification'].value_counts().head(60))
print(igp['class'].value_counts())
print("missing values per channel:\n", igp[ch].isna().sum())
print("zeros per channel:\n", (igp[ch]==0).sum())
# channel totals and correlation QC
print("channel sums (1e9):\n", (igp[ch].sum()/1e9).round(3))
L = np.log2(igp[ch].replace(0,np.nan))
print("channel medians:\n", L.median().round(3))
print(L.corr().round(3).to_string())
for cl in ('A375','H1703'):
    ko, nt = grp[cl+'_KO'], grp[cl+'_NT']
    igp[f'l2fc_{cl}'] = L[ko].mean(axis=1) - L[nt].mean(axis=1)
    t,p = stats.ttest_ind(L[ko], L[nt], axis=1, equal_var=False, nan_policy='omit')
    igp[f'p_{cl}'] = p
    igp[f'fdr_{cl}'] = multipletests(np.nan_to_num(p, nan=1.0), method='fdr_bh')[1]
igp.to_csv("/tmp/outputs/tables/glyco_igp_stats.csv", index=False)
igp.to_pickle("/tmp/work/glyco_igp_stats.pkl")
summ = igp.groupby('class').agg(n=('class','size'),
      A375_median_l2fc=('l2fc_A375','median'), A375_frac_up=('l2fc_A375', lambda x:(x>0).mean()), A375_n_sig_up=('fdr_A375', lambda x: 0),
      H1703_median_l2fc=('l2fc_H1703','median'), H1703_frac_up=('l2fc_H1703', lambda x:(x>0).mean()))
for cl in ('A375','H1703'):
    summ[f'{cl}_n_sig_up'] = igp[(igp[f'fdr_{cl}']<0.05)&(igp[f'l2fc_{cl}']>0)].groupby('class').size()
    summ[f'{cl}_n_sig_down'] = igp[(igp[f'fdr_{cl}']<0.05)&(igp[f'l2fc_{cl}']<0)].groupby('class').size()
    # intensity-weighted share of each class
    for g_ in ('KO','NT'):
        tot = igp[grp[f'{cl}_{g_}']].sum().sum()
        summ[f'{cl}_{g_}_intensity_share'] = igp.groupby('class')[grp[f'{cl}_{g_}']].sum().sum(axis=1)/tot
summ = summ.fillna(0)
print(summ.round(3).to_string())
summ.to_csv("/tmp/outputs/tables/glyco_class_summary.csv")
print("corr of l2fc between lines: %.3f" % igp[['l2fc_A375','l2fc_H1703']].corr().iloc[0,1])
