"""Values read off the client's figure PDFs (embedded raster images) by pixel measurement.
Axis calibration from detected tick marks; marker centres from colour-segmented blobs and/or zoomed visual reading.
Accuracy ~ +-2% of axis range. Error bars are as drawn: the PDFs do not say whether they are SD or SEM, nor give n.
"""
import pandas as pd
rows = []
def add(src, panel, series, x, value, err=None, unit='mm3', note=''):
    rows.append(dict(source=src, panel=panel, series=series, x=x, value=value, error_bar_halfwidth=err, unit=unit, note=note))
P='phenotype_figures.pdf'
add(P+' p1','MC38 WT','sgNTC','day 25',1164,818); add(P+' p1','MC38 WT','sgMGAT1','day 25',1778,865)
add(P+' p1','MC38 sgSTK11','sgNTC','day 19',1088,510); add(P+' p1','MC38 sgSTK11','sgMGAT1','day 19',542,450)
add(P+' p1','MC38 sgSTK11 +/- anti-PD-1','NTC; IgG2a','day 9 of treatment',1139,672)
add(P+' p1','MC38 sgSTK11 +/- anti-PD-1','NTC; anti-PD-1','day 9 of treatment',758,672)
add(P+' p1','MC38 sgSTK11 +/- anti-PD-1','sgMGAT1; IgG2a','day 9 of treatment',619,308)
add(P+' p1','MC38 sgSTK11 +/- anti-PD-1','sgMGAT1; anti-PD-1','day 9 of treatment',399,274)
add(P+' p1','MC38 sgSTK11 +/- anti-PD-1','NTC; IgG2a','day 7 of treatment',819,402); add(P+' p1','MC38 sgSTK11 +/- anti-PD-1','NTC; anti-PD-1','day 7 of treatment',579,348)
add(P+' p1','MC38 sgSTK11 +/- anti-PD-1','sgMGAT1; IgG2a','day 7 of treatment',396,188); add(P+' p1','MC38 sgSTK11 +/- anti-PD-1','sgMGAT1; anti-PD-1','day 7 of treatment',287,162)
add(P+' p4','Control T cells','sgNTC','day 19',1931,386); add(P+' p4','Control T cells','sgMGAT1','day 19',1641,200)
add(P+' p4','NY-ESO T cells 1e6','sgNTC','day 19',1303,515); add(P+' p4','NY-ESO T cells 1e6','sgMGAT1','day 19',616,378)
add(P+' p4','NY-ESO T cells 2e6','sgNTC','day 19',601,398); add(P+' p4','NY-ESO T cells 2e6','sgMGAT1','day 19',176,198)
add(P+' p7','sgSTK11 + sgNTC (C57BL/6)','MGAT1 WT cDNA','day 12',894,529); add(P+' p7','sgSTK11 + sgNTC (C57BL/6)','MGAT1 D211A+D289A cDNA','day 12',791,291)
add(P+' p7','sgSTK11 + sgMGAT1 (C57BL/6)','MGAT1 WT cDNA','day 19',863,243); add(P+' p7','sgSTK11 + sgMGAT1 (C57BL/6)','MGAT1 D211A+D289A cDNA','day 19',420,160)
add(P+' p8','MC38 sgNTC','Nude','day 8',929,323); add(P+' p8','MC38 sgNTC','C57BL/6','day 8',381,131); add(P+' p8','MC38 sgNTC','C57BL/6 + anti-PD-1','day 8',96,53)
add(P+' p8','MC38 sgSTK11','Nude','day 7',964,296); add(P+' p8','MC38 sgSTK11','C57BL/6','day 7',1266,493); add(P+' p8','MC38 sgSTK11','C57BL/6 + anti-PD-1','day 7',648,364)
U='relative viability'
for g,a,b in (('sgNTC',0.92,0.86),('sgB2M',1.85,1.97),('sgMGAT1_1',0.41,0.31),('sgMGAT1_2',0.41,0.25),('sgMGAT1_3',0.43,0.54),('sgMGAT1_4',0.26,0.30)):
    add(P+' p3','NCI-H1703 co-culture',g,'E:T 0.2',a,unit=U); add(P+' p3','NCI-H1703 co-culture',g,'E:T 0.4',b,unit=U)
for g,a,n in (('sgNTC',0.79,''),('sgB2M',1.84,''),('sgMGAT1_1',0.45,'dots 0.37, 0.53'),('sgMGAT1_2',0.17,''),('sgMGAT1_3',0.42,'dots 0.26, 0.58'),('sgMGAT1_4',0.48,'')):
    add(P+' p3','NCI-H1755 co-culture',g,'E:T 0.2',a,unit=U,note=n)
for g,d1,d2 in (('sgNTC + vector',1.165,1.14),('sgNTC + WT',1.136,1.138),('sgNTC + D289A',1.074,1.107),('sgNTC + D211A+D289A',1.122,1.135),('sgMGAT1 + vector',0.724,0.715),('sgMGAT1 + WT',1.15,1.141),('sgMGAT1 + D289A',0.545,0.585),('sgMGAT1 + D211A+D289A',0.531,0.554)):
    add(P+' p5','cDNA rescue, viability with T cells',g,'donor 1',d1,unit=U,note='mean of 2 dots'); add(P+' p5','cDNA rescue, viability with T cells',g,'donor 2',d2,unit=U,note='mean of 2 dots')
for g,v in (('sgNTC parental',6.75),('sgNTC + vector',6.7),('sgNTC + WT',6.35),('sgNTC + D289A',5.75),('sgNTC + D211A+D289A',5.55),('sgMGAT1 + vector',0.03),('sgMGAT1 + WT',5.35),('sgMGAT1 + D289A',0.0),('sgMGAT1 + D211A+D289A',0.0)):
    add(P+' p5','cDNA rescue, PHA-L MFI',g,'',v,unit='x1e6 MFI',note='mean of 2 dots')
add(P+' p2','A375','sgMGAT1 PHA-L (sgNTC = 1)','',0.027,unit='relative signal'); add(P+' p2','NCI-H1703','sgMGAT1 PHA-L (sgNTC = 1)','',0.032,unit='relative signal')
add(P+' p2','A375','sgMGAT1 GNA (sgNTC = 1)','',8.2,unit='relative signal'); add(P+' p2','NCI-H1703','sgMGAT1 GNA (sgNTC = 1)','',8.7,unit='relative signal')
A='assay_figures.pdf'
add(A+' p4','DSF derivative peaks','5% DMSO','Tm',49.4,unit='deg C',note='gridline-calibrated; CSV implies 49'); add(A+' p4','DSF derivative peaks','UDP 5000 uM','Tm',51.4,unit='deg C',note='dTm +2.0; CSV 51 / +2')
add(A+' p4','DSF derivative peaks','ANT-3744 100 uM','Tm',55.3,unit='deg C',note='dTm +5.9; CSV 55 / +6'); add(A+' p4','DSF derivative peaks','ANT-3744 + UDP','Tm',56.9,unit='deg C',note='dTm +7.5; CSV 57 / +8')
add(P+' p6','STK11 immunoblot densitometry (STK11/vinculin, parental = 1)','STK11-KO lanes (no cDNA)','',0.075,unit='ratio',note='0.06, 0.09; rough, from embedded image')
add(P+' p6','STK11 immunoblot densitometry (STK11/vinculin, parental = 1)','STK11-KO + cDNA lanes','',0.16,unit='ratio',note='0.14, 0.20, 0.09, 0.20; rough, from embedded image')
for g,v in (('Unstained',110),('sgNTC + MGAT1 WT',9600),('sgNTC + D211A+D289A',10300),('sgMGAT1 + MGAT1 WT',11400),('sgMGAT1 + D211A+D289A',1100),('sgMGAT1 + D211A+D289A (high MOI)',1500)):
    add(P+' p6','PHA-L histogram, modal fluorescence (log axis)',g,'',v,unit='a.u.',note='peak position read off a log axis; +-15%')
T = pd.DataFrame(rows)
# how each value was obtained: 'auto' = digitisation/phenotype_digit.py (or ic50_digit.py / 20 for DSF); 'manual' = read by eye from a 3-5x zoom of the same image
T['method'] = 'auto (colour-segmented marker centroids)'
manual = (T.series.isin(['NTC; anti-PD-1','sgMGAT1; anti-PD-1'])) | ((T.source.str.endswith('p4')) & (T.series=='sgMGAT1') & (T.panel!='NY-ESO T cells 1e6')) | \
         ((T.source.str.endswith('p7')) & (T.series.str.contains('D211A')) & (T.panel.str.contains('sgNTC'))) | ((T.source.str.endswith('p8')) & (T.series.str.contains('anti-PD-1'))) | \
         (T.panel.str.contains('histogram')) | (T.panel.str.contains('immunoblot')) | (T.panel.str.contains('PHA-L MFI')) | (T.series.str.contains('GNA'))
T.loc[manual,'method'] = 'manual (read from 3-5x zoom; +-2% of axis range)'
T.loc[T.panel.str.contains('immunoblot'),'method'] = 'band densitometry on the embedded image (rough)'
T['error_bar_note'] = T.error_bar_halfwidth.apply(lambda v: 'as drawn; SD or SEM not stated; measured from cap positions' if pd.notna(v) else '')
T.to_csv("/tmp/outputs/tables/figure_digitisation.csv", index=False); print(len(T)); print(T.groupby('method').size()); print(T.head(12).to_string())
