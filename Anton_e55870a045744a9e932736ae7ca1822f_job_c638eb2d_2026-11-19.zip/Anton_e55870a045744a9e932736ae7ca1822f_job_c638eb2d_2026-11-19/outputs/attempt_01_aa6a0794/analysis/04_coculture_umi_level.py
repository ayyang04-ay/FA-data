"""UMI-level robustness analysis of the NCI-H1703 co-culture screen.
Each UMI = independent lineage of one guide. For each UMI with n=c+t>=8 compute a binomial z-score for the
fraction of reads in the T-cell sample relative to the NegCtrl pooled fraction p0, with overdispersion
phi estimated from NegCtrl UMIs.  Gene score = mean UMI z * sqrt(N_umi) (Stouffer) and the median UMI log-ratio;
an empirical null is built from count-matched NegCtrl pseudo-genes.
Also: sign test = fraction of a gene's UMIs that fall below the NegCtrl median fraction.
"""
import pandas as pd, numpy as np
from scipy import stats
rng = np.random.default_rng(1)
df = pd.read_pickle("/tmp/work/coculture.pkl")
C, T = 'tumor_only_untreated', 'MSCV_TCR_high_24hr'
d = df[(df[C]+df[T])>=8].copy()
d['n'] = d[C]+d[T]
neg = d.genetype.eq('NegCtrl')
p0 = d.loc[neg,T].sum()/d.loc[neg,'n'].sum()
d['z0'] = (d[T]-d.n*p0)/np.sqrt(d.n*p0*(1-p0))
phi = d.loc[neg,'z0'].var()
print("UMIs kept: %d of %d; p0=%.4f; overdispersion phi=%.3f; NegCtrl z0 mean=%.3f" % (len(d), len(df), p0, phi, d.loc[neg,'z0'].mean()))
d['z'] = d.z0/np.sqrt(phi)
d['frac'] = d[T]/d.n
d['below'] = (d.frac < d.loc[neg,'frac'].median()).astype(int)
d['lr'] = np.log2((d[T]+0.5)/(d[C]+0.5)) - np.log2(p0/(1-p0))
gene = d.groupby(['gene_symbol','genetype']).agg(n_umi=('z','size'), z_mean=('z','mean'), frac_below=('below','mean'), lr_median=('lr','median')).reset_index()
gene['Z_stouffer'] = gene.z_mean*np.sqrt(gene.n_umi)
# empirical null: NegCtrl UMIs resampled into pseudo-genes of the same size distribution
negz = d.loc[neg,'z'].values
sizes = gene.loc[gene.genetype.isin(['other','ESG']),'n_umi'].values
nullZ = np.array([rng.choice(negz, s, replace=False).mean()*np.sqrt(s) for s in rng.choice(sizes, 20000)])
print("null Z: mean %.3f sd %.3f" % (nullZ.mean(), nullZ.std()))
gene['Z_cal'] = (gene.Z_stouffer-nullZ.mean())/nullZ.std()
real = gene.genetype.isin(['other','ESG'])
gene['rank_dep_umi'] = np.nan; gene.loc[real,'rank_dep_umi'] = gene.loc[real,'Z_cal'].rank(method='min')
gene = gene.sort_values('Z_cal')
gene.to_csv("/tmp/outputs/tables/coculture_gene_stats_umi_level.csv", index=False)
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
print(gene[real.reindex(gene.index)].head(30).round(3).to_string())
print(gene[gene.gene_symbol.isin(['MGAT1','MGAT2','MGAT5','SLC35A1','SLC35A2','CMAS','PTPN2','CFLAR','B2M','CTAG1B','JAK1','STK11','CD274','CD276'])].round(3).to_string())
# MGAT1 per guide UMI-level
m = d[d.gene_symbol=='MGAT1']
print(m.groupby('sgrna_id').agg(n_umi=('z','size'), z_mean=('z','mean'), frac_below=('below','mean'), lr_median=('lr','median'), c=(C,'sum'), t=(T,'sum'), cmax=(C,'max'), tmax=(T,'max')).round(3))
print("NegCtrl reference: frac_below=%.3f lr_median=%.3f" % (d.loc[neg,'below'].mean(), d.loc[neg,'lr'].median()))
# leave-top-UMI-out for MGAT1 guides
m_all = df[df.gene_symbol=='MGAT1']
for gid, x in m_all.groupby('sgrna_id'):
    x = x.sort_values(C, ascending=False)
    top5c = x[C].head(5).sum()/x[C].sum(); top5t = x.sort_values(T,ascending=False)[T].head(5).sum()/x[T].sum()
    xr = x.iloc[5:]
    sf = df[T].sum()/df[C].sum()
    print(gid, "n_umi=%d top5 share ctrl=%.2f tcell=%.2f | LFC all=%.2f, LFC w/o top5 ctrl UMIs=%.2f" % (len(x), top5c, top5t, np.log2(x[T].sum()/x[C].sum()/sf), np.log2(xr[T].sum()/xr[C].sum()/sf)))
