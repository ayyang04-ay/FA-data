"""Do individual tumours behave like the group they are labelled with?
Leave-one-out nearest-centroid classification on a small panel of immune 'reporter' genes whose knockout
behaviour separates the arms (chosen a priori as classical controls, not by fitting): Cd274, Jak1, Jak2, Stat1, Ifngr1, Ifngr2, Ptpn2, B2m, H2-K1, Tap1, Adar, Socs1.
Three classes per background: nude-like (G1/G5), PD-1-axis-intact (G2/G6), PD-1-axis-blocked (G3+G4 / G7+G8).
Also tests whether G3 vs G4 and G7 vs G8 can be told apart at all.
"""
import pandas as pd, numpy as np
ALL = pd.read_csv("/tmp/work/invivo_gene_scores_permouse.csv", index_col=0)
genes = ['Cd274','Jak1','Jak2','Stat1','Ifngr1','Ifngr2','Ptpn2','B2m','H2-K1','Tap1','Adar','Socs1']
X = ALL.loc[genes, [c for c in ALL.columns if c.startswith('Group')]].T
grp = pd.Series([c.split('_')[0] for c in X.index], index=X.index)
cls3 = grp.map({'Group1':'nude','Group5':'nude','Group2':'intact','Group6':'intact','Group3':'blocked','Group4':'blocked','Group7':'blocked','Group8':'blocked'})
bg = pd.Series([c.split('_')[1] for c in X.index], index=X.index)
def loo(Xs, y):
    pred = {}
    for s in Xs.index:
        tr = Xs.drop(s); ytr = y.drop(s)
        cen = tr.groupby(ytr).mean(); sd = tr.std()
        d = (((cen - Xs.loc[s])/sd)**2).sum(axis=1)
        pred[s] = d.idxmin()
    return pd.Series(pred)
rows=[]
for b in ('NTC','STK11'):
    m = bg==b
    p = loo(X[m], cls3[m])
    ct = pd.crosstab(cls3[m].rename('labelled arm (inferred)'), p.rename('classified as'))
    print(f"\n{b} background: leave-one-out nearest-centroid, 3 classes; accuracy {np.mean(p==cls3[m]):.2f}\n", ct.to_string())
    mis = p[p!=cls3[m]]
    for s in mis.index: rows.append((s, cls3[s], mis[s]))
    # can the two 'blocked' groups be separated?
    gg = ('Group3','Group4') if b=='NTC' else ('Group7','Group8')
    m2 = grp.isin(gg)
    p2 = loo(ALL.loc[:, m2[m2].index].T.loc[:, ALL.index[~ALL.index.str.startswith('NTCpseudo')]].pipe(lambda d: d.loc[:, d.var().nlargest(100).index]), grp[m2])
    print(f"   {gg[0]} vs {gg[1]} using the 100 most variable genes: LOO accuracy {np.mean(p2==grp[m2]):.2f} (chance ~0.5)")
M = pd.DataFrame(rows, columns=['sample','labelled_class','classified_as']); print("\nTumours whose reporter profile sits closer to another arm:\n", M.to_string())
M.to_csv("/tmp/outputs/tables/invivo_label_consistency_outliers.csv", index=False)
