"""Assemble the memo: inject the evidence ledger (Appendix A) into analysis/memo_source.md and write
MGAT1_recommendation_memo.md and a self-contained .html (figures embedded)."""
import pandas as pd, base64, re, markdown
src = open("/tmp/outputs/analysis/memo_source.md").read()
L = pd.read_csv("/tmp/outputs/evidence_ledger.csv").fillna('')
def esc(x): return str(x).replace('|','/').replace('\n',' ')
rows = ["| ID | Statement | Value | Client source | How derived | Kind | Note |", "|---|---|---|---|---|---|---|"]
for _,r in L.iterrows():
    rows.append("| " + " | ".join(esc(r[c]) for c in ['id','statement','value','client_source','derivation','kind','note']) + " |")
md = src.replace("<!--LEDGER-->", "\n".join(rows))
open("/tmp/outputs/MGAT1_recommendation_memo.md","w").write(md)
html_body = markdown.markdown(md, extensions=['tables'])
def embed(m):
    path = "/tmp/outputs/" + m.group(1)
    b64 = base64.b64encode(open(path,'rb').read()).decode()
    return f'src="data:image/png;base64,{b64}"'
html_body = re.sub(r'src="(figures/[^"]+)"', embed, html_body)
css = """body{font-family:Georgia,serif;max-width:1000px;margin:2em auto;padding:0 1.2em;line-height:1.5;color:#222}
h1{font-size:1.6em} h2{font-size:1.25em;margin-top:1.8em;border-bottom:1px solid #ccc;padding-bottom:.2em}
table{border-collapse:collapse;font-size:.86em;margin:1em 0;width:100%} th,td{border:1px solid #bbb;padding:5px 7px;vertical-align:top;text-align:left} th{background:#f0f0f0}
img{max-width:100%;border:1px solid #ddd;margin:.4em 0 1.2em} code{background:#f4f4f4;padding:1px 3px;font-size:.92em}"""
open("/tmp/outputs/MGAT1_recommendation_memo.html","w").write(f"<!doctype html><html><head><meta charset='utf-8'><title>MGAT1 programme: verification and recommendation</title><style>{css}</style></head><body>{html_body}</body></html>")
print("memo words (excluding ledger):", len(src.split()), "| ledger rows:", len(L))
