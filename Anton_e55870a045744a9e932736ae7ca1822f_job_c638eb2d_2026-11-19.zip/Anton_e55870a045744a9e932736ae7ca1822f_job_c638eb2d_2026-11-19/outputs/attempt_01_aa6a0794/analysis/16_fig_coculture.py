"""Figure 2: NCI-H1703 genome-wide T-cell co-culture screen.
Left: gene z-scores (vs non-targeting pseudo-genes) for MGAT1 and reference genes, with rank among 19,052 genes.
Right: per-guide log2 fold-changes for MGAT1 against the non-targeting guide distribution."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
g = pd.read_csv("/tmp/outputs/tables/coculture_gene_stats.csv")
gd = pd.read_csv("/tmp/outputs/tables/coculture_guide_stats.csv")
real = g[g.genetype.isin(['other','ESG'])].sort_values('z').reset_index(drop=True)
N = len(real); real['rank_dep'] = np.arange(1,N+1)
groups = [("Resistance controls (antigen presentation / IFN-g sensing)", ['B2M','CTAG1B','IFNGR1','JAK1'], '#2e8b57'),
          ("Known sensitiser controls", ['CFLAR','PTPN2'], '#1f77b4'),
          ("MGAT1", ['MGAT1'], '#c0392b'),
          ("Sugar-nucleotide supply (sialic acid / galactose / GlcNAc)", ['SLC35A1','CMAS','SLC35A2','GALE','UAP1'], '#7d3c98'),
          ("Other N-glycan branching enzymes", ['MGAT2','MGAT4B','MGAT5','MAN2A1'], '#e67e22'),
          ("Programme-relevant genes", ['STK11','CD274','CD276'], '#555555')]
rows=[]
for title, genes, col in groups:
    for gene in genes:
        r = real[real.gene_symbol==gene].iloc[0]
        rows.append((gene, r.z, int(r.rank_dep), col, title))
fig, (ax, ax2) = plt.subplots(1,2, figsize=(14.5,6.4), gridspec_kw={'width_ratios':[1.55,1]})
y = np.arange(len(rows))[::-1]
ax.barh(y, [r[1] for r in rows], color=[r[3] for r in rows], height=0.7)
for yi,(gene,z,rk,col,title) in zip(y,rows):
    lab = f"{gene}   z = {z:+.1f}   (rank {rk:,} of {N:,})" if z<0 else f"{gene}   z = {z:+.1f}   (rank {N-rk+1:,} enriched)"
    ax.text(0.6 if z<0 else -0.6, yi, lab, va='center', ha='left' if z<0 else 'right', fontsize=8.8)
ax.axvline(0, color='k', lw=0.8); ax.set_yticks([])
ax.set_xlim(-21, 21); ax.set_xlabel("gene z-score vs non-targeting pseudo-genes\n(negative = knockout makes tumour cells easier for T cells to kill)")
seen=set(); handles=[]
for title,genes,col in groups: handles.append(plt.Rectangle((0,0),1,1,color=col,label=title))
ax.legend(handles=handles, fontsize=7.8, loc='lower left', frameon=False, bbox_to_anchor=(0.0,1.0), ncol=2)
neg = gd[gd.genetype=='NegCtrl'].lfc_raw
ax2.hist(neg, bins=60, color='#c8c8c8')
cols = ['#c0392b','#e74c3c','#a93226','#d98880']
top = ax2.get_ylim()[1]
lines=[]
for k,((i,r),c) in enumerate(zip(gd[gd.gene_symbol=='MGAT1'].iterrows(), cols)):
    ax2.axvline(r.lfc_raw, color=c, lw=2)
    ax2.text(0.40, 0.95-0.065*k, f"{r.sgrna_id}: {r.lfc_raw:+.2f}  ({int(r.c)} -> {int(r.t)} reads; {int(r.n_umi)} UMIs)", color=c, fontsize=8.2, va='center', transform=ax2.transAxes,
             bbox=dict(facecolor='white', edgecolor='none', pad=1.2))
ax2.set_ylim(0, top*1.45)
ax2.set_xlabel("guide log2 fold-change, T-cell co-culture vs tumour-only\n(centred on non-targeting guides)"); ax2.set_ylabel("number of non-targeting guides (grey histogram, n=989)")
ax2.set_title("All four MGAT1 library guides fall below\nthe non-targeting distribution", fontsize=10.5, loc='left')
fig.suptitle("Genome-wide co-culture screen: NCI-H1703 + NY-ESO-1 TCR-T cells, 24 h, one sample per arm (coculture_screen_umi_counts.csv.gz)", fontsize=10.5, y=0.985)
fig.tight_layout(rect=(0,0,1,0.95)); fig.savefig("/tmp/outputs/figures/fig2_coculture_screen_mgat1.png", dpi=160)
