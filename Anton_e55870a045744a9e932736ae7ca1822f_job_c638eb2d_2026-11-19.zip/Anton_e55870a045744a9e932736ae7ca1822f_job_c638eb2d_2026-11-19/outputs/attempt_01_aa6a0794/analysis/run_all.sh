#!/usr/bin/env bash
# Re-runs the whole verification from the client's files in /tmp/world/filesystem.
# Intermediates go to /tmp/work, results to /tmp/outputs/{tables,figures}.  ~5 min.
set -euo pipefail
A=/tmp/outputs/analysis; mkdir -p /tmp/work/figs /tmp/outputs/tables /tmp/outputs/figures
mm genomics python $A/00_extract_pdfs.py
mm core python $A/01_invivo_qc.py            > /tmp/work/log_01.txt
mm core python $A/02_invivo_lfc.py           > /tmp/work/log_02.txt
mm core python $A/03_coculture_screen.py     > /tmp/work/log_03.txt 2>&1
mm core python $A/04_coculture_umi_level.py  > /tmp/work/log_04.txt
mm chem python $A/05_glycoproteomics.py      > /tmp/work/log_05.txt 2>&1
mm chem python $A/06_glyco_site_composition.py > /tmp/work/log_06.txt
mm core python $A/07_structures.py           > /tmp/work/log_07.txt
mm core python $A/08_structure_geometry.py   > /tmp/work/log_08.txt
mm core python $A/09_invivo_group_identity.py > /tmp/work/log_09.txt
mm core python $A/10_invivo_mgat1_contrasts.py > /tmp/work/log_10.txt
mm core python $A/digitisation/ic50_digit.py > /tmp/work/log_ic50_digit.txt
mm core python $A/11_ic50_refit.py           > /tmp/work/log_11.txt
mm core python $A/12_ic50_vs_kd.py           > /tmp/work/log_12.txt
mm core python $A/13_ligand_burial.py        > /tmp/work/log_13.txt
mm core python $A/14_invivo_robustness.py    > /tmp/work/log_14.txt
mm core python $A/15_fig_invivo.py
mm core python $A/16_fig_coculture.py
mm core python $A/17_fig_doseresponse.py
(cd /tmp/work && pymol -cq $A/18_render_structure.pml > /tmp/work/log_18_pymol.txt 2>&1)
mm core python $A/18_fig_structure.py
mm chem python $A/19_fig_glyco.py            > /tmp/work/log_19.txt
mm core python $A/digitisation/phenotype_digit.py > /tmp/work/log_phenotype_digit.txt
mm core python $A/digitisation/other_digit.py > /tmp/work/log_other_digit.txt
mm core python $A/20_figure_digitisation_table.py > /tmp/work/log_20.txt
mm renv Rscript $A/21_invivo_edger_crosscheck.R > /tmp/work/log_21.txt 2>&1
mm core python $A/22_invivo_retention_nonparametric.py > /tmp/work/log_22.txt
mm core python $A/23_invivo_label_consistency.py > /tmp/work/log_23.txt
mm core python $A/24_evidence_ledger.py > /tmp/work/log_24.txt
mm chem python $A/25_build_memo.py > /tmp/work/log_25.txt
echo "all done"
