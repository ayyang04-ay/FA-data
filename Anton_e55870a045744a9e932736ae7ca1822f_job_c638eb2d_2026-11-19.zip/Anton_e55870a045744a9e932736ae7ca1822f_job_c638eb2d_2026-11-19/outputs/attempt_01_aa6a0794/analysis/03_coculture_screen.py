"""NCI-H1703 genome-wide co-culture screen (tumour-only vs NY-ESO-1 TCR-T, 24 h), UMI-level file.
Single sample per condition -> replication comes from (a) 4 guides/gene and (b) independent UMI lineages per guide.
Analysis:
  1. guide-level: sum UMIs, log2 ratio (T cell / tumour only) with pseudocount, centred on NegCtrl guides
  2. gene-level: mean guide LFC; z vs null built from NegCtrl guides (random 4-guide pseudo-genes)
  3. UMI-level robustness: per-guide 'clone-robust' LFC = median-of-UMI ratio via winsorised sums, and
     per-gene Mann-Whitney of UMI-level survival fractions vs NegCtrl UMIs (count-matched)
Outputs: tables/coculture_gene_stats.csv, tables/coculture_guide_stats.csv
"""
import pandas as pd, numpy as np
from scipy import stats
rng = np.random.default_rng(0)
import os
if not os.path.exists("/tmp/work/coculture.pkl"):
    pd.read_csv("/tmp/world/filesystem/coculture_screen_umi_counts.csv.gz").to_pickle("/tmp/work/coculture.pkl")
df = pd.read_pickle("/tmp/work/coculture.pkl")
C, T = 'tumor_only_untreated', 'MSCV_TCR_high_24hr'
tot = df[[C,T]].sum()
print("library totals:", tot.to_dict(), "ratio T/C = %.4f" % (tot[T]/tot[C]))
# ---------- guide level
g = df.groupby(['gene_symbol','sgrna_id','genetype'], sort=False).agg(n_umi=('umi_barcode','size'), c=(C,'sum'), t=(T,'sum'),
         c_max=(C,'max'), t_max=(T,'max')).reset_index()
# winsorised sums: cap each UMI at the 99th percentile of UMI counts within condition to blunt jackpots
capC, capT = df[C].quantile(0.999), df[T].quantile(0.999)
df['cw'] = df[C].clip(upper=capC); df['tw'] = df[T].clip(upper=capT)
gw = df.groupby('sgrna_id', sort=False).agg(cw=('cw','sum'), tw=('tw','sum'))
g = g.merge(gw, left_on='sgrna_id', right_index=True)
# UMI-presence based (each UMI lineage counts once): number of UMIs detected in each condition
df['cp'] = (df[C]>0).astype(int); df['tp'] = (df[T]>0).astype(int)
gp = df.groupby('sgrna_id', sort=False).agg(cp=('cp','sum'), tp=('tp','sum'))
g = g.merge(gp, left_on='sgrna_id', right_index=True)
PC = 10
sf = tot[T]/tot[C]
g['lfc_raw'] = np.log2((g.t+PC*sf)/(g.c+PC)) - np.log2(sf)
g['lfc_w']   = np.log2((g.tw+PC*sf)/(g.cw+PC)) - np.log2(sf)
neg = g.genetype.eq('NegCtrl')
for col in ('lfc_raw','lfc_w'):
    g[col] = g[col] - g.loc[neg, col].median()
g['lfc_umi_presence'] = np.log2((g.tp+1)/(g.cp+1)); g['lfc_umi_presence'] -= g.loc[neg,'lfc_umi_presence'].median()
print("NegCtrl guide LFC sd: raw %.3f, winsor %.3f" % (g.loc[neg,'lfc_raw'].std(), g.loc[neg,'lfc_w'].std()))
print("low-count guides (c<100):", (g.c<100).sum())
g.to_csv("/tmp/outputs/tables/coculture_guide_stats.csv", index=False)
# ---------- gene level
ok = g[g.c>=100].copy()
gene = ok.groupby(['gene_symbol','genetype']).agg(n_guides=('sgrna_id','size'), lfc_mean=('lfc_raw','mean'), lfc_median=('lfc_raw','median'),
            lfcw_mean=('lfc_w','mean'), lfc_min=('lfc_raw','min'), lfc_max=('lfc_raw','max'),
            n_neg_guides=('lfc_raw', lambda x: (x<0).sum()), c=('c','sum'), t=('t','sum'), n_umi=('n_umi','sum')).reset_index()
# null: random 4-guide draws from NegCtrl guides
negv = ok.loc[ok.genetype.eq('NegCtrl'),'lfc_raw'].values
null = {k: np.array([rng.choice(negv, k, replace=False).mean() for _ in range(200000)]) for k in (1,2,3,4)}
def pvals(r):
    k = min(int(r.n_guides),4); nd = null[k]
    lo = (np.sum(nd<=r.lfc_mean)+1)/(len(nd)+1); hi = (np.sum(nd>=r.lfc_mean)+1)/(len(nd)+1)
    return pd.Series({'p_dep':lo,'p_enr':hi,'z':(r.lfc_mean-nd.mean())/nd.std()})
gene = pd.concat([gene, gene.apply(pvals, axis=1)], axis=1)
from statsmodels.stats.multitest import multipletests
real = gene.genetype.isin(['other','ESG'])
gene['fdr_dep'] = np.nan; gene['fdr_enr']=np.nan
gene.loc[real,'fdr_dep'] = multipletests(gene.loc[real,'p_dep'], method='fdr_bh')[1]
gene.loc[real,'fdr_enr'] = multipletests(gene.loc[real,'p_enr'], method='fdr_bh')[1]
gene['rank_dep'] = np.nan; gene.loc[real,'rank_dep'] = gene.loc[real,'z'].rank(method='min')
gene['rank_enr'] = np.nan; gene.loc[real,'rank_enr'] = (-gene.loc[real,'z']).rank(method='min')
gene = gene.sort_values('z')
gene.to_csv("/tmp/outputs/tables/coculture_gene_stats.csv", index=False)
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',50)
print("N real genes:", real.sum())
print("TOP 40 depleted (sensitisers)"); print(gene[real].head(40).round(3).to_string())
print("TOP 40 enriched (resistance)"); print(gene[real].sort_values('z',ascending=False).head(40).round(3).to_string())
print(gene[gene.gene_symbol.isin(['MGAT1','MGAT2','MGAT3','MGAT4A','MGAT4B','MGAT5','B2M','HLA-A','TAP1','TAP2','TAPBP','JAK1','JAK2','STAT1','IFNGR1','IFNGR2','CTAG1B','CTAG1A','PTPN2','ADAR','SOCS1','CD274','CD276','TRAF2','BIRC2','CFLAR','RNF31','TNFAIP3','TNFRSF1A','CASP8','FADD','STK11','MAN1A1','MAN1A2','MAN2A1','MAN2A2','SLC35A3','SLC35A2','B4GALT1','ALG3','ALG5','ALG6','ALG8','ALG9','ALG12','MOGS','GANAB','FUT8','SPPL3','B3GNT2','ICAM1','CD58','NLRC5','IRF1','KEAP1','ATG7','VPS4A','TBK1','PRMT1','RIPK1','OTULIN'])].round(3).to_string())
