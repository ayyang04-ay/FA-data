"""Assumption-light confirmation of the in vivo Mgat1 result: no pseudocounts, no log-means.
For each tumour: guide abundance (CPM) divided by its mean abundance in the matched-background baseline.
Report, per group, (i) the fraction of tumours in which each Mgat1 / Mgat2 guide is retained at >=25% of baseline,
against the same statistic for the median non-targeting guide, and (ii) the median abundance ratio."""
import pandas as pd, numpy as np
df = pd.read_csv("/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz")
meta = df[['sgrna','gene_sgrna_id','gene_symbol']].copy(); meta['is_ntc']=meta.gene_symbol.str.startswith('BRDN')
X = df.drop(columns=['sgrna','gene_sgrna_id','gene_symbol']); X.index=meta.gene_sgrna_id
X = X.drop(columns=pd.read_csv('/tmp/outputs/tables/invivo_excluded_samples.csv').sample_name.tolist())
cpm = X/X.sum()*1e6
grp = pd.Series([c.split('_')[0] for c in X.columns], index=X.columns); bg = pd.Series([c.split('_')[1] for c in X.columns], index=X.columns)
ratio = pd.DataFrame({c: cpm[c]/cpm[[f'Baseline_{bg[c]}_b{i}' for i in (1,2,3)]].mean(axis=1) for c in X.columns if grp[c].startswith('Group')})
g2 = grp[ratio.columns]; ntc = meta.gene_sgrna_id[meta.is_ntc].values
mg1 = ['Mgat1_1','Mgat1_2','Mgat1_3','Mgat1_4']; rows=[]
for g in [f'Group{i}' for i in range(1,9)]:
    cols = g2.index[g2==g]
    r = {'group':g, 'n_tumours':len(cols), 'NTC_guides_median_frac_retained': (ratio.loc[ntc, cols]>=0.25).mean(axis=1).median()}
    for gid in mg1+['Mgat2_1','Mgat2_2','Mgat2_3','Mgat2_4']: r[gid+'_frac_retained'] = (ratio.loc[gid, cols]>=0.25).mean()
    r['Mgat1_median_abundance_ratio'] = np.median(ratio.loc[mg1, cols].values); r['NTC_median_abundance_ratio'] = np.median(ratio.loc[ntc, cols].values)
    r['Mgat1_zero_count_frac'] = (X.loc[mg1, cols]==0).values.mean(); r['NTC_zero_count_frac'] = (X.loc[ntc, cols]==0).values.mean()
    rows.append(r)
T = pd.DataFrame(rows).round(3); T.to_csv("/tmp/outputs/tables/invivo_mgat1_retention_nonparametric.csv", index=False)
pd.set_option('display.width',250); pd.set_option('display.max_columns',30); print(T.T.to_string())
