# MGAT1 inhibitor programme (Antera): independent verification and recommendation

Prepared 1 November 2026 from the 16 files in the client package. Every number below comes from those files. Tags in square brackets, such as [A2], point to the evidence ledger (Appendix A and `evidence_ledger.csv`), which gives the source file and location for each number and the script that produced it.

## 1. Recommendation

**Do not advance the compound series yet. Hold it at its current stage, and release further spend only if a short cell-based package shows that the compound reproduces what deleting MGAT1 does.** By "advance" I mean in vivo efficacy work, candidate nomination, or any milestone that presumes a working inhibitor in cells.

The case for MGAT1 as a target survives my re-analysis of the raw data and is strong. The compounds are real, potent binders of the purified enzyme. But nothing in the package connects the two. It contains no test of any compound in a cell or an animal [D15]; every biological result comes from deleting the gene. The data also give specific reasons why the connection cannot be assumed (section 3), and the "STK11-mutant, checkpoint-resistant NSCLC" label runs ahead of the evidence (section 4).

In one line: the client has a validated target and a validated binder, but not yet evidence that the binder does the target's job in a cell. This is a "not yet", not a "no". Section 5 sets out what would bring it back, and what should end it.

## 2. What holds up

I re-analysed both CRISPR screens, the glycoproteomics and the crystal structures from the raw files, and re-measured the figures. The findings the programme rests on hold up.

| Claim | Verdict | What my re-analysis shows |
|---|---|---|
| Deleting MGAT1 makes human tumour cells easier for T cells to kill | Reproduced from raw data | Genome-wide screen in NCI-H1703: MGAT1 ranks 19th of 19,052 genes (z = −8.2), all four guides depleted, rank 5 to 92 under four other scoring methods [A2–A4]. Screen controls behave as they should [A5]. Four further guides, different from those in the screen, reproduce it in two NSCLC lines: relative viability 0.17–0.54 against 0.79–0.92 for control [A9, A10]. |
| The effect needs MGAT1's enzyme activity | Consistent in the figures; raw data not supplied | Wild-type MGAT1 restores T-cell resistance (0.72 → 1.15); catalytically inactive mutants do not (0.54–0.57) [A11]. The same holds in mice: knockout tumours given wild-type MGAT1 reach 863 mm³, against 420 mm³ with the inactive mutant [B18]. |
| Deleting MGAT1 strips complex N-glycans | Reproduced from raw data (mass spectrometry) and figures (lectins) | Staining for complex glycans (lectin PHA-L) falls to about 3% of control; staining for the unprocessed precursor (lectin GNA) rises 8–9-fold [A13]. By mass spectrometry the precursor (Man5) doubles from 20% to 40% of signal and complex forms roughly halve [C2–C4]. |
| In mice, the dependence is strongest in Stk11-deficient tumours under immune pressure | Reproduced from raw data; treatment-arm labels inferred | Of 795 genes, Mgat1 is the 1st to 8th most Stk11-knockout-selective dependency in immunocompetent mice (1.7–2.4 log2 units more depleted than in the wild-type background, z = −5.2 to −9.4). A second method (edgeR) gives the same ranks [B5, B6]. Single-gene knockout: tumours about 50% smaller [B16]. |
| The compounds bind and inhibit purified MGAT1 | Consistent across registry, figures and structures | ANT-4267 inhibits at 43 nM and binds at 30–70 nM [D1, D2]. Across the series, inhibition tracks binding (r = 0.95) [D7]. Five crystal structures at 1.55–2.0 Å [D11]. Solubility and hepatocyte stability are good [D2]. |

In this memo, z is the distance from the average of random sets of non-targeting control guides, in standard deviations; a log2 change of −1 means half as abundant.

Two features of the chemistry deserve credit. Potency improved by more than three orders of magnitude from the screening hit [D1]. And ANT-3744 does not compete with UDP, the nucleotide part of the donor substrate [D8, D9], so the high donor concentrations inside cells should not blunt it.

## 3. Why the compound cannot be advanced on this evidence

**1. There are no compound data in cells.** The registry has no cellular, permeability, selectivity or pharmacokinetic columns, and none of the eleven phenotype pages involves a compound [D15]. Whether the compound reaches MGAT1 inside a cell and changes glycans is unknown.

**2. The compound binds far from the catalytic site, and how it inhibits is not established.** In the crystal structure ANT-3744 sits in a pocket at the C-terminal end of the protein, 24 Å from the bound UDP and 18 Å from D289, the nearer of the two residues the client mutates to inactivate the enzyme [D12, D13] (Figure 4). The catalytic domain does not change shape when it binds [D14]. Inhibition was measured on a truncated enzyme with a free five-sugar acceptor (records §6.3), not on the full-length enzyme acting on a glycoprotein. Whether the compound competes with the acceptor is not reported.

**3. Inhibition appears to stop at about 90%.** The four potent analogues all level off at 8–10% residual signal, out to concentrations hundreds to thousands of times their IC50 [D4] (Figure 3). This is either assay background (signal that does not depend on sugar transfer) or genuinely partial inhibition. The records do not say how 0% was defined, so I cannot tell which.

**4. The biology has only been shown for complete or near-complete loss of function.** Every sensitised state in the package has PHA-L at roughly a tenth of control or less (3% or less in the human lines, 11–14% in the engineered rescue line); every protected state has it at 80% or more [A12, A13, A16]. Nothing lies in between. Two observations suggest the bar is high. Knocking out the next branching enzymes does not reproduce the effect in either screen (MGAT2 rank 2,493; Mgat2 not depleted in any mouse arm) [A6, B12]. And over-expressing MGAT1 well above normal does not raise PHA-L, which suggests the enzyme is present in excess [A15]. This matters because of point 3: a reversible inhibitor that leaves 10% of activity may not be enough.

**5. A drug is not a knockout, and the knockout sets a moderate ceiling.** Complete deletion from the day of implantation gives tumours about half the size, not regressions [B16–B18]. A drug would start on established tumours and reach T cells as well as tumour cells; every experiment here removed MGAT1 from tumour cells only. There are no data on the mouse enzyme, on selectivity against related enzymes, or on tolerability. The mechanistic work (competition, thermal shift, structures) was done on ANT-3744, not on the 19-fold more potent ANT-4267 [D1, D8–D13].

## 4. Where the indication label runs ahead of the data

- **STK11.** The link rests on one engineered mouse colon line, MC38 [B4–B6, B16]. The STK11 status of the human lines is not documented anywhere in the package, and in the human screen STK11 knockout itself was neutral (z = +1.3) [A8]. In Stk11-wild-type MC38, single-gene MGAT1 knockout gave no benefit; tumours were numerically larger (1,778 vs 1,164 mm³) [B16].
- **Checkpoint resistance.** The Stk11-deficient model responds less to anti-PD-1 than wild-type (33–49% smaller tumours against 75%) but is not refractory [B17, B19]. MGAT1 loss does not restore the response. In the screen, anti-PD-1 added nothing to Mgat1 depletion (−0.01 log2, 95% CI −0.50 to +0.48), while a known sensitiser, Ptpn2, was detected in the same comparison [B10]. In the single-gene study the combination matched what two independent effects would give (399 mm³ observed, 412 predicted) [B17]. The supportable claim is "acts independently of PD-1 blockade".
- **T-cell mechanism.** In Stk11-deficient tumours, about half to two-thirds of the Mgat1 depletion is already present in nude mice, which lack T cells [B9]. An intact immune system adds a further 1.0 log2 unit (95% CI 0.45–1.61) [B8]. So the mouse effect is only partly the T-cell mechanism shown in human cells.
- **NSCLC.** The human evidence is in NSCLC lines; the in vivo Stk11 evidence is in a colon line.

## 5. What would bring it back

Gates 1–3 are cell-based, quick, and decide the programme. Gate 4 can run alongside. Gates 5–6 should wait until 1–3 pass. Benchmarks are the client's own knockout results. The single most informative experiment is Gates 1 and 3 run together: one dose series of ANT-4267 on control and MGAT1-knockout NSCLC cells, read out as glycan staining and as T-cell killing.

| Gate | What it must establish | Comparisons the data must include | Benchmark from client data | Bring-back criterion |
|---|---|---|---|---|
| 1. Target engagement in cells | The compound remodels N-glycans in intact cells, dose-dependently, at soluble and non-toxic concentrations | MGAT1-knockout and control cells side by side; at least three analogues spanning the potency range, for example ANT-4267, ANT-3744 and ANT-2118 (cell rank order should follow enzyme rank order); compound on knockout cells (should add nothing); human and mouse lines | PHA-L ≈ 3% of control, GNA 8–9× [A13]; Man5 20% → 40%; CD276 N91 complex forms 10–15% → 1% [C2, C5] | PHA-L loss of ≥90%, or the level Gate 2 shows to be sufficient |
| 2. How much inhibition is enough | The relationship between residual MGAT1 activity and T-cell sensitisation; and whether the 8–10% enzyme floor is real | Graded genetic loss (for example titrated re-expression in knockout cells) plotted as PHA-L against T-cell killing; compound dose-response on the same axes; enzyme assay with a defined zero | Only two states exist today: PHA-L at 14% of control or less (sensitised) and 80% or more (protected) [A12, A13, A16] | Compound's maximal cellular effect reaches the sufficient level |
| 3. Functional phenocopy and specificity | The compound sensitises tumour cells to antigen-specific T-cell killing, through MGAT1 | Control vs MGAT1-knockout cells ± compound; B2M knockout and non-specific T cells as assay controls; compound on tumour cells only, T cells only, and both; an MGAT1 pocket mutant that no longer binds the compound, if it keeps activity; both NSCLC lines | Knockout: 0.17–0.54 vs 0.79–0.92 control [A9, A10]; wild-type rescue returns to 1.15 [A11] | At least half the knockout effect in both lines, absent in knockout cells, with T-cell killing of control targets intact |
| 4. Mechanism and selectivity | How a distal binder blocks catalysis, and that it does so on the natural substrate | Competition with acceptor and with UDP-GlcNAc; full-length enzyme and glycoprotein acceptor; ANT-4267 in the same site; mouse enzyme; related GlcNAc-transferases | ANT-3744: KD 0.4 μM, not weakened by UDP [D8] | Comparable potency on natural substrate and on mouse enzyme; clean selectivity |
| 5. In vivo exposure, then efficacy | Exposure that holds the tumour glycan marker near the knockout state, then tumour control | Stk11-deficient and wild-type MC38; immunocompetent and nude hosts; ± anti-PD-1; an MGAT1-knockout tumour arm in the same study; the glycan marker on tumour cells and on host immune cells; tolerability; individual animals, with group sizes set from the client's own variability (error bars 47–89% of the mean [B21]) | Knockout: 46–51% smaller in Stk11-deficient [B16–B18]; none in wild-type; additive with anti-PD-1 | A pre-agreed fraction of the knockout effect with marker confirmation, and a decision that this ceiling is worth pursuing |
| 6. Indication | That STK11 loss raises dependence on MGAT1 in human NSCLC | Matched STK11-intact and STK11-deficient human NSCLC cells in the T-cell assay, for knockout and compound; documented STK11 status for every line; a second Stk11-deficient mouse model, ideally lung | Mouse only: 1.7–2.4 log2 selective [B5, B6] | A larger effect in STK11-deficient human cells |

**What should end it.** If the best compound, at soluble and non-toxic concentrations, cannot drive glycan remodelling to the level Gate 2 shows is needed, or does not sensitise cells to T-cell killing, stop this series. The target would remain valid for a different chemical approach. Both screens also point to neighbouring steps in the same pathway that score as strongly as MGAT1 (SLC35A1, SLC35A2 and CMAS in human cells; B4galt1 in mice) [A7, B13].

## 6. What I set aside or discounted, and why

- **Four of 141 tumour libraries** in the mouse screen: one failed sequencing (349 reads), two had lost a third or more of the library, and one is a second copy of another sample filed under a different animal number [B2]. Keeping the two bottlenecked tumours does not change the result.
- **Conventional p-values for cross-background comparisons.** Under a standard t-test, random sets of non-targeting control guides came out "significant" 14–46% of the time instead of 5%, so I scored every gene against non-targeting controls instead.
- **The Stk11 comparison in nude mice.** Its sign depends on the method (−0.87 or +0.88), so I treat it as no evidence either way [B7].
- **Potency values for the screening hit ANT-0592.** It inhibits only above its solubility limit [D6].
- **The two acquired compounds, ANT-1938 and ANT-2214.** Neither shows saturable binding [D10]; they are not usable comparators.
- **Data points at 1,000 μM.** They lie above solubility and ten times above the top concentration given in the records [E2].
- **Absolute fold-changes in the glycoproteomics.** Knockout channels carry about 1.6 times the total signal, so I used within-channel composition instead [C3].
- **Statistical significance of the tumour-growth figures.** The figures give no group size and do not say whether bars are SD or SEM [B21]. I used them for direction and approximate size only.
- **PD-L1 as the mechanism.** PD-L1 is not detected in the glycoproteomics [C5], no PD-L1 blot is in the package, and PD-L1 knockout is neutral in the human screen [A8].
- **Anything from outside the package**, including published MGAT1 biology and public cell-line genotypes.

## 7. What I could not verify, and what to ask the client

I could not check: ligand electron density (no structure factors were supplied); raw binding (SPR), thermal-shift, flow-cytometry and tumour-volume data; or the enzyme activity of the mutant proteins, which the records describe but do not report.

Questions that would tighten the picture:

1. Which treatment arm is each of Groups 1–8 in the mouse screen? The records do not say. I inferred the arms from internal controls [B3]. Groups 3 and 4 (and 7 and 8) are indistinguishable and both look anti-PD-1-treated.
2. The records give 45 animals; the file has 141 tumours [E1]. Which is right, and why do samples 82346 and 82364 carry the same library?
3. What are the group sizes and error-bar definitions for every tumour-growth and co-culture figure?
4. What is the STK11 status of NCI-H1703, NCI-H1755 and A375?
5. How was 0% activity defined in the enzyme assay, and what was the top concentration tested [E2]?
6. Is there any cellular or in vivo compound data not in this package? The records are dated 18 August 2026 and the PDFs are stamped 18 November 2026 [E3], so I cannot confirm what "current to 1 November" covers.

## Figures

**Figure 1. Mouse screen: Mgat1, Mgat2 and two control genes, by group.**

![Figure 1](figures/fig1_invivo_screen_mgat1_by_group.png)

**Figure 2. Human co-culture screen: MGAT1 against reference genes, and its four guides.**

![Figure 2](figures/fig2_coculture_screen_mgat1.png)

**Figure 3. Enzyme inhibition curves re-fitted from the client's figure, showing the residual plateau.**

![Figure 3](figures/fig3_dose_response_refit.png)

**Figure 4. Where ANT-3744 binds relative to the catalytic site.**

![Figure 4](figures/fig4_structure_binding_site.png)

**Figure 5. Glycoproteomics: glycan classes in control and MGAT1-knockout cells.**

![Figure 5](figures/fig5_glycoproteomics_class_shift.png)

## Appendix A. Evidence ledger

Each row is a number used above. "Kind" is *direct* (read from a client file), *computed* (my re-analysis of client raw data) or *digitised* (measured from a figure image). Script and table paths are relative to the output folder. The same table is in `evidence_ledger.csv`.

<!--LEDGER-->

## Appendix B. How the re-analysis was done

- **Human co-culture screen.** Counts for each unique molecular identifier (UMI, a barcode marking one lineage of cells carrying a guide) summed per guide; log2 ratio of T-cell to tumour-only arm, centred on the 989 non-targeting guides; gene score is the mean of its guides, compared with 200,000 random four-guide sets of non-targeting guides. Because there is one sample per arm, I repeated the analysis at the level of individual UMI lineages and with outlier-capped counts. Guides against essential genes are mildly depleted in the T-cell arm (mean −0.14 log2), so the screen carries a small general-fitness component; MGAT1 guides sit at normal abundance in the tumour-only arm, so this does not explain the MGAT1 result [A17].
- **Mouse screen.** Counts normalised to reads per million; log2 fold-change of each tumour against the three baseline samples of the same background; centred on the 400 non-targeting guides; gene score per tumour is the mean of four guides. Groups are compared with the tumour as the unit, and each gene is scored against 5,000 random four-guide non-targeting sets. Cross-checked with edgeR and with a count-free retention measure.
- **Glycoproteomics.** Each glycopeptide classified by composition; the share of signal in each class computed within each channel, so that loading differences cancel.
- **Structures.** Statistics read from the file headers; distances, contacts and burial computed from coordinates.
- **Figures.** Values measured from the embedded images after calibrating the axes from tick marks; accuracy about ±2% of the axis range.

All scripts are in `analysis/` and run end to end with `analysis/run_all.sh`; outputs are in `tables/`.
