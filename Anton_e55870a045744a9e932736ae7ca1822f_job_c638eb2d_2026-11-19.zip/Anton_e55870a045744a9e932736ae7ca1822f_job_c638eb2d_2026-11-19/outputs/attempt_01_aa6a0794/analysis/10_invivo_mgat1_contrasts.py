"""In vivo screen: formal contrasts for Mgat1 (and all 795 library genes), mouse = unit of replication.
Group identity (INFERRED, see 09_invivo_group_identity.py):
   G1/G5 = nude (no adaptive immunity), G2/G6 = C57BL/6 isotype, G3+G4 / G7+G8 = C57BL/6 PD-1 axis blocked.
Backgrounds: NTC (Stk11 wild-type) = G1-4 ; STK11 (Stk11 knockout) = G5-8.
"""
import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',60)
ALL = pd.read_csv("/tmp/work/invivo_gene_scores_permouse.csv", index_col=0)
grp = pd.Series([c.split('_')[0] for c in ALL.columns], index=ALL.columns)
bg = pd.Series([c.split('_')[1] for c in ALL.columns], index=ALL.columns)
pseudo = ALL.index.str.startswith('NTCpseudo')
def cols(groups, background=None):
    m = grp.isin(groups)
    if background: m &= (bg==background)
    return grp.index[m]
def one_sample(c, label):
    x = ALL[c]; t,p = stats.ttest_1samp(x, 0, axis=1)
    r = pd.DataFrame({'mean':x.mean(1),'median':x.median(1),'sd':x.std(1),'n':x.shape[1],'t':t,'p':p,'frac_mice_neg':(x<0).mean(1)}, index=ALL.index)
    nd = r.loc[pseudo,'mean']; r['z_vs_ntc'] = (r['mean']-nd.mean())/nd.std()
    rr = r[~pseudo].copy(); rr['rank_depleted'] = rr['mean'].rank(method='min'); rr['fdr']=multipletests(rr.p,method='fdr_bh')[1]
    rr['label']=label; return rr
def two_sample(ca, cb, label):
    a, b = ALL[ca], ALL[cb]
    t,p = stats.ttest_ind(a,b,axis=1,equal_var=False); u = stats.mannwhitneyu(a,b,axis=1).pvalue
    r = pd.DataFrame({'mean_a':a.mean(1),'mean_b':b.mean(1),'diff':a.mean(1)-b.mean(1),'n_a':a.shape[1],'n_b':b.shape[1],'t':t,'p':p,'p_mwu':u}, index=ALL.index)
    nd = r.loc[pseudo,'diff']; r['z_vs_ntc']=(r['diff']-nd.mean())/nd.std()
    # 95% CI (Welch)
    va, vb = a.var(1)/a.shape[1], b.var(1)/b.shape[1]; se = np.sqrt(va+vb); df = (va+vb)**2/(va**2/(a.shape[1]-1)+vb**2/(b.shape[1]-1))
    r['ci_lo'] = r['diff']-stats.t.ppf(0.975,df)*se; r['ci_hi'] = r['diff']+stats.t.ppf(0.975,df)*se
    rr = r[~pseudo].copy(); rr['rank_neg']=rr['t'].rank(method='min'); rr['rank_neg_by_diff']=rr['diff'].rank(method='min'); rr['fdr']=multipletests(rr.p,method='fdr_bh')[1]
    rr['label']=label; rr['null_fp_rate']=(r.loc[pseudo,'p']<0.05).mean(); return rr
one = {
 'in vitro endpoint, NTC bg': cols(['Endpoint'],'NTC'), 'in vitro endpoint, STK11 bg': cols(['Endpoint'],'STK11'),
 'G1 nude, NTC': cols(['Group1']), 'G2 B6 isotype, NTC': cols(['Group2']), 'G3+4 B6 aPD-1, NTC': cols(['Group3','Group4']),
 'G5 nude, STK11': cols(['Group5']), 'G6 B6 isotype, STK11': cols(['Group6']), 'G7+8 B6 aPD-1, STK11': cols(['Group7','Group8'])}
rows=[]; full_one={}
for k,c in one.items():
    r = one_sample(c,k); full_one[k]=r
    m = r.loc['Mgat1']; rows.append(dict(condition=k, n=int(m.n), Mgat1_mean_LFC=m['mean'], Mgat1_median_LFC=m['median'], sd=m.sd, frac_mice_depleted=m.frac_mice_neg, p=m.p, fdr=m.fdr, z_vs_NTCpseudo=m.z_vs_ntc, rank_most_depleted_of_795=int(m.rank_depleted),
              Mgat2_mean_LFC=r.loc['Mgat2','mean'], B2m=r.loc['B2m','mean'], Cd274=r.loc['Cd274','mean'], Ptpn2=r.loc['Ptpn2','mean'], Jak1=r.loc['Jak1','mean']))
T1 = pd.DataFrame(rows); print(T1.round(3).to_string()); T1.to_csv("/tmp/outputs/tables/invivo_mgat1_by_condition.csv", index=False)
two = {
 'Stk11-KO vs WT | in vitro': (cols(['Endpoint'],'STK11'), cols(['Endpoint'],'NTC')),
 'Stk11-KO vs WT | nude (G5 v G1)': (cols(['Group5']), cols(['Group1'])),
 'Stk11-KO vs WT | B6 isotype (G6 v G2)': (cols(['Group6']), cols(['Group2'])),
 'Stk11-KO vs WT | B6 aPD-1 (G7+8 v G3+4)': (cols(['Group7','Group8']), cols(['Group3','Group4'])),
 'Stk11-KO vs WT | all in vivo': (cols(['Group5','Group6','Group7','Group8']), cols(['Group1','Group2','Group3','Group4'])),
 'B6 isotype vs nude | WT (G2 v G1)': (cols(['Group2']), cols(['Group1'])),
 'B6 isotype vs nude | Stk11-KO (G6 v G5)': (cols(['Group6']), cols(['Group5'])),
 'aPD-1 vs isotype | WT (G3+4 v G2)': (cols(['Group3','Group4']), cols(['Group2'])),
 'aPD-1 vs isotype | Stk11-KO (G7+8 v G6)': (cols(['Group7','Group8']), cols(['Group6'])),
 'all B6 vs nude | Stk11-KO (G6+7+8 v G5)': (cols(['Group6','Group7','Group8']), cols(['Group5'])),
 'all B6 vs nude | WT (G2+3+4 v G1)': (cols(['Group2','Group3','Group4']), cols(['Group1'])),
}
rows=[]; full_two={}
for k,(ca,cb) in two.items():
    r = two_sample(ca,cb,k); full_two[k]=r
    m = r.loc['Mgat1']; rows.append(dict(contrast=k, n_a=int(m.n_a), n_b=int(m.n_b), Mgat1_a=m.mean_a, Mgat1_b=m.mean_b, diff=m['diff'], ci_lo=m.ci_lo, ci_hi=m.ci_hi, p_welch=m.p, p_mwu=m.p_mwu, fdr=m.fdr, z_vs_NTCpseudo=m.z_vs_ntc,
              rank_neg_of_795=int(m.rank_neg), rank_by_effect=int(m.rank_neg_by_diff), pseudo_gene_fp_rate=m.null_fp_rate))
T2 = pd.DataFrame(rows); print(T2.round(4).to_string()); T2.to_csv("/tmp/outputs/tables/invivo_mgat1_contrasts.csv", index=False)
pd.concat([r.assign(gene=r.index) for r in full_two.values()]).to_csv("/tmp/outputs/tables/invivo_all_genes_all_contrasts.csv.gz", index=False)
pd.concat([r.assign(gene=r.index) for r in full_one.values()]).to_csv("/tmp/outputs/tables/invivo_all_genes_depletion_by_group.csv.gz", index=False)
# interaction: (G6-G5) - (G2-G1) = Stk11-specific, adaptive-immunity-dependent component, bootstrap CI over mice
rng = np.random.default_rng(0)
x = {g: ALL.loc['Mgat1', cols([g])].values for g in ['Group1','Group2','Group5','Group6']}
est = (x['Group6'].mean()-x['Group5'].mean())-(x['Group2'].mean()-x['Group1'].mean())
bs = [(rng.choice(x['Group6'],len(x['Group6'])).mean()-rng.choice(x['Group5'],len(x['Group5'])).mean())-(rng.choice(x['Group2'],len(x['Group2'])).mean()-rng.choice(x['Group1'],len(x['Group1'])).mean()) for _ in range(20000)]
print("Interaction (isotype-vs-nude difference, Stk11-KO minus WT): %.2f  95%% bootstrap CI [%.2f, %.2f]  P(>=0)=%.4f" % (est, np.percentile(bs,2.5), np.percentile(bs,97.5), np.mean(np.array(bs)>=0)))
# top genes in the headline contrasts
for k in ['Stk11-KO vs WT | all in vivo','Stk11-KO vs WT | B6 isotype (G6 v G2)','Stk11-KO vs WT | nude (G5 v G1)','B6 isotype vs nude | Stk11-KO (G6 v G5)','aPD-1 vs isotype | Stk11-KO (G7+8 v G6)']:
    print("\n==", k); print(full_two[k].sort_values('t').head(15)[['mean_a','mean_b','diff','t','p','fdr','z_vs_ntc','rank_neg']].round(3).to_string())
for k in ['G6 B6 isotype, STK11','G7+8 B6 aPD-1, STK11','G5 nude, STK11','G2 B6 isotype, NTC']:
    print("\n== most depleted:", k); print(full_one[k].sort_values('mean').head(15)[['mean','median','n','p','fdr','z_vs_ntc','rank_depleted']].round(3).to_string())
