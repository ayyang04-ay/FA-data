"""Loading-independent read-out of the MGAT1-KO glycan shift:
for every glycosite, the share of the site's total reporter intensity carried by each glycan class,
computed within each TMT channel (so channel loading cancels).  Also global class shares per channel.
"""
import pandas as pd, numpy as np
from scipy import stats
pd.set_option('display.width',300); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',80); pd.set_option('display.max_colwidth',50)
igp = pd.read_pickle("/tmp/work/glyco_igp_stats.pkl")
ch = [c for c in igp.columns if c.startswith('Intensity ')]
short = [c.replace('Intensity ','') for c in ch]
# --- global class share per channel
tot = igp[ch].sum()
share = igp.groupby('class')[ch].sum()/tot
share.columns = short
print("Global intensity share of each glycan class per TMT channel (%):")
print((100*share).round(1).to_string())
mg = igp.copy(); mg['mgat1_dep'] = mg['class'].isin(['complex','hybrid/mono-antennary'])
dep = mg[mg.mgat1_dep][ch].sum()/tot; dep.index=short
print("\nMGAT1-dependent (hybrid+complex) share per channel (%):"); print((100*dep).round(2).to_string())
g = {'A375_KO':short[0:4],'A375_NT':short[4:8],'H1703_KO':short[8:12],'H1703_NT':short[12:16]}
for cl in ('A375','H1703'):
    ko, nt = dep[g[cl+'_KO']], dep[g[cl+'_NT']]
    print(f"{cl}: hybrid+complex share NT {100*nt.mean():.2f}% -> KO {100*ko.mean():.2f}%  (residual {ko.mean()/nt.mean():.2f} of NT; Welch p={stats.ttest_ind(ko,nt,equal_var=False).pvalue:.2e})")
    m5 = share.loc['Man5']
    print(f"{cl}: Man5 share NT {100*m5[g[cl+'_NT']].mean():.1f}% -> KO {100*m5[g[cl+'_KO']].mean():.1f}%")
# --- per-site composition
igp['site'] = igp['Gene name'].astype(str)+'_N'+igp['Position'].astype(str)
rows=[]
for s, d in igp.groupby('site'):
    if d.mgat1_dep.sum()==0 if 'mgat1_dep' in d else False: pass
    d = d.assign(dep=d['class'].isin(['complex','hybrid/mono-antennary']))
    if d.dep.sum()==0 or (~d.dep).sum()==0: continue
    f = d[d.dep][ch].sum()/d[ch].sum(); f.index=short
    rows.append(dict(site=s, gene=d['Gene name'].iloc[0], n_forms=len(d), n_dep_forms=int(d.dep.sum()),
        A375_NT=f[g['A375_NT']].mean(), A375_KO=f[g['A375_KO']].mean(), H1703_NT=f[g['H1703_NT']].mean(), H1703_KO=f[g['H1703_KO']].mean(),
        p_A375=stats.ttest_ind(f[g['A375_KO']], f[g['A375_NT']], equal_var=False).pvalue, p_H1703=stats.ttest_ind(f[g['H1703_KO']], f[g['H1703_NT']], equal_var=False).pvalue))
S = pd.DataFrame(rows)
S['A375_ratio'] = S.A375_KO/S.A375_NT; S['H1703_ratio']=S.H1703_KO/S.H1703_NT
S.to_csv("/tmp/outputs/tables/glyco_site_complex_share.csv", index=False)
print("\nSites with both MGAT1-dependent and MGAT1-independent glycoforms quantified:", len(S))
for cl in ('A375','H1703'):
    print(f"{cl}: median complex+hybrid share of site NT {S[cl+'_NT'].median():.3f} -> KO {S[cl+'_KO'].median():.3f}; median KO/NT ratio {S[cl+'_ratio'].median():.3f}; sites decreased {(S[cl+'_ratio']<1).sum()}/{len(S)}; sign-test p={stats.binomtest(int((S[cl+'_ratio']<1).sum()), len(S), 0.5).pvalue:.2e}")
print(S.sort_values('H1703_ratio').round(3).to_string())
