"""Burial of ANT-3744 (C3744) in its pocket: ligand SASA alone vs in the protein chain (Shrake-Rupley),
and explicit protein-ligand polar contacts (<=3.5 A), incl. symmetry mates (gemmi neighbour search).
"""
import gemmi, numpy as np
from Bio.PDB import MMCIFParser, ShrakeRupley, Select
from Bio.PDB.Structure import Structure
from Bio.PDB.Model import Model
from Bio.PDB.Chain import Chain
import warnings; warnings.filterwarnings('ignore')
D="/tmp/world/filesystem/"
p = MMCIFParser(QUIET=True)
for f in ("MGAT1_C3744.cif","MGAT1_C3744_UDP.cif"):
    s = p.get_structure('x', D+f)
    for ch in s[0]:
        lig = [r for r in ch if r.get_resname()=='C3744']
        if not lig: continue
        lig = lig[0]
        # ligand alone
        s1 = Structure('a'); m1 = Model(0); c1 = Chain('L'); s1.add(m1); m1.add(c1); c1.add(lig.copy())
        sr = ShrakeRupley(); sr.compute(s1[0], level='R'); sasa_free = list(s1[0]['L'])[0].sasa
        # ligand + same-chain protein (no waters)
        s2 = Structure('b'); m2 = Model(0); c2 = Chain(ch.id); s2.add(m2); m2.add(c2)
        for r in ch:
            if r.id[0]==' ' or r.get_resname()=='C3744': c2.add(r.copy())
        sr.compute(s2[0], level='R')
        sasa_cplx = [r for r in s2[0][ch.id] if r.get_resname()=='C3744'][0].sasa
        print(f"{f} chain {ch.id}: ligand SASA free {sasa_free:.0f} A^2, in complex {sasa_cplx:.0f} A^2 -> buried {100*(1-sasa_cplx/sasa_free):.0f}%")
    st = gemmi.read_structure(D+f); st.setup_entities(); model = st[0]
    ns = gemmi.NeighborSearch(model, st.cell, 5).populate(include_h=False)
    for ch in model:
        for res in ch:
            if res.name!='C3744': continue
            print(f"  polar contacts <=3.5 A, {f} chain {ch.name}:")
            for a in res:
                if a.element.name not in ('N','O'): continue
                for mk in ns.find_atoms(a.pos, '\0', radius=3.5):
                    cra = mk.to_cra(model)
                    if cra.residue is res: continue
                    if cra.atom.element.name in ('N','O'):
                        d = st.cell.find_nearest_pbc_image(a.pos, cra.atom.pos, mk.image_idx).dist() if hasattr(st.cell,'find_nearest_pbc_image') else None
                        print(f"     {a.name:4s} ... {cra.chain.name}/{cra.residue.name}{cra.residue.seqid.num}/{cra.atom.name:4s} {'(symmetry mate)' if mk.image_idx!=0 else ''} ")
