"""In vivo pooled CRISPR screen: sample-level QC and exclusion list.
Input : crispr_invivo_guide_counts.csv.gz, crispr_invivo_ngs_demux.csv.gz
Checks: read depth, guide drop-out (bottleneck), skew (Gini), demultiplexing table consistency,
        near-duplicate libraries (two 'animals' with the same clonal fingerprint in the 400 non-targeting guides).
Output: tables/invivo_sample_qc.csv, tables/invivo_excluded_samples.csv
"""
import pandas as pd, numpy as np
D = "/tmp/world/filesystem/"
df = pd.read_csv(D+"crispr_invivo_guide_counts.csv.gz")
dm = pd.read_csv(D+"crispr_invivo_ngs_demux.csv.gz")
meta = df[['sgrna','gene_sgrna_id','gene_symbol']].copy()
meta['is_ntc'] = meta.gene_symbol.str.startswith('BRDN')
X = df.drop(columns=['sgrna','gene_sgrna_id','gene_symbol'])
def gini(x):
    x = np.sort(np.asarray(x,dtype=float)); n=len(x)
    return (2*np.sum((np.arange(1,n+1))*x)/(n*x.sum())) - (n+1)/n
qc = pd.DataFrame({'total_reads':X.sum(), 'n_zero_guides':(X==0).sum(), 'frac_zero':(X==0).mean().round(4),
                   'median_count':X.median(), 'top_guide_frac':(X.max()/X.sum()).round(5), 'gini':X.apply(gini).round(4)})
qc.index.name='sample_name'; qc = qc.reset_index()
qc['group'] = qc.sample_name.str.split('_').str[0]; qc['background'] = qc.sample_name.str.split('_').str[1]
qc = qc.merge(dm, on='sample_name', how='outer', indicator=True)
print("count-matrix columns vs demux rows:", qc._merge.value_counts().to_dict())
print("index collisions within a run:", dm.duplicated(['ngs_sample_id','first_10nt_id']).sum(), "| duplicated sample names:", dm.sample_name.duplicated().sum())
print("samples per group:\n", qc.groupby(['group','background']).size().to_string())
# near-duplicate detection on non-targeting guides (their pattern in a tumour is a random clonal fingerprint)
tum = [c for c in X.columns if c.startswith('Group') and X[c].sum()>1e5]
L = np.log2(X.loc[meta.is_ntc.values, tum]/X[tum].sum()*1e6+1)
C = L.rank().corr()  # Spearman
v = C.values[np.triu_indices(len(tum),1)]
print("NTC-guide Spearman between tumours: median %.3f, 99th pct %.3f, max %.3f" % (np.median(v), np.percentile(v,99), v.max()))
dups = [(tum[i],tum[j],C.iloc[i,j]) for i in range(len(tum)) for j in range(i+1,len(tum)) if C.iloc[i,j]>0.8]
for a,b,r in dups:
    print(f"NEAR-DUPLICATE libraries: {a} ~ {b}: NTC Spearman {r:.3f}; raw-count Pearson over all guides {np.corrcoef(X[a],X[b])[0,1]:.3f}; read ratio {X[b].sum()/X[a].sum():.2f}; median count ratio {np.median((X[b]+.5)/(X[a]+.5)):.2f}")
excl = []
for _,r in qc.iterrows():
    if r.total_reads < 1e5: excl.append((r.sample_name, f"failed library ({int(r.total_reads)} reads)"))
    elif r.group.startswith('Group') and r.frac_zero > 0.25: excl.append((r.sample_name, f"severe bottleneck ({100*r.frac_zero:.0f}% of guides at zero)"))
for a,b,r in dups:
    drop = a if X[a].sum()<X[b].sum() else b; keep = b if drop==a else a
    excl.append((drop, f"same library as {keep} (non-targeting-guide Spearman {r:.2f}); lower-depth copy dropped"))
E = pd.DataFrame(excl, columns=['sample_name','reason']); E.to_csv("/tmp/outputs/tables/invivo_excluded_samples.csv", index=False)
print(E.to_string())
qc.drop(columns=['_merge']).to_csv("/tmp/outputs/tables/invivo_sample_qc.csv", index=False)
