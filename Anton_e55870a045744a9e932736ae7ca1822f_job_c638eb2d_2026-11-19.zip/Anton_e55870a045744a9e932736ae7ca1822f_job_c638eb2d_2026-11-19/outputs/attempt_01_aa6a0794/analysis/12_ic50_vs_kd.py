"""Digitise the IC50-vs-SPR KD scatter (assay_figures.pdf p.5) and quantify the correlation.
Axis calibration from detected tick marks: x 0.01 at px 233.5 ... 1000 at px 1094.5 ; y 0.01 at px 806.5 ... 1000 at px 233.5.
"""
import sys; sys.dont_write_bytecode = True; sys.path.insert(0,'/tmp/outputs/analysis/digitisation')
from axis import *
import pandas as pd
from scipy import stats
img = load("/tmp/work/figs/assay_figures_p5.png")
black = mask_color(img,'black')
sub = black[215:800, 240:1100]
bl = blobs(sub, open_size=9, min_area=60, max_area=1200)
pts=[]
for x,y,n,xmin,xmax,ymin,ymax in bl:
    px,py = x+240, y+215
    ic50 = 10**(-2 + (px-233.5)/(1094.5-233.5)*5); kd = 10**(-2 + (806.5-py)/(806.5-233.5)*5)
    w,h = xmax-xmin+1, ymax-ymin+1
    pts.append((ic50,kd,n,w,h))
df = pd.DataFrame(pts, columns=['ic50_uM','kd_uM','area','w','h'])
# keep roughly circular blobs (drop text fragments / identity-line pieces)
med = df.area.median()
df['ok'] = (df.w.between(12,26))&(df.h.between(12,26))
print(df.round(3).to_string())
d = df[df.ok].copy()
# merged double points: area ~2x
print("n points:", len(d), " median area:", med)
d['ratio'] = d.ic50_uM/d.kd_uM
r = stats.pearsonr(np.log10(d.ic50_uM), np.log10(d.kd_uM)); rs = stats.spearmanr(d.ic50_uM, d.kd_uM)
sl = stats.linregress(np.log10(d.ic50_uM), np.log10(d.kd_uM))
print(f"log-log Pearson r={r[0]:.3f} (p={r[1]:.1e}); Spearman rho={rs[0]:.3f}; slope={sl.slope:.2f}; geometric-mean IC50/KD={10**np.mean(np.log10(d.ratio)):.2f}; range {d.ratio.min():.2f}-{d.ratio.max():.2f}")
d.to_csv("/tmp/outputs/tables/ic50_vs_kd_digitised.csv", index=False)
