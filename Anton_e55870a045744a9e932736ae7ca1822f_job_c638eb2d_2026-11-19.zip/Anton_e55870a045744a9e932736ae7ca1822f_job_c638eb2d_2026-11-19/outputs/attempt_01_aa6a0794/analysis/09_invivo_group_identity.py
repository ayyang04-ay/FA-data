"""In vivo screen: the records never say which arm is Group1..8.  Infer it from internal positive controls
and test every group-vs-group contrast genome(library)-wide, with non-targeting pseudo-genes as the null.
gene score per mouse = mean LFC (vs matched baseline) of its 4 guides, centred on NTC guides.
"""
import pandas as pd, numpy as np, itertools
from scipy import stats
rng = np.random.default_rng(0)
pd.set_option('display.width',250); pd.set_option('display.max_rows',500); pd.set_option('display.max_columns',60)
lfc = pd.read_csv("/tmp/work/invivo_guide_lfc.csv", index_col=0)
meta = pd.read_csv("/tmp/work/invivo_guide_meta.csv")
grp = pd.Series([c.split('_')[0] for c in lfc.columns], index=lfc.columns)
# QC exclusions: samples with >25% zero guides (severe bottleneck)
qc = pd.read_csv("/tmp/outputs/tables/invivo_sample_qc.csv").set_index('sample_name')
bad = [s for s in lfc.columns if qc.loc[s,'frac_zero']>0.25]
print("additional exclusions at this step (should be none; exclusions are applied in 02):", bad)
keep = [c for c in lfc.columns if c not in bad]
lfc = lfc[keep]; grp = grp[keep]
print(grp.value_counts().sort_index())
is_ntc = meta.is_ntc.values
gene_of = meta.gene.values
# gene-level per mouse
G = lfc[~is_ntc].groupby(gene_of[~is_ntc]).mean()
# pseudo-genes from NTC guides: 100 disjoint sets of 4
ntc_idx = np.where(is_ntc)[0]; perm = rng.permutation(ntc_idx)
P = pd.DataFrame({f'NTCpseudo_{i}': lfc.iloc[perm[4*i:4*i+4]].mean() for i in range(100)}).T
ALL = pd.concat([G,P])
ALL.to_csv("/tmp/work/invivo_gene_scores_permouse.csv")
def contrast(a_groups, b_groups, label):
    a = ALL[grp.index[grp.isin(a_groups)]]; b = ALL[grp.index[grp.isin(b_groups)]]
    t,p = stats.ttest_ind(a, b, axis=1, equal_var=False)
    u = stats.mannwhitneyu(a, b, axis=1, alternative='two-sided')
    res = pd.DataFrame({'mean_a':a.mean(1), 'mean_b':b.mean(1), 'diff':a.mean(1)-b.mean(1), 'med_diff':a.median(1)-b.median(1), 't':t, 'p_welch':p, 'p_mwu':u.pvalue}, index=ALL.index)
    res['is_pseudo'] = res.index.str.startswith('NTCpseudo')
    # empirical z from pseudo-gene null
    nd = res.loc[res.is_pseudo,'diff']
    res['z_vs_ntc'] = (res['diff']-nd.mean())/nd.std()
    real = res[~res.is_pseudo].copy()
    real['rank_neg'] = real['t'].rank(method='min'); real['rank_pos'] = (-real['t']).rank(method='min')
    from statsmodels.stats.multitest import multipletests
    real['fdr'] = multipletests(real.p_welch, method='fdr_bh')[1]
    print(f"\n### {label}: n_a={a.shape[1]}, n_b={b.shape[1]}; pseudo-gene null diff sd={nd.std():.3f}; pseudo-genes with p<0.05: {(res.loc[res.is_pseudo,'p_welch']<0.05).sum()}/100")
    print(" most negative:"); print(real.sort_values('t').head(12)[['mean_a','mean_b','diff','t','p_welch','fdr','z_vs_ntc']].round(3).to_string())
    print(" most positive:"); print(real.sort_values('t',ascending=False).head(8)[['mean_a','mean_b','diff','t','p_welch','fdr','z_vs_ntc']].round(3).to_string())
    return real
R = {}
R['G3vG4'] = contrast(['Group3'],['Group4'],'Group3 vs Group4 (NTC bg)')
R['G7vG8'] = contrast(['Group7'],['Group8'],'Group7 vs Group8 (STK11 bg)')
R['G2vG1'] = contrast(['Group2'],['Group1'],'Group2 vs Group1 (NTC bg)')
R['G6vG5'] = contrast(['Group6'],['Group5'],'Group6 vs Group5 (STK11 bg)')
R['G34vG2'] = contrast(['Group3','Group4'],['Group2'],'Group3+4 vs Group2 (NTC bg)')
R['G78vG6'] = contrast(['Group7','Group8'],['Group6'],'Group7+8 vs Group6 (STK11 bg)')
