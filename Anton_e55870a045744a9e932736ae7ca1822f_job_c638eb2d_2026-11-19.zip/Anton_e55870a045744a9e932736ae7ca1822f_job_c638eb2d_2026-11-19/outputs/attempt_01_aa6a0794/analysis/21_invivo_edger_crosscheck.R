# Cross-check of the in vivo screen with an independent, count-based method (edgeR quasi-likelihood).
# Guides = features; library sizes scaled on the 400 non-targeting guides; one coefficient per group (incl. Baseline per background).
# Contrasts are "group vs matched baseline" differences, so background-specific library composition cancels.
# Gene-level: mean guide logFC and limma::fry rotation test on the 4 guides of each gene.
suppressMessages({library(edgeR); library(limma)})
d <- read.csv(gzfile("/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz"), check.names=FALSE)
meta <- d[,1:3]; X <- as.matrix(d[,-(1:3)]); rownames(X) <- meta$gene_sgrna_id
drop <- read.csv("/tmp/outputs/tables/invivo_excluded_samples.csv")$sample_name
X <- X[, !(colnames(X) %in% drop)]
X <- X[, !grepl("^Plasmid", colnames(X))]
grp <- sub("_[^_]+$", "", colnames(X))            # e.g. Group6_STK11, Baseline_NTC, Endpoint_STK11
grp <- factor(grp)
is_ntc <- grepl("^BRDN", meta$gene_symbol)
y <- DGEList(counts=X)
# normalise on non-targeting guides: effective library size = sum of NTC counts (scaled)
ntc_sum <- colSums(X[is_ntc,]); y$samples$lib.size <- ntc_sum/mean(ntc_sum)*mean(colSums(X)); y$samples$norm.factors <- 1
design <- model.matrix(~0+grp); colnames(design) <- levels(grp)
y <- estimateDisp(y, design, robust=TRUE)
fit <- glmQLFit(y, design, robust=TRUE)
cm <- makeContrasts(
  KOvWT_nude    = (Group5_STK11-Baseline_STK11) - (Group1_NTC-Baseline_NTC),
  KOvWT_iso     = (Group6_STK11-Baseline_STK11) - (Group2_NTC-Baseline_NTC),
  KOvWT_aPD1    = ((Group7_STK11+Group8_STK11)/2-Baseline_STK11) - ((Group3_NTC+Group4_NTC)/2-Baseline_NTC),
  B6vNude_KO    = Group6_STK11-Group5_STK11,
  B6vNude_WT    = Group2_NTC-Group1_NTC,
  aPD1vIso_KO   = (Group7_STK11+Group8_STK11)/2-Group6_STK11,
  aPD1vIso_WT   = (Group3_NTC+Group4_NTC)/2-Group2_NTC,
  dep_G6        = Group6_STK11-Baseline_STK11,
  dep_G5        = Group5_STK11-Baseline_STK11,
  dep_G2        = Group2_NTC-Baseline_NTC,
  dep_G1        = Group1_NTC-Baseline_NTC,
  invitro_KO    = Endpoint_STK11-Baseline_STK11,
  invitro_WT    = Endpoint_NTC-Baseline_NTC,
  levels=design)
genes <- ifelse(is_ntc, "NTC", meta$gene_symbol)
idx <- split(seq_len(nrow(X)), genes); idx$NTC <- NULL
# NTC pseudo-genes for calibration
set.seed(1); ntc_i <- sample(which(is_ntc)); pseudo <- split(ntc_i, rep(1:100, each=4)); names(pseudo) <- paste0("NTCpseudo_",1:100)
out <- list()
for (cn in colnames(cm)) {
  q <- glmQLFTest(fit, contrast=cm[,cn]); lfc <- q$table$logFC
  g_lfc <- sapply(idx, function(i) mean(lfc[i])); p_lfc <- sapply(pseudo, function(i) mean(lfc[i]))
  z <- (g_lfc-mean(p_lfc))/sd(p_lfc)
  out[[cn]] <- data.frame(contrast=cn, gene=names(g_lfc), mean_logFC=g_lfc, z_vs_ntc=z, rank_neg=rank(g_lfc, ties.method="min"))
  m <- out[[cn]][out[[cn]]$gene=="Mgat1",]
  cat(sprintf("%-14s Mgat1 mean guide logFC %6.2f  z_vs_NTC %6.1f  rank(most negative) %3d/%d | guides: %s\n", cn, m$mean_logFC, m$z_vs_ntc, m$rank_neg, length(g_lfc),
      paste(sprintf("%.2f", lfc[idx$Mgat1]), collapse=", ")))
}
res <- do.call(rbind, out); write.csv(res, "/tmp/outputs/tables/invivo_edger_crosscheck.csv", row.names=FALSE)
cat("common dispersion:", y$common.dispersion, "\n")
