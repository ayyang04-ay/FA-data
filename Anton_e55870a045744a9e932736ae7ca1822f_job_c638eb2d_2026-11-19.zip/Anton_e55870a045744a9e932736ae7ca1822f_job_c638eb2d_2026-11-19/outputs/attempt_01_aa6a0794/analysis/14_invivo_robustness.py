"""Robustness of the in vivo Mgat1 result.
(a) empirical null from 5,000 random 4-guide non-targeting pseudo-genes (same statistic as the gene)
(b) alternative summarisation: median of guides; drop weakest guide; different pseudocounts
(c) per-guide contrasts
(d) leave-one-mouse-out range
(e) sensitivity to inclusion of the two bottlenecked tumours and of the Group3-vs-Group4 assignment
"""
import pandas as pd, numpy as np
from scipy import stats
rng = np.random.default_rng(42)
D = "/tmp/world/filesystem/"
df = pd.read_csv(D+"crispr_invivo_guide_counts.csv.gz")
meta = df[['sgrna','gene_sgrna_id','gene_symbol']].copy(); meta['is_ntc']=meta.gene_symbol.str.startswith('BRDN'); meta['gene']=np.where(meta.is_ntc,'NTC',meta.gene_symbol)
X = df.drop(columns=['sgrna','gene_sgrna_id','gene_symbol']); X.index = meta.gene_sgrna_id
EXC = pd.read_csv('/tmp/outputs/tables/invivo_excluded_samples.csv')
BOTTLENECK = EXC.sample_name[EXC.reason.str.contains('bottleneck')].tolist()
X = X.drop(columns=[s for s in EXC.sample_name if s not in BOTTLENECK])   # failed + duplicate always out
def make_lfc(pc=5.0, drop=None):
    drop = BOTTLENECK if drop is None else drop
    cpm = X/X.sum()*1e6; L = np.log2(cpm+pc); out={}
    for c in X.columns:
        g,bg = c.split('_')[0], c.split('_')[1]
        if g.startswith('Group') or g=='Endpoint':
            if c in drop: continue
            base = L[[f'Baseline_{bg}_b{i}' for i in (1,2,3)]].mean(axis=1)
            v = L[c]-base; out[c] = v - v[meta.is_ntc.values].median()
    return pd.DataFrame(out)
def groups(lfc): return pd.Series([c.split('_')[0] for c in lfc.columns], index=lfc.columns)
CON = {'KO-vs-WT | nude': (['Group5'],['Group1']), 'KO-vs-WT | B6 isotype': (['Group6'],['Group2']), 'KO-vs-WT | B6 aPD-1': (['Group7','Group8'],['Group3','Group4']),
       'B6 isotype-vs-nude | Stk11-KO': (['Group6'],['Group5']), 'B6 isotype-vs-nude | WT': (['Group2'],['Group1']),
       'aPD-1-vs-isotype | Stk11-KO': (['Group7','Group8'],['Group6']), 'aPD-1-vs-isotype | WT': (['Group3','Group4'],['Group2']),
       'depletion | G6 (Stk11-KO, B6 isotype)': (['Group6'],None), 'depletion | G5 (Stk11-KO, nude)': (['Group5'],None), 'depletion | G2 (WT, B6 isotype)': (['Group2'],None), 'depletion | G1 (WT, nude)':(['Group1'],None)}
def stat(gs, grp, a, b):
    # gs: Series over samples (gene score per mouse)
    xa = gs[grp.isin(a)]
    if b is None: return xa.mean()
    return xa.mean() - gs[grp.isin(b)].mean()
def analyse(lfc, summar='mean', guides=None, label=''):
    grp = groups(lfc)
    ids = meta.gene_sgrna_id[meta.gene=='Mgat1'].values if guides is None else guides
    k = len(ids)
    gs = lfc.loc[ids].mean() if summar=='mean' else lfc.loc[ids].median()
    ntc_ids = meta.gene_sgrna_id[meta.is_ntc].values
    # null: 5000 random k-guide NTC sets
    sets = [rng.choice(ntc_ids, k, replace=False) for _ in range(5000)]
    Nmat = np.stack([(lfc.loc[s].mean().values if summar=='mean' else lfc.loc[s].median().values) for s in sets])   # 5000 x samples
    rows=[]
    for name,(a,b) in CON.items():
        obs = stat(gs, grp, a, b)
        ma = grp.isin(a).values
        null = Nmat[:,ma].mean(axis=1) - (Nmat[:,grp.isin(b).values].mean(axis=1) if b is not None else 0)
        p_emp = (np.sum(null<=obs)+1)/(len(null)+1); p_emp2 = min(1, 2*min(p_emp, (np.sum(null>=obs)+1)/(len(null)+1)))
        rows.append(dict(analysis=label, contrast=name, estimate=obs, null_mean=null.mean(), null_sd=null.std(), z=(obs-null.mean())/null.std(), p_emp_two_sided=p_emp2))
    return pd.DataFrame(rows)
res=[]
base = make_lfc()
res.append(analyse(base, label='primary (mean of 4 guides, pc=5 CPM)'))
res.append(analyse(base, summar='median', label='median of 4 guides'))
res.append(analyse(base, guides=['Mgat1_1','Mgat1_2','Mgat1_4'], label='drop weakest guide (Mgat1_3)'))
res.append(analyse(make_lfc(pc=1.0), label='pseudocount 1 CPM'))
res.append(analyse(make_lfc(pc=20.0), label='pseudocount 20 CPM'))
res.append(analyse(make_lfc(drop=()), label='keep the 2 bottlenecked tumours'))
R = pd.concat(res); R.to_csv("/tmp/outputs/tables/invivo_mgat1_robustness.csv", index=False)
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
print(R.pivot(index='contrast', columns='analysis', values='estimate').round(2).to_string())
print(R.pivot(index='contrast', columns='analysis', values='z').round(1).to_string())
print(R[R.analysis.str.startswith('primary')][['contrast','estimate','null_sd','z','p_emp_two_sided']].round(4).to_string())
# per-guide
grp = groups(base)
print("\nper-guide KO-vs-WT differences")
for gid in ['Mgat1_1','Mgat1_2','Mgat1_3','Mgat1_4']:
    v = base.loc[gid]
    print(gid, {k: round(stat(v,grp,a,b),2) for k,(a,b) in CON.items()})
# leave-one-out for headline contrasts
gs = base.loc[meta.gene_sgrna_id[meta.gene=='Mgat1'].values].mean()
for name in ['KO-vs-WT | B6 isotype','B6 isotype-vs-nude | Stk11-KO','aPD-1-vs-isotype | Stk11-KO']:
    a,b = CON[name]; vals=[]
    for s in gs.index[grp.isin(a+b)]:
        g2 = gs.drop(s); vals.append(stat(g2, grp.drop(s), a, b))
    print(f"leave-one-mouse-out {name}: {min(vals):.2f} .. {max(vals):.2f}")
# G3 vs G4 and G7 vs G8 separately for Mgat1 and Cd274
G = base.copy(); G['gene']=meta.gene.values
for gene in ['Mgat1','Cd274','Ptpn2','Jak1']:
    gs = G[G.gene==gene].drop(columns='gene').mean()
    out = {g: (round(gs[grp==g].mean(),2), round(gs[grp==g].std()/np.sqrt((grp==g).sum()),2)) for g in ['Group1','Group2','Group3','Group4','Group5','Group6','Group7','Group8']}
    print(gene, out)
    for a,b in (('Group2','Group3'),('Group2','Group4'),('Group3','Group4'),('Group6','Group7'),('Group6','Group8'),('Group7','Group8')):
        t = stats.ttest_ind(gs[grp==a], gs[grp==b], equal_var=False); print(f"    {a} vs {b}: diff {gs[grp==a].mean()-gs[grp==b].mean():+.2f}, Welch p={t.pvalue:.2g}")
