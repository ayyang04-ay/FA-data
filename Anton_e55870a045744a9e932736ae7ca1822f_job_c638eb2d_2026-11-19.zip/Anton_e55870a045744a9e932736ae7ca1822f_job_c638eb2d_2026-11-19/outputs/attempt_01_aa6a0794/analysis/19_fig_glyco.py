"""Figure 5: glycoproteomics. Share of total glycopeptide reporter intensity by glycan class in each TMT channel
(loading-independent), non-targeting vs MGAT1-KO populations, A375 and NCI-H1703; plus sentinel sites."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
igp = pd.read_pickle("/tmp/work/glyco_igp_stats.pkl")
ch = [c for c in igp.columns if c.startswith('Intensity ')]
cls_map = {'Man5':'Man5 (MGAT1 substrate)','high-mannose':'Man6-9 high-mannose','paucimannose/truncated':'truncated / paucimannose','other(HexNAc2)':'truncated / paucimannose','hybrid/mono-antennary':'hybrid + complex (need MGAT1)','complex':'hybrid + complex (need MGAT1)'}
igp['cls'] = igp['class'].map(cls_map)
share = igp.groupby('cls')[ch].sum()/igp[ch].sum()*100
share.columns = [c.replace('Intensity ','') for c in ch]
grp = {'A375\nnon-targeting':['AM_N1','AM_N2','AM_N3','AM_N4'],'A375\nMGAT1 KO':['AM_KO1','AM_KO2','AM_KO3','AM_KO4'],'NCI-H1703\nnon-targeting':['NH_N1','NH_N2','NH_N3','NH_N4'],'NCI-H1703\nMGAT1 KO':['NH_M_KO1','NH_M_KO2','NH_M_KO3','NH_M_KO4']}
order = ['Man5 (MGAT1 substrate)','hybrid + complex (need MGAT1)','Man6-9 high-mannose','truncated / paucimannose']
cols = ['#c0392b','#1f77b4','#bbbbbb','#dddddd']
fig,(ax,ax2) = plt.subplots(1,2, figsize=(14,5.6), gridspec_kw={'width_ratios':[1.25,1]})
x = np.arange(len(grp)); w=0.2
for k,(cl,col) in enumerate(zip(order,cols)):
    means = [share.loc[cl, v].mean() for v in grp.values()]
    ax.bar(x+(k-1.5)*w, means, w, color=col, label=cl, edgecolor='k', linewidth=0.4)
    for xi,v in zip(x, grp.values()):
        ax.scatter([xi+(k-1.5)*w]*4, share.loc[cl, v], s=9, color='k', zorder=5)
    for xi,m in zip(x,means): ax.text(xi+(k-1.5)*w, m+1.2, f"{m:.0f}" if m>=10 else f"{m:.1f}", ha='center', fontsize=8)
ax.set_xticks(x); ax.set_xticklabels(list(grp.keys())); ax.set_ylabel("share of total glycopeptide reporter intensity (%)")
ax.legend(fontsize=8.5, frameon=False, loc='upper center', ncol=2); ax.set_ylim(0,70)
ax.set_title("Glycan-class composition per TMT channel (bars = mean of 4 channels, dots = channels)", fontsize=10, loc='left')
S = pd.read_csv("/tmp/outputs/tables/glyco_site_complex_share.csv")
sent = ['CD276_N91','LAMP1_N249','ITGB1_N481','CD63_N130','SLC3A2_N381','TFRC_N251','LRP1_N4364','MCAM_N544']
S = S.set_index('site').loc[sent]
y = np.arange(len(sent))[::-1]; h=0.19
for k,(c,col,labl) in enumerate([('A375_NT','#9ecae1','A375 non-targeting'),('A375_KO','#08519c','A375 MGAT1 KO'),('H1703_NT','#fcbba1','H1703 non-targeting'),('H1703_KO','#a50f15','H1703 MGAT1 KO')]):
    ax2.barh(y+(1.5-k)*h, S[c]*100, h, color=col, label=labl)
ax2.set_yticks(y); ax2.set_yticklabels([s.replace('_',' ') for s in sent]); ax2.set_xlabel("hybrid + complex glycoforms, % of that site's intensity")
ax2.set_xlim(0,128); ax2.set_xticks([0,20,40,60,80,100]); ax2.legend(fontsize=8, frameon=False, loc='center right'); ax2.set_title("Eight of the largest-shift sites (candidate marker sites for compound testing).\nNot typical: median site keeps 66% (A375) / 74% (H1703) of its share", fontsize=9.5, loc='left')
fig.suptitle("Glycoproteomics (glycoproteomics_site_quant.xlsx, sheet IGP_quant): MGAT1 knockout doubles Man5 and roughly halves hybrid + complex signal", fontsize=10.5)
fig.tight_layout(rect=(0,0,1,0.95)); fig.savefig("/tmp/outputs/figures/fig5_glycoproteomics_class_shift.png", dpi=160)
print(share.round(1).to_string()); print(S[['A375_NT','A375_KO','H1703_NT','H1703_KO']].round(3))
