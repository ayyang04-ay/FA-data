# MGAT1 inhibitor programme (Antera): independent verification and recommendation

Prepared 1 November 2026 from the 16 files in the client package. Every number below comes from those files. Tags in square brackets, such as [A2], point to the evidence ledger (Appendix A and `evidence_ledger.csv`), which gives the source file and location for each number and the script that produced it.

## 1. Recommendation

**Do not advance the compound series yet. Hold it at its current stage, and release further spend only if a short cell-based package shows that the compound reproduces what deleting MGAT1 does.** By "advance" I mean in vivo efficacy work, candidate nomination, or any milestone that presumes a working inhibitor in cells.

The case for MGAT1 as a target survives my re-analysis of the raw data and is strong. The compounds are real, potent binders of the purified enzyme. But nothing in the package connects the two. It contains no test of any compound in a cell or an animal [D15]; every biological result comes from deleting the gene. The data also give specific reasons why the connection cannot be assumed (section 3), and the "STK11-mutant, checkpoint-resistant NSCLC" label runs ahead of the evidence (section 4).

In one line: the client has a validated target and a validated binder, but not yet evidence that the binder does the target's job in a cell. This is a "not yet", not a "no". Section 5 sets out what would bring it back, and what should end it.

## 2. What holds up

I re-analysed both CRISPR screens, the glycoproteomics and the crystal structures from the raw files, and re-measured the figures. The findings the programme rests on hold up.

| Claim | Verdict | What my re-analysis shows |
|---|---|---|
| Deleting MGAT1 makes human tumour cells easier for T cells to kill | Reproduced from raw data | Genome-wide screen in NCI-H1703: MGAT1 ranks 19th of 19,052 genes (z = −8.2), all four guides depleted, rank 5 to 92 under four other scoring methods [A2–A4]. Screen controls behave as they should [A5]. Four further guides, different from those in the screen, reproduce it in two NSCLC lines: relative viability 0.17–0.54 against 0.79–0.92 for control [A9, A10]. |
| The effect needs MGAT1's enzyme activity | Consistent in the figures; raw data not supplied | Wild-type MGAT1 restores T-cell resistance (0.72 → 1.15); catalytically inactive mutants do not (0.54–0.57) [A11]. The same holds in mice: knockout tumours given wild-type MGAT1 reach 863 mm³, against 420 mm³ with the inactive mutant [B18]. |
| Deleting MGAT1 strips complex N-glycans | Reproduced from raw data (mass spectrometry) and figures (lectins) | Staining for complex glycans (lectin PHA-L) falls to about 3% of control; staining for the unprocessed precursor (lectin GNA) rises 8–9-fold [A13]. By mass spectrometry the precursor (Man5) doubles from 20% to 40% of signal and complex forms roughly halve [C2–C4]. |
| In mice, the dependence is strongest in Stk11-deficient tumours under immune pressure | Reproduced from raw data; treatment-arm labels inferred | Of 795 genes, Mgat1 is the 1st to 8th most Stk11-knockout-selective dependency in immunocompetent mice (1.7–2.4 log2 units more depleted than in the wild-type background, z = −5.2 to −9.4). A second method (edgeR) gives the same ranks [B5, B6]. Single-gene knockout: tumours about 50% smaller [B16]. |
| The compounds bind and inhibit purified MGAT1 | Consistent across registry, figures and structures | ANT-4267 inhibits at 43 nM and binds at 30–70 nM [D1, D2]. Across the series, inhibition tracks binding (r = 0.95) [D7]. Five crystal structures at 1.55–2.0 Å [D11]. Solubility and hepatocyte stability are good [D2]. |

In this memo, z is the distance from the average of random sets of non-targeting control guides, in standard deviations; a log2 change of −1 means half as abundant.

Two features of the chemistry deserve credit. Potency improved by more than three orders of magnitude from the screening hit [D1]. And ANT-3744 does not compete with UDP, the nucleotide part of the donor substrate [D8, D9], so the high donor concentrations inside cells should not blunt it.

## 3. Why the compound cannot be advanced on this evidence

**1. There are no compound data in cells.** The registry has no cellular, permeability, selectivity or pharmacokinetic columns, and none of the eleven phenotype pages involves a compound [D15]. Whether the compound reaches MGAT1 inside a cell and changes glycans is unknown.

**2. The compound binds far from the catalytic site, and how it inhibits is not established.** In the crystal structure ANT-3744 sits in a pocket at the C-terminal end of the protein, 24 Å from the bound UDP and 18 Å from D289, the nearer of the two residues the client mutates to inactivate the enzyme [D12, D13] (Figure 4). The catalytic domain does not change shape when it binds [D14]. Inhibition was measured on a truncated enzyme with a free five-sugar acceptor (records §6.3), not on the full-length enzyme acting on a glycoprotein. Whether the compound competes with the acceptor is not reported.

**3. Inhibition appears to stop at about 90%.** The four potent analogues all level off at 8–10% residual signal, out to concentrations hundreds to thousands of times their IC50 [D4] (Figure 3). This is either assay background (signal that does not depend on sugar transfer) or genuinely partial inhibition. The records do not say how 0% was defined, so I cannot tell which.

**4. The biology has only been shown for complete or near-complete loss of function.** Every sensitised state in the package has PHA-L at roughly a tenth of control or less (3% or less in the human lines, 11–14% in the engineered rescue line); every protected state has it at 80% or more [A12, A13, A16]. Nothing lies in between. Two observations suggest the bar is high. Knocking out the next branching enzymes does not reproduce the effect in either screen (MGAT2 rank 2,493; Mgat2 not depleted in any mouse arm) [A6, B12]. And over-expressing MGAT1 well above normal does not raise PHA-L, which suggests the enzyme is present in excess [A15]. This matters because of point 3: a reversible inhibitor that leaves 10% of activity may not be enough.

**5. A drug is not a knockout, and the knockout sets a moderate ceiling.** Complete deletion from the day of implantation gives tumours about half the size, not regressions [B16–B18]. A drug would start on established tumours and reach T cells as well as tumour cells; every experiment here removed MGAT1 from tumour cells only. There are no data on the mouse enzyme, on selectivity against related enzymes, or on tolerability. The mechanistic work (competition, thermal shift, structures) was done on ANT-3744, not on the 19-fold more potent ANT-4267 [D1, D8–D13].

## 4. Where the indication label runs ahead of the data

- **STK11.** The link rests on one engineered mouse colon line, MC38 [B4–B6, B16]. The STK11 status of the human lines is not documented anywhere in the package, and in the human screen STK11 knockout itself was neutral (z = +1.3) [A8]. In Stk11-wild-type MC38, single-gene MGAT1 knockout gave no benefit; tumours were numerically larger (1,778 vs 1,164 mm³) [B16].
- **Checkpoint resistance.** The Stk11-deficient model responds less to anti-PD-1 than wild-type (33–49% smaller tumours against 75%) but is not refractory [B17, B19]. MGAT1 loss does not restore the response. In the screen, anti-PD-1 added nothing to Mgat1 depletion (−0.01 log2, 95% CI −0.50 to +0.48), while a known sensitiser, Ptpn2, was detected in the same comparison [B10]. In the single-gene study the combination matched what two independent effects would give (399 mm³ observed, 412 predicted) [B17]. The supportable claim is "acts independently of PD-1 blockade".
- **T-cell mechanism.** In Stk11-deficient tumours, about half to two-thirds of the Mgat1 depletion is already present in nude mice, which lack T cells [B9]. An intact immune system adds a further 1.0 log2 unit (95% CI 0.45–1.61) [B8]. So the mouse effect is only partly the T-cell mechanism shown in human cells.
- **NSCLC.** The human evidence is in NSCLC lines; the in vivo Stk11 evidence is in a colon line.

## 5. What would bring it back

Gates 1–3 are cell-based, quick, and decide the programme. Gate 4 can run alongside. Gates 5–6 should wait until 1–3 pass. Benchmarks are the client's own knockout results. The single most informative experiment is Gates 1 and 3 run together: one dose series of ANT-4267 on control and MGAT1-knockout NSCLC cells, read out as glycan staining and as T-cell killing.

| Gate | What it must establish | Comparisons the data must include | Benchmark from client data | Bring-back criterion |
|---|---|---|---|---|
| 1. Target engagement in cells | The compound remodels N-glycans in intact cells, dose-dependently, at soluble and non-toxic concentrations | MGAT1-knockout and control cells side by side; at least three analogues spanning the potency range, for example ANT-4267, ANT-3744 and ANT-2118 (cell rank order should follow enzyme rank order); compound on knockout cells (should add nothing); human and mouse lines | PHA-L ≈ 3% of control, GNA 8–9× [A13]; Man5 20% → 40%; CD276 N91 complex forms 10–15% → 1% [C2, C5] | PHA-L loss of ≥90%, or the level Gate 2 shows to be sufficient |
| 2. How much inhibition is enough | The relationship between residual MGAT1 activity and T-cell sensitisation; and whether the 8–10% enzyme floor is real | Graded genetic loss (for example titrated re-expression in knockout cells) plotted as PHA-L against T-cell killing; compound dose-response on the same axes; enzyme assay with a defined zero | Only two states exist today: PHA-L at 14% of control or less (sensitised) and 80% or more (protected) [A12, A13, A16] | Compound's maximal cellular effect reaches the sufficient level |
| 3. Functional phenocopy and specificity | The compound sensitises tumour cells to antigen-specific T-cell killing, through MGAT1 | Control vs MGAT1-knockout cells ± compound; B2M knockout and non-specific T cells as assay controls; compound on tumour cells only, T cells only, and both; an MGAT1 pocket mutant that no longer binds the compound, if it keeps activity; both NSCLC lines | Knockout: 0.17–0.54 vs 0.79–0.92 control [A9, A10]; wild-type rescue returns to 1.15 [A11] | At least half the knockout effect in both lines, absent in knockout cells, with T-cell killing of control targets intact |
| 4. Mechanism and selectivity | How a distal binder blocks catalysis, and that it does so on the natural substrate | Competition with acceptor and with UDP-GlcNAc; full-length enzyme and glycoprotein acceptor; ANT-4267 in the same site; mouse enzyme; related GlcNAc-transferases | ANT-3744: KD 0.4 μM, not weakened by UDP [D8] | Comparable potency on natural substrate and on mouse enzyme; clean selectivity |
| 5. In vivo exposure, then efficacy | Exposure that holds the tumour glycan marker near the knockout state, then tumour control | Stk11-deficient and wild-type MC38; immunocompetent and nude hosts; ± anti-PD-1; an MGAT1-knockout tumour arm in the same study; the glycan marker on tumour cells and on host immune cells; tolerability; individual animals, with group sizes set from the client's own variability (error bars 47–89% of the mean [B21]) | Knockout: 46–51% smaller in Stk11-deficient [B16–B18]; none in wild-type; additive with anti-PD-1 | A pre-agreed fraction of the knockout effect with marker confirmation, and a decision that this ceiling is worth pursuing |
| 6. Indication | That STK11 loss raises dependence on MGAT1 in human NSCLC | Matched STK11-intact and STK11-deficient human NSCLC cells in the T-cell assay, for knockout and compound; documented STK11 status for every line; a second Stk11-deficient mouse model, ideally lung | Mouse only: 1.7–2.4 log2 selective [B5, B6] | A larger effect in STK11-deficient human cells |

**What should end it.** If the best compound, at soluble and non-toxic concentrations, cannot drive glycan remodelling to the level Gate 2 shows is needed, or does not sensitise cells to T-cell killing, stop this series. The target would remain valid for a different chemical approach. Both screens also point to neighbouring steps in the same pathway that score as strongly as MGAT1 (SLC35A1, SLC35A2 and CMAS in human cells; B4galt1 in mice) [A7, B13].

## 6. What I set aside or discounted, and why

- **Four of 141 tumour libraries** in the mouse screen: one failed sequencing (349 reads), two had lost a third or more of the library, and one is a second copy of another sample filed under a different animal number [B2]. Keeping the two bottlenecked tumours does not change the result.
- **Conventional p-values for cross-background comparisons.** Under a standard t-test, random sets of non-targeting control guides came out "significant" 14–46% of the time instead of 5%, so I scored every gene against non-targeting controls instead.
- **The Stk11 comparison in nude mice.** Its sign depends on the method (−0.87 or +0.88), so I treat it as no evidence either way [B7].
- **Potency values for the screening hit ANT-0592.** It inhibits only above its solubility limit [D6].
- **The two acquired compounds, ANT-1938 and ANT-2214.** Neither shows saturable binding [D10]; they are not usable comparators.
- **Data points at 1,000 μM.** They lie above solubility and ten times above the top concentration given in the records [E2].
- **Absolute fold-changes in the glycoproteomics.** Knockout channels carry about 1.6 times the total signal, so I used within-channel composition instead [C3].
- **Statistical significance of the tumour-growth figures.** The figures give no group size and do not say whether bars are SD or SEM [B21]. I used them for direction and approximate size only.
- **PD-L1 as the mechanism.** PD-L1 is not detected in the glycoproteomics [C5], no PD-L1 blot is in the package, and PD-L1 knockout is neutral in the human screen [A8].
- **Anything from outside the package**, including published MGAT1 biology and public cell-line genotypes.

## 7. What I could not verify, and what to ask the client

I could not check: ligand electron density (no structure factors were supplied); raw binding (SPR), thermal-shift, flow-cytometry and tumour-volume data; or the enzyme activity of the mutant proteins, which the records describe but do not report.

Questions that would tighten the picture:

1. Which treatment arm is each of Groups 1–8 in the mouse screen? The records do not say. I inferred the arms from internal controls [B3]. Groups 3 and 4 (and 7 and 8) are indistinguishable and both look anti-PD-1-treated.
2. The records give 45 animals; the file has 141 tumours [E1]. Which is right, and why do samples 82346 and 82364 carry the same library?
3. What are the group sizes and error-bar definitions for every tumour-growth and co-culture figure?
4. What is the STK11 status of NCI-H1703, NCI-H1755 and A375?
5. How was 0% activity defined in the enzyme assay, and what was the top concentration tested [E2]?
6. Is there any cellular or in vivo compound data not in this package? The records are dated 18 August 2026 and the PDFs are stamped 18 November 2026 [E3], so I cannot confirm what "current to 1 November" covers.

## Figures

**Figure 1. Mouse screen: Mgat1, Mgat2 and two control genes, by group.**

![Figure 1](figures/fig1_invivo_screen_mgat1_by_group.png)

**Figure 2. Human co-culture screen: MGAT1 against reference genes, and its four guides.**

![Figure 2](figures/fig2_coculture_screen_mgat1.png)

**Figure 3. Enzyme inhibition curves re-fitted from the client's figure, showing the residual plateau.**

![Figure 3](figures/fig3_dose_response_refit.png)

**Figure 4. Where ANT-3744 binds relative to the catalytic site.**

![Figure 4](figures/fig4_structure_binding_site.png)

**Figure 5. Glycoproteomics: glycan classes in control and MGAT1-knockout cells.**

![Figure 5](figures/fig5_glycoproteomics_class_shift.png)

## Appendix A. Evidence ledger

Each row is a number used above. "Kind" is *direct* (read from a client file), *computed* (my re-analysis of client raw data) or *digitised* (measured from a figure image). Script and table paths are relative to the output folder. The same table is in `evidence_ledger.csv`.

| ID | Statement | Value | Client source | How derived | Kind | Note |
|---|---|---|---|---|---|---|
| A1 | Genes scored in NCI-H1703 co-culture screen | 19,052 genes; 77,079 guides; 7,960,054 UMI rows | coculture_screen_umi_counts.csv.gz | analysis/03_coculture_screen.py -> tables/coculture_gene_stats.csv | computed | guides with <100 tumour-only reads dropped (2,879) |
| A2 | MGAT1 rank among sensitisers (knockout increases T-cell killing) | rank 19 of 19,052; z = -8.2; mean log2FC -0.85; FDR < 0.001 | coculture_screen_umi_counts.csv.gz (rows gene_symbol = MGAT1) | analysis/03 -> tables/coculture_gene_stats.csv | computed | null = 200,000 random 4-guide sets of the 989 non-targeting guides |
| A3 | MGAT1 per-guide log2FC (T-cell vs tumour-only, NTC-centred) | -1.18, -1.11, -0.64, -0.46 (reads 782->302, 743->301, 1341->757, 657->420) | same | analysis/03 -> tables/coculture_guide_stats.csv; figures/fig2 | computed | weakest guide sits at the 2nd percentile of non-targeting guides |
| A4 | MGAT1 rank under alternative scoring | 5 (UMI-level), 27 (median guide), 42 (winsorised), 92 (weakest guide) | same | analysis/03, 04 -> tables/coculture_gene_stats_umi_level.csv | computed | UMI-level: 70% of 187 MGAT1 UMI lineages fall below the non-targeting median |
| A5 | Screen positive controls | B2M z +14.0 (rank 1 enriched); CTAG1B (NY-ESO-1 antigen) +13.3 (rank 2); PTPN2 -13.0 (rank 3 depleted); CFLAR -19.7 (rank 1) | same | analysis/03 | computed | shows the single-replicate screen behaved as expected |
| A6 | Other N-glycan branching enzymes do not score | MGAT2 z -1.7 (rank 2,493); MGAT5 z -1.4 (rank 3,139); MGAT4B z -3.0 (rank 600) | same | analysis/03 | computed |  |
| A7 | Sugar-nucleotide supply genes score as strongly or more strongly than MGAT1 | SLC35A1 z -14.1 (rank 2); SLC35A2 -10.8 (rank 5); GALE -10.7 (6); UAP1 -8.1 (20); CMAS -8.0 (21) | same | analysis/03 | computed |  |
| A8 | STK11, CD274 (PD-L1), CD276 knockouts are neutral in H1703 | z +1.3, -1.3, +1.6 | same | analysis/03 | computed | STK11 genotype of H1703 is not documented in the package |
| A9 | Arrayed validation, NCI-H1703 (relative viability with T cells) | sgNTC 0.92 / 0.86 (E:T 0.2 / 0.4); four sgMGAT1 0.25-0.54; sgB2M 1.85 / 1.97 | phenotype_figures.pdf p3 | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised | validation guides are 4 different sequences from the 4 library guides (records section 1 vs screen file) |
| A10 | Arrayed validation, NCI-H1755 (E:T 0.2) | sgNTC 0.79; four sgMGAT1 0.17-0.48; sgB2M 1.84 | phenotype_figures.pdf p3 | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised |  |
| A11 | cDNA rescue (viability with T cells, mean of 2 donors) | sgNTC+vector 1.15; sgMGAT1+vector 0.72; +WT 1.15; +D289A 0.57; +D211A/D289A 0.54 | phenotype_figures.pdf p5 (right) | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised | n = 2 wells x 2 donors |
| A12 | cDNA rescue (PHA-L MFI, x1e6) | sgNTC+vector 6.7; sgMGAT1+vector ~0.03; +WT 5.35; +D289A ~0; +D211A/D289A ~0 | phenotype_figures.pdf p5 (left) | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised |  |
| A13 | Lectin phenotype of MGAT1 knockout | PHA-L 0.027 (A375) and 0.032 (H1703) of control; GNA 8.2x and 8.7x | phenotype_figures.pdf p2 | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised |  |
| A14 | Adoptive-transfer xenograft, day 19 (mm3), sgNTC vs sgMGAT1 | control T cells 1931 vs 1641 (-15%); 1e6 NY-ESO T 1303 vs 616 (-53%); 2e6 NY-ESO T 601 vs 176 (-71%) | phenotype_figures.pdf p4 | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised | cell line / n / error-bar type not stated |
| A15 | Rescue constructs are over-expressed, yet PHA-L is no higher than control | MGAT1 band in cDNA lanes far above the endogenous band (immunoblot); PHA-L 6.35e6 (sgNTC+WT cDNA) vs 6.7e6 (sgNTC+vector) | phenotype_figures.pdf p11 (blot), p5 (left) | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised | suggests MGAT1 is not limiting at normal levels; indirect |
| A16 | PHA-L in the engineered rescue panel (flow histogram, modal fluorescence) | unstained ~110; sgNTC+WT ~9,600; sgMGAT1+WT ~11,400; sgMGAT1+D211A/D289A ~1,100 (about 11% of control); same at high MOI ~1,500 (about 14%) | phenotype_figures.pdf p6 (histogram) | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised | cell line not labelled; no knockout-only trace, so the 11-14% may be background lectin binding or residual mutant activity |
| A17 | The co-culture screen carries a small general-fitness component, which does not explain MGAT1 | essential-gene guides: mean log2FC -0.14 (non-targeting -0.00); 15% of essential genes at z < -3 vs 3% of other genes.  MGAT1 guides sit at normal abundance in the tumour-only arm (657-1,341 reads; library median 697; essential-gene median 108) | coculture_screen_umi_counts.csv.gz (genetype = ESG vs NegCtrl) | analysis/03 -> tables/coculture_guide_stats.csv | computed | so MGAT1 knockout had no fitness cost before T cells were added |
| B1 | Samples in the in vivo count matrix | 159 columns: 141 tumours (8 groups), 6 baseline, 6 in-vitro endpoint, 6 plasmid; 3,580 guides (795 genes x 4 + 400 non-targeting) | crispr_invivo_guide_counts.csv.gz; crispr_invivo_ngs_demux.csv.gz | analysis/01_invivo_qc.py -> tables/invivo_sample_qc.csv | direct |  |
| B2 | Tumour libraries excluded | 4 of 141: Group7_STK11_82431 (349 reads); Group3_NTC_82276 (45% guides at zero); Group4_NTC_82321 (33%); Group3_NTC_82364 (same library as 82346: non-targeting Spearman 0.98, raw-count Pearson 0.995) | crispr_invivo_guide_counts.csv.gz | analysis/01 -> tables/invivo_excluded_samples.csv | computed | results unchanged if the two bottlenecked tumours are kept (tables/invivo_mgat1_robustness.csv) |
| B3 | Group identity (inferred, not in records) | G1/G5 nude; G2/G6 PD-1 axis intact (isotype); G3,G4/G7,G8 PD-1 axis blocked | - | analysis/09, 14, 23 | computed | Cd274-knockout score: G1 +0.75, G2 -3.01, G3 -0.33, G4 -0.17, G5 +0.44, G6 -1.00, G7 -0.28, G8 +0.24; G1/G5 have separate contiguous animal-ID blocks; leave-one-out arm classification 97% (WT) / 87% (Stk11-KO); G3 vs G4 not separable (55%) |
| B4 | Mgat1 gene score (mean log2FC vs baseline) by group | WT: in vitro +0.19; G1 -0.99; G2 -1.19; G3 -0.71; G4 -0.43.  Stk11-KO: in vitro -0.29; G5 -1.86; G6 -2.89; G7 -2.96; G8 -2.85 | crispr_invivo_guide_counts.csv.gz (rows Mgat1_1..4) | analysis/02, 09, 10 -> tables/invivo_mgat1_by_condition.csv; figures/fig1 | computed | n per group 18,17,13,20 / 17,17,17,18; in vitro n = 3 each |
| B5 | Stk11-KO minus WT, immunocompetent isotype arm (G6 - G2) | -1.71 log2 (95% CI -2.38 to -1.03); z -5.2 vs 5,000 non-targeting pseudo-genes (empirical p <= 0.0004); rank 8 of 795 by t, 2 by effect size | same | analysis/10, 14 -> tables/invivo_mgat1_contrasts.csv, invivo_mgat1_robustness.csv | computed | edgeR cross-check: -1.32, rank 8 of 795 (tables/invivo_edger_crosscheck.csv) |
| B6 | Stk11-KO minus WT, anti-PD-1 arms (G7+8 - G3+4) | -2.36 (95% CI -2.79 to -1.94); z -9.4; rank 1 of 795 | same | analysis/10, 14 | computed | edgeR: -2.33, rank 1 of 795 |
| B7 | Stk11-KO minus WT, nude mice (G5 - G1) | -0.87 (z -1.9, empirical p 0.06) by log-mean method; +0.88 (z +1.0) by edgeR -> no robust difference | same | analysis/10, 14, 21 | computed | set aside: sign depends on method because G1 tumours are heavily jackpotted (Gini 0.74-0.91) |
| B8 | Immunocompetent minus nude within Stk11-KO (G6 - G5) | -1.03 (95% CI -1.61 to -0.45); z -4.6 (empirical p <= 0.0004) | same | analysis/10, 14 | computed | edgeR -1.39, z -4.6.  Same contrast in WT (G2 - G1): -0.19, z +0.1 |
| B9 | Share of Stk11-KO Mgat1 depletion already present without T cells | G5 / G6 = -1.86 / -2.89 = 64% (log-mean); -1.27 / -2.66 = 48% (edgeR); -2.39 / -3.46 = 69% (median abundance ratio vs non-targeting guides) | same | analysis/10, 21, 22 | computed | nude mice keep innate immunity: B2m-knockout -2.3 and Cd47-knockout -2.6/-3.0 in G1/G5 |
| B10 | Anti-PD-1 minus isotype within Stk11-KO (G7+8 - G6) | -0.01 (95% CI -0.50 to +0.48); z 0.0; rank 427 of 795 | same | analysis/10, 14 | computed | positive control for this contrast: Ptpn2 -0.58 (z -3.4, rank 7).  In WT: +0.65 (z +3.0), i.e. less depletion under anti-PD-1 |
| B11 | Mgat1 in vitro (endpoint vs baseline) | WT +0.19; Stk11-KO -0.29 (n = 3 flasks each) | same (Endpoint_* columns) | analysis/10 | computed | no meaningful cell-intrinsic fitness cost in culture |
| B12 | Mgat2 is not depleted in any arm | +0.06 to +0.86 | same (rows Mgat2_1..4) | analysis/10; figures/fig1 | computed |  |
| B13 | B4galt1 is the other top Stk11-KO-selective hit | all in vivo: -1.50 (rank 1 by t; Mgat1 rank 2); isotype -1.71; anti-PD-1 -1.75 | same | analysis/10 -> tables/invivo_all_genes_all_contrasts.csv.gz | computed |  |
| B14 | Assumption-free check: Mgat1 guide retention | Stk11-KO B6 arms: guides 1, 2, 4 retained (>=25% of baseline) in 0-12% of tumours vs 94% for the median non-targeting guide; median abundance ratio 0.07-0.08 vs 0.77-0.83 | same | analysis/22 -> tables/invivo_mgat1_retention_nonparametric.csv | computed |  |
| B15 | Functional evidence of Stk11 loss in the STK11 arm | in vitro, Sik3 (-1.24) and Mark2 (-0.98) knockouts are selectively depleted and Crtc3 (+0.77) enriched in the Stk11-KO background | same | analysis/10 -> tables/invivo_all_genes_all_contrasts.csv.gz | computed | interpretation (Stk11 substrates) is mine |
| B16 | Single-gene MC38 studies (mm3): sgNTC vs sgMGAT1 | Stk11-WT day 25: 1164 vs 1778 (+53%); Stk11-KO day 19: 1088 vs 542 (-50%) | phenotype_figures.pdf p1 (left, middle) | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised | error bars (as drawn) +-818/865 and +-510/450; n and SD/SEM not stated |
| B17 | Single-gene MC38-sgSTK11 +/- anti-PD-1, day 9 (mm3) | NTC IgG 1139; NTC anti-PD-1 758 (-33%); sgMGAT1 IgG 619 (-46%); sgMGAT1 anti-PD-1 399 | phenotype_figures.pdf p1 (right) | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised | independent-effects expectation for the combination = 1139 x 0.666 x 0.543 = 412 vs 399 observed -> additive |
| B18 | Catalytic-dead rescue in vivo, day 19 (mm3) | sgSTK11+sgMGAT1: WT cDNA 863 vs D211A/D289A 420 (-51%); sgSTK11+sgNTC (day 12): 894 vs 791 | phenotype_figures.pdf p7 | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised | the MGAT1-knockout arm of this panel derives from a single clone (A-F5; p11 schematic); the WT-vs-mutant comparison is within that clone, which controls for clonal effects |
| B19 | MC38 library populations: host and anti-PD-1 dependence (mm3) | Stk11-WT day 8: nude 929, B6 381, B6+anti-PD-1 96 (-75%); Stk11-KO day 7: nude 964, B6 1266, B6+anti-PD-1 648 (-49%) | phenotype_figures.pdf p8 | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised | the Stk11-KO model is anti-PD-1 hypo-responsive, not refractory |
| B20 | Residual STK11 protein in engineered MC38 lines | STK11/vinculin ~0.06-0.09 of parental in sgSTK11 lanes; ~0.09-0.20 in sgSTK11 + cDNA lanes | phenotype_figures.pdf p6 | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual); rough densitometry of the embedded image | digitised | semi-quantitative only |
| B21 | Variability in the MC38 tumour-growth figures | drawn error bars are 47-89% of the group mean at the last time point | phenotype_figures.pdf p1 | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual) | digitised | n and SD/SEM not stated, so significance cannot be computed |
| C1 | Glycoproteomics dataset size | 2,687 intact glycopeptides, 910 sites, 524 proteins; 16 TMT channels | glycoproteomics_site_quant.xlsx | analysis/05_glycoproteomics.py | direct | the three sheets roll up exactly (site = sum of glycoforms = sum of PSM rows) |
| C2 | Man5 share of glycopeptide signal, non-targeting -> MGAT1 KO | A375 19.9% -> 40.1%; H1703 18.8% -> 40.4% | sheet IGP_quant | analysis/06 -> tables/glyco_class_summary.csv; figures/fig5 | computed | within-channel shares, so independent of loading |
| C3 | Hybrid + complex share, non-targeting -> KO | A375 9.9% -> 5.5%; H1703 9.1% -> 5.1% (56% remains) | sheet IGP_quant | analysis/06 | computed | KO channels carry ~1.6x the total signal of control channels, so raw fold-changes were not used |
| C4 | Site-level confirmation | complex share fell at 125 of 164 sites in each line (sign test p = 1e-11); median site keeps 66% (A375) / 74% (H1703) | sheet IGP_quant | analysis/06 -> tables/glyco_site_complex_share.csv | computed |  |
| C5 | Example site: CD276 (B7-H3) N91 complex share | 14.6% -> 1.2% (A375); 10.2% -> 0.9% (H1703) | sheet IGP_quant | analysis/06 | computed | PD-L1 (CD274) is not among the 524 proteins detected |
| D1 | Registry potencies (UDP-Glo IC50, uM) | ANT-0592 197; ANT-2118 25.6; ANT-1476 2.02; ANT-3744 0.814; ANT-3105 0.543; ANT-4267 0.043 | compound_properties.csv | - | direct | re-fit of the plotted curves: 176, 23, 1.4, 0.42, 0.32, 0.037 (tables/ic50_refit.csv) |
| D2 | ANT-4267 profile | SPR KD 0.07 uM (steady-state) / 0.03 uM (kinetic); kinetic solubility 96.4 uM; hepatocyte CLint < 1.35 ul/min/1e6 cells; MW 478; LogD 2.6; TPSA 108 | compound_properties.csv | - | direct | species of the hepatocytes not stated |
| D3 | ANT-3744 profile | IC50 0.814 uM; KD 0.38 uM; solubility 178 uM; CLint 3.2; MW 419; TPSA 110 | compound_properties.csv | - | direct | structure in CIF: C23H25N5O3, MW 419.5, TPSA 110.4 (RDKit) - matches |
| D4 | Residual-activity plateau of the potent analogues | fitted floor 8-10% of control (ANT-1476 8.3, ANT-3105 8.9, ANT-3744 7.9, ANT-4267 9.8; SE 0.5-1.3) | assay_figures.pdf p1 | analysis/digitisation/ic50_digit.py, 11_ic50_refit.py -> tables/ic50_refit.csv; figures/fig3 | digitised | fits with the floor forced to 0 are 4-38x worse (RSS); how 0% was defined is not in the records |
| D5 | Hill slopes | 0.85-1.17 for the four potent analogues; 1.33 for ANT-0592 | assay_figures.pdf p1 | analysis/11 | digitised |  |
| D6 | ANT-0592 is insoluble where it inhibits | kinetic solubility 11.8 uM; activity 96% at 12 uM; IC50 197 uM; 5 of 10 test concentrations above solubility | compound_properties.csv; assay_figures.pdf p1 | analysis/11 | direct + digitised | registry flags its KD with * |
| D7 | IC50 tracks SPR KD across the series | log-log r = 0.95 (19 resolved points of ~25); geometric-mean IC50/KD 1.7 | assay_figures.pdf p5 | analysis/12_ic50_vs_kd.py -> tables/ic50_vs_kd_digitised.csv | digitised |  |
| D8 | ANT-3744 and UDP bind at the same time | KD(ANT-3744) 0.4 -> 0.2 uM with 5 mM UDP; KD(UDP) 32 -> 20 uM with 20 uM ANT-3744 | spr_competition.csv; assay_figures.pdf p3 | - | direct | if competitive, 5 mM UDP would push the apparent KD to ~63 uM |
| D9 | Thermal shift is additive | dTm +2 (UDP), +6 (ANT-3744), +8 (both); Tm 51 / 55 / 57 C | dsf_thermal_shift.csv; assay_figures.pdf p4 | analysis/digitisation/*.py -> tables/figure_digitisation.csv (its method column says auto or manual); derivative-peak positions +2.0, +5.9, +7.5 | direct + digitised |  |
| D10 | Acquired compounds do not bind | ANT-1938 IC50 > 100 uM (40% inhibition); ANT-2214 74 uM (60%); no saturable SPR binding | compound_properties.csv; assay_figures.pdf p2 | - | direct |  |
| D11 | Crystal structures | apo 1.65 A; UDP 1.55; UDP-GlcNAc 2.00; ANT-3744 2.00; ANT-3744+UDP 2.01 A; Rfree 0.18-0.22; wild-type human MGAT1 104-445, two copies each | MGAT1_*.cif headers | analysis/07_structures.py -> tables/structure_stats.csv | direct | no structure factors supplied, so ligand density could not be re-examined |
| D12 | ANT-3744 binding site | pocket formed by residues 388-444 (Y388, F394, P412, P434, W437, E438, G439, Y440, D441, W444); 67% of ligand surface buried | MGAT1_C3744.cif, MGAT1_C3744_UDP.cif | analysis/07, 13 -> tables/structure_ligands.csv | computed |  |
| D13 | Distance from ANT-3744 to the catalytic site | 23.9 / 24.2 A to nearest UDP atom (chains A / B); 25.8 / 26.2 A to Mn; 18.1-18.6 A to D289 side chain; 27 A to D211 | MGAT1_C3744_UDP.cif | analysis/08_structure_geometry.py; figures/fig4 | computed |  |
| D14 | No change in the catalytic domain on ANT-3744 binding | C-alpha RMSD 0.45-0.55 A (apo vs binary; UDP vs ternary); largest shifts are the pocket residues 436-439 (up to 4.8 A); a handful of others move 1.5-2.2 A | MGAT1_*.cif | analysis/08 | computed |  |
| D15 | Data on any compound in cells or animals | none in the package | all files | - | direct | registry has no cellular, permeability, selectivity, PK or in vivo columns; none of the 11 phenotype pages involves a compound (8 are gene-knockout or cDNA experiments, 3 are context: antigen expression, unmodified-line killing, blot and schematic) |
| E1 | Records vs file: animal numbers | records: C57BL/6 n = 30, nude n = 15; file: 141 tumour samples in 8 undecoded groups | experimental_records.pdf section 2, 2.1 | - | direct |  |
| E2 | Records vs figure: top test concentration | records: 100 uM; figure: 1000 uM for 5 of 6 compounds | experimental_records.pdf section 6.3; assay_figures.pdf p1 | analysis/digitisation/ic50_digit.py | direct + digitised |  |
| E3 | Dates | records "compiled 18 August 2026"; PDF creation stamps 18 November 2026 | experimental_records.pdf p1; PDF metadata | analysis/00_extract_pdfs.py | direct | brief says data are current to 1 November 2026 |

## Appendix B. How the re-analysis was done

- **Human co-culture screen.** Counts for each unique molecular identifier (UMI, a barcode marking one lineage of cells carrying a guide) summed per guide; log2 ratio of T-cell to tumour-only arm, centred on the 989 non-targeting guides; gene score is the mean of its guides, compared with 200,000 random four-guide sets of non-targeting guides. Because there is one sample per arm, I repeated the analysis at the level of individual UMI lineages and with outlier-capped counts. Guides against essential genes are mildly depleted in the T-cell arm (mean −0.14 log2), so the screen carries a small general-fitness component; MGAT1 guides sit at normal abundance in the tumour-only arm, so this does not explain the MGAT1 result [A17].
- **Mouse screen.** Counts normalised to reads per million; log2 fold-change of each tumour against the three baseline samples of the same background; centred on the 400 non-targeting guides; gene score per tumour is the mean of four guides. Groups are compared with the tumour as the unit, and each gene is scored against 5,000 random four-guide non-targeting sets. Cross-checked with edgeR and with a count-free retention measure.
- **Glycoproteomics.** Each glycopeptide classified by composition; the share of signal in each class computed within each channel, so that loading differences cancel.
- **Structures.** Statistics read from the file headers; distances, contacts and burial computed from coordinates.
- **Figures.** Values measured from the embedded images after calibrating the axes from tick marks; accuracy about ±2% of the axis range.

All scripts are in `analysis/` and run end to end with `analysis/run_all.sh`; outputs are in `tables/`.
