# MGAT1 inhibitor programme (Antera Therapeutics): independent verification and recommendation

Prepared 1 November 2026. Basis: the 16 client files in the data room, treated as ground truth. Every quantitative dataset was re-analysed from the raw files; scripts, tables and figures are attached (`scripts/`, `tables/`, `figures/`). Section 7 maps each number to its source. Mouse genes are written Stk11 and Mgat1, human genes STK11 and MGAT1. Screen effects are log2 fold-changes unless a fold is stated (−1 means halved, −3 means one-eighth).

---

## 1. Recommendation

**Do not advance the asset yet.** Hold the ANT series (best compound ANT-4267, tool compound ANT-3744) at its current stage. Do not commit to in vivo efficacy work, candidate selection or a checkpoint-combination development plan on this package. Fund one short bridging step with a stop/go decision at its end: show that a compound does in a tumour cell what the MGAT1 knockout does.

The target does not look wrong; most of the genetics verified. The call rests on two facts:

- **No compound has been tested for activity in a cell.** Every phenotype in the package is genetic. For the ANT compounds there is enzyme potency, binding, solubility and hepatocyte clearance, and nothing else: no cellular target engagement, no T-cell assay, no selectivity, no exposure, no in vivo data. The link between the molecule and the biology has not been attempted.
- **The indication hypothesis stands on one model, and its mechanism is open.** The Stk11-selective signal is strong in immunocompetent mice and persists under PD-1 blockade, which the positioning needs. But it comes from one engineered mouse colorectal line. PD-1 blockade does not deepen it. Roughly 45–75% of it is present without T cells. And the T-cell sensitisation the programme is built on is shown only with engineered T cells, in human cells whose STK11 status is not recorded; in Stk11-wild-type mouse tumours it is absent. The package cannot say whether this should be developed as a T-cell sensitiser, a combination partner or a single agent.

The first fact alone is enough for the call. It does not depend on how the in vivo screen arms are labelled, which I had to infer (section 3.1).

Five findings carry the call.

| # | Finding | Headline numbers |
|---|---|---|
| 1 | **The genetic signal is real and Stk11-selective.** | Pooled in vivo CRISPR screen in the mouse tumour line MC38: Mgat1 guides are depleted 7.5-fold in Stk11-KO tumours in C57BL/6 mice (median log2 fold-change −2.91, 52 tumours) against 1.5-fold in Stk11-wild-type tumours (−0.63, 50 tumours). Difference −2.29 (95% CI −2.71 to −1.82, p = 2×10⁻¹⁴), rank 2 of 795 genes for Stk11-selectivity, and rank 1 by a second analysis method. B4galt1, a galactosyltransferase that acts downstream of MGAT1 on the same glycans, ranks beside it. Little or no effect in culture (+0.20 and −0.29). |
| 2 | **Half to three-quarters of it does not need T cells, and PD-1 blockade adds nothing.** | In the arm that behaves as nude mice (the records do not label the arms; section 3.1), Mgat1 guides are still depleted 2.3- to 4.5-fold in Stk11-KO tumours (17 tumours). That is 74% of the C57BL/6 effect by two tumour-level analyses and 44% by a pooled-count model. For comparison Jak1, a canonical T-cell-dependent gene, keeps 14%. The two arms that behave as PD-1-blocked match the isotype-like arm (+0.24 and −0.28 by two methods, neither significant). In the single-gene study anti-PD-1 lowers volume by about a third with or without Mgat1 (1,134→756 and 619→390 mm³): additive. |
| 3 | **Human T-cell sensitisation is real, and catalysis is what matters.** | NCI-H1703 genome-wide co-culture screen: MGAT1 ranks 22 of 19,114 genes (log2 fold-change −0.84, CI −1.11 to −0.62, 4 of 4 guides). Four further guides reproduce it in two lung lines (relative viability 0.17–0.54 against 0.80–0.92 for control). Wild-type MGAT1 rescues (1.14–1.17); catalytically dead MGAT1 does not (0.50–0.61). |
| 4 | **The compounds are genuine, potent binders in a test tube. That is all that is known.** | ANT-4267: enzyme IC50 0.043 µM, SPR Kd 0.03–0.07 µM, solubility 96 µM, hepatocyte clearance below the assay limit. Binding is confirmed three ways for ANT-3744 (SPR Kd 0.4 µM, +6 °C thermal shift, two crystal structures), and potency tracks affinity across the series (r = 0.95, 25 compounds). |
| 5 | **How the compound inhibits is unresolved.** | In the crystal structures ANT-3744 sits in a pocket in the C-terminal lobe, 24 Å from UDP and 16 Å from the nearest atom of catalytic Asp289. It shares no contact residue with the donor site, and the catalytic-site backbone moves by less than 0.4 Å when it binds. Competition was tested only against UDP. Whether it blocks the glycoprotein acceptor, which is what matters in the Golgi, has not been measured. |

One further number frames the upside: **complete genetic loss of MGAT1 activity slows tumours by about half; it does not regress them.** In the Stk11-KO mouse model knockout tumours reach 542 against 1,087 mm³ (day 19), and catalytically dead rescue reaches 422 against 862 mm³. In the adoptive-transfer study with NY-ESO-1 T cells, knockout tumours are 52–70% smaller, with stasis at the higher T-cell dose. A reversible drug will be judged against that ceiling.

**What brings it back** (detail in section 4):

- (a) ANT-4267 reproduces the knockout glycan shift in intact lung-cancer cells at a concentration the molecule can plausibly reach, with controls that prove the effect runs through MGAT1.
- (b) The same treatment reproduces at least half of the knockout's T-cell sensitisation without impairing the T cells.
- (c) The client supplies the arm key for the in vivo screen, and it confirms or overturns the T-cell reading above.

With (a)–(c) in hand the programme earns in vivo pharmacology and a sharper indication hypothesis. Until then, chemistry effort is better spent on cell activity than on further enzyme potency, which is already at 43 nM.

---

## 2. What verified and what did not

| Claim the programme rests on | Verdict | What the client's data show | Source |
|---|---|---|---|
| Mgat1 is a selective dependency of Stk11-deficient tumours in vivo | **Verified, one model** | Rank 1–2 of 795 for Stk11-selectivity in C57BL/6 mice by two analysis methods. Three of four guides sit at −3.2 to −4.3 in every C57BL/6 Stk11-KO arm (the fourth is inactive), and all 52 tumours are below −1. The effect in Stk11-KO tumours (−2.9) is comparable to Adar (−3.2) and larger than Ptpn2 (−1.5). The library is a curated 795-gene druggable set, so the rank is within that set. MC38 is a mouse colon-carcinoma line (general knowledge; the records name the line, not its origin) with engineered Stk11 loss. There is no lung model. | Screen counts; `tables/invivo_Mgat1_key_contrasts.csv`, `invivo_Mgat1_two_method_comparison.csv`, `invivo_Mgat1_per_guide.csv`; Fig. 1–2 |
| The dependency runs through T cells and adds to checkpoint blockade | **Partly** | A T-cell-dependent component exists in Stk11-KO tumours but is the smaller part by the tumour-level analyses: about a quarter of the effect (p = 0.018 after adjusting for selection strength), against 56% by the pooled-count model. Jak1 and Ptpn2 lose about 87% of their effect in the nude-like arm; Mgat1 loses 26%. There is no PD-1 interaction in the screen or the single-gene study. In Stk11-wild-type tumours T cells add nothing (the effect is, if anything, weaker with them: +0.45 to +0.99), and MGAT1-knockout (sgMGAT1) tumours grew larger than control (1,775 vs 1,164 mm³). | Same tables plus `invivo_scale_adjusted_relative_depletion.csv`; phenotype figures p.1; `tables/figure_readouts_digitised.csv` |
| MGAT1 loss sensitises human lung-cancer cells to T-cell killing | **Verified in an engineered-TCR setting** | Screen rank 22 of 19,114, stable under three ways of counting (rank 22–34). Positive controls behave: the NY-ESO-1 antigen, B2M and the IFN-γ and TNF receptors protect; CFLAR and PTPN2 sensitise. Arrayed validation uses four different guides in NCI-H1703 and NCI-H1755. Adoptive-transfer tumour study (model not named): −52% and −70% tumour volume with 1×10⁶ and 2×10⁶ NY-ESO-1 T cells, −14% with control T cells. The screen has one sample per condition. STK11 status of the human lines is not recorded, and STK11 knockout itself is neutral in this screen (+0.12). | Co-culture counts; `tables/coculture_key_genes.csv`; phenotype figures p.3–4; Fig. 3 |
| Catalytic activity is required, so an enzyme inhibitor is the right modality | **Verified in vitro; supported in vivo with a caveat** | Rescue panel as in finding 3, with wild-type and dead constructs expressed at comparable levels on the immunoblot. In vivo, dead-mutant rescue tumours are 51% smaller than wild-type rescue in the same knockout clone (422 vs 862 mm³ at day 19; error bars separate from day 17). Caveat: on the immunoblot the dead-mutant line carries roughly three times more residual STK11 (about 0.19 vs 0.06 of wild-type level), which could slow it for a reason unrelated to MGAT1. | Phenotype figures p.5–7, p.11 |
| MGAT1 knockout produces the expected glycan change, usable as a pharmacodynamic marker | **Verified** | Lectin flow cytometry: PHA-L, which binds complex N-glycans, falls to ≤5% of control, and GNA, which binds high-mannose glycans, rises 8–9-fold, in A375 and NCI-H1703. Glycoproteomics (2,687 glycopeptides, 910 sites, 4 vs 4 replicates per line): the MGAT1 substrate Man5 doubles (median log2 +1.0 in both lines), upstream Man6–9 is unchanged (−0.05, +0.01), and complex glycans fall (−0.30, −0.42; sialylated complex −0.59, −0.65). At CD276 Asn91 complex forms fall 3–6-fold and Man5 rises about 4-fold. | Phenotype figures p.2; glycoproteomics workbook; `tables/glyco_class_summary.csv`; Fig. 4 |
| Potent, drug-like MGAT1 inhibitors exist | **Potency verified biochemically; the rest untested** | Table values agree with the plotted curves within fitting convention (my refit gives 0.42 µM for ANT-3744 against 0.81 µM reported, and 0.037 against 0.043 µM for ANT-4267). The package documents no cell permeability, cellular potency, selectivity panel, interference counter-screen for the luminescent readout, or exposure data. The species of the hepatocytes is not stated. | `compound_properties.csv`; assay figures p.1, p.5; `tables/biochem_dose_response_refit_from_figure.csv` |
| Mechanism is understood: non-competitive with the donor | **Partly** | ANT-3744 and UDP bind together: SPR affinity is retained in saturating partner (0.4→0.2 µM and 32→20 µM), thermal shifts add (2 + 6 = 8 °C), and the ternary crystal structure shows both. The mode of inhibition against UDP-GlcNAc and against the acceptor is not determined. The biochemical acceptor is a free pentasaccharide, not a glycoprotein. All mechanism work is on ANT-3744; for ANT-4267 there is a potency curve and table values only. | `spr_competition.csv`, `dsf_thermal_shift.csv`, five CIF files; `tables/structure_*.csv`; Fig. 5 |

---

## 3. The case in more detail

### 3.1 The in vivo screen is sound; what it shows is narrower than the positioning

The count matrix holds 3,580 guides (795 genes × 4, plus 400 non-targeting) across 141 tumours, 6 pre-implant baselines, 6 in vitro endpoints and 6 plasmid samples. Checks I ran before using it:

- Editing worked in both backgrounds: core-essential genes are depleted about 20-fold between plasmid and baseline (mean log2 −4.4 in both).
- Every tumour's guide distribution matches its own background's pre-implant population, so there are no Stk11/control sample swaps.
- Four samples were removed: one failed library (349 reads), two severely bottlenecked tumours (33% and 45% of guides at zero), and one duplicate (two "animals" with correlation 0.98; the next-highest pair in the study is 0.79). Keeping them changes nothing.
- Each tumour was seeded with about 28 cells per guide, so single tumours are noisy. The conclusions rest on 13–20 tumours per arm.

The records do not say which of Groups 1–8 is which treatment arm. I inferred it, and I am confident of the nude assignment:

- Groups 1 and 5 carry their own consecutive animal-ID blocks, separate from the interleaved (randomised) blocks of Groups 2–4 and 6–8.
- Groups 1 and 5 show no selection on T-cell-dependent genes: Cd274 +0.7/+0.6, Ptpn2 +0.6/−0.2, Stat1 +0.8/+0.4, where the other six groups are negative. A ten-gene T-cell-pressure signature separates their tumours from the rest one by one (AUC 0.99 and 1.00). They still select against B2m and H2-K1, as expected where NK cells remain.
- Groups 2 and 6 select against PD-L1 loss (Cd274 −3.3 and −0.8). Groups 3, 4, 7 and 8 do not (−0.4 to +0.1), the pattern expected under PD-1 blockade. Why there are two such arms per background is not documented.

![Fig. 1](figures/fig1_invivo_Mgat1_by_arm.png)

*Fig. 1. Mgat1 log2 fold-change per tumour, by arm and background (primary analysis).*

I analysed the screen three ways. The primary analysis takes the median over tumours, which describes the typical tumour and is robust to single tumours in which one guide clone has overgrown. The first cross-check is a negative-binomial model on pooled counts, which such clones can dominate. The second cross-check adjusts each tumour for its overall strength of selection. The analyses agree on everything except the size of the nude-arm effect.

| Mgat1, log2 fold-change | Median over tumours (rank of 795) | Pooled-count model (rank of 795) | Robust? |
|---|---|---|---|
| Stk11-KO tumours, C57BL/6 arms | −2.91 (9) | −2.77 (8) | Yes |
| Stk11-wild-type tumours, C57BL/6 arms | −0.63 (148) | −0.71 (122) | Yes |
| Stk11-selectivity in C57BL/6 | −2.29 (2) | −2.03 (1) | Yes |
| PD-1-blockade-like minus isotype-like, Stk11-KO | +0.24 (427) | −0.28 (136) | Yes: no effect |
| Stk11-KO tumours, nude-like arm | −2.16 (8) | −1.21 (43) | Depleted in both; size differs |
| Stk11-wild-type tumours, nude-like arm | −1.07 (54) | −1.69 (57) | Depleted in both; size differs |
| T-cell increment in Stk11-KO (C57BL/6 minus nude-like) | −0.76 (26) | −1.62 (3) | Present in both; size differs |
| Stk11-selectivity in nude-like arms | −1.09 (83) | +0.65 (623) | No |

The scale-adjusted view expresses depletion in each tumour relative to 34 genes that are depleted in culture, whose loss is cell-intrinsic. This removes differences between arms in how hard selection has acted overall.

| Relative depletion (1.0 = a typical cell-intrinsic fitness gene) | Stk11-KO, nude-like | Stk11-KO, C57BL/6 | Share kept without T cells | Wild-type, nude-like | Wild-type, C57BL/6 |
|---|---|---|---|---|---|
| Mgat1 | 1.44 | 1.93 | 74% (p = 0.018) | 0.86 | 0.43 |
| B4galt1 | 1.20 | 1.31 | 92% (p = 0.38) | 1.20 | 0.26 |
| Jak1 | 0.19 | 1.38 | 14% (p = 3×10⁻⁸) | 0.48 | 1.86 |
| Ptpn2 | 0.11 | 0.94 | 12% (p = 1×10⁻⁶) | −0.50 | 1.46 |

What can be said firmly:

- Mgat1 loss is selected against in nude-like mice, so a large part of the in vivo requirement does not need T cells: about three-quarters by the two tumour-level analyses, 44% by the pooled model. "T-cell-independent" is not "immune-independent": nude mice keep NK cells and macrophages, and the screen cannot separate innate killing from a tumour-intrinsic requirement.
- A T-cell-dependent remainder exists but is modest, unlike Jak1 or Ptpn2, which lose almost all of their effect without T cells.
- The Stk11-selectivity that the programme relies on is robust in immunocompetent mice (1.93 vs 0.43; p = 4×10⁻¹³). In nude-like mice it points the same way by two analyses (1.44 vs 0.86; p = 0.10) and the other way by the pooled model, so it is unresolved there.
- PD-1 blockade changes nothing (scale-adjusted 1.84 vs 2.00; p = 0.63), although the same arms show the expected loss of PD-L1 dependence. This does not depend on my labelling: the three C57BL/6 Stk11-KO arms are indistinguishable whichever one received anti-PD-1 (−3.11, −3.08, −2.82; every pairwise p > 0.4).
- In Stk11-wild-type tumours the direction is the opposite of sensitisation. Mgat1 loss is selected against less as T-cell pressure rises (nude-like −1.07, isotype-like −1.13, PD-1-like −0.64 and −0.30; PD-1-like vs isotype-like +0.72, nominal p = 0.03), and knockout tumours grew larger than control in the single-gene study. The sensitisation seen with engineered T cells in culture has not been reproduced with endogenous T cells in a wild-type tumour.
- In culture the cost is small (cumulative −0.82 from plasmid to endpoint in the Stk11-KO background).

![Fig. 2](figures/fig2_invivo_contrasts.png)

*Fig. 2. Where Mgat1 ranks among 795 genes in three contrasts (primary analysis; the pooled-count cross-check gives ranks 1, 3 and 136).*

The human and mouse evidence answer different questions. The mouse screen ties Mgat1 to Stk11 loss. The human work shows that MGAT1 loss makes tumour cells easier for engineered T cells to kill, in lines whose STK11 status is not recorded. No experiment shows both properties together in a lung model.

### 3.2 The single-gene tumour studies agree in direction but are weak evidence

Values below are digitised from phenotype figures p.1. No group sizes, error definitions or statistics are given, and the error bars overlap in each of these comparisons. (The in vivo rescue on p.7 is the exception: its error bars separate from day 17.)

- Stk11-KO MC38: sgMGAT1 542 vs control 1,087 mm³ at day 19.
- Under treatment (day 9): control 1,134 (isotype) and 756 (anti-PD-1); sgMGAT1 619 and 390. Multiplying the two single effects predicts 413; observed 390.
- According to the engineering schematic (p.11), the sgMGAT1 line is a single clone (A-F5) and the control is a pool, so clonal differences are confounded with the knockout.
- The "checkpoint-resistant" model is relative: anti-PD-1 still lowers Stk11-KO tumour volume by 33–50%.

### 3.3 The human genetics and the glycan readouts hold up

![Fig. 3](figures/fig3_coculture_rank.png)

*Fig. 3. NCI-H1703 co-culture screen: all genes (left) and selected genes with bootstrap intervals (right).*

- Eight different human MGAT1 guides (four in the screen library, four in the arrayed validation) give the same direction of effect.
- The neighbours of MGAT1 in the ranking are informative. The sialic-acid and galactose transporters rank above it (SLC35A1 −1.44, SLC35A2 −1.09), and the hexosamine-supply genes sit beside it. The protection appears to come from capped, sialylated glycans, of which MGAT1 loss removes only the N-linked complex share.
- What lies downstream of the glycan change is not identified. Loss of PD-L1 (CD274, −0.14) or of B7-H3 (CD276, +0.16) does not sensitise in the same screen, so the obvious glycosylated checkpoint ligands are not the explanation. The records list PD-L1 and CD276 antibodies and PD-L1 guides, but no such data are in the package.
- Knockout produces the expected glycan switch in both lines tested, at the level of individual sites on surface proteins (Fig. 4). That gives the programme a ready pharmacodynamic marker.

![Fig. 4](figures/fig4_glycoproteomics.png)

*Fig. 4. Glycoproteomics, MGAT1 knockout vs control, in A375 and NCI-H1703.*

### 3.4 How deep inhibition must be is unknown, and the hints point to "very deep"

- Every phenotype in the package comes from cells with ≥95% loss of PHA-L signal.
- Knocking out the next branching enzyme, MGAT2, does nothing in either screen (in vivo +0.1 to +0.3; co-culture −0.17, not significant).
- Over-expressing dead MGAT1 in MGAT1-intact cells lowers PHA-L by about 15% and produces no sensitisation (1.07–1.17).

A reversible inhibitor given systemically is a different intervention from a complete, permanent, tumour-restricted knockout. ANT-3744 leaves the protein within about two minutes on the SPR traces, so effect will follow free drug concentration. Every experiment in the package removes MGAT1 from tumour cells only. There is no information on what systemic inhibition does to normal tissues, or to the T cells that are supposed to do the killing.

### 3.5 The chemistry is a credible start with an unusual and unexplained mechanism

![Fig. 5](figures/fig5_structure_sites.png)

*Fig. 5. The ANT-3744 site relative to the donor site in the ternary complex.*

- Binding site: 14 residues line the ANT-3744 pocket (Tyr388, Thr389, Gly390, Phe394, Gly410, Pro412, Pro434, Trp437, Glu438, Gly439, Tyr440, Asp441, Pro442, Trp444); 21 line the donor site; none is shared. Binding is induced-fit (residues 436–439 move by up to 4.8 Å).
- In all four crystallographic copies the solvent-exposed half of the ligand touches a neighbouring molecule in the lattice (Glu133, or Glu274/Glu278, at 3.0–3.9 Å). No structure factors were supplied, so ligand density could not be re-checked.
- "Cooperative with UDP" is not established. The shifts are ≤2-fold, reported as single values, on different sensor surfaces. "Does not compete with UDP" is established.
- The enzyme, SPR and thermal-shift work is at pH 7.5–7.6 on human protein. Potency on mouse Mgat1, which every syngeneic experiment depends on, has not been measured.
- Binding and structures use a shorter construct (residues 104–445) than the activity assay (30–445). The Kd–IC50 correlation argues the truncation does not matter for binding, but access to the pocket in the full-length, membrane-anchored enzyme has not been shown.
- The screening hit (ANT-0592) and the two "acquired" compounds are not usable reference points (section 5). There is no external positive-control inhibitor, so the comparators for every next experiment have to be genetic.

---

## 4. Path back: what the next studies must establish, and against what

Thresholds are proposals anchored to the client's own knockout data; the client should agree them before the work starts.

| Gate | What it must establish | Comparisons the experiment must include | Bring-back criterion | Stop signal |
|---|---|---|---|---|
| **0. Paper gate** (no new experiments) | The arm key for Groups 1–8; group sizes, error definitions and statistics for every tumour study; STK11 status of NCI-H1703, NCI-H1755 and A375; identity of the adoptive-transfer model; any existing cell data. | — | Arm key confirms or overturns the nude and PD-1 readings in section 3.1. | — |
| **1. Cellular target engagement** | ANT-4267 remodels N-glycans in intact cells, dose- and time-dependently, without killing them. | Knockout (sgMGAT1) and non-targeting control (sgNTC) cells in the same run, as ceiling and floor. Compound on sgMGAT1 cells (must add nothing). A weak analogue from the same series, e.g. ANT-2118 (IC50 25.6 µM, roughly 600-fold weaker than ANT-4267); its cell effect must shift accordingly. Six or more analogues for a potency rank-order. Human lines (NCI-H1703, NCI-H1755) and mouse MC38 ± Stk11-KO. | Near-knockout glycan shift in both human lines: PHA-L ≤10% of control and GNA ≥5-fold (knockout gives ≤5% and 8–9-fold), with the same Man5-up / complex-down switch at sentinel sites (e.g. CD276 Asn91, LAMP1 Asn249, SLC3A2 Asn381), at a concentration well below the 96 µM solubility limit. | No glycan shift at ≤10 µM with any analogue; or a shift that also appears in sgMGAT1 cells. |
| **2. Phenocopy** | Compound-treated tumour cells become as sensitive to T cells as knockout cells, and the T cells still work. | sgMGAT1 (ceiling), sgNTC, sgB2M (resistance control). Antigen-specific vs non-transduced T cells. Two tumour lines × two donors. T cells pre-exposed and co-exposed to compound. Compound on sgMGAT1 cells. A binding-pocket mutant of MGAT1 that keeps catalysis, re-expressed in knockout cells (it should make cells resistant to the compound). A titration that relates % PHA-L loss to sensitisation. | At least half of the knockout effect in the competition assay (knockout: 0.17–0.54 vs control 0.80–0.92), no effect in sgMGAT1 cells, no loss of T-cell killing of control cells. This defines the pharmacodynamic threshold for in vivo work. | Deep glycan shift without sensitisation; or sensitisation only at concentrations that impair T cells. |
| **3. Mechanism and selectivity** | How the compound inhibits, and that it is selective. | Mode of inhibition against both UDP-GlcNAc and acceptor. A glycoprotein acceptor, not only the pentasaccharide. Golgi-like pH. An orthogonal product-detection readout and a detection-reagent counter-screen. Pocket mutants in solution (should lose binding and inhibition). ANT-4267's own sensorgrams, thermal shift and co-structure. Mouse Mgat1. A glycosyltransferase panel including the closest human homologues, and a broad off-target panel. | Potency holds on glycoprotein acceptor and at Golgi pH; pocket mutants abolish inhibition; ≥100-fold window over related transferases. | Potency collapses on glycoprotein acceptor; or inhibition survives pocket mutation. |
| **4. Which hypothesis** (can run alongside 1–3) | How much of the Stk11-selective effect needs T cells, what the rest depends on, and whether any of it extends beyond one colorectal line. | Two or more independent guides or three or more clones per genotype, with clone-matched controls and an STK11 immunoblot for every line at implant and endpoint. Stk11-KO vs wild-type. Nude vs C57BL/6 vs a strain also lacking NK cells. ± anti-PD-1; ± CD8 depletion. Pre-specified group sizes and statistics. One Stk11-deficient vs proficient lung model. Human STK11-mutant lung lines ± STK11 restoration in co-culture. | A reproducible Stk11-selective effect in a lung model, with its immune dependence defined. That decides between a single-agent and a combination hypothesis. | Effect confined to the MC38 clone. |
| **5. In vivo pharmacology** (only after 1–3) | Exposure drives the tumour glycan marker, and the marker drives efficacy. | Vehicle. sgMGAT1 tumours as the genetic ceiling (about 50% lower volume). Compound in sgMGAT1 tumours (must add nothing). Anti-PD-1 alone and in combination. Stk11-KO vs wild-type tumours. Nude vs C57BL/6. A standard-of-care arm the client selects. Tolerability and glycan readouts in normal tissues and immune cells. | Tumour glycan shift at the Gate-2 threshold at a tolerated exposure, with efficacy approaching the genetic ceiling and absent in sgMGAT1 tumours. | Threshold not reachable at tolerated exposure. |

Gates 0–2 are the minimum to reverse the call. Gates 3–5 are what candidate selection would then require.

---

## 5. What I set aside or discounted, and why

| Item | Treatment | Reason | Effect on conclusions |
|---|---|---|---|
| Four screen samples: Group7_STK11_82431, Group3_NTC_82276, Group4_NTC_82321, Group3_NTC_82364 | Excluded | 349 reads; 45% and 33% of guides at zero; duplicate of Group3_NTC_82346 (r = 0.98; the animal IDs differ by a digit transposition) | None (sensitivity run in `tables/invivo_Mgat1_by_group.csv`) |
| Guide Mgat1_3 | Kept in the primary analysis | Essentially inactive (−0.2 to −0.95 in the Stk11-KO C57BL/6 arms, where the other three are −3.2 to −4.3). Dropping it strengthens the effect (−3.5 to −3.7) | Conservative choice |
| Group → arm labels | Inferred, flagged throughout | Not in the records | The Stk11-selectivity result does not depend on it. The T-cell and PD-1 statements do; hence Gate 0 |
| Size of the nude-arm effect | Reported as a range, not a point | The median-over-tumours and pooled-count analyses differ (−2.16 vs −1.21), because a few nude-arm tumours retain one undepleted Mgat1 guide at high count | I claim only what all three analyses support |
| ANT-0592 potency (IC50 197 µM, Kd 32.2 µM with an undefined asterisk) | Not used | Both values exceed the compound's measured solubility (11.8 µM) | Fold-improvement claims from the hit are unreliable |
| ANT-1938 and ANT-2214 ("acquired") | Not used as benchmarks | 40% and 60% inhibition at 100 µM (the "74 µM" IC50 is extrapolated); SPR shows no binding and non-saturable binding respectively | No external reference inhibitor exists |
| "Cooperativity" between ANT-3744 and UDP | Downgraded to "no competition" | ≤2-fold shifts across separately prepared surfaces, reported as single values | Mechanism claim narrowed |
| Tumour-growth and bar-chart values | Used as approximate | Digitised from figures; no group sizes or statistics | Directional support only |
| STK11 immunoblot densitometry | Semi-quantitative caveat only | Measured on the embedded image | Flags a possible confound in the in vivo rescue |
| NY-ESO-1 expression across cell lines (phenotype p.9) | Context only | Public CCLE data, not client-generated | None |
| Co-culture screen significance values | Treated as ranking aids | One sample per condition; uncertainty taken from resampling the molecular barcodes (UMIs) within each guide | MGAT1 rank stable under three count methods |
| In vivo rescue (phenotype p.7) | Kept, with caveat | Same-clone comparison is clean, but residual STK11 differs between the two lines | Supports catalysis-dependence in vivo; not conclusive alone |

Record inconsistencies to raise with the client (none changes the call):

- Stated animal numbers (30 C57BL/6 and 15 nude) do not reconcile with 141 tumour samples in four groups per background.
- The potency protocol states a top concentration of 100 µM; five of six plotted curves run to 1,000 µM. The SPR data argue the plotted axis is right.
- Buffer and protein entries that look like unit slips ("1 mM BSA"; "18.6 nM … 9.3 µM final").
- The legends of phenotype p.1 and p.8 appear transposed.
- The thermal-shift figure labels the compound "HTS ANT-3744", although the registry lists ANT-3744 as synthesised in house.
- The STK11 blot uses vinculin, which is not in the antibody list. Several things are described but not shown: the D211A single mutant, the enzyme-activity titration of the mutant proteins, PD-L1 and CD276 immunoblots, and the PD-L1 and PTPN2 guides.
- UDP saturates at about 10 response units on a surface of about 9,000 (roughly 12% of the 1:1 expectation) while ANT-3744 reaches 100% or more. Either the surfaces differed or most immobilised protein does not bind nucleotide.

Not available to me, so not verified: raw sequencing reads, structure factors, raw flow and blot files, and any raw biophysics for ANT-4267.

---

## 6. Questions for the client now

1. Which treatment is each of Groups 1–8, and what is the second PD-1-like arm?
2. Group sizes, error-bar definitions and statistics for phenotype p.1, 4, 7 and 8; which tumour line is in p.4?
3. STK11 genotype of NCI-H1703, NCI-H1755 and A375.
4. Has any ANT compound been put on cells, in any assay? If so, why is it not in the package?
5. Top concentration actually used in the potency assay; meaning of the asterisk on ANT-0592.
6. Species of hepatocytes; any permeability, plasma-protein-binding or exposure data.
7. Structure factors for the two ANT-3744 structures; sensorgrams for ANT-4267.
8. The PD-L1 and CD276 immunoblots, the PD-L1 and PTPN2 guide experiments, and the mutant-enzyme activity data that the records refer to.

---

## 7. Source map: where each number comes from

Client files: **D1** `crispr_invivo_guide_counts.csv.gz`; **D2** `crispr_invivo_ngs_demux.csv.gz`; **D3** `coculture_screen_umi_counts.csv.gz`; **D4** `glycoproteomics_site_quant.xlsx`; **D5** `compound_properties.csv`; **D6** `spr_binding.csv`; **D7** `spr_competition.csv`; **D8** `dsf_thermal_shift.csv`; **D9** the five `MGAT1_*.cif` files; **R** `experimental_records.pdf`; **A** `assay_figures.pdf`; **P** `phenotype_figures.pdf`.

| Number(s) | Client source | My analysis output |
|---|---|---|
| 3,580 guides, 795 genes, 400 non-targeting; 141 tumours + 18 reference samples; 24 runs; 28 cells per guide at implant (100,000 cells ÷ 3,580) | D1, D2, R §2 | `scripts/01_invivo_screen.py` → `tables/invivo_sample_qc.csv` |
| Four excluded samples (349 reads; 44.6% and 33.0% zero guides; r = 0.984 duplicate); background-match check | D1 | `tables/invivo_sample_qc.csv` |
| Essential-gene dropout −4.4; Mgat1 in vitro +0.18/−0.27 (endpoint vs baseline), −0.82 cumulative in Stk11-KO | D1 | `tables/invivo_invitro_arms_Mgat1.csv` |
| Mgat1 per arm (−1.07, −1.13, −0.64, −0.30; −2.16, −3.11, −3.08, −2.82; in vitro +0.20, −0.29), ranks, CIs | D1 | `tables/invivo_Mgat1_by_group.csv`; Fig. 1 |
| Per-guide medians (−3.2 to −4.3; Mgat1_3 −0.2 to −0.95) | D1 | `tables/invivo_Mgat1_per_guide.csv` |
| Primary contrasts: −2.29 (rank 2; p = 1.7×10⁻¹⁴); nude −1.09; C57BL/6 vs nude −0.76 (rank 26); PD-1-like vs isotype-like +0.24 (p = 0.71); wild-type +0.45 | D1 | `tables/invivo_Mgat1_key_contrasts.csv`, `invivo_contrasts_all_genes.csv`; Fig. 2 |
| Two-method table (−2.77, −0.71, −1.21, −1.69, −2.03, +0.65, −1.62, −0.28, +0.99 and ranks); 44–74% share; 2.3- to 4.5-fold | D1 | `scripts/01b_invivo_screen_edgeR_crosscheck.R` → `tables/invivo_Mgat1_two_method_comparison.csv`, `invivo_edgeR_crosscheck_all_genes.csv`; also `invivo_Mgat1_nude_share.csv`, `invivo_Mgat1_summary_method_sensitivity.csv` |
| Scale-adjusted relative depletion (1.44, 1.93, 0.86, 0.43; 74%, p = 0.018; Jak1 14%, Ptpn2 12%; PD-1-like 1.84 vs 2.00) | D1 | `scripts/01d_invivo_scale_adjusted.py` → `tables/invivo_scale_adjusted_relative_depletion.csv` |
| Arm inference (Cd274, Ptpn2, Stat1, Jak1, B2m, H2-K1 by group; animal-ID blocks 82276–82383, 82386–82470, 82498–82520, 82523–82549; signature AUC 0.99 and 1.00) | D1, D2 | `tables/invivo_arm_inference_evidence.csv`, `invivo_arm_signature_per_tumour.csv`, `invivo_sample_qc.csv` |
| Adar −3.2, Ptpn2 −1.5, B4galt1, Mgat2 by arm | D1 | `tables/invivo_gene_median_log2FC_by_group.csv` |
| Co-culture: 77,079 guides, 19,114 genes, MGAT1 rank 22, −0.84 (−1.11 to −0.62), guides −1.16/−1.09/−0.64/−0.46; SLC35A1 −1.44, SLC35A2 −1.09, MGAT2 −0.17, STK11 +0.12, CD274 −0.14, CD276 +0.16; controls | D3 | `scripts/02_coculture_screen.py` → `tables/coculture_key_genes.csv`, `coculture_MGAT1_guides.csv`, `coculture_gene_level.csv`; Fig. 3 |
| Arrayed co-culture 0.17–0.54 vs 0.80–0.92; B2M 1.84–1.97 | P p.3 | `scripts/08c_…`, `08d_…` → `tables/figure_readouts_digitised.csv` |
| Rescue: vector 0.69–0.74, wild-type 1.14–1.17, dead 0.50–0.61; PHA-L about −15% with dead mutant in intact cells | P p.5 | same |
| Adoptive transfer: 1,923/1,649; 1,294/620; 596/~180 mm³ | P p.4 | same |
| MC38 tumour volumes (1,164/1,775; 1,087/542; 1,134/756/619/390; 862/422; 868/790; model characterisation 931/382/87 and 964/1,264/632) | P p.1, p.7, p.8 | same |
| STK11 residual 0.06 vs 0.19 | P p.6 | same (image densitometry) |
| Lectins: PHA-L ≤5%, GNA 8–9× | P p.2 | same |
| Glycoproteomics: 2,687 / 910 / 524; Man5 +1.0; Man6–9 −0.05/+0.01; complex −0.30/−0.42; sialylated −0.59/−0.65; CD276 Asn91; 65 of 105 sites switch in both lines | D4 (sheet IGP_quant) | `scripts/03_glycoproteomics.py` → `tables/glyco_class_summary.csv`, `glyco_sites_with_Man5_and_complex.csv`; Fig. 4 |
| Compound table values (IC50, Kd, solubility, clearance, MW, logD, TPSA) | D5 | — |
| Refit IC50s (0.42, 0.037 µM etc.); curves run to 1,000 µM | A p.1 | `tables/biochem_dose_response_refit_from_figure.csv` |
| IC50 vs Kd, r = 0.95, median ratio 1.8, 25 compounds | A p.5 | `tables/biochem_IC50_vs_Kd_read_from_figure.csv` |
| SPR 0.4 µM and 31 µM; competition 0.4→0.2, 32→20 µM; UDP plateau ~10 RU; dissociation within ~2 min | D6, D7, A p.2–3, R §6.4 | — |
| Thermal shift +2, +6, +8 °C | D8, A p.4 | — |
| Structures: resolution 1.55–2.01 Å, R-free 0.18–0.22; pocket and donor-site residues; 23.9 Å, 16.1 Å, 19.8 Å; 4.8 Å induced fit; <0.4 Å at catalytic-site Cα atoms; lattice contacts | D9 | `scripts/04_structures.py` → `tables/structure_summary.csv`, `structure_ligand_contacts_4A.csv`, `structure_ANT3744_distances.csv`, `structure_conformational_changes.csv`; Fig. 5 |
| Clone-versus-pool design; comparable expression of wild-type and dead constructs | P p.11 | — |
| Eight distinct human MGAT1 guides, each mapping once to the MGAT1 locus | R §1, D3 | `scripts/09_guide_mapping_check.py` → `tables/guide_mapping_GRCh38.csv` (uses the GRCh38 reference genome, which is outside the data room; reagent check only) |

Methods in brief.

- *In vivo screen, primary:* counts per million; log2 ratio to the matched pre-implant baseline; centred on the 400 non-targeting guides; gene score per tumour = mean of four guides; the tumour is the unit of replication (Mann–Whitney tests, bootstrap confidence intervals, Welch t for ranking).
- *In vivo screen, cross-check:* negative-binomial quasi-likelihood model (edgeR) on the same samples, arm vs own baseline, re-centred on the non-targeting guides; gene value = mean of four guides.
- *In vivo screen, scale-adjusted:* per tumour, gene score divided by the median score of 34 yardstick genes (those depleted below −1 in culture in both backgrounds, chosen without reference to any tumour arm); arms compared by Mann–Whitney test.
- *Co-culture screen:* reads summed over UMIs per guide; log2 ratio normalised to 989 non-targeting guides; gene score = mean of guides; null from random four-guide control sets; repeated with winsorised UMI counts and with UMI detection counts.
- *Glycoproteomics:* channels centred on Man7–9 glycopeptides, which lie upstream of MGAT1, so that loading is corrected without forcing the knockout and control distributions to match.
- *Structures:* contacts within 4 Å including symmetry mates; least-squares superposition on Cα atoms.
- *Figures:* tumour volumes and bar heights were read from the embedded images by pixel calibration against the axis ticks.
