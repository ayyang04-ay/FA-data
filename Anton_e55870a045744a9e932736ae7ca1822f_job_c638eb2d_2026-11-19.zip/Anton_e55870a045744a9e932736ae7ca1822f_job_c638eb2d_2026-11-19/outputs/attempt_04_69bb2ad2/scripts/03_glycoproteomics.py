#!/usr/bin/env python
"""TMT glycoproteomics (A375 and NCI-H1703, sgNTC vs MGAT1-KO population, n=4 each) - independent re-analysis.
Input : glycoproteomics_site_quant.xlsx (sheet IGP_quant = one row per intact glycopeptide; Site_quant; IGP_Pep_quant)
Method: glycan composition -> class; log2 reporter intensity; channels are centred on the median of Man7-9 glycopeptides
        (upstream of MGAT1, so expected to be unaffected by the knockout) to remove loading differences without
        forcing the global distribution to be equal; KO-vs-NTC log2FC per glycopeptide with Welch t-test (n=4 v 4).
"""
import pandas as pd, numpy as np, re
from scipy import stats
IN='/tmp/world/filesystem/glycoproteomics_site_quant.xlsx'; OUT='/tmp/outputs/tables/'
igp = pd.read_excel(IN, sheet_name='IGP_quant'); site = pd.read_excel(IN, sheet_name='Site_quant'); pep = pd.read_excel(IN, sheet_name='IGP_Pep_quant')
chan = ['AM_KO1','AM_KO2','AM_KO3','AM_KO4','AM_N1','AM_N2','AM_N3','AM_N4','NH_M_KO1','NH_M_KO2','NH_M_KO3','NH_M_KO4','NH_N1','NH_N2','NH_N3','NH_N4']
icol = ['Intensity '+c for c in chan]
def parse(comp):
    d={'HexNAc':0,'Hex':0,'Fuc':0,'NeuAc':0,'NeuGc':0,'other':0}
    for m in re.finditer(r'([A-Za-z0-9\-]+)\((\d+)\)', str(comp)):
        k,n=m.group(1),int(m.group(2)); d[k if k in d else 'other']+=n
    return d
def classify(comp):
    d=parse(comp); hn,hx,fu,na=d['HexNAc'],d['Hex'],d['Fuc'],d['NeuAc']+d['NeuGc']
    if d['other']: return 'phospho/other'
    if hn<=1: return 'truncated (HexNAc<=1)'
    if hn==2:
        if hx==5: return 'Man5 (MGAT1 substrate)' if fu==0 else 'Man5+Fuc'
        if 6<=hx<=9 and fu==0: return 'Man6-9'
        if hx<=4: return 'paucimannose/Man<=4'
        return 'other HexNAc2'
    if hn==3: return 'hybrid / mono-antennary (HexNAc3)'
    return 'complex (HexNAc>=4)'
igp['glycan_class']=igp['Observed Modification'].map(classify)
igp['sialylated']=igp['Observed Modification'].str.contains('NeuAc|NeuGc')
I = igp[icol].replace(0,np.nan); L=np.log2(I); L.columns=chan
ref = igp['Observed Modification'].isin(['HexNAc(2)Hex(7)','HexNAc(2)Hex(8)','HexNAc(2)Hex(9)'])
Ln = L - L[ref].median()
sets = {'A375':(chan[0:4],chan[4:8]),'NCI-H1703':(chan[8:12],chan[12:16])}
for nm,(ko,n) in sets.items():
    igp[f'log2FC_{nm}'] = Ln[ko].mean(axis=1)-Ln[n].mean(axis=1)
    igp[f'log2FC_raw_{nm}'] = L[ko].mean(axis=1)-L[n].mean(axis=1)
    igp[f'p_{nm}'] = stats.ttest_ind(Ln[ko],Ln[n],axis=1,equal_var=False,nan_policy='omit').pvalue
print('glycopeptides %d; sites %d; proteins %d'%(len(igp), igp.groupby(['Protein accession','Position']).ngroups, igp['Protein accession'].nunique()))
print('channel sums (1e9):', (igp[icol].sum()/1e9).round(2).to_dict())
rows=[]
for cls,sub in igp.groupby('glycan_class'):
    r={'glycan_class':cls,'n_glycopeptides':len(sub)}
    for nm in sets:
        v=sub[f'log2FC_{nm}'].dropna()
        r[f'{nm}_median_log2FC']=round(v.median(),2); r[f'{nm}_IQR']=f"{v.quantile(.25):.2f} to {v.quantile(.75):.2f}"
        r[f'{nm}_frac_down>1.4x']=round((v<-0.5).mean(),2); r[f'{nm}_frac_up>1.4x']=round((v>0.5).mean(),2)
    rows.append(r)
S=pd.DataFrame(rows); S.to_csv(OUT+'glyco_class_summary.csv',index=False); print(S.to_string())
# sialylated complex
for nm in sets:
    v=igp[(igp.glycan_class=='complex (HexNAc>=4)')&igp.sialylated][f'log2FC_{nm}']; print(nm,'sialylated complex: n=%d median %.2f'%(len(v),v.median()))
# per-channel signature (QC for swaps / incomplete KO)
sig = pd.DataFrame({'Man5_minus_Man7-9':L[igp.glycan_class=='Man5 (MGAT1 substrate)'].median()-L[ref].median(),
                    'complex_minus_Man7-9':L[igp.glycan_class=='complex (HexNAc>=4)'].median()-L[ref].median()}).round(2)
sig.to_csv(OUT+'glyco_channel_signature.csv'); print(sig.T.to_string())
# replicate concordance between cell lines
print('between-line correlation of log2FC (all glycopeptides): %.2f'%igp[['log2FC_A375','log2FC_NCI-H1703']].corr().iloc[0,1])
# sentinel sites for PD biomarker: complex glycopeptides down in both lines with Man5 up at the same site
key = igp.groupby(['Gene name','Position'])
rows=[]
for (gname,pos),sub in key:
    cx = sub[sub.glycan_class=='complex (HexNAc>=4)']; m5 = sub[sub.glycan_class=='Man5 (MGAT1 substrate)']
    if len(cx) and len(m5):
        rows.append(dict(gene=gname, site=f'N{pos}', n_complex_forms=len(cx), complex_median_log2FC_A375=round(cx['log2FC_A375'].median(),2), complex_median_log2FC_H1703=round(cx['log2FC_NCI-H1703'].median(),2),
                         Man5_log2FC_A375=round(m5['log2FC_A375'].median(),2), Man5_log2FC_H1703=round(m5['log2FC_NCI-H1703'].median(),2)))
T=pd.DataFrame(rows); T['switch_score']=(T.Man5_log2FC_A375+T.Man5_log2FC_H1703-T.complex_median_log2FC_A375-T.complex_median_log2FC_H1703)/2
T=T.sort_values('switch_score',ascending=False); T.to_csv(OUT+'glyco_sites_with_Man5_and_complex.csv',index=False)
print('sites with both Man5 and complex forms quantified:',len(T)); print(T.head(25).to_string())
print('of these, sites with complex down & Man5 up in both lines:', ((T.complex_median_log2FC_A375<0)&(T.complex_median_log2FC_H1703<0)&(T.Man5_log2FC_A375>0)&(T.Man5_log2FC_H1703>0)).sum())
igp.drop(columns=icol).round(4).to_csv(OUT+'glyco_glycopeptide_level.csv',index=False)
