#!/usr/bin/env python
"""Annotate the PyMOL render of the MGAT1.UDP.ANT-3744 ternary complex (run 06a_structure_render.pml first: pymol -cq 06a_structure_render.pml)."""
import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
F='/tmp/outputs/figures/'
im = np.array(Image.open('/tmp/work/struct/fig5_raw.png').convert('RGB'))
x0,x1,y0,y1 = 180,1820,230,1200
im = im[y0:y1, x0:x1]
p = {k:(float(v[0])-x0, float(v[1])-y0) for k,v in json.load(open('/tmp/work/struct/fig5_proj.json')).items()}
fig,ax = plt.subplots(figsize=(10.5,6.4))
ax.imshow(im); ax.axis('off')
box = dict(fc='white', ec='none', alpha=0.85, pad=1.5)
def lab(key, text, xytext, color):
    ax.annotate(text, p[key], xytext=xytext, fontsize=9.5, color=color, ha='center', va='center', fontweight='bold', bbox=box, arrowprops=dict(arrowstyle='-', color=color, lw=1))
lab('lig','ANT-3744\ninduced pocket in the C-terminal lobe\n(Y388, F394, W437, E438, G439,\nY440, D441, W444)',(215,110),'#c00000')
lab('udp','UDP + Mn$^{2+}$\n(donor site)',(1400,800),'#0000c0')
lab('glcnac','GlcNAc of UDP-GlcNAc\n(superposed from the\nUDP-GlcNAc complex)',(1330,130),'#008000')
lab('d289','Asp289',(820,870),'#c06000')
lab('d211','Asp211',(1450,330),'#c06000')
mid1 = ((p['ligC15'][0]+p['udpO1B'][0])/2, (p['ligC15'][1]+p['udpO1B'][1])/2)
ax.text(mid1[0], mid1[1]-42, '23.9 Å to UDP', fontsize=9.5, ha='center', color='k', bbox=box)
mid2 = ((p['ligC16'][0]+p['d289O'][0])/2, (p['ligC16'][1]+p['d289O'][1])/2)
ax.text(mid2[0]-30, mid2[1]+50, '16.1 Å to Asp289', fontsize=9.5, ha='center', color='k', bbox=box)
ax.set_title('MGAT1 · UDP · ANT-3744 ternary complex (MGAT1_C3744_UDP.cif, chain A, 2.0 Å):\nthe inhibitor sits in the C-terminal lobe, remote from the donor site and from the aspartates mutated in the catalytic-dead constructs', fontsize=10)
fig.savefig(F+'fig5_structure_sites.png', dpi=200, bbox_inches='tight')
print('fig5 written')
