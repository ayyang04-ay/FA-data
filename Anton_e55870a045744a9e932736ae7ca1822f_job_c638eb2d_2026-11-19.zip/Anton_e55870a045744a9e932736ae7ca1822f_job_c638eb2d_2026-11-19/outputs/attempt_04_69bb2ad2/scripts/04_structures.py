#!/usr/bin/env python
"""MGAT1 crystal structures (5 coordinate files) - independent geometric analysis with gemmi.
No structure factors/maps were supplied, so ligand density cannot be re-checked; this script verifies what the
coordinates themselves say: where ANT-3744 (C3744) sits relative to the donor site, what it touches, lattice contacts,
and what moves when it binds.
"""
import gemmi, numpy as np, pandas as pd
IN='/tmp/world/filesystem/'; OUT='/tmp/outputs/tables/'
files = {'apo':'MGAT1_apo.cif','UDP':'MGAT1_UDP.cif','UDP-GlcNAc':'MGAT1_UDP_GlcNAc.cif','ANT-3744':'MGAT1_C3744.cif','ANT-3744+UDP':'MGAT1_C3744_UDP.cif'}
S={}; rows=[]
for k,f in files.items():
    st = gemmi.read_structure(IN+f); st.setup_entities(); S[k]=st
    b = gemmi.cif.read(IN+f).sole_block()
    gv = lambda t: b.find_value(t)
    row = dict(structure=k, file=f, space_group=st.spacegroup_hm, cell='%.1f x %.1f x %.1f'%st.cell.parameters[:3], resolution_A=gv('_reflns.d_resolution_high'), completeness=gv('_reflns.percent_possible_obs'),
               Rwork=gv('_refine.ls_R_factor_R_work'), Rfree=gv('_refine.ls_R_factor_R_free'), crystallisation=gv('_exptl_crystal_grow.pdbx_details'))
    for ch in st[0]:
        pol = ch.get_polymer(); ids=[r.seqid.num for r in pol]
        gaps = [f'{ids[i]+1}-{ids[i+1]-1}' for i in range(len(ids)-1) if ids[i+1]-ids[i]>1]
        row[f'chain{ch.name}_modelled'] = f'{ids[0]}-{ids[-1]}' + (f' (missing {", ".join(gaps)})' if gaps else ' (no gaps)')
        row[f'chain{ch.name}_meanB'] = round(np.mean([a.b_iso for r in pol for a in r]),1)
        ligs=[]
        for r in ch.get_ligands():
            if r.name in ('C3744','UDP','UD1','MN'):
                ligs.append(f"{r.name}: occ {np.mean([a.occ for a in r]):.2f}, B {np.mean([a.b_iso for a in r]):.0f}")
        row[f'chain{ch.name}_ligands'] = '; '.join(ligs)
    rows.append(row)
T = pd.DataFrame(rows); T.to_csv(OUT+'structure_summary.csv', index=False); print(T.T.to_string())

def contacts(st, chain, resname, cutoff=4.0):
    m = st[0]; ns = gemmi.NeighborSearch(m, st.cell, cutoff+1).populate(include_h=False)
    lig = [r for r in m[chain] if r.name==resname][0]; out={}
    for a in lig:
        for mark in ns.find_atoms(a.pos, '\0', radius=cutoff):
            cra = mark.to_cra(m)
            if cra.residue is lig or cra.residue.name=='HOH': continue
            dist = st.cell.find_nearest_pbc_image(a.pos, cra.atom.pos, mark.image_idx).dist()
            key=(cra.chain.name, cra.residue.name, cra.residue.seqid.num, 'symmetry mate' if mark.image_idx!=0 else 'same molecule' if cra.chain.name==chain else 'other chain in ASU')
            if key not in out or dist<out[key]: out[key]=dist
    return lig, out
rows=[]
for k,res in [('ANT-3744','C3744'),('ANT-3744+UDP','C3744'),('ANT-3744+UDP','UDP'),('UDP','UDP'),('UDP-GlcNAc','UD1')]:
    for ch in 'AB':
        lig,out = contacts(S[k], ch, res)
        for (c,rn,num,where),dist in sorted(out.items(), key=lambda kv:(kv[0][3],kv[0][2])):
            rows.append(dict(structure=k, ligand=res, ligand_chain=ch, contact_residue=f'{rn}{num}', contact_chain=c, relation=where, min_distance_A=round(dist,2)))
C = pd.DataFrame(rows); C.to_csv(OUT+'structure_ligand_contacts_4A.csv', index=False)
pocket = sorted(set(C[(C.ligand=='C3744')&(C.relation=='same molecule')].contact_residue), key=lambda s:int(s[3:]))
donor  = sorted(set(C[(C.ligand.isin(['UDP','UD1']))&(C.relation=='same molecule')&(~C.contact_residue.str.startswith('MN'))].contact_residue), key=lambda s:int(s[3:]))
print('\nANT-3744 pocket residues (<=4 A, any copy):', pocket)
print('donor-site residues (<=4 A of UDP or UDP-GlcNAc):', donor)
print('residues shared between the two sites:', sorted(set(pocket)&set(donor)))
print('lattice (symmetry-mate) contacts to ANT-3744:'); print(C[(C.ligand=='C3744')&(C.relation!='same molecule')].to_string(index=False))

# distances from ANT-3744 to catalytic elements (ternary complex) and to UDP-GlcNAc after superposition
def ca(st,ch): return {r.seqid.num: np.array(r.find_atom('CA','*').pos.tolist()) for r in st[0][ch].get_polymer() if r.find_atom('CA','*')}
def kabsch(P,Q):
    Pc,Qc=P.mean(0),Q.mean(0); U,s,Vt=np.linalg.svd((P-Pc).T@(Q-Qc)); d=np.sign(np.linalg.det(Vt.T@U.T)); R=Vt.T@np.diag([1,1,d])@U.T; return R,Pc,Qc
rows=[]
for ch in 'AB':
    m = S['ANT-3744+UDP'][0][ch]
    lig = np.array([a.pos.tolist() for r in m if r.name=='C3744' for a in r])
    def mind(xyz): return float(np.min(np.linalg.norm(lig[:,None,:]-np.asarray(xyz)[None,:,:],axis=2)))
    get = lambda name: [a.pos.tolist() for r in m if r.name==name for a in r]
    resat = lambda num: [a.pos.tolist() for r in m.get_polymer() if r.seqid.num==num for a in r]
    row = dict(chain=ch, to_UDP=mind(get('UDP')), to_Mn=mind(get('MN')), to_Asp211=mind(resat(211)), to_Asp289=mind(resat(289)), to_Trp288=mind(resat(288)))
    # superpose UDP-GlcNAc complex onto the ternary complex and measure to the GlcNAc moiety
    A = ca(S['UDP-GlcNAc'],ch); B = ca(S['ANT-3744+UDP'],ch); common=sorted(set(A)&set(B))
    R,Pc,Qc = kabsch(np.array([A[i] for i in common]), np.array([B[i] for i in common]))
    ud1 = [r for r in S['UDP-GlcNAc'][0][ch] if r.name=='UD1'][0]
    glc = np.array([a.pos.tolist() for a in ud1 if a.name.endswith("'") and a.name[0] in 'CON' and a.name not in ("C1'","C2'","C3'","C4'","C5'","O2'","O3'","O4'","O5'")]) if False else None
    allud1 = {a.name: (R@(np.array(a.pos.tolist())-Pc))+Qc for a in ud1}
    row['to_UDP-GlcNAc_any_atom(superposed)'] = mind(list(allud1.values()))
    rows.append({k:(round(v,1) if isinstance(v,float) else v) for k,v in row.items()})
D = pd.DataFrame(rows); D.to_csv(OUT+'structure_ANT3744_distances.csv', index=False); print('\nminimum distances from ANT-3744 (A), ternary complex:'); print(D.to_string(index=False))

# induced fit: CA shifts on ANT-3744 binding
rows=[]
for a,b in [('apo','ANT-3744'),('UDP','ANT-3744+UDP'),('apo','UDP'),('UDP','UDP-GlcNAc')]:
    for ch in 'AB':
        A=ca(S[a],ch); B=ca(S[b],ch); common=sorted(set(A)&set(B)); R,Pc,Qc=kabsch(np.array([A[i] for i in common]),np.array([B[i] for i in common]))
        dev={i: float(np.linalg.norm((R@(A[i]-Pc))+Qc-B[i])) for i in common}
        big={i:round(d,1) for i,d in dev.items() if d>2.0}
        rows.append(dict(pair=f'{a} -> {b}', chain=ch, n_CA=len(common), rmsd_A=round(float(np.sqrt(np.mean(np.square(list(dev.values()))))),2), residues_CA_shift_gt_2A=str(big),
                         max_shift_catalytic_site_res=round(max(dev.get(i,0) for i in (209,210,211,288,289)),2)))
M = pd.DataFrame(rows); M.to_csv(OUT+'structure_conformational_changes.csv', index=False); print(); print(M.to_string(index=False))
