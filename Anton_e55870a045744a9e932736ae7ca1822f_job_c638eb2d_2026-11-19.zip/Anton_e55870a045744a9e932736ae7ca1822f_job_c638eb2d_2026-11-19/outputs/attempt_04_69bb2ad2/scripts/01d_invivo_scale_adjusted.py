#!/usr/bin/env python
"""Scale-adjusted view of the in vivo screen.
Arms differ in overall strength of selection (time in vivo, bottleneck). As an internal yardstick I use the genes that are
depleted in culture in BOTH backgrounds (endpoint vs baseline < -1; defined without looking at any tumour arm): their loss is
cell-intrinsic, so their depletion in a tumour measures how hard selection has acted in that tumour, independent of T cells.
For each tumour: relative depletion of gene X = score(X) / median score of the yardstick genes."""
import pandas as pd, numpy as np
from scipy import stats
T='/tmp/outputs/tables/'
gs = pd.read_csv(T+'invivo_per_tumour_gene_scores.csv', index_col=0); g = gs.pop('group')
med = gs.groupby(g).median().T
ref = med[(med.Endpoint_STK11 < -1.0) & (med.Endpoint_NTC < -1.0)].index.tolist()
print(len(ref), 'yardstick genes:', ', '.join(ref))
tum = g[g.str.startswith('Group')].index
inten = gs.loc[tum, ref].median(axis=1)
B6K=['Group6','Group7','Group8']; B6W=['Group2','Group3','Group4']
arm = {'Stk11-KO nude-like':['Group5'], 'Stk11-KO C57BL/6':B6K, 'WT nude-like':['Group1'], 'WT C57BL/6':B6W}
print('median yardstick depletion by arm:', {k: round(float(inten[g[tum].isin(v)].median()),2) for k,v in arm.items()})
rows=[]
for x in ['Mgat1','B4galt1','Itgb1','Cd47','B2m','H2-K1','Tap1','Adar','Jak1','Ptpn2','Stat1','Socs1','Rbck1','Cd274','Mgat2']:
    r = gs.loc[tum, x]/inten
    v = {k: r[g[tum].isin(vv)] for k,vv in arm.items()}
    rows.append(dict(gene=x, **{k+' (median relative depletion)': round(float(s.median()),2) for k,s in v.items()},
                     KO_share_retained_without_T_cells=round(float(v['Stk11-KO nude-like'].median()/v['Stk11-KO C57BL/6'].median()),2),
                     p_KO_nude_vs_B6=float('%.2g'%stats.mannwhitneyu(v['Stk11-KO nude-like'], v['Stk11-KO C57BL/6']).pvalue),
                     p_WT_nude_vs_B6=float('%.2g'%stats.mannwhitneyu(v['WT nude-like'], v['WT C57BL/6']).pvalue),
                     p_KO_vs_WT_in_nude=float('%.2g'%stats.mannwhitneyu(v['Stk11-KO nude-like'], v['WT nude-like']).pvalue),
                     p_KO_vs_WT_in_B6=float('%.2g'%stats.mannwhitneyu(v['Stk11-KO C57BL/6'], v['WT C57BL/6']).pvalue)))
R = pd.DataFrame(rows); R.to_csv(T+'invivo_scale_adjusted_relative_depletion.csv', index=False)
pd.set_option('display.width',300); print(R.to_string(index=False))
# per-arm (individual groups) for Mgat1
r = gs.loc[tum,'Mgat1']/inten
print(r.groupby(g[tum]).median().round(2).to_dict())
# PD-1-like vs isotype-like in Stk11-KO, scale-adjusted
print('PD-1-like (G7+G8) vs isotype-like (G6), Stk11-KO, scale-adjusted: %.2f vs %.2f, p=%.2g'%(r[g[tum].isin(['Group7','Group8'])].median(), r[g[tum]=='Group6'].median(), stats.mannwhitneyu(r[g[tum].isin(['Group7','Group8'])], r[g[tum]=='Group6']).pvalue))
# yardstick depletion: nude vs B6 slope (arm medians)
am = pd.DataFrame({k: gs.loc[tum[g[tum].isin(v)], ref].median() for k,v in arm.items()})
for a,b in [('Stk11-KO nude-like','Stk11-KO C57BL/6'),('WT nude-like','WT C57BL/6')]:
    x=am[b].values; y=am[a].values; print(f'yardstick genes, {a} vs {b}: slope through origin {float((x*y).sum()/(x*x).sum()):.2f}')

# ---------- per-tumour check of the arm inference ----------
# T-cell-pressure signature = mean score of ten genes whose loss is known to matter only under T-cell / IFN-gamma pressure.
tsig = ['Jak1','Stat1','Ptpn2','Socs1','Rbck1','Jak2','Ifngr2','Adar','Tap1','H2-D1']
sig = gs.loc[tum, tsig].mean(axis=1)
S = pd.DataFrame({'group':g[tum], 'T_cell_pressure_signature':sig.round(3), 'Cd274':gs.loc[tum,'Cd274'].round(3)}); S.to_csv(T+'invivo_arm_signature_per_tumour.csv')
print(S.groupby('group').agg(n=('Cd274','size'), signature_median=('T_cell_pressure_signature','median'), signature_min=('T_cell_pressure_signature','min'), signature_max=('T_cell_pressure_signature','max'), Cd274_median=('Cd274','median')).round(2))
for nude,b6 in [('Group1',B6W),('Group5',B6K)]:
    a = S[S.group==nude].T_cell_pressure_signature; b = S[S.group.isin(b6)].T_cell_pressure_signature
    print(f'{nude} vs {"+".join(b6)}: AUC {stats.mannwhitneyu(a,b).statistic/(len(a)*len(b)):.3f}, p={stats.mannwhitneyu(a,b).pvalue:.1e}')
