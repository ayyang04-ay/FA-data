#!/usr/bin/env python
"""In vivo pooled CRISPR screen (MC38 +/- Stk11 KO) - independent re-analysis.
Input : crispr_invivo_guide_counts.csv.gz, crispr_invivo_ngs_demux.csv.gz
Output: tables in /tmp/outputs/tables (invivo_*.csv)
Method (deliberately simple and transparent):
  * CPM per sample; log2((cpm+5)/(matched-background baseline cpm+5)); centred on the median of the 400 non-targeting guides
  * per-tumour gene score = mean over the 4 guides; group value = median over tumours
  * tumour is the unit of replication for all between-group tests (Mann-Whitney; Welch t for ranking)
"""
import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
IN='/tmp/world/filesystem/'; OUT='/tmp/outputs/tables/'
c = pd.read_csv(IN+'crispr_invivo_guide_counts.csv.gz'); d = pd.read_csv(IN+'crispr_invivo_ngs_demux.csv.gz')
meta = c.iloc[:,:3].copy(); X = c.iloc[:,3:].copy(); X.index = meta.gene_sgrna_id
isntc = meta.gene_symbol.str.startswith('BRDN').values
gene = pd.Series(np.where(isntc,'NTC',meta.gene_symbol), index=X.index)
def sgroup(s):
    p = s.split('_'); return p[0]+'_'+p[1] if p[0] in ('Baseline','Endpoint') else p[0]
grp = pd.Series({s:sgroup(s) for s in X.columns})
bg  = pd.Series({s:('NTC' if '_NTC_' in s else 'STK11' if '_STK11_' in s else 'NA') for s in X.columns})
cpm = X/X.sum()*1e6
base = {b: cpm[[s for s in X.columns if s.startswith('Baseline_'+b)]].mean(axis=1) for b in ('NTC','STK11')}
plasmid = cpm[[s for s in X.columns if s.startswith('Plasmid')]].mean(axis=1)

# ---------- QC ----------
def gini(x):
    x=np.sort(np.asarray(x,float)); n=len(x); return (2*np.sum(np.arange(1,n+1)*x)/(n*x.sum()))-(n+1)/n
qc = pd.DataFrame({'group':grp,'background':bg,'total_reads':X.sum(),'guides_zero':(X==0).sum(),'frac_zero':(X==0).mean().round(4),
                   'gini':X.apply(gini).round(3)}).join(d.set_index('sample_name'))
L = np.log2(cpm+1); R = L.corr()
tum = [s for s in X.columns if s.startswith('Group')]
Rt = R.loc[tum,tum].copy(); np.fill_diagonal(Rt.values, np.nan)
qc.loc[tum,'max_r_other_tumour'] = Rt.max(axis=1).round(3); qc.loc[tum,'most_similar_tumour'] = Rt.idxmax(axis=1)
# background fingerprint: does the tumour look like its own background's pre-implant population?
bN = np.log2(cpm[[s for s in X.columns if s.startswith('Baseline_NTC')]]+5).mean(axis=1)
bS = np.log2(cpm[[s for s in X.columns if s.startswith('Baseline_STK11')]]+5).mean(axis=1)
dd = (bS-bN); dd = dd-dd.median(); ok = (base['NTC']>30)&(base['STK11']>30)
for s in tum: qc.loc[s,'bg_fingerprint_rho'] = round(stats.spearmanr((np.log2(cpm[s]+5)-(bS+bN)/2)[ok], dd[ok])[0],3)
qc['flag']=''
qc.loc[qc.total_reads<1e5,'flag'] += 'FAILED_LIBRARY(<1e5 reads);'
qc.loc[(qc.frac_zero>0.2)&(qc.total_reads>=1e5),'flag'] += 'SEVERE_BOTTLENECK(>20% guides zero);'
qc.loc[qc.max_r_other_tumour>0.95,'flag'] += 'DUPLICATE_LIBRARY(r>0.95 with another tumour);'
qc.to_csv(OUT+'invivo_sample_qc.csv')
EXCL = ['Group7_STK11_82431','Group3_NTC_82276','Group4_NTC_82321','Group3_NTC_82364']  # failed; bottleneck; bottleneck; duplicate of 82346

# ---------- log fold changes ----------
def lfc_matrix(pc=5.0):
    out={}
    for s in X.columns:
        if bg[s]=='NA': continue
        if s.startswith('Baseline'): continue
        l = np.log2((cpm[s]+pc)/(base[bg[s]]+pc)); out[s] = l-np.median(l[isntc])
    return pd.DataFrame(out)
LFC = lfc_matrix()
def gene_scores(LFC, samples, guides=None):
    M = LFC[samples]
    if guides is not None: M = M.loc[guides]
    return M.groupby(gene[M.index]).mean()
ARMS = {'Group1':'NTC | nude (inferred)','Group2':'NTC | C57BL/6, PD-L1-dependent arm (inferred isotype)','Group3':'NTC | C57BL/6, PD-1-blockade-like arm (inferred)','Group4':'NTC | C57BL/6, PD-1-blockade-like arm (inferred)',
        'Group5':'STK11 | nude (inferred)','Group6':'STK11 | C57BL/6, PD-L1-dependent arm (inferred isotype)','Group7':'STK11 | C57BL/6, PD-1-blockade-like arm (inferred)','Group8':'STK11 | C57BL/6, PD-1-blockade-like arm (inferred)',
        'Endpoint_NTC':'NTC | in vitro endpoint','Endpoint_STK11':'STK11 | in vitro endpoint'}
order = ['Endpoint_NTC','Group1','Group2','Group3','Group4','Endpoint_STK11','Group5','Group6','Group7','Group8']

def run(excl, label, guides_mgat=None, pc=5.0):
    LF = lfc_matrix(pc)
    keep = [s for s in LF.columns if s not in excl]
    GS = gene_scores(LF, keep).drop(index='NTC'); g = grp[keep]
    # null for gene score from random 4-guide NTC sets, per group median
    rng = np.random.default_rng(0)
    ntc_idx = np.where(isntc)[0]
    sets = [rng.choice(ntc_idx,4,replace=False) for _ in range(2000)]
    rows=[]
    for G in order:
        cols = [s for s in keep if g[s]==G]
        med = GS[cols].median(axis=1)
        nullmed = np.array([LF[cols].values[i].mean(0) for i in sets])
        nullmed = np.median(nullmed,axis=1)
        z = (med-nullmed.mean())/nullmed.std()
        rk = med.rank()
        m = GS.loc['Mgat1',cols] if guides_mgat is None else LF.loc[guides_mgat, cols].mean()
        # bootstrap CI of the median over tumours
        bs = [np.median(rng.choice(m.values,len(m))) for _ in range(5000)]
        rows.append(dict(analysis=label, group=G, arm=ARMS[G], n_samples=len(cols), Mgat1_median_log2FC=round(float(np.median(m)),2), ci95_lo=round(np.percentile(bs,2.5),2), ci95_hi=round(np.percentile(bs,97.5),2),
                         Mgat1_z_vs_NTC_guides=round(float(z['Mgat1']),1), Mgat1_rank_most_depleted=int(rk['Mgat1']), n_genes=len(rk),
                         frac_tumours_Mgat1_below_minus1=round(float((m<-1).mean()),2)))
    return pd.DataFrame(rows), GS, g, LF, keep
summ, GS, g, LF, keep = run(EXCL,'primary (4 QC exclusions; all 4 guides)')
summ_all,_,_,_,_ = run(['Group7_STK11_82431'],'sensitivity: only the failed library removed')
summ_3g,_,_,_,_ = run(EXCL,'sensitivity: 3 active guides (Mgat1_1,_2,_4)', guides_mgat=['Mgat1_1','Mgat1_2','Mgat1_4'])
summ_pc,_,_,_,_ = run(EXCL,'sensitivity: pseudocount 1 CPM', pc=1.0)
pd.concat([summ,summ_all,summ_3g,summ_pc]).to_csv(OUT+'invivo_Mgat1_by_group.csv', index=False)
print(summ.to_string())

# per-guide table
rows=[]
for gid in ['Mgat1_1','Mgat1_2','Mgat1_3','Mgat1_4']:
    for G in order:
        cols=[s for s in keep if g[s]==G]; v=LF.loc[gid,cols]
        rows.append(dict(guide=gid, group=G, arm=ARMS[G], n=len(cols), median_log2FC=round(v.median(),2), frac_below_minus1=round((v<-1).mean(),2)))
pd.DataFrame(rows).pivot(index='group',columns='guide',values='median_log2FC').loc[order].to_csv(OUT+'invivo_Mgat1_per_guide.csv')
print(pd.DataFrame(rows).pivot(index='group',columns='guide',values='median_log2FC').loc[order])

# ---------- contrasts (tumour = unit) ----------
def contrast(A,B,name):
    a = GS.loc[:,[s for s in keep if g[s] in A]]; b = GS.loc[:,[s for s in keep if g[s] in B]]
    t,p = stats.ttest_ind(a,b,axis=1,equal_var=False)
    pm = np.array([stats.mannwhitneyu(a.loc[x],b.loc[x]).pvalue for x in GS.index])
    df = pd.DataFrame({'contrast':name,'n_A':a.shape[1],'n_B':b.shape[1],'median_A':a.median(axis=1),'median_B':b.median(axis=1),'diff_median':a.median(axis=1)-b.median(axis=1),'welch_t':t,'p_mannwhitney':pm})
    df['fdr_bh']=multipletests(df.p_mannwhitney,method='fdr_bh')[1]
    df['rank_by_t(1=most selectively depleted in A)']=df.welch_t.rank().astype(int)
    return df.sort_values('welch_t')
CON = {'STK11_vs_NTC__C57BL6_all3arms':(['Group6','Group7','Group8'],['Group2','Group3','Group4']),
       'STK11_vs_NTC__nude':(['Group5'],['Group1']),
       'C57BL6_vs_nude__STK11':(['Group6','Group7','Group8'],['Group5']),
       'C57BL6_vs_nude__NTC':(['Group2','Group3','Group4'],['Group1']),
       'PD1blockadeLike_vs_isotypeLike__STK11':(['Group7','Group8'],['Group6']),
       'PD1blockadeLike_vs_isotypeLike__NTC':(['Group3','Group4'],['Group2'])}
allc=[]; keyrows=[]
rng = np.random.default_rng(1)
for name,(A,B) in CON.items():
    df = contrast(A,B,name); df.index.name='gene'; allc.append(df.reset_index())
    r = df.loc['Mgat1']
    a = GS.loc['Mgat1',[s for s in keep if g[s] in A]].values; b = GS.loc['Mgat1',[s for s in keep if g[s] in B]].values
    bs = [np.median(rng.choice(a,len(a)))-np.median(rng.choice(b,len(b))) for _ in range(5000)]
    keyrows.append(dict(contrast=name, A='+'.join(A), B='+'.join(B), n_A=len(a), n_B=len(b), Mgat1_median_A=round(r.median_A,2), Mgat1_median_B=round(r.median_B,2), diff=round(r.diff_median,2),
                        diff_ci95=f"{np.percentile(bs,2.5):.2f} to {np.percentile(bs,97.5):.2f}", p_mannwhitney=f"{r.p_mannwhitney:.1e}", fdr_bh=f"{r.fdr_bh:.1e}", rank_of_795=int(r['rank_by_t(1=most selectively depleted in A)'])))
    print('\n',name); print(df.head(8).round(3).to_string())
pd.concat(allc).to_csv(OUT+'invivo_contrasts_all_genes.csv', index=False)
K = pd.DataFrame(keyrows); K.to_csv(OUT+'invivo_Mgat1_key_contrasts.csv', index=False); print(K.to_string())
# share of the STK11-KO Mgat1 effect already present without T cells (log scale), bootstrap over tumours
rows=[]
for label,guides in [('all 4 guides',['Mgat1_1','Mgat1_2','Mgat1_3','Mgat1_4']),('3 active guides (Mgat1_1,_2,_4)',['Mgat1_1','Mgat1_2','Mgat1_4'])]:
    m = LF.loc[guides, keep].mean()
    nude = m[[s for s in keep if g[s]=='Group5']].values; b6 = m[[s for s in keep if g[s] in ('Group6','Group7','Group8')]].values
    wtn = m[[s for s in keep if g[s]=='Group1']].values; wtb = m[[s for s in keep if g[s] in ('Group2','Group3','Group4')]].values
    rb = np.random.default_rng(11)
    bs = [np.median(rb.choice(nude,len(nude)))/np.median(rb.choice(b6,len(b6))) for _ in range(20000)]
    rows.append(dict(guides=label, Stk11KO_nude_median=round(float(np.median(nude)),2), Stk11KO_C57BL6_median=round(float(np.median(b6)),2),
                     fold_depletion_nude=round(float(2**-np.median(nude)),1), fold_depletion_C57BL6=round(float(2**-np.median(b6)),1),
                     share_present_in_nude=round(float(np.median(nude)/np.median(b6)),2), share_ci95=f"{np.percentile(bs,2.5):.2f} to {np.percentile(bs,97.5):.2f}",
                     WT_nude_median=round(float(np.median(wtn)),2), WT_C57BL6_median=round(float(np.median(wtb)),2), fold_depletion_WT_C57BL6=round(float(2**-np.median(wtb)),1)))
NS = pd.DataFrame(rows); NS.to_csv(OUT+'invivo_Mgat1_nude_share.csv', index=False); print(NS.to_string())
# arm-identity evidence table
ev = GS.loc[['Cd274','Ptpn2','Stat1','Jak1','Adar','B2m','H2-K1','Cd47','Mgat1','B4galt1','Mgat2']].T; ev['group']=g
ev = ev.groupby('group').median().round(2).loc[[o for o in order if o.startswith('Group')]]
ev.insert(0,'animal_ID_range',[f"{min(int(s.split('_')[-1]) for s in keep if g[s]==G)}-{max(int(s.split('_')[-1]) for s in keep if g[s]==G)}" for G in ev.index])
ev.insert(0,'inferred_arm',[ARMS[G] for G in ev.index]); ev.to_csv(OUT+'invivo_arm_inference_evidence.csv'); print(ev.to_string())
# gene-level table by group
med = GS.T.groupby(g).median().T[order]; med.to_csv(OUT+'invivo_gene_median_log2FC_by_group.csv')
# in vitro (baseline vs plasmid; endpoint vs plasmid)
rows=[]
for b in ('NTC','STK11'):
    e = cpm[[s for s in X.columns if s.startswith('Endpoint_'+b)]].mean(axis=1)
    for nm,(num,den) in {'baseline_vs_plasmid':(base[b],plasmid),'endpoint_vs_baseline':(e,base[b]),'endpoint_vs_plasmid':(e,plasmid)}.items():
        l = np.log2((num+5)/(den+5)); l=l-np.median(l[isntc]); gl = l.groupby(gene).mean()
        nullsd = np.std([l.values[i].mean() for i in [np.random.default_rng(k).choice(np.where(isntc)[0],4,replace=False) for k in range(2000)]])
        rows.append(dict(background=b, comparison=nm, Mgat1_log2FC=round(gl['Mgat1'],2), z=round(gl['Mgat1']/nullsd,1), Rpl_Pcna_Plk1_mean=round(gl[['Rpl3','Rpl5','Rpl8','Rpl18','Pcna','Plk1']].mean(),2)))
pd.DataFrame(rows).to_csv(OUT+'invivo_invitro_arms_Mgat1.csv', index=False); print(pd.DataFrame(rows).to_string())
GS.T.assign(group=g).to_csv(OUT+'invivo_per_tumour_gene_scores.csv')

# ---------- sensitivity of the arm-level Mgat1 estimate to how tumours are summarised ----------
act = ['Mgat1_1','Mgat1_2','Mgat1_4']; allg = ['Mgat1_1','Mgat1_2','Mgat1_3','Mgat1_4']
rows=[]
for G in ['Group1','Group2','Group3','Group4','Group5','Group6','Group7','Group8']:
    cols = [s for s in keep if g[s]==G]
    m4 = LF.loc[allg, cols].mean(); m3 = LF.loc[act, cols].mean()
    pooled = cpm[cols].mean(axis=1); b = base[bg[cols[0]]]
    l = np.log2((pooled+5)/(b+5)); l = l - np.median(l[isntc])
    rows.append(dict(group=G, arm=ARMS[G], n=len(cols), median_of_tumours_4guides=round(m4.median(),2), mean_of_tumours_4guides=round(m4.mean(),2), median_of_tumours_3active=round(m3.median(),2),
                     median_all_guide_x_tumour_3active=round(float(np.median(LF.loc[act, cols].values)),2), pooled_mean_CPM_4guides=round(float(l[allg].mean()),2), pooled_mean_CPM_3active=round(float(l[act].mean()),2),
                     frac_tumours_below_minus1=round(float((m4<-1).mean()),2), frac_tumours_below_minus2=round(float((m4<-2).mean()),2)))
MS = pd.DataFrame(rows); MS.to_csv(OUT+'invivo_Mgat1_summary_method_sensitivity.csv', index=False); print(MS.to_string(index=False))
b6 = MS[MS.group.isin(['Group6','Group7','Group8'])]; nu = MS[MS.group=='Group5'].iloc[0]
for col in ['median_of_tumours_4guides','mean_of_tumours_4guides','median_of_tumours_3active','median_all_guide_x_tumour_3active','pooled_mean_CPM_4guides','pooled_mean_CPM_3active']:
    print(f'share of Stk11-KO log2 depletion present in nude-like arm [{col}]: {nu[col]/b6[col].mean():.2f}')

