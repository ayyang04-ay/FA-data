#!/usr/bin/env python
"""Reagent check (uses the GRCh38 reference genome in the analysis environment, i.e. data from outside the client package):
where do the human guide sequences listed in the records / the co-culture library map?  Needs samtools on PATH."""
import subprocess, re, pandas as pd
FA='/opt/refdbs/vep/homo_sapiens/116_GRCh38/Homo_sapiens.GRCh38.dna.toplevel.fa.gz'
lib = pd.read_csv('/tmp/world/filesystem/coculture_screen_umi_counts.csv.gz', usecols=['gene_symbol','sgrna_id','sgrna_sequence']).drop_duplicates('sgrna_id')
guides = {'MGAT1_1 (records, arrayed)':'GTTCCGAGAGCTGGCTACCG','MGAT1_2 (records, arrayed)':'ACTGGAAGGTGACAATACCC','MGAT1_3 (records, arrayed)':'GCCCGACCTGAGCAGCATTG','MGAT1_4 (records, arrayed)':'GGCCAGGGAAAAAGTCGGTG',
          'B2M sgRNA3 (records)':'GGCCGAGATGTCTCGCTCCG','PD-L1_sg1 (records)':'GGTTCCCAAGGACCTATATG','PD-L1_sg2 (records)':'ACTGCTTGTCCAGATGACTT','sgPTPN2 (records)':'CCATGACTATCCTCATAGAG','NTC-1 (records)':'AGTATGAGACTCATAGGGTG','NTC-2 (records)':'GAAGGCCTTAACACGTCGAC'}
for _,r in lib[lib.gene_symbol=='MGAT1'].iterrows(): guides[f'{r.sgrna_id} (co-culture library)'] = r.sgrna_sequence
rc = lambda s: s[::-1].translate(str.maketrans('ACGT','TGCA'))
hits = {k:[] for k in guides}
for ch in [str(i) for i in range(1,23)]+['X','Y']:
    seq = ''.join(subprocess.run(['samtools','faidx',FA,ch],capture_output=True,text=True).stdout.split('\n')[1:]).upper()
    for k,gseq in guides.items():
        for strand,s in (('+',gseq),('-',rc(gseq))):
            for m in re.finditer(s, seq):
                pam = seq[m.end():m.end()+3] if strand=='+' else rc(seq[m.start()-3:m.start()])
                hits[k].append(f'chr{ch}:{m.start()+1}({strand}) PAM {pam}')
out = pd.DataFrame([dict(guide=k, sequence=guides[k], n_perfect_matches=len(v), locations='; '.join(v)) for k,v in hits.items()])
out.to_csv('/tmp/outputs/tables/guide_mapping_GRCh38.csv', index=False); print(out.to_string(index=False))
