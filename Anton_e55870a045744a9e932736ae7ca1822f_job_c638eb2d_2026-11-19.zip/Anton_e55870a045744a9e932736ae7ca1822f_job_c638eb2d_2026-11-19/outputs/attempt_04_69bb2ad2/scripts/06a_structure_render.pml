load /tmp/world/filesystem/MGAT1_C3744_UDP.cif, tern
load /tmp/world/filesystem/MGAT1_UDP_GlcNAc.cif, ud1
remove solvent
remove tern and not chain A
remove ud1 and not chain A
remove resn EDO+GOL
align ud1 and name CA, tern and name CA
hide everything
bg_color white
set orthoscopic, 1
show cartoon, tern and polymer
color grey85, tern and polymer
color wheat, tern and polymer and resi 388-394+410-412+434-445
set stick_radius, 0.35
show sticks, tern and resn UDP
show spheres, tern and resn MN
set sphere_scale, 0.7
show sticks, ud1 and resn UD1 and name C1'+C2'+C3'+C4'+C5'+C6'+C7'+C8'+N2'+O3'+O4'+O5'+O6'+O7'
color green, ud1 and resn UD1 and elem C
show sticks, tern and resn C3744
color red, tern and resn C3744 and elem C
color blue, tern and resn UDP and elem C
color purple, tern and resn MN
show sticks, tern and polymer and resi 211+289 and not name N+C+O
color orange, tern and polymer and resi 211+289 and elem C
set cartoon_transparency, 0.3
distance dUDP, tern and resn C3744 and name C15, tern and resn UDP and name O1B
distance dD289, tern and resn C3744 and name C16, tern and polymer and resi 289 and name O
hide labels, dUDP
hide labels, dD289
set dash_color, black
set dash_width, 3
set dash_gap, 0.5
orient tern and (resn C3744 or resn UDP or resi 289)
turn z, 0
zoom tern and polymer, 4
set ray_trace_mode, 1
set ray_trace_gain, 0.05
set antialias, 2
set ray_shadows, 0
png /tmp/work/struct/fig5_raw.png, width=2000, height=1400, dpi=200, ray=1
python
from pymol import cmd
import numpy as np, json
v = cmd.get_view()
R = np.array(v[0:9]).reshape(3,3)   # rows: as returned
cam = np.array(v[9:12]); org = np.array(v[12:15]); fov = abs(cmd.get('field_of_view') and float(cmd.get('field_of_view')))
def cen(sel):
    m = cmd.get_model(sel); return np.mean([a.coord for a in m.atom],axis=0)
W,H = 2000,1400
def proj(p):
    pc = (np.array(p)-org) @ R + cam      # model -> camera (PyMOL stores rotation so that camera = (model-origin)·R + cam)
    half_h = abs(cam[2])*np.tan(np.radians(fov)/2)
    scale = (H/2)/half_h
    return (W/2 + pc[0]*scale, H/2 - pc[1]*scale)
out={}
for name,sel in [('lig','tern and resn C3744'),('udp','tern and resn UDP'),('mn','tern and resn MN'),('d289','tern and polymer and resi 289 and name CG'),('d211','tern and polymer and resi 211 and name CG'),('glcnac',"ud1 and resn UD1 and name C1'+C2'+C3'+C4'+C5'"),
                 ('ligC15','tern and resn C3744 and name C15'),('udpO1B','tern and resn UDP and name O1B'),('ligC16','tern and resn C3744 and name C16'),('d289O','tern and polymer and resi 289 and name O')]:
    out[name]=proj(cen(sel))
json.dump(out, open('/tmp/work/struct/fig5_proj.json','w'))
print(out)
python end
