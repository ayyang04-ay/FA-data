#!/usr/bin/env python
"""Readouts from phenotype_figures.pdf that are not line plots: co-culture bars (p.3), rescue panel (p.5), STK11 immunoblot (p.6).
Run 08a first. All values are approximate (pixel calibration against axis ticks / image densitometry of the embedded PNG)."""
from PIL import Image
import numpy as np
from scipy import ndimage as ndi
FIG='/tmp/work/figs/'
def grp(l, gap=1):
    g=[]
    for y in l:
        if g and y-g[-1][-1]<=gap: g[-1].append(y)
        else: g.append([y])
    return [(x[0],x[-1]) for x in g]
# ---------- p.3 co-culture competition bars ----------
a = np.array(Image.open(FIG+'phenotype_p03_0.png').convert('RGB')).astype(int); dk = a.sum(axis=2)<200
# calibration: top panel 0 at y=485.5, 147 px per unit (tumour-only bars = 1.0); bottom panel 0 at y=1183.5, 186.5 px per unit (ticks at 0.5 steps); dot radius ~8 px sits on each bar top
for name,(yaxis,ytop,ppu,labels) in {'NCI-H1703 (E:T 0.2, 0.4)':(485,100,147.0,['sgNTC','sgB2M','sgMGAT1_1','sgMGAT1_2','sgMGAT1_3','sgMGAT1_4']),
                                     'NCI-H1755 (E:T 0.2)':(1183,790,186.5,['sgNTC','sgB2M','sgMGAT1_1','sgMGAT1_2','sgMGAT1_3','sgMGAT1_4'])}.items():
    edges = grp([230+i for i,v in enumerate(dk[yaxis-12, 230:700]) if v]); vals=[]
    for i in range(0,len(edges)-1,2):
        x0 = edges[i][1]+1; x1 = edges[i+1][0]-1; y = yaxis-12
        while y>ytop and not all(a[y-k, x0:x1+1].sum(axis=1).min()>690 for k in range(3)): y-=1
        vals.append(round((yaxis+0.5-(y+8))/ppu,2))
    per = len(vals)//len(labels)
    print(name, {lab: vals[i*per:(i+1)*per] for i,lab in enumerate(labels)}, '(first value of each group = tumour-only bar, 1.0; for bars with error bars the value is the top of the error bar)')
# ---------- p.5 rescue panel: replicate dots ----------
a = np.array(Image.open(FIG+'phenotype_p05_0.png').convert('RGB')).astype(int)
def centres(mask, rmin=7, rmax=13):
    dt = ndi.distance_transform_edt(mask); mx = ndi.maximum_filter(dt, size=9); pts=[]
    for y,x in np.argwhere((dt==mx)&(dt>=rmin)&(dt<=rmax)):
        if all((x-px)**2+(y-py)**2>64 for px,py in pts): pts.append((x,y))
    return pts
y0, ppu = 772.5, 337.0
for name,m in {'black (no T cells, and sgMGAT1 groups)':a.sum(axis=2)<150, 'blue (donor 1, sgNTC groups)':(a[:,:,2]>110)&(a[:,:,0]<80)&(a[:,:,1]<80), 'red (donor 2, sgNTC groups)':(a[:,:,0]>180)&(a[:,:,1]<80)&(a[:,:,2]<80)}.items():
    sub = np.zeros_like(m); sub[230:765, 1385:2200] = m[230:765, 1385:2200]
    print('p.5 dots', name, sorted([(int(x), round((y0-y)/ppu,2)) for x,y in centres(sub)]))
# ---------- p.6 STK11 immunoblot densitometry ----------
inv = 255 - np.array(Image.open(FIG+'phenotype_p06_0.png').convert('L')).astype(float)
lanes = [(349,412),(435,498),(519,581),(603,665),(687,746),(768,834),(853,917),(937,1000),(1020,1084)]
labels = ['parental','MGAT1wt/STK11wt','MGAT1ko/STK11wt','MGAT1wt/STK11ko','MGAT1ko/STK11ko','STK11ko +WT cDNA','STK11ko +mut cDNA','MGAT1ko/STK11ko +WT cDNA','MGAT1ko/STK11ko +mut cDNA']
res=[]
for (c0,c1) in lanes:
    cc0,cc1 = c0+3,c1-3; r = 395+np.argmax(inv[395:445, cc0:cc1].mean(axis=1))
    band = inv[r-10:r+11, cc0:cc1].mean() - np.mean([inv[368:388, cc0:cc1].mean(), inv[448:462, cc0:cc1].mean()])
    vr = 565+np.argmax(inv[565:635, cc0:cc1].mean(axis=1)); vinc = inv[vr-9:vr+10, cc0:cc1].mean() - inv[540:555, cc0:cc1].mean()
    res.append(band/vinc)
ref = np.mean(res[1:3])
print('p.6 STK11/vinculin relative to the two Stk11-wild-type engineered lanes:'); [print(f'   lane {i+1} {l:28s} {v/ref:.2f}') for i,(l,v) in enumerate(zip(labels,res))]
