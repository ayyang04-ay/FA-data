#!/usr/bin/env bash
# Re-runs the whole re-analysis from the client files in /tmp/world/filesystem. `mm <env> <cmd>` = micromamba run -n <env> <cmd>.
set -euo pipefail
cd "$(dirname "$0")"; mkdir -p /tmp/outputs/tables /tmp/outputs/figures /tmp/work/figs /tmp/work/struct
mm core     python 01_invivo_screen.py                 > /tmp/work/log_01.txt
mm renv     Rscript 01b_invivo_screen_edgeR_crosscheck.R > /tmp/work/log_01b.txt 2>&1
mm core     python 01c_invivo_two_method_table.py      > /tmp/work/log_01c.txt
mm core     python 01d_invivo_scale_adjusted.py        > /tmp/work/log_01d.txt
mm core     python 02_coculture_screen.py              > /tmp/work/log_02.txt
mm chem     python 03_glycoproteomics.py               > /tmp/work/log_03.txt 2>&1
mm core     python 04_structures.py                    > /tmp/work/log_04.txt
mm genomics python 08a_extract_figure_images.py        > /tmp/work/log_08a.txt 2>&1
mm core     python 08b_digitise_assay_figures.py       > /tmp/work/log_08b.txt
mm core     python 08c_digitise_phenotype_figures.py   > /tmp/work/log_08c.txt
mm core     python 08d_read_bars_and_blot.py           > /tmp/work/log_08d.txt
mm core     python 09_guide_mapping_check.py           > /tmp/work/log_09.txt
mm core     python 05_figures.py
pymol -cq 06a_structure_render.pml > /tmp/work/log_06a.txt 2>&1
mm core     python 06b_structure_annotate.py
mm chem     python 07_render_memo_html.py
mm core     python 07b_render_memo_pdf.py
echo "all done"
