#!/usr/bin/env python
"""NCI-H1703 genome-wide T-cell co-culture screen - independent re-analysis.
Input : coculture_screen_umi_counts.csv.gz (one row per guide x UMI; two conditions, one sample each)
Method: guide count = sum over UMIs; log2FC (T-cell / tumour-only) normalised on the 989 NegCtrl guides;
        gene score = mean of its guides; empirical p from 200,000 random 4-guide NegCtrl sets; BH-FDR.
        Robustness: (a) UMI counts winsorised at 50, (b) number of UMIs detected instead of reads, (c) bootstrap over UMIs.
"""
import pandas as pd, numpy as np
from statsmodels.stats.multitest import multipletests
IN='/tmp/world/filesystem/'; OUT='/tmp/outputs/tables/'
df = pd.read_csv(IN+'coculture_screen_umi_counts.csv.gz').rename(columns={'tumor_only_untreated':'c','MSCV_TCR_high_24hr':'t'})
print('rows',len(df),'guides',df.sgrna_id.nunique(),'genes',df.gene_symbol.nunique(),'unique UMIs',df.umi_barcode.nunique())
print('reads: tumour-only %d, T-cell %d'%(df.c.sum(), df.t.sum()))
df['cw']=df.c.clip(upper=50); df['tw']=df.t.clip(upper=50); df['cp']=(df.c>0).astype(int); df['tp']=(df.t>0).astype(int)
g = df.groupby('sgrna_id').agg(gene=('gene_symbol','first'), genetype=('genetype','first'), n_umi=('c','size'), c=('c','sum'), t=('t','sum'), cw=('cw','sum'), tw=('tw','sum'), cp=('cp','sum'), tp=('tp','sum'))
neg = g.genetype=='NegCtrl'
def lfc(c,t,pc):
    sf = t[neg].sum()/c[neg].sum(); return np.log2((t+pc*sf)/(c+pc))-np.log2(sf)
g['lfc']=lfc(g.c,g.t,20); g['lfc_winsor']=lfc(g.cw,g.tw,20); g['lfc_umi_detect']=lfc(g.cp,g.tp,5)
print('NegCtrl guide log2FC: mean %.3f sd %.3f (n=%d)'%(g.lfc[neg].mean(), g.lfc[neg].std(), neg.sum()))
print('median UMIs per guide by class:', g.groupby('genetype').n_umi.median().to_dict())
tg = g[g.genetype.isin(['other','ESG'])]
rng = np.random.default_rng(0)
res = tg.groupby('gene').agg(n_guides=('lfc','size'), genetype=('genetype','first'), reads_ctrl=('c','sum'), reads_tcell=('t','sum'))
for col in ['lfc','lfc_winsor','lfc_umi_detect']:
    res[col+'_mean'] = tg.groupby('gene')[col].mean()
    res['rank_'+col] = res[col+'_mean'].rank(method='min').astype(int)
nv = g.lfc[neg].values; sd=g.lfc[neg].std()
null = np.sort(np.array([nv[rng.choice(len(nv),4,replace=False)].mean() for _ in range(200000)]))
res['n_guides_z_below_-2'] = tg.assign(z=(tg.lfc-g.lfc[neg].mean())/sd).groupby('gene').z.apply(lambda x:(x<-2).sum())
res['n_guides_z_above_2'] = tg.assign(z=(tg.lfc-g.lfc[neg].mean())/sd).groupby('gene').z.apply(lambda x:(x>2).sum())
res['p_depleted'] = (np.searchsorted(null, res.lfc_mean.values, side='right')+1)/(len(null)+1)
res['p_enriched'] = (len(null)-np.searchsorted(null, res.lfc_mean.values, side='left')+1)/(len(null)+1)
res['fdr_depleted']=multipletests(res.p_depleted,method='fdr_bh')[1]; res['fdr_enriched']=multipletests(res.p_enriched,method='fdr_bh')[1]
res = res.sort_values('lfc_mean'); res.round(4).to_csv(OUT+'coculture_gene_level.csv')
g.round(4).to_csv(OUT+'coculture_guide_level.csv')
print('genes FDR<5%% depleted: %d ; enriched: %d ; of %d'%((res.fdr_depleted<0.05).sum(), (res.fdr_enriched<0.05).sum(), len(res)))
# bootstrap over UMIs for selected genes
sfall = g.t[neg].sum()/g.c[neg].sum()
def boot(gene, B=2000):
    groups=[s[['c','t']].values for _,s in df[df.gene_symbol==gene].groupby('sgrna_id')]
    out=[]
    for b in range(B):
        l=[]
        for a in groups:
            i=rng.integers(0,len(a),len(a)); l.append(np.log2((a[i,1].sum()+20*sfall)/(a[i,0].sum()+20))-np.log2(sfall))
        out.append(np.mean(l))
    return np.percentile(out,[2.5,97.5])
sel = ['CFLAR','SLC35A1','PTPN2','GFPT1','SLC35A2','MGAT1','UAP1','CMAS','MOGS','MGAT2','MGAT5','MAN2A1','B4GALT1','SLC35A3','STK11','CD274','CD276','TRAF2','B2M','CTAG1B','CTAG1A','IFNGR1','IFNGR2','JAK1','JAK2','STAT1','TNFRSF1A','TAP1','TAP2','CD58','FAS','CASP8']
rows=[]
N=len(res)
for x in sel:
    r=res.loc[x]; ci=boot(x)
    rows.append({'gene':x,'n_guides':int(r.n_guides),'log2FC_mean':round(r.lfc_mean,2),'ci95_umi_bootstrap':f"{ci[0]:.2f} to {ci[1]:.2f}",'per_guide_log2FC':' / '.join(f'{v:.2f}' for v in tg[tg.gene==x].lfc),
                 f'rank_most_depleted_of_{N}':int(r.rank_lfc),'rank_winsorised':int(r.rank_lfc_winsor),'rank_umi_detection':int(r.rank_lfc_umi_detect),'fdr_depleted':f"{r.fdr_depleted:.2g}",'fdr_enriched':f"{r.fdr_enriched:.2g}"})
K=pd.DataFrame(rows); K.to_csv(OUT+'coculture_key_genes.csv',index=False); print(K.to_string())
m = df[df.gene_symbol=='MGAT1'].groupby('sgrna_id').agg(seq=('sgrna_sequence','first'), n_umi=('c','size'), reads_ctrl=('c','sum'), reads_tcell=('t','sum'), umi_detected_ctrl=('cp','sum'), umi_detected_tcell=('tp','sum'), max_umi_ctrl=('c','max'), max_umi_tcell=('t','max'))
m['log2FC']=g.loc[m.index,'lfc'].round(2); m.to_csv(OUT+'coculture_MGAT1_guides.csv'); print(m.to_string())
print('top 30 depleted:', ', '.join(f"{k}({v:.2f})" for k,v in res.lfc_mean.head(30).items()))
print('top 20 enriched:', ', '.join(f"{k}({v:.2f})" for k,v in res.lfc_mean.tail(20)[::-1].items()))
