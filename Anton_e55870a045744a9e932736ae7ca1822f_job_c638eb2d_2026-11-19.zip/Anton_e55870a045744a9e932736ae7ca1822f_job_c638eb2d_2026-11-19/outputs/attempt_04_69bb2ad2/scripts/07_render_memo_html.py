#!/usr/bin/env python
"""Render the memo to a single self-contained HTML file (figures embedded)."""
import markdown, base64, re, os
src = open('/tmp/outputs/MGAT1_recommendation_memo.md', encoding='utf-8').read()
html = markdown.markdown(src, extensions=['tables','sane_lists'])
def embed(m):
    path = os.path.join('/tmp/outputs', m.group(1))
    b64 = base64.b64encode(open(path,'rb').read()).decode()
    return f'src="data:image/png;base64,{b64}"'
html = re.sub(r'src="(figures/[^"]+)"', embed, html)
css = """
body{font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;font-size:14px;line-height:1.5;max-width:1080px;margin:32px auto;padding:0 24px;color:#1a1a1a}
h1{font-size:24px;border-bottom:2px solid #333;padding-bottom:8px} h2{font-size:19px;margin-top:32px;border-bottom:1px solid #bbb;padding-bottom:4px} h3{font-size:16px;margin-top:24px}
table{border-collapse:collapse;width:100%;margin:12px 0;font-size:13px} th,td{border:1px solid #c8c8c8;padding:6px 8px;vertical-align:top;text-align:left} th{background:#f0f0f0}
code{background:#f4f4f4;padding:1px 4px;border-radius:3px;font-size:12px} img{max-width:100%;display:block;margin:14px auto 4px auto} em{color:#444} hr{border:0;border-top:1px solid #ddd;margin:28px 0}
"""
open('/tmp/outputs/MGAT1_recommendation_memo.html','w',encoding='utf-8').write(f'<!doctype html><html><head><meta charset="utf-8"><title>MGAT1 programme - verification and recommendation</title><style>{css}</style></head><body>{html}</body></html>')
print('html written', len(html))
