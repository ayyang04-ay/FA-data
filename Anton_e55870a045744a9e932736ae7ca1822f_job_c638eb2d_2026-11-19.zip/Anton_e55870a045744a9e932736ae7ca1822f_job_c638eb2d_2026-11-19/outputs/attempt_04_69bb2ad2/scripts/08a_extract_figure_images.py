#!/usr/bin/env python
"""Extract the embedded page images from the two client figure PDFs (run in an env with pypdf, e.g. `mm genomics python 08a_...`)."""
import pypdf, os
IN='/tmp/world/filesystem/'; OUT='/tmp/work/figs/'; os.makedirs(OUT, exist_ok=True)
for f in ['assay_figures.pdf','phenotype_figures.pdf']:
    r = pypdf.PdfReader(IN+f)
    for i,p in enumerate(r.pages):
        for j,im in enumerate(p.images):
            fn = OUT+'%s_p%02d_%d.png'%(f.replace('_figures.pdf',''), i+1, j); im.image.save(fn); print(fn, im.image.size)
