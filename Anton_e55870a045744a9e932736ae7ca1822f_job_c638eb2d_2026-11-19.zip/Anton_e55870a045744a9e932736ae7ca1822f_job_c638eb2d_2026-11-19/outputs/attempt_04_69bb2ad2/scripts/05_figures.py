#!/usr/bin/env python
"""Figures for the MGAT1 diligence memo (reads the tables written by scripts 01-04)."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
T='/tmp/outputs/tables/'; F='/tmp/outputs/figures/'
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150,'savefig.dpi':200,'font.family':'DejaVu Sans'})
rng=np.random.default_rng(0)

# ---------- Fig 1: Mgat1 per tumour by arm ----------
gs = pd.read_csv(T+'invivo_per_tumour_gene_scores.csv', index_col=0)
order = ['Endpoint_NTC','Group1','Group2','Group3','Group4','Endpoint_STK11','Group5','Group6','Group7','Group8']
lab = {'Endpoint_NTC':'in vitro\nendpoint','Group1':'Group1\nnude*','Group2':'Group2\nB6*\nisotype-like','Group3':'Group3\nB6*\nPD-1-block-like','Group4':'Group4\nB6*\nPD-1-block-like',
       'Endpoint_STK11':'in vitro\nendpoint','Group5':'Group5\nnude*','Group6':'Group6\nB6*\nisotype-like','Group7':'Group7\nB6*\nPD-1-block-like','Group8':'Group8\nB6*\nPD-1-block-like'}
fig,axes = plt.subplots(1,2,figsize=(12.5,4.6),sharey=True,gridspec_kw={'wspace':0.06})
for ax,bgname,grs,col in [(axes[0],'Stk11-wild-type background (sgNTC)',order[:5],'#6b6b6b'),(axes[1],'Stk11-knockout background (sgStk11)',order[5:],'#1f6fb4')]:
    for i,G in enumerate(grs):
        v = gs.loc[gs.group==G,'Mgat1'].values
        ax.scatter(i+rng.uniform(-0.16,0.16,len(v)), v, s=16, color=col, alpha=0.75, lw=0, zorder=3)
        ax.hlines(np.median(v), i-0.3, i+0.3, color='k', lw=2, zorder=4)
        ax.text(i, 1.55, f'{np.median(v):.2f}\n(n={len(v)})', ha='center', va='bottom', fontsize=8)
    ax.axhline(0,color='grey',lw=0.8,ls='--'); ax.set_xticks(range(5)); ax.set_xticklabels([lab[G] for G in grs],fontsize=7.5); ax.set_title(bgname,fontsize=10,pad=24)
    ax.set_ylim(-6.2,2.6)
axes[0].set_ylabel('Mgat1 log2 fold-change vs pre-implant baseline\n(mean of 4 guides per tumour)')
fig.text(0.5,-0.09,'Each dot = one tumour (or one in-vitro endpoint sample); bar and number = median; values centred on the 400 non-targeting guides.\n*Arm identity is not in the records: inferred from animal-ID blocks and the behaviour of Cd274, Ptpn2, Stat1, Jak1 (tables/invivo_arm_inference_evidence.csv).',ha='center',fontsize=7.5)
fig.suptitle('In vivo pooled screen (MC38): Mgat1 loss is selected against in Stk11-KO tumours - present in the nude-like arm, deeper in C57BL/6, unchanged by PD-1 blockade',fontsize=10.5,y=1.04)
fig.savefig(F+'fig1_invivo_Mgat1_by_arm.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 2: contrasts ----------
con = pd.read_csv(T+'invivo_contrasts_all_genes.csv')
fig,axes = plt.subplots(1,3,figsize=(12.5,4.1),gridspec_kw={'wspace':0.32})
specs=[('STK11_vs_NTC__C57BL6_all3arms','Stk11-KO vs WT tumours, C57BL/6 (52 vs 50 tumours)\n"Is the dependency Stk11-selective?"',{'Mgat1':(8,3),'B4galt1':(8,3)}),
       ('C57BL6_vs_nude__STK11','C57BL/6 vs nude*, Stk11-KO tumours (52 vs 17)\n"Does it need T cells?"',{'Mgat1':(10,4),'Jak1':(8,3),'Ptpn2':(34,-12),'B2m':(34,8),'Stat1':(34,-22),'B4galt1':(8,4)}),
       ('PD1blockadeLike_vs_isotypeLike__STK11','PD-1-blockade-like* vs isotype-like*, Stk11-KO (35 vs 17)\n"Does PD-1 blockade deepen it?"',{'Mgat1':(8,4),'Ptpn2':(8,3),'Cd274':(-48,6),'B4galt1':(-58,4)})]
for ax,(name,title,labs) in zip(axes,specs):
    d = con[con.contrast==name].sort_values('welch_t').reset_index(drop=True)
    ax.scatter(d.index+1, d.diff_median, s=5, color='#b5b5b5', lw=0)
    for gname,off in labs.items():
        r = d[d.gene==gname]
        if len(r):
            c = '#d62728' if gname=='Mgat1' else '#1f6fb4'
            ax.scatter(r.index+1, r.diff_median, s=30 if gname=='Mgat1' else 16, color=c, zorder=5)
            ax.annotate(f"{gname} (rank {int(r.index[0])+1})", (r.index[0]+1, r.diff_median.iloc[0]), xytext=off, textcoords='offset points', fontsize=8, color=c, fontweight='bold' if gname=='Mgat1' else 'normal',
                        arrowprops=dict(arrowstyle='-',color=c,lw=0.5) if abs(off[0])>20 else None)
    ax.axhline(0,color='grey',lw=0.8,ls='--'); ax.set_xlabel('gene rank by Welch t (795 genes)'); ax.set_title(title,fontsize=8.5)
axes[0].set_ylabel('difference in median log2FC (first group - second group)')
fig.suptitle('Where Mgat1 sits among 795 library genes in the three contrasts that matter for the positioning (tumour = unit of replication)',fontsize=10.5,y=1.08)
fig.text(0.5,-0.03,'*inferred arm identity',ha='center',fontsize=7.5)
fig.savefig(F+'fig2_invivo_contrasts.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 3: co-culture screen ----------
g = pd.read_csv(T+'coculture_gene_level.csv', index_col=0)
k = pd.read_csv(T+'coculture_key_genes.csv')
rankcol = [c for c in k.columns if c.startswith('rank_most_depleted')][0]
k['lo'] = k.ci95_umi_bootstrap.str.split(' to ').str[0].astype(float); k['hi'] = k.ci95_umi_bootstrap.str.split(' to ').str[1].astype(float)
cat = {'MGAT1':'#d62728'}
for x in ['SLC35A1','CMAS','SLC35A2','GFPT1','UAP1','MOGS']: cat[x]='#ff7f0e'
for x in ['CFLAR','PTPN2','TRAF2']: cat[x]='#1f6fb4'
for x in ['CTAG1B','CTAG1A','B2M','IFNGR1','IFNGR2','STAT1','JAK1','JAK2','TNFRSF1A','TAP1','TAP2','CD58','FAS','CASP8']: cat[x]='#2ca02c'
for x in ['MGAT2','MGAT5','MAN2A1','B4GALT1','SLC35A3','STK11','CD274','CD276']: cat[x]='#7f7f7f'
show = ['CFLAR','SLC35A1','PTPN2','GFPT1','SLC35A2','MGAT1','UAP1','CMAS','MOGS','TRAF2','B4GALT1','MGAT2','MGAT5','CD274','SLC35A3','STK11','CD276','MAN2A1','TAP1','JAK1','TNFRSF1A','STAT1','IFNGR2','B2M','CTAG1B']
kk = k.set_index('gene').loc[show]
fig,axes = plt.subplots(1,2,figsize=(11.5,5.6),gridspec_kw={'width_ratios':[1,1.25],'wspace':0.28})
ax=axes[0]
ax.hist(g.lfc_mean, bins=120, color='#c9c9c9')
ax.set_yscale('log'); ax.set_xlabel('gene-level log2 fold-change (T-cell co-culture vs tumour only)'); ax.set_ylabel('number of genes (log scale)')
for nm,yy in [('MGAT1',300),('SLC35A1',60),('CFLAR',15),('B2M',15),('CTAG1B',60)]:
    x = g.loc[nm,'lfc_mean']; ax.annotate(nm,(x,1),xytext=(x,yy),ha='center',fontsize=8,color=cat[nm],fontweight='bold' if nm=='MGAT1' else 'normal',arrowprops=dict(arrowstyle='-|>',color=cat[nm],lw=0.8))
ax.set_title(f'All {len(g):,} genes (989 non-targeting guides: SD 0.20 per guide)',fontsize=9)
ax=axes[1]
y = np.arange(len(kk))[::-1]
for yi,(nm,r) in zip(y,kk.iterrows()):
    ax.plot([r.lo,r.hi],[yi,yi],color=cat[nm],lw=1.6); ax.scatter(r.log2FC_mean,yi,color=cat[nm],s=30 if nm=='MGAT1' else 18,zorder=4)
    ax.text(2.05,yi,f"#{int(r[rankcol]):,}",va='center',fontsize=7.5,color='#444444')
ax.set_yticks(y); ax.set_yticklabels(kk.index,fontsize=8)
for tl in ax.get_yticklabels():
    tl.set_color(cat[tl.get_text()]); tl.set_fontweight('bold' if tl.get_text()=='MGAT1' else 'normal')
ax.axvline(0,color='grey',lw=0.8,ls='--'); ax.set_xlim(-2.6,2.6); ax.set_xlabel('log2 fold-change, mean of guides (bar = 95% CI from bootstrapping UMIs)')
ax.text(2.05,len(kk)-0.3,'rank',fontsize=7.5,color='#444444',va='bottom')
ax.set_title('Selected genes: more killed by T cells  <-   ->  protected',fontsize=9)
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([],[],marker='o',ls='',color=c,label=l) for c,l in [('#d62728','MGAT1'),('#ff7f0e','glycan supply / sialylation / galactosylation / N-glycan trimming'),('#1f6fb4','known sensitisers'),('#2ca02c','known resistance genes (antigen, MHC-I, IFN/TNF sensing)'),('#7f7f7f','other N-glycan branching genes, STK11, PD-L1, B7-H3')]],fontsize=7,frameon=False,loc='lower left',bbox_to_anchor=(-0.02,-0.36))
fig.suptitle('NCI-H1703 genome-wide co-culture screen (NY-ESO-1 TCR-T, 24 h, one sample per condition): MGAT1 loss sensitises to T-cell killing (rank 22 of 19,114)',fontsize=10,y=0.97)
fig.savefig(F+'fig3_coculture_rank.png',bbox_inches='tight'); plt.close(fig)

# ---------- Fig 4: glycoproteomics ----------
gp = pd.read_csv(T+'glyco_glycopeptide_level.csv')
classes = ['Man6-9','Man5 (MGAT1 substrate)','hybrid / mono-antennary (HexNAc3)','complex (HexNAc>=4)']
fig,axes = plt.subplots(1,2,figsize=(12,4.4),gridspec_kw={'width_ratios':[1.15,1],'wspace':0.3})
ax=axes[0]; pos=0; ticks=[]; 
for cls in classes:
    for j,(nm,c) in enumerate([('A375','#8c564b'),('NCI-H1703','#1f6fb4')]):
        v = gp.loc[gp.glycan_class==cls,f'log2FC_{nm}'].dropna().values
        bp = ax.boxplot(v, positions=[pos+j*0.8], widths=0.65, patch_artist=True, showfliers=False, medianprops=dict(color='k'))
        bp['boxes'][0].set_facecolor(c); bp['boxes'][0].set_alpha(0.75)
    ticks.append(pos+0.4); pos+=2.2
ax.set_xticks(ticks); ax.set_xticklabels(['Man6-9\n(upstream)\nn=926','Man5\n(MGAT1 substrate)\nn=532','HexNAc3\n(hybrid/mono-ant.)\nn=133','complex\n(HexNAc>=4)\nn=379'],fontsize=8)
ax.axhline(0,color='grey',lw=0.8,ls='--'); ax.set_ylabel('log2 fold-change, MGAT1-KO vs sgNTC\n(TMT; n=4 v 4; ratios are compressed)')
ax.legend(handles=[plt.Rectangle((0,0),1,1,color='#8c564b',alpha=0.75,label='A375'),plt.Rectangle((0,0),1,1,color='#1f6fb4',alpha=0.75,label='NCI-H1703')],frameon=False,fontsize=8,loc='upper right')
ax.set_title('Glycopeptide classes (2,687 intact glycopeptides, 910 sites)',fontsize=9.5)
ax=axes[1]
s = pd.read_csv(T+'glyco_sites_with_Man5_and_complex.csv')
ax.scatter(s.complex_median_log2FC_H1703, s.Man5_log2FC_H1703, s=14, color='#1f6fb4', alpha=0.7, label='NCI-H1703', lw=0)
ax.scatter(s.complex_median_log2FC_A375, s.Man5_log2FC_A375, s=14, color='#8c564b', alpha=0.7, label='A375', lw=0)
for nm,site in [('CD276','N91'),('LAMP1','N249'),('SLC3A2','N381'),('TFRC','N251'),('MCAM','N544')]:
    r = s[(s.gene==nm)&(s.site==site)]
    if len(r): ax.annotate(f'{nm} {site}',(r.complex_median_log2FC_H1703.iloc[0],r.Man5_log2FC_H1703.iloc[0]),xytext=(5,3),textcoords='offset points',fontsize=7.5)
ax.axhline(0,color='grey',lw=0.8,ls='--'); ax.axvline(0,color='grey',lw=0.8,ls='--')
ax.set_xlabel('complex glycoforms at the site (median log2FC)'); ax.set_ylabel('Man5 glycoform at the same site (log2FC)'); ax.legend(frameon=False,fontsize=8)
ax.set_title('105 sites carrying both forms: complex down, Man5 up',fontsize=9)
fig.suptitle('Glycoproteomics confirms the expected on-target consequence of MGAT1 knockout in both human lines',fontsize=10.5,y=1.02)
fig.savefig(F+'fig4_glycoproteomics.png',bbox_inches='tight'); plt.close(fig)
print('figures written')
