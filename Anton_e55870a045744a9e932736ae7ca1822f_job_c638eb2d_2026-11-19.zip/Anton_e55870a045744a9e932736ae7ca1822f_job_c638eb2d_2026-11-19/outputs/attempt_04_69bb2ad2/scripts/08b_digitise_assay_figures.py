#!/usr/bin/env python
"""Pixel-digitise the dose-response curves (assay_figures.pdf p.1) and the IC50-vs-Kd scatter (p.5), then refit / correlate.
Axis calibration is taken from the tick marks of each panel. Run 08a first."""
from PIL import Image
import numpy as np, pandas as pd
from scipy import ndimage as ndi, stats
from scipy.optimize import curve_fit
FIG='/tmp/work/figs/'; T='/tmp/outputs/tables/'
# ---------- p.1: six dose-response panels ----------
a = np.array(Image.open(FIG+'assay_p01_0.png').convert('L')).astype(int); dk = a<100
yy,xx = np.mgrid[-6:7,-6:7]; disk = (xx**2+yy**2)<=36
lab,n = ndi.label(ndi.binary_opening(dk, structure=disk)); blobs=[]
for i in range(1,n+1):
    ys,xs = np.where(lab==i)
    if 100<len(ys)<600 and np.ptp(xs)<30 and np.ptp(ys)<30: blobs.append((xs.mean(), ys.mean()))
panels = {'ANT-0592':(0,0,-2),'ANT-1476':(1,0,-2),'ANT-2118':(2,0,-2),'ANT-3105':(0,1,-2),'ANT-3744':(1,1,-2),'ANT-4267':(2,1,-3)}   # column, row, log10 of first x tick
x0 = [215.5, 998.5, 1782.5]; dec = 101.2                      # x pixel of first decade tick; pixels per decade
ycal = [(529.5, 3.672),(1174.5,3.66)]                          # y pixel of 0 %; pixels per % activity
table = {'ANT-0592':197,'ANT-1476':2.02,'ANT-2118':25.6,'ANT-3105':0.543,'ANT-3744':0.814,'ANT-4267':0.043}
def fourpl(lc, top, bottom, lic50, hill): return bottom + (top-bottom)/(1+10**((lc-lic50)*hill))
rows=[]
for name,(ci,ri,lowdec) in panels.items():
    pts = sorted([(x,y) for x,y in blobs if (x0[ci]-10 < x < x0[ci]+650) and ((y<560) if ri==0 else (y>700))])
    lc = np.array([lowdec + (x-x0[ci])/dec for x,y in pts]); act = np.array([(ycal[ri][0]-y)/ycal[ri][1] for x,y in pts])
    p,_ = curve_fit(fourpl, lc, act, p0=[100, 5, np.median(lc), 1], maxfev=20000)
    rows.append(dict(compound=name, n_points=len(pts), conc_min_uM=round(10**lc.min(),4), conc_max_uM=round(10**lc.max(),1), top=round(p[0],1), bottom=round(p[1],1), IC50_refit_uM=round(10**p[2],3), hill=round(p[3],2),
                     IC50_table_uM=table[name], activity_at_top_conc=round(act[-1],1)))
R = pd.DataFrame(rows); R.to_csv(T+'biochem_dose_response_refit_from_figure.csv', index=False); print(R.to_string(index=False))
# ---------- p.5: IC50 vs SPR Kd ----------
a = np.array(Image.open(FIG+'assay_p05_0.png').convert('L')).astype(int); dk = a<128
dt = ndi.distance_transform_edt(dk); mx = ndi.maximum_filter(dt, size=9)
pts=[]
for y,x in np.argwhere((dt==mx)&(dt>=6.5)&(dt<=11)):
    if 240<x<1090 and 235<y<800 and all((x-px)**2+(y-py)**2>36 for px,py in pts): pts.append((x,y))
X = lambda px: 10**(-2 + (px-233.0)/172.3); Y = lambda py: 10**(3 - (py-233.0)/114.7)     # decade ticks: x 0.01 at 233 px, 172.3 px/decade; y 1000 at 233 px, 114.7 px/decade
d = pd.DataFrame(sorted([(X(x),Y(y)) for x,y in pts]), columns=['IC50_uM_read_from_figure','SPR_Kd_uM_read_from_figure']); d['IC50_over_Kd']=d.iloc[:,0]/d.iloc[:,1]
d.round(3).to_csv(T+'biochem_IC50_vs_Kd_read_from_figure.csv', index=False)
print('IC50 vs Kd: n=%d resolvable points; log-log Pearson r=%.3f; Spearman=%.3f; median IC50/Kd=%.2f (range %.2f-%.2f)'%(len(d), stats.pearsonr(np.log10(d.iloc[:,0]),np.log10(d.iloc[:,1]))[0], stats.spearmanr(d.iloc[:,0],d.iloc[:,1])[0], d.IC50_over_Kd.median(), d.IC50_over_Kd.min(), d.IC50_over_Kd.max()))
