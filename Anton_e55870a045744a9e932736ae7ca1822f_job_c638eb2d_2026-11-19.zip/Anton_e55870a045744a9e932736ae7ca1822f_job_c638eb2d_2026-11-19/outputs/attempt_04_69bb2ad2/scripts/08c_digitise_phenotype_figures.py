#!/usr/bin/env python
"""Pixel-read the tumour-growth panels of phenotype_figures.pdf (p.1, p.4, p.7, p.8). Run 08a first.
For each series colour, a narrow window centred on each time point is scanned top-to-bottom; runs of coloured rows
>= 6 px tall are markers (value = centre), runs of 2-4 px are error-bar caps. Axis calibration comes from the tick marks.
Values partly hidden behind other series, bar charts (p.2, p.3, p.5) and the STK11 blot (p.6) were read separately;
all readouts used in the memo are collected in tables/figure_readouts_digitised.csv."""
from PIL import Image
import numpy as np
FIG='/tmp/work/figs/'
def load(fn): return np.array(Image.open(FIG+fn).convert('RGB')).astype(int)
def scan(a, rgb, xc, y0, y1, tol, half, minw):
    m = (np.abs(a-np.array(rgb)).sum(axis=2) < tol); cnt = m[y0:y1, int(round(xc))-half:int(round(xc))+half+1].sum(axis=1)
    rows = np.where(cnt>=minw)[0]+y0; groups=[]
    for y in rows:
        if groups and y-groups[-1][-1]<=1: groups[-1].append(y)
        else: groups.append([y])
    return [(g[0],g[-1],len(g)) for g in groups]
def report(a, panel, yzero, px_per_unit, xs, cols, yrange, half=9, minw=8):
    print('==', panel)
    for name,(rgb,tol) in cols.items():
        for d,x in xs.items():
            g = scan(a, rgb, x, yrange[0], yrange[1], tol, half, minw)
            marks = [round((yzero-(s+e)/2)/px_per_unit) for s,e,n in g if n>=6 and (yzero-(s+e)/2)/px_per_unit>5]
            caps  = [round((yzero-(s+e)/2)/px_per_unit) for s,e,n in g if n<6 and (yzero-(s+e)/2)/px_per_unit>5]
            print(f'   {name:22s} day {d:>2}: marker {marks}  caps {caps}')
a = load('phenotype_p01_0.png'); BG = {'black sgNTC':((16,16,16),60), 'green sgMGAT1':((0,130,60),110)}
report(a,'p.1 left  MC38 WT (mm3)', 628.5, 130.17/1000, {25: 240.5+25*23.44}, BG, (150,640))
report(a,'p.1 middle MC38 sgSTK11 (mm3)', 628.5, 112/500, {19: 1099+19*29.45}, BG, (150,640))
report(a,'p.1 right MC38 sgSTK11 + treatment (mm3)', 629.0, 95.25/500, {9: 2044+9*57.1},
       {'black NTC;IgG2a':((16,16,16),60),'grey NTC;anti-PD1':((160,160,160),50),'green sgMGAT1;IgG2a':((40,165,50),90),'blue sgMGAT1;anti-PD1':((50,65,150),90)}, (230,640))
a = load('phenotype_p04_0.png'); C4 = {'blue sgNTC':((50,65,150),90), 'red sgMGAT1':((225,0,20),110)}; xs = {19:156.5+15.8*19}
report(a,'p.4 control T cells (mm3)', 362.5, 255.5/2500, xs, C4, (95,372), half=8)
report(a,'p.4 NYESO 1e6 (mm3)', 795.5, 256/2500, xs, C4, (525,805), half=8)
report(a,'p.4 NYESO 2e6 (mm3)', 1227.5, 256/2500, xs, C4, (955,1237), half=8)
a = load('phenotype_p07_0.png'); C7 = {'black MGAT1 WT cDNA':((16,16,16),60), 'blue D211A+D289A cDNA':((50,65,150),90)}
report(a,'p.7 left sgSTK11+sgNTC (mm3)', 638, 393/1500, {12:368+21.75*12}, C7, (215,650), half=11, minw=10)
report(a,'p.7 right sgSTK11+sgMGAT1 (mm3)', 642, 402/1500, {19:1064.5+21.72*19}, C7, (215,655), half=11, minw=10)
a = load('phenotype_p08_0.png'); C8 = {'black nude':((30,20,30),60), 'grey C57BL/6':((115,115,115),50), 'green C57BL/6+anti-PD1':((35,130,50),90)}
report(a,'p.8 left MC38 sgNTC (mm3)', 756.5, 506/1500, {8:325.5+76*8}, C8, (215,770), half=12, minw=11)
report(a,'p.8 right MC38 sgSTK11 (mm3)', 755.5, 503/2000, {7:1512.5+75.5*7}, C8, (215,770), half=12, minw=11)
