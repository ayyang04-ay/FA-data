#!/usr/bin/env python
"""Side-by-side table of the primary (median over tumours) and cross-check (edgeR pooled-count) estimates for Mgat1.
Run after 01_invivo_screen.py and 01b_invivo_screen_edgeR_crosscheck.R."""
import pandas as pd
T='/tmp/outputs/tables/'
e = pd.read_csv(T+'invivo_edgeR_crosscheck_all_genes.csv'); em = e[e.gene=='Mgat1'].set_index('contrast')
k = pd.read_csv(T+'invivo_Mgat1_key_contrasts.csv').set_index('contrast')
gs = pd.read_csv(T+'invivo_per_tumour_gene_scores.csv', index_col=0)
def med(groups): return round(float(gs[gs.group.isin(groups)]['Mgat1'].median()),2)
def rank_in(groups):
    m = gs[gs.group.isin(groups)].drop(columns='group').median(); return int(m.rank()['Mgat1'])
B6K=['Group6','Group7','Group8']; B6W=['Group2','Group3','Group4']
rows = [('Stk11-KO tumours, C57BL/6 arms (vs baseline)', med(B6K), rank_in(B6K), 'STK_B6'),
        ('Stk11-wild-type tumours, C57BL/6 arms (vs baseline)', med(B6W), rank_in(B6W), 'WT_B6'),
        ('Stk11-KO tumours, nude-like arm (vs baseline)', med(['Group5']), rank_in(['Group5']), 'STK_nude'),
        ('Stk11-wild-type tumours, nude-like arm (vs baseline)', med(['Group1']), rank_in(['Group1']), 'WT_nude'),
        ('Stk11-selectivity in C57BL/6 (KO minus wild-type)', k.loc['STK11_vs_NTC__C57BL6_all3arms','diff'], k.loc['STK11_vs_NTC__C57BL6_all3arms','rank_of_795'], 'STKvsWT_B6'),
        ('Stk11-selectivity in nude-like arms (KO minus wild-type)', k.loc['STK11_vs_NTC__nude','diff'], k.loc['STK11_vs_NTC__nude','rank_of_795'], 'STKvsWT_nude'),
        ('T-cell increment in Stk11-KO (C57BL/6 minus nude-like)', k.loc['C57BL6_vs_nude__STK11','diff'], k.loc['C57BL6_vs_nude__STK11','rank_of_795'], 'B6vsNude_STK'),
        ('T-cell increment in Stk11-wild-type (C57BL/6 minus nude-like)', k.loc['C57BL6_vs_nude__NTC','diff'], k.loc['C57BL6_vs_nude__NTC','rank_of_795'], 'B6vsNude_WT'),
        ('PD-1-blockade-like minus isotype-like, Stk11-KO', k.loc['PD1blockadeLike_vs_isotypeLike__STK11','diff'], k.loc['PD1blockadeLike_vs_isotypeLike__STK11','rank_of_795'], 'PD1vsIso_STK'),
        ('PD-1-blockade-like minus isotype-like, Stk11-wild-type', k.loc['PD1blockadeLike_vs_isotypeLike__NTC','diff'], k.loc['PD1blockadeLike_vs_isotypeLike__NTC','rank_of_795'], 'PD1vsIso_WT')]
out = pd.DataFrame([dict(quantity=q, primary_median_over_tumours_log2=m, primary_rank_of_795=int(r), crosscheck_NB_GLM_pooled_log2=round(float(em.loc[c,'mean_guide_logFC_NTCcentred']),2),
                         crosscheck_z_vs_NTC_sets=em.loc[c,'z_vs_NTC_sets'], crosscheck_rank_of_795=int(em.loc[c,'rank_by_logFC'])) for q,m,r,c in rows])
out.to_csv(T+'invivo_Mgat1_two_method_comparison.csv', index=False); print(out.to_string(index=False))
print('share of Stk11-KO effect present in nude-like arm: median method %.2f ; pooled-count model %.2f'%(out.iloc[2,1]/out.iloc[0,1], out.iloc[2,3]/out.iloc[0,3]))
