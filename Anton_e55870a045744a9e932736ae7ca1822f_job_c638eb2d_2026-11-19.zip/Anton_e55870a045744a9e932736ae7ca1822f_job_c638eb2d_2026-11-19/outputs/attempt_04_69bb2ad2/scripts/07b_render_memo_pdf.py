#!/usr/bin/env python
"""Render the memo markdown to PDF with ReportLab (simple converter: headings, paragraphs, bullet/numbered lists, tables, images)."""
import re, os, matplotlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, ListFlowable, ListItem, HRFlowable, KeepTogether
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader
SRC='/tmp/outputs/MGAT1_recommendation_memo.md'; OUT='/tmp/outputs/MGAT1_recommendation_memo.pdf'; BASE='/tmp/outputs/'
fd = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data/fonts/ttf/')
for name,f in [('DV','DejaVuSans.ttf'),('DV-B','DejaVuSans-Bold.ttf'),('DV-I','DejaVuSans-Oblique.ttf'),('DV-BI','DejaVuSans-BoldOblique.ttf'),('DVM','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name, fd+f))
pdfmetrics.registerFontFamily('DV', normal='DV', bold='DV-B', italic='DV-I', boldItalic='DV-BI')
body = ParagraphStyle('body', fontName='DV', fontSize=9, leading=12.5, spaceAfter=5, alignment=TA_LEFT)
h1 = ParagraphStyle('h1', parent=body, fontName='DV-B', fontSize=15, leading=19, spaceAfter=8)
h2 = ParagraphStyle('h2', parent=body, fontName='DV-B', fontSize=12, leading=15, spaceBefore=10, spaceAfter=6)
h3 = ParagraphStyle('h3', parent=body, fontName='DV-B', fontSize=10, leading=13, spaceBefore=8, spaceAfter=4)
cell = ParagraphStyle('cell', parent=body, fontSize=7.2, leading=9.2, spaceAfter=0)
cellh = ParagraphStyle('cellh', parent=cell, fontName='DV-B')
cap = ParagraphStyle('cap', parent=body, fontName='DV-I', fontSize=8, leading=10, textColor=colors.HexColor('#444444'), spaceAfter=8)
def inline(t):
    t = t.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'`(.+?)`', r'<font face="DVM" size="-1">\1</font>', t)
    t = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'<i>\1</i>', t)
    return t
W = A4[0]-3.0*cm
def make_table(lines):
    rows = [[c.strip() for c in ln.strip().strip('|').split('|')] for ln in lines if not re.match(r'^\s*\|[\s\-|:]+\|\s*$', ln)]
    ncol = len(rows[0]); rows = [r+['']*(ncol-len(r)) for r in rows]
    lens = [max(12, sum(len(r[i]) for r in rows)/len(rows))**0.6 for i in range(ncol)]
    # minimum width = longest unbreakable word in the column (so words are never split) + padding
    def longest(i):
        words = [w for r in rows for w in re.split(r'[\s/]+', re.sub(r'[*`]', '', r[i])) if w]
        return max(pdfmetrics.stringWidth(w, 'DV-B', 7.2) for w in words) + 9 if words else 1.5*cm
    minw = [longest(i) for i in range(ncol)]
    widths = [W*l/sum(lens) for l in lens]
    for _ in range(20):                                   # enforce minima, redistribute the remainder proportionally
        deficit = sum(max(0, minw[i]-widths[i]) for i in range(ncol))
        if deficit < 0.5: break
        free = [i for i in range(ncol) if widths[i] > minw[i]]
        tot = sum(widths[i]-minw[i] for i in free)
        widths = [max(widths[i], minw[i]) if i not in free else widths[i] - deficit*(widths[i]-minw[i])/tot for i in range(ncol)]
    s_ = sum(widths); widths = [w*W/s_ for w in widths]
    data = [[Paragraph(inline(c), cellh if ri==0 else cell) for c in r] for ri,r in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.4,colors.HexColor('#b5b5b5')),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#ececec')),('VALIGN',(0,0),(-1,-1),'TOP'),
                           ('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),('TOPPADDING',(0,0),(-1,-1),2.5),('BOTTOMPADDING',(0,0),(-1,-1),2.5)]))
    return t
story=[]; lines = open(SRC, encoding='utf-8').read().split('\n'); i=0
while i < len(lines):
    ln = lines[i]
    if not ln.strip(): i+=1; continue
    if ln.startswith('# '): story.append(Paragraph(inline(ln[2:]), h1)); i+=1; continue
    if ln.startswith('## '): story.append(Paragraph(inline(ln[3:]), h2)); i+=1; continue
    if ln.startswith('### '): story.append(Paragraph(inline(ln[4:]), h3)); i+=1; continue
    if ln.strip()=='---': story.append(HRFlowable(width='100%', thickness=0.5, color=colors.HexColor('#bbbbbb'), spaceBefore=6, spaceAfter=6)); i+=1; continue
    m = re.match(r'!\[(.*?)\]\((.*?)\)', ln.strip())
    if m:
        path = BASE+m.group(2); iw,ih = ImageReader(path).getSize(); w = W; h = w*ih/iw
        if h > 11.5*cm: h = 11.5*cm; w = h*iw/ih
        img = Image(path, width=w, height=h); img.hAlign='CENTER'
        nxt = lines[i+2].strip() if i+2 < len(lines) else ''
        if re.match(r'^\*[^*].*\*$', nxt): story.append(KeepTogether([img, Paragraph(inline(nxt.strip('*')), cap)])); i+=3
        else: story.append(img); i+=1
        continue
    if ln.lstrip().startswith('|'):
        blk=[]
        while i < len(lines) and lines[i].lstrip().startswith('|'): blk.append(lines[i]); i+=1
        story.append(make_table(blk)); story.append(Spacer(1,6)); continue
    if re.match(r'^(- |\d+\. )', ln):
        items=[]; numbered = bool(re.match(r'^\d+\. ', ln))
        while i < len(lines) and re.match(r'^(- |\d+\. )', lines[i]):
            items.append(ListItem(Paragraph(inline(re.sub(r'^(- |\d+\. )','',lines[i])), body), leftIndent=14)); i+=1
        story.append(ListFlowable(items, bulletType='1' if numbered else 'bullet', bulletFontName='DV', bulletFontSize=8, leftIndent=14, start=None if numbered else '•')); story.append(Spacer(1,3)); continue
    para=[ln]; i+=1
    while i < len(lines) and lines[i].strip() and not re.match(r'^(#|- |\d+\. |\||!\[|---)', lines[i]): para.append(lines[i]); i+=1
    story.append(Paragraph(inline(' '.join(para)), body))
def footer(canvas, doc):
    canvas.saveState(); canvas.setFont('DV', 7); canvas.setFillColor(colors.HexColor('#666666'))
    canvas.drawString(1.5*cm, 0.9*cm, 'MGAT1 inhibitor programme: independent verification and recommendation'); canvas.drawRightString(A4[0]-1.5*cm, 0.9*cm, 'page %d'%doc.page); canvas.restoreState()
SimpleDocTemplate(OUT, pagesize=A4, leftMargin=1.5*cm, rightMargin=1.5*cm, topMargin=1.4*cm, bottomMargin=1.5*cm, title='MGAT1 inhibitor programme: independent verification and recommendation').build(story, onFirstPage=footer, onLaterPages=footer)
print('pdf written')
