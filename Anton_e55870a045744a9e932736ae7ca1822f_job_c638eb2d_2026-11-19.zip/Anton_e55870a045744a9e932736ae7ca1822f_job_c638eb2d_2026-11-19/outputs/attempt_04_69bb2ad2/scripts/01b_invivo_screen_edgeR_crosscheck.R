# Orthogonal cross-check of the in vivo screen with a negative-binomial GLM (edgeR quasi-likelihood).
# Same QC exclusions as the primary analysis; library sizes scaled on the 400 non-targeting guides;
# guide-level contrasts are (tumour arm vs its own pre-implant baseline); genes are summarised with fry() (4 guides = one set).
suppressMessages({library(edgeR); library(limma)})
x <- read.csv(gzfile('/tmp/world/filesystem/crispr_invivo_guide_counts.csv.gz'), check.names=FALSE)
meta <- x[,1:3]; cnt <- as.matrix(x[,-(1:3)]); rownames(cnt) <- meta$gene_sgrna_id
excl <- c('Group7_STK11_82431','Group3_NTC_82276','Group4_NTC_82321','Group3_NTC_82364')
keep <- !(colnames(cnt) %in% excl) & !grepl('^Plasmid|^Endpoint', colnames(cnt))
cnt <- cnt[,keep]
grp <- sub('_(NTC|STK11)_.*','',colnames(cnt)); grp[grepl('^Baseline_NTC',colnames(cnt))] <- 'BaseNTC'; grp[grepl('^Baseline_STK11',colnames(cnt))] <- 'BaseSTK'
grp <- factor(grp)
isntc <- grepl('^BRDN', meta$gene_symbol)
y <- DGEList(cnt, group=grp)
y$samples$lib.size <- colSums(cnt[isntc,])           # scale on non-targeting guides
y$samples$norm.factors <- 1
design <- model.matrix(~0+grp); colnames(design) <- levels(grp)
y <- estimateDisp(y, design, robust=TRUE)
cat('common dispersion:', y$common.dispersion, '\n')
fit <- glmQLFit(y, design, robust=TRUE)
con <- makeContrasts(
  STK_B6      = (Group6+Group7+Group8)/3 - BaseSTK,
  WT_B6       = (Group2+Group3+Group4)/3 - BaseNTC,
  STK_nude    = Group5 - BaseSTK,
  WT_nude     = Group1 - BaseNTC,
  STKvsWT_B6  = ((Group6+Group7+Group8)/3 - BaseSTK) - ((Group2+Group3+Group4)/3 - BaseNTC),
  STKvsWT_nude= (Group5 - BaseSTK) - (Group1 - BaseNTC),
  B6vsNude_STK= (Group6+Group7+Group8)/3 - Group5,
  B6vsNude_WT = (Group2+Group3+Group4)/3 - Group1,
  PD1vsIso_STK= (Group7+Group8)/2 - Group6,
  PD1vsIso_WT = (Group3+Group4)/2 - Group2,
  levels=design)
genes <- ifelse(isntc, NA, meta$gene_symbol)
idx <- split(seq_len(nrow(cnt))[!isntc], genes[!isntc])
out <- list()
for (cn in colnames(con)) {
  qlf <- glmQLFTest(fit, contrast=con[,cn])
  tt <- qlf$table
  ntc_shift <- median(tt$logFC[isntc])               # re-centre on the typical non-targeting guide (sum-based scaling is jackpot-sensitive)
  tt$logFC <- tt$logFC - ntc_shift
  g_lfc <- tapply(tt$logFC[!isntc], genes[!isntc], mean)
  # empirical gene-level null from random 4-guide sets of non-targeting guides
  set.seed(1); nullm <- replicate(20000, mean(sample(tt$logFC[isntc], 4)))
  fr <- fry(y, index=idx, design=design, contrast=con[,cn])
  fr <- fr[names(g_lfc),]
  # signed rank: most negative first, by signed -log10 p
  score <- ifelse(fr$Direction=='Down', log10(fr$PValue), -log10(fr$PValue))
  rk <- rank(score, ties.method='min')
  z <- (as.numeric(g_lfc)-mean(nullm))/sd(nullm)
  out[[cn]] <- data.frame(contrast=cn, gene=names(g_lfc), mean_guide_logFC_NTCcentred=round(as.numeric(g_lfc),3), z_vs_NTC_sets=round(z,2), rank_by_logFC=rank(as.numeric(g_lfc), ties.method='min'), ntc_median_shift_removed=round(ntc_shift,3),
                          fry_direction=fr$Direction, fry_p=signif(fr$PValue,3), fry_fdr=signif(fr$FDR,3), rank_by_fry=rk)
  m <- out[[cn]][out[[cn]]$gene=='Mgat1',]
  cat(sprintf('%-14s NTC shift %5.2f | Mgat1 centred logFC %6.2f  z %6.1f  rank(logFC) %3d  | fry %s p=%.2g rank %d | guides: %s\n', cn, ntc_shift, m$mean_guide_logFC_NTCcentred, m$z_vs_NTC_sets, m$rank_by_logFC, m$fry_direction, m$fry_p, m$rank_by_fry,
              paste(round(tt$logFC[meta$gene_symbol=='Mgat1'],2), collapse=' / ')))
}
res <- do.call(rbind, out)
write.csv(res, '/tmp/outputs/tables/invivo_edgeR_crosscheck_all_genes.csv', row.names=FALSE)
write.csv(res[res$gene %in% c('Mgat1','B4galt1','Jak1','Ptpn2','Adar','B2m','Cd274','Stat1','Mgat2'),], '/tmp/outputs/tables/invivo_edgeR_crosscheck_key_genes.csv', row.names=FALSE)
for (cn in c('STKvsWT_B6','STKvsWT_nude','B6vsNude_STK','PD1vsIso_STK','STK_nude','WT_nude')) { d <- out[[cn]]; d <- d[order(d$rank_by_logFC),]; cat('\n',cn,'top 10 by centred logFC:', paste(sprintf('%s(%.2f)', d$gene[1:10], d$mean_guide_logFC_NTCcentred[1:10]), collapse=', '), '\n') }
