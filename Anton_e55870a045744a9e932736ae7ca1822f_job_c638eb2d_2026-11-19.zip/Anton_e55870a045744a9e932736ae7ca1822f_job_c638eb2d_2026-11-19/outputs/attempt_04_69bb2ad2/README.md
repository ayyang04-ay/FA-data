# MGAT1 programme diligence: contents of this folder

| File | What it is |
|---|---|
| `MGAT1_recommendation_memo.md` | The recommendation memo (master copy). Section 1 is the call; section 7 maps every number to its source. |
| `MGAT1_recommendation_memo.html` | Same memo, single self-contained file with figures embedded. |
| `MGAT1_recommendation_memo.pdf` | Same memo as PDF (rendered from the markdown with ReportLab). |
| `figures/fig1…fig5` | Figures used in the memo. |
| `tables/` | Every table the memo cites (CSV). |
| `scripts/` | Code that regenerates all tables and figures from the client files; `run_all.sh` runs everything (about 5 minutes). |

## Tables

| Table | Content |
|---|---|
| `invivo_sample_qc.csv` | Per-sample QC of the in vivo screen: reads, zero-count guides, Gini, sequencing run and index, closest other tumour, background-match score, exclusion flag. |
| `invivo_Mgat1_by_group.csv` | Mgat1 median log2 fold-change, CI, z and rank per arm; primary analysis plus three sensitivity variants. |
| `invivo_Mgat1_per_guide.csv` | Median log2 fold-change of each of the four Mgat1 guides per arm. |
| `invivo_Mgat1_key_contrasts.csv` | The six contrasts for Mgat1 (Stk11-KO vs wild-type; C57BL/6 vs nude-like; PD-1-like vs isotype-like), with CI, p and rank. |
| `invivo_contrasts_all_genes.csv` | The same contrasts for all 795 genes. |
| `invivo_Mgat1_two_method_comparison.csv` | Primary (median over tumours) and cross-check (edgeR pooled-count model) estimates side by side. |
| `invivo_edgeR_crosscheck_all_genes.csv`, `…_key_genes.csv` | Full output of the edgeR cross-check. |
| `invivo_scale_adjusted_relative_depletion.csv` | Depletion relative to 34 culture-depleted "yardstick" genes, per arm, for Mgat1 and reference genes. |
| `invivo_Mgat1_nude_share.csv`, `invivo_Mgat1_summary_method_sensitivity.csv` | Share of the Stk11-KO effect present in the nude-like arm under different summary statistics. |
| `invivo_arm_inference_evidence.csv`, `invivo_arm_signature_per_tumour.csv` | Evidence used to infer which group is which arm (not stated in the client records): marker genes per group, and a ten-gene T-cell-pressure signature per tumour. |
| `invivo_gene_median_log2FC_by_group.csv`, `invivo_per_tumour_gene_scores.csv` | Gene-level values for every arm and every tumour. |
| `invivo_invitro_arms_Mgat1.csv` | Mgat1 and essential-gene behaviour in culture (plasmid, baseline, endpoint). |
| `coculture_gene_level.csv`, `coculture_guide_level.csv` | NCI-H1703 co-culture screen, all genes and all guides, three counting methods. |
| `coculture_key_genes.csv`, `coculture_MGAT1_guides.csv` | Selected genes with bootstrap intervals; the four MGAT1 guides. |
| `glyco_class_summary.csv`, `glyco_glycopeptide_level.csv`, `glyco_sites_with_Man5_and_complex.csv`, `glyco_channel_signature.csv` | Glycoproteomics re-analysis. |
| `structure_summary.csv`, `structure_ligand_contacts_4A.csv`, `structure_ANT3744_distances.csv`, `structure_conformational_changes.csv` | Crystal-structure geometry. |
| `biochem_dose_response_refit_from_figure.csv`, `biochem_IC50_vs_Kd_read_from_figure.csv` | Values digitised from the assay figures and refitted. |
| `figure_readouts_digitised.csv` | Every value read from the phenotype figures, with page, panel and caveats. |
| `guide_mapping_GRCh38.csv` | Where the human guide sequences map in the reference genome (reagent check; uses data from outside the client package). |

## Notes on provenance

- Client files were read from `/tmp/world/filesystem` and were not modified.
- Arm identity for Groups 1–8 of the in vivo screen is inferred, not documented. Anything that depends on it is flagged in the memo.
- Values read from figures are approximate.
- The PDF was generated in an environment without a PDF viewer. Its text and layout were checked programmatically, not by eye; the markdown and HTML are the reference copies.
