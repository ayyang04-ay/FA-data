# CRE-MK-01 → validation proposal: deliverables

| File | What it is |
|---|---|
| `CRE-MK-01_validation_proposal.md` / `.docx` / `.html` | The committee proposal. The first line is the recommendation; Section 1 is the decision summary; Sections 3–4 give the evidence; Section 5 specifies the in vivo slot study (CRE-MK-02); Sections 6–7 cover follow-on studies and decision criteria. |
| `figures/fig1_forest_metastatic_burden.png` | Creatine effect on lung metastatic burden across every comparison in the package (GMR, 95% CI; random-effects pool). Integrity-flagged experiments are shown in grey. |
| `figures/fig2_transcript_heatmap.png` | MK transcript programme: 6 creatine experiments, the perturbations (Slc6a8-KO, siCkb, STAT5i, Stat5b-KO, liposomal creatine, PCr), and human CD41+ cells |
| `figures/fig3_human_platelet_function.png` | Within-subject re-analysis of volunteer aggregation by agonist and day |
| `figures/fig4_phosphoproteomics_QC.png` | p-value distribution (imputation artefacts) and volcano: no FDR-significant phosphosites |
| `figures/fig5_MK_SLC6A8_gate.png` | MK-Slc6a8 knockout: metastasis, MK creatine, aggregation (including the Fig 3d paradox) |
| `figures/fig6_human_platelet_protein.png` | Human GP6 and P2RY12 protein: tabulated values vs approximate densitometry of the representative blots |
| `figures/fig7_target_scorecard.png` | Evidence scorecard built only from CRE-MK-01 data |
| `analysis/*.py` | Re-analysis scripts (Python; pandas, SciPy, statsmodels, lifelines, matplotlib) |
| `analysis/*.csv` | All recomputed statistics cited in the proposal |

## Reproducing the analysis

1. Make a working directory containing `CRE-MK-01_source_data.xlsx`, `CRE-MK-01_phosphoproteomics.xlsx` and a sub-folder `analysis/` holding the scripts.
2. Run the scripts in numeric order (`01_…` to `16_…`). The figure scripts (`12_`, `12b_`, `13_`) need the CSVs produced by the earlier scripts.
3. For the densitometry checks (`densit.py`, `densit_generic.py`), the images must first be extracted from the workbook to `src_unz/xl/media/`; an `.xlsx` file is a zip archive.

Every reported P-value that we re-computed reproduced exactly from the tabulated values. The densitometry on published JPEG panels is a plausibility check only, not a measurement.
