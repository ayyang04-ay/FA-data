**Recommendation: we take platelet GPVI (GP6) forward as the primary target. The in vivo slot should test whether blocking GPVI prevents creatine-driven metastasis. Megakaryocyte SLC6A8 (the creatine-uptake gate) is backup #1 and is re-tested as a benchmark arm in the same study. The α2A-adrenergic receptor (ADRA2A) is backup #2. STAT5B, CKB, P2Y12 and COX-1 are not advanced this quarter.**

# CRE-MK-01 follow-up: validation proposal for the next-quarter in vivo slot

*Evidence base: CRE-MK-01 source data (87 panels), the phosphoproteomics export and the study-conventions document only. External literature was not used as evidence. Where a design choice rests on an assumption that the package does not test, this document says so.*

---

## 1. Decision summary

| | Target | Why it is in this position (CRE-MK-01 data only) | What the next quarter does |
|----|--------|------------------------------------|------------|
| **Primary** | **Platelet GPVI (GP6)** | Of the effectors we measured, only GPVI lines up at every level of evidence: mouse MK mRNA, mouse platelet function, promoter occupancy, human mRNA, human protein and human platelet function. *Gp6* was induced in all 6 independent mouse MK experiments (2.8–42×; the largest and most consistent transcript). Creatine increased STAT5B occupancy at its promoter. Collagen-evoked aggregation rose in mice (Figs 2b, 3d). In the four volunteers with molecular data, GP6 protein rose in 4/4 (2.6× by day 14), and collagen-evoked aggregation rose in 9/11 volunteers by day 14 (geometric mean 2.5×). The one thing missing is a causal test, and that is what an in vivo slot can supply. | **CRE-MK-02:** a blinded 2×2 study (creatine × GPVI blockade) in both sexes, with an MK-*Slc6a8*-knockout benchmark arm |
| Backup #1 | Megakaryocyte SLC6A8 | This is the only node with in vivo loss-of-function protection. In MK-specific knockouts, creatine no longer increased metastasis (genotype × creatine interaction p = 0.0003), and liposomal creatine restored gene induction in knockout MKs. However, the axis does nothing without supplemental creatine: knockout vehicle mice had 3.39% burden vs 2.36% in wild-type vehicle mice. We have no human data on SLC6A8, and there is an unexplained aggregation result (Fig 3d). | Re-tested inside CRE-MK-02 as the "full-blockade" reference. Advanced if GPVI fails and the benchmark replicates. |
| Backup #2 | α2A-adrenergic receptor (ADRA2A) | This is the strongest human functional signal. Epinephrine-evoked aggregation rose in 10–11/11 volunteers at days 7 and 14 (FDR < 0.05), and *ADRA2A* mRNA rose in 4/4 (about 20× at day 7). It was also induced in 6/6 mouse experiments. The gaps: it was never tested functionally in mice, and it has no causal data. | Mouse epinephrine-potentiation assay, then α2A blockade, if the GPVI result is negative |
| Not advanced | STAT5B | This is the package's headline mechanism and its weakest link. No phosphosite passes FDR (minimum q = 0.167), and canonical STAT5 tyrosine phosphorylation is undetectable in MKs. The only metastasis rescue used a pan-STAT5A/B inhibitor given systemically. The MK-*Stat5b* knockout has no metastasis readout. Identical animal-level values for three animals per group appear in both the STAT5-inhibitor experiment (Fig 6b) and the aspirin platelet-transfer experiment (Supp 2d). | Integrity audit, plus a low-cost MK-*Stat5b*-knockout metastasis run outside the slot |
| Not advanced | CKB | All evidence is in vitro. Knocking it down blocks only part of the induction (median 41% of the log-induction retained). CKB protein in brain is at least 3.6× the MK level (Fig 4b). | None this quarter |
| Not advanced | P2Y12, COX-1 | Human function does not agree. ADP-evoked aggregation was flat (day-14 geometric mean 1.07×, 6/11 volunteers up). Arachidonic-acid responses showed only a trend. The aspirin result (Supp 2d) is on integrity hold. | None this quarter |

**What would change this call.** The decision rules for the slot are in Section 5.4 and the full elevation/demotion matrix is in Section 7. In short:

* If GPVI blockade does not reduce the creatine increment but the *Slc6a8*-knockout benchmark abolishes it, SLC6A8 (and then ADRA2A) moves up.
* If the creatine effect does not replicate under masked conditions, all target work stops.

---

## 2. The five findings that drive the recommendation

1. **The phenotype is reproducible in our hands, but every experiment was unmasked and unpowered** (our Fig. 1).
   * Creatine increased lung metastatic burden in all 10 unflagged wild-type comparisons, drawn from 9 independent experiments: pooled geometric-mean ratio (GMR) 3.03 (95% CI 2.58–3.57; I² = 47%).
   * This held with both gavage and a 5% diet, and came with shorter survival (HR 2.9 in Fig 1c and 2.3 in Fig 1l).
   * The conventions document confirms that allocation was not masked, group sizes were not calculated, and sex was not analysed. A masked replication is therefore the first deliverable of any slot.
2. **Platelets carry the effect, and MK creatine uptake is required** (our Fig. 5).
   * Platelet counts did not change, but reactivity did (ADP +36%, collagen +20%, thrombin +124%; Fig 2b).
   * Human day-7 platelets transferred the phenotype into mice (GMR 2.76, 1.60–4.77; Fig 7g).
   * MK-specific *Slc6a8* deletion abolished the metastasis increase (Fig 3i) and the transcript programme (Fig 3f), and blunted the rise in MK creatine (Fig 3c).
   * The effect is therefore host-MK, not tumour: tumour *Slc6a8* knockdown left the creatine effect intact (interaction p = 0.68; Fig 1f).
3. **Creatine switches on a selective MK "platelet-priming" programme, and GP6 leads it** (our Fig. 2).
   * All 11 panel transcripts rose in 6/6 experiments.
   * *Gp6* rose most (mean log2FC 2.81, range 2.8–42×), then *Adra2a*, *Pitpnb* and *P2ry12*.
   * Core MK lineage and maturation genes (*Nfe2*, *Gata1*, *Itgb3*, *Tubb1*) did not move (Supp 3c).
4. **Humans reproduce the GPVI and α2A arms of that programme; P2Y12- and COX-1-dependent responses do not change** (our Figs. 3 and 6).
   * Serum creatine rose 3.4-fold, similar to the mouse models (2.7–2.9×).
   * Platelet function did not change at day 3, when serum creatine was already at plateau. Changes appeared at days 7–14, a lag consistent with MK programming plus platelet turnover.
   * Collagen and epinephrine responses rose; ADP did not, and arachidonic acid showed only a trend.
   * GP6 protein rose in 4/4 volunteers. The tabulated P2RY12 rise is not visible in the representative blots.
   * *RAB4A*, one of the claimed STAT5B ChIP targets, *fell* in 4/4 volunteers.
5. **The CKB → STAT5B-S127 link is not decision-grade** (our Fig. 4). See Section 3.5. A slot spent on STAT5B would be spent on a hypothesis whose key data are either non-significant after multiple-testing correction or on integrity hold.

---

## 3. Evidence base (re-analysed from animal-, subject- and replicate-level source data)

**How we checked the numbers.** We recomputed every two-group test in the package (62 endpoints) and the post-hoc/ANOVA outputs for the factorial, time-course and human panels. Every reported P-value we recomputed reproduces from the tabulated values (checks listed in Appendix A). The arithmetic is sound; the issues below are about design, normalisation and provenance. Methods are in Appendix A, and every number is in `analysis/*.csv`.

### 3.1 The phenotype (Figs 1, S1; our Fig. 1)

**Metastatic burden.**

| Comparison | Creatine vs control, GMR (95% CI) | n |
|----------------|----------------|----|
| Fig 1b | 3.30 (1.97–5.52) | 6/6 |
| Fig 1k | 2.25 (1.82–2.78) | 6/6 |
| Fig 1f, sh-scrambled tumours | 4.07 (1.98–8.41) | 6/6 |
| Fig 1f, tumour sh-*Slc6a8* | 3.16 (2.43–4.09) | 6/6 |
| Supp 1e | 2.14 (1.40–3.26) | 6/6 |
| Supp 1f | 2.86 (1.44–5.68) | 4/4 |
| Supp 1g | 4.26 (2.53–7.16) | 10/10 |
| Supp 1k | 3.52 (2.06–6.03) | 10/10 |
| Supp 1i, 5% creatine diet | 3.53 (2.11–5.90) | 4/4 |
| Fig 3i, Pf4-Cre;*Slc6a8*+/+ | 3.56 (1.81–7.00) | 4/4 |
| **Random-effects pool (10 comparisons)** | **3.03 (2.58–3.57)** | |

**Other endpoints moved the same way:**
* Foci: 1.5–3.0×.
* Lung weight: 1.2–1.7×.
* PET SUV-BW: 2.1× (Fig 1a) and 1.7× (Fig 1j).
* Survival: Fig 1c median 21 → 18 days, HR 2.93 (1.04–8.23), n = 10/10. Fig 1l median 16 → 14 days, HR 2.28 (1.16–4.46), n = 20/18.

**Early lung retention (Fig 1h).** Arrest at 15 minutes was equal (ratio 0.86, p = 0.31). From then on, retention diverged: the creatine/vehicle ratio was 1.51 at 6 h, 1.79 at 12 h and 2.76 at 24 h. At 24 h, 6.5% of the 15-minute signal remained with creatine vs 2.0% with vehicle. The effect therefore acts in the **seeding-survival window**, which sets when any blockade must provide coverage.

**No nonspecific explanations.** Body weight, food and water intake (Supp 1a–c), leukocyte and red-cell counts (Supp 3a), and platelet count/indices (Fig 2a, Supp 4b, 7a, 7b) were all unchanged.

**Exposure and dose.**
* Serum creatine rose 2.71× with gavage (Supp 1d), 2.91× with diet (Supp 1h), and 2.70× in Pf4-Cre controls (Fig 3b).
* Gavage delivered 17 mg three times a week, about 0.35 g/kg/day. This matches the volunteers' 20 g/day per kg (0.35 g/kg/day at 57.6 kg).
* Habitual human maintenance dosing (3–5 g/day) is 4–7× lower and **has not been tested**.

**Caveats.**
* All allocation was unmasked, with no power calculation.
* Tumour line, route and timing are not annotated for most panels; only Fig 1f says "melanoma".
* Fig 1i is unit-of-n inflated (8 fields per group, df = 14).
* Effect sizes from small unmasked studies tend to be inflated, so CRE-MK-02 is powered for a 2× effect rather than 3×.

![Our Fig. 1: creatine effect on lung metastatic burden across all CRE-MK-01 comparisons (recomputed; flagged experiments in grey)](figures/fig1_forest_metastatic_burden.png)

### 3.2 Platelets carry the effect; MK creatine uptake gates it (Figs 2–4, S2, S4; our Fig. 5)

**Platelet function in mice.**
* Aggregation: ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56% (n = 3 per group, p ≤ 0.001; Fig 2b).
* α-granules ×1.9 (Fig 2c) and lung PKH⁺ platelet area ×2.4 (Fig 2j). Both are counted per field, not per animal, so their p-values are inflated.
* TEG maximum amplitude +36% (Fig 2d), p = 0.049. This is fragile: it is driven by one low vehicle sample, and Mann–Whitney gives p = 0.095.
* Creatine at 0.2 mM, close to the supplemented serum level, raised GP6 and P2RY12 protein in MKs in vitro but **not in mature platelets** (Fig 2i). The drug acts on MKs.

**Platelet transfer.**
* Human day-7 vs day-0 platelets transferred into mice: burden 4.65% → 12.66% (GMR 2.76), foci 21.8 → 39.4, n = 5/5 (Fig 7g). This is unmasked, and donor identity and recipient strain are not documented.
* The mouse donor-platelet transfer ± aspirin experiment (Supp 2d) is on integrity hold (Section 3.6).

**MK-specific *Slc6a8* deletion (Pf4-Cre; Figs 3, S4).**
* Serum creatine rose equally in both genotypes (2.70× vs 2.44×).
* MK intracellular creatine rose 5.3× in wild-type mice (Student p = 0.049; Welch p = 0.11) and only 1.5× in knockouts (p = 0.20).
* Metastasis: wild-type 2.36% → 7.91% vs knockout 3.39% → 2.88%. The genotype × creatine interaction was p = 0.0003 for burden (log scale p = 0.0009), p = 0.004 for foci and p = 0.0002 for lung weight. The creatine effect within knockouts was GMR 0.79 (0.41–1.54).
* The transcript programme was abolished: the median fraction of log-induction retained was 0.01, and 7/11 genes had interaction p < 0.05. *P2ry12*, *Gp6*, *Fcgr2a* and *Adra2a* kept 27–68% of their induction.
* The α-granule increase was abolished (Supp 4c; per-field counts).
* Liposomal creatine, which bypasses the transporter, **restored** the programme in knockout MKs: the median log2FC was about 1.4 vs ≈ 0 with free creatine (Supp 4e). Intracellular creatine is sufficient, and uptake is the gate.
* Tumour *Slc6a8* knockdown did not change the creatine effect (Fig 1f; interaction p = 0.68 for burden, 0.95 for foci). However, the knockdown is only partly validated: the sh-*Slc6a8* blot shows about a 30% band reduction by our approximate densitometry, and the 82% mRNA knockdown is labelled *si*RNA (Supp 2a).

**Wrinkles that must be resolved (Fig 3d, S4a).**
* In knockouts, creatine **lowered** aggregation below knockout vehicle (ADP 54 → 31%, collagen 61 → 51%, thrombin 45 → 35%). Transporter loss should give no effect, not an inverse one.
* Baseline wild-type ADP aggregation was 63% in Fig 3d but 42% in Fig 2b. That is a large between-batch shift, and raw traces are needed.
* The representative knockout-validation blot shows only about a 40–45% drop in SLC6A8 band intensity in knockout MKs.

![Our Fig. 5: the MK-Slc6a8 knockout: metastasis, MK creatine and aggregation](figures/fig5_MK_SLC6A8_gate.png)

### 3.3 The MK programme (Figs 2f, 3f, 4, 6, S3–S5; our Fig. 2)

**Creatine induction.** Log2 fold changes were recomputed from tabulated ΔCt (treated mean minus control mean) in six independent experiments:
* in vivo: Figs 2f, 3f, 6g
* in vitro: Figs 4h, 4j
* Fig 6a: in vivo, inferred from the oral STAT5-IN-1 dosing

Induction by gene:

| Gene | Mean induction | Range | Experiments with Welch p < 0.05 |
|--------|--------|--------|------------|
| *Gp6* | 7.0× | 2.8–42× | 6/6 |
| *Adra2a* | 4.3× | 2.2–18× | 5/6 |
| *Pitpnb* | 3.9× | 2.2–7.4× | 6/6 |
| *P2ry12* | 3.7× | 2.0–5.2× | 5/6 |

*Fcgr2a*, *F2r*, *Rab4a*, *Runx1*, *Itga2b*, *Gpiba* and *Rab27b* rose 2.7–3.6× on average.

**Selectivity and supporting observations.**
* MK maturation markers were flat: *Nfe2*, *Gata1*, *Itgb3* and *Tubb1* did not change (Supp 3c).
* *Ckb* mRNA rose 1.8× (Fig 4e).
* *Gatm* and *Gamt* were unchanged (Supp 5a).
* Exogenous phosphocreatine did not induce the programme; it lowered it (Fig 4h).

**Perturbations: fraction of creatine log-induction retained** (1 = no block, 0 = full block; median across 11 genes; `fraction_induction_retained.csv`):

| Perturbation | Median retained | Notes |
|------------|--------|----------------------------|
| *Slc6a8* knockout | 0.01 | Full block |
| STAT5-IN-1 | 0.11 | The inhibitor alone also lowered basal *Rab4a* (−2.25 log2), *Adra2a* (−1.82) and *Gp6* (−1.37) |
| *Stat5b* MK knockout | 0.18 | *P2ry12*, *Gp6*, *Gpiba*, *F2r* and *Adra2a* kept 33–49% of their induction |
| si*Ckb* | 0.41 | 6/11 genes still ≥1.5× |

**Unit-of-n caveat.** Each MK qPCR group has three values. The conventions state that "each sample was run in triplicate", so the unit of n for these panels (mouse or technical well) must be confirmed. Treated replicates were also normalised to the *positionally paired* control replicate (e.g. `G6 = G5 − G4`), which is an arbitrary pairing. We therefore used ΔCt means throughout.

![Our Fig. 2: transcript programme across mouse experiments, perturbations and human CD41⁺ cells](figures/fig2_transcript_heatmap.png)

### 3.4 Human cohort: what translates and what does not (Figs 7, S8; our Figs. 3, 6)

**Design.**
* 11 healthy Asian volunteers, aged 20–25, BMI 20.9 ± 3.6, 6 female and 5 male.
* 20 g/day creatine for 14 days.
* Single-arm and unmasked, with no placebo.
* 4 volunteers were randomly selected for the CD41⁺ qPCR and platelet blots.
* The reported statistics are ordinary (between-group) ANOVA/Dunnett on fold-changes with a constant day-0 column. We re-analysed within-subject log fold-changes instead (Wilcoxon signed-rank; BH-FDR across all 36 agonist × metric × day tests).

**Exposure.** Serum creatine rose from 45.3 ± 13.1 µM to 152.9–159.2 µM (median fold 3.5–3.6; minimum 2.1×; all 11 rose by day 3). Platelet count, PCT, MPV and PDW did not change (Supp 8b).

**Function (maximum aggregation, geometric-mean fold vs own day 0).**

| Agonist (pathway) | Day 3 | Day 7 | Day 14 |
|------------|--------|------------|----------------|
| Collagen (GPVI) | 1.01 (6/11 ↑) | 1.25 (8/11) | **2.51 (9/11), p = 0.005, q = 0.029** |
| Epinephrine (α2A) | 0.86 (5/11) | **1.33 (10/11), p = 0.005, q = 0.029** | **1.63 (10/11), p = 0.002, q = 0.018** |
| ADP (P2Y12) | 0.77 (5/11) | 1.03 (6/11) | 1.07 (6/11), p = 0.77 |
| Arachidonic acid (COX-1) | 0.86 (5/11) | 1.04 (7/11) | 1.32 (9/11), p = 0.054, q = 0.15 |

Other epinephrine metrics were stronger still: average aggregation at day 14 rose in 11/11 (q = 0.012), and adhesion at days 7 and 14 rose in 11/11 (q = 0.012). For collagen average aggregation at day 14 (9/11, q = 0.031), the reported ANOVA was **non-significant** (p = 0.12) because of one 40× value. The log-scale re-analysis is robust to that value.

**CD41⁺ transcripts (n = 4, fold vs own day 0).**
* *ADRA2A*: 20.5× at day 7 (4/4; p = 0.001) and 4.0× at day 14 (4/4).
* *GP6*: 6.9× at day 7 (4/4) and 3.7× at day 14 (4/4).
* *P2RY12*: 3.0× at day 7 (3/4) and 4.9× at day 14 (3/4).
* ***RAB4A*: 0.36× at day 14 (0/4 up; p = 0.002)**, the opposite of the mouse direction.
* Volunteer 2 barely responded for most genes.
* Technical-triplicate ranges reach 3.7 Ct.
* Volunteer 4 *PITPNB* ΔCt values are +26 to +28 (raw-Ct-like), so the reported *PITPNB*-V4 and *RAB27B*-V4 fold-changes cannot be reproduced from the tabulated ΔCt.

**Platelet protein (immunoblot densitometry, not transcript; n = 4).**
* GP6/β-actin rose in 4/4 at day 7 (2.0×) and day 14 (2.6×; paired log p = 0.021).
* P2RY12/β-actin is tabulated as 4/4 up (1.7× at day 14, p = 0.044).
* Our approximate densitometry of the representative Supp 8d images reproduces the GP6 rise (about 1.4–2.1× at day 14, 4/4). It does **not** reproduce a P2RY12 rise (about 1.0–1.2×). These are composite JPEG panels, so this is a plausibility check only, not a measurement.

**Reading.** Creatine changes human platelets selectively (GPVI and α2A pathways, GP6 protein), with a lag that fits new MK-derived platelets, and human creatine-exposed platelets are pro-metastatic in mice. Neither a P2Y12 nor a COX-1 rationale is supported.

![Our Fig. 3: within-subject change in maximum aggregation by agonist](figures/fig3_human_platelet_function.png)

![Our Fig. 6: human platelet GP6 and P2RY12 protein (tabulated vs approximate densitometry of representative blots)](figures/fig6_human_platelet_protein.png)

### 3.5 The CKB → STAT5B link (Figs 4–6, S5–S6; our Fig. 4)

**Phosphoproteomics (n = 3 vs 3; 5,812 phosphopeptides from 2,033 genes; no site localisation in the export).**
* No peptide passes FDR: the minimum reported q is 0.167, and BH gives 0.25.
* Using the conventions' screen (p < 0.05 and fold change ≥ 1.2 or ≤ 0.83), 209 peptides qualify. That is about the same as the ~216 expected by chance.
* 1,702 peptides (29%) share p = 0.42265 exactly. This is the Welch t = 1, df = 2 signature of a value quantified in one replicate of one group with the rest imputed. About 300 more cluster at p ≈ 0.18 (the two-of-three pattern).
* The header says Student's t, but that signature is Welch's.
* The Stat5b phosphopeptide ranks 17th (p = 0.0012, q = 0.25, LFC +5.7, a presence/absence-type value). A second Stat5b peptide is unchanged (q = 0.49).

**Canonical activation.** pSTAT5A/B (Y694/699) is **undetectable** in MKs with or without creatine, while the Jurkat + IL-2 positive control is positive (Supp 6a).

**S127 phosphorylation.**
* The readout is a pan-phospho antibody on over-expressed FLAG-STAT5B, in three blots per panel.
* Creatine raised wild-type signal 1.39× (p = 0.009; Fig 5e) and 1.28× (p = 0.087; Fig 5f).
* The authors compared constructs only within each treatment. The key test is the wild-type vs S127A × creatine interaction. We computed it: p = 0.024 in Fig 5e and p = 0.043 in Fig 5f (log scale 0.036 and 0.052).
* One replicate (5e, duplicate 2, vehicle pan-phos) is a saturated smear.
* The FLAG band is at about 75 kDa in some replicates and about 95–100 kDa in others.
* The in vitro CKB kinase experiment is a single blot with no kinase-dead or S127A control (Supp 6d).

**Pharmacology and genetics.**
* STAT5-IN-1 inhibits STAT5A *and* STAT5B (per the conventions), is given systemically, and lowers basal MK expression on its own.
* The MK-*Stat5b* knockout blocks only part of the induction (Section 3.3). It has no knockout-vehicle group and **no metastasis readout** (Figs 6d–g, S7b).

**ChIP (Fig 5j, S6i).** Creatine increased occupancy at −0.2 kb and −1 kb of *P2ry12*, *Gp6* and *Rab4a*, with exon regions unchanged. However:
* % input values of up to ~50%, with exon (negative-region) background of 2–14% in vehicle, are unusually high.
* No IgG control is tabulated.
* The *RAB4A* direction is reversed in humans.

**Metastasis rescue (Fig 6b).** STAT5-IN-1 abolished the creatine increase (interaction p = 7×10⁻⁶; log scale 0.0004). But three animals per control arm carry values identical to Supp 2d (Section 3.6).

![Our Fig. 4: phosphoproteomics p-value distribution and volcano](figures/fig4_phosphoproteomics_QC.png)

### 3.6 Data-integrity and quality findings that affect decisions

| # | Finding | Where | Consequence |
|----|------------------------------------|--------|----------------|
| 1 | **Identical animal-level data appear in two different experiments.** Three of five "Vehicle" and three of five "Creatine" mice in Fig 6b have burden *and* foci values identical, in the same order, to animals 4–6 of Supp 2d's "vehicle-donor" and "creatine-donor" platelet recipients. This points to either re-used animals or a copy-paste error. Vehicle burdens are 3.29136, 3.733544, 2.886353 and foci 37/25/33; creatine burdens are 11.13465, 13.22011, 14.12619 and foci 53/62/47. | Fig 6b ↔ Supp 2d | Both the STAT5-inhibitor rescue and the aspirin platelet-transfer result are on hold until raw lung images and animal IDs are audited. Neither is used to justify CRE-MK-02. |
| 2 | Volunteer 4 *PITPNB* "ΔCt" is +26 to +28 (raw Ct-like). The *PITPNB*-V4 and *RAB27B*-V4 fold-changes don't reproduce from tabulated ΔCt. | Fig 7d | Excluded from our human summaries; request raw Ct |
| 3 | In *Slc6a8* knockouts, creatine lowers aggregation below knockout vehicle. Wild-type baselines differ by 20–36 percentage points between experiments (ADP 63% vs 42%; thrombin 61% vs 25%). | Fig 3d vs 2b | Request raw traces; re-measure in the CRE-MK-02 PD cohort |
| 4 | No FDR-significant phosphosites; 29–34% presence/absence artefacts; no site localisation | Phospho export | The phosphoproteomics cannot nominate STAT5B |
| 5 | Per-field n (8 fields per group) used as independent replicates | Fig 1i, 2c, 2j, S4c | p-values overstated; per-animal means required |
| 6 | MK qPCR unit of n not stated; treated replicates normalised to positionally paired controls | All MK qPCR panels | Re-analysed as ΔCt means; confirm biological n |
| 7 | Human analyses: between-group ANOVA on within-subject fold-changes; BMI compared with an unpaired test | Fig 7c, 7e, S8a | Re-analysed within-subject |
| 8 | Knockdown/knockout validation is incomplete. SLC6A8 band intensity falls about 40–45% in MK-KO (S4a). Tumour sh-*Slc6a8* falls about 30% on the blot, while the qPCR is labelled *si*RNA (S2a). | S4a, S2a | Deletion/knockdown efficiency must be profiled before reuse |
| 9 | Labelling: "Creatinine" (Fig 4d, a creatine assay); "ADAR2A" (ADRA2A); a Tukey row "WT-creatine vs si-Slc6a8-creatine" in an sh-RNA experiment (Fig 1f); tumour models largely unannotated | Various | Annotate before reuse |
| 10 | Allocation not masked; no sample-size calculation; sex not analysed, and sex is confounded with strain/model (male C57BL/6J, female BALB/cJ) | Conventions | Built into the CRE-MK-02 design |

---

## 4. Target selection

### 4.1 Scorecard (CRE-MK-01 evidence only; our Fig. 7)

Each criterion is scored 0–3. Tractability and safety are **not scored** because the package does not evidence them; they are gating assumptions (Section 8).

| Target | C1 In vivo causal evidence on metastasis | C2 MK mechanism (necessity/sufficiency) | C3 Human concordance (our cohort) | C4 Integrity / replication | Σ |
|--------|------------|------------|------------|------------|----|
| MK SLC6A8 | 2: MK-KO abolishes (1 experiment, n = 4) | 3: KO blocks; liposome bypass restores | 1: substrate exposure only | 1: 3d paradox; partial deletion on blot | **7** |
| **Platelet GPVI** | 0: untested | 1: induced 6/6; ChIP target | 3: mRNA 4/4, protein 4/4, collagen 9/11 | 2: replicated | **6** |
| ADRA2A | 0 | 1: induced 6/6 | 3: mRNA 4/4, epinephrine 10–11/11 | 2 | **6** |
| P2Y12 | 0 | 1: induced 6/6; ChIP target | 1: ADP flat; blot rise not evident | 2 | 4 |
| CKB | 0 | 2: siRNA partial; OE sufficient | 0: not measured | 2 | 4 |
| STAT5B | 1: pan-STAT5 drug only, duplicated values | 2: partial; no pY694/699 | 0: not measured; *RAB4A* ↓ | 0 | 3 |
| COX-1 | 1: Supp 2d, duplicated values | 0 | 1: AA trend only | 0 | 2 |

![Our Fig. 7: evidence scorecard](figures/fig7_target_scorecard.png)

### 4.2 Why GPVI is primary even though SLC6A8 scores one point higher

* **Match the experiment to the gap.**
  * SLC6A8's points come from a result we already hold (Fig 3i). What it lacks is human relevance, which an in vivo slot cannot provide. We have no data that human MKs take up creatine through SLC6A8.
  * GPVI already has the human evidence. What it lacks is exactly what an in vivo slot provides: a causal test.
  * Putting an MK-*Slc6a8*-knockout arm inside the GPVI study recovers the SLC6A8 replication at the cost of two arms. The quarter therefore yields a decision on both nodes.
* **Indication value.**
  * In our data, the MK creatine axis is silent without supplemental creatine. *Slc6a8*-knockout vehicle mice (3.39%) did no better than wild-type vehicle mice (2.36%; Fig 3i). The flagged Fig 6b shows the same pattern for STAT5-IN-1 alone, but it is not relied on here. An SLC6A8-directed drug would therefore only counter an exposure that patients can simply stop.
  * It would also, by design, oppose creatine uptake in other tissues; brain creatine rises with supplementation (Fig 4a).
  * GPVI blockade may act with *or* without creatine. The 2×2 design measures that main effect directly, and a positive main effect would widen the indication beyond creatine users.
* **GPVI beats P2Y12 as the effector to test, on our own human data.** The package's blots and ChIP emphasise GP6 and P2RY12 equally. The volunteers separate them: collagen up, ADP flat; GP6 protein rise visible, P2RY12 not.
* **GPVI beats ADRA2A (for now) on breadth of evidence.** Both are human-concordant, and ADRA2A has the stronger human functional signal. But only GPVI also has mouse functional data (collagen aggregation rose in Figs 2b and 3d; epinephrine was never tested in mice), human protein data and promoter-occupancy data. The CRE-MK-02 PD satellite measures epinephrine responses in mice, so ADRA2A is evaluated at no extra cost.
* **GPVI comes with a human pharmacodynamic readout.** Collagen-evoked aggregation rose 2.5× in 9/11 volunteers by day 14, which gives the human follow-up a ready biomarker.

### 4.3 Backups

* **Backup #1, MK SLC6A8.** This is the mechanism anchor, the benchmark arm in CRE-MK-02, and the first pivot if GPVI blockade fails while the knockout still protects. It is also the basis of the non-drug deliverable: guidance on supplemental creatine in patients with cancer, pending the human PD study.
* **Backup #2, ADRA2A.** This is the strongest human functional signal. It has never been probed functionally in mice, so the first step is cheap: do platelets from creatine-treated mice show greater epinephrine potentiation? The package does not evidence systemic on-target effects of α2A blockade either way; that would need specific assessment.

### 4.4 Not advanced this quarter (and what would change that)

See Section 7 for the full matrix.

* **STAT5B** would need all of the following:
  * a clean MK-*Stat5b*-knockout metastasis result (masked; with a knockout-vehicle arm; the line exists);
  * site-localised, FDR-controlled S127 phosphorylation in primary MKs;
  * resolution of the Fig 6b / Supp 2d duplicated values.
* **CKB** would need MK-specific loss-of-function in vivo and kinase-dead controls. Its brain abundance (≥3.6× MK, Fig 4b) remains a concern.
* **P2Y12** would need a placebo-controlled human rise in P2Y12-dependent function.
* **COX-1** would need a clean replication of the aspirin donor-platelet experiment.

---

## 5. The in vivo slot: study CRE-MK-02 (specification)

### 5.1 Question

Is platelet GPVI required for creatine-enhanced metastatic seeding? And what fraction of the creatine effect does it carry, relative to full MK *Slc6a8* deletion?

### 5.2 Design

| Element | Specification |
|--------|------------------------------------|
| Design | Randomised, masked, 2×2 factorial: creatine vs vehicle × GPVI blockade vs isotype, in Pf4-Cre;*Slc6a8*+/+ littermates. Plus two benchmark arms: Pf4-Cre;*Slc6a8*^fl/fl^ (fl/Y in males) with vehicle or creatine, both on isotype. **6 arms.** Optional 7th arm: creatine + aspirin (30 mg/kg/day), as a generic-antiplatelet benchmark and a clean replacement for Supp 2d. |
| Population | Both sexes, 7 female + 7 male per arm; age-matched adults; the Cre/flox colony background. Randomisation is stratified by sex and litter; cages are mixed across arms where welfare allows. |
| Tumour model (indication) | The melanoma model annotated in Fig 1f (C57BL/6-compatible). Confirm from lab records that Figs 1a–c used the same line. Chosen because it captures the seeding window shown in Fig 1h; the 15-minute lung signal there implies intravenous seeding, also to be confirmed. A spontaneous-metastasis model and a second tumour type are in Part B (Section 6.1). |
| Creatine exposure | Creatine monohydrate 42.5 mg/mL × 400 µL (17 mg) by gavage three times a week, as in CRE-MK-01. Starts ≥7 days before tumour challenge (platelet turnover; human effects appeared at day 7) and continues to endpoint. Vehicle is water. **Exposure check:** serum creatine at day −1 should be ≥2.5× vehicle (CRE-MK-01 mice 2.7–2.9×; humans 3.4×). |
| GPVI blockade | A GPVI-blocking reagent qualified in our system before the slot. Acceptance criteria: ≥80% inhibition of GPVI-specific-agonist aggregation ex vivo across the dosing interval; platelet count ≥80% of isotype; no bleeding beyond the pre-set threshold. Given from day −1 to day +7 around tumour challenge, covering seeding plus early colonisation. Isotype control is matched for format and dose. |
| Comparators | Vehicle + isotype (baseline). Creatine + isotype (effect to be blocked). MK-*Slc6a8* knockout + creatine (full-blockade benchmark). Knockout + vehicle (knockout baseline). Aspirin arm optional. |
| n | 14 randomised per arm; ≥12 evaluable. 84 mice in the main cohort (98 with the aspirin arm). PD/safety satellite: 5 per arm, 30–35 mice. |
| **Primary endpoint** | Lung metastatic burden (% lung area), from masked whole-lung histomorphometry on standardised step sections at a fixed day. Log-transformed. The animal is the unit. |
| **Primary contrast** | Creatine + GPVI blockade vs creatine + isotype (GMR, 95% CI) |
| Key secondary | (a) Replication: creatine + isotype vs vehicle + isotype. (b) Creatine × GPVI-blockade interaction, reported as the fraction of the creatine log-effect removed. (c) Knockout benchmark: knockout + creatine vs wild-type + creatine, and the creatine effect within knockouts. (d) Masked macroscopic foci count; lung weight. |
| PD/mechanism readouts (satellite, pre-tumour) | Serum and MK creatine. MK transcript panel (*Gp6*, *Adra2a*, *P2ry12*, *Rab4a*, *Itga2b*) to confirm the programme was switched on. Platelet surface GPVI. Aggregation to a GPVI-specific agonist, collagen, ADP, a PAR4 agonist/thrombin and epinephrine. The epinephrine readout doubles as the first test of backup #2. |
| Seeding readouts (satellite) | Lung retention of labelled tumour cells at 24 h, and platelet–tumour-cell co-localisation, quantified per animal. This mirrors Fig 1h but with masked, per-animal units. |
| Safety | Tail-bleeding time, platelet count, haemoglobin, body weight |
| Pre-specified exclusions | Failed tumour-cell delivery (criterion fixed in the SAP, e.g. the 15-minute lung signal used in Fig 1h) and deaths unrelated to tumour. All exclusions are reported by arm. |
| Analysis | Pre-registered statistical analysis plan. Linear model on log burden with creatine, GPVI-blockade (or genotype) and sex, plus batch. Fields are averaged within animal. Hierarchical testing order: (1) replication → (2) primary contrast → (3) interaction → (4) knockout benchmark. Effect sizes with 95% CIs. Sex is reported as a pre-specified secondary factor; it is not powered. |

### 5.3 Power

Assumptions: σ(log burden) = 0.5 (observed median 0.375, inflated for sex and batch), and a 2× creatine effect (shrunk from the pooled 3.0×). With 12 evaluable per arm:
* **90% power** to replicate a 2× creatine effect;
* **90% power** to detect a 50% reduction (GMR 0.5) in the primary contrast;
* interaction power of 0.74–0.96 for removing 70–100% of a 3× effect, but only 0.38–0.65 if the true effect is 2×. The interaction is therefore a secondary, estimation-focused endpoint.

Calculations are in `analysis/14_power.py`.

### 5.4 Decision rules (pre-specified)

| Outcome | Criterion | Action |
|--------|--------------------|--------------------|
| **STOP: programme** | Creatine + isotype vs vehicle + isotype GMR < 1.5, or its 95% CI includes 1 | The creatine effect is not robust under masking. Stop target work; report to the safety function. The human PD study continues only as a risk assessment. |
| **GO: GPVI** | Replication met, **and** primary-contrast GMR ≤ 0.6 with upper 95% CI < 1.0, **and** GPVI PD inhibition ≥ 80%, **and** no meaningful bleeding/thrombocytopenia | GPVI moves to Part B (spontaneous metastasis, survival, second model) and to the human platelet-transfer ± anti-GPVI bridging study |
| **GO: GPVI (broad)** | The above, plus a GPVI main effect in vehicle arms of similar size (interaction not significant) | Re-frame the indication beyond creatine users; Part B includes no-creatine arms |
| **PIVOT: SLC6A8 / ADRA2A** | Primary-contrast GMR > 0.8 (or < 30% of the creatine effect removed) despite ≥ 80% PD inhibition, **while** the knockout benchmark abolishes the creatine effect | The effect needs MK creatine uptake but not GPVI. The next slot goes to ADRA2A (if the mouse epinephrine readout is primed) and/or SLC6A8 pharmacology and platelet transfer. |
| **Re-examine the MK hypothesis** | Knockout benchmark fails to replicate (knockout + creatine vs wild-type + creatine GMR > 0.7) | Audit the CRE-MK-01 genetics (deletion efficiency, Cre specificity) before any further MK-node work |
| **Inconclusive** | Replication met but PD < 80% | Tool failure. Repeat with a re-qualified tool; do not interpret efficacy. |

### 5.5 Timeline within the quarter

* **Weeks 0–4:** prerequisites (Section 8).
* **Weeks 4–11:** in-life (7 days of pre-exposure, tumour challenge, endpoint at the CRE-MK-01 readout day).
* **Weeks 11–13:** masked read and analysis.
* **Decision at quarter end.**

---

## 6. Subsequent studies (contingent on the slot outcome)

### 6.1 Part B in vivo (next slot, if GO)

* **Models:**
  * (i) Spontaneous metastasis: orthotopic primary tumour, then resection, then metastasis. Run in the female BALB/cJ model listed in the conventions (probably Figs 1j–l; confirm the panel and tumour type from lab records) and in the C57BL/6 melanoma line.
  * (ii) Survival cohort: time to humane endpoint.
* **Schedule:** perioperative GPVI blockade starting before resection (the CTC-release window) and continuing 7–14 days. A seeding-only schedule (day −1 to +3) is a separate arm.
* **Arms:** creatine ± GPVI blockade, and **no-creatine** ± GPVI blockade, to test the broad indication.
* **Endpoints:**
  * Primary: masked distant-metastatic burden.
  * Key secondary: overall survival, with the hazard ratio as the effect size.
  * Also: local recurrence, PD, bleeding.

### 6.2 Mouse platelet-transfer module (replaces the integrity-held Supp 2d)

* **Donors:** wild-type + vehicle, wild-type + creatine, MK-*Slc6a8*-knockout + creatine.
* **Ex vivo treatment of donor platelets:** GPVI-blocking Fab vs control Fab, plus an optional aspirin arm.
* **Recipients:** challenged with tumour cells; masked burden endpoint.
* This isolates the platelet-intrinsic dependence on GPVI and SLC6A8 away from any systemic drug effect.

### 6.3 Human PD study CRE-HV-02 (runs in parallel; no in vivo slot needed)

| Element | Specification |
|--------|------------------------------------|
| Design | Randomised, double-blind, placebo-controlled, parallel groups. Three arms: placebo; 5 g/day × 28 d (habitual maintenance, **never tested**); 20 g/day × 7 d then 5 g/day (the loading regimen used in CRE-MK-01) |
| Population | Healthy adults aged 18–70, both sexes, ≥2 ancestries, stratified at age 50. This extends beyond the 20–25-year-old, single-ancestry CRE-MK-01 cohort toward the ages at which cancer is common. Exclusions: antiplatelet, NSAID or anticoagulant use; creatine use in the prior 8 weeks; renal impairment. |
| n | About 30 per arm. That gives ≥90% power to detect a 1.6× change vs placebo if the SD of log2 change is ≤ 0.7 (CRE-MK-01 GP6/β-actin at day 14: SD 0.63). A blinded internal pilot re-estimates the SD. |
| Primary endpoint | Change in platelet surface GPVI (flow cytometry) from day 0 to day 14, vs placebo |
| Key secondary | GPVI-specific-agonist aggregation (the decisive functional readout) and collagen aggregation. Epinephrine aggregation (ADRA2A track). ADP and arachidonic acid as **negative-control pathways**. Time course at days 3, 7, 14 and 28, plus a day-14 washout to test reversibility. Serum-creatine exposure–response. Platelet RNA panel on leukocyte-depleted platelets (*GP6*, *ADRA2A*, *P2RY12*, *RAB4A*, *PITPNB*). |
| Conduct | Central laboratory blinded to arm and day; fixed draw time; duplicate measurements; fixed reagent lots. The placebo arm is essential because within-subject variability is large: the SD of the ADP log2 change is 0.75–1.3 in CRE-MK-01. |

### 6.4 Human platelet → mouse bridging (needs an in vivo slot after GO)

* **Samples:** day-0 and day-14 platelets from CRE-HV-02 participants (creatine vs placebo arms).
* **Treatment:** each pre-treated with an anti-human GPVI Fab or a control Fab, then transferred into recipient mice challenged with tumour cells.
* **Design controls:** masked; document donor identity, platelet dose, recipient strain and platelet survival (none of which was documented for Fig 7g).
* This is the direct human-relevance test of GPVI blockade.

### 6.5 Backup and resolution work (outside the slot unless triggered)

* **ADRA2A:**
  * first, the mouse epinephrine-potentiation readout (already built into the CRE-MK-02 PD satellite);
  * then α2A blockade in the 2×2 format, if the slot pivots.
* **SLC6A8:**
  * qualify a pharmacological blocker in our system (MK creatine uptake, plus exposure that spares other tissues);
  * test human CD34⁺-derived MK creatine uptake ± SLC6A8 blockade, which provides the missing human evidence for this node;
  * profile deletion efficiency and Cre specificity in the existing colony.
* **STAT5B resolution:**
  * a MK-*Stat5b*-knockout metastasis run (existing line; masked; with a knockout-vehicle arm);
  * targeted, site-localised phosphoproteomics of primary MKs with FDR control and documented missing-value handling;
  * the Fig 6b / Supp 2d audit.

### 6.6 Risk deliverable (independent of target choice)

* A cancer-survivor cohort in the tumour types we model (melanoma is the only one annotated in the package; others to be confirmed) to record creatine-supplement use, with platelet GPVI and reactivity measured.
* A proposal for outcome linkage if CRE-HV-02 confirms a PD effect at maintenance doses.

### 6.7 Indication hypotheses (for planning only; our data cover mouse lung-metastasis models and healthy volunteers)

* **GPVI, if GO.** Perioperative prevention of haematogenous metastatic seeding in resectable solid tumours with lung-tropic spread. Enrich with a platelet biomarker (surface GPVI or GPVI-agonist reactivity, the CRE-HV-02 readouts) and/or documented creatine exposure.
* **GPVI, if GO (broad).** Drop the creatine-exposure restriction.
* **SLC6A8 track.** This is not a drug indication. It would support patient guidance on supplemental creatine during active treatment or surveillance, conditional on CRE-HV-02 showing PD effects at maintenance doses.

---

## 7. What would elevate one choice over another

| Candidate | Single most informative next datum | Elevates if… | Demotes if… |
|----|------------|--------------------|----------------|
| **GPVI** | CRE-MK-02 primary contrast | GMR ≤ 0.6 with PD ≥ 80%. Human GPVI density and GPVI-agonist aggregation rise vs placebo (CRE-HV-02). Anti-GPVI removes the pro-metastatic activity of human creatine platelets (6.4). | No attenuation despite PD ≥ 80%. No human rise vs placebo at maintenance dose. |
| **SLC6A8** | CRE-MK-02 knockout benchmark + platelet-transfer module | The knockout replicates masked. Knockout-donor platelets lose pro-metastatic activity. Human MK creatine uptake is SLC6A8-dependent. A blocker reproduces the knockout at tissue-sparing exposure. | The knockout fails to replicate, or the deletion is incomplete and effects are not attributable. |
| **ADRA2A** | Mouse epinephrine-potentiation readout (CRE-MK-02 satellite) | Primed in mice, **and** the epinephrine signal holds vs placebo in CRE-HV-02, **and** α2A blockade attenuates in the 2×2 | Not primed in mice, or the human signal disappears with placebo control |
| **STAT5B** | MK-*Stat5b*-knockout metastasis (masked) | The knockout protects; site-localised S127 phosphorylation reaches FDR < 0.05 in primary MKs; the Fig 6b audit is clean | The knockout does not protect, or the audit confirms data re-use |
| **CKB** | MK-specific *Ckb* loss in vivo | Protection with kinase-dead controls confirming a non-metabolic role | Metabolic-only effect, or no protection |
| **P2Y12** | CRE-HV-02 ADP/P2Y12 readouts | P2Y12-dependent function rises vs placebo and P2Y12 blockade attenuates in mice | ADP response stays flat (as in CRE-MK-01) |

---

## 8. Pre-slot gating items (weeks 0–4) and risks

**Gating items.**
1. **Integrity audit** of Fig 6b / Supp 2d (animal IDs, raw lung images, histology files). Raw Ct for Fig 7d V4. Aggregation traces for Figs 2b/3d.
2. **GPVI tool qualification** in our system against the acceptance criteria in 5.2. Confirm, by a tissue-expression check, the working assumption of platelet/MK restriction, which the package does not evidence.
3. **Colony:** enough Pf4-Cre;*Slc6a8*^fl/fl^ and +/+ littermates of both sexes. Confirm deletion efficiency in MKs and check recombination in platelets and the main leukocyte subsets.
4. **Annotations:** tumour line, route, inoculum and readout day for the Fig 1/S1 models; the creatine start day relative to tumour challenge.
5. **SAP registration,** masking plan (coded dosing solutions; masked histology).

**Risks and mitigations.**
* *The creatine effect shrinks under masking.* CRE-MK-02 is powered for a 2× effect and has a STOP rule.
* *GPVI reagent causes platelet depletion.* Platelet count is an acceptance criterion and a model covariate, and the design allows a Fab-format fallback.
* *No GPVI reagent passes qualification by week 4.* The slot is not lost. It runs the backup #1 package instead: a masked MK-*Slc6a8* replication (2×2, both sexes) plus the platelet-transfer module (6.2), with epinephrine/collagen PD readouts. GPVI moves to the following slot.
* *Knockout arm breeding shortfall.* Run the knockout arms in one sex first and state the limitation. The GPVI 2×2 is unaffected.
* *Floor effect:* anti-GPVI could lower vehicle-arm burden, compressing the interaction. The primary endpoint is the simple contrast, so the interaction is estimation only.
* *Human variability.* Placebo control, a central masked lab and an internal pilot re-estimate of the SD.

---

## Appendix A. How the numbers were derived

All computations used the source workbook values. Scripts are in `analysis/` (Python: pandas, SciPy, statsmodels, lifelines).

* **Verification.** Student's t, Welch's t, Mann–Whitney (exact), and log-scale t for all 62 two-group endpoints (`two_group_recomputed.csv`). Tukey/Dunnett re-runs for the factorial, time-course and human panels (`11_verify_anova.py`, `15_verify_tukey.py`). All reported P-values reproduce.
* **Effect sizes.** Geometric-mean ratio (GMR) = exp(mean log treated − mean log control), with Welch 95% CI on the log scale. Random-effects pooling used DerSimonian–Laird over the 10 unflagged wild-type comparisons (`metastatic_burden_forest.csv`).
* **Factorial interactions** (Figs 1f, 3d, 3i, 6b, S4c, 5e/5f wild-type vs mutant): two-way OLS ANOVA, type II, on raw and log scales (`factorial_interactions.csv`).
* **qPCR.** The ΔCt convention was read from the sheets (2^ΔCt = relative expression). log2FC = mean ΔCt(treated) − mean ΔCt(control), with a Welch t-test on ΔCt (`qpcr_contrasts.csv`). 2×2 interactions used OLS on ΔCt (`qpcr_interactions.csv`). Fraction of induction retained = log2FC under perturbation ÷ log2FC without it (`fraction_induction_retained.csv`).
* **Human aggregation.** Within-subject log2 fold-change vs own day 0; Wilcoxon signed-rank and one-sample t; BH-FDR over 36 tests (`human_aggregation_reanalysis.csv`).
* **Human CD41⁺ qPCR.** Technical triplicates averaged per volunteer and day; log2FC vs own day 0; V4 *PITPNB* excluded (`human_cd41_qpcr_*.csv`).
* **Human protein.** Paired log-scale tests and repeated-measures ANOVA on the Fig 7e table. Approximate lane densitometry of the published JPEG panels (Supp 8d; also S4a, S2a, Fig 4b): background-subtracted, column-integrated band intensity ÷ β-actin (`densit*.py`). JPEG panels may be saturated and are not raw images, so these values are plausibility checks only.
* **Phosphoproteomics.** BH recomputation and Storey π0 (0.67–0.77). The degenerate p-value 0.42265 equals the two-sided p for t = 1, df = 2, reproducible as Welch for (x, 0, 0) vs (0, 0, 0). Nominal-hit expectation = 5% × peptides meeting the fold-change screen (`phospho_with_BH.csv`).
* **Survival.** Log-rank and Cox proportional hazards on the tabulated death days (all events) (`09_survival.py`).
* **Power.** Non-central t on the log scale (`14_power.py`).

## Appendix B. Panel-by-panel evidence index

| Panel | What it shows (recomputed) | Weight in this proposal |
|--------|----------------------------|------------|
| 1a/1b/1c | Lung weight 1.43×, SUV 2.14×, burden GMR 3.30, foci 1.92×; survival HR 2.93 (n = 10/10) | Phenotype |
| 1f | Tumour sh-*Slc6a8* does not alter the creatine effect (interaction p = 0.68); knockdown partly validated | Host, not tumour |
| 1h | Early retention ratio 0.86 → 1.51 → 1.79 → 2.76 (15 min → 24 h) | Seeding window → dosing window |
| 1i | GFP⁺ cells/field 2.2× (field-level n) | Supportive only |
| 1j/1k/1l | Lung weight 1.63×, SUV 1.68×, burden GMR 2.25, foci 1.65×; HR 2.28 (n = 20/18) | Phenotype, second model |
| 2a, S3a, S4b, S7a/b | Counts/indices unchanged | Qualitative platelet change |
| 2b, 2c, 2d, 2j | Aggregation ↑ (all agonists); α-granules 1.9×; TEG-MA +36% (fragile); lung platelet area 2.4× | Platelet priming in mice |
| 2e, 2g, 2i | Blots: MK GP6/P2RY12 ↑ in vivo and at 0.2–2 mM in vitro; no change when mature platelets are exposed in vitro (2i); mouse platelet blots (2e) not quantified, near-saturated | MK-level action |
| 2f, 3f, 4h, 4j, 6a, 6g | 11-gene programme induced in 6/6 experiments; *Gp6* largest | Effector ranking |
| 3b/3c/3d/3g/3i, S4a/S4c/S4e | MK-*Slc6a8* knockout: equal serum exposure, MK creatine blunted, aggregation/programme/metastasis increments abolished; liposome rescue; 3d paradox; partial band loss | Backup #1 evidence |
| 4a–4g, 4i–4l, S5a–c | MK creatine 3.0–5.3×, PCr 3.9–5.4×; CKB ↑; si*Ckb* partial; CKB-OE sufficient without changing creatine/PCr; brain CKB ≥ 3.6× MK | CKB not advanced |
| 5e/5f, 5g–5i, S6d–h | Pan-phospho STAT5B-FLAG; WT × S127A interaction p = 0.024 / 0.043; single qualitative blots; nuclear STAT5B ↑ (S6h) | STAT5B not decision-grade |
| 5j, S6i | ChIP occupancy ↑ at −0.2/−1 kb (*P2ry12*, *Gp6*, *Rab4a*); high % input | Supports GP6 as a programme target |
| 6b | STAT5-IN-1 abolishes the metastasis increment; values for 3 animals per arm duplicated in S2d | On hold |
| 6d/6e/6f/6g, S7b | *Stat5b* MK deletion complete; MK creatine normal; partial block of the programme; no metastasis data | STAT5B not advanced |
| 7b | Serum creatine 45 → 153–159 µM (all 11 ↑) | Exposure bridge |
| 7c | Collagen and epinephrine ↑ at day 7–14; ADP flat; arachidonic acid trend | GPVI / α2A over P2Y12 / COX-1 |
| 7d | CD41⁺ mRNA: *ADRA2A*, *GP6*, *P2RY12* ↑; *RAB4A* ↓; V4 *PITPNB* invalid | Human programme partly conserved |
| 7e, S8d | GP6 protein ↑ 4/4; P2RY12 tabulated ↑ but not evident in representative blots | GPVI |
| 7g | Human day-7 platelets → mouse burden GMR 2.76 | Human platelets carry the effect |
| S1a–d, S1h | Body weight, food, water unchanged; serum creatine 2.7–2.9× | Exposure, no confounding |
| S1e–g, S1k, S1i | Additional models and the diet route: GMR 2.14–4.26 | Reproducibility |
| S2a, S2d | sh-*Slc6a8* validation incomplete; platelet transfer ± aspirin duplicates 6b values | On hold |
| S3c | MK maturation genes largely flat (*Myl9* ↓, *Casp12* ↑, *Hsd3b1* ↑) | Selective programme |
| S6a | No pSTAT5 Y694/699 in MKs (Jurkat + IL-2 positive) | Canonical STAT5 absent |
| S8a–c | BMI stable (unpaired test used); human platelet indices unchanged; CD41⁺ enrichment (monocytes about 0.06× *CD41*) | Cohort QC |
| Phospho export | 0 FDR hits; 29–34% presence/absence artefacts; Stat5b q = 0.25 | STAT5B not nominated |

## Appendix C. Files delivered

* `CRE-MK-01_validation_proposal.md` / `.docx` / `.html`: this proposal.
* `figures/fig1–fig7*.png`: forest plot, transcript heatmap, human function, phosphoproteomics QC, SLC6A8 gate, human protein, scorecard.
* `analysis/*.py`: all re-analysis scripts. Run them from a working directory containing both source `.xlsx` files and an `analysis/` folder.
* `analysis/*.csv`: every recomputed statistic cited above.
