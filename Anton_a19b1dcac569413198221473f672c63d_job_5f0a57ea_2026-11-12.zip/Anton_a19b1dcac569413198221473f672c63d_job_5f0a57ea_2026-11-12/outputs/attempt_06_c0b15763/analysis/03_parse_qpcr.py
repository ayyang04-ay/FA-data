import openpyxl, re, numpy as np, pandas as pd, json
wb = openpyxl.load_workbook('CRE-MK-01_source_data.xlsx', data_only=True)
sheets = ['Fig. 2f','Fig. 3f','Fig. 4e','Fig. 4h','Fig. 4j','Fig. 4l','Fig.6a','Fig. 6g',
          'Supplementary Fig  2a','Supplementary Fig  3c','Supplementary Fig  4e','Supplementary Fig  5a','Supplementary Fig  8c']
LABELS = {'ΔCT1','ΔCT2','ΔCT3','ΔCT4','After normalization','2^ΔCT1','(ΔCT2-ΔCT1)','2^(ΔCT2-ΔCT1)'}
records=[]
for sn in sheets:
    ws=wb[sn]
    maxr=ws.max_row; maxc=ws.max_column
    grid={(c.row,c.column):c.value for row in ws.iter_rows() for c in row if c.value is not None}
    for (r,c),v in grid.items():
        if isinstance(v,str) and re.fullmatch(r'ΔCT(\d)',v.strip()):
            k=int(re.fullmatch(r'ΔCT(\d)',v.strip()).group(1))
            vals=[grid.get((r,c+i)) for i in (1,2,3)]
            if not all(isinstance(x,(int,float)) for x in vals): continue
            # gene: look in same row and up to 2 rows above, columns 1..c-1, for a string not in labels
            gene=None
            for rr in (r, r-1, r-2):
                for cc in range(1,c):
                    g=grid.get((rr,cc))
                    if isinstance(g,str) and g.strip() not in LABELS and not g.startswith('Note') and not g.startswith('Graphs') and 'Relative' not in g and 'CT' not in g and 'normal' not in g:
                        gene=g.strip(); break
                if gene: break
            records.append(dict(sheet=sn,gene=gene,group=k,row=r,col=c,v1=vals[0],v2=vals[1],v3=vals[2]))
df=pd.DataFrame(records)
# de-duplicate repeated ΔCT1 copies (same gene, same group, same values)
df=df.drop_duplicates(subset=['sheet','gene','group','v1','v2','v3'])
print(df.groupby('sheet').gene.unique())
df.to_csv('analysis/qpcr_parsed.csv',index=False)
print(df.head(30).to_string())
print(len(df))
