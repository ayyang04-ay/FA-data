import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
A=pd.read_csv('analysis/human_aggregation_long.csv')
print('Dunnett (ordinary, as reported) vs day0:')
for (ag,met),s in A.groupby(['agonist','metric'],sort=False):
    r=stats.dunnett(s.d3.values,s.d7.values,s.d14.values,control=s.d0.values)
    print(f'{ag:9s} {met:28s}', np.round(r.pvalue,4))
# Fig 3i / 6b / S2d Tukey
def tk(name,groups):
    y=[];g=[]
    for k,v in groups.items(): y+=v; g+=[k]*len(v)
    print('==',name); print(pairwise_tukeyhsd(np.array(y),np.array(g)))
tk('S2d burden',{'VehDonor':[6.414189,9.508146,9.320839,3.29136,3.733544,2.886353],'CreDonor':[25.23738,25.75262,18.04805,11.13465,13.22011,14.12619],'CreAspDonor':[5.826676,5.060908,4.035548,0.785871,4.705105,5.741156]})
tk('Fig6e MK creatine',{'WT-Veh':[9.941342,25.49864,25.48932],'WT-Cre':[99.63794,78.81516,107.0593],'Stat5bKO-Cre':[81.41063,81.61312,131.5194]})
tk('Fig7b serum',{'d0':[47.739,27.802,44.458,25.531,39.411,46.982,57.329,44.711,56.067,37.392,70.705],'d3':[172.196,108.873,161.583,155.216,153.447,151.678,162.645,142.834,148.494,165.829,159.461],
 'd7':[194.837,147.433,166.89,147.787,143.188,155.923,167.244,114.534,154.155,160.168,158.753],'d14':[214.294,156.985,142.481,160.168,143.896,159.815,122.67,155.923,183.163,141.773,170.074]})
