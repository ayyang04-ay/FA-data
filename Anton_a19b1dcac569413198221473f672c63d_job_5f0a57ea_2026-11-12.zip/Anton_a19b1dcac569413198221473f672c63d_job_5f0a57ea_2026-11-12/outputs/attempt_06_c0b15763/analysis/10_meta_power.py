import numpy as np, pandas as pd
from scipy import stats
pd.set_option('display.width',250)
B = {  # metastatic burden (%) vehicle vs creatine
 'Fig1b (C57BL/6J model)':([2.520141,8.57602,5.014081,7.272389,3.103791,4.642723],[17.69541,11.12241,14.59739,15.33215,13.33241,24.92012],'ok'),
 'Fig1k (BALB/cJ model)':([8.319681,6.68745,6.825005,8.510771,5.95375,7.149815],[16.15659,17.77848,13.94514,14.72625,13.60751,22.19711],'ok'),
 'Fig1f shScr tumour':([2.140578,1.502691,4.734425,7.259364,3.126361,8.545323],[22.84291,15.37146,9.488901,17.54824,15.27744,15.12845],'ok'),
 'Fig1f shSlc6a8 tumour':([6.003466,4.411222,5.053624,6.501543,7.829754,5.041724],[24.95491,18.75453,17.87032,18.74111,14.50824,14.94675],'ok'),
 'SuppFig1e':([20.93048,10.07985,21.40961,17.96392,8.864929,18.11365],[36.85549,44.70853,32.98504,21.7761,29.86035,35.14982],'ok'),
 'SuppFig1f':([4.634175,1.88914,3.964059,5.07603],[15.05064,7.878332,11.80125,8.395904],'ok'),
 'SuppFig1g':([12.71673,6.329834,2.373347,2.873357,7.338642,4.711478,18.44746,5.092113,13.20602,2.773063],[26.40104,31.13075,28.30778,18.85539,19.88642,20.182,33.70799,28.21014,27.86664,27.46881],'ok'),
 'SuppFig1k':([3.925449,4.890024,6.833996,5.477122,3.541821,2.297575,3.347051,1.107069,4.798092,1.497466],[8.959814,5.390679,26.46634,6.320798,11.36883,15.59385,11.82212,18.60377,22.62082,6.467441],'ok'),
 'SuppFig1i (5% creatine diet)':([9.28809,6.096887,5.542432,8.235143],[29.58684,18.29654,37.02099,19.97352],'ok'),
 'Fig3i Pf4-Cre;Slc6a8+/+':([1.625611,3.472779,2.979551,1.380532],[10.26911,7.184769,6.895276,7.29299],'ok'),
 'Fig3i Pf4-Cre;Slc6a8fl/fl (MK-KO)':([2.744865,4.09758,3.688436,3.032601],[4.946393,2.67788,1.95575,1.920413],'ko'),
 'Fig6b no inhibitor':([2.407487,3.29136,3.733544,2.886353,4.918131],[18.22751,11.13465,13.22011,14.12619,12.57216],'flag'),
 'Fig6b + STAT5-IN-1':([3.060235,5.402287,4.055843,1.769177,3.875278],[3.23019,4.602506,4.628309,5.682891,4.314398],'flag'),
 'SuppFig2d donor-platelet transfer':([6.414189,9.508146,9.320839,3.29136,3.733544,2.886353],[25.23738,25.75262,18.04805,11.13465,13.22011,14.12619],'flag'),
 'SuppFig2d creatine+aspirin donor vs vehicle donor':([6.414189,9.508146,9.320839,3.29136,3.733544,2.886353],[5.826676,5.060908,4.035548,0.785871,4.705105,5.741156],'flag'),
 'Fig7g human platelets d7 vs d0':([3.140989,4.20225,3.946535,8.486744,3.470013],[8.545416,21.92856,10.49395,10.94653,11.36809],'ok'),
}
rows=[]
for k,(a,b,flag) in B.items():
    la,lb=np.log(a),np.log(b)
    d=lb.mean()-la.mean()
    se=np.sqrt(la.var(ddof=1)/len(la)+lb.var(ddof=1)/len(lb))
    # Welch df
    v1,v2=la.var(ddof=1)/len(la),lb.var(ddof=1)/len(lb)
    dfw=(v1+v2)**2/(v1**2/(len(la)-1)+v2**2/(len(lb)-1))
    tcrit=stats.t.ppf(0.975,dfw)
    sp=np.sqrt(((len(la)-1)*la.var(ddof=1)+(len(lb)-1)*lb.var(ddof=1))/(len(la)+len(lb)-2))
    rows.append(dict(experiment=k,flag=flag,n_veh=len(a),n_cre=len(b),GMR=np.exp(d),lo=np.exp(d-tcrit*se),hi=np.exp(d+tcrit*se),log_d=d,se=se,sd_pooled_log=sp))
R=pd.DataFrame(rows)
print(R.round(3).to_string())
# random-effects pooled (DerSimonian-Laird) over primary WT creatine-vs-vehicle experiments (exclude KO, flagged, aspirin, STAT5i)
core=R[R.flag=='ok']
w=1/core.se**2; fe=(w*core.log_d).sum()/w.sum()
Q=(w*(core.log_d-fe)**2).sum(); dfq=len(core)-1
C=w.sum()-(w**2).sum()/w.sum(); tau2=max(0,(Q-dfq)/C)
wr=1/(core.se**2+tau2); re=(wr*core.log_d).sum()/wr.sum(); sere=np.sqrt(1/wr.sum())
I2=max(0,(Q-dfq)/Q)*100
print(f'Random-effects pooled GMR over {len(core)} unflagged WT experiments: {np.exp(re):.2f} (95% CI {np.exp(re-1.96*sere):.2f}-{np.exp(re+1.96*sere):.2f}); I2={I2:.0f}%, tau2={tau2:.3f}')
print('Median pooled within-group SD of log(burden):',core.sd_pooled_log.median().round(3),' range',core.sd_pooled_log.min().round(3),core.sd_pooled_log.max().round(3))
R.to_csv('analysis/metastatic_burden_forest.csv',index=False)
# Power for interaction designs
from math import ceil
def n_interaction(sigma,delta,alpha=0.05,power=0.9):
    z=stats.norm.ppf(1-alpha/2)+stats.norm.ppf(power)
    return ceil((z*2*sigma/delta)**2)
def n_two_group(sigma,delta,alpha=0.05,power=0.9):
    z=stats.norm.ppf(1-alpha/2)+stats.norm.ppf(power)
    return ceil(2*(z*sigma/delta)**2)
sig=core.sd_pooled_log.median()
eff=re
for frac in [1.0,0.7,0.5]:
    print(f'sigma={sig:.2f}, creatine effect={np.exp(eff):.2f}x; detect {int(frac*100)}% attenuation (interaction): n/group 80%={n_interaction(sig,frac*eff,power=0.8)}, 90%={n_interaction(sig,frac*eff,power=0.9)}')
# conservative: assume creatine effect only 2-fold in replication
for gm in [2.0,1.5]:
    d=np.log(gm)
    print(f'replication main effect GMR {gm}: n/group 80%={n_two_group(sig,d,power=0.8)}, 90%={n_two_group(sig,d,power=0.9)}; 70% attenuation interaction n/group 90%={n_interaction(sig,0.7*d,power=0.9)}')
# with sigma inflated 1.5x (more heterogeneity in blinded, both-sex study)
sig2=sig*1.5
print('sigma x1.5 =',round(sig2,2))
for frac in [1.0,0.7,0.5]:
    print(f'  detect {int(frac*100)}% attenuation: n/group 80%={n_interaction(sig2,frac*eff,power=0.8)}, 90%={n_interaction(sig2,frac*eff,power=0.9)}')
