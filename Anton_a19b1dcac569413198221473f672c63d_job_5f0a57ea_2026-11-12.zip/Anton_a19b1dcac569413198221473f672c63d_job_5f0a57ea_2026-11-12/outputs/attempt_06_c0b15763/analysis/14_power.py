import numpy as np
from scipy import stats
def power_two_group(n,sigma,delta,alpha=0.05):
    se=sigma*np.sqrt(2/n); df=2*n-2
    t=stats.t.ppf(1-alpha/2,df); ncp=delta/se
    return 1-stats.nct.cdf(t,df,ncp)+stats.nct.cdf(-t,df,ncp)
def power_interaction(n,sigma,delta,alpha=0.05,k=4):
    se=sigma*2/np.sqrt(n); df=k*n-k
    t=stats.t.ppf(1-alpha/2,df); ncp=delta/se
    return 1-stats.nct.cdf(t,df,ncp)+stats.nct.cdf(-t,df,ncp)
print('Primary contrast (creatine+anti-GPVI vs creatine+isotype), log scale')
for sigma in [0.375,0.5,0.6]:
    for gmr in [0.5,0.6,0.67]:
        d=abs(np.log(gmr))
        ns=[n for n in range(3,40) if power_two_group(n,sigma,d)>=0.9]
        print(f' sigma={sigma} GMR={gmr}: n/arm for 90% power = {ns[0] if ns else ">40"};  power at n=12: {power_two_group(12,sigma,d):.2f}')
print('Interaction (creatine x GPVI-blockade): fraction of creatine log-effect removed')
for sigma in [0.375,0.5]:
    for eff in [2.0,3.0]:
        for frac in [1.0,0.7,0.5]:
            d=frac*np.log(eff)
            print(f' sigma={sigma} creatine effect {eff}x, {int(frac*100)}% removed: power at n=12/arm = {power_interaction(12,sigma,d):.2f}')
print('Replication of creatine effect (creatine+isotype vs vehicle+isotype) at n=12, sigma=0.5:')
for eff in [1.5,2.0,3.0]:
    print(f'  {eff}x: power {power_two_group(12,0.5,np.log(eff)):.2f}')
# human PD
def n_par(sd,delta,alpha=0.05,power=0.9):
    for n in range(3,300):
        if power_two_group(n,sd,delta,alpha)>=power: return n
print('Human PD parallel design, log2 scale: n/arm for 90% power')
for sd in [0.6,0.7,0.9,1.2]:
    for fc in [1.4,1.6,2.0]:
        print(f'  SD(log2 change)={sd} detect {fc}x vs placebo: n/arm={n_par(sd,np.log2(fc))}')
