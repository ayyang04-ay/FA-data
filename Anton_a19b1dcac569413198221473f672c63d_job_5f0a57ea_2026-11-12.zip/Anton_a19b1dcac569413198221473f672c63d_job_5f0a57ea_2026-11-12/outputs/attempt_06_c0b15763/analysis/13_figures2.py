import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':8.5,'font.family':'DejaVu Sans'})
OUT='/tmp/outputs/figures/'
# ---------- Fig 5: SLC6A8 MK gate ----------
fig,axes=plt.subplots(1,4,figsize=(12,3.3))
grp=['WT\nveh','WT\ncre','KO\nveh','KO\ncre']
bur=[[1.625611,3.472779,2.979551,1.380532],[10.26911,7.184769,6.895276,7.29299],[2.744865,4.09758,3.688436,3.032601],[4.946393,2.67788,1.95575,1.920413]]
foc=[[18,29,33,39],[59,49,63,55],[29,21,34,22],[36,31,18,14]]
mkc=[[11.1978,18.51648,11.35897],[34.76271,74.94872,106.6923],[21.05738,13.01399,6.991701],[19.47518,26.12821,17.71724]]
cols=['#7f7f7f','#1f4e79','#f4b183','#c55a11']
def dots(ax,data,title,ylab,note=None,log=False):
    for i,(d,c) in enumerate(zip(data,cols)):
        ax.scatter(np.full(len(d),i)+np.linspace(-0.12,0.12,len(d)),d,color=c,s=18,zorder=3)
        ax.plot([i-0.25,i+0.25],[np.mean(d)]*2,color='k',lw=1.5)
    ax.set_xticks(range(4)); ax.set_xticklabels(grp); ax.set_title(title,fontsize=8.5); ax.set_ylabel(ylab)
    if log: ax.set_yscale('log')
    if note: ax.text(0.02,0.98,note,transform=ax.transAxes,va='top',fontsize=7)
dots(axes[0],bur,'Fig 3i lung metastatic burden','% lung area',note='genotype×creatine interaction\np=0.0003 (raw), 0.0009 (log)')
dots(axes[1],foc,'Fig 3i metastatic foci','foci / lung',note='interaction p=0.004')
dots(axes[2],mkc,'Fig 3c MK intracellular creatine','creatine (units as reported)',note='WT: 5.3x (Student p=0.049;\n Welch p=0.11); KO: 1.5x (p=0.20)')
# aggregation 3d
agg={'ADP':[[64,62,64],[70,72,70],[54,56,52],[30,32,32]],'Collagen':[[64,64,66],[76,76,78],[60,62,60],[52,50,50]],'Thrombin':[[60,62,62],[76,74,74],[46,44,46],[34,36,36]]}
ax=axes[3]
for k,(ag,d) in enumerate(agg.items()):
    m=[np.mean(x) for x in d]
    ax.plot(range(4),m,'-o',label=ag,ms=4)
ax.set_xticks(range(4)); ax.set_xticklabels(grp); ax.set_ylabel('max aggregation (%)'); ax.set_title('Fig 3d platelet aggregation (means, n=3)',fontsize=8.5)
ax.legend(fontsize=7,frameon=False,loc='lower left')
ax.text(0.98,0.98,'KO + creatine falls BELOW\nKO vehicle (ADP −23 pts):\nunexplained; baseline WT ADP\n63% here vs 42% in Fig 2b',transform=ax.transAxes,ha='right',va='top',fontsize=6.8,color='#c00000')
fig.suptitle('Megakaryocyte SLC6A8 is the only node with in vivo loss-of-function protection (Pf4-Cre;Slc6a8 fl/fl, n=3–4/group, unmasked)',fontsize=9)
plt.tight_layout(rect=(0,0,1,0.92)); plt.savefig(OUT+'fig5_MK_SLC6A8_gate.png',dpi=200); plt.close()

# ---------- Fig 6: human platelet protein ----------
gp6=np.array([[0.438392,0.406563,0.795446,0.951753],[0.417301,0.823525,0.618009,0.876533],[0.279484,0.551077,1.052902,1.393029],[0.539324,0.313478,0.871327,1.111208]])
p2=np.array([[1.033134,1.444647,1.086538,1.374988],[0.518929,1.192388,0.821571,0.874541],[0.470438,1.006007,0.739907,1.285329],[0.89578,1.115118,1.101423,1.28611]])
dens={'GP6':np.array([[1.0,1.73,1.19,1.87],[1.0,1.95,2.64,2.10],[1.0,0.76,1.60,1.89],[1.0,0.68,1.18,1.39]]),
      'P2RY12':np.array([[1.0,1.20,0.72,0.98],[1.0,1.23,0.93,1.16],[1.0,1.25,1.04,1.06],[1.0,1.25,1.02,1.06]])}
fig,axes=plt.subplots(1,2,figsize=(9,3.4),sharey=True)
days=[0,3,7,14]
for ax,(name,M) in zip(axes,[('GP6',gp6),('P2RY12',p2)]):
    for i in range(4):
        ax.plot(days,M[i]/M[i,0],'-o',color='#1f4e79',alpha=0.8,ms=4,label='Fig 7e tabulated (per volunteer)' if i==0 else None)
        ax.plot(days,dens[name][i],'--s',color='#c55a11',alpha=0.8,ms=3.5,label='our approx. densitometry of Supp 8d blots' if i==0 else None)
    ax.axhline(1,color='k',lw=0.7,ls=':')
    ax.set_yscale('log'); ax.set_xticks(days); ax.set_xlabel('day of 20 g/day creatine'); ax.set_title(f'{name}/β-actin, fold vs own day 0 (n=4)',fontsize=8.5)
axes[0].set_ylabel('fold change (log)'); axes[0].legend(fontsize=6.8,frameon=False,loc='upper left')
axes[0].text(14,0.45,'d14: tabulated 2.6x (4/4 up)\nblots ≈1.4–2.1x (4/4 up)',ha='right',fontsize=7)
axes[1].text(14,0.45,'d14: tabulated 1.7x (4/4 up)\nblots ≈1.0–1.2x (not evident)',ha='right',fontsize=7)
fig.suptitle('Human platelet protein (immunoblot, not transcript): GP6 rise is visible in the representative blots; P2RY12 rise is not',fontsize=9)
plt.tight_layout(rect=(0,0,1,0.9)); plt.savefig(OUT+'fig6_human_platelet_protein.png',dpi=200); plt.close()

# ---------- Fig 7: scorecard ----------
targets=['Platelet GPVI (GP6)','MK SLC6A8','α2A-adrenergic receptor (ADRA2A)','P2Y12 (P2RY12)','CKB','STAT5B','COX-1 (aspirin)']
crit=['C1 In vivo causal\nevidence (metastasis)','C2 MK mechanism\n(necessity/sufficiency)','C3 Human concordance\n(our cohort)','C4 Data integrity /\nreplication']
S=np.array([[0,1,3,2],[2,3,1,1],[0,1,3,2],[0,1,1,2],[0,2,0,2],[1,2,0,0],[1,0,1,0]])
notes=[['none yet','induced 6/6 expts;\nChIP target','mRNA 4/4, protein 4/4,\ncollagen 9/11 ↑','replicated; human\nstats re-done'],
       ['MK-KO abolishes\n(n=4, 1 expt)','KO blocks; liposome\nbypass restores','substrate only\n(serum ↑3.4x)','3d paradox; partial\ndeletion on blot'],
       ['none yet','induced 6/6 expts','mRNA 4/4; EPI\n10–11/11 ↑','replicated'],
       ['none yet','induced 6/6;\nChIP target','ADP response flat;\nblot rise not evident','replicated'],
       ['none','siRNA partial;\nOE sufficient','not measured','single expts'],
       ['pan-STAT5 drug only\n(duplicated values)','inhibitor/KO partial;\nno pY694/699','not measured;\nRAB4A ↓ in humans','duplicated values;\nphospho q≥0.17'],
       ['Supp 2d only\n(duplicated values)','not tested','AA response:\ntrend only','duplicated values']]
fig,ax=plt.subplots(figsize=(11,4.6))
im=ax.imshow(S,cmap='YlGn',vmin=0,vmax=3,aspect='auto')
for i in range(S.shape[0]):
    for j in range(S.shape[1]):
        ax.text(j,i,f'{S[i,j]}\n{notes[i][j]}',ha='center',va='center',fontsize=6.6,color='white' if S[i,j]>=3 else 'black')
tot=S.sum(1)
for i,t in enumerate(tot): ax.text(S.shape[1]-0.35,i,f'  Σ {t}/12',va='center',fontsize=8,weight='bold')
ax.set_xticks(range(len(crit))); ax.set_xticklabels(crit,fontsize=7.5); ax.set_yticks(range(len(targets))); ax.set_yticklabels(targets)
ax.set_xlim(-0.5,S.shape[1]+0.3)
ax.set_title('Evidence scorecard built only from CRE-MK-01 data (0 = none/discordant … 3 = strong). Tractability/safety not scored: not evidenced in package.',fontsize=8.5)
plt.tight_layout(); plt.savefig(OUT+'fig7_target_scorecard.png',dpi=200); plt.close()
print('ok')
