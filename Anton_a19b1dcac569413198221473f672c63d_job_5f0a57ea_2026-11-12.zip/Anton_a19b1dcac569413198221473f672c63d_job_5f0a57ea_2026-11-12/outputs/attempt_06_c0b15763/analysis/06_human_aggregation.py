import openpyxl, numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250)
wb = openpyxl.load_workbook('CRE-MK-01_source_data.xlsx', data_only=True)
ws = wb['Fig. 7c']
grid={(c.row,c.column):c.value for row in ws.iter_rows() for c in row if c.value is not None}
# blocks: find header rows with 'Relative ...' in col A; agonist is in col A of previous row or in A of same block
blocks=[]
for (r,c),v in sorted(grid.items()):
    if c==1 and isinstance(v,str) and v.startswith('Relative'):
        ag=grid.get((r-1,1))
        blocks.append((r,ag,v))
recs=[]
for r,ag,metric in blocks:
    # data rows: next 11 rows with numeric in columns B..E (2..5); special case ADP adhesion where header row itself holds first data row
    start=r+1
    if isinstance(grid.get((r,2)),(int,float)):  # header row contains data
        start=r
    k=0; rr=start
    while k<11:
        vals=[grid.get((rr,cc)) for cc in (2,3,4,5)]
        if all(isinstance(x,(int,float)) for x in vals):
            recs.append(dict(agonist=ag,metric=metric.replace('Relative ','').replace(' (fold change)',''),subj=k+1,d0=vals[0],d3=vals[1],d7=vals[2],d14=vals[3]))
            k+=1
        rr+=1
        if rr>start+20: break
A=pd.DataFrame(recs)
print(A.groupby(['agonist','metric']).size())
rows=[]
for (ag,met),sub in A.groupby(['agonist','metric'],sort=False):
    for d in ['d3','d7','d14']:
        x=sub[d].values.astype(float)
        lx=np.log2(np.where(x>0,x,np.nan))
        nz=np.isfinite(lx)
        t,p=stats.ttest_1samp(lx[nz],0)
        w=stats.wilcoxon(lx[nz]) if nz.sum()>5 else None
        rows.append(dict(agonist=ag,metric=met,day=d,n=int(nz.sum()),n_zero=int((~nz).sum()),median_FC=np.median(x),geomean_FC=2**np.nanmean(lx),
                         arith_mean_FC=x.mean(),n_up=int((x>1).sum()),n_down=int((x<1).sum()),p_log_onesample_t=p,p_wilcoxon=w.pvalue if w else np.nan,
                         max_FC=x.max()))
R=pd.DataFrame(rows)
R['q_BH_wilcoxon_all36']=multipletests(R.p_wilcoxon,method='fdr_bh')[1]
R['q_BH_t_all36']=multipletests(R.p_log_onesample_t,method='fdr_bh')[1]
print(R.round(4).to_string())
R.to_csv('analysis/human_aggregation_reanalysis.csv',index=False)
# Reproduce authors' ordinary one-way ANOVA + Dunnett approximation check for collagen max
from scipy.stats import f_oneway
for (ag,met),sub in A.groupby(['agonist','metric'],sort=False):
    F,p=f_oneway(sub.d0,sub.d3,sub.d7,sub.d14)
    print(ag,met,'ordinary one-way ANOVA p=',round(p,4))
# influence: collagen avg aggregation d14 arithmetic mean with/without max
sub=A[(A.agonist=='collagen')&(A.metric=='average aggregation rate')]
print('collagen avg d14 values', sub.d14.values, 'mean',sub.d14.mean(),'mean without max',np.sort(sub.d14.values)[:-1].mean())
A.to_csv('analysis/human_aggregation_long.csv',index=False)
