import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
import statsmodels.formula.api as smf, statsmodels.api as sm
def tk(name,groups,pairs):
    y=[];g=[]
    for k,v in groups.items(): y+=list(v); g+=[k]*len(v)
    r=pairwise_tukeyhsd(np.array(y,float),np.array(g))
    names=list(r.groupsunique)
    tab={(a,b):p for a,b,p in zip(r._multicomp.pairindices[0],r._multicomp.pairindices[1],r.pvalues)}
    print('==',name)
    for a,b,rep in pairs:
        ia,ib=names.index(a),names.index(b); print(f'  {a} vs {b}: {tab[(min(ia,ib),max(ia,ib))]:.3g} | reported {rep}')
tk('S4b PLT',{'WTv':[893,823,954],'WTc':[1012,1071,644],'KOv':[1074,1172,880],'KOc':[983,827,1167]},[('WTv','WTc','0.9989'),('WTv','KOv','0.6837'),('WTc','KOc','0.9233'),('KOv','KOc','0.9817')])
tk('S7a PLT',{'V':[915,509,514],'C':[710,896,680],'Vi':[900,712,895],'Ci':[559,615,620]},[('V','C','0.7534'),('V','Vi','0.4124'),('V','Ci','0.9745')])
tk('S7b PLT',{'WTv':[887,804,997],'WTc':[943,623,714],'KOc':[585,744,751]},[('WTv','WTc','0.4195'),('WTv','KOc','0.1885'),('WTc','KOc','0.7918')])
tk('Fig5f vehicle',{'WT':[0.64808,0.839803,0.776453],'A':[0.629359,0.742513,0.789045],'3A':[0.635331,0.888382,0.762468],'D':[0.967327,1.004524,1.083835]},[('WT','3A','0.9997'),('WT','D','0.0372'),('A','D','0.0201'),('3A','D','0.0424')])
tk('Fig5f creatine',{'WT':[0.941633,1.105585,0.851071],'A':[0.657846,0.73446,0.509784],'3A':[0.64766,0.712502,0.653898],'D':[1.034501,1.066243,0.880337]},[('WT','A','0.0161'),('WT','D','0.9862'),('A','3A','0.9673')])
# S8b Dunnett (ordinary one-way, as reported)
plt_=np.array([[307,318,317,305],[216,206,235,220],[218,190,191,211],[213,218,162,162],[202,226,228,247],[306,292,304,294],[226,246,225,225],[320,317,292,279],[264,248,242,238],[203,229,195,209],[305,291,335,302]])
r=stats.dunnett(plt_[:,1],plt_[:,2],plt_[:,3],control=plt_[:,0]); print('== S8b PLT Dunnett',np.round(r.pvalue,4),'| reported >0.9999, 0.9909, 0.9634')
# 5j: two-way ANOVA (region x treatment) + Sidak per region
def chip(name,veh,cre,rep):
    rows=[]
    for reg in veh:
        for v in veh[reg]: rows.append(dict(reg=reg,trt='V',y=v))
        for v in cre[reg]: rows.append(dict(reg=reg,trt='C',y=v))
    d=pd.DataFrame(rows); m=smf.ols('y~C(reg)*C(trt)',data=d).fit()
    mse=m.mse_resid; dfr=m.df_resid; k=len(veh)
    print('==',name)
    for reg in veh:
        diff=np.mean(veh[reg])-np.mean(cre[reg]); se=np.sqrt(mse*(2/3)); t=diff/se
        p=2*stats.t.sf(abs(t),dfr); ps=1-(1-p)**k
        print(f'  {reg}: diff {diff:.3f} Sidak p {ps:.3g} | reported {rep[reg]}')
chip('Fig5j P2ry12',{'Exon':[5.255603,2.061731,6.652314],'2K':[1.890616,1.447794,2.875586],'1K':[2.777633,3.349292,2.443343],'0.2K':[0.442533,0.636775,0.680118]},
     {'Exon':[3.955489,8.362047,5.516894],'2K':[8.626983,10.33063,11.03379],'1K':[12.7185,12.85142,14.25955],'0.2K':[6.675409,8.304286,6.293472]},
     {'Exon':'0.7023','2K':'9.0e-06','1K':'2.5e-07','0.2K':'9.3e-05'})
chip('Fig5j Gp6',{'Exon':[8.931213,11.50235,6.934809],'2K':[13.67867,17.4343,17.4343],'1K':[4.419417,3.246435,4.736614],'0.2K':[3.602145,2.240555,4.512279]},
     {'Exon':[8.42021,12.24275,5.791175],'2K':[9.342808,12.85142,16.72409],'1K':[15.55015,12.67449,18.30107],'0.2K':[8.626983,9.407792,11.74403]},
     {'Exon':'0.9998','2K':'0.4079','1K':'0.0001','0.2K':'0.0185'})
chip('SuppFig6i Rab4a',{'Exon':[11.66291,13.77381,7.536299],'2K':[4.328467,6.560729,12.15819],'1K':[9.60547,10.51121,7.129773],'0.2K':[8.808255,6.983045,6.606363]},
     {'Exon':[7.080524,6.934809,10.22378],'2K':[12.28526,11.11053,8.838835],'1K':[20.02675,34.62774,20.09627],'0.2K':[48.97101,51.05061,23.00469]},
     {'Exon':'0.974','2K':'0.9688','1K':'0.0392','0.2K':'5.2e-05'})
