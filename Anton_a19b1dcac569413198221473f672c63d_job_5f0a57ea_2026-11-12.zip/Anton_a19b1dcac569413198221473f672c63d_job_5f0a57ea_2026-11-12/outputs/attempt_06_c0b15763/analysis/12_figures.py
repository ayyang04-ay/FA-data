import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans'})
OUT='/tmp/outputs/figures/'
# ---------- Fig 1: forest plot ----------
R=pd.read_csv('analysis/metastatic_burden_forest.csv')
order=['Fig1b (C57BL/6J model)','Fig1k (BALB/cJ model)','Fig1f shScr tumour','Fig1f shSlc6a8 tumour','SuppFig1e','SuppFig1f','SuppFig1g','SuppFig1k','SuppFig1i (5% creatine diet)',
       'Fig3i Pf4-Cre;Slc6a8+/+','Fig3i Pf4-Cre;Slc6a8fl/fl (MK-KO)','Fig6b no inhibitor','Fig6b + STAT5-IN-1','SuppFig2d donor-platelet transfer','SuppFig2d creatine+aspirin donor vs vehicle donor','Fig7g human platelets d7 vs d0']
labels={'Fig1b (C57BL/6J model)':'Fig 1b  C57BL/6J model (gavage)','Fig1k (BALB/cJ model)':'Fig 1k  BALB/cJ model (gavage)','Fig1f shScr tumour':'Fig 1f  melanoma sh-scrambled',
 'Fig1f shSlc6a8 tumour':'Fig 1f  melanoma sh-Slc6a8 (tumour KD)','SuppFig1e':'Supp 1e','SuppFig1f':'Supp 1f','SuppFig1g':'Supp 1g','SuppFig1k':'Supp 1k','SuppFig1i (5% creatine diet)':'Supp 1i  5% creatine diet',
 'Fig3i Pf4-Cre;Slc6a8+/+':'Fig 3i  Pf4-Cre;Slc6a8+/+ (MK-WT)','Fig3i Pf4-Cre;Slc6a8fl/fl (MK-KO)':'Fig 3i  Pf4-Cre;Slc6a8 fl/fl (MK-KO)','Fig6b no inhibitor':'Fig 6b  no inhibitor  [DUPLICATE FLAG]',
 'Fig6b + STAT5-IN-1':'Fig 6b  + STAT5-IN-1  [DUPLICATE FLAG]','SuppFig2d donor-platelet transfer':'Supp 2d  creatine-donor platelets  [DUPLICATE FLAG]',
 'SuppFig2d creatine+aspirin donor vs vehicle donor':'Supp 2d  creatine+aspirin donor vs vehicle donor  [FLAG]','Fig7g human platelets d7 vs d0':'Fig 7g  human platelets day 7 vs day 0 (into mice)'}
R=R.set_index('experiment').loc[order].reset_index()
fig,ax=plt.subplots(figsize=(8.2,6.2))
y=np.arange(len(R))[::-1]
colors={'ok':'#1f4e79','ko':'#c55a11','flag':'#9e9e9e'}
for yi,(_,r) in zip(y,R.iterrows()):
    c=colors[r.flag]
    ax.plot([r.lo,r.hi],[yi,yi],color=c,lw=1.6)
    ax.plot(r.GMR,yi,'s',color=c,ms=6, mfc=c if r.flag!='flag' else 'white')
    ax.text(13.5,yi,f'{r.GMR:.2f} ({r.lo:.2f}–{r.hi:.2f})  n={r.n_veh}/{r.n_cre}',va='center',fontsize=7.5)
ax.axvline(1,color='k',lw=0.8,ls='--')
ax.set_xscale('log'); ax.set_xlim(0.25,12)
ax.set_xticks([0.25,0.5,1,2,4,8]); ax.set_xticklabels(['0.25','0.5','1','2','4','8'])
ax.set_yticks(y); ax.set_yticklabels([labels[e] for e in R.experiment],fontsize=7.8)
ax.set_xlabel('Geometric-mean ratio of lung metastatic burden, creatine vs control (95% CI, Welch on log scale)')
ax.axhspan(y[len(order)-7]-0.5, y[len(order)-7]+0.5, color='#fde9d9', zorder=0) if False else None
ax.set_title('Creatine effect on metastatic burden across every experiment in CRE-MK-01\n(recomputed from animal-level source data)',fontsize=9.5)
leg=[Patch(color='#1f4e79',label='Unflagged creatine vs control'),Patch(color='#c55a11',label='Creatine effect in MK-Slc6a8 KO'),Patch(facecolor='white',edgecolor='#9e9e9e',label='Integrity flag: 3 animals shared between Fig 6b and Supp 2d')]
ax.legend(handles=leg,loc='lower left',fontsize=7,frameon=False)
fig.text(0.01,0.005,'Random-effects pooled GMR across the 10 unflagged wild-type mouse comparisons = see proposal Section 3.1.',fontsize=6.5)
plt.tight_layout(rect=(0,0.01,0.86,1))
plt.savefig(OUT+'fig1_forest_metastatic_burden.png',dpi=200); plt.close()

# ---------- Fig 2: transcript heatmap ----------
Q=pd.read_csv('analysis/qpcr_contrasts.csv')
H=pd.read_csv('analysis/human_cd41_qpcr_recomputed.csv')
genes=['Gp6','Adra2a','P2ry12','Itga2b','Gpiba','F2r','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
cols=[('2f in vivo Cre vs Veh (WT MKs)','2f in vivo'),('3f in vivo Cre vs Veh (Pf4-Cre;Slc6a8+/+)','3f in vivo'),('6g in vivo Cre vs Veh (WT)','6g in vivo'),
      ('4h in vitro Cre vs Ctrl','4h in vitro'),('4j in vitro Cre vs Ctrl (siScr)','4j in vitro'),('6a Cre vs Veh','6a (STAT5i expt)'),
      ('3f in vivo Cre vs Veh (Pf4-Cre;Slc6a8fl/fl)','Cre effect in\nMK-Slc6a8 KO (3f)'),('S4e Slc6a8-KO MKs: Cre vs Ctrl','Cre in KO MKs\n(S4e)'),('S4e Slc6a8-KO MKs: liposomal Cre vs Ctrl','Liposomal Cre\nin KO MKs (S4e)'),
      ('4j in vitro Cre vs Ctrl (siCkb)','Cre effect\nwith siCkb (4j)'),('4l in vitro CKB-OE vs EV','CKB-OE vs EV\n(4l)'),('6a Cre vs Veh (with STAT5i)','Cre effect\nwith STAT5i (6a)'),('6a STAT5i vs Veh (no Cre)','STAT5i alone\n(6a)'),
      ('6g Stat5b-KO+Cre vs WT-Veh','Stat5b-KO+Cre\nvs WT-Veh (6g)'),('4h in vitro PCr vs Ctrl','PCr vs Ctrl\n(4h)')]
M=np.full((len(genes),len(cols)+2),np.nan)
for j,(c,_) in enumerate(cols):
    sub=Q[Q.contrast==c].set_index('gene')
    for i,g in enumerate(genes):
        if g in sub.index: M[i,j]=sub.loc[g,'log2FC']
hmap={g.upper():g for g in genes}; hmap['GPIBA']='Gpiba'
L=pd.read_csv('analysis/human_cd41_qpcr_per_volunteer.csv')
L=L[~((L.gene=='PITPNB')&(L.vol=='V4'))]   # V4 PITPNB dCt values are invalid (~+27; raw Ct-like)
for k,d in enumerate([7,14]):
    sub=L[L.day==d].groupby('gene').log2FC.mean()
    for i,g in enumerate(genes):
        hg=g.upper() if g!='Gpiba' else 'GPIBA'
        if hg in sub.index: M[i,len(cols)+k]=sub.loc[hg]
fig,ax=plt.subplots(figsize=(11.5,4.6))
im=ax.imshow(M,cmap='RdBu_r',vmin=-4,vmax=4,aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        if np.isfinite(M[i,j]): ax.text(j,i,f'{M[i,j]:.1f}',ha='center',va='center',fontsize=6.5,color='white' if abs(M[i,j])>2.6 else 'black')
ax.set_yticks(range(len(genes))); ax.set_yticklabels(genes)
xl=[l for _,l in cols]+['Human CD41+\nday 7 (n=4*)','Human CD41+\nday 14 (n=4*)']
ax.set_xticks(range(len(xl))); ax.set_xticklabels(xl,rotation=60,ha='right',fontsize=7)
for x in [5.5,13.5+1.0]: pass
ax.axvline(5.5,color='k',lw=1.2); ax.axvline(len(cols)-0.5,color='k',lw=1.2)
cb=plt.colorbar(im,ax=ax,fraction=0.025); cb.set_label('log2 fold change')
ax.set_title('Transcript panel: creatine induction (left, 6 independent mouse MK experiments), perturbations (middle), human CD41+ cells vs own day 0 (right)\nlog2FC = mean ΔCt(treated) − mean ΔCt(control), recomputed from tabulated ΔCt.  *PITPNB human: n=3 (volunteer 4 ΔCt invalid)',fontsize=8.5)
plt.tight_layout(); plt.savefig(OUT+'fig2_transcript_heatmap.png',dpi=200); plt.close()

# ---------- Fig 3: human aggregation ----------
A=pd.read_csv('analysis/human_aggregation_long.csv')
RA=pd.read_csv('analysis/human_aggregation_reanalysis.csv')
ags=['collagen','EPI','ADP','AA']; mets=['maximum aggregation rate','average aggregation rate','platelet adhesion rate']
fig,axes=plt.subplots(1,4,figsize=(11,3.6),sharey=True)
for ax,ag in zip(axes,ags):
    s=A[(A.agonist==ag)&(A.metric=='maximum aggregation rate')]
    for k,d in enumerate(['d3','d7','d14']):
        x=s[d].values.astype(float); x=np.where(x>0,x,np.nan)
        jit=(np.random.RandomState(k).rand(len(x))-0.5)*0.25
        ax.scatter(np.full(len(x),k)+jit,x,s=12,color='#7f7f7f',alpha=0.7,zorder=2)
        r=RA[(RA.agonist==ag)&(RA.metric=='maximum aggregation rate')&(RA.day==d)].iloc[0]
        ax.plot([k-0.25,k+0.25],[r.geomean_FC]*2,color='#c00000' if r.p_wilcoxon<0.05 else 'k',lw=2.2,zorder=3)
        ax.text(k,14,f'{r.n_up}/11↑\np={r.p_wilcoxon:.3f}',ha='center',fontsize=6.8)
    ax.axhline(1,color='k',lw=0.7,ls='--'); ax.set_yscale('log'); ax.set_ylim(0.08,30)
    ax.set_xticks([0,1,2]); ax.set_xticklabels(['d3','d7','d14']); ax.set_title({'EPI':'Epinephrine','AA':'Arachidonic acid','ADP':'ADP','collagen':'Collagen'}[ag])
axes[0].set_ylabel('Max aggregation, fold vs own day 0 (log)')
fig.suptitle('Healthy volunteers (n=11), 20 g/day creatine: within-subject change in maximum aggregation\nbar = geometric mean (red: Wilcoxon p<0.05); p = Wilcoxon signed-rank on log fold change (re-analysis)',fontsize=9)
plt.tight_layout(rect=(0,0,1,0.90)); plt.savefig(OUT+'fig3_human_platelet_function.png',dpi=200); plt.close()

# ---------- Fig 4: phosphoproteomics ----------
P=pd.read_csv('analysis/phospho_with_BH.csv')
fig,axes=plt.subplots(1,2,figsize=(10,3.8))
ax=axes[0]
ax.hist(P.p,bins=40,range=(0,1),color='#5b9bd5',edgecolor='white')
ax.axhline(len(P)/40,color='k',ls='--',lw=0.8); ax.text(0.52,len(P)/40+40,'uniform (no-signal) expectation',fontsize=7)
ax.annotate('1,702 peptides (29%) with p = 0.4226\n= Welch t = 1, df = 2 signature\n(quantified in 1 of 3 replicates of one group)',xy=(0.42,1750),xytext=(0.50,1300),fontsize=7,arrowprops=dict(arrowstyle='->'))
ax.annotate('~300 peptides near p = 0.18\n(t ≈ 2, df = 2: 2-of-3 pattern)',xy=(0.185,310),xytext=(0.03,800),fontsize=7,arrowprops=dict(arrowstyle='->'))
ax.set_xlabel('Reported p-value'); ax.set_ylabel('Phosphopeptides'); ax.set_title('p-value distribution (5,812 phosphopeptides, n=3 vs 3)',fontsize=8.5)
ax=axes[1]
deg=np.isclose(P.p,0.42264973081,atol=1e-8)
ax.scatter(P.lfc[~deg],-np.log10(P.p[~deg]),s=3,color='#7f7f7f',alpha=0.5,label='quantified peptides')
ax.scatter(P.lfc[deg],-np.log10(P.p[deg]),s=3,color='#f4b183',alpha=0.5,label='p=0.4226 artefact')
s=P[P.gene=='Stat5b']
ax.scatter(s.lfc,-np.log10(s.p),s=30,color='#c00000',zorder=3,label='Stat5b phosphopeptides')
for _,r in s.iterrows(): ax.text(r.lfc+0.2,-np.log10(r.p),f'Stat5b q={r.q:.2f}',fontsize=7,color='#c00000')
ax.axhline(-np.log10(0.05),color='k',ls=':',lw=0.8); ax.text(-8.3,1.38,'nominal p=0.05',fontsize=6.5)
ax.set_xlabel('Reported log fold change (creatine vs vehicle)'); ax.set_ylabel('-log10 p'); ax.set_title('No phosphopeptide reaches FDR<0.10 (min q = 0.167)',fontsize=8.5)
ax.legend(fontsize=6.5,frameon=False,loc='upper left')
plt.tight_layout(); plt.savefig(OUT+'fig4_phosphoproteomics_QC.png',dpi=200); plt.close()
print('figures done')
