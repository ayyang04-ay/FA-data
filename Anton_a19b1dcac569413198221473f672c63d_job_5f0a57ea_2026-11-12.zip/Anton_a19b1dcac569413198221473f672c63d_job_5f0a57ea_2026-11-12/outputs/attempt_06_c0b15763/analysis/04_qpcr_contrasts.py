import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf, statsmodels.api as sm
df=pd.read_csv('analysis/qpcr_parsed.csv')
def get(sheet,gene,g):
    r=df[(df.sheet==sheet)&(df.gene==gene)&(df.group==g)]
    if len(r)==0: return None
    r=r.iloc[0]; return np.array([r.v1,r.v2,r.v3],float)
contrasts = {
 'Fig. 2f':[('2f in vivo Cre vs Veh (WT MKs)',2,1)],
 'Fig. 3f':[('3f in vivo Cre vs Veh (Pf4-Cre;Slc6a8+/+)',2,1),('3f KO-Veh vs WT-Veh',3,1),('3f in vivo Cre vs Veh (Pf4-Cre;Slc6a8fl/fl)',4,3)],
 'Fig. 4h':[('4h in vitro Cre vs Ctrl',2,1),('4h in vitro PCr vs Ctrl',3,1)],
 'Fig. 4j':[('4j in vitro siCkb vs siScr (no Cre)',2,1),('4j in vitro Cre vs Ctrl (siScr)',3,1),('4j in vitro Cre vs Ctrl (siCkb)',4,2)],
 'Fig. 4l':[('4l in vitro CKB-OE vs EV',2,1)],
 'Fig.6a':[('6a Cre vs Veh',2,1),('6a STAT5i vs Veh (no Cre)',3,1),('6a Cre vs Veh (with STAT5i)',4,3)],
 'Fig. 6g':[('6g in vivo Cre vs Veh (WT)',2,1),('6g Stat5b-KO+Cre vs WT-Veh',3,1),('6g Stat5b-KO+Cre vs WT+Cre',3,2)],
 'Supplementary Fig  4e':[('S4e Slc6a8-KO MKs: Cre vs Ctrl',2,1),('S4e Slc6a8-KO MKs: liposomal Cre vs Ctrl',3,1)],
 'Supplementary Fig  3c':[('S3c Cre vs Veh (MK maturation genes)',2,1)],
 'Fig. 4e':[('4e Ckb Cre vs Veh',2,1)],
 'Supplementary Fig  5a':[('S5a Cre vs Veh',2,1)],
 'Supplementary Fig  2a':[('S2a siSlc6a8 vs siScr',2,1)],
}
rows=[]
for sheet,cl in contrasts.items():
    genes=df[df.sheet==sheet].gene.unique()
    for gene in genes:
        for lab,b,a in cl:
            xa=get(sheet,gene,a); xb=get(sheet,gene,b)
            if xa is None or xb is None: continue
            l2=xb.mean()-xa.mean()
            t,p=stats.ttest_ind(xb,xa,equal_var=False)
            t2,p2=stats.ttest_ind(xb,xa)
            rows.append(dict(sheet=sheet,contrast=lab,gene=gene,log2FC=l2,FC=2**l2,p_welch=p,p_student=p2,sd_a=xa.std(ddof=1),sd_b=xb.std(ddof=1)))
R=pd.DataFrame(rows)
R.to_csv('analysis/qpcr_contrasts.csv',index=False)
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
# interaction tests (2x2): 3f, 4j, 6a
irows=[]
for sheet,lab,(g1,g2,g3,g4) in [('Fig. 3f','3f Slc6a8 genotype x creatine',(1,2,3,4)),('Fig. 4j','4j siCkb x creatine',(1,3,2,4)),('Fig.6a','6a STAT5i x creatine',(1,2,3,4))]:
    for gene in df[df.sheet==sheet].gene.unique():
        # g1=ctrl/ctrl, g2=cre/ctrl, g3=ctrl/X, g4=cre/X
        data=[]
        for g,(A,B) in zip((g1,g2,g3,g4),[('noX','veh'),('noX','cre'),('X','veh'),('X','cre')]):
            for v in get(sheet,gene,g): data.append(dict(A=A,B=B,y=v))
        d=pd.DataFrame(data)
        m=smf.ols('y~C(A)*C(B)',data=d).fit()
        an=sm.stats.anova_lm(m,typ=2)
        e_noX=d[(d.A=='noX')&(d.B=='cre')].y.mean()-d[(d.A=='noX')&(d.B=='veh')].y.mean()
        e_X=d[(d.A=='X')&(d.B=='cre')].y.mean()-d[(d.A=='X')&(d.B=='veh')].y.mean()
        irows.append(dict(test=lab,gene=gene,log2FC_cre_noX=e_noX,log2FC_cre_X=e_X,p_interaction=an.loc['C(A):C(B)','PR(>F)']))
I=pd.DataFrame(irows); I.to_csv('analysis/qpcr_interactions.csv',index=False)
print(I.round(4).to_string())
# pivot of main creatine contrasts
main=['2f in vivo Cre vs Veh (WT MKs)','3f in vivo Cre vs Veh (Pf4-Cre;Slc6a8+/+)','6g in vivo Cre vs Veh (WT)','4h in vitro Cre vs Ctrl','4j in vitro Cre vs Ctrl (siScr)','6a Cre vs Veh']
genes=['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
P=R[R.contrast.isin(main)].pivot(index='gene',columns='contrast',values='log2FC').loc[genes,main]
print(P.round(2).to_string())
Pp=R[R.contrast.isin(main)].pivot(index='gene',columns='contrast',values='p_welch').loc[genes,main]
print(Pp.round(4).to_string())
other=['3f in vivo Cre vs Veh (Pf4-Cre;Slc6a8fl/fl)','3f KO-Veh vs WT-Veh','S4e Slc6a8-KO MKs: Cre vs Ctrl','S4e Slc6a8-KO MKs: liposomal Cre vs Ctrl','4h in vitro PCr vs Ctrl','4j in vitro Cre vs Ctrl (siCkb)','4j in vitro siCkb vs siScr (no Cre)','4l in vitro CKB-OE vs EV','6a STAT5i vs Veh (no Cre)','6a Cre vs Veh (with STAT5i)','6g Stat5b-KO+Cre vs WT-Veh','6g Stat5b-KO+Cre vs WT+Cre']
P2=R[R.contrast.isin(other)].pivot(index='gene',columns='contrast',values='log2FC').loc[genes,other]
print(P2.round(2).T.to_string())
print(R[R.sheet.isin(['Supplementary Fig  3c','Fig. 4e','Supplementary Fig  5a','Supplementary Fig  2a'])].round(4).to_string())
