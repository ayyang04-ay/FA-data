import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, Polygon
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans'})
OUT='/tmp/outputs/figures/'
R=pd.read_csv('analysis/metastatic_burden_forest.csv')
order=['Fig1b (C57BL/6J model)','Fig1k (BALB/cJ model)','Fig1f shScr tumour','Fig1f shSlc6a8 tumour','SuppFig1e','SuppFig1f','SuppFig1g','SuppFig1k','SuppFig1i (5% creatine diet)',
       'Fig3i Pf4-Cre;Slc6a8+/+','POOLED','Fig3i Pf4-Cre;Slc6a8fl/fl (MK-KO)','Fig7g human platelets d7 vs d0','Fig6b no inhibitor','Fig6b + STAT5-IN-1','SuppFig2d donor-platelet transfer','SuppFig2d creatine+aspirin donor vs vehicle donor']
labels={'Fig1b (C57BL/6J model)':'Fig 1b  gavage (model A)','Fig1k (BALB/cJ model)':'Fig 1k  gavage (model B)','Fig1f shScr tumour':'Fig 1f  melanoma, sh-scrambled',
 'Fig1f shSlc6a8 tumour':'Fig 1f  melanoma, tumour sh-Slc6a8','SuppFig1e':'Supp 1e','SuppFig1f':'Supp 1f','SuppFig1g':'Supp 1g','SuppFig1k':'Supp 1k','SuppFig1i (5% creatine diet)':'Supp 1i  5% creatine diet',
 'Fig3i Pf4-Cre;Slc6a8+/+':'Fig 3i  Pf4-Cre;Slc6a8+/+ (MK-WT)','POOLED':'Pooled, 10 unflagged WT comparisons (random effects)','Fig3i Pf4-Cre;Slc6a8fl/fl (MK-KO)':'Fig 3i  Pf4-Cre;Slc6a8 fl/fl (MK-KO)','Fig6b no inhibitor':'Fig 6b  no inhibitor',
 'Fig6b + STAT5-IN-1':'Fig 6b  + STAT5-IN-1','SuppFig2d donor-platelet transfer':'Supp 2d  creatine-donor vs vehicle-donor platelets',
 'SuppFig2d creatine+aspirin donor vs vehicle donor':'Supp 2d  creatine+aspirin donor vs vehicle donor','Fig7g human platelets d7 vs d0':'Fig 7g  human day-7 vs day-0 platelets into mice'}
R=R.set_index('experiment')
R.loc['POOLED',['GMR','lo','hi','flag','n_veh','n_cre']]=[3.03,2.58,3.57,'pooled',0,0]
R=R.loc[order].reset_index()
fig,ax=plt.subplots(figsize=(9.5,6.6))
y=np.arange(len(R))[::-1].astype(float)
colors={'ok':'#1f4e79','ko':'#c55a11','flag':'#9e9e9e','pooled':'#000000'}
for yi,(_,r) in zip(y,R.iterrows()):
    c=colors[r.flag]
    if r.flag=='pooled':
        ax.add_patch(Polygon([[r.lo,yi],[r.GMR,yi+0.3],[r.hi,yi],[r.GMR,yi-0.3]],closed=True,color='k'))
        ax.text(16,yi,f'{r.GMR:.2f} ({r.lo:.2f}–{r.hi:.2f}); I²=47%',va='center',fontsize=7.5,weight='bold')
        continue
    ax.plot([r.lo,r.hi],[yi,yi],color=c,lw=1.6)
    ax.plot(r.GMR,yi,'s',color=c,ms=6, mfc=c if r.flag!='flag' else 'white')
    ax.text(16,yi,f'{r.GMR:.2f} ({r.lo:.2f}–{r.hi:.2f})  n={int(r.n_veh)}/{int(r.n_cre)}',va='center',fontsize=7.5,color='k' if r.flag!='flag' else '#7f7f7f')
ax.axvline(1,color='k',lw=0.8,ls='--')
ax.axhline(y[order.index('POOLED')]-0.5,color='#bfbfbf',lw=0.6)
ax.axhline(y[order.index('Fig7g human platelets d7 vs d0')]-0.5,color='#bfbfbf',lw=0.6)
ax.text(0.27,y[order.index('Fig6b no inhibitor')]+0.24,'Integrity hold: identical values (burden + foci) for 3 animals/group in both Fig 6b and Supp 2d',fontsize=6.8,color='#7f7f7f',style='italic',va='center')
ax.set_xscale('log'); ax.set_xlim(0.25,14)
ax.set_xticks([0.25,0.5,1,2,4,8]); ax.set_xticklabels(['0.25','0.5','1','2','4','8'])
ax.set_yticks(y); ax.set_yticklabels([labels[e] for e in R.experiment],fontsize=7.8)
ax.set_xlabel('Geometric-mean ratio of lung metastatic burden vs control (95% CI; Welch, log scale)')
ax.set_title('Creatine and lung metastatic burden: every comparison in CRE-MK-01, recomputed from animal-level values',fontsize=9.5)
leg=[Patch(color='#1f4e79',label='Creatine vs vehicle (wild-type MK) / human platelet transfer'),Patch(color='#c55a11',label='Creatine vs vehicle in MK-Slc6a8 KO'),Patch(facecolor='white',edgecolor='#9e9e9e',label='Flagged (duplicated animal-level values)')]
ax.legend(handles=leg,loc='upper center',bbox_to_anchor=(0.35,-0.085),ncol=2,fontsize=7,frameon=False)
plt.tight_layout(rect=(0,0.02,0.80,1))
plt.savefig(OUT+'fig1_forest_metastatic_burden.png',dpi=200); plt.close()
