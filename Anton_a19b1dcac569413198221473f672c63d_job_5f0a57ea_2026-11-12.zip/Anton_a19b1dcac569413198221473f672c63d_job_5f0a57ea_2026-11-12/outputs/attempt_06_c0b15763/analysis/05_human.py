import openpyxl, re, numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
pd.set_option('display.width',250)
wb = openpyxl.load_workbook('CRE-MK-01_source_data.xlsx', data_only=True)
ws = wb['Fig. 7d']
grid={(c.row,c.column):c.value for row in ws.iter_rows() for c in row if c.value is not None}
# gene headers at rows 6,25,44,63,82,100 in columns A(1) and H(8); values in C-F (3-6) or I-L (9-12)
recs=[]
for (r,c),v in grid.items():
    if isinstance(v,str) and v.startswith('ΔCT-'):
        day=int(v.split('-')[1].replace('d',''))
        # find gene header above in column c-1 (A or H)
        gc = 1 if c==2 else 8
        rr=r
        while rr>0 and not (isinstance(grid.get((rr,gc)),str) and grid.get((rr,gc)).isupper()):
            rr-=1
        gene=grid.get((rr,gc))
        for i in range(4):
            val=grid.get((r,c+1+i))
            recs.append(dict(gene=gene,day=day,vol=f'V{i+1}',row=r,dct=val))
H=pd.DataFrame(recs)
H['gene']=H.gene.replace({'ADAR2A':'ADRA2A'})
print(H.groupby('gene').size())
# per volunteer per day mean dCT (technical triplicate)
M=H.groupby(['gene','vol','day']).dct.agg(['mean','std','min','max']).reset_index()
M['range']=M['max']-M['min']
print('Technical-triplicate spread (range, dCT units) summary by gene:')
print(M.groupby('gene')['range'].describe().round(2))
# flag anomalies
print('\nPositive dCT values (anomalous):')
print(H[H.dct>0].to_string())
# log2FC per volunteer vs day 0
rows=[]
for (g,v),sub in M.groupby(['gene','vol']):
    base=sub[sub.day==0]['mean'].values[0]
    for d in [3,7,14]:
        rows.append(dict(gene=g,vol=v,day=d,log2FC=sub[sub.day==d]['mean'].values[0]-base))
L=pd.DataFrame(rows)
# compare with authors' 'After normalization' values
auth={}
for (r,c),v in grid.items():
    if isinstance(v,str) and v.startswith('After normalization-') and not v.endswith('0d'):
        day=int(v.split('-')[1].replace('d',''))
        gc = 1 if c==2 else 8
        rr=r
        while rr>0 and not (isinstance(grid.get((rr,gc)),str) and grid.get((rr,gc)).isupper()):
            rr-=1
        gene=grid.get((rr,gc)).replace('ADAR2A','ADRA2A')
        for i in range(4):
            auth[(gene,f'V{i+1}',day)]=grid.get((r,c+1+i))
L['FC_recomputed']=2**L.log2FC
L['FC_reported']=[auth[(g,v,d)] for g,v,d in zip(L.gene,L.vol,L.day)]
print(L.pivot_table(index=['gene','vol'],columns='day',values=['FC_recomputed','FC_reported']).round(2).to_string())
# across-volunteer test per gene/day: one-sample t on log2FC, and sign count
S=[]
for (g,d),sub in L.groupby(['gene','day']):
    x=sub.log2FC.values
    t,p=stats.ttest_1samp(x,0)
    S.append(dict(gene=g,day=d,mean_log2FC=x.mean(),geo_FC=2**x.mean(),n_up=(x>0).sum(),n=len(x),p_onesample=p,
                  vols=' '.join(f'{2**xi:.2f}' for xi in x)))
S=pd.DataFrame(S)
print(S.round(3).to_string())
S.to_csv('analysis/human_cd41_qpcr_recomputed.csv',index=False)
L.to_csv('analysis/human_cd41_qpcr_per_volunteer.csv',index=False)
M.to_csv('analysis/human_cd41_qpcr_techrep_summary.csv',index=False)
