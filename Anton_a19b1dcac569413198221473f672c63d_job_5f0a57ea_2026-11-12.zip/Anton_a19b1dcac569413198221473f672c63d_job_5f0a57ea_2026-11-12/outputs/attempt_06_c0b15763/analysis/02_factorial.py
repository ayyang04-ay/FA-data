import numpy as np, pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from scipy import stats
pd.set_option('display.width',250)

def two_way(name, groups, fA, fB, logscale=False):
    # groups: dict label->(levelA, levelB, values)
    rows=[]
    for lab,(a,b,vals) in groups.items():
        for v in vals: rows.append(dict(A=a,B=b,y=np.log(v) if logscale else v,label=lab))
    df=pd.DataFrame(rows)
    m=smf.ols('y ~ C(A)*C(B)',data=df).fit()
    an=sm.stats.anova_lm(m,typ=2)
    # Tukey all pairs
    tk=pairwise_tukeyhsd(df.y,df.label)
    return df,an,tk,m

out=[]
def report(name, groups, fA, fB):
    for logscale in [False, True]:
        df,an,tk,m=two_way(name,groups,fA,fB,logscale)
        p_int=an.loc['C(A):C(B)','PR(>F)']
        print(f'==== {name} | {"log" if logscale else "raw"} scale | interaction p = {p_int:.4g}')
        print(an.round(4))
        if not logscale: print(tk)
        out.append(dict(panel=name,scale='log' if logscale else 'raw',p_interaction=p_int,
                        p_mainA=an.loc['C(A)','PR(>F)'],p_mainB=an.loc['C(B)','PR(>F)']))
    # means
    for lab,(a,b,v) in groups.items():
        print(f'   {lab:40s} n={len(v)} mean={np.mean(v):.3f} sd={np.std(v,ddof=1):.3f}')

# Fig 1f: tumour shRNA x creatine
report('Fig1f lung weight',{
 'shScr-Veh':('shScr','Veh',[0.2051,0.1525,0.1646,0.1691,0.2068,0.2221]),
 'shScr-Cre':('shScr','Cre',[0.2591,0.2624,0.3623,0.3602,0.2556,0.3572]),
 'shSlc6a8-Veh':('shSlc','Veh',[0.226,0.2481,0.244,0.2085,0.2102,0.2427]),
 'shSlc6a8-Cre':('shSlc','Cre',[0.3234,0.278,0.3426,0.3758,0.2979,0.2443])},'tumour','treat')
report('Fig1f metastatic burden',{
 'shScr-Veh':('shScr','Veh',[2.140578,1.502691,4.734425,7.259364,3.126361,8.545323]),
 'shScr-Cre':('shScr','Cre',[22.84291,15.37146,9.488901,17.54824,15.27744,15.12845]),
 'shSlc6a8-Veh':('shSlc','Veh',[6.003466,4.411222,5.053624,6.501543,7.829754,5.041724]),
 'shSlc6a8-Cre':('shSlc','Cre',[24.95491,18.75453,17.87032,18.74111,14.50824,14.94675])},'tumour','treat')
report('Fig1f foci',{
 'shScr-Veh':('shScr','Veh',[8,6,7,18,10,15]),
 'shScr-Cre':('shScr','Cre',[18,20,20,44,32,30]),
 'shSlc6a8-Veh':('shSlc','Veh',[11,9,12,15,21,15]),
 'shSlc6a8-Cre':('shSlc','Cre',[22,36,28,35,29,35])},'tumour','treat')
report('Fig1f SUV',{
 'shScr-Veh':('shScr','Veh',[1058.9,893.6,1095.7,949.07,926.52,877.28]),
 'shScr-Cre':('shScr','Cre',[1409.3,1330.5,1162.3,1194.2,1155.2,1245.9]),
 'shSlc6a8-Veh':('shSlc','Veh',[1086,982.98,1062.4,843.52,892.77,919.32]),
 'shSlc6a8-Cre':('shSlc','Cre',[1254.4,1161.2,1376.4,1417.4,1139.2,1355.41])},'tumour','treat')
# Fig 3i: host MK Slc6a8 x creatine
report('Fig3i lung weight',{
 'WT-Veh':('WT','Veh',[0.2086,0.2052,0.2121,0.1991]),
 'WT-Cre':('WT','Cre',[0.2519,0.258,0.2406,0.244]),
 'KO-Veh':('KO','Veh',[0.2173,0.2282,0.2311,0.2106]),
 'KO-Cre':('KO','Cre',[0.2238,0.2235,0.2185,0.234])},'geno','treat')
report('Fig3i metastatic burden',{
 'WT-Veh':('WT','Veh',[1.625611,3.472779,2.979551,1.380532]),
 'WT-Cre':('WT','Cre',[10.26911,7.184769,6.895276,7.29299]),
 'KO-Veh':('KO','Veh',[2.744865,4.09758,3.688436,3.032601]),
 'KO-Cre':('KO','Cre',[4.946393,2.67788,1.95575,1.920413])},'geno','treat')
report('Fig3i foci',{
 'WT-Veh':('WT','Veh',[18,29,33,39]),
 'WT-Cre':('WT','Cre',[59,49,63,55]),
 'KO-Veh':('KO','Veh',[29,21,34,22]),
 'KO-Cre':('KO','Cre',[36,31,18,14])},'geno','treat')
# Fig 3d aggregation
for ag,vals in {'ADP':([64,62,64],[70,72,70],[54,56,52],[30,32,32]),
                'Collagen':([64,64,66],[76,76,78],[60,62,60],[52,50,50]),
                'Thrombin':([60,62,62],[76,74,74],[46,44,46],[34,36,36])}.items():
    report(f'Fig3d aggregation {ag}',{'WT-Veh':('WT','Veh',vals[0]),'WT-Cre':('WT','Cre',vals[1]),
        'KO-Veh':('KO','Veh',vals[2]),'KO-Cre':('KO','Cre',vals[3])},'geno','treat')
# Fig 6b STAT5i x creatine
report('Fig6b metastatic burden',{
 'Veh':('noI','Veh',[2.407487,3.29136,3.733544,2.886353,4.918131]),
 'Cre':('noI','Cre',[18.22751,11.13465,13.22011,14.12619,12.57216]),
 'Veh+STAT5i':('STAT5i','Veh',[3.060235,5.402287,4.055843,1.769177,3.875278]),
 'Cre+STAT5i':('STAT5i','Cre',[3.23019,4.602506,4.628309,5.682891,4.314398])},'inhib','treat')
report('Fig6b foci',{
 'Veh':('noI','Veh',[23,37,25,33,33]),
 'Cre':('noI','Cre',[51,53,62,47,78]),
 'Veh+STAT5i':('STAT5i','Veh',[24,32,38,20,34]),
 'Cre+STAT5i':('STAT5i','Cre',[28,33,30,20,25])},'inhib','treat')
# Supp 4c alpha granules (fields)
report('SuppFig4c alpha-granules (fields)',{
 'WT-Veh':('WT','Veh',[5,3,3,2,1,2,3,2]),'WT-Cre':('WT','Cre',[5,5,6,6,4,4,7,4]),
 'KO-Veh':('KO','Veh',[1,2,2,4,3,1,2,3]),'KO-Cre':('KO','Cre',[5,2,1,1,2,3,1,3])},'geno','treat')
# Fig 5e/5f: STAT5B mutant x creatine (WT vs S127A), (WT vs 3A), (WT vs S127D)
for panel,veh,cre in [('Fig5e',{'WT':[0.659454,0.674769,0.814221],'S127A':[0.672877,0.852802,0.828226],'3A':[0.700789,0.798797,0.822926],'S127D':[1.154619,0.939173,1.041934]},
                               {'WT':[1.027282,0.930996,1.033835],'S127A':[0.796595,0.871665,0.819922],'3A':[0.714459,0.69881,0.793392],'S127D':[0.991615,0.944168,1.092005]}),
                      ('Fig5f',{'WT':[0.64808,0.839803,0.776453],'S127A':[0.629359,0.742513,0.789045],'3A':[0.635331,0.888382,0.762468],'S127D':[0.967327,1.004524,1.083835]},
                               {'WT':[0.941633,1.105585,0.851071],'S127A':[0.657846,0.73446,0.509784],'3A':[0.64766,0.712502,0.653898],'S127D':[1.034501,1.066243,0.880337]})]:
    for mut in ['S127A','3A','S127D']:
        report(f'{panel} pan-phos/FLAG WT vs {mut}',{
            'WT-Veh':('WT','Veh',veh['WT']),'WT-Cre':('WT','Cre',cre['WT']),
            f'{mut}-Veh':(mut,'Veh',veh[mut]),f'{mut}-Cre':(mut,'Cre',cre[mut])},'construct','treat')
    # simple creatine effect within each construct
    for k in veh:
        t,p=stats.ttest_ind(cre[k],veh[k])
        print(f'  {panel} creatine effect within {k}: veh {np.mean(veh[k]):.3f} cre {np.mean(cre[k]):.3f} ratio {np.mean(cre[k])/np.mean(veh[k]):.2f} t-test p={p:.4f}')
pd.DataFrame(out).to_csv('analysis/factorial_interactions.csv',index=False)
print(pd.DataFrame(out).round(5).to_string())
