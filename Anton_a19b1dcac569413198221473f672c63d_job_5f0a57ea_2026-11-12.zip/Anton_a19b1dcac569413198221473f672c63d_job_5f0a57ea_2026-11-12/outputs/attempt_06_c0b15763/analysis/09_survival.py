import numpy as np
from lifelines.statistics import logrank_test
from lifelines import KaplanMeierFitter, CoxPHFitter
import pandas as pd
sets={'Fig1c':([17,17,20,20,21,23,27,29,30,30],[13,13,13,13,18,20,21,21,22,24]),
      'Fig1l':([14,14,14,15,15,15,15,16,16,16,16,18,18,18,18,19,19,20,20,20],[12,12,12,12,13,13,14,14,14,14,15,15,15,17,17,18,19,19])}
for k,(v,c) in sets.items():
    r=logrank_test(v,c,event_observed_A=[1]*len(v),event_observed_B=[1]*len(c))
    km=KaplanMeierFitter()
    mv=km.fit(v).median_survival_time_; mc=km.fit(c).median_survival_time_
    df=pd.DataFrame({'T':v+c,'E':1,'cre':[0]*len(v)+[1]*len(c)})
    cph=CoxPHFitter().fit(df,'T','E')
    hr=np.exp(cph.params_['cre']); ci=np.exp(cph.confidence_intervals_.loc['cre'].values)
    print(k,'n',len(v),len(c),'logrank chi2',round(r.test_statistic,3),'p',round(r.p_value,4),'median veh',mv,'cre',mc,'HR',round(hr,2),'95%CI',np.round(ci,2))
