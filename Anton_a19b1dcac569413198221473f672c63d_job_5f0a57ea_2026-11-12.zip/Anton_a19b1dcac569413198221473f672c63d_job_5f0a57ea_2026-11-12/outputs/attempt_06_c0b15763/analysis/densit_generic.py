from PIL import Image
import numpy as np, sys
def quant(img, x0,x1,y0,y1,lanes, bgrows=3):
    A=np.asarray(Image.open(img).convert('L')).astype(float)
    sub=255-A[y0:y1,x0:x1]
    bg=np.median(np.vstack([sub[:bgrows,:],sub[-bgrows:,:]]),axis=0)
    prof=np.clip(sub-bg[None,:],0,None).sum(axis=0)
    lr=[l-x0 for l in lanes]
    b=[0]+[int((lr[i]+lr[i+1])/2) for i in range(len(lr)-1)]+[x1-x0]
    return np.array([prof[b[i]:b[i+1]].sum() for i in range(len(lr))])
