import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250)
df = pd.read_excel('CRE-MK-01_phosphoproteomics.xlsx')
df.columns=['gene','p','q','lfc']
n=len(df)
df['q_BH']=multipletests(df.p,method='fdr_bh')[1]
print('n peptides',n,'unique genes',df.gene.nunique(),'missing gene names',df.gene.isna().sum())
print('min BH q',df.q_BH.min(),' min provided q',df.q.min())
print('corr provided q vs BH q', np.corrcoef(df.q,df.q_BH)[0,1])
# Storey pi0
for lam in [0.5,0.6,0.7,0.8]:
    pi0=(df.p>lam).mean()/(1-lam); print('Storey pi0 at lambda',lam,round(pi0,3))
# degenerate p
t1=2*stats.t.sf(1,2)
deg=np.isclose(df.p,t1,atol=1e-9)
print('p == 0.42265 (t=1, Welch df=2 signature) count',deg.sum(), f'{deg.mean()*100:.1f}%')
print('|LFC| of degenerate peptides: median',df.lfc[deg].abs().median(),' of others',df.lfc[~deg].abs().median())
# nominal hits by authors' criterion (log2 assumed)
crit=(df.p<0.05)&((df.lfc>=np.log2(1.2))|(df.lfc<=np.log2(0.83)))
print('authors criterion hits (log2 FC):',crit.sum(),' expected false positives if all null ~', round(0.05*n*((df.lfc.abs()>=0.263).mean()),1))
print('p<0.05 overall',(df.p<0.05).sum(),' expected under null',0.05*n)
nd=df[~deg]
print('Excluding degenerate: n',len(nd),' p<0.05',(nd.p<0.05).sum(),' expected',round(0.05*len(nd),1),' ratio',round((nd.p<0.05).sum()/(0.05*len(nd)),2))
# binomial test for enrichment of small p among non-degenerate
print('binomial test p<0.05 enrichment (non-degenerate):',stats.binomtest(int((nd.p<0.05).sum()),len(nd),0.05,alternative='greater').pvalue)
# large-LFC hits (presence/absence)
hits=df[crit]
print('hits with |LFC|>3:',(hits.lfc.abs()>3).sum(),'of',len(hits))
print(df[df.gene.isin(['Stat5b','Stat5a'])].to_string())
print('Rank of Stat5b peptide by p:', int((df.p<df.loc[df.gene=='Stat5b','p'].min()).sum())+1)
h,edges=np.histogram(df.p,bins=20,range=(0,1))
print(list(zip(np.round(edges[:-1],2),h)))
df.to_csv('analysis/phospho_with_BH.csv',index=False)
