import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.anova import AnovaRM
pd.set_option('display.width',250)
gp6=np.array([[0.438392,0.406563,0.795446,0.951753],[0.417301,0.823525,0.618009,0.876533],[0.279484,0.551077,1.052902,1.393029],[0.539324,0.313478,0.871327,1.111208]])
p2=np.array([[1.033134,1.444647,1.086538,1.374988],[0.518929,1.192388,0.821571,0.874541],[0.470438,1.006007,0.739907,1.285329],[0.89578,1.115118,1.101423,1.28611]])
days=[0,3,7,14]
for name,M in [('GP6/ACTB',gp6),('P2RY12/ACTB',p2)]:
    print('=====',name)
    L=np.log2(M)
    for j,d in enumerate(days[1:],1):
        x=L[:,j]-L[:,0]
        t,p=stats.ttest_1samp(x,0)
        print(f'day {d}: per-subject FC', np.round(2**x,2), f'geomean FC {2**x.mean():.2f}  paired t (log) p={p:.4f}  n_up={(x>0).sum()}/4')
    # repeated-measures ANOVA on log scale
    df=pd.DataFrame([dict(subj=i,day=str(d),y=L[i,j]) for i in range(4) for j,d in enumerate(days)])
    print(AnovaRM(df,'y','subj',within=['day']).fit())
    # ordinary one-way ANOVA (as reported)
    print('ordinary one-way ANOVA p =',stats.f_oneway(*[M[:,j] for j in range(4)]).pvalue)
# serum creatine
S=np.array([[47.739,172.196,194.837,214.294],[27.802,108.873,147.433,156.985],[44.458,161.583,166.89,142.481],[25.531,155.216,147.787,160.168],
[39.411,153.447,143.188,143.896],[46.982,151.678,155.923,159.815],[57.329,162.645,167.244,122.67],[44.711,142.834,114.534,155.923],
[56.067,148.494,154.155,183.163],[37.392,165.829,160.168,141.773],[70.705,159.461,158.753,170.074]])
print('serum creatine means',S.mean(0).round(1),'sd',S.std(0,ddof=1).round(1))
print('fold vs d0 per subject (d3,d7,d14) median', np.median(S[:,1:]/S[:,[0]],axis=0).round(2), 'min', (S[:,1:]/S[:,[0]]).min(0).round(2))
# mouse serum for bridge
mouse={'Supp1d gavage':([66.553,73.37875,56.10075,60.58025,61.86,77.2185],[186.4335,183.4471,165.1024,183.8737,171.9284,180.4608]),
       'Supp1h diet':([75.0855,67.833,68.686,101.109],[209.2578,214.3773,234.215,251.0665]),
       'Fig3b WT (Pf4-Cre;Slc6a8+/+)':([84.11,85.348,99.145,97.376,77.212],[213.148,215.624,254.538,287.084,225.884])}
for k,(a,b) in mouse.items():
    print(k,'veh',np.mean(a).round(1),'cre',np.mean(b).round(1),'ratio',round(np.mean(b)/np.mean(a),2))
