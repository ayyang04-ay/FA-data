from PIL import Image
import numpy as np
im = Image.open('src_unz/xl/media/image26.jpeg').convert('L')
A = np.asarray(im).astype(float)
panels = {
 ('V1','GP6'):   (300,505,152,200,[335,380,430,475]),
 ('V1','P2RY12'):(700,930,150,195,[740,795,845,900]),
 ('V1','ACTB'):  (1140,1360,145,182,[1180,1225,1275,1325]),
 ('V2','GP6'):   (270,500,418,452,[305,365,418,470]),
 ('V2','P2RY12'):(680,895,405,437,[712,760,810,857]),
 ('V2','ACTB'):  (1160,1432,408,442,[1200,1260,1322,1388]),
 ('V3','GP6'):   (295,502,683,716,[330,372,422,472]),
 ('V3','P2RY12'):(695,925,685,722,[735,780,835,890]),
 ('V3','ACTB'):  (1140,1412,673,707,[1180,1245,1305,1372]),
 ('V4','GP6'):   (220,470,975,1008,[260,320,375,435]),
 ('V4','P2RY12'):(710,962,975,1007,[750,815,870,932]),
 ('V4','ACTB'):  (1180,1442,972,1006,[1220,1280,1332,1398]),
}
res={}
for (v,g),(x0,x1,y0,y1,lanes) in panels.items():
    sub = 255-A[y0:y1, x0:x1]
    # background: per-column min over rows (rolling-ball-like) -> use the median of top 3 and bottom 3 rows
    bg = np.median(np.vstack([sub[:3,:], sub[-3:,:]]), axis=0)
    prof = np.clip(sub - bg[None,:], 0, None).sum(axis=0)
    # lane boundaries at midpoints
    lanes_rel=[l-x0 for l in lanes]
    bounds=[0]+[int((lanes_rel[i]+lanes_rel[i+1])/2) for i in range(3)]+[x1-x0]
    vals=[prof[bounds[i]:bounds[i+1]].sum() for i in range(4)]
    res[(v,g)]=np.array(vals)
    Image.fromarray(A[y0-10:y1+10, x0:x1].astype('uint8')).resize(((x1-x0)*3,(y1-y0+20)*3)).save(f'densit/{v}_{g}.png')
import pandas as pd
rows=[]
for v in ['V1','V2','V3','V4']:
    for g in ['GP6','P2RY12']:
        r = res[(v,g)]/res[(v,'ACTB')]
        rows.append([v,g]+list(np.round(res[(v,g)]/1000,1))+list(np.round(res[(v,'ACTB')]/1000,1))+list(np.round(r/r[0],2)))
df=pd.DataFrame(rows,columns=['vol','gene','d0','d3','d7','d14','a0','a3','a7','a14','rel0','rel3','rel7','rel14'])
print(df.to_string())
