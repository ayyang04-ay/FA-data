import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
df=pd.read_excel('/tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx')
df.columns=['gene','p','q','lfc']
single=np.isclose(df.p,0.42265,atol=2e-5)
fig,axs=plt.subplots(1,2,figsize=(11,4.4))
ax=axs[0]
ax.scatter(df.lfc[~single],-np.log10(df.p[~single]),s=4,c='#9db3c9',label=f'quantified in ≥2 samples (n={int((~single).sum())})',rasterized=True)
ax.scatter(df.lfc[single],-np.log10(df.p[single]),s=4,c='#e0a060',label=f'single-sample detections, p≡0.4226 (n={int(single.sum())})',rasterized=True)
st=df[(df.gene=='Stat5b')]
ax.scatter(st.lfc,-np.log10(st.p),s=40,facecolors='none',edgecolors='red',lw=1.5,label='Stat5b phosphopeptides')
for _,r in st.iterrows():
    if r.p<0.01: ax.annotate(f"Stat5b  p={r.p:.4f}\nq={r.q:.2f}, rank 17/5812",(r.lfc,-np.log10(r.p)),xytext=(r.lfc-7.5,-np.log10(r.p)+0.6),fontsize=7.5,arrowprops=dict(arrowstyle='-',color='red',lw=0.7))
ax.axhline(-np.log10(0.05),color='grey',ls='--',lw=0.7)
ax.text(-8.3,-np.log10(0.05)+0.05,'nominal p=0.05',fontsize=7,color='grey')
ax.set_xlabel('log fold change (creatine vs vehicle), as supplied'); ax.set_ylabel('-log10 p (t-test, n=3 vs 3)')
ax.set_title('A. Phosphopeptide volcano (no peptide has q<0.05; min q=0.167)',fontsize=9)
ax.legend(fontsize=7,loc='upper left',frameon=False)
ax=axs[1]
sub=df[~single]
ax.hist(sub.p,bins=20,range=(0,1),color='#9db3c9',edgecolor='white')
ax.axhline(len(sub)/20,color='k',ls='--',lw=0.8)
ax.text(0.52,len(sub)/20+8,'expected count per bin if no true effects',fontsize=7)
ax.set_xlabel('p value'); ax.set_ylabel('phosphopeptides')
ax.set_title(f'B. p-value distribution, peptides quantified in ≥2 samples\n(p<0.05: {int((sub.p<0.05).sum())} observed vs {0.05*len(sub):.0f} expected under the null)',fontsize=9)
fig.suptitle('Figure 3. Phosphoproteomics (CRE-MK-01_phosphoproteomics.xlsx) does not distinguish creatine-treated from vehicle MKs beyond chance',fontsize=9.5,x=0.01,ha='left')
plt.tight_layout(rect=(0,0,1,0.94))
plt.savefig('/tmp/outputs/figures/fig3_phosphoproteomics.png',dpi=200)
