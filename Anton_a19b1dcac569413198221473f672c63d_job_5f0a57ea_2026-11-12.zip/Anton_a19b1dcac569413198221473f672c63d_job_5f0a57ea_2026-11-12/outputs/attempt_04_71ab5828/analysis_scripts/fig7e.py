import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.anova import AnovaRM
gp6=np.array([[0.43839,0.40656,0.79545,0.95175],[0.4173,0.82352,0.61801,0.87653],[0.27948,0.55108,1.0529,1.39303],[0.53932,0.31348,0.87133,1.11121]])
p2=np.array([[1.03313,1.44465,1.08654,1.37499],[0.51893,1.19239,0.82157,0.87454],[0.47044,1.00601,0.73991,1.28533],[0.89578,1.11512,1.10142,1.28611]])
for name,m in [('GP6',gp6),('P2RY12',p2)]:
    df=pd.DataFrame([(s,d,m[s,i]) for s in range(4) for i,d in enumerate(['d0','d3','d7','d14'])],columns=['subj','day','y'])
    r=AnovaRM(df,'y','subj',within=['day']).fit()
    print(name); print(r.anova_table)
    print(' ordinary one-way:', stats.f_oneway(*m.T))
    for j,d in enumerate(['d3','d7','d14']):
        print('  paired t d0 vs',d, stats.ttest_rel(m[:,j+1],m[:,0]).pvalue, ' ratio', (m[:,j+1]/m[:,0]).round(2))
    print('  Friedman', stats.friedmanchisquare(*m.T))
# Supp 8b platelets RM
plt=np.array([[307,318,317,305],[216,206,235,220],[218,190,191,211],[213,218,162,162],[202,226,228,247],[306,292,304,294],[226,246,225,225],[320,317,292,279],[264,248,242,238],[203,229,195,209],[305,291,335,302]])
df=pd.DataFrame([(s,d,plt[s,i]) for s in range(11) for i,d in enumerate(['d0','d3','d7','d14'])],columns=['subj','day','y'])
print('PLT RM', AnovaRM(df,'y','subj',within=['day']).fit().anova_table)
# BMI paired
b0=[21.67126,18.42653,19.4674,15.6157,20.28123,18.52237,21.96459,17.89802,22.58271,27.7551,25.95156]
b14=[21.56107,18.46659,19.54086,15.69007,20.78826,18.10614,21.79945,18.31426,22.65798,27.85306,26.81661]
print('BMI paired', stats.ttest_rel(b14,b0), np.mean(np.array(b14)-np.array(b0)))
