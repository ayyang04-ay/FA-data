import openpyxl, itertools
wb = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)
# collect column vectors (consecutive numeric cells in a column) and row vectors
vecs=[]
for ws in wb.worksheets:
    if any(k in ws.title for k in []): continue
    maxr, maxc = ws.max_row, ws.max_column
    grid=[[ws.cell(r,c).value for c in range(1,maxc+1)] for r in range(1,maxr+1)]
    # column runs
    for c in range(maxc):
        run=[]; start=None
        for r in range(maxr+1):
            v = grid[r][c] if r<maxr else None
            if isinstance(v,(int,float)) and not isinstance(v,bool):
                if not run: start=r
                run.append(v)
            else:
                if len(run)>=3: vecs.append((ws.title,'col',c,start,run))
                run=[]
    for r in range(maxr):
        run=[]; start=None
        for c in range(maxc+1):
            v = grid[r][c] if c<maxc else None
            if isinstance(v,(int,float)) and not isinstance(v,bool):
                if not run: start=c
                run.append(v)
            else:
                if len(run)>=3: vecs.append((ws.title,'row',r,start,run))
                run=[]
def key(v): return round(float(v),4)
found=set()
for (a,b) in itertools.combinations(range(len(vecs)),2):
    A=vecs[a]; B=vecs[b]
    if A[0]==B[0]: continue
    av=[key(x) for x in A[4]]; bv=[key(x) for x in B[4]]
    for i in range(len(av)-2):
        for j in range(len(bv)-2):
            k=0
            while i+k<len(av) and j+k<len(bv) and av[i+k]==bv[j+k]: k+=1
            if k>=3:
                seg=tuple(av[i:i+k])
                # skip trivial sequences (all 1s etc.)
                if len(set(seg))==1: continue
                tag=(A[0],B[0],seg)
                if tag in found: continue
                found.add(tag)
                print(f"{A[0]} {A[1]}{A[2]+1}@{A[3]+1}  <->  {B[0]} {B[1]}{B[2]+1}@{B[3]+1}  len={k}: {seg}")
