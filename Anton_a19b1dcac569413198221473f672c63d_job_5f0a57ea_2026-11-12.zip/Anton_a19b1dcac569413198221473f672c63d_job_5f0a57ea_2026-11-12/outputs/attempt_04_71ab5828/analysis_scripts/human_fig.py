import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
exec(open('/tmp/work/analysis/human.py').read().split('rows=[]')[0])  # loads raw dict and serum vectors
fig,axs=plt.subplots(1,5,figsize=(13,3.6),gridspec_kw={'width_ratios':[1.1,1,1,1,1]})
ax=axs[0]
ser=np.array([d0,d3,d7,d14]).T
for s in ser: ax.plot([0,3,7,14],s,color='#7f7f7f',lw=0.8,alpha=0.8)
ax.plot([0,3,7,14],ser.mean(0),color='k',lw=2)
ax.set_xticks([0,3,7,14]); ax.set_xlabel('day'); ax.set_ylabel('serum creatine (µM)')
ax.set_title('Serum creatine (Fig 7b)\nn=11, 20 g/day',fontsize=8.5)
df=pd.read_csv('/tmp/work/analysis/fig7c_reanalysis.csv')
for ax,(ag) in zip(axs[1:],['collagen','EPI','AA','ADP']):
    m=np.array(raw[(ag,'max')],float)
    lm=np.log2(np.where(m>0,m,np.nan))
    for s in lm: ax.plot([3,7,14],s,color='#9db3c9',lw=0.8,marker='o',ms=2)
    ax.plot([3,7,14],np.nanmean(lm,0),color='#1f4e79',lw=2,marker='s',ms=4)
    ax.axhline(0,color='k',lw=0.7,ls='--')
    ax.set_ylim(-3,4); ax.set_xticks([3,7,14]); ax.set_xlabel('day')
    sub=df[(df.agonist==ag)&(df.param=='max')]
    txt='\n'.join(f"d{int(r.day)}: {r.n_up} up, q={r.q_BH_log_t:.2f}" for _,r in sub.iterrows())
    ax.text(0.03,0.97,txt,transform=ax.transAxes,fontsize=7,va='top')
    name={'EPI':'Epinephrine','AA':'Arachidonic acid','ADP':'ADP','collagen':'Collagen'}[ag]
    ax.set_title(f'{name}: max aggregation\n(log2 fold vs own day 0)',fontsize=8.5)
axs[1].set_ylabel('log2 fold change vs day 0')
fig.suptitle('Figure 4. Human volunteer cohort re-analysed on the log scale within subject (one-sample t on log2 fold change; BH across 36 agonist×parameter×day tests)',fontsize=9,x=0.01,ha='left')
plt.tight_layout(rect=(0,0,1,0.93))
plt.savefig('/tmp/outputs/figures/fig4_human_platelet_function.png',dpi=200)
