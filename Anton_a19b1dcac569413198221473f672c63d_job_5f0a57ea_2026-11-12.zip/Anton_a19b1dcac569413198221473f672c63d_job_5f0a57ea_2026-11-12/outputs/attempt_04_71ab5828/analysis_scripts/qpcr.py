import openpyxl, numpy as np, re
from scipy import stats
wb = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)
def parse(sheetname):
    ws = wb[sheetname]
    maxr, maxc = ws.max_row, ws.max_column
    g=[[ws.cell(r,c).value for c in range(1,maxc+1)] for r in range(1,maxr+1)]
    out={}
    gene=None
    for r in range(maxr):
        a=g[r][0]
        if isinstance(a,str) and a.strip() and not a.startswith('Graphs') and 'Note' not in a and 'Relative' not in a:
            gene=a.strip(); out.setdefault(gene,{})
        for c in range(maxc):
            v=g[r][c]
            if isinstance(v,str) and re.fullmatch(r'ΔCT\d',v.strip()):
                vals=[x for x in g[r][c+1:c+4]]
                if gene: out[gene].setdefault(v.strip(),[]).append((c,vals))
    return out
def analyze(sheetname, labels):
    d=parse(sheetname)
    print('=====',sheetname)
    res={}
    for gene,dd in d.items():
        if 'ΔCT1' not in dd: continue
        ref=np.array(dd['ΔCT1'][0][1],float)
        line=f"{gene:8s}"
        for k in sorted(dd):
            if k=='ΔCT1': continue
            for (c,vals) in dd[k]:
                x=np.array(vals,float)
                ddct = x - ref.mean()
                fc = 2**ddct
                t,p = stats.ttest_ind(x,ref)
                lab = labels.get(k,k)
                line += f" | {lab}: FC(mean-ref)={2**(x.mean()-ref.mean()):.2f} p={p:.3g}"
                res.setdefault(lab,[]).append((gene,2**(x.mean()-ref.mean()),p))
        print(line)
    return res
r=analyze('Fig. 2f',{'ΔCT2':'Cre'})
r=analyze('Fig. 3f',{'ΔCT2':'WT+Cre','ΔCT3':'KO veh','ΔCT4':'KO+Cre'})
r=analyze('Fig. 4h',{'ΔCT2':'Cre','ΔCT3':'PCr'})
r=analyze('Fig. 4j',{'ΔCT2':'siCkb','ΔCT3':'Cre+scr','ΔCT4':'Cre+siCkb'})
r=analyze('Fig. 4l',{'ΔCT2':'CKB-OE'})
r=analyze('Fig.6a',{'ΔCT2':'Cre','ΔCT3':'Veh+STAT5i','ΔCT4':'Cre+STAT5i'})
r=analyze('Fig. 6g',{'ΔCT2':'WT+Cre','ΔCT3':'Stat5bKO+Cre'})
r=analyze('Supplementary Fig  4e',{'ΔCT2':'Cre','ΔCT3':'Cre@lipo'})
r=analyze('Supplementary Fig  3c',{'ΔCT2':'Cre'})
