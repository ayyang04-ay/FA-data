import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
exps = [
 # label, panel, veh, cre, note
 ('Fig 1b (model A, gavage)', [2.520141,8.57602,5.014081,7.272389,3.103791,4.642723],[17.69541,11.12241,14.59739,15.33215,13.33241,24.92012],''),
 ('Fig 1f melanoma, sh-scr tumour', [2.140578,1.502691,4.734425,7.259364,3.126361,8.545323],[22.84291,15.37146,9.488901,17.54824,15.27744,15.12845],''),
 ('Fig 1f melanoma, sh-Slc6a8 tumour', [6.003466,4.411222,5.053624,6.501543,7.829754,5.041724],[24.95491,18.75453,17.87032,18.74111,14.50824,14.94675],''),
 ('Fig 1k (model B, gavage)', [8.319681,6.68745,6.825005,8.510771,5.95375,7.149815],[16.15659,17.77848,13.94514,14.72625,13.60751,22.19711],''),
 ('Fig 3i Pf4-Cre;Slc6a8+/+', [1.625608,3.472777,2.979548,1.380526],[10.26911,7.184766,6.895283,7.292994],''),
 ('Fig 6b (no inhibitor)', [2.40749,3.29136,3.73354,2.88635,4.91813],[18.22751,11.13465,13.22011,14.12619,12.57216],'shares 3 mice/arm with Supp 2d'),
 ('Supp 1e', [20.93048,10.07985,21.40961,17.96392,8.86493,18.11365],[36.85549,44.70853,32.98504,21.7761,29.86035,35.14982],''),
 ('Supp 1f', [4.63417,1.88914,3.96406,5.07603],[15.05064,7.87833,11.80125,8.3959],''),
 ('Supp 1g', [12.71673,6.32983,2.37335,2.87336,7.33864,4.71148,18.44746,5.09211,13.20602,2.77306],[26.40104,31.13075,28.30778,18.85539,19.88642,20.182,33.70799,28.21014,27.86664,27.46881],''),
 ('Supp 1i (5% creatine diet)', [9.28809,6.09689,5.54243,8.23514],[29.58684,18.29654,37.02099,19.97352],''),
 ('Supp 1k', [3.92545,4.89002,6.834,5.47712,3.54182,2.29758,3.34705,1.10707,4.79809,1.49747],[8.95981,5.39068,26.46634,6.3208,11.36883,15.59385,11.82212,18.60377,22.62082,6.46744],''),
]
negctl = [
 ('Fig 3i Pf4-Cre;Slc6a8 fl/fl (MK KO)', [2.744861,4.097582,3.688438,3.032604],[4.946393,2.677876,1.955753,1.920411],''),
 ('Fig 6b + STAT5-IN-1 (systemic)', [3.06024,5.40229,4.05584,1.76918,3.87528],[3.23019,4.60251,4.62831,5.68289,4.3144],'same experiment as flagged Fig 6b arms'),
]
transfer = [
 ('Supp 2d creatine-donor vs vehicle-donor PLT', [6.41419,9.50815,9.32084,3.29136,3.73354,2.88635],[25.23738,25.75262,18.04805,11.13465,13.22011,14.12619],'3 mice/arm duplicated from Fig 6b'),
 ('Supp 2d creatine+aspirin-donor vs vehicle-donor PLT', [6.41419,9.50815,9.32084,3.29136,3.73354,2.88635],[5.82668,5.06091,4.03555,0.78587,4.7051,5.74116],'vehicle arm partly duplicated'),
 ('Fig 7g human day-7 vs day-0 donor PLT', [3.14099,4.20225,3.94653,8.48674,3.47001],[8.54542,21.92856,10.49395,10.94653,11.36809],'donor n unknown'),
]
def rom(v,c):
    v=np.array(v); c=np.array(c)
    lr=np.log(c.mean()/v.mean())
    se=np.sqrt(v.var(ddof=1)/(len(v)*v.mean()**2)+c.var(ddof=1)/(len(c)*c.mean()**2))
    return lr,se,len(v),len(c)
rows=[]
for grp,L in [('Creatine vs vehicle (WT hosts)',exps),('Creatine effect with pathway blocked',negctl),('Platelet transfer',transfer)]:
    for lab,v,c,note in L:
        lr,se,nv,nc=rom(v,c)
        rows.append(dict(group=grp,label=lab,n_veh=nv,n_cre=nc,ratio=np.exp(lr),lo=np.exp(lr-1.96*se),hi=np.exp(lr+1.96*se),lr=lr,se=se,note=note))
df=pd.DataFrame(rows)
# random-effects (DerSimonian-Laird) across WT-host experiments, excluding 6b (integrity) and sh-Slc6a8 arm (same experiment as scr) 
sel=df[(df.group=='Creatine vs vehicle (WT hosts)')]
def dl(s):
    w=1/s.se**2; fe=(w*s.lr).sum()/w.sum(); Q=(w*(s.lr-fe)**2).sum(); k=len(s)
    tau2=max(0,(Q-(k-1))/(w.sum()-(w**2).sum()/w.sum()))
    wr=1/(s.se**2+tau2); re=(wr*s.lr).sum()/wr.sum(); sere=np.sqrt(1/wr.sum())
    I2=max(0,(Q-(k-1))/Q) if Q>0 else 0
    return np.exp(re),np.exp(re-1.96*sere),np.exp(re+1.96*sere),tau2,I2,k
for name,s in [('all WT-host experiments',sel),('excluding Fig 6b',sel[~sel.label.str.contains('6b')])]:
    r=dl(s); print(name,'pooled ratio %.2f (95%% CI %.2f-%.2f) tau2 %.3f I2 %.2f k=%d'%r)
pd.set_option('display.width',200)
print(df[['group','label','n_veh','n_cre','ratio','lo','hi','note']].round(2).to_string(index=False))
df.to_csv('/tmp/work/analysis/forest_burden.csv',index=False)
# plot
fig,ax=plt.subplots(figsize=(8.5,7.2))
ylabels=[];y=0;yt=[]
colors={'Creatine vs vehicle (WT hosts)':'#1f4e79','Creatine effect with pathway blocked':'#7f7f7f','Platelet transfer':'#b35900'}
for grp in ['Creatine vs vehicle (WT hosts)','Creatine effect with pathway blocked','Platelet transfer']:
    s=df[df.group==grp]
    ax.text(0.26,y-0.1,grp,fontsize=9,fontweight='bold',va='bottom')
    y-=1
    for _,r in s.iterrows():
        mk='o' if not r.note else 'D'
        ax.errorbar(r.ratio,y,xerr=[[r.ratio-r.lo],[r.hi-r.ratio]],fmt=mk,color=colors[grp],ms=5,capsize=2)
        ax.text(0.26,y,f"{r.label} (n={r.n_veh}/{r.n_cre})" + (" *" if r.note else ""),fontsize=7.5,va='center')
        ax.text(9.0,y,f"{r.ratio:.2f} ({r.lo:.2f}-{r.hi:.2f})",fontsize=7.5,va='center')
        y-=1
    y-=0.4
r=dl(sel[~sel.label.str.contains('6b')])
ax.errorbar(r[0],y,xerr=[[r[0]-r[1]],[r[2]-r[0]]],fmt='s',color='black',ms=7,capsize=3)
ax.text(0.26,y,'Pooled, WT hosts (random effects, excl. Fig 6b)',fontsize=8,fontweight='bold',va='center')
ax.text(9.0,y,f"{r[0]:.2f} ({r[1]:.2f}-{r[2]:.2f})",fontsize=7.5,va='center',fontweight='bold')
ax.axvline(1,color='grey',lw=0.8,ls='--')
ax.set_xscale('log'); ax.set_xlim(0.25,20); ax.set_ylim(y-1,1)
ax.set_yticks([]); ax.set_xticks([0.5,1,2,4,8]); ax.set_xticklabels(['0.5','1','2','4','8'])
ax.set_xlabel('Ratio of mean lung metastatic burden, creatine / vehicle (95% CI, log scale)')
ax.set_title('Creatine effect on lung metastatic burden across the CRE-MK-01 package',fontsize=10)
ax.text(0.26,y-0.8,'* panel with a data-integrity flag (see Section 4); diamonds mark flagged rows',fontsize=7)
for s in ['top','right','left']: ax.spines[s].set_visible(False)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/fig1_forest_metastatic_burden.png',dpi=200)
