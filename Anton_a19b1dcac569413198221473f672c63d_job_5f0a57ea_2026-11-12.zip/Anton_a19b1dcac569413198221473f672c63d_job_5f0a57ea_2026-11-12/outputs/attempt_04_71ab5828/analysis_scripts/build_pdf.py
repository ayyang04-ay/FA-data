import re, os, sys
import matplotlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image,
                                PageBreak, KeepTogether, HRFlowable, ListFlowable, ListItem)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping
from PIL import Image as PILImage

FD = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
pdfmetrics.registerFont(TTFont('DV', os.path.join(FD, 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B', os.path.join(FD, 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DV-I', os.path.join(FD, 'DejaVuSans-Oblique.ttf')))
pdfmetrics.registerFont(TTFont('DV-BI', os.path.join(FD, 'DejaVuSans-BoldOblique.ttf')))
pdfmetrics.registerFont(TTFont('DVM', os.path.join(FD, 'DejaVuSansMono.ttf')))
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DV-B'); addMapping('DV', 0, 1, 'DV-I'); addMapping('DV', 1, 1, 'DV-BI')

SRC = sys.argv[1]
OUT = sys.argv[2]
BASE = '/tmp/outputs'

body = ParagraphStyle('body', fontName='DV', fontSize=8.6, leading=11.4, spaceAfter=4, alignment=TA_LEFT)
lead = ParagraphStyle('lead', parent=body, fontSize=10, leading=13.5, spaceAfter=8, textColor=colors.HexColor('#102a43'),
                      backColor=colors.HexColor('#e8f0f8'), borderColor=colors.HexColor('#1f4e79'), borderWidth=0.8,
                      borderPadding=6)
h1 = ParagraphStyle('h1', fontName='DV-B', fontSize=14, leading=17, spaceBefore=8, spaceAfter=6, textColor=colors.HexColor('#1f4e79'))
h2 = ParagraphStyle('h2', fontName='DV-B', fontSize=11.5, leading=14, spaceBefore=9, spaceAfter=4, textColor=colors.HexColor('#1f4e79'))
h3 = ParagraphStyle('h3', fontName='DV-B', fontSize=9.6, leading=12, spaceBefore=7, spaceAfter=3, textColor=colors.HexColor('#243b53'))
cell = ParagraphStyle('cell', fontName='DV', fontSize=6.9, leading=8.4)
cellh = ParagraphStyle('cellh', fontName='DV-B', fontSize=6.9, leading=8.4, textColor=colors.white)
bullet = ParagraphStyle('bullet', parent=body, leftIndent=0, spaceAfter=1.5)


def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'`([^`]+)`', r'<font name="DVM" size="7.6">\1</font>', t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'<i>\1</i>', t)
    t = re.sub(r'\^([^\^\s][^\^]*?)\^', r'<super>\1</super>', t)
    return t


def para(text, style=body):
    return Paragraph(inline(text), style)


def make_table(rows):
    header = [c.strip() for c in rows[0].strip().strip('|').split('|')]
    data = []
    for r in rows[2:]:
        cells = [c.strip() for c in r.strip().strip('|').split('|')]
        data.append(cells)
    ncol = len(header)
    # column widths by content length
    lens = [max([len(header[i])] + [len(d[i]) if i < len(d) else 0 for d in data]) for i in range(ncol)]
    total_w = A4[0] - 30 * mm
    lens = [min(max(l, 8), 160) for l in lens]
    s = sum(lens)
    widths = [total_w * l / s for l in lens]
    minw = 14 * mm
    for i in range(ncol):
        if widths[i] < minw:
            widths[i] = minw
    sc = total_w / sum(widths)
    widths = [w * sc for w in widths]
    tdata = [[Paragraph(inline(h), cellh) for h in header]]
    for d in data:
        d = d + [''] * (ncol - len(d))
        tdata.append([Paragraph(inline(c), cell) for c in d])
    t = Table(tdata, colWidths=widths, repeatRows=1)
    st = [('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1f4e79')),
          ('VALIGN', (0, 0), (-1, -1), 'TOP'),
          ('GRID', (0, 0), (-1, -1), 0.3, colors.HexColor('#9fb3c8')),
          ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
          ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]
    for i in range(1, len(tdata)):
        if i % 2 == 0:
            st.append(('BACKGROUND', (0, i), (-1, i), colors.HexColor('#f0f4f8')))
    t.setStyle(TableStyle(st))
    return t


def make_image(path):
    full = os.path.join(BASE, path)
    im = PILImage.open(full)
    w, h = im.size
    maxw = A4[0] - 30 * mm
    maxh = A4[1] - 45 * mm
    sc = min(maxw / w, maxh / h)
    return Image(full, width=w * sc, height=h * sc)


lines = open(SRC, encoding='utf-8').read().split('\n')
story = []
i = 0
first = True
list_buf = []   # (level, ordered, text)


def flush_list():
    global list_buf
    if not list_buf:
        return
    # build nested list flowables
    def build(items, level):
        out = []
        j = 0
        while j < len(items):
            lv, ordered, txt = items[j]
            if lv == level:
                sub = []
                k = j + 1
                while k < len(items) and items[k][0] > level:
                    sub.append(items[k]); k += 1
                flows = [Paragraph(inline(txt), bullet)]
                if sub:
                    flows.append(build(sub, level + 1))
                out.append(ListItem(flows, leftIndent=12 + 10 * level))
                j = k
            else:
                j += 1
        ordered = items[0][1]
        if ordered:
            return ListFlowable(out, bulletType='1', bulletFontName='DV', bulletFontSize=8.2, leftIndent=12 + 10 * level)
        return ListFlowable(out, bulletType='bullet', start='•' if level == 0 else '–', bulletFontName='DV',
                            bulletFontSize=8, leftIndent=12 + 10 * level)
    story.append(build(list_buf, 0))
    story.append(Spacer(1, 3))
    list_buf = []


while i < len(lines):
    ln = lines[i]
    s = ln.rstrip()
    m_list = re.match(r'^(\s*)(- |\d+\. )(.*)$', s)
    if m_list and not s.strip().startswith('---'):
        indent = len(m_list.group(1)) // 2
        ordered = m_list.group(2)[0].isdigit()
        text = m_list.group(3)
        # continuation lines
        j = i + 1
        while j < len(lines) and lines[j].startswith(' ' * (len(m_list.group(1)) + 3)) and not re.match(r'^\s*(- |\d+\. )', lines[j]):
            text += ' ' + lines[j].strip(); j += 1
        list_buf.append((indent, ordered, text))
        i = j
        continue
    else:
        if s.strip() == '' and list_buf:
            # allow blank lines inside lists only if next line continues the list
            nxt = lines[i + 1] if i + 1 < len(lines) else ''
            if re.match(r'^\s*(- |\d+\. )', nxt):
                i += 1
                continue
        flush_list()
    if s.strip() == '':
        i += 1
        continue
    if first and s.startswith('**'):
        story.append(Paragraph(inline(s), lead))
        first = False
        i += 1
        continue
    if s.startswith('# '):
        story.append(Paragraph(inline(s[2:]), h1)); i += 1; continue
    if s.startswith('## '):
        story.append(Paragraph(inline(s[3:]), h2)); i += 1; continue
    if s.startswith('### '):
        story.append(Paragraph(inline(s[4:]), h3)); i += 1; continue
    if s.strip() == '---':
        story.append(HRFlowable(width='100%', thickness=0.6, color=colors.HexColor('#9fb3c8'), spaceBefore=4, spaceAfter=4)); i += 1; continue
    m = re.match(r'!\[[^\]]*\]\(([^)]+)\)', s.strip())
    if m:
        story.append(Spacer(1, 3)); story.append(make_image(m.group(1))); story.append(Spacer(1, 5)); i += 1; continue
    if s.startswith('|'):
        rows = []
        while i < len(lines) and lines[i].startswith('|'):
            rows.append(lines[i]); i += 1
        story.append(make_table(rows)); story.append(Spacer(1, 6))
        continue
    # paragraph (merge following plain lines)
    text = s
    j = i + 1
    while j < len(lines) and lines[j].strip() and not re.match(r'^(#|\||!\[|- |\d+\. |---|\s+- )', lines[j]):
        text += ' ' + lines[j].strip(); j += 1
    story.append(para(text))
    i = j
flush_list()


def on_page(canvas, doc):
    canvas.saveState()
    canvas.setFont('DV', 7)
    canvas.setFillColor(colors.HexColor('#627d98'))
    canvas.drawString(15 * mm, 8 * mm, 'CRE-MK-01 validation proposal - derived solely from the CRE-MK-01 data package')
    canvas.drawRightString(A4[0] - 15 * mm, 8 * mm, f'page {doc.page}')
    canvas.restoreState()


doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm, bottomMargin=15 * mm,
                        title='CRE-MK-01 validation proposal', author='Portfolio analysis')
doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
print('built', OUT)
