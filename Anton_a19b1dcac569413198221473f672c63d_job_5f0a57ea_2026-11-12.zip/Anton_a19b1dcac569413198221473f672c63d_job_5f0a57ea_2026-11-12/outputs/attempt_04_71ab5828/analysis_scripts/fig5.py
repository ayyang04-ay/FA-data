import numpy as np, pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
from scipy import stats
d5e={'veh':{'WT':[0.65945,0.67477,0.81422],'S127A':[0.67288,0.8528,0.82823],'3A':[0.70079,0.7988,0.82293],'S127D':[1.15462,0.93917,1.04193]},
     'cre':{'WT':[1.02728,0.931,1.03384],'S127A':[0.7966,0.87167,0.81992],'3A':[0.71446,0.69881,0.79339],'S127D':[0.99162,0.94417,1.092]}}
d5f={'veh':{'WT':[0.64808,0.8398,0.77645],'S127A':[0.62936,0.74251,0.78904],'3A':[0.63533,0.88838,0.76247],'S127D':[0.96733,1.00452,1.08384]},
     'cre':{'WT':[0.94163,1.10559,0.85107],'S127A':[0.65785,0.73446,0.50978],'3A':[0.64766,0.7125,0.6539],'S127D':[1.0345,1.06624,0.88034]}}
for name,d in [('5e',d5e),('5f',d5f)]:
    rows=[(t,m,v) for t in d for m in d[t] for v in d[t][m]]
    df=pd.DataFrame(rows,columns=['treat','mut','y'])
    print('==',name)
    for m in ['WT','S127A','3A','S127D']:
        a=d['veh'][m]; b=d['cre'][m]
        print(f"  {m}: veh {np.mean(a):.3f} -> cre {np.mean(b):.3f}  ratio {np.mean(b)/np.mean(a):.2f}  t-test p={stats.ttest_ind(b,a).pvalue:.3g}")
    sub=df[df.mut.isin(['WT','S127A'])]
    t=anova_lm(smf.ols('y~C(treat)*C(mut)',sub).fit(),typ=2)
    print('  WT vs S127A x treatment interaction p =', round(t.loc['C(treat):C(mut)','PR(>F)'],4))
