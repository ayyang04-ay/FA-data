import openpyxl, re, collections, math
wb = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)
occ = collections.defaultdict(list)
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            v=c.value
            if isinstance(v,(int,float)) and not isinstance(v,bool):
                occ[v].append((ws.title, c.coordinate))
# consider values with enough precision: non-integers with >=4 significant decimals
def sig(v):
    s=repr(float(v))
    if 'e' in s: return 10
    intpart,_,dec = s.partition('.')
    dec=dec.rstrip('0')
    return len(intpart.lstrip('-').lstrip('0'))+len(dec)
rows=[]
for v,locs in occ.items():
    if len(locs)<2: continue
    sheets=set(l[0] for l in locs)
    if isinstance(v,float) and sig(v)>=5:
        rows.append((v,locs))
rows.sort(key=lambda x:(-len(set(l[0] for l in x[1])), x[0]))
for v,locs in rows:
    sheets=set(l[0] for l in locs)
    print(v, len(locs), 'sheets:',len(sheets), locs[:8])
