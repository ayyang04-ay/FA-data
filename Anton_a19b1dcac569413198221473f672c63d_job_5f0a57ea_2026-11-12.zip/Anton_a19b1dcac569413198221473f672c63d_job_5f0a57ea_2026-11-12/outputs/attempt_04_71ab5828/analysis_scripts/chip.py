import numpy as np, pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
from scipy import stats
sets={
'P2ry12':{'Exon':([5.2556,2.06173,6.65231],[3.95549,8.36205,5.51689]),'2K':([1.89062,1.44779,2.87559],[8.62698,10.33063,11.03379]),'1K':([2.77763,3.34929,2.44334],[12.7185,12.85142,14.25955]),'0.2K':([0.44253,0.63677,0.68012],[6.67541,8.30429,6.29347])},
'Gp6':{'Exon':([8.93121,11.50235,6.93481],[8.42021,12.24275,5.79117]),'2K':([13.67867,17.4343,17.4343],[9.34281,12.85142,16.72409]),'1K':([4.41942,3.24643,4.73661],[15.55015,12.67449,18.30107]),'0.2K':([3.60215,2.24056,4.51228],[8.62698,9.40779,11.74403])},
'Rab4a':{'Exon':([11.66291,13.77381,7.5363],[7.08052,6.93481,10.22378]),'2K':([4.32847,6.56073,12.15819],[12.28526,11.11053,8.83883]),'1K':([9.60547,10.51121,7.12977],[20.02675,34.62774,20.09627]),'0.2K':([8.80826,6.98304,6.60636],[48.97101,51.05061,23.00469])},
}
for g,d in sets.items():
    rows=[(reg,t,v) for reg,(a,b) in d.items() for t,x in [('veh',a),('cre',b)] for v in x]
    df=pd.DataFrame(rows,columns=['reg','treat','y'])
    m=smf.ols('y~C(reg)*C(treat)',df).fit()
    mse=m.mse_resid; dfres=m.df_resid
    print('==',g,'resid df',dfres)
    for reg,(a,b) in d.items():
        diff=np.mean(a)-np.mean(b); se=np.sqrt(mse*(2/3)); t=diff/se
        p=2*stats.t.sf(abs(t),dfres); p_sidak=1-(1-p)**4
        print(f"  {reg}: veh {np.mean(a):.2f} cre {np.mean(b):.2f} fold {np.mean(b)/np.mean(a):.1f} diff {diff:.3f} Sidak p={p_sidak:.3g}")
    # log-scale check
    df['ly']=np.log(df.y)
    m2=smf.ols('ly~C(reg)*C(treat)',df).fit()
    print('  log-scale interaction p', anova_lm(m2,typ=2).loc['C(reg):C(treat)','PR(>F)'].round(4))
# % input grid check
for v in [8.62698,12.85142,17.4343,6.934809]:
    print(v, 'implied dCt', round(-np.log2(v/100),4))
