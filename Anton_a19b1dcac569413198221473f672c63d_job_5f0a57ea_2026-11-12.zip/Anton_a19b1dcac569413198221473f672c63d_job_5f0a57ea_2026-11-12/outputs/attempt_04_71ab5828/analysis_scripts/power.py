import numpy as np, pandas as pd
from scipy import stats
df=pd.read_csv('/tmp/work/analysis/forest_burden.csv')
# within-group SD on log scale, per experiment arm, from raw
raw = {
 '1b':([2.520141,8.57602,5.014081,7.272389,3.103791,4.642723],[17.69541,11.12241,14.59739,15.33215,13.33241,24.92012]),
 '1f_scr':([2.140578,1.502691,4.734425,7.259364,3.126361,8.545323],[22.84291,15.37146,9.488901,17.54824,15.27744,15.12845]),
 '1k':([8.319681,6.68745,6.825005,8.510771,5.95375,7.149815],[16.15659,17.77848,13.94514,14.72625,13.60751,22.19711]),
 '3i_WT':([1.625608,3.472777,2.979548,1.380526],[10.26911,7.184766,6.895283,7.292994]),
 '3i_KO':([2.744861,4.097582,3.688438,3.032604],[4.946393,2.677876,1.955753,1.920411]),
 'S1e':([20.93048,10.07985,21.40961,17.96392,8.86493,18.11365],[36.85549,44.70853,32.98504,21.7761,29.86035,35.14982]),
 'S1f':([4.63417,1.88914,3.96406,5.07603],[15.05064,7.87833,11.80125,8.3959]),
 'S1g':([12.71673,6.32983,2.37335,2.87336,7.33864,4.71148,18.44746,5.09211,13.20602,2.77306],[26.40104,31.13075,28.30778,18.85539,19.88642,20.182,33.70799,28.21014,27.86664,27.46881]),
 'S1i':([9.28809,6.09689,5.54243,8.23514],[29.58684,18.29654,37.02099,19.97352]),
 'S1k':([3.92545,4.89002,6.834,5.47712,3.54182,2.29758,3.34705,1.10707,4.79809,1.49747],[8.95981,5.39068,26.46634,6.3208,11.36883,15.59385,11.82212,18.60377,22.62082,6.46744]),
}
sds=[]; 
for k,(v,c) in raw.items():
    for arm,x in [('veh',v),('cre',c)]:
        lx=np.log(x); sds.append((k,arm,len(x),lx.std(ddof=1)))
s=pd.DataFrame(sds,columns=['exp','arm','n','sd_log'])
print(s.round(3).to_string(index=False))
pooled=np.sqrt(((s.n-1)*s.sd_log**2).sum()/(s.n-1).sum())
print('pooled within-group SD of log burden:',round(pooled,3),' median',round(s.sd_log.median(),3),' 75th pct',round(s.sd_log.quantile(0.75),3))
za=stats.norm.isf(0.025)
def n_interaction(delta,sd,power=0.9):
    zb=stats.norm.ppf(power)
    # interaction contrast var = sd^2*(4/n)
    return int(np.ceil(4*sd**2*(za+zb)**2/delta**2))
def n_main(delta,sd,power=0.9):
    zb=stats.norm.ppf(power); return int(np.ceil(2*sd**2*(za+zb)**2/delta**2))
for sd in [pooled, 0.5, 0.6]:
    print(f"SD={sd:.2f}: main effect ratio 3 (delta={np.log(3):.2f}) n/group={n_main(np.log(3),sd)}; ratio 2 n/group={n_main(np.log(2),sd)}; ratio 1.5 n/group={n_main(np.log(1.5),sd)}")
    for att in [1.0,0.75,0.5]:
        d=att*np.log(2.9)
        print(f"   interaction: KO abolishes {int(att*100)}% of log-effect (WT ratio 2.9) n/cell (90% power) = {n_interaction(d,sd,0.9)}; 80% power = {n_interaction(d,sd,0.8)}")
    # equivalence-type bound: upper 95% (one-sided) of KO creatine effect < log(1.5) when true=0
    zb=stats.norm.ppf(0.9); z1=stats.norm.isf(0.05)
    n=int(np.ceil(2*sd**2*(z1+zb)**2/np.log(1.5)**2))
    print(f"   KO creatine effect upper 95% bound < 1.5-fold (true=1.0), 90% power: n/group={n}")
# survival events
for hr in [2.0,2.3,2.9]:
    for power in [0.8,0.9]:
        zb=stats.norm.ppf(power)
        d=4*(za+zb)**2/np.log(hr)**2
        print(f"log-rank HR {hr} power {power}: total events {int(np.ceil(d))}")
