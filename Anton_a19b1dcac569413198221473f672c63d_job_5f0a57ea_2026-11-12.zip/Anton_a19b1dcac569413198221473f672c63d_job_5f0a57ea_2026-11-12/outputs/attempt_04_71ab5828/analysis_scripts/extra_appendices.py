import numpy as np, pandas as pd, openpyxl, re
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
from scipy import stats
# ---------- F: interaction tests
def inter(panel, outcome, data, log):
    rows=[]
    for (a,b),vals in data.items():
        for v in vals: rows.append(dict(factor=a,treat=b,y=np.log(v) if log else v))
    df=pd.DataFrame(rows)
    t=anova_lm(smf.ols('y~C(factor)*C(treat)',df).fit(),typ=2)
    p=t.loc['C(factor):C(treat)','PR(>F)']
    res=dict(panel=panel,outcome=outcome,scale='log' if log else 'raw',interaction_p=float(f"{p:.3g}"))
    for f in df.factor.unique():
        s=df[df.factor==f]
        c=s[s.treat=='cre'].y.mean(); v=s[s.treat=='veh'].y.mean()
        res[f'creatine_effect_{f}']=round(np.exp(c-v),3) if log else round(c-v,4)
    return res
D=[]
f3i_b={('ctrl','veh'):[1.625608,3.472777,2.979548,1.380526],('ctrl','cre'):[10.26911,7.184766,6.895283,7.292994],('KO','veh'):[2.744861,4.097582,3.688438,3.032604],('KO','cre'):[4.946393,2.677876,1.955753,1.920411]}
f3i_f={('ctrl','veh'):[18,29,33,39],('ctrl','cre'):[59,49,63,55],('KO','veh'):[29,21,34,22],('KO','cre'):[36,31,18,14]}
f3i_l={('ctrl','veh'):[0.2086,0.2052,0.2121,0.1991],('ctrl','cre'):[0.2519,0.258,0.2406,0.244],('KO','veh'):[0.2173,0.2282,0.2311,0.2106],('KO','cre'):[0.2238,0.2235,0.2185,0.234]}
f6b_b={('none','veh'):[2.40749,3.29136,3.73354,2.88635,4.91813],('none','cre'):[18.22751,11.13465,13.22011,14.12619,12.57216],('STAT5i','veh'):[3.06024,5.40229,4.05584,1.76918,3.87528],('STAT5i','cre'):[3.23019,4.60251,4.62831,5.68289,4.3144]}
f6b_f={('none','veh'):[23,37,25,33,33],('none','cre'):[51,53,62,47,78],('STAT5i','veh'):[24,32,38,20,34],('STAT5i','cre'):[28,33,30,20,25]}
f1f_b={('shScr','veh'):[2.140578,1.502691,4.734425,7.259364,3.126361,8.545323],('shScr','cre'):[22.84291,15.37146,9.488901,17.54824,15.27744,15.12845],('shSlc6a8','veh'):[6.003466,4.411222,5.053624,6.501543,7.829754,5.041724],('shSlc6a8','cre'):[24.95491,18.75453,17.87032,18.74111,14.50824,14.94675]}
f1f_f={('shScr','veh'):[8,6,7,18,10,15],('shScr','cre'):[18,20,20,44,32,30],('shSlc6a8','veh'):[11,9,12,15,21,15],('shSlc6a8','cre'):[22,36,28,35,29,35]}
f3d={'ADP':{('ctrl','veh'):[64,62,64],('ctrl','cre'):[70,72,70],('KO','veh'):[54,56,52],('KO','cre'):[30,32,32]},
     'collagen':{('ctrl','veh'):[64,64,66],('ctrl','cre'):[76,76,78],('KO','veh'):[60,62,60],('KO','cre'):[52,50,50]},
     'thrombin':{('ctrl','veh'):[60,62,62],('ctrl','cre'):[76,74,74],('KO','veh'):[46,44,46],('KO','cre'):[34,36,36]}}
D+= [inter('Fig 3i (MK Slc6a8 KO)','metastatic burden',f3i_b,True), inter('Fig 3i (MK Slc6a8 KO)','metastatic burden',f3i_b,False),
     inter('Fig 3i (MK Slc6a8 KO)','foci',f3i_f,False), inter('Fig 3i (MK Slc6a8 KO)','lung weight',f3i_l,False),
     inter('Fig 6b (STAT5-IN-1) [flag I-1]','metastatic burden',f6b_b,True), inter('Fig 6b (STAT5-IN-1) [flag I-1]','foci',f6b_f,False),
     inter('Fig 1f (tumour Slc6a8 KD)','metastatic burden',f1f_b,True), inter('Fig 1f (tumour Slc6a8 KD)','foci',f1f_f,False)]
for ag,d in f3d.items(): D.append(inter('Fig 3d (MK Slc6a8 KO)',f'aggregation {ag} (%)',d,False))
pd.DataFrame(D).to_csv('/tmp/outputs/appendix_F_interaction_tests.csv',index=False)
# ---------- G: MK qPCR re-analysis
wb = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)
def parse(sheetname):
    ws = wb[sheetname]; maxr, maxc = ws.max_row, ws.max_column
    g=[[ws.cell(r,c).value for c in range(1,maxc+1)] for r in range(1,maxr+1)]
    out={}; gene=None
    for r in range(maxr):
        a=g[r][0]
        if isinstance(a,str) and a.strip() and not a.startswith('Graphs') and 'Note' not in a and 'Relative' not in a:
            gene=a.strip(); out.setdefault(gene,{})
        for c in range(maxc):
            v=g[r][c]
            if isinstance(v,str) and re.fullmatch(r'ΔCT\d',v.strip()) and gene:
                out[gene].setdefault(v.strip(),[]).append(g[r][c+1:c+4])
    return out
panels={'Fig. 2f':('vehicle',{'ΔCT2':'creatine'}),
        'Fig. 3f':('Pf4-Cre;Slc6a8+/+ vehicle',{'ΔCT2':'Slc6a8+/+ creatine','ΔCT3':'Slc6a8 fl/fl vehicle','ΔCT4':'Slc6a8 fl/fl creatine'}),
        'Fig. 4h':('control',{'ΔCT2':'creatine','ΔCT3':'phosphocreatine'}),
        'Fig. 4j':('control + si-scrambled',{'ΔCT2':'control + si-Ckb','ΔCT3':'creatine + si-scrambled','ΔCT4':'creatine + si-Ckb'}),
        'Fig. 4l':('CKB-EV',{'ΔCT2':'CKB-OE'}),
        'Fig.6a':('vehicle',{'ΔCT2':'creatine','ΔCT3':'vehicle + STAT5 inhibitor','ΔCT4':'creatine + STAT5 inhibitor'}),
        'Fig. 6g':('WT vehicle',{'ΔCT2':'WT creatine','ΔCT3':'Pf4-iCre;Stat5b fl/fl creatine'}),
        'Supplementary Fig  4e':('Slc6a8-null MKs control',{'ΔCT2':'free creatine','ΔCT3':'liposomal creatine'}),
        'Supplementary Fig  3c':('vehicle',{'ΔCT2':'creatine'}),
        'Fig. 4e':('vehicle',{'ΔCT2':'creatine'}),
        'Supplementary Fig  2a':('si/sh-scrambled',{'ΔCT2':'si/sh-Slc6a8'})}
G=[]
for sh,(ref,labs) in panels.items():
    d=parse(sh)
    for gene,dd in d.items():
        if 'ΔCT1' not in dd: continue
        r=np.array(dd['ΔCT1'][0],float)
        for k,lab in labs.items():
            if k not in dd: continue
            x=np.array(dd[k][0],float)
            G.append(dict(panel=sh.replace('Supplementary Fig  ','Supp ').replace('Fig.6a','Fig. 6a'),gene=gene,reference=ref,condition=lab,
                          fold_vs_reference_mean=round(2**(x.mean()-r.mean()),3),t_test_p_on_dCt=float(f"{stats.ttest_ind(x,r).pvalue:.3g}"),n=f"{len(r)}/{len(x)}"))
pd.DataFrame(G).to_csv('/tmp/outputs/appendix_G_MK_qPCR_reanalysis.csv',index=False)
# ---------- H: phosphoproteomics summary
ph=pd.read_excel('/tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx'); ph.columns=['gene','p','q','lfc']
single=np.isclose(ph.p,0.42265,atol=2e-5)
sub=ph[~single]
summ=[('phosphopeptide rows',len(ph)),('unique gene names',ph.gene.nunique()),('exact duplicate rows',int(ph.duplicated().sum())),
      ('minimum q (as supplied)',round(ph.q.min(),4)),('peptides with q<0.05',int((ph.q<0.05).sum())),('peptides with q<0.10',int((ph.q<0.10).sum())),
      ('rows with p = 0.42265 (single-sample detections; Welch t=1, df=2)',int(single.sum())),('rows with p in 0.18-0.20 and abs(logFC)>2',int(((ph.p>0.17)&(ph.p<0.20)&(ph.lfc.abs()>2)).sum())),
      ('rows with abs(logFC)>2',int((ph.lfc.abs()>2).sum())),
      ('p<0.05 among peptides quantified in >=2 samples',int((sub.p<0.05).sum())),('expected under null (5% of those)',round(0.05*len(sub),1)),
      ('p<0.05 among peptides with abs(logFC)<=2',int(((ph.lfc.abs()<=2)&(ph.p<0.05)).sum())),('expected under null',round(0.05*(ph.lfc.abs()<=2).sum(),1)),
      ('conventions screen (FC>=1.2 or <=0.83 [log2], p<0.05) hits',int(((ph.p<0.05)&(ph.lfc.abs()>=np.log2(1.2))).sum())),
      ('Stat5b peptide 1: p / q / logFC / rank','0.00123 / 0.2458 / 5.70 / 17 of 5812'),('Stat5b peptide 2: p / q / logFC','0.471 / 0.488 / 0.49'),
      ('Stat5a peptide: p / q / logFC','0.403 / 0.461 / 0.13')]
pd.DataFrame(summ,columns=['metric','value']).to_csv('/tmp/outputs/appendix_H_phosphoproteomics_summary.csv',index=False)
# ---------- I: forest + survival
fb=pd.read_csv('/tmp/work/analysis/forest_burden.csv')
fb[['group','label','n_veh','n_cre','ratio','lo','hi','note']].round(3).to_csv('/tmp/outputs/appendix_I_metastasis_effect_by_panel.csv',index=False)
print('done')
