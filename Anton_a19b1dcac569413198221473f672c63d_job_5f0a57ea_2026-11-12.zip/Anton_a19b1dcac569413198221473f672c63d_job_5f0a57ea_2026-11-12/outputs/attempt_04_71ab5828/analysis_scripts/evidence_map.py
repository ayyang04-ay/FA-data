import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
col={'strong':'#cfe8cf','moderate':'#fff2b3','weak':'#ffd9b3','compromised':'#f4b6b6'}
edge={'strong':'#2e7d32','moderate':'#b59b00','weak':'#d9822b','compromised':'#c62828'}
nodes=[
 ('Exogenous creatine (gavage or 5% diet)\nSerum creatine ↑ 2.4–2.9× in mice (Supp 1d, 1h, Fig 3b); ↑ 3.5× in humans on 20 g/day (Fig 7b)\nhuman loading-dose levels (~155–160 µM) approach the mouse levels that drove metastasis (~180–240 µM)',
  'strong','Exposure bridge'),
 ('Tumour-cell SLC6A8: NOT required\nsh-Slc6a8 tumours respond like controls (Fig 1f; interaction p=0.44)\ncaveat: knock-down only partial at protein level (Supp 2a blot)',
  'moderate','Host, not tumour'),
 ('Megakaryocyte SLC6A8 (Pf4-Cre deletion)  ◀ PRIMARY\nabolishes creatine-driven metastasis (Fig 3i; interaction p<0.001, n=4/group),\nMK creatine accumulation, transcript program, α-granules, aggregation gain;\nliposomal creatine bypass restores the program in SLC6A8-null MKs (Supp 4e)',
  'strong','Gate: strongest causal node\n(single n=4 study)'),
 ('CKB (creatine kinase B) in MKs\n↑ with creatine; si-Ckb blocks and CKB-OE mimics the program in vitro;\nno in vivo test; kinase activity on STAT5B = one pan-phospho blot (Supp 6d)',
  'weak','In vitro only'),
 ('STAT5B in MKs  ◀ BACKUP 2 (mechanistic)\nphosphoproteomics not significant (q=0.25); canonical pY694/699 absent (Supp 6a);\nS127-dependent pan-phospho signal +28–39% (n=3); ChIP ↑ at promoters;\nsystemic STAT5-IN-1 blocks metastasis (Fig 6b: duplicate-animal flag);\nMK-Stat5b KO blunts transcripts, but no metastasis test and no KO-vehicle arm',
  'compromised','Plausible, unproven'),
 ('Platelet-activation program  ◀ BACKUP 1 (translational; GP6/GPVI lead)\nMK transcripts ↑ (Gp6 2.8–42×, 6 experiments); MK GP6/P2RY12 protein ↑ (mouse platelet protein: mixed, unquantified);\nhuman platelets GP6 ↑ (n=4) and collagen/epinephrine aggregation ↑ (n=11)\nplatelet counts/indices unchanged in every dataset (mouse and human)',
  'moderate','Best human bridge'),
 ('Functional platelet priming → early tumour-cell retention\nmouse aggregation ↑ (n=3), α-granules ↑ (fields as n), lung retention 6–24 h ↑ 1.5–2.8×;\ncreatine-primed platelets transfer the phenotype (Supp 2d flagged; Fig 7g donors unreported)',
  'moderate','Mechanism of harm'),
 ('Outcome: lung metastasis ↑ (pooled ratio 2.9, 95% CI 2.5–3.3; 10 comparisons, 9 experiments)\nsurvival ↓ (HR 2.3–2.9; 2 cohorts). Not blinded; no sample-size calculation',
  'strong','Phenotype'),
]
fig,ax=plt.subplots(figsize=(10,10.2))
ax.set_xlim(0,10); ax.set_ylim(-0.2,len(nodes)*1.25+1.0); ax.axis('off')
y=len(nodes)*1.25+0.2
for i,(txt,grade,tag) in enumerate(nodes):
    h=0.98
    box=FancyBboxPatch((0.2,y-h),7.6,h,boxstyle='round,pad=0.02,rounding_size=0.08',fc=col[grade],ec=edge[grade],lw=1.4)
    ax.add_patch(box)
    ax.text(0.35,y-h/2,txt,fontsize=7.6,va='center',ha='left')
    ax.text(8.05,y-h/2,f"{tag}\n[{grade}]",fontsize=8,va='center',ha='left',color=edge[grade],fontweight='bold')
    if i<len(nodes)-1:
        ax.annotate('',xy=(4.0,y-h-0.24),xytext=(4.0,y-h),arrowprops=dict(arrowstyle='-|>',color='#555555',lw=1.2))
    y-=1.25
ax.set_title('Figure 2. Evidence map for the creatine → megakaryocyte → platelet → metastasis chain (grades reflect the data package only)',fontsize=9,loc='left')
leg=[('strong','replicated in vivo and/or genetic, concordant readouts'),('moderate','in vivo but single/underpowered, or partial controls'),('weak','in vitro only or single image'),('compromised','integrity flag or key readouts null/absent')]
top=len(nodes)*1.25+0.75
for j,(g,t) in enumerate(leg):
    xx=0.2+(j%2)*4.9; yy=top-(j//2)*0.32
    ax.add_patch(FancyBboxPatch((xx,yy-0.1),0.25,0.2,boxstyle='round,pad=0.01',fc=col[g],ec=edge[g]))
    ax.text(xx+0.35,yy,f"{g}: {t}",fontsize=7,va='center')
plt.tight_layout()
plt.savefig('/tmp/outputs/figures/fig2_evidence_map.png',dpi=200)
