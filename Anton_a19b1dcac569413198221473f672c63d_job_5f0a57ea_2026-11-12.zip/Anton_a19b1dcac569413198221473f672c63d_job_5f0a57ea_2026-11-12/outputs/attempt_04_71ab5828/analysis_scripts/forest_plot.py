import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
df=pd.read_csv('/tmp/work/analysis/forest_burden.csv')
df['note']=df['note'].fillna('')
def dl(s):
    w=1/s.se**2; fe=(w*s.lr).sum()/w.sum(); Q=(w*(s.lr-fe)**2).sum(); k=len(s)
    tau2=max(0,(Q-(k-1))/(w.sum()-(w**2).sum()/w.sum()))
    wr=1/(s.se**2+tau2); re=(wr*s.lr).sum()/wr.sum(); sere=np.sqrt(1/wr.sum())
    return np.exp(re),np.exp(re-1.96*sere),np.exp(re+1.96*sere)
fig=plt.figure(figsize=(10,7.6))
ax=fig.add_axes([0.43,0.13,0.40,0.81])
colors={'Creatine vs vehicle (WT hosts)':'#1f4e79','Creatine effect with pathway blocked':'#7f7f7f','Platelet transfer':'#b35900'}
y=0
def lab(yv,text,bold=False,size=8):
    fig.text(0.01, ax.transData.transform((1,yv))[1]/fig.dpi/fig.get_size_inches()[1], text, fontsize=size, fontweight='bold' if bold else 'normal', va='center')
rows=[]
for grp in ['Creatine vs vehicle (WT hosts)','Creatine effect with pathway blocked','Platelet transfer']:
    s=df[df.group==grp]
    rows.append(('hdr',grp,y)); y-=1
    for _,r in s.iterrows():
        rows.append(('row',r,y)); y-=1
    y-=0.4
sel=df[(df.group=='Creatine vs vehicle (WT hosts)')&(~df.label.str.contains('6b'))]
pooled=dl(sel)
rows.append(('pool',pooled,y))
ax.set_ylim(y-0.8,0.8)
ax.set_xscale('log'); ax.set_xlim(0.3,9)
ax.axvline(1,color='grey',lw=0.8,ls='--')
for kind,obj,yy in rows:
    if kind=='row':
        r=obj
        integrity = ('duplicated' in r.note) or ('flagged' in r.note) or ('shares' in r.note)
        design = ('donor n unknown' in r.note)
        mk='D' if integrity else ('^' if design else 'o')
        ax.errorbar(r.ratio,yy,xerr=[[r.ratio-r.lo],[r.hi-r.ratio]],fmt=mk,color=colors[r.group],ms=5,capsize=2)
ax.errorbar(pooled[0],rows[-1][2],xerr=[[pooled[0]-pooled[1]],[pooled[2]-pooled[0]]],fmt='s',color='black',ms=7,capsize=3)
ax.set_yticks([]); ax.set_xticks([0.5,1,2,4,8]); ax.set_xticklabels(['0.5','1','2','4','8'])
from matplotlib.ticker import NullFormatter
ax.xaxis.set_minor_formatter(NullFormatter())
ax.set_xlabel('Ratio of mean lung metastatic burden (95% CI, log scale)',fontsize=9)
for s in ['top','right','left']: ax.spines[s].set_visible(False)
fig.canvas.draw()
H=fig.get_size_inches()[1]*fig.dpi
def ypos(yy): return ax.transData.transform((1,yy))[1]/H
for kind,obj,yy in rows:
    if kind=='hdr':
        fig.text(0.01,ypos(yy),obj,fontsize=9,fontweight='bold',va='center')
    elif kind=='row':
        r=obj
        flag=''
        if ('duplicated' in r.note) or ('flagged' in r.note) or ('shares' in r.note): flag='  [integrity flag]'
        elif 'donor n unknown' in r.note: flag='  [design caveat]'
        fig.text(0.02,ypos(yy),f"{r.label} (n={r.n_veh}/{r.n_cre}){flag}",fontsize=7.6,va='center')
        fig.text(0.845,ypos(yy),f"{r.ratio:.2f} ({r.lo:.2f}–{r.hi:.2f})",fontsize=7.6,va='center')
    else:
        fig.text(0.01,ypos(yy),'Pooled WT-host estimate (random effects; Fig 6b excluded)',fontsize=8,fontweight='bold',va='center')
        fig.text(0.845,ypos(yy),f"{obj[0]:.2f} ({obj[1]:.2f}–{obj[2]:.2f})",fontsize=7.6,va='center',fontweight='bold')
fig.text(0.845,0.965,'Ratio (95% CI)',fontsize=8,fontweight='bold')
fig.suptitle('Figure 1. Creatine effect on lung metastatic burden, panel by panel (recomputed from per-animal source data)',fontsize=9.5,x=0.01,ha='left',y=0.995)
fig.text(0.01,0.01,'Ratio = mean(creatine)/mean(vehicle); CI by delta method on the log ratio. Pathway-blocked rows compare creatine vs vehicle within the blocked condition.\nPlatelet-transfer rows compare recipients of donor platelets. Diamonds = panel affected by the Fig 6b/Supp 2d duplicate-animal flag; triangle = donor number not reported.',fontsize=6.8)
plt.savefig('/tmp/outputs/figures/fig1_forest_metastatic_burden.png',dpi=200)
