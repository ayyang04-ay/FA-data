import numpy as np
from scipy import stats
exec(open('/tmp/work/analysis/human.py').read().split('rows=[]')[0])
za=stats.norm.isf(0.025)
for key in [('collagen','max'),('EPI','max'),('EPI','avg'),('ADP','max'),('AA','max')]:
    m=np.array(raw[key],float)
    l=np.log2(np.where(m>0,m,np.nan))
    sd3=np.nanstd(l[:,0],ddof=1); sd14=np.nanstd(l[:,2],ddof=1); mu14=np.nanmean(l[:,2])
    print(key,'d3 SD(log2) %.2f  d14 mean %.2f SD %.2f'%(sd3,mu14,sd14))
    for eff_frac in [1.0,0.5]:
        delta=mu14*eff_frac
        sd=np.sqrt((sd3**2+sd14**2)/2)
        for power in [0.8,0.9]:
            zb=stats.norm.ppf(power)
            n=2*sd**2*(za+zb)**2/delta**2 if delta>0 else np.inf
            print(f"    effect {eff_frac*100:.0f}% of observed (delta={delta:.2f} log2), pooled SD {sd:.2f}: n/arm for {int(power*100)}% power = {np.ceil(n):.0f}")
