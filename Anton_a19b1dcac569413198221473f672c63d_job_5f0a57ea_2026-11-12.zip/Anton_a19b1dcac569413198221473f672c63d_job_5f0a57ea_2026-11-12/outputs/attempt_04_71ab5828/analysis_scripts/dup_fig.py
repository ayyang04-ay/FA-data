import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
f6b_v=[2.40749,3.29136,3.73354,2.88635,4.91813]; f6b_c=[18.22751,11.13465,13.22011,14.12619,12.57216]
s2d_v=[6.41419,9.50815,9.32084,3.29136,3.73354,2.88635]; s2d_c=[25.23738,25.75262,18.04805,11.13465,13.22011,14.12619]
f6b_vf=[23,37,25,33,33]; f6b_cf=[51,53,62,47,78]; s2d_vf=[36,40,32,37,25,33]; s2d_cf=[56,67,53,53,62,47]
fig,ax=plt.subplots(figsize=(10,3.6)); ax.axis('off')
cols=['Fig 6b\nvehicle','Supp 2d\nvehicle-donor PLT','Fig 6b\ncreatine','Supp 2d\ncreatine-donor PLT','Fig 6b\nvehicle foci','Supp 2d\nveh-donor foci','Fig 6b\ncreatine foci','Supp 2d\ncre-donor foci']
data=[f6b_v,s2d_v,f6b_c,s2d_c,f6b_vf,s2d_vf,f6b_cf,s2d_cf]
dups={3.29136,3.73354,2.88635,11.13465,13.22011,14.12619}
dupf={(4,1),(4,2),(4,3),(5,3),(5,4),(5,5),(6,1),(6,2),(6,3),(7,3),(7,4),(7,5)}
x0=0.02; w=0.12
for j,(c,d) in enumerate(zip(cols,data)):
    ax.text(x0+j*w+w/2,0.93,c,ha='center',va='center',fontsize=7.5,fontweight='bold')
    for i,v in enumerate(d):
        hl = (v in dups) if j<4 else ((j,i) in dupf)
        ax.add_patch(plt.Rectangle((x0+j*w+0.005,0.78-i*0.11-0.045),w-0.01,0.09,color='#f4b6b6' if hl else '#f2f2f2',transform=ax.transAxes))
        ax.text(x0+j*w+w/2,0.78-i*0.11,f"{v:.5f}" if isinstance(v,float) else str(v),ha='center',va='center',fontsize=7.5)
ax.text(0.02,0.02,'Highlighted: identical values in the same order in two different experiments (metastatic burden to 5–6 significant digits, and the matching foci counts).\nFig 6b = STAT5-inhibitor experiment (directly treated mice); Supp 2d = platelet-transfer experiment (recipients of donor platelets).',fontsize=7.2,transform=ax.transAxes)
ax.set_title('Figure 5. Three animals per arm appear in both Fig 6b and Supp Fig 2d (burden: Fig 6b rows 5–7 = Supp 2d rows 8–10; foci: rows 14–16 = rows 17–19)',fontsize=9,loc='left')
plt.savefig('/tmp/outputs/figures/fig5_duplicate_animals.png',dpi=200,bbox_inches='tight')
