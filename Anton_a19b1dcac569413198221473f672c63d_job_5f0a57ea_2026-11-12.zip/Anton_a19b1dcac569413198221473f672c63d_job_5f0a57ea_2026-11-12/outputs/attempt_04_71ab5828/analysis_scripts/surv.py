import numpy as np
from lifelines import KaplanMeierFitter, CoxPHFitter
from lifelines.statistics import logrank_test
import pandas as pd
sets={'Fig1c':([17,17,20,20,21,23,27,29,30,30],[13,13,13,13,18,20,21,21,22,24]),
      'Fig1l':([14,14,14,15,15,15,15,16,16,16,16,18,18,18,18,19,19,20,20,20],[12,12,12,12,13,13,14,14,14,14,15,15,15,17,17,18,19,19])}
for k,(v,c) in sets.items():
    r=logrank_test(v,c,event_observed_A=[1]*len(v),event_observed_B=[1]*len(c))
    kv=KaplanMeierFitter().fit(v); kc=KaplanMeierFitter().fit(c)
    df=pd.DataFrame({'T':v+c,'E':1,'cre':[0]*len(v)+[1]*len(c)})
    cph=CoxPHFitter().fit(df,'T','E')
    hr=np.exp(cph.params_['cre']); ci=np.exp(cph.confidence_intervals_.values[0])
    print(k,'n',len(v),len(c),'logrank chi2 %.3f p %.4f'%(r.test_statistic,r.p_value),'median veh',kv.median_survival_time_,'cre',kc.median_survival_time_,'mean',np.mean(v),np.mean(c),'HR %.2f (%.2f-%.2f)'%(hr,ci[0],ci[1]))
