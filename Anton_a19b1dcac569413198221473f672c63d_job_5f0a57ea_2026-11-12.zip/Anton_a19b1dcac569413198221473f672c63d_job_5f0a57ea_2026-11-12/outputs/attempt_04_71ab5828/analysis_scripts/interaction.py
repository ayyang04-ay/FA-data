import numpy as np, pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
def inter(name, data, log=False):
    rows=[]
    for (a,b),vals in data.items():
        for v in vals: rows.append(dict(factor=a,treat=b,y=np.log(v) if log else v))
    df=pd.DataFrame(rows)
    m=smf.ols('y~C(factor)*C(treat)',df).fit()
    t=anova_lm(m,typ=2)
    p=t.loc['C(factor):C(treat)','PR(>F)']
    # ratio of creatine effects
    eff={}
    for f in df.factor.unique():
        s=df[df.factor==f]
        eff[f]=s[s.treat=='cre'].y.mean()-s[s.treat=='veh'].y.mean()
    print(f"{name:35s} log={log} interaction p={p:.4g}  creatine effect by factor: {{{', '.join(f'{k}: {v:.3g}' for k,v in eff.items())}}}")
# Fig 3i
inter('3i burden (MK Slc6a8)',{('WT','veh'):[1.625608,3.472777,2.979548,1.380526],('WT','cre'):[10.26911,7.184766,6.895283,7.292994],('KO','veh'):[2.744861,4.097582,3.688438,3.032604],('KO','cre'):[4.946393,2.677876,1.955753,1.920411]})
inter('3i burden (MK Slc6a8)',{('WT','veh'):[1.625608,3.472777,2.979548,1.380526],('WT','cre'):[10.26911,7.184766,6.895283,7.292994],('KO','veh'):[2.744861,4.097582,3.688438,3.032604],('KO','cre'):[4.946393,2.677876,1.955753,1.920411]},log=True)
inter('3i foci',{('WT','veh'):[18,29,33,39],('WT','cre'):[59,49,63,55],('KO','veh'):[29,21,34,22],('KO','cre'):[36,31,18,14]})
inter('3i lung wt',{('WT','veh'):[0.2086,0.2052,0.2121,0.1991],('WT','cre'):[0.2519,0.258,0.2406,0.244],('KO','veh'):[0.2173,0.2282,0.2311,0.2106],('KO','cre'):[0.2238,0.2235,0.2185,0.234]})
# Fig 6b
inter('6b burden (STAT5i)',{('none','veh'):[2.40749,3.29136,3.73354,2.88635,4.91813],('none','cre'):[18.22751,11.13465,13.22011,14.12619,12.57216],('inh','veh'):[3.06024,5.40229,4.05584,1.76918,3.87528],('inh','cre'):[3.23019,4.60251,4.62831,5.68289,4.3144]},log=True)
inter('6b foci',{('none','veh'):[23,37,25,33,33],('none','cre'):[51,53,62,47,78],('inh','veh'):[24,32,38,20,34],('inh','cre'):[28,33,30,20,25]})
# Fig 1f tumour Slc6a8
inter('1f burden (tumour Slc6a8 KD)',{('scr','veh'):[2.140578,1.502691,4.734425,7.259364,3.126361,8.545323],('scr','cre'):[22.84291,15.37146,9.488901,17.54824,15.27744,15.12845],('sh','veh'):[6.003466,4.411222,5.053624,6.501543,7.829754,5.041724],('sh','cre'):[24.95491,18.75453,17.87032,18.74111,14.50824,14.94675]},log=True)
inter('1f foci',{('scr','veh'):[8,6,7,18,10,15],('scr','cre'):[18,20,20,44,32,30],('sh','veh'):[11,9,12,15,21,15],('sh','cre'):[22,36,28,35,29,35]})
# 3d aggregation
inter('3d ADP agg',{('WT','veh'):[64,62,64],('WT','cre'):[70,72,70],('KO','veh'):[54,56,52],('KO','cre'):[30,32,32]})
