import re, base64, os, subprocess, sys
src='/tmp/work/proposal_src.md'
out_md='/tmp/outputs/CRE-MK-01_validation_proposal.md'
out_html='/tmp/outputs/CRE-MK-01_validation_proposal.html'
s=open(src,encoding='utf-8').read()
# markdown for readers: ^x^ -> <sup>x</sup>
md=re.sub(r'\^([^\^\s][^\^]*?)\^', r'<sup>\1</sup>', s)
open(out_md,'w',encoding='utf-8').write(md)
# html
import markdown
def reindent(text):
    out=[]
    for ln in text.split('\n'):
        m=re.match(r'^(\s+)(- |\d+\. )(.*)$', ln)
        if m:
            lvl=len(m.group(1))//2
            ln=' '*(4*lvl)+m.group(2)+m.group(3)
        out.append(ln)
    return '\n'.join(out)
html_body=markdown.markdown(reindent(md), extensions=['tables','sane_lists'])
def emb(m):
    path=os.path.join('/tmp/outputs',m.group(1))
    b=base64.b64encode(open(path,'rb').read()).decode()
    return f'src="data:image/png;base64,{b}"'
html_body=re.sub(r'src="(figures/[^"]+)"', emb, html_body)
css='''body{font-family:"DejaVu Sans",Arial,Helvetica,sans-serif;max-width:1050px;margin:24px auto;padding:0 18px;font-size:14px;line-height:1.45;color:#1b2a38}
h1{color:#1f4e79;font-size:24px}h2{color:#1f4e79;border-bottom:2px solid #c9d6e3;padding-bottom:3px;margin-top:28px}h3{color:#243b53;margin-top:18px}
table{border-collapse:collapse;width:100%;font-size:12px;margin:8px 0 14px}th{background:#1f4e79;color:#fff;text-align:left;padding:4px 6px;vertical-align:top}
td{border:1px solid #c9d6e3;padding:4px 6px;vertical-align:top}tr:nth-child(even) td{background:#f3f6f9}
img{max-width:100%;border:1px solid #e1e8ef;margin:6px 0}code{font-size:12px;background:#f1f4f7;padding:1px 3px}
body>p:first-child{background:#e8f0f8;border:1px solid #1f4e79;padding:10px 12px;font-size:15.5px}'''
html=f'<!DOCTYPE html><html><head><meta charset="utf-8"><title>CRE-MK-01 validation proposal</title><style>{css}</style></head><body>{html_body}</body></html>'
open(out_html,'w',encoding='utf-8').write(html)
print('md and html written', len(html))
