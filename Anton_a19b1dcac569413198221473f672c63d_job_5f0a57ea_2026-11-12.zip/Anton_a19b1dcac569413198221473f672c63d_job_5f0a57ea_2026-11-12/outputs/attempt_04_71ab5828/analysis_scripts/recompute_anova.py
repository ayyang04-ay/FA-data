import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
import itertools
def tukey(name, groups, pairs=None):
    labels=[]; vals=[]
    for k,v in groups.items():
        labels += [k]*len(v); vals += list(v)
    F,p = stats.f_oneway(*groups.values())
    res = pairwise_tukeyhsd(np.array(vals,float), np.array(labels))
    print(f"== {name}: one-way ANOVA F={F:.3f} p={p:.3g}")
    df = pd.DataFrame(res._results_table.data[1:], columns=res._results_table.data[0])
    if pairs:
        for a,b in pairs:
            r = df[((df.group1==a)&(df.group2==b))|((df.group1==b)&(df.group2==a))]
            print('   ', r.to_string(header=False, index=False))
    else:
        print(df.to_string(index=False))
    for k,v in groups.items():
        v=np.array(v,float); print(f"     {k}: mean {v.mean():.4g} sd {v.std(ddof=1):.3g} n={len(v)}")

# Fig 1f
g = {'scr_veh':[0.2051,0.1525,0.1646,0.1691,0.2068,0.2221],'scr_cre':[0.2591,0.2624,0.3623,0.3602,0.2556,0.3572],
     'sh_veh':[0.226,0.2481,0.244,0.2085,0.2102,0.2427],'sh_cre':[0.3234,0.278,0.3426,0.3758,0.2979,0.2443]}
tukey('1f lung', g, [('scr_veh','scr_cre'),('scr_cre','sh_cre'),('sh_veh','sh_cre'),('scr_veh','sh_veh')])
g = {'scr_veh':[1058.9,893.6,1095.7,949.07,926.52,877.28],'scr_cre':[1409.3,1330.5,1162.3,1194.2,1155.2,1245.9],
     'sh_veh':[1086,982.98,1062.4,843.52,892.77,919.32],'sh_cre':[1254.4,1161.2,1376.4,1417.4,1139.2,1355.41]}
tukey('1f SUV', g, [('scr_veh','scr_cre'),('scr_cre','sh_cre'),('sh_veh','sh_cre')])
g = {'scr_veh':[2.140578,1.502691,4.734425,7.259364,3.126361,8.545323],'scr_cre':[22.84291,15.37146,9.488901,17.54824,15.27744,15.12845],
     'sh_veh':[6.003466,4.411222,5.053624,6.501543,7.829754,5.041724],'sh_cre':[24.95491,18.75453,17.87032,18.74111,14.50824,14.94675]}
tukey('1f burden', g, [('scr_veh','scr_cre'),('scr_cre','sh_cre'),('sh_veh','sh_cre')])
g = {'scr_veh':[8,6,7,18,10,15],'scr_cre':[18,20,20,44,32,30],'sh_veh':[11,9,12,15,21,15],'sh_cre':[22,36,28,35,29,35]}
tukey('1f foci', g, [('scr_veh','scr_cre'),('scr_cre','sh_cre'),('sh_veh','sh_cre')])

# Fig 3d (aggregation, per agonist)
for ag,vals in {'ADP':([64,62,64],[70,72,70],[54,56,52],[30,32,32]),'Collagen':([64,64,66],[76,76,78],[60,62,60],[52,50,50]),'Thrombin':([60,62,62],[76,74,74],[46,44,46],[34,36,36])}.items():
    g={'WT_veh':vals[0],'WT_cre':vals[1],'KO_veh':vals[2],'KO_cre':vals[3]}
    tukey('3d '+ag, g, [('WT_veh','WT_cre'),('KO_veh','KO_cre'),('WT_veh','KO_veh')])

# Fig 3i
g={'WT_veh':[0.2086,0.2052,0.2121,0.1991],'WT_cre':[0.2519,0.258,0.2406,0.244],'KO_veh':[0.2173,0.2282,0.2311,0.2106],'KO_cre':[0.2238,0.2235,0.2185,0.234]}
tukey('3i lung', g, [('WT_veh','WT_cre'),('WT_cre','KO_cre'),('KO_veh','KO_cre'),('WT_veh','KO_veh')])
g={'WT_veh':[1.625608,3.472777,2.979548,1.380526],'WT_cre':[10.26911,7.184766,6.895283,7.292994],'KO_veh':[2.744861,4.097582,3.688438,3.032604],'KO_cre':[4.946393,2.677876,1.955753,1.920411]}
tukey('3i burden', g, [('WT_veh','WT_cre'),('WT_cre','KO_cre'),('KO_veh','KO_cre'),('WT_veh','KO_veh')])
g={'WT_veh':[18,29,33,39],'WT_cre':[59,49,63,55],'KO_veh':[29,21,34,22],'KO_cre':[36,31,18,14]}
tukey('3i foci', g, [('WT_veh','WT_cre'),('WT_cre','KO_cre'),('KO_veh','KO_cre'),('WT_veh','KO_veh')])

# Fig 6b
g={'veh':[2.40749,3.29136,3.73354,2.88635,4.91813],'cre':[18.22751,11.13465,13.22011,14.12619,12.57216],'veh_inh':[3.06024,5.40229,4.05584,1.76918,3.87528],'cre_inh':[3.23019,4.60251,4.62831,5.68289,4.3144]}
tukey('6b burden', g, [('veh','cre'),('veh','veh_inh'),('cre','cre_inh'),('veh_inh','cre_inh')])
g={'veh':[23,37,25,33,33],'cre':[51,53,62,47,78],'veh_inh':[24,32,38,20,34],'cre_inh':[28,33,30,20,25]}
tukey('6b foci', g, [('veh','cre'),('veh','veh_inh'),('cre','cre_inh'),('veh_inh','cre_inh')])

# Supp 2d
g={'vehPLT':[6.41419,9.50815,9.32084,3.29136,3.73354,2.88635],'crePLT':[25.23738,25.75262,18.04805,11.13465,13.22011,14.12619],'creAspPLT':[5.82668,5.06091,4.03555,0.78587,4.7051,5.74116]}
tukey('S2d burden', g)
g={'vehPLT':[36,40,32,37,25,33],'crePLT':[56,67,53,53,62,47],'creAspPLT':[35,36,32,8,28,33]}
tukey('S2d foci', g)

# Fig 6e
g={'WT_veh':[9.94134,25.49864,25.48932],'WT_cre':[99.63794,78.81516,107.0593],'S5bKO_cre':[81.41063,81.61312,131.5194]}
tukey('6e MK creatine', g)

# Fig 5e
g={'WT':[0.65945,0.67477,0.81422],'S127A':[0.67288,0.8528,0.82823],'3A':[0.70079,0.7988,0.82293],'S127D':[1.15462,0.93917,1.04193]}
tukey('5e vehicle', g)
g={'WT':[1.02728,0.931,1.03384],'S127A':[0.7966,0.87167,0.81992],'3A':[0.71446,0.69881,0.79339],'S127D':[0.99162,0.94417,1.092]}
tukey('5e creatine', g)
g={'WT':[0.64808,0.8398,0.77645],'S127A':[0.62936,0.74251,0.78904],'3A':[0.63533,0.88838,0.76247],'S127D':[0.96733,1.00452,1.08384]}
tukey('5f vehicle', g)
g={'WT':[0.94163,1.10559,0.85107],'S127A':[0.65785,0.73446,0.50978],'3A':[0.64766,0.7125,0.6539],'S127D':[1.0345,1.06624,0.88034]}
tukey('5f creatine', g)
# Supp 4b,4c
g={'WT_veh':[893,823,954],'WT_cre':[1012,1071,644],'KO_veh':[1074,1172,880],'KO_cre':[983,827,1167]}
tukey('S4b PLT', g)
g={'WT_veh':[5,3,3,2,1,2,3,2],'WT_cre':[5,5,6,6,4,4,7,4],'KO_veh':[1,2,2,4,3,1,2,3],'KO_cre':[5,2,1,1,2,3,1,3]}
tukey('S4c a-granules (fields)', g)
