import openpyxl, numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
wb = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)
ws = wb['Fig. 7d']
g=[[ws.cell(r,c).value for c in range(1,13)] for r in range(1,ws.max_row+1)]
blocks=[]
for r in range(len(g)):
    # left block: gene col A(0), label col B(1), values C-F (2..5)
    if isinstance(g[r][0],str) and g[r][2]=='Volunteer1':
        blocks.append((g[r][0],r,1,2))
    # right block: gene col H(7), label col H(7) in following rows, values I-L (8..11)
    if isinstance(g[r][7],str) and g[r][8]=='Volunteer1':
        blocks.append((g[r][7],r,7,8))
rows=[]
for gene,r,labc,valc in blocks:
    dct={}; norm={}
    for i in range(1,17):
        lab=g[r+i][labc]; vals=g[r+i][valc:valc+4]
        if lab is None: continue
        if lab.startswith('ΔCT'): dct.setdefault(lab,[]).append(vals)
        elif lab.startswith('After'): norm[lab]=vals
    d0=np.array(dct['ΔCT-0d'],float)
    for day in ['3d','7d','14d']:
        dd=np.array(dct['ΔCT-'+day],float)
        calc_meanlin=(2**dd).mean(0)/(2**d0).mean(0)
        rep=np.array(norm['After normalization-'+day],float)
        for v in range(4):
            rows.append(dict(gene=gene,day=day,vol=v+1,reported=rep[v],recalc=calc_meanlin[v],ratio=rep[v]/calc_meanlin[v]))
df=pd.DataFrame(rows)
pd.set_option('display.width',200)
print('genes parsed:', df.gene.unique())
bad=df[(np.abs(np.log(df.ratio))>0.05)]
print('Mismatches:'); print(bad.round(4).to_string(index=False)); print('n rows',len(df),'n mismatch',len(bad))
out=[]
for (gene,day),s in df.groupby(['gene','day']):
    x=np.log2(s.reported.values)
    t=stats.ttest_1samp(x,0)
    out.append(dict(gene=gene,day=day,geo_fc=2**x.mean(),n_up=int((x>0).sum()),p=t.pvalue))
o=pd.DataFrame(out)
o['q_BH(33)']=multipletests(o.p,method='fdr_bh')[1]
print(o.round(4).sort_values(['day','gene']).to_string(index=False))
df.to_csv('/tmp/work/analysis/fig7d_recalc.csv',index=False)
o.to_csv('/tmp/work/analysis/fig7d_stats.csv',index=False)
# per-volunteer pattern at day 14
piv=df[df.day=='14d'].pivot(index='gene',columns='vol',values='reported')
print(piv.round(2))
piv=df[df.day=='7d'].pivot(index='gene',columns='vol',values='reported')
print(piv.round(2))
