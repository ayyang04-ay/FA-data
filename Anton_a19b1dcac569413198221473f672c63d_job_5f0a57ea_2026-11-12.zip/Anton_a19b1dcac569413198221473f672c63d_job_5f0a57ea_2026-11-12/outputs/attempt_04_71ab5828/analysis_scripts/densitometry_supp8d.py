import numpy as np
from PIL import Image
im=np.array(Image.open('/tmp/work/xl_src/xl/media/image26.jpeg').convert('L')).astype(float)
dark=255-im
lanes={
 ('V1','GP6'):[(315,347),(362,392),(407,440),(450,485)],
 ('V1','P2RY12'):[(730,765),(780,815),(832,865),(882,920)],
 ('V1','ACTB'):[(1150,1190),(1202,1240),(1252,1295),(1307,1342)],
 ('V2','GP6'):[(282,322),(340,380),(395,437),(450,492)],
 ('V2','P2RY12'):[(695,730),(742,777),(790,825),(837,872)],
 ('V2','ACTB'):[(1177,1227),(1245,1292),(1311,1357),(1376,1425)],
 ('V3','GP6'):[(307,345),(360,385),(405,450),(455,495)],
 ('V3','P2RY12'):[(702,742),(757,797),(815,855),(872,915)],
 ('V3','ACTB'):[(1152,1207),(1217,1270),(1282,1335),(1347,1400)],
 ('V4','GP6'):[(235,282),(295,340),(355,400),(412,460)],
 ('V4','P2RY12'):[(725,775),(787,835),(850,895),(910,955)],
 ('V4','ACTB'):[(1190,1240),(1255,1300),(1310,1360),(1375,1425)],
}
yguess={'V1':172,'V2':430,'V3':698,'V4':990}
out={}
for (v,prot),L in lanes.items():
    yg=yguess[v]
    x0=min(a for a,b in L); x1=max(b for a,b in L)
    # refine band center per lane
    areas=[]
    for (a,b) in L:
        col=dark[yg-25:yg+26,a:b].mean(1)
        yc=yg-25+int(np.argmax(col))
        band=dark[yc-8:yc+9,a:b]
        bg=np.median(np.concatenate([dark[yc-22:yc-14,a:b].ravel(),dark[yc+14:yc+22,a:b].ravel()]))
        s=band-bg; s[s<0]=0
        areas.append(s.sum())
    out[(v,prot)]=np.array(areas)
import pandas as pd
rep_gp6=np.array([[0.43839,0.40656,0.79545,0.95175],[0.4173,0.82352,0.61801,0.87653],[0.27948,0.55108,1.0529,1.39303],[0.53932,0.31348,0.87133,1.11121]])
rep_p2=np.array([[1.03313,1.44465,1.08654,1.37499],[0.51893,1.19239,0.82157,0.87454],[0.47044,1.00601,0.73991,1.28533],[0.89578,1.11512,1.10142,1.28611]])
print('Reported (Fig 7e) rows, relative to own d0:')
for i in range(4):
    print('  row',i+1,'GP6',np.round(rep_gp6[i]/rep_gp6[i,0],2),' P2RY12',np.round(rep_p2[i]/rep_p2[i,0],2))
print('Image densitometry (Supp 8d), ratio to ACTB, relative to own d0:')
for v in ['V1','V2','V3','V4']:
    g=out[(v,'GP6')]/out[(v,'ACTB')]; p=out[(v,'P2RY12')]/out[(v,'ACTB')]
    print(' ',v,'GP6',np.round(g/g[0],2),' P2RY12',np.round(p/p[0],2), ' raw ACTB', np.round(out[(v,'ACTB')]/out[(v,'ACTB')][0],2))
