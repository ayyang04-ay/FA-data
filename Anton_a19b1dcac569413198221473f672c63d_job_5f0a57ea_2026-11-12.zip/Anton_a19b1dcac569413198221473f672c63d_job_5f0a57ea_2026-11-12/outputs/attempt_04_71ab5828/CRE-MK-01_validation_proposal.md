**Recommendation: take megakaryocyte SLC6A8 forward as the primary target. SLC6A8 is the transporter that lets supplemental creatine into megakaryocytes, where it reprograms the platelets they release. Use next quarter's in vivo slot for a blinded, powered genetic confirmation in two models. Keep the platelet-activation layer (lead: GPVI, tested against approved antiplatelet drugs) and STAT5B as gated backups. Do not advance CKB.**

# CRE-MK-01: validation proposal for the portfolio committee

**Sources.** This proposal uses only the three files in the data package:

- `CRE-MK-01_source_data.xlsx`: 87 sheets and 26 embedded blot images.
- `CRE-MK-01_phosphoproteomics.xlsx`: 5,812 phosphopeptides.
- `study_conventions.pdf`.

**Method.** Every number below was recomputed from the per-animal or per-subject values in those files. Appendix A explains how each one was derived, and the scripts are in `analysis_scripts/`. All reported t-tests, ANOVAs and log-rank tests were recomputed and agree with the reported values. Published literature was not used as evidence.

---

## 1. The decision on one page

### What we are asking for

Allocate the in vivo slot to **Study 1 (CRE-MK-02)**, set out in Section 5.1. It is a randomised, blinded, sex-balanced 2×2 study:

- **Factors:** megakaryocyte-specific *Slc6a8* deletion × creatine exposure.
- **Primary test:** a pre-specified interaction test on lung metastatic burden.

The study is tiered by animal numbers:

| Tier | Contents | Mice |
|---|---|---|
| 1 (must run) | Replicates the Fig 3i experiment, plus a pharmacodynamic (PD) satellite group | 88 |
| 2 (recommended) | Adds a spontaneous-metastasis module | +64 |
| 3 (if capacity allows) | Adds a survival group, an aspirin benchmark arm and a post-seeding exposure arm | +80 |

### Why megakaryocyte (MK) SLC6A8 is the primary target

- **It is the only node tested against the metastasis endpoint by a genetic loss of function restricted to megakaryocytes — and the deletion removes the creatine effect.**
  - Lung metastatic burden with creatine: 2.36 → 7.91 % in Cre-only controls, versus 3.39 → 2.88 % in *Pf4-Cre;Slc6a8<sup>fl/fl</sup>* mice (Fig 3i).
  - Our genotype × creatine interaction test gives p = 0.0003 for burden, 0.004 for foci and 0.0002 for lung weight.
- **Each intermediate step changes with the genotype, while systemic exposure does not.**
  - Serum creatine rises equally in both genotypes: 2.70× vs 2.44× (Fig 3b).
  - In knockout (KO) mice the following are lost: the rise in MK creatine (5.3× in controls vs 1.5× in KO; Fig 3c), the MK platelet-activation transcript program (Fig 3f), the α-granule gain (Supp 4c) and the aggregation gain (Fig 3d).
  - Delivering creatine into SLC6A8-null MKs by liposome restores the transcript program (Supp 4e).
  - So the transporter is the gate, and creatine inside the cell is the signal.
- **The effect comes from the host, not the tumour.** Knocking down *Slc6a8* in the melanoma cells did not change the creatine effect (3.5× vs 3.15×; interaction p = 0.44; Fig 1f).
- **None of the data-integrity findings (Section 4: duplicated animals, irreproducible values, the null screen; I-1 to I-3) touch the SLC6A8 panels.** The design caveats that do apply (n = 4, no blinding, fields used as n for α-granules, partial deletion) are exactly what Study 1 is built to fix.

### Why STAT5B is not the primary target, even though it is the end point of the package's mechanistic story

- **The phosphoproteomic screen that nominated STAT5B is statistically null.**
  - No peptide passes FDR (false discovery rate); the Stat5b peptide has q = 0.25.
  - The number of nominal hits is about what chance alone would produce: 238 with p < 0.05 against 205 expected among peptides quantified in ≥2 samples, and 150 against 184 expected among peptides with an absolute logFC ≤ 2.
  - No phosphosite positions are reported.
- **Canonical STAT5 activation is absent.** Tyrosine phosphorylation at Y694/699 is undetectable in MKs, with or without creatine (Supp 6a).
- **The S127 evidence is weak.** It is a change of +28 % to +39 % in a pan-phospho signal, with n = 3, and only one of two experiments is significant.
- **The only in vivo metastasis test is compromised.**
  - It used a systemic inhibitor (Fig 6b), which does not localise the effect to MKs.
  - Three animals per arm in that experiment have values identical to animals in a different experiment (Supp 2d).
  - There is no MK-*Stat5b* metastasis experiment, and no KO-vehicle arm.

### Backups, in order

1. **Backup 1 (translational): the platelet-activation layer, with GPVI (encoded by *GP6*) as the lead receptor and approved antiplatelet drugs as comparators.**
   - *Why it ranks first:* it has the best human bridge.
     - GP6 protein rose 2.1–5.0× in all four volunteers tested.
     - Collagen- and epinephrine-induced aggregation rose in 9–11 of 11 volunteers (FDR q ≈ 0.03).
     - ADP- and arachidonic-acid-induced responses did not change.
   - *Why it is the natural fallback:* it sits downstream of any route by which creatine enters.
   - *Why GPVI leads:* *Gp6* is induced in all 6 mouse MK experiments (2.8–42×; the largest change in 3 of them). It is the only receptor whose protein and matching functional response (collagen aggregation) both rise in mice and in humans. P2RY12 protein rose, but ADP responses did not change in humans. The *Gp6* promoter is occupied after creatine (ChIP).
   - *Second receptor to profile:* the α2A-adrenergic receptor (*ADRA2A*). The epinephrine response was the most consistent human signal, and *ADRA2A* is the only human transcript that survives FDR. It has no protein data and has not been tested functionally in mice. Study 1 therefore adds epinephrine aggregation.
2. **Backup 2 (mechanistic): STAT5B.** It can be promoted only if the gate in Section 5.2 is passed.
3. **Hold: CKB.** All functional evidence for CKB is in vitro.

### Why spend the slot confirming SLC6A8 rather than testing something new

- **The current evidence is not yet decision-grade.** SLC6A8 is the strongest node, but it rests on one unblinded experiment with n = 4 per group, an incomplete deletion and an unexplained opposite-sign platelet effect. A portfolio commitment should rest on more than that.
- **The alternatives are not ready for animals.** A STAT5B in vivo study now would build on evidence that is unresolved (I-1, I-3). That gate can be cleared without animals during the same quarter.
- **The platelet-layer study needs preparation.** Its comparator tools must first be qualified, and it is best designed once Study 1 shows whether SLC6A8 is the whole gate.
- **Study 1 is built to pay off beyond SLC6A8.** It measures the full chain, from MK creatine loading through to platelet function and haemostasis. Its results inform both backups as well as the primary.

### Scope the committee should price in

Every node in this pathway only matters when creatine is given. In vehicle-treated mice, neither MK-*Slc6a8* deletion (burden 3.39 vs 2.37 %; Fig 3i) nor STAT5 inhibition (3.63 vs 3.45 %; Fig 6b) changed metastasis.

- **What the data support:** patients with cancers that spread through the blood who are exposed to creatine. This is a risk-mitigation and biomarker indication.
- **What the data do not support:** a standalone anti-metastatic indication.
- **Druggability of SLC6A8 itself is a separate question.** Blocking the transporter throughout the body also blocks the intended effects of creatine. Exogenous creatine raises brain creatine 1.19× and phosphocreatine 1.95× (Fig 4a, 4c). Study 1's safety readouts and the pharmacology gate (Section 5.5) will decide whether SLC6A8 remains the drug target or serves as the mechanism and biomarker, with Backup 1 as the intervention.

### Before animals are committed (2–4 weeks, no animal use)

- Resolve the duplicate animals (integrity item I-1).
- Re-derive the volunteer-4 human qPCR values (I-2).
- Re-process the phosphoproteomics with site localisation (I-3).
- Document the tumour model, sex and genotype behind each panel (I-12).
- Lock the statistical analysis plan for Study 1.
- Start colony expansion now; colony supply is the rate-limiting step.

---

## 2. Evidence overview

![Evidence map](figures/fig2_evidence_map.png)

**Table 1. Candidate targets scored on the data package alone**

| Criterion | MK SLC6A8 | Platelet-activation layer (GPVI lead) | STAT5B | CKB |
|---|---|---|---|---|
| In vivo test of whether the node is needed for metastasis | MK-restricted KO removes the creatine effect (Fig 3i; interaction p = 0.0003) | Aspirin-treated donor platelets only (Supp 2d; flag I-1) | Systemic inhibitor only (Fig 6b; flag I-1); no MK-KO metastasis study | None |
| Proximal mechanism | MK creatine uptake, transcripts, α-granules and aggregation all lost in KO | Aggregation ↑; GP6/P2RY12 ↑; platelet counts unchanged | KO blunts transcripts but has no KO-vehicle arm; no canonical pY; pan-phospho S127 only | Creatine ↑ CKB; si-*Ckb* blocks and overexpression mimics the program in vitro |
| Is activating the node enough? | Liposomal creatine restores the program in SLC6A8-null MKs | Primed platelets transfer the phenotype (Fig 7g; Supp 2d flagged) | Not tested functionally | CKB overexpression is enough in vitro, independent of phosphocreatine |
| Human bridge | Not measured | GP6 ↑ in 4/4 volunteers; collagen and epinephrine aggregation ↑ in 9–11/11 | Not measured | Not measured |
| Integrity flags on this node | No integrity flags; design caveats I-4, I-9, I-10, I-12 | I-1, I-2, I-6 | I-1, I-3, I-7, I-8 | Label issue only (I-11) |
| Safety or selectivity signal in our data | KO lowers baseline aggregation and creatine lowers it further (Fig 3d), so haemostasis must be tested; creatine also raises brain creatine | Acts on platelets only; counts unaffected | Inhibitor suppresses baseline MK transcripts (Fig 6a) | Brain CKB band far stronger than MK band (Fig 4b) |
| **Verdict** | **Primary** | **Backup 1** | **Backup 2 (gated)** | **Hold** |

---

## 3. Evidence in detail

### 3.1 The phenotype is large, consistent and survives re-analysis

![Forest plot](figures/fig1_forest_metastatic_burden.png)

**Metastatic burden**

- Creatine increased lung metastatic burden in all 11 creatine-versus-vehicle comparisons in wild-type (WT) hosts.
- The ratios ranged from 2.07 to 4.02, and every 95 % CI lies above 1.
- Pooled random-effects ratio: 2.89 (95 % CI 2.50–3.33; I² ≈ 35 %) with the flagged Fig 6b excluded, and 3.02 with it included.

**Other endpoints point the same way**

- Metastatic foci rose 1.5–3.0×.
- Lung weight rose 1.21–1.66×.
- PET SUV rose 2.14× and 1.68× (Fig 1a, 1j).
- The effect holds for both gavage and a 5 % creatine diet (3.6×; Supp 1i).

**Survival**

- Fig 1c (n = 10/10): median survival 21 → 18 days; HR 2.93 (1.04–8.23); log-rank p = 0.032.
- Fig 1l (n = 20/18): median survival 16 → 14 days; HR 2.28 (1.16–4.46); p = 0.011.

**Not a calorie effect.** Food intake, water intake and body weight were unchanged (Supp 1a–c).

**The weakness is in how the studies were run, not the arithmetic.**

- Allocation was never masked.
- Group sizes were not calculated in advance.
- Sex was not analysed.
- Each strain was used in one sex only.
- The tumour model behind each panel is not documented.
- Unblinded, small studies tend to overstate effect sizes, so Study 1 is powered for a smaller effect than observed.

### 3.2 Exposure bridge: mouse and human creatine levels overlap

**Table 2. Serum creatine**

| Setting | Baseline (µM) | On creatine (µM) | Fold | Source (n) |
|---|---|---|---|---|
| Mouse, gavage 17 mg 3×/week | 65.9 | 178.5 | 2.71 | Supp 1d (6/6) |
| Mouse, 5 % diet | 78.2 | 227.2 | 2.91 | Supp 1h (4/4) |
| Mouse, *Pf4-Cre;Slc6a8<sup>+/+</sup>* | 88.6 | 239.3 | 2.70 | Fig 3b (5/5) |
| Mouse, *Pf4-Cre;Slc6a8<sup>fl/fl</sup>* | 89.1 | 217.7 | 2.44 | Fig 3b (5/5) |
| Human, 20 g/day: day 3 / day 7 / day 14 | 45.3 | 152.9 / 155.5 / 159.2 | 3.5 | Fig 7b (11; every subject up 2.1–6.3×) |

- Human loading-dose levels reach roughly 65–90 % of the mouse levels that drove metastasis.
- Maintenance-dose exposures were not studied.
- The gavage dose is 17 mg (42.5 mg/mL × 400 µL; study conventions).

### 3.3 The effect is host-mediated, not tumour-intrinsic

**What Fig 1f shows**

- Creatine raised burden 3.50× with control melanoma cells and 3.15× with *Slc6a8*-knockdown cells.
- The interaction test was not significant: p = 0.44 (log burden) and p = 0.95 (foci).

**Caveat: the knockdown was only partial at protein level**

- mRNA fell 70–90 % (Supp 2a).
- The protein blot shows only a modest reduction.
- The label is inconsistent: the blot says "sh", while the table and Tukey rows say "si" and "WT".

**The MK genetics carry the main weight.** Tumour-cell *Slc6a8* knockdown does not affect the result; deleting *Slc6a8* in the host's megakaryocytes does (Section 3.5).

### 3.4 Creatine primes platelets without changing how many there are

| Readout | Vehicle → creatine | n (unit) | Source | Comment |
|---|---|---|---|---|
| Platelet count (10<sup>9</sup>/L) | 789 → 789 | 3/3 mice | Fig 2a | Also unchanged in Supp 4b, 7a, 7b and in humans (Supp 8b; RM-ANOVA p = 0.60) |
| Other blood counts (WBC, lymphocytes, monocytes, RBC) | All unchanged | 5/5 mice | Supp 3a | No general haematological effect |
| MK maturation transcripts | *Nfe2, Gata1, Zfpm1, Itgb3, Tubb1, Lims1* not significant (nominal: *Casp12* 1.9×, *Myl9* 0.5×, *Hsd3b1* 1.4×) | 3/3 | Supp 3c | MK differentiation unaffected |
| Aggregation to ADP / collagen / thrombin (%) | 42→57 / 66→79 / 25→56 | 3/3 mice | Fig 2b | Very tight variance |
| α-granules per field | 2.0 → 3.9 | 8 fields | Fig 2c | Fields used as n (I-4) |
| TEG MA (mm) | 39.7 → 54.0 (p = 0.049) | 5/5 | Fig 2d | p = 0.097 without one low vehicle value; R, K and α unchanged |
| Lung tumour-cell signal at 15 min / 6 h / 12 h / 24 h | 0.86× / 1.51× / 1.79× / 2.76× | 6/6 | Fig 1h | Equal initial arrest, increased retention |
| PKH⁺ area in lung (%) | 1.9 → 4.5 | 8 fields | Fig 2j | Fields used as n |
| GP6/P2RY12 protein in cultured MKs vs cultured platelets | Up in MKs at 0.2 and 2 mM; no change in platelets | Images | Fig 2i | The program is set in MKs, not in circulating platelets |
| GP6/P2RY12 protein in MKs and platelets from treated mice | Clearly up in MKs (Fig 2g, 6f). In platelets: little visible change in Fig 2e, an increase in Fig 6f | Images, unquantified | Fig 2e, 2g, 6f | The mouse platelet protein change is inconsistent and unquantified; human platelets show it (Fig 7e) |
| Transfer of primed platelets | Mouse creatine-donor platelets 3.06×; human day-7 platelets 2.72× | 6/6; 5/5 | Supp 2d; Fig 7g | Supp 2d flagged (I-1); Fig 7g donors not reported (I-13) |

What these results mean together:

- **The lag matches the human time course.** The program is set in megakaryocytes, and mature platelets do not respond directly (Fig 2i). Platelet priming therefore requires platelet turnover. In humans there was no platelet change at day 3 but clear changes at days 7–14.
- **Creatine acts after tumour cells arrest.** Early tumour-cell arrest was unchanged, while retention at 6–24 h rose. This points to a step after arrest and fits a platelet-dependent mechanism.

### 3.5 Megakaryocyte SLC6A8 is the gate (primary target)

**Table 3. SLC6A8 evidence**

| Readout | *Pf4-Cre;Slc6a8<sup>+/+</sup>*: vehicle → creatine | *Pf4-Cre;Slc6a8<sup>fl/fl</sup>*: vehicle → creatine | Source; our re-analysis |
|---|---|---|---|
| Serum creatine (µM) | 88.6 → 239.3 | 89.1 → 217.7 | Fig 3b; equal exposure |
| MK creatine | 13.7 → 72.1 (5.3×; p = 0.049; Welch p = 0.10) | 13.7 → 21.1 (1.5×; p = 0.20) | Fig 3c; n = 3, underpowered |
| Aggregation to ADP / collagen / thrombin (%) | 63→71 / 65→77 / 61→75 | 54→31 / 61→51 / 45→35 | Fig 3d; interaction p < 10⁻⁷ (ADP) |
| MK transcripts (11 genes) | All up 2.0–5.5× | 0.37–1.48×, except *Fcgr2a* 3.3× | Fig 3f (ΔΔCt against the vehicle mean) |
| GP6/P2RY12 protein (MK) | Up | No change | Fig 3g images |
| α-granules per field | 2.6 → 5.1 | 2.25 → 2.25 | Supp 4c (fields used as n) |
| Platelet count (10<sup>9</sup>/L) | 890 → 909 | 1042 → 992 | Supp 4b |
| Lung metastatic burden (%) | 2.36 → 7.91 | 3.39 → 2.88 | Fig 3i; interaction p = 0.0003 (0.0009 on log scale) |
| Metastatic foci | 29.8 → 56.5 | 26.5 → 24.8 | Fig 3i; interaction p = 0.004 |
| Creatine delivered into SLC6A8-null MKs | — | Free creatine: little or no induction (0.18–1.5×; *F2r* 0.18×, *Runx1* 0.56×). Liposomal creatine: 9/11 transcripts up 2.1–4.0× | Supp 4e |

**Gaps that Study 1 must close**

1. **One small, unblinded experiment.** The deciding metastasis endpoint rests on a single experiment with n = 4 per group.
2. **The deletion is incomplete.**
   - Rough densitometry of the Supp 4a image shows KO MKs keep about half the WT SLC6A8 band.
   - MK creatine still rises 54 % in KO (Fig 3c).
3. **Creatine has a second, opposite-sign effect that does not go through SLC6A8.**
   - In KO mice creatine *lowers* aggregation (ADP 54 → 31 %), and KO baseline aggregation is below controls (ADP 54 vs 63 %; thrombin 45 vs 61 %) (Fig 3d).
   - In null MKs, free creatine lowers *F2r* and *Runx1* (Supp 4e).
   - Haemostasis endpoints are therefore mandatory.
4. **Genotype and sex need confirming.**
   - *Slc6a8* is X-linked, so "fl/fl" animals are female, yet the conventions list C57BL/6J experiments as male.
   - The specificity of *Pf4-Cre* recombination is not documented.
5. **SLC6A8 is not yet shown to be drug-tractable in our system.** A systemic transporter blocker would also act outside MKs (Fig 4a, 4c).

### 3.6 CKB: a plausible link, shown in vitro only

**What the data show**

- In vivo, creatine raises MK creatine 3.05× and phosphocreatine 3.9× (Fig 4a, 4c).
- It also raises *Ckb* mRNA 1.8× (Fig 4e) and CKB protein in MKs (Fig 4b image; the same is seen in culture, Fig 4g).
- The same rises are seen in cultured MKs: creatine 3.6× (Fig 4d) and phosphocreatine 5.4× (Fig 4f).
- Expression of the creatine-synthesis enzymes *Gatm* and *Gamt* is unchanged (Supp 5a; tissue not stated), so creatine synthesis is not induced.
- Adding phosphocreatine from outside does not reproduce the program. Transcripts ranged 0.29–1.12× (Fig 4h).

**In vitro perturbations**

- si-*Ckb* prevents the creatine induction. For example, *Itga2b* goes from 4.2× to 1.3× and *Pitpnb* from 7.4× to 0.75× (Fig 4j).
- CKB overexpression induces the program 1.7–6.0× (Fig 4l).
- Overexpression does not change MK creatine (0.97×) or phosphocreatine (1.25×, not significant; Supp 5c). This points to an action that does not depend on CKB's metabolic role.

**The link from CKB to STAT5B is thin.** It rests on one in vitro kinase image with a pan-phospho antibody (Supp 6d) and on unquantified single images (Fig 5g–5i).

**Verdict: hold.** There has been no in vivo perturbation of CKB, and the brain CKB band is far stronger than the MK band (Fig 4b). Resolve the open questions in vitro before spending any animals.

### 3.7 STAT5B: plausible, but not supported at decision grade

![Phosphoproteomics](figures/fig3_phosphoproteomics.png)

| Evidence | What it shows | Why it is not decision-grade |
|---|---|---|
| Phosphoproteomics (n = 3 per group) | One Stat5b phosphopeptide: p = 0.0012, logFC 5.7, rank 17 of 5,812 | q = 0.25, and no peptide passes FDR. 29 % of peptides were detected in one sample only. Nominal hits are at chance level: 238 with p < 0.05 against 205 expected among peptides quantified in ≥2 samples; 150 against 184 among peptides with an absolute logFC ≤ 2. The Stat5b logFC of 5.7 lies in the range dominated by missing-value artefacts. No site information. The other Stat5b peptide is unchanged (p = 0.47) |
| pY694/699 blot (Supp 6a) | No signal in MKs with or without creatine; the Jurkat + IL-2 control is positive | The canonical activation mark is absent, so the mechanism has to be non-canonical |
| STAT5B-FLAG mutants (Fig 5e, 5f) | Creatine raises the pan-phospho/FLAG ratio of WT STAT5B by 1.39× (p = 0.009) and 1.28× (p = 0.09), but not for S127A or 3A; WT × S127A interaction p = 0.024 and 0.043 | The antibody is pan-phospho, not site-specific. Phospho and FLAG were run on separate gels. S127D, which cannot be phosphorylated at 127, gives the highest signal. n = 3 |
| ChIP (Fig 5j, Supp 6i) | Creatine raises proximal-promoter occupancy at *P2ry12* (4.6–12×), *Gp6* (2.9–3.8×; −2 kb region unchanged) and *Rab4a* (2.7–5.5×; −2 kb unchanged); exon controls are flat | Antibody, IgG and KO-specificity controls are not in the data |
| STAT5-IN-1 in MKs (Fig 6a) | Blocks the creatine induction | The inhibitor alone suppresses baseline expression (*Rab4a* 0.21×, *Gpiba* 0.37×, *Gp6* 0.39×) |
| STAT5-IN-1 in vivo (Fig 6b) | Blocks creatine-driven metastasis (13.86 vs 4.49 %; interaction p = 0.0004) | Systemic, so not MK-specific. Three animals per arm are duplicated in Supp 2d (I-1) |
| Nuclear STAT5B (Supp 6h, Fig 5h) | Nuclear STAT5B modestly higher with creatine | Single unquantified blots; the Fig 5h nuclear fraction has no nuclear loading or purity control |
| MK-*Stat5b* KO (Fig 6d–g, Supp 7b) | Creatine uptake intact (98 vs 95 µmol/g); most transcripts not induced (*Itga2b* 1.03×, *Runx1* 1.02×) | No KO-vehicle arm. Some induction remains (*P2ry12* 1.9×, *Adra2a* 1.9×, *F2r* 1.6×, *Gpiba* 1.6×). The Fig 6f blots (GP6/P2RY12 lower in KO + creatine than WT + creatine) are single and unquantified. No metastasis or platelet-function test. Different Cre driver (*Pf4-P2A-iCre*) from the *Slc6a8* line |

### 3.8 Human cohort: the platelet signal is real, within the limits of an uncontrolled design

![Human platelet function](figures/fig4_human_platelet_function.png)

**Cohort design**

- 11 healthy Asian volunteers aged 20–25 (6 women, 5 men).
- Open-label and single-arm: 20 g/day for 14 days.
- No placebo and no time-matched control.

**Platelet function, re-analysed on a log scale within each subject**

- **Epinephrine, maximum aggregation:** 1.33× at day 7 (10/11 up) and 1.63× at day 14 (10/11; q = 0.03).
- **Epinephrine, average-rate and adhesion indices:** up in 10–11/11 at days 7 and 14 (q ≤ 0.044).
- **Collagen, maximum aggregation:** 2.5× at day 14 only (9/11; q = 0.03).
- **ADP and arachidonic acid (AA):** no change at any time point (q ≥ 0.13).
- **Day 3:** most indices were below baseline. This is why a placebo and time control is needed.
- **The reported statistics were weaker than they looked, but the result stands.** The original analysis compared each subject against a baseline fixed at exactly 1 (one-way ANOVA/Dunnett), which overstates certainty. The main findings still hold under a proper within-subject analysis.

**The agonist pattern matches the induced receptors, which matters for choosing comparators**

- The responses that rose are to collagen (via GPVI, encoded by *GP6*) and to epinephrine (via the α2A receptor, encoded by *ADRA2A*).
- The responses that did not rise are to ADP (via P2Y12) and to AA (via the COX-1/thromboxane route).
- Aspirin and P2Y12 blockers act on pathways that did not change in humans. A GPVI-directed arm is therefore needed alongside them.

**Transcripts in CD41⁺ cells (n = 4)**

- The CD41⁺ isolates are enriched for *CD41* mRNA (monocytes have about 6 % of the level; MEG-01 cells about 71 %; Supp 8c), so they carry platelet/MK-derived RNA.
- Only *ADRA2A* at day 7 (20.6×) survives FDR.
- *RAB4A* fell in all four volunteers (0.38× at day 14), the opposite of the mouse result.
- Two genes for volunteer 4 cannot be reproduced (I-2).

**Protein (n = 4)**

- GP6/β-actin rose 2.1–5.0× at day 14 (RM-ANOVA p = 0.005).
- P2RY12 rose 1.3–2.7× (p = 0.003), but the representative blots show a smaller change (I-6).

**Transfer (Fig 7g).** Day-7 human platelets raised recipient metastatic burden 2.72× (n = 5/5 recipients; donors not reported).

**Still unknown:**

- Dose–response at maintenance doses.
- Whether the effect reverses after stopping.
- Effects of age, sex and ancestry.
- Causality, which needs a placebo-controlled study.

---

## 4. Data-integrity and design findings

These need to be resolved or designed around. The full log is in `appendix_C_integrity_and_design_log.csv`.

![Duplicate animals](figures/fig5_duplicate_animals.png)

| ID | Where | Finding (short) | Severity | Effect on the decision |
|---|---|---|---|---|
| I-1 | Fig 6b vs Supp 2d | Three animals per arm are identical across the two experiments, in both metastatic burden (to 5–6 significant digits) and foci, in the same order | High | Both panels are excluded from decision-grade use until raw records are produced. They hold the only in vivo STAT5 test and the only mouse antiplatelet test |
| I-2 | Fig 7d | Volunteer 4: PITPNB "ΔCt" values of +26 to +28 appear to be raw Ct. PITPNB and RAB27B normalised values cannot be reproduced, and the day-14 direction reverses. The other 126/132 cells reproduce exactly | Medium | Human transcript evidence is weakened further |
| I-3 | Phosphoproteomics | Null screen (minimum q = 0.167). 29 % single-sample detections (p ≡ 0.4226). No site localisation. 153 duplicate rows | High for the STAT5B claim | Cannot nominate STAT5B |
| I-4 | Fig 1i, 2c, 2j, Supp 4c | Microscope fields used as n; number of animals not stated | Medium | p-values overstated |
| I-5 | Fig 7c, 7e, Supp 8a | Baseline fixed at 1 and compared by ordinary ANOVA; repeated measures ignored; paired BMI data analysed unpaired | Low–medium | Our re-analysis keeps the epinephrine and collagen findings and drops ADP and AA |
| I-6 | Fig 7e vs Supp 8d | Quantified P2RY12 rises 1.3–2.7× in every row. Rough densitometry of the representative blots gives 1.16× and 1.09× for two volunteers. Rows are not labelled by volunteer | Low–medium | Human P2RY12 protein change is less certain than GP6 |
| I-7 | Fig 6a, 6e, 6g, Supp 6a | Inhibitor suppresses baseline expression; no KO-vehicle arm; "WT" control not defined; no canonical pY | Medium | Cannot isolate STAT5B's role in the creatine response |
| I-8 | Fig 5e–5i, Supp 6d | Pan-phospho antibody; separate gels; S127D gives the highest signal; single unquantified images | Medium | S127 is not established as the site |
| I-9 | Supp 2a, 4a blots | Tumour knockdown and MK deletion both incomplete at protein level | Medium | Effect sizes are uncertain |
| I-10 | Fig 3d, Supp 4e | Creatine has an opposite-sign effect on platelets in SLC6A8-null mice and MKs | Biology/safety | Haemostasis endpoints are required |
| I-11 | Labels | sh/si/WT mislabels in Fig 1f and Supp 2a; "Creatinine" axis in Fig 4d; "ADAR2A" in Fig 7d | Low | Clarity only |
| I-12 | Study conduct | Allocation not masked, no sample-size calculation, sex not analysed, one sex per strain, tumour models per panel undocumented | Medium | Effects may be inflated and may not generalise |
| I-13 | Fig 7g | Donor number and recipient strain not stated | Medium | Replication is at recipient level, not donor level |
| I-14 | ChIP | Repeated %-input values map exactly onto round ΔCt values, consistent with the stated two-decimal rounding; no IgG or KO controls in the data | Low | Specificity not verified |
| I-15 | qPCR | Each treated replicate was paired with an arbitrary control replicate. Recomputing against the control mean changes no conclusion | Low | None |

These findings may have innocent explanations, such as shared control animals or spreadsheet errors. They should be resolved, not presumed to be misconduct.

---

## 5. Proposed studies

### 5.1 Study 1 (the in vivo slot): CRE-MK-02, confirming megakaryocyte SLC6A8

| Element | Specification |
|---|---|
| Question | Does loss of SLC6A8 restricted to megakaryocytes prevent creatine-driven lung metastasis under blinded, powered, sex-balanced conditions? Does it do so by preventing creatine loading in MKs and platelet priming, without compromising haemostasis? |
| Design | Randomised and blinded 2 × 2 factorial. Factor 1 is genotype: *Pf4-Cre;Slc6a8<sup>fl/fl</sup>* (females) or *<sup>fl/Y</sup>* (males) versus *Pf4-Cre;Slc6a8<sup>+/+</sup>* or *<sup>+/Y</sup>* littermates. Factor 2 is exposure: creatine versus vehicle. Stratified by sex and litter. The analysis plan is locked before the first animal is dosed. Animals are allocated by someone not involved in injections or scoring. Histology is scored blind |
| Population | Both sexes, aged 8–12 weeks, from the same colony and genetic background as Fig 3 |
| Exposure | Module A uses gavage as in the package's main experiments (17 mg, 3×/week), to replicate Fig 3i. Module B uses a 5 % creatine diet versus a matched control diet (continuous, closer to human use). Exposure starts 14 days before tumour challenge, so that at least one platelet turnover occurs, and continues to the endpoint. Exposure is checked: serum creatine must be ≥2.5× baseline in creatine arms and equal across genotypes |
| Clinical indication represented | Patients with resected solid tumours at risk of blood-borne (lung) metastasis who are exposed to supplemental creatine; the use case is risk mitigation and biomarker, not standalone anti-metastatic therapy |
| Tumour settings (stand-ins for the clinical indication) | Module A: experimental lung metastasis with the melanoma line of Fig 1f, syngeneic to the colony (replicates Fig 3i). Module B: spontaneous lung metastasis from an orthotopic primary tumour in a B6-syngeneic line, chosen from lines available in house, with primary-tumour growth measured so a growth effect can be separated from a dissemination effect. The WT creatine effect in Module B is itself a readout, because the package does not document a spontaneous model |
| Primary endpoint | Lung metastatic burden (% area) in Module A, read blind from whole-lung step sections |
| Primary analysis | Linear model on log burden with terms for genotype, exposure, genotype × exposure, sex and batch. The primary test is the genotype × exposure interaction. The creatine ratio within each genotype is reported with its 95 % CI. The animal is the unit of analysis |
| Key secondary endpoints | Foci count; lung weight; burden and primary-tumour growth in Module B; time to humane endpoint (Tier 3) |
| PD readouts (satellite group, n = 6 per cell, measured at tumour challenge) | Serum creatine; MK creatine and phosphocreatine; MK CKB; a pre-specified score across the 11 genes of Fig 2f; platelet aggregation to collagen, ADP, thrombin and epinephrine (epinephrine added because it was the most consistent human signal); surface GPVI and P2Y12; α-granules with the animal as the unit; lung retention of tumour cells at 6–24 h |
| Safety readouts | Platelet count and indices; tail bleeding time; TEG; body weight and food intake |
| Genotype quality control | Loss of SLC6A8 protein in MKs and platelets (target ≥80 %); check for recombination in haematopoietic cells other than MKs |
| Comparators | Cre-only littermates (genotype control); vehicle or control diet (exposure control). Tier 3 adds WT + creatine + aspirin 30 mg/kg/day (the regimen used in the package), to benchmark genetic protection against an available drug. Tier 3 also adds a WT arm that starts creatine 24 h *after* tumour challenge, to separate an effect on seeding from an effect on outgrowth |
| Sample size | 16 per cell (8 per sex) in each module. The pooled within-group SD of log burden across the package is 0.44 (range 0.14–0.71). With 16 per cell, power to detect a 75 % reduction of a 2.9-fold creatine effect (two-sided α = 0.05) is 95 % at SD 0.44, 89 % at SD 0.5 and 76 % at SD 0.6. Power to replicate a 2-fold effect in controls is >90 %. Survival group: 24 per arm gives about 48 events, which provides 80 % power at HR 2.3 |
| Animal numbers by tier | Tier 1: Module A 64 + PD 24 = 88. Tier 2: Module B 64 (152 in total). Tier 3: survival 48, aspirin 16, post-seeding 16 (232 in total) |
| Success criteria (all pre-specified) | (1) Assay sensitivity: creatine effect in controls ≥2-fold with lower 95 % CI >1.3. (2) Interaction p < 0.05, and the creatine effect in KO ≤25 % of the control effect on the log scale, with upper 95 % CI <1.6-fold. (3) The rise in MK creatine is ≥70 % smaller in KO. (4) Bleeding time in KO is no more than 1.5× that of control-vehicle animals. (5) Same direction in both sexes and, in Tier 2, in Module B |
| Timeline | Before the slot (now, 2–4 weeks): fix the data issues, lock the analysis plan, expand the colony. Slot weeks 1–10: 14 days of exposure before challenge, then the tumour phase (median survival in the package's experimental-metastasis cohorts was 14–21 days). Slot weeks 10–13: blinded read-out, with the decision memo at quarter end. If the colony cannot supply Tier 2 in time, run Tier 1 first and Tier 2 straight after |

### 5.2 Study 2 (Backup 2: STAT5B)

**Gate — run in parallel with Study 1, no animals needed**

1. Resolve I-1 from animal IDs and raw lung images.
2. Show site-level STAT5B phosphorylation in primary MKs with and without creatine (n ≥ 4 per group). This means targeted quantification of the S127 and Y699 phosphopeptides, or a validated site-specific antibody.
3. Show that an S127 mutant cannot support the creatine transcript program in *Stat5b*-null MKs.
4. Show that the ChIP signal is lost in *Stat5b*-null MKs.

**In vivo study — next slot, only if the gate passes**

- Design: *Pf4-iCre;Stat5b<sup>fl/fl</sup>* versus *Pf4-iCre;Stat5b<sup>+/+</sup>* littermates, each with creatine or vehicle. This line uses a different Cre driver (*Pf4-P2A-iCre*) from the *Slc6a8* line, so it needs its own Cre-only controls. The control genotype must be stated explicitly; the package's "WT" is not defined.
- Model, endpoints and power: the same as Study 1 Module A (64 mice).
- Additions: a KO-vehicle arm (missing from the package) and platelet-function readouts (never measured in *Stat5b* KO).
- Promotion rule: if the interaction shows a ≥75 % reduction *and* site-level phosphorylation replicates, STAT5B becomes co-primary as an MK-intrinsic node downstream of entry.

### 5.3 Study 3 (Backup 1: the platelet-activation layer)

**Design**

- WT mice given creatine or vehicle, crossed with four agents: vehicle, aspirin, a P2Y12 antagonist, and a GPVI-blocking tool.
- This is a 2 × 4 factorial with 12 per cell, 96 mice in total.
- The tools must first be qualified internally for target engagement, measured by agonist-specific aggregation.

**Indication represented:** mitigation in creatine-exposed patients with cancer, using an approved or platelet-restricted agent.

**Endpoints**

- Primary: the agent × creatine interaction on lung metastatic burden. The question is whether the agent removes the creatine increment, not merely lowers the baseline.
- Secondary: bleeding time, and aggregation to each agonist.

**Why these comparators**

- *Aspirin* is the only antiplatelet drug used in the package. It blocks the COX-1 route, which did not change in humans.
- *P2Y12 blockade* targets a receptor whose transcript and protein rose, but whose functional readout (ADP) did not change in humans.
- *GPVI blockade* matches the collagen hyperreactivity seen in mice and humans.

**Timing:** next slot, or sooner if Study 1 Tier 3 includes the aspirin benchmark.

### 5.4 Study 4: randomised, placebo-controlled human PD study

This runs in parallel and does not use the in vivo slot.

| Element | Specification |
|---|---|
| Population | Healthy adults aged 18–65, both sexes, several ancestries; no antiplatelet or NSAID use; stratified by age (<40 / ≥40). The package cohort was 11 Asian adults aged 20–25 |
| Indication represented | Exposure–response for supplemental creatine in people; this defines the dose at which the platelet liability appears. No disease indication |
| Design | Double-blind, placebo-controlled, parallel groups. Stage 1: placebo versus 20 g/day for 14 days (the package exposure), 20 per arm. Stage 2, only if Stage 1 is positive: placebo versus a maintenance-range dose (for example 3–5 g/day) for 28 days, about 60 per arm |
| Primary endpoint | Placebo-adjusted change at day 14, on a log scale, in maximal aggregation induced by epinephrine and by collagen (tested hierarchically) |
| Secondary endpoints | ADP and AA responses; surface GPVI and P2Y12 on platelets; creatine and phosphocreatine content of platelets (the bridge to SLC6A8); a platelet transcript score; serum creatine (exposure–response); CBC; coagulation; reversal 14 days after stopping |
| Exploratory | Ex vivo addition of aspirin, a P2Y12 antagonist or GPVI blockade to day-14 samples, to see which normalises the creatine increment. Platelet transfer designed at donor level: each donor's platelets into ≥3 recipient mice, analysed by donor |
| Sample size | From our re-analysis, the SD of the log2 change is 0.58 for epinephrine and 1.13 for collagen. 20 per arm gives ≥96 % power for the observed effects. About 60 per arm gives 90 % power for half the observed effect, which is likely at lower doses or once regression to the mean is accounted for |
| Ethics | No creatine will be given to patients with cancer in any interventional study |

### 5.5 Study 5 and the pharmacology gate

**Clinical context (observational study)**

- Setting: existing cohorts of patients with resected melanoma or breast cancer.
- Measure:
  - Creatine-supplement use.
  - Serum creatine.
  - Platelet reactivity, in a subset of patients.
- Relate these to distant-metastasis-free survival.
- Purpose: to generate hypotheses, and to establish how large the at-risk population is and how to find it.

**SLC6A8 pharmacology gate.** No SLC6A8 blocker enters an in vivo slot until, in our own system, it has been shown to do all of the following:

- Inhibit creatine accumulation in isolated MKs.
- Abolish the transcript program.
- Reach those levels at achievable exposures.
- Avoid depleting brain or muscle creatine at those exposures. Fig 4a and 4c show these tissues respond to creatine.

---

## 6. What would elevate one choice over another

| Result | Decision |
|---|---|
| Study 1 meets criteria 1–5 | SLC6A8 is confirmed as primary. Next: the pharmacology gate, the human bridge (creatine content of platelets) and Study 3 to choose the intervention |
| Study 1: control effect replicates, but KO removes only 25–75 % of it, or protection appears in one module only | SLC6A8 contributes but is not the gate. Promote **Backup 1** (the platelet layer sits downstream of any entry route) into the next slot |
| Study 1: KO protects, but with prolonged bleeding or reduced baseline platelet function beyond threshold | Reframe SLC6A8 as mechanism and biomarker rather than a drug target. Choose the intervention from the platelet layer (a node with a known bleeding profile) |
| Study 1: the creatine effect in controls fails to replicate under blinding (<1.5× or CI includes 1) | Stop. The phenotype is not robust enough to justify any target |
| Study 3: an approved agent (aspirin or P2Y12 antagonist) removes ≥75 % of the creatine increment without extra bleeding beyond its known profile, and Study 4 confirms placebo-controlled priming | This becomes the fastest route to patients: mitigation in creatine-exposed patients |
| Study 3: only GPVI blockade removes the increment, and Study 4 confirms collagen/GPVI-pathway priming | GPVI becomes the translational lead target |
| Study 2: I-1 resolved, site-level STAT5B phosphorylation replicated, and MK-*Stat5b* KO removes ≥75 % of the effect | Promote STAT5B to co-primary as the MK-intrinsic transcriptional node |
| I-1 unresolved, or site-level phosphorylation not reproduced | Drop STAT5B from the portfolio case and keep it as a mechanistic footnote |
| Study 4 shows no placebo-adjusted effect at maintenance doses | Lower the clinical urgency; the liability may be confined to loading-dose exposure |

---

## 7. Assumptions, risks and limits of this analysis

- **Tumour models.** The package does not say which tumour line underlies each panel. Module A assumes the Fig 1f melanoma line is available and syngeneic to the colony. Both strains in the conventions (C57BL/6J male, BALB/cJ female) would need to be checked.
- **Effect sizes are probably inflated.** Unblinded, small studies tend to overstate effects. Power has been set for a 75 % reduction and an SD up to 0.6, not for the observed effect.
- **Densitometry is approximate.** Values from the embedded JPEG blots (I-6, I-9) are rough. Raw images are needed.
- **Published literature was excluded by design.** As a result, choices such as which GPVI tool and which P2Y12 antagonist to use still need internal qualification before Study 3.
- **The X-linked colony may limit supply.** Breeding should start at once.
- **The indication is conditional on creatine exposure.** If Study 5 shows the exposed population is small or hard to identify, the value of the programme shifts towards risk communication rather than a drug indication.

---

## Appendix A: how the numbers were derived

- **Extraction**
  - All 87 source-data sheets were parsed programmatically, cell by cell.
  - All 26 embedded images were reviewed.
  - The phosphoproteomics sheet was read in full.
- **Two-group tests**
  - Student's t, as in the package, re-run on raw values; Welch's t reported alongside.
  - All reported t, df and p values agree with the reported values.
- **Multi-group tests**
  - One-way ANOVA with Tukey's test, recomputed with statsmodels; all agree with the reported values.
  - "Abolition" claims were tested formally as interactions: two-way ANOVA (type II) on raw and log-transformed outcomes.
- **Survival:** log-rank and Cox regression using lifelines.
- **Forest plot:** ratio of means with a delta-method SE of the log ratio, pooled by DerSimonian–Laird random effects.
- **qPCR:** ΔΔCt against the control-group mean, with t-tests on ΔCt. The package's method pairs each treated replicate with an arbitrary control replicate.
- **Human data**
  - Log2 fold change against each subject's own day 0.
  - One-sample t-tests and Wilcoxon signed-rank tests, with BH-FDR applied across all 36 combinations of agonist, parameter and day.
  - Repeated-measures ANOVA and Friedman tests for Fig 7b, 7e and Supp 8b.
  - The Fig 7d normalised values were recomputed as mean(2<sup>ΔCt</sup> at day d) ÷ mean(2<sup>ΔCt</sup> at day 0). 126 of 132 cells matched to within 10⁻⁵.
- **Phosphoproteomics**
  - q-values were checked by BH.
  - The single-detection signature was identified from the repeated p = 0.42265 (Welch t = 1, df = 2).
  - The p-value histogram was examined, and nominal hits were counted against the null expectation.
- **Duplicate scan:** exact matches of high-precision values, and of consecutive sequences of three or more values, across all sheets.
- **Densitometry:** background-subtracted integrated band intensity from the JPEGs. This is approximate.
- **Power calculations**
  - Normal approximation for two-group comparisons and for the 2 × 2 interaction contrast, whose variance is 4σ²/n.
  - Schoenfeld event numbers for survival.
  - SDs were taken from the package itself.

## Appendices B–I (files)

| Appendix | File | Contents |
|---|---|---|
| B | `appendix_B_panel_register_two_group.csv` | Every two-group panel with means, ratios, reported p, recomputed p and Welch p |
| C | `appendix_C_integrity_and_design_log.csv` | The full integrity and design log, with requested fixes |
| D | `appendix_D_human_aggregation_reanalysis.csv` | The 36 human aggregation tests |
| E | `appendix_E_human_qPCR_reanalysis.csv` | The 33 human transcript tests |
| F | `appendix_F_interaction_tests.csv` | Genotype/drug × creatine interaction tests for Fig 1f, 3d, 3i and 6b |
| G | `appendix_G_MK_qPCR_reanalysis.csv` | 196 MK transcript comparisons, recomputed against the control mean (ΔΔCt), with p-values |
| H | `appendix_H_phosphoproteomics_summary.csv` | Phosphoproteomics quality metrics and the Stat5b/Stat5a rows |
| I | `appendix_I_metastasis_effect_by_panel.csv` | Data behind Figure 1: effect on metastasis for each panel |
| — | `analysis_scripts/` | All code used to produce the numbers and figures above |
