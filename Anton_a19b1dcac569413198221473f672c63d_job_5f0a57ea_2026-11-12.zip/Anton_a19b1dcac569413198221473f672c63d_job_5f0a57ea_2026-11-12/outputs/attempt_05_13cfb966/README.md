# CRE-MK-01 follow-up validation proposal: deliverables

**Main document:** `CRE-MK-01_validation_proposal.pdf` (the same content is in `.md`). The first line is the recommendation.

| Folder | Contents |
|---|---|
| `figures/` | **Fig1:** creatine effect across all experiments (forest plot) and the 2×2 interaction tests. **Fig2:** volunteer platelet read-outs, re-analysed. **Fig3:** data-integrity flags. |
| `tables/` | **T1:** every two-group panel, recomputed (Student as reported, Welch, exact Mann–Whitney, GMR, Hedges g). **T2:** factorial interaction tests. **T3:** meta-analysis. **T4:** volunteer platelet function (paired tests, BH-FDR). **T5:** volunteer CD41⁺ qPCR. **T6:** mouse qPCR contrasts. **T7:** data-integrity and design log (16 items). **T8:** power for the in vivo slot. |
| `analysis/` | Python scripts that regenerate every number, table and figure. |

**Running the scripts**

- Run `extract.py` first, in an environment with openpyxl. It writes `/tmp/work/tidy.json`; a copy is saved as `tidy_extracted_data.json`.
- Then run:
  - `an*.py`: analyses;
  - `export_*.py`: tables;
  - `fig_*.py`: figures;
  - `md_to_pdf.py`: builds the PDF.
- `dens2.py` is the approximate densitometry of the displayed human blots. Its estimates are approximate and are used only to flag disagreements.

**Scope:** the analysis uses only the supplied workbook, the phosphoproteomics table and the study conventions. No external data were used as evidence.
