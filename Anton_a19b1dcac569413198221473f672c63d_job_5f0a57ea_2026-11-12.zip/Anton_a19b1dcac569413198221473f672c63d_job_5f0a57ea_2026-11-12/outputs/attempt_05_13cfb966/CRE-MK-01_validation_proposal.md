**Recommendation: take forward megakaryocyte SLC6A8 as the primary target. SLC6A8 is the transporter that lets exogenous (supplemental) creatine into megakaryocytes, which then make pro-metastatic platelets. Use next quarter's in vivo slot for a blinded, powered, two-model test of whether deleting Slc6a8 in megakaryocytes removes creatine-driven metastasis. Run GPVI-driven platelet hyper-reactivity as the druggable backup in a shared-control arm of the same study. Hold STAT5B as a conditional backup until a duplication of data between two figure panels is resolved.**

# CRE-MK-01: follow-up validation proposal

*For: the portfolio committee, in vivo slot allocation. Basis: the CRE-MK-01 source workbook (87 panels), the phosphoproteomics table and the study-conventions document. I recomputed every statistic in this document from the raw values (Appendix A). No external data were used as evidence.*

Abbreviations: MK = megakaryocyte; GMR = ratio of geometric means (creatine ÷ control); CI = 95% confidence interval; q = Benjamini–Hochberg false-discovery rate.

---

## 1. Decision summary

**What we take forward, and why**

- **MK SLC6A8 is the only node where removing it in vivo abolished the creatine effect on metastasis (Fig 3i).**
  - In Cre-matched controls, creatine raised lung metastatic burden 3.56-fold (CI 2.10–6.01).
  - In Pf4-Cre;Slc6a8-deleted mice it did not (0.79-fold, CI 0.47–1.34).
  - The ratio of the two effects (the interaction) was 0.22 (CI 0.11–0.47, p = 0.0009).
  - Foci and lung weight agree: interactions of 0.45 (0.23–0.88) and 0.84 (0.78–0.90).
- **The block sits in the MK, not in creatine exposure.**
  - Serum creatine rose equally in both genotypes: 2.7-fold vs 2.5-fold (Fig 3b).
  - Deletion also removed the creatine-induced rise in α-granules (Supp 4c), platelet aggregation (Fig 3d) and MK GP6/P2RY12 protein (Fig 3g).
  - In Slc6a8-null MKs, creatine packaged in liposomes (which bypasses the transporter) restored the gene program (Supp 4e).
- **SLC6A8 sits upstream of every effector we might drug, so confirming it de-risks the whole axis.**
  - I found no duplication or provenance anomaly in the Fig 3i metastasis data. Its lung-weight spread is unusually tight (CV 3–4% vs 6–34% in other experiments), so its raw records are included in the Study 0 audit.
  - Its companion qPCR (Fig 3f) is affected (§2.7).
- **"Primary" means the node the slot must validate first, not the molecule we would dose.** Systemic SLC6A8 inhibition is not a development path on current evidence: the brain also accumulates creatine (Fig 4a). The development modality (a platelet effector such as GPVI, or exposure management) is chosen from the same study's GPVI arm and pharmacodynamic read-outs (§4.7).

**Why not the alternatives (yet)**

- **STAT5B.** This is the package's headline mechanism, but its support is compromised or missing:
  - The only in vivo efficacy data, the STAT5 inhibitor experiment (Fig 6b), share three vehicle and three creatine animals with the platelet-transfer/aspirin experiment (Supp 2d). Burden matches to seven significant digits and foci counts are identical.
  - No Stat5b-knockout metastasis experiment exists.
  - The phosphoproteomic STAT5B hit is not FDR-significant.
  - The inhibitor suppresses baseline MK expression, so its effect is not specific.
  - In volunteers, RAB4A (a STAT5 ChIP target) falls rather than rises.
- **GPVI.** It has the best human support, and the receptor class is druggable in principle (not verified in our system):
  - Collagen-induced aggregation rose 2.5-fold by day 14 in 9/11 volunteers (q = 0.02).
  - GP6 protein rose in 4/4 volunteers.
  - However, nothing in our data tests GPVI causally, so it is the backup and is tested inside the same slot.
- **P2Y12, COX-1/aspirin, CKB, RAB4A and tumour-cell SLC6A8** are deprioritised; reasons are in §3.

**What the slot buys (Study 1, §4.2)**

- Design: Pf4-Cre;Slc6a8-deleted mice vs Cre-matched littermates, × creatine vs control.
  - Both sexes; two tumour models syngeneic to the knockout background; n = 15 per cell.
  - Blinded histomorphometry.
  - A shared-control GPVI-blockade arm.
  - Pharmacodynamic satellite cohorts.
- Power, at the upper-quartile SD observed in our data, to detect complete removal of a creatine effect as small as 2.0-fold: 0.83 in one model, 0.99 with both models pooled. The pooled estimate across our experiments is 3.2-fold.
- Size: the minimum viable version is about 90 mice (one model, core factorial only); the recommended version is about 230.

**Pre-registered go/no-go rules**

| Outcome of Study 1 | Decision |
|---|---|
| Creatine effect in controls GMR ≥ 1.5 (lower CI > 1) **and** SLC6A8 interaction ≤ 0.5 with upper CI < 1 (pooled), with the same direction in each model | **GO:** SLC6A8 axis validated. Choose the intervention point from the GPVI arm and the PD read-outs. |
| GPVI blockade removes ≥ 60% of the log creatine effect (interaction upper CI < 1), with no excess bleeding vs isotype | **Promote GPVI** to lead druggable target (Study 2, which adds the aspirin comparator) |
| Creatine effect replicates, but the SLC6A8 interaction is between 0.5 and 0.8, or its CI includes 1 | SLC6A8 is only partly required. Test tumour SLC6A8 with a validated knockout; GPVI becomes lead if its arm is positive. |
| Creatine effect not reproduced under blinding (pooled GMR < 1.25, or upper CI < 1.5) | **STOP** the creatine-metastasis axis |

**Gating work that needs no slot (Study 0, 2–4 weeks).** This audit decides whether the STAT5B and aspirin evidence can re-enter the ranking. It covers:

- source records for the Fig 6b / Supp 2d duplication;
- raw aggregometry traces (Fig 2b);
- raw qPCR Ct files (Figs 2f–6g, 7d);
- uncropped, unsaturated blots;
- site-level phosphoproteomics output.

---

## 2. What the data package supports: re-analysis

### 2.1 The phenotype: creatine increases lung metastasis in every experiment, but no experiment was blinded

![Figure 1. A: creatine effect on metastatic burden in all 10 experiments, re-analysed on the log scale (Welch CIs), with random-effects pooling. B: 2×2 experiments showing which perturbations remove the creatine effect.](figures/Fig1_creatine_effect_forest.png)

**Metastasis endpoints across 10 independent vehicle-vs-creatine contrasts** (Figs 1b, 1k, 1f, 3i, 6b; Supp 1e, 1f, 1g, 1i, 1k):

| Endpoint | Pooled creatine effect, random effects | Heterogeneity |
|---|---|---|
| Lung metastatic burden | GMR 3.18 (2.62–3.86) | I² = 59% |
| Metastatic foci | 2.02 (1.74–2.35) | I² = 70% |
| Lung weight (7 experiments) | 1.33 (1.21–1.45) | I² = 63% |

- All 10 experiments are individually significant.
- Dropping Fig 6b (duplication, §2.7) leaves burden at 3.04 (2.51–3.68).
- The effect holds with 5% creatine diet as well as gavage (Supp 1i: 3.53-fold).

**Survival** (Fig 1c, 1l; log-rank reproduced exactly):

| Experiment | Hazard ratio (creatine vs vehicle) | Median survival |
|---|---|---|
| Fig 1c | 2.93 (1.04–8.23) | 21 → 18 d |
| Fig 1l | 2.28 (1.16–4.46) | 16 → 14 d |

Fig 1l has 20 vs 18 mice with no recorded attrition.

**Where in the metastatic cascade (Fig 1h)**

- Tumour-cell signal in the lung at 15 min was unchanged: 0.83-fold (0.60–1.15).
- It was higher with creatine at:
  - 6 h: 1.51-fold (1.30–1.75);
  - 12 h: 1.90-fold (1.13–3.20);
  - 24 h: 2.80-fold (1.50–5.24).
- Creatine therefore does not change initial arrest. It improves survival or retention of arrested tumour cells over the first day, which is the window in which a platelet-mediated mechanism would operate.

**Caveats**

- Allocation was not masked at any stage and there was no sample-size calculation.
- Sex was confounded with strain (male C57BL/6J vs female BALB/cJ).
- There is modest small-study asymmetry (Egger p = 0.057 for burden).
- The true effect is therefore probably smaller than 3.2-fold, so Study 1 is powered for 2.0-fold.

### 2.2 Exposure bridge: human exposure is within the range that drove metastasis in mice

| Setting | Serum creatine, control → creatine | Source |
|---|---|---|
| Mouse, oral gavage: 17 mg three times a week (≈ 340 mg/kg/day averaged) | 66 → 178 µM (2.7-fold) | Supp 1d |
| Mouse, 5% diet | 78 → 227 µM (2.9-fold) | Supp 1h |
| Mouse, Pf4-Cre controls | 89 → 239 µM | Fig 3b |
| Volunteers, 20 g/day for 14 days (≈ 350 mg/kg/day at the mean body weight of 57.6 kg) | 45 → 153–159 µM (3.5-fold; every volunteer ≥ 2.1-fold) | Fig 7b |

- The mouse exposures that increased metastasis are within about 1.5× of those reached by our volunteers.
- No lower daily dose was tested in humans.
- Within the cohort there was no exposure–response (all |ρ| ≤ 0.51, all p ≥ 0.11), which is expected with a single dose level.

### 2.3 Where in the pathway: the causal tests

2×2 designs, analysed on the log scale. The creatine effect in each background is the GMR; the interaction is the ratio of creatine effects in the perturbed vs the control background. CIs here come from the pooled-variance 2×2 model, so they differ slightly from the per-experiment Welch intervals in Figure 1A.

| Perturbation (panel, n per cell) | Creatine effect, control background | Creatine effect, perturbed | Interaction (CI), p | Evidence status |
|---|---|---|---|---|
| MK Slc6a8 deletion (Fig 3i, n = 4) | 3.56 (2.10–6.01) | 0.79 (0.47–1.34) | **0.22 (0.11–0.47), 0.0009** | Clean; single experiment; unblinded |
| Tumour-cell shSlc6a8 (Fig 1f, n = 6) | 4.07 (2.52–6.58) | 3.16 (1.95–5.10) | 0.77 (0.39–1.53), 0.44 | Knock-down incomplete at protein level (§2.7) |
| STAT5-IN-1, oral (Fig 6b, n = 5) | 4.08 (2.79–5.98) | 1.30 (0.89–1.90) | 0.32 (0.19–0.54), 0.0004 | 3 of 5 animals per control arm duplicated in Supp 2d |
| Aspirin-treated creatine-donor platelets (Supp 2d, n = 6) | Creatine-donor vs vehicle-donor 3.26 (1.81–5.90) | Aspirin-donor vs vehicle-donor 0.71 (0.30–1.68) | — | Same duplication |

The SLC6A8 result is supported by concordant mechanistic read-outs:

- Serum creatine is unaffected by genotype (Fig 3b). The MK-level block is not complete and statistically marginal:
  - MK creatine rose 4.9-fold in controls vs 1.7-fold in knockouts (Fig 3c).
  - The interaction p is 0.065 with n = 3, so this pharmacodynamic readout needs a powered repeat.
- The creatine-induced rises in α-granules (Supp 4c, interaction 0.45) and MK GP6/P2RY12 protein (Fig 3g) are absent in knockouts.
- Liposomal creatine, which bypasses SLC6A8, restores induction of 9/11 program genes in Slc6a8-null MKs (Supp 4e; e.g. Gp6 2.8-fold, P2ry12 2.2-fold). Plain creatine does not (Gp6 1.25-fold, P2ry12 1.04-fold).

**Caution: the knockout is not a neutral background.**

- Slc6a8-null platelets hypo-aggregate at baseline (thrombin 45% vs 61%).
- In knockouts, creatine lowers aggregation rather than leaving it unchanged (Fig 3d).
- Study 1 therefore includes bleeding time and a bypass-specificity read-out.

### 2.4 Platelets as the carrier, and the MK time lag

- **MK re-programming, not a direct platelet effect.** In vitro, creatine raises GP6 and P2RY12 protein in MKs but not in isolated platelets (Fig 2i).
- **Human time course fits an MK-origin effect.** Volunteers show no platelet-function change at day 3, and changes at days 7–14 (§2.5), consistent with the time needed to replace circulating platelets.
- **Human platelets carry the phenotype into mice.** Platelets taken from volunteers on day 7 raised metastatic burden 2.76-fold (1.60–4.77) vs their day-0 platelets (Fig 7g). This is the only platelet-transfer result not implicated in the duplication. However, n = 5 per arm, it was unblinded, and donor pooling is undocumented.
- **Platelet counts and indices do not change**, in mice (Figs 2a; Supp 4b, 7a, 7b) or in volunteers (Supp 8b). The change is functional, not numerical.

### 2.5 The effector layer: which receptor matters in humans

![Figure 2. Volunteer read-outs. A: platelet function re-analysed with paired tests and FDR across 36 tests. B: platelet protein per volunteer. C: day-14 protein fold-change as reported vs my densitometry of the displayed blots.](figures/Fig2_human_platelet_readouts.png)

**Mouse MK transcripts**

- Across six creatine-vs-control experiments: P2ry12 2.0–5.2-fold, Gp6 2.8–42-fold, Adra2a 2.2–17.7-fold.
- But all 11 panel genes move together, and the qPCR layer has provenance problems (§2.7), so these are supportive only.

**Volunteer platelet function (Fig 7c)**

I re-analysed this with paired tests on the log scale and FDR control across 36 tests; the original analysis ignored repeated measures. The change was concentrated in two agonists:

| Agonist (receptor) | Day 7 | Day 14 | Verdict |
|---|---|---|---|
| Epinephrine (α2A) | 1.33–1.78-fold, 10–11/11 up | 1.63–2.11-fold, 10–11/11 up | q ≤ 0.02 at both days |
| Collagen (GPVI), max / avg | — | 2.51 / 2.72-fold, 9/11 up | q = 0.02 |
| Arachidonic acid (COX-1) | — | 1.3–1.8-fold | Trend only, q ≥ 0.07 |
| ADP (P2Y12) | — | ≤ 1.17-fold | Flat, q ≥ 0.58 |

- Nothing changed at day 3 (all q ≥ 0.48).
- All four agonists were tested on the same samples. A global assay drift would move all of them, so ADP staying flat while epinephrine and collagen rise points to a receptor-selective change, despite the absence of a placebo arm.
- Results hold when volunteer 5 is excluded. That volunteer shows a COX-inhibitor-like collapse of arachidonic-acid responses on days 3–7 (§2.7).
- Epinephrine was never tested in mice, so the α2A signal is human-only. Study 1 adds epinephrine to mouse aggregometry.

**Volunteer transcripts (Fig 7d; CD41⁺ cells, n = 4; unadjusted p)**

- ADRA2A: up in 4/4 volunteers at day 7 (20.6-fold, p = 0.001) and day 14 (4.0-fold).
- GP6: up in 4/4 at days 7 and 14.
- RAB4A: *down* in 4/4 at day 14 (0.36-fold, p = 0.002).

**Volunteer platelet protein (Fig 7e, n = 4)**

- GP6: up in 4/4 at day 7 (reported 2.0-fold) and day 14 (2.6-fold).
  - My densitometry of the displayed blots (Supp 8d) reproduces the direction at day 14 (1.35–1.84-fold) but not the magnitude.
- P2RY12: the reported increase (1.33–2.73-fold) is not reproduced by my densitometry (0.97–1.24-fold).

**Conclusion: in humans, GPVI and α2A carry the functional signal, and P2Y12 does not.**

### 2.6 The transcriptional node (STAT5B, CKB): weakest layer of the package

- **Phosphoproteomics**
  - No peptide passes FDR (minimum BH q = 0.25; supplied Q-values ≥ 0.167).
  - There is no excess of small p-values.
  - 29% of peptides share one identical p-value, an artefact of how missing values were handled.
  - The study's "differential" rule selects 209 peptides, about as many as chance predicts (~216).
  - The Stat5b phosphopeptide ranks 17th of 5,812 (p = 0.0012, q = 0.25). Its log2 fold-change of 5.7 has an on/off pattern typical of imputed values. The site is not given.
- **S127 evidence**
  - It rests on a pan-phospho antibody read-out. Replicate blots show saturation, bubbles or smears, and vehicle and creatine lanes sit on separate membranes.
  - A phosphomimetic S127D residue cannot be read as phospho-serine, so its higher pan-phospho signal does not show S127 phosphorylation.
  - Canonical STAT5 pY694/699 is undetectable in MKs (Supp 6a).
  - The genotype × creatine interaction is p = 0.006 (Fig 5e) and p = 0.067 (Fig 5f).
- **The inhibitor and the knockout**
  - STAT5-IN-1 alone lowers baseline expression of most panel genes (e.g. Rab4a 0.21-fold, Gp6 0.39-fold; Fig 6a).
  - Stat5b-knockout experiments have no knockout-vehicle arm and no metastasis endpoint. Knockout MKs still show residual induction (P2ry12 1.9-fold, Adra2a 1.9-fold; Fig 6g).
- **CKB**
  - The evidence is in vitro only.
  - Ckb siRNA attenuates but does not abolish induction: creatine still raises 6/11 genes 1.5–3.2-fold (Fig 4j). This is hidden by normalising every group to the scrambled-siRNA control.
  - CKB overexpression induces the program without changing MK creatine or phosphocreatine (Supp 5c).
  - Brain expresses far more CKB than MKs (Fig 4b).
- **ChIP**
  - STAT5 occupancy at P2ry12, Gp6 and Rab4a promoters rises 2.7–12-fold (Fig 5j; Supp 6i).
  - However, the exon control regions read 5–11% of input, no IgG values are given, and two Rab4a primer pairs share one forward primer.

### 2.7 Data-integrity and design findings

Full log: `tables/T7_data_integrity_and_design_log.csv`.

![Figure 3. Integrity flags. A: the same animals appear in two experiments. B: baseline ΔCT of the same genes across experiments. C: phosphoproteomics p-value distribution. D: structure of the Fig 2b triplicates.](figures/Fig3_data_integrity_flags.png)

| # | Severity | Finding | Decision consequence |
|---|---|---|---|
| I-1 | Critical | The same 3 vehicle and 3 creatine animals (burden to 7 significant digits, identical foci, same order) appear in **Fig 6b** (STAT5 inhibitor) and **Supp 2d** (platelet transfer ± aspirin). | The STAT5-inhibitor and aspirin evidence cannot support a decision until source records are produced. |
| I-2 | Critical | **Fig 2b**: in all 6 aggregation triplicates the 3rd value equals the mean of the other two. Simulated probability for independent readings: about 10⁻⁵ to 10⁻⁹. | The wild-type mouse aggregation increase is unverified until raw traces are seen. |
| I-3 | Major | **Fig 3f**: the WT-creatine ΔCT values are not instrument-native; for 8/11 genes they equal the vehicle ΔCT plus a float32 increment, consistent with reconstruction from fold-changes. Baseline ΔCT of the same genes in MKs differs by 7–19 cycles between experiments and changes sign in Fig 3f. | No qPCR result can be used as decision evidence without raw Ct files. |
| I-4 | Major | **Fig 7d**: PITPNB volunteer-4 values look like raw Ct values (+26 to +28). Plotted values for PITPNB-V4 and RAB27B-V4 do not reproduce from the sheet (RAB27B day 14: 0.54-fold recorded vs 2.36-fold plotted). | Those human transcripts are excluded. |
| I-5/6 | Major | Phosphoproteomics is FDR-null; S127 evidence rests on pan-phospho blots with quality problems. | STAT5B mechanism is hypothesis-generating only. |
| I-7 | Major | STAT5-IN-1 is not specific; Stat5b-knockout data lack a knockout-vehicle arm and any in vivo endpoint. | STAT5B necessity is untested. |
| I-8 | Major | Volunteer study: single-arm, unblinded, no placebo, repeated measures ignored, no multiplicity control, n = 4 for molecular read-outs. Circulating "CD41⁺ cells" are likely dominated by platelets rather than MKs. Volunteer 5 has an aspirin-like arachidonic-acid collapse on days 3–7. | Human data are hypothesis-generating; a placebo-controlled study is needed. |
| I-9–I-10 | Major/Mod. | No blinding or power calculation; sex confounded with strain; microscopy fields analysed as independent replicates (Figs 1i, 2c, 2j; Supp 4c). | Effect sizes likely inflated. |
| I-11 | Moderate | Tumour Slc6a8 knock-down: ~82% at mRNA (the qPCR is labelled *si*), but roughly half the SLC6A8 band persists on the *sh* blot. | "Host only" is not secure; close with a validated knockout. |
| I-12–16 | Moderate/Minor | Slc6a8-null platelets are hypo-aggregant (Fig 3d); MK-uptake interaction p = 0.065 (Fig 3c); Fig 3i lung-weight CV is 3–4% vs 6–34% elsewhere; GP6 apparent size varies between blots; labels inconsistent ("Creatinine", "ADAR2A", si/sh). | Handled in the Study 1 design and the Study 0 audit. |

Everything else reproduced. Every reported statistic I re-derived (Student t-tests, Tukey and Dunnett comparisons, log-rank) matched the sheets exactly. The arithmetic is sound; the problems lie in the analysis choices, the design and the provenance of specific panels.

---

## 3. Target-by-target assessment

| Node | Causal in vivo evidence | Integrity of that evidence | Human support | Tools / tractability | Liabilities seen in our data | Verdict |
|---|---|---|---|---|---|---|
| **MK SLC6A8** | Deletion removes creatine effect (interaction 0.22, 0.11–0.47) | Endpoint clean; companion qPCR flagged (I-3) | Indirect: exposure match; MK-lag time course | Conditional knockout line in house | Knockout hypo-aggregation (Fig 3d); brain also accumulates creatine (Fig 4a), so systemic inhibition carries risk | **Primary: validate** |
| **GPVI (GP6)** | None | — | **Strongest**: collagen 2.5-fold (q = 0.02); GP6 protein 4/4; mRNA 4/4 | Blocking reagent or model must be qualified in our system | None observed | **Backup 1**: shared-control arm in Study 1 |
| α2A (ADRA2A) | None | — | Epinephrine 1.6–2.1-fold (10–11/11, q ≤ 0.02); ADRA2A mRNA 4/4 | — | Receptor acts well beyond platelets | Co-read-out within Backup 1 |
| **STAT5B** | Inhibitor only (Fig 6b); no knockout metastasis data | **Critical** (I-1); null phospho screen (I-5); blots (I-6) | Contradictory (RAB4A falls) | Conditional knockout line in house | Inhibitor suppresses the baseline MK program | **Backup 2**: conditional on Study 0 |
| P2Y12 | None | Protein increase not reproduced (I-14) | ADP response flat (q ≥ 0.58) | — | — | Deprioritise |
| COX-1 (aspirin) | Supp 2d only | **Critical** (I-1) | Arachidonic-acid trend, q ≥ 0.07 | Available | — | Active comparator only |
| CKB | In vitro only; knock-down effect partial | — | None | — | Brain CKB far above MK (Fig 4b) | Not now |
| Tumour SLC6A8 | No interaction (0.77, 0.39–1.53) | Knock-down incomplete (I-11) | — | — | — | Close cheaply with a validated knockout |

---

## 4. Proposed studies

### 4.1 Study 0: data audit (no slot; 2–4 weeks; runs alongside breeding for Study 1)

Requests:

1. Animal-level source records (IDs, dates, histology images) for Fig 6b and Supp 2d, and for Fig 3i (the primary evidence).
2. Raw aggregometry traces for Figs 2b and 3d.
3. Raw Ct files with the ΔCT sign convention and reference gene for Figs 2f, 3f, 4h–l, 6a, 6g, Supp 4e and 7d.
4. Uncropped, unsaturated blots for Figs 5e–i, 7e and Supp 8d, with the densitometry files.
5. Site-level phosphoproteomics output and the missing-value handling used.
6. Per-experiment tumour line, sex, genotype nomenclature and dosing schedule. Slc6a8 is X-linked, so males are hemizygous.

Outcome:

- If I-1 is resolved with original data, the STAT5-inhibitor and aspirin results re-enter the ranking.
- If it is not, both are retired.

### 4.2 Study 1: the in vivo slot. Confirm MK-SLC6A8 dependence; head-to-head GPVI arm

**Question**

- Primary: does MK SLC6A8 mediate creatine-promoted metastasis when tested blinded, powered, in both sexes and in two models?
- Secondary: does blocking GPVI remove the same increment?

**Population (animals)**

- Pf4-Cre;Slc6a8-floxed mice (females fl/fl, males fl/Y) and Pf4-Cre;Slc6a8 wild-type littermates (Cre-matched controls).
- Age 8–12 weeks.
- Sexes balanced within every cell (8 and 7 per cell).
- Confirm Slc6a8 protein loss in MKs and its retention in leukocytes and brain (lineage-specificity check).

**Indications (tumour models)**

- Model 1: the melanoma model used for Figs 1f and 3i.
- Model 2: a second tumour line syngeneic to the knockout line's background, preferably a spontaneous-metastasis (orthotopic, resected) model.
  - The BALB/c-derived model in the package cannot be used unless the knockout line is on BALB/c.
- Endpoint organ: lung, as in every experiment in the package.

**Exposure**

- The original oral regimen (42.5 mg/mL, 400 µL, three times a week) for a direct replication.
- Start it 14 days before tumour challenge (or the documented original schedule) and continue to endpoint.
- Verify serum creatine falls in the 150–250 µM window seen in mice and volunteers.

**Arms and comparators** (per model; n = 15 per cell)

| Arm | Genotype | Exposure | Co-treatment | Role |
|---|---|---|---|---|
| 1 | Cre control | Control (water) | Isotype/vehicle | Reference |
| 2 | Cre control | Creatine | Isotype/vehicle | Creatine effect |
| 3 | MK Slc6a8 deleted | Control | Isotype/vehicle | Genotype baseline |
| 4 | MK Slc6a8 deleted | Creatine | Isotype/vehicle | **Primary interaction (arms 1–4)** |
| 5 | Cre control | Control | GPVI blockade | GPVI baseline |
| 6 | Cre control | Creatine | GPVI blockade | **GPVI interaction (arms 1, 2, 5, 6)** |

**Randomisation and blinding**

- Computer-generated allocation, stratified by litter and sex.
- Coded cages and diets.
- Histology and image analysis done blind to group.
- Statistical analysis plan pre-registered before the first tumour challenge.

**Endpoints**

- **Primary:** lung metastatic burden (% of lung area, blinded automated histomorphometry on pre-specified sections), analysed on the log scale.
- **Key secondary:**
  - metastatic foci (negative binomial model);
  - lung weight;
  - lung retention of labelled tumour cells at 24 h (satellite cohort, Model 1, 6 per cell, reproducing the Fig 1h window).
- **Pharmacodynamic satellites** (tumour-free, 6 per cell, day 14 of exposure):
  - serum creatine;
  - MK creatine and phosphocreatine;
  - platelet surface GPVI, P2Y12 and α2A;
  - ex vivo aggregation to collagen, epinephrine, ADP and thrombin, with raw traces archived;
  - α-granule content summarised per animal;
  - platelet count and indices.
- **Safety and specificity:**
  - tail bleeding time (Slc6a8-null hypo-aggregation signal; GPVI blockade);
  - brain and skeletal-muscle creatine, which should be unchanged by MK deletion. This becomes the liability read-out for any later systemic SLC6A8 approach.

**Analysis**

- Linear mixed model on log burden: genotype (or blocker) × exposure, with sex and model as fixed effects and litter as a random effect.
- Estimand: ratio of creatine effects, with CI.
- Fixed-sequence testing, each step at α = 0.05:
  1. creatine effect in controls;
  2. SLC6A8 interaction;
  3. GPVI interaction.
- Heterogeneity across model and sex is reported.

**Sample size** (`tables/T8_power_in_vivo_slot.csv`)

- Observed within-group SD of log burden: median 0.33, upper quartile 0.45 (31 groups).
- With 15 per cell and SD 0.45, power to detect complete removal of a 2.0-fold creatine effect is:
  - 0.83 in one model;
  - 0.99 pooled across two models.
- Power to detect 75% removal, pooled: 0.88.
- If the true effect is the observed 3.2-fold, power in a single model is ≥ 0.98 for complete removal (SD up to 0.55).

**Configurations** (+10% for attrition)

| Configuration | Content | Mice |
|---|---|---|
| Minimum viable | Model 1, arms 1–4 + PD satellite | ≈ 90 |
| **Recommended** | Model 1, arms 1–6; Model 2, arms 1–4; PD satellite; 24-h retention satellite (Model 1, arms 1–4) | ≈ 230 |
| Full | Recommended + platelet-transfer sufficiency cohort (tumour-free wild-type-control, wild-type-creatine and knockout-creatine donors → wild-type recipients, 12 per arm) + Model 2 GPVI arms | ≈ 345 |

The platelet-transfer cohort replaces the compromised Supp 2d.

**Decision rules:** as in §1.

### 4.3 Study 2: Backup 1, GPVI (with α2A) as the druggable effector (next slot if promoted)

- **Design:** wild-type mice, both models. 2 exposures (control vs creatine) × 4 treatments:
  - isotype/vehicle;
  - GPVI blockade;
  - aspirin, 30 mg/kg/day (the package's regimen), as an active comparator testing generic COX-1 antiplatelet effect;
  - exploratory α2A antagonism.
- n = 15 per cell.
- **Primary endpoint:** interaction of each treatment with creatine on log burden.
- **Secondary:** target engagement (surface GPVI; loss of collagen response); bleeding time; 24-h tumour-cell retention.
- **Human bridge:** platelets from creatine-exposed volunteers (Study 4), treated ex vivo with GPVI blockade vs control, transferred into recipient mice. Blinded, and replicated per donor rather than pooled.
- **Promote GPVI** if:
  - it removes ≥ 60% of the log creatine effect, with the upper CI of the interaction below 1;
  - bleeding is no worse than aspirin;
  - the human-platelet bioassay agrees.
- If aspirin performs equally well, the mechanism is generic platelet activation. That is a cheaper intervention but lower novelty, and the committee should weigh it accordingly.

### 4.4 Study 3: Backup 2, STAT5B (conditional on Study 0 clearing I-1)

- **Design:** Pf4-iCre;Stat5b-floxed mice vs Cre-matched littermates × creatine vs control, 15 per cell.
  - It includes the knockout-vehicle arm missing from the current data.
  - Same endpoints as Study 1.
- **Mechanism package:**
  - site-specific STAT5B phosphorylation in primary MKs by a targeted mass-spectrometry method (n ≥ 5 per group, FDR-controlled);
  - transcriptome-wide response with FDR;
  - ChIP with IgG and negative-region controls.
- **Promote STAT5B** only if all of the following hold:
  - the interaction is ≤ 0.5 (upper CI < 1);
  - phosphorylation at the proposed site is confirmed;
  - human platelets/MKs show the same program. RAB4A would have to rise, not fall.

### 4.5 Study 4: human pharmacodynamic study (clinical pharmacology; not the slot)

**Population**

- Healthy adults aged 18–60, both sexes, at least two ancestries.
- Exclusions: antiplatelet or NSAID use (medication diary; arachidonic-acid response as a compliance check, given volunteer 5), bleeding or thrombotic disorders, renal impairment, history of cancer.

**Design**

- Randomised, double-blind, placebo-controlled, three parallel arms:
  - placebo (matched powder);
  - creatine 5 g/day;
  - creatine 20 g/day for 7 days, then 5 g/day.
- 28 days on treatment, then 28 days of washout to test reversibility.

**Endpoints**

- **Primary:** change in epinephrine-induced maximal aggregation from baseline to day 14 vs placebo. Analyse absolute aggregation values by ANCOVA on the log scale; the original study reported only fold-changes.
- **Key secondary:** collagen-induced aggregation; platelet surface GPVI.
- **Specificity controls:** ADP and arachidonic-acid responses.
- **PK and other secondary:**
  - serum creatine;
  - platelet transcript panel (GP6, ADRA2A, P2RY12, RAB4A, …) with FDR control;
  - washout reversal.
- **Exploratory:** blinded mouse bioassay of each participant's platelets (Fig 7g design), replicated per donor.

**Sample size**

- Observed day-14 SD of log2 change: 0.64 (epinephrine max).
- 40 per arm gives ≈ 80% power per creatine-vs-placebo comparison to detect 60% of the observed effect.
- About 132 enrolled, allowing for drop-out.

**Patients**

- Do not randomise people with cancer to creatine while harm is hypothesised.
- Patient evidence should come from an observational cohort of supplement users (e.g. resected melanoma), measuring creatine exposure and platelet epinephrine/collagen reactivity.

### 4.6 Parallel low-cost work (no slot)

1. **Human relevance of the SLC6A8 gate.** Human CD34⁺-derived MKs with SLC6A8 knocked down or knocked out, ± exposure-matched creatine (0.2 mM, the lowest dose active in Fig 2i). Read out GP6/ADRA2A/P2RY12 with multiple reference genes.
2. **Tumour-cell SLC6A8.** Validated knockouts in both tumour lines, with protein-null confirmation, to close I-11.
3. **Phospho confirmation.** Targeted confirmation of the top phospho hits in MKs ± creatine (n ≥ 5 per group).

### 4.7 Indications and populations for eventual development

- **Biology-defined indication.** Prevention of haematogenous lung metastasis. Every read-out in the package is lung colonisation, and the effect appears 6–24 h after tumour-cell arrest (Fig 1h).
  - Melanoma is the only histology documented (Fig 1f), so it is the first indication hypothesis: a perioperative/adjuvant window in high-risk resected disease.
  - The second model's histology must be documented before we generalise.
- **Exposure-defined population.** People with cancer who take creatine supplements.
  - Candidate enrichment markers: serum creatine, plus platelet epinephrine/collagen reactivity and GPVI density.
- **Two possible outputs**, depending on Studies 1, 2 and 4:
  - a risk-management recommendation on creatine supplementation in high-risk patients, if the human PD study is positive;
  - a platelet-directed intervention (GPVI) with aspirin as the comparator, if Studies 1 and 2 support it.
- Systemic SLC6A8 or CKB inhibition is not a development path on current evidence. Brain creatine and CKB data (Figs 4a–c) flag an on-target liability.

---

## 5. What would change the ranking

| Observation | Effect on the ranking |
|---|---|
| Study 1: SLC6A8 interaction ≤ 0.5, upper CI < 1, consistent in both models | SLC6A8 stays primary (axis validated); move to intervention choice |
| Study 1: platelets from creatine-fed control donors (but not knockout donors) transfer the effect | Platelet-effector targets (GPVI, α2A) rise; the MK-reprogramming model is confirmed |
| Study 1: GPVI blockade removes ≥ 60% of the creatine effect without excess bleeding | **GPVI becomes the lead druggable target** (Study 2 next) |
| Study 1: SLC6A8 interaction 0.5–0.8, or CI includes 1 | Other uptake routes or the tumour contribute. Run the validated tumour-SLC6A8 knockout; GPVI leads if positive. |
| Study 0 clears I-1, **and** Stat5b MK knockout removes the creatine effect with site-specific phosphorylation confirmed | STAT5B rises to backup 1. Its pleiotropy still argues against it as a drug target. |
| Study 0 does not clear I-1 | STAT5-inhibitor and aspirin results retired; STAT5B drops out |
| Study 4: placebo-controlled increase in epinephrine/collagen reactivity at 5 g/day | Human relevance established at ordinary doses; raises priority of the whole axis and of the patient cohort |
| Study 4: no change vs placebo, or only at 20 g/day | Human relevance limited to high-dose loading; programme value falls |
| Creatine effect fails blinded replication | Stop the axis |

---

## 6. Key risks and mitigations

- **Colony size.**
  - The recommended configuration needs about 60 genotyped littermates per model, balanced by sex and, because Slc6a8 is X-linked, with a specific breeding scheme. Breeding must start now.
  - If numbers fall short, run the minimum-viable configuration; the decision rules still apply.
- **Cre specificity.** Verify recombination is restricted to the MK lineage in our colony (Study 1 population checks).
- **Knockout is not neutral** (baseline hypo-aggregation). Mitigations: bleeding read-out, pharmacodynamic satellites and the liposomal-bypass logic (Supp 4e). Optionally add a knockout + liposomal-creatine rescue arm if capacity allows.
- **GPVI reagent.** It must be qualified in our system (target engagement, no platelet depletion beyond the intended effect) before the arm starts. If it is not ready, run arms 1–4 and move the GPVI arm to Study 2.
- **Assay quality.**
  - qPCR only with multiple validated reference genes and archived raw Ct files.
  - Blots only unsaturated, on the same membrane, with site-specific antibodies.
  - Aggregometry with raw traces retained.
  - Unit of analysis always the animal or volunteer, never the microscopy field.

---

## Appendix A: how the numbers were derived

1. **Extraction.** Every numeric cell was read from the workbook (cached values and formulas); panels were mapped to tidy data (`analysis/extract.py`). Before any re-analysis, every reported t-test, Tukey/Dunnett comparison and log-rank statistic checked was reproduced from the raw values.
2. **Effect sizes.**
   - Continuous endpoints: ratio of geometric means with Welch CIs on the log scale, plus Hedges g. Student (as reported), Welch and exact Mann–Whitney p-values are in T1. With n = 3 per group the Mann–Whitney p cannot fall below 0.10.
   - 2×2 designs: ordinary least squares on log values; interaction = ratio of creatine effects, with pooled-variance CI (T2).
   - Survival: log-rank and Cox proportional hazards.
3. **Synthesis.** DerSimonian–Laird random-effects pooling of log GMRs across the 10 vehicle-vs-creatine experiments; Egger regression (T3).
4. **Volunteers.**
   - Serum creatine: paired log ratios.
   - Platelet function: one-sample tests on log2 fold-change (t-test and Wilcoxon signed-rank) at each day, with Benjamini–Hochberg FDR over 36 tests (T4).
   - Transcripts and protein: per-volunteer log2 fold-change (mean of technical triplicates); repeated-measures ANOVA (T5).
5. **Mouse qPCR.** Welch tests on ΔCT per contrast, using the sheet's own sign convention (T6). Provenance checks:
   - whether each value is exactly representable as an instrument float32 number;
   - whether differences are float32;
   - cross-experiment comparison of control-group ΔCT.
6. **Phosphoproteomics.** P-value histogram; Storey π₀ (0.67 including artefacts, 0.95 excluding); BH FDR; detection of p-values shared by many peptides (missing-value artefacts).
7. **Forensic checks.**
   - Cross-panel search for shared continuous values and shared runs of ≥ 3 values.
   - Monte-Carlo probability of the Fig 2b triplicate structure (integer readings, SD 1–5).
   - Box densitometry with local background on the displayed blot images (Supp 8d, Supp 2a). These are JPEG figure images, so the estimates are approximate; they are used only to flag disagreements, not as replacement data.
8. **Power.** Non-central t calculations for the 2×2 interaction and for two-arm comparisons, using SDs observed in this package (T8).

## Appendix B: files delivered

- `CRE-MK-01_validation_proposal.md` / `.pdf`: this document.
- `figures/`: Fig1 (forest and interaction), Fig2 (human read-outs), Fig3 (integrity flags).
- `tables/`:
  - T1: all two-group panels recomputed;
  - T2: factorial interactions;
  - T3: meta-analysis;
  - T4: human platelet function;
  - T5: human CD41⁺ qPCR;
  - T6: mouse qPCR contrasts;
  - T7: integrity log;
  - T8: power.
- `analysis/`: Python scripts that regenerate every number and figure from the source workbook.
