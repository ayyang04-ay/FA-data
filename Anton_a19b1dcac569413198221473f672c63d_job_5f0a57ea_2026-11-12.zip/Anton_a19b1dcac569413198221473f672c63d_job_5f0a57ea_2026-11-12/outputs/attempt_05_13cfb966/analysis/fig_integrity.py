import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
import pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig, axes = plt.subplots(2, 2, figsize=(13, 9.5))
# A duplication
ax = axes[0, 0]
b6 = D['Fig. 6b']['Metastatic burden (%)']['groups']; b2 = D['Supp 2d']['Metastatic burden (%)']['groups']
f6 = D['Fig. 6b']['Metastatic foci']['groups']; f2 = D['Supp 2d']['Metastatic foci']['groups']
rows = []
for lab6, lab2, col in [('Vehicle', 'Vehicle donor PLT', '#1f77b4'), ('Creatine', 'Creatine donor PLT', '#d62728')]:
    for i, (x, f) in enumerate(zip(b6[lab6], f6[lab6])):
        ax.scatter(x, f, s=60, facecolor='none', edgecolor=col, lw=1.5, label=f'Fig 6b {lab6}' if i == 0 else None)
    for i, (x, f) in enumerate(zip(b2[lab2], f2[lab2])):
        ax.scatter(x, f, s=18, color=col, marker='x', label=f'Supp 2d {lab2}' if i == 0 else None)
for x, f in zip(b6['Vehicle'] + b6['Creatine'], f6['Vehicle'] + f6['Creatine']):
    if x in b2['Vehicle donor PLT'] + b2['Creatine donor PLT']:
        ax.annotate(f'{x:.6g}%, {int(f)} foci', (x, f), textcoords='offset points', xytext=(6, -10), fontsize=7)
ax.set_xlabel('Metastatic burden (%)'); ax.set_ylabel('Metastatic foci')
ax.set_title('A. Same 3 vehicle + 3 creatine animals (burden AND foci, 7 sig. digits)\nappear in two different experiments: Fig 6b (STAT5i) and Supp 2d (platelet transfer)', fontsize=9)
ax.legend(fontsize=7, loc='lower right')
# B qPCR baseline dCT
ax = axes[0, 1]
Q = D['qPCR']
sheets = ['Fig. 2f', 'Fig. 3f', 'Fig. 4h', 'Fig. 4j', 'Fig. 4l', 'Fig. 6a', 'Fig. 6g', 'Supp 4e']
genes = ['Itga2b', 'P2ry12', 'Gp6', 'Gpiba', 'F2r', 'Adra2a', 'Fcgr2a', 'Runx1', 'Rab4a', 'Rab27b', 'Pitpnb']
for g in genes:
    vals = [np.mean([float(x) for x in Q[s][g][list(Q[s][g].keys())[0]]]) for s in sheets]
    ax.plot(range(len(sheets)), vals, '-o', ms=3, lw=1, label=g)
ax.axhline(0, color='k', lw=0.6)
ax.set_xticks(range(len(sheets))); ax.set_xticklabels(sheets, rotation=30, fontsize=8)
ax.set_ylabel('control-group \u0394CT as recorded (same cell type: mouse BM MKs)')
ax.set_title('B. Baseline \u0394CT of the same genes varies 7\u201319 cycles between experiments;\nsign flips in Fig 3f \u2192 fold-change direction not verifiable without raw Ct', fontsize=9)
ax.legend(fontsize=6.5, ncol=4, loc='lower left')
# C phospho p-value histogram
ax = axes[1, 0]
df = pd.read_excel('/tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx', sheet_name=0); df.columns = ['gene', 'p', 'q', 'lfc']
art = np.isclose(df.p, 0.42265, atol=1e-5)
ax.hist([df.p[~art], df.p[art]], bins=40, stacked=True, color=['#7f7f7f', '#ff7f0e'], label=['all other peptides', 'p = 0.42265 exactly (1,702 peptides, missing-value artefact)'])
ax.axhline(len(df)/40, color='k', ls='--', lw=0.8, label='uniform expectation (no true effects)')
st = df[df.gene == 'Stat5b'].p.min()
ax.annotate(f'Stat5b phosphopeptide\np={st:.4f}, rank 17/5,812\nBH q=0.25 (not significant)', xy=(st, 160), xytext=(0.55, 650), arrowprops=dict(arrowstyle='->'), fontsize=8)
ax.set_xlabel('P value (phosphopeptide, creatine vs vehicle MKs, n=3 vs 3)'); ax.set_ylabel('count')
ax.set_title('C. Phosphoproteomics: no enrichment of small P values; no peptide passes FDR\n(209 "differential" by study criteria vs ~216 expected by chance)', fontsize=9)
ax.legend(fontsize=7)
# D Fig 2b structure
ax = axes[1, 1]
cols = {'Vehicle': '#1f77b4', 'Creatine': '#d62728'}
xt = []
for i, (name, blk) in enumerate(D['Fig. 2b'].items()):
    for j, (grp, vals) in enumerate(blk['groups'].items()):
        x0 = i*3 + j
        ax.scatter([x0]*3, vals, color=cols[grp], s=25)
        ax.plot([x0-0.25, x0+0.25], [np.mean(vals)]*2, color='k', lw=1)
        ax.text(x0, max(vals)+2, f'{[int(v) for v in vals]}', ha='center', fontsize=7)
    xt.append((i*3+0.5, name.replace('Aggregation ', '').replace(' (%)', '')))
ax.set_xticks([x for x, _ in xt]); ax.set_xticklabels([l for _, l in xt])
ax.set_ylabel('Platelet aggregation (%)')
ax.set_title('D. Fig 2b: in all 6 triplicates the 3rd value is exactly the mean of the other two\n(P \u2248 1e-5 to 1e-9 under independent integer readings, simulated)', fontsize=9)
plt.tight_layout()
plt.savefig('/tmp/outputs/figures/Fig3_data_integrity_flags.png', dpi=200)
