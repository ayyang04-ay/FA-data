import json, numpy as np
D = json.load(open('/tmp/work/tidy.json'))
Q = D['qPCR']
sheets = ['Fig. 2f','Fig. 3f','Fig. 4h','Fig. 4j','Fig. 4l','Fig. 6a','Fig. 6g','Supp 4e']
genes = ['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
print('Mean control-group dCT (as recorded in sheet) per gene x experiment (primary mouse MKs):')
print(f"{'gene':8s} " + ' '.join(f'{s:>8s}' for s in sheets) + '   range')
for g in genes:
    vals = []
    for s in sheets:
        grp = list(Q[s][g].keys())[0]
        vals.append(np.mean([float(x) for x in Q[s][g][grp]]))
    print(f'{g:8s} ' + ' '.join(f'{v:8.2f}' for v in vals) + f'   {max(vals)-min(vals):5.1f} cycles')
