import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
from statsmodels.stats.multitest import multipletests
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker
H = D['Fig. 7c']['fold_change_wide']
order = ['collagen max','collagen avg','collagen adhesion','EPI max','EPI avg','EPI adhesion','AA max','AA avg','AA adhesion','ADP max','ADP avg','ADP adhesion']
gm = np.zeros((12,3)); pw = np.zeros((12,3)); up = np.zeros((12,3), int)
for i,k in enumerate(order):
    M = np.array(H[k], float)
    for j in range(3):
        x = M[:, j+1]
        gm[i,j] = np.log2(x[x>0]).mean()
        pw[i,j] = stats.wilcoxon(x-1).pvalue
        up[i,j] = (x>1).sum()
q = multipletests(pw.ravel(), method='fdr_bh')[1].reshape(pw.shape)
fig = plt.figure(figsize=(13, 6))
ax = fig.add_axes([0.17, 0.12, 0.30, 0.78])
im = ax.imshow(gm, cmap='RdBu_r', vmin=-1.5, vmax=1.5, aspect='auto')
for i in range(12):
    for j in range(3):
        s = f'x{2**gm[i,j]:.2f}\n{up[i,j]}/11 up\nq={q[i,j]:.2f}'
        ax.text(j, i, s, ha='center', va='center', fontsize=6.3, color='k', weight='bold' if q[i,j] < 0.05 else 'normal')
ax.set_xticks(range(3)); ax.set_xticklabels(['day 3', 'day 7', 'day 14'])
labels = [o.replace('EPI','Epinephrine (\u03b12A)').replace('collagen','Collagen (GPVI)').replace('ADP','ADP (P2Y12)').replace('AA','Arachidonic acid (COX-1)') for o in order]
ax.set_yticks(range(12)); ax.set_yticklabels(labels, fontsize=7.5)
cb = plt.colorbar(im, ax=ax, fraction=0.05, pad=0.02); cb.set_label('log2 fold-change vs day 0 (geometric mean)', fontsize=8)
ax.set_title('A. Volunteer platelet function (Fig 7c), n=11, re-analysed\npaired Wilcoxon vs day 0, BH-FDR over 36 tests (bold: q<0.05)', fontsize=9)
# panel B: protein
ax2 = fig.add_axes([0.60, 0.56, 0.37, 0.34])
for k, col in [('GP6/ACTB', '#2ca02c'), ('P2RY12/ACTB', '#9467bd')]:
    M = np.array(D['Fig. 7e'][k], float)
    for r in M:
        ax2.plot([0,3,7,14], r/r[0], '-o', color=col, alpha=0.6, ms=3, lw=1)
    ax2.plot([], [], '-o', color=col, label=k + ' (reported, per volunteer)')
ax2.axhline(1, color='grey', ls='--', lw=0.8); ax2.set_yscale('log'); ax2.set_yticks([0.5,1,2,4]); ax2.set_yticklabels(['0.5','1','2','4']); ax2.yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
ax2.set_xticks([0,3,7,14]); ax2.set_xlabel('day of creatine 20 g/day'); ax2.set_ylabel('fold vs day 0')
ax2.legend(fontsize=7, loc='upper left'); ax2.set_title('B. Platelet protein (Fig 7e), n=4 volunteers', fontsize=9)
# panel C: day-14 reported vs re-quantified from Supp Fig 8d image
mine = {'GP6': [1.76, 1.61, 1.84, 1.35], 'P2RY12': [1.19, 1.24, 0.97, 1.10]}
rep = {'GP6': [2.17, 2.10, 4.98, 2.06], 'P2RY12': [1.33, 1.69, 2.73, 1.44]}
ax3 = fig.add_axes([0.60, 0.12, 0.37, 0.30])
xs = np.arange(2)
for i, p in enumerate(['GP6', 'P2RY12']):
    ax3.scatter(np.full(4, i-0.12), rep[p], color='k', s=18, label='reported (Fig 7e rows)' if i == 0 else None)
    ax3.scatter(np.full(4, i+0.12), mine[p], color='#d62728', marker='^', s=22, label='re-quantified from Supp Fig 8d image (approx.)' if i == 0 else None)
ax3.axhline(1, color='grey', ls='--', lw=0.8); ax3.set_yscale('log'); ax3.set_yticks([0.8,1,2,4]); ax3.set_yticklabels(['0.8','1','2','4']); ax3.yaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
ax3.set_xticks(xs); ax3.set_xticklabels(['GP6/ACTB day 14', 'P2RY12/ACTB day 14']); ax3.set_xlim(-0.6, 1.6)
ax3.set_ylabel('fold vs day 0'); ax3.legend(fontsize=7, loc='upper right')
ax3.set_title('C. Day-14 fold: reported vs independent densitometry of displayed blots', fontsize=9)
plt.savefig('/tmp/outputs/figures/Fig2_human_platelet_readouts.png', dpi=200)
