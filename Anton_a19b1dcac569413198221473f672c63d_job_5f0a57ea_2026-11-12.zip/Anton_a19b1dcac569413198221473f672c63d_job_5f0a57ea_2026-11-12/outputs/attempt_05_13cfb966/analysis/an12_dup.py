import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
b6 = D['Fig. 6b']['Metastatic burden (%)']['groups']; f6 = D['Fig. 6b']['Metastatic foci']['groups']
b2 = D['Supp 2d']['Metastatic burden (%)']['groups']; f2 = D['Supp 2d']['Metastatic foci']['groups']
print('Fig 6b Vehicle burden   :', b6['Vehicle']); print('Supp 2d Veh-donor burden:', b2['Vehicle donor PLT'])
print('Fig 6b Creatine burden  :', b6['Creatine']); print('Supp 2d Cre-donor burden:', b2['Creatine donor PLT'])
print('Fig 6b Vehicle foci     :', f6['Vehicle']); print('Supp 2d Veh-donor foci  :', f2['Vehicle donor PLT'])
print('Fig 6b Creatine foci    :', f6['Creatine']); print('Supp 2d Cre-donor foci  :', f2['Creatine donor PLT'])
# identical pairs
for lab, a, b in [('veh burden', b6['Vehicle'], b2['Vehicle donor PLT']), ('cre burden', b6['Creatine'], b2['Creatine donor PLT']),
                  ('veh foci', f6['Vehicle'], f2['Vehicle donor PLT']), ('cre foci', f6['Creatine'], f2['Creatine donor PLT'])]:
    print(lab, 'shared values:', sorted(set(a) & set(b)))
# sensitivity: drop duplicated animals
def drop(v, dup): return [x for x in v if x not in dup]
dup_vb = set(b6['Vehicle']) & set(b2['Vehicle donor PLT']); dup_cb = set(b6['Creatine']) & set(b2['Creatine donor PLT'])
print('\nSensitivity (duplicated animals removed from BOTH panels):')
g6 = {'Vehicle': drop(b6['Vehicle'], dup_vb), 'Creatine': drop(b6['Creatine'], dup_cb), 'Vehicle+STAT5i': b6['Vehicle+STAT5i'], 'Creatine+STAT5i': b6['Creatine+STAT5i']}
print('  Fig 6b remaining n:', {k: len(v) for k, v in g6.items()})
r = twoway_log(g6, 'Vehicle', 'Creatine', 'Vehicle+STAT5i', 'Creatine+STAT5i')
print(f'  Fig 6b creatine effect without inhibitor x{r["effect1"]:.2f} [{r["effect1_ci"][0]:.2f},{r["effect1_ci"][1]:.2f}]; with inhibitor x{r["effect2"]:.2f}; interaction {r["interaction"]:.2f} [{r["inter_ci"][0]:.2f},{r["inter_ci"][1]:.2f}] p={fmt_p(r["p_inter"])}')
g2 = {'V': drop(b2['Vehicle donor PLT'], dup_vb), 'C': drop(b2['Creatine donor PLT'], dup_cb), 'A': b2['Creatine+aspirin donor PLT']}
print('  Supp 2d remaining n:', {k: len(v) for k, v in g2.items()})
for a, b in [('V', 'C'), ('C', 'A'), ('V', 'A')]:
    gm, lo, hi, p, *_ = ratio_ci(g2[a], g2[b])
    print(f'  Supp 2d {b}/{a}: GMR {gm:.2f} [{lo:.2f},{hi:.2f}] p={fmt_p(p)}')
