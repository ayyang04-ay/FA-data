import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
import pandas as pd
import statsmodels.formula.api as smf
import statsmodels.api as sm
for sheet in ['Fig. 5e', 'Fig. 5f']:
    g = D[sheet]['p-FLAG/FLAG']['groups']
    rows = []
    for k, v in g.items():
        trt, gt = k.split('-')
        for i, x in enumerate(v): rows.append((trt, gt, i, x))
    df = pd.DataFrame(rows, columns=['trt','gt','rep','y'])
    print(f'\n=== {sheet} pan-phospho/FLAG (n=3 blots per cell) ===')
    print(df.groupby(['gt','trt']).y.agg(['mean','std']).round(3).unstack())
    m = smf.ols('np.log(y) ~ C(gt, Treatment("WT")) * C(trt, Treatment("Vehicle"))', data=df).fit()
    print(sm.stats.anova_lm(m, typ=2).round(4))
    # specific contrasts: creatine effect within each genotype (log ratio)
    for gt in ['WT','S127A','3A','S127D']:
        a = np.array(g[f'Vehicle-{gt}']); b = np.array(g[f'Creatine-{gt}'])
        gm, lo, hi, p, *_ = ratio_ci(a, b)
        print(f'   creatine/vehicle within {gt:6s}: {gm:.2f} [{lo:.2f},{hi:.2f}] p={fmt_p(p)}')
    # interaction WT vs S127A
    r = twoway_log(g, 'Vehicle-WT','Creatine-WT','Vehicle-S127A','Creatine-S127A')
    print(f'   interaction (S127A vs WT creatine response): ratio {r["interaction"]:.2f} [{r["inter_ci"][0]:.2f},{r["inter_ci"][1]:.2f}] p={fmt_p(r["p_inter"])} (pooled over 4 cells only)')
    print('   NB: separate membranes for vehicle and creatine in replicate 2; pan-phospho antibody is not site-specific; S127D (Asp) cannot be detected as phospho-Ser')

print('\n=== ChIP (% input), Fig 5j (P2ry12, Gp6) + Supp 6i (Rab4a); n=3 per group ===')
C = D['ChIP (Fig 5j + Supp 6i)']
for k, v in C.items():
    a, b = np.array(v['Vehicle']), np.array(v['Creatine'])
    gm, lo, hi, p, *_ = ratio_ci(a, b)
    print(f'   {k:14s} vehicle {a.mean():6.2f}  creatine {b.mean():6.2f}  ratio {gm:5.2f} [{lo:5.2f},{hi:6.2f}] Welch(log) p={fmt_p(p)}  values V={np.round(a,2).tolist()} C={np.round(b,2).tolist()}')
