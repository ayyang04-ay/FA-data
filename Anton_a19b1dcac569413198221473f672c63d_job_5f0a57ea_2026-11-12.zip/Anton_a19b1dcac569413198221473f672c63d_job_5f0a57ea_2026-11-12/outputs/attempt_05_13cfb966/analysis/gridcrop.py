from PIL import Image, ImageDraw
import sys
import os
im = Image.open(os.environ.get('IMG','/tmp/work/xlsx/src/xl/media/image26.jpeg')).convert('RGB')
def crop(x0,y0,x1,y1,scale,out):
    c = im.crop((x0,y0,x1,y1)).resize(((x1-x0)*scale,(y1-y0)*scale), Image.NEAREST)
    d = ImageDraw.Draw(c)
    for x in range(x0 - x0%10, x1, 10):
        X=(x-x0)*scale
        d.line([(X,0),(X,6 if x%50 else 14)], fill=(255,0,0), width=1)
        if x%50==0: d.text((X+2,14), str(x), fill=(255,0,0))
    for y in range(y0 - y0%10, y1, 10):
        Y=(y-y0)*scale
        d.line([(0,Y),(6 if y%50 else 14,Y)], fill=(0,0,255), width=1)
        if y%50==0: d.text((16,Y+2), str(y), fill=(0,0,255))
    c.save(out)
args = list(map(int, sys.argv[1:6])); crop(*args, sys.argv[6])
