import json, numpy as np
D = json.load(open('/tmp/work/tidy.json'))
H = D['qPCR']['Fig. 7d']
mism = []
for gene, vols in H.items():
    for v in ['V1','V2','V3','V4']:
        d0 = np.array([float(x) for x in vols[v]['0d']])
        for t in ['3d','7d','14d']:
            dt = np.array([float(x) for x in vols[v][t]])
            s = float(vols[v]['sheet_norm'][['0d','3d','7d','14d'].index(t)])
            m1 = 2**(dt.mean()-d0.mean())
            m2 = np.mean(2**(dt - d0.mean()))
            m3 = np.mean(2**dt)/np.mean(2**d0)
            best = min([(abs(np.log2(s/m)),name,m) for name,m in [('2^meandiff',m1),('mean(2^x)/..',m2),('ratio of means',m3)]])
            mism.append((gene,v,t,s,m1,m2,m3,best))
# which method matches most often
from collections import Counter
print(Counter(b[-1][1] for b in mism))
print('Cells where the best method deviates by >25% from sheet value:')
for g,v,t,s,m1,m2,m3,best in mism:
    if best[0] > np.log2(1.25):
        print(f'  {g:7s} {v} {t:>3s}: sheet={s:.2f}  recomputed: 2^meandiff={m1:.2f} mean(2^x)={m2:.2f} ratio-of-means={m3:.2f}')
