import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
studies = [
 ('Fig. 1b', 'Fig. 1b', 'Vehicle', 'Creatine'),
 ('Fig. 1k', 'Fig. 1k', 'Vehicle', 'Creatine'),
 ('Fig. 1f (sh-scr tumour)', 'Fig. 1f', 'shScr-Vehicle', 'shScr-Creatine'),
 ('Fig. 3i (Pf4-Cre;Slc6a8+/+)', 'Fig. 3i', 'WT-Vehicle', 'WT-Creatine'),
 ('Fig. 6b (no inhibitor)*', 'Fig. 6b', 'Vehicle', 'Creatine'),
 ('Supp 1e', 'Supplementary Fig  1e', 'Vehicle', 'Creatine'),
 ('Supp 1f', 'Supplementary Fig  1f', 'Vehicle', 'Creatine'),
 ('Supp 1g', 'Supplementary Fig  1g', 'Vehicle', 'Creatine'),
 ('Supp 1i (5% diet)', 'Supplementary Fig  1i', 'Control diet', 'Creatine diet'),
 ('Supp 1k', 'Supplementary Fig  1k', 'Vehicle', 'Creatine'),
]
def dl(y, v):
    w = 1/v; yf = (w*y).sum()/w.sum(); Q = (w*(y-yf)**2).sum(); k=len(y)
    C = w.sum() - (w**2).sum()/w.sum(); tau2 = max(0,(Q-(k-1))/C)
    ws = 1/(v+tau2); yr = (ws*y).sum()/ws.sum(); se = (1/ws.sum())**0.5
    I2 = max(0,(Q-(k-1))/Q) if Q>0 else 0
    return yr, se, tau2, Q, I2, yf, (1/w.sum())**0.5
for endpoint in ['Metastatic burden (%)', 'Metastatic foci', 'Lung weight (g)']:
    print('\n=== Endpoint:', endpoint)
    ys, vs, labs, ns, sdlog = [], [], [], [], []
    for lab, sheet, a, b in studies:
        if endpoint not in D[sheet]: continue
        g = D[sheet][endpoint]['groups']
        gm, lo, hi, p, diff, se, df = ratio_ci(g[a], g[b])
        la, lb = np.log(g[a]), np.log(g[b])
        sp = np.sqrt(((len(la)-1)*la.var(ddof=1)+(len(lb)-1)*lb.var(ddof=1))/(len(la)+len(lb)-2))
        ys.append(diff); vs.append(se**2); labs.append(lab); ns.append((len(g[a]),len(g[b]))); sdlog.append(sp)
        print(f'  {lab:30s} n={len(g[a])}/{len(g[b])}  GMR={gm:5.2f} [{lo:5.2f},{hi:5.2f}]  p={fmt_p(p)}  pooled SD(log)={sp:.3f}  vehicle CV={np.std(g[a],ddof=1)/np.mean(g[a]):.2f}')
    ys, vs = np.array(ys), np.array(vs)
    yr, se, tau2, Q, I2, yf, sef = dl(ys, vs)
    print(f'  Random-effects pooled GMR = {np.exp(yr):.2f} [{np.exp(yr-1.96*se):.2f},{np.exp(yr+1.96*se):.2f}], tau^2={tau2:.3f}, Q={Q:.2f} (df={len(ys)-1}), I^2={100*I2:.0f}%; fixed GMR={np.exp(yf):.2f}')
    # leave-out duplicated Fig 6b
    m = np.array(['6b' not in l for l in labs])
    yr2, se2, *_ = dl(ys[m], vs[m])
    print(f'  Excluding Fig 6b (duplication): pooled GMR = {np.exp(yr2):.2f} [{np.exp(yr2-1.96*se2):.2f},{np.exp(yr2+1.96*se2):.2f}]')
    # Egger test
    import statsmodels.api as sm
    prec = 1/np.sqrt(vs); z = ys/np.sqrt(vs)
    X = sm.add_constant(prec); res = sm.OLS(z, X).fit()
    print(f'  Egger intercept = {res.params[0]:.2f} (p={res.pvalues[0]:.3f})  [small-study asymmetry test; low power with k={len(ys)}]')
    print(f'  median pooled SD(log) across studies = {np.median(sdlog):.3f}; range {min(sdlog):.3f}-{max(sdlog):.3f}')
    # excess significance: expected power of each study to detect pooled effect (two-sided 0.05, Welch approx using study SE)
    from scipy import stats as st
    pw = []
    for y, v, (na, nb) in zip(ys, vs, ns):
        df = na+nb-2; ncp = yr/np.sqrt(v); tc = st.t.ppf(0.975, df)
        pw.append(st.nct.sf(tc, df, ncp) + st.nct.cdf(-tc, df, ncp))
    obs = sum(1 for y, v in zip(ys, vs) if abs(y/np.sqrt(v)) > 2)
    print(f'  expected # significant (given pooled effect) = {sum(pw):.1f} of {len(pw)}; observed ~{obs}')
