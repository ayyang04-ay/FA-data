import json, math
import numpy as np
from scipy import stats

D = json.load(open('/tmp/work/tidy.json'))


def hedges_g(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    na, nb = len(a), len(b)
    sp = math.sqrt(((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2))
    d = (b.mean() - a.mean()) / sp if sp > 0 else float('inf')
    J = 1 - 3 / (4 * (na + nb) - 9)
    return d * J


def ratio_ci(a, b, alpha=0.05):
    """ratio of geometric means b/a with Welch CI on log scale"""
    la, lb = np.log(np.asarray(a, float)), np.log(np.asarray(b, float))
    diff = lb.mean() - la.mean()
    va, vb = la.var(ddof=1) / len(la), lb.var(ddof=1) / len(lb)
    se = math.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(la) - 1) + vb ** 2 / (len(lb) - 1)) if se > 0 else 1
    t = stats.t.ppf(1 - alpha / 2, df)
    p = 2 * stats.t.sf(abs(diff / se), df) if se > 0 else 0
    return math.exp(diff), math.exp(diff - t * se), math.exp(diff + t * se), p, diff, se, df


def mean_ratio_ci(a, b, alpha=0.05):
    """ratio of arithmetic means b/a with delta-method (Fieller-like) CI"""
    a, b = np.asarray(a, float), np.asarray(b, float)
    ma, mb = a.mean(), b.mean()
    r = mb / ma
    se_log = math.sqrt(a.var(ddof=1) / len(a) / ma ** 2 + b.var(ddof=1) / len(b) / mb ** 2)
    z = stats.norm.ppf(1 - alpha / 2)
    return r, r * math.exp(-z * se_log), r * math.exp(z * se_log)


def two_group_tests(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    st = stats.ttest_ind(b, a, equal_var=True)
    we = stats.ttest_ind(b, a, equal_var=False)
    try:
        mw = stats.mannwhitneyu(b, a, alternative='two-sided', method='exact')
    except Exception:
        mw = stats.mannwhitneyu(b, a, alternative='two-sided')
    return dict(n=(len(a), len(b)), mean=(a.mean(), b.mean()), sd=(a.std(ddof=1), b.std(ddof=1)),
                student_t=st.statistic, student_p=st.pvalue, welch_p=we.pvalue, mw_p=mw.pvalue,
                g=hedges_g(a, b))


def fmt_p(p):
    if p is None or (isinstance(p, float) and math.isnan(p)):
        return 'NA'
    if p < 1e-4:
        return f'{p:.1e}'
    if p < 0.001:
        return f'{p:.4f}'
    return f'{p:.3f}'


def twoway_log(groups, g1a, g1b, g2a, g2b):
    """2x2 on log scale: effect of treatment in background 1 (g1a->g1b) vs background 2 (g2a->g2b).
    Returns ratio-of-ratios (interaction), CI and p using pooled residual variance (OLS)."""
    arrs = [np.log(np.asarray(groups[k], float)) for k in (g1a, g1b, g2a, g2b)]
    ns = [len(x) for x in arrs]
    means = [x.mean() for x in arrs]
    ss = sum(((x - x.mean()) ** 2).sum() for x in arrs)
    df = sum(ns) - 4
    s2 = ss / df
    eff1 = means[1] - means[0]
    eff2 = means[3] - means[2]
    inter = eff2 - eff1
    se_i = math.sqrt(s2 * sum(1 / n for n in ns))
    t = inter / se_i
    p = 2 * stats.t.sf(abs(t), df)
    tc = stats.t.ppf(0.975, df)
    se1 = math.sqrt(s2 * (1 / ns[0] + 1 / ns[1]))
    se2 = math.sqrt(s2 * (1 / ns[2] + 1 / ns[3]))
    out = dict(effect1=math.exp(eff1), effect1_ci=(math.exp(eff1 - tc * se1), math.exp(eff1 + tc * se1)), p1=2 * stats.t.sf(abs(eff1 / se1), df),
               effect2=math.exp(eff2), effect2_ci=(math.exp(eff2 - tc * se2), math.exp(eff2 + tc * se2)), p2=2 * stats.t.sf(abs(eff2 / se2), df),
               interaction=math.exp(inter), inter_ci=(math.exp(inter - tc * se_i), math.exp(inter + tc * se_i)), p_inter=p, df=df,
               attenuation=1 - (eff2 / eff1) if eff1 != 0 else float('nan'))
    return out


def twoway_lin(groups, g1a, g1b, g2a, g2b):
    arrs = [np.asarray(groups[k], float) for k in (g1a, g1b, g2a, g2b)]
    ns = [len(x) for x in arrs]
    means = [x.mean() for x in arrs]
    ss = sum(((x - x.mean()) ** 2).sum() for x in arrs)
    df = sum(ns) - 4
    s2 = ss / df
    eff1 = means[1] - means[0]
    eff2 = means[3] - means[2]
    inter = eff2 - eff1
    se_i = math.sqrt(s2 * sum(1 / n for n in ns))
    p = 2 * stats.t.sf(abs(inter / se_i), df)
    tc = stats.t.ppf(0.975, df)
    return dict(eff1=eff1, eff2=eff2, inter=inter, inter_ci=(inter - tc * se_i, inter + tc * se_i), p_inter=p, df=df)
