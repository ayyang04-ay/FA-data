from PIL import Image
import numpy as np, json
im = np.asarray(Image.open('/tmp/work/xlsx/src/xl/media/image26.jpeg').convert('L')).astype(float)
inv = 255 - im
# lane centers (x) and band y-range per volunteer/protein (from gridded crops)
spec = {
 (1,'GP6'):    ([330,375,420,466], (165,185), 20),
 (1,'P2RY12'): ([748,795,845,893], (165,182), 22),
 (1,'ACTB'):   ([1168,1222,1273,1326], (157,175), 22),
 (2,'GP6'):    ([303,360,416,472], (430,448), 24),
 (2,'P2RY12'): ([712,759,806,853], (416,431), 19),
 (2,'ACTB'):   ([1202,1268,1336,1400], (413,435), 26),
 (3,'GP6'):    ([326,372,422,472], (688,705), 20),
 (3,'P2RY12'): ([722,776,834,892], (690,712), 22),
 (3,'ACTB'):   ([1178,1245,1310,1375], (683,703), 26),
 (4,'GP6'):    ([259,318,378,436], (980,1002), 24),
 (4,'P2RY12'): ([751,813,873,932], (980,1002), 24),
 (4,'ACTB'):   ([1215,1277,1336,1400], (978,1000), 24),
}
out = {}
for (v, prot), (xs, (y0, y1), hw) in spec.items():
    vals = []
    for x in xs:
        box = inv[y0:y1, x-hw:x+hw]
        above = inv[max(0,y0-16):y0-6, x-hw:x+hw]
        below = inv[y1+6:y1+16, x-hw:x+hw]
        bg = np.median(np.concatenate([above.ravel(), below.ravel()]))
        vals.append(float(np.clip(box - bg, 0, None).sum()))
    out[(v, prot)] = vals
D = json.load(open('/tmp/work/tidy.json'))
rep = {'GP6': np.array(D['Fig. 7e']['GP6/ACTB']), 'P2RY12': np.array(D['Fig. 7e']['P2RY12/ACTB'])}
print('My densitometry of Supp Fig 8d (JPEG; approximate) vs reported Fig 7e ratios')
for prot in ['GP6', 'P2RY12']:
    print(f'\n{prot}/ACTB  (normalised to each volunteer\'s day 0)')
    mine_all = []
    for v in range(1, 5):
        r = np.array(out[(v, prot)]) / np.array(out[(v, 'ACTB')])
        r = r / r[0]
        mine_all.append(r)
        print(f'  V{v} mine: ' + ' '.join(f'{x:5.2f}' for x in r))
    print('  reported rows (each normalised to own day 0):')
    for i in range(4):
        rr = rep[prot][i] / rep[prot][i][0]
        print(f'  row{i+1}:    ' + ' '.join(f'{x:5.2f}' for x in rr))
print('\nraw integrals:')
for k, v in out.items(): print(k, [round(x) for x in v])
