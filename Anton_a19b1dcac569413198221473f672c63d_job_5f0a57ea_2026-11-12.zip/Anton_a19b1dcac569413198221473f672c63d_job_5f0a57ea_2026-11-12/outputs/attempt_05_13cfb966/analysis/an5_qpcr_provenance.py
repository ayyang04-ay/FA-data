import json, numpy as np
D = json.load(open('/tmp/work/tidy.json'))
Q = D['qPCR']
def cls(x):
    if x is None: return 'None'
    x = float(x)
    if float(np.float32(x)) == x: return 'f32'
    if abs(x - round(x, 2)) < 1e-9: return '2dp'
    if abs(x*1000 - round(x*1000)) < 1e-6: return '3dp'
    # difference of two float32 values? (dCT computed in double from float32 Ct) -> check if x*2^k integer for modest k
    for k in range(10, 30):
        if abs(x*2**k - round(x*2**k)) < 1e-6: return f'dyadic{k}'
    return 'other'
for sheet, genes in Q.items():
    if sheet == 'Fig. 7d': continue
    print('==', sheet)
    for gene, groups in genes.items():
        s = []
        for lab, vals in groups.items():
            c = [cls(v) for v in vals]
            s.append(f"{lab}:{','.join(c)}")
        print(f'   {gene:10s} ' + ' | '.join(s))
