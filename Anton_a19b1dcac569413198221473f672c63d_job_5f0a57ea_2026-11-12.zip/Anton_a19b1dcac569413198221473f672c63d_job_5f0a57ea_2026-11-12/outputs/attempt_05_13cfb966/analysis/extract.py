"""Extract raw data from CRE-MK-01 workbook into tidy JSON for re-analysis.
Run with: mm singlecell python /tmp/work/extract.py
"""
import openpyxl, json, re
from openpyxl.utils import column_index_from_string as ci, get_column_letter as gl

WB = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)
OUT = {}


def col(ws, letter, r0, r1):
    vals = []
    for r in range(r0, r1 + 1):
        v = ws[f'{letter}{r}'].value
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            vals.append(float(v))
    return vals


def rowvals(ws, r, c0, c1):
    vals = []
    for c in range(ci(c0), ci(c1) + 1):
        v = ws.cell(row=r, column=c).value
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            vals.append(float(v))
    return vals


def two_group(sheet, name, rows, cols=('B', 'C'), labels=('Vehicle', 'Creatine'), unit='animal'):
    ws = WB[sheet]
    d = {labels[i]: col(ws, cols[i], rows[0], rows[1]) for i in range(len(cols))}
    OUT.setdefault(sheet, {})[name] = {'groups': d, 'unit': unit}

# ---------------- Fig 1 ----------------
two_group('Fig. 1a', 'Lung weight (g)', (3, 8))
two_group('Fig. 1a', 'SUV-BW', (12, 17))
two_group('Fig. 1b', 'Metastatic burden (%)', (3, 8))
two_group('Fig. 1b', 'Metastatic foci', (12, 17))
two_group('Fig. 1j', 'Lung weight (g)', (4, 9))
two_group('Fig. 1j', 'SUV-BW', (13, 18))
two_group('Fig. 1k', 'Metastatic burden (%)', (4, 9))
two_group('Fig. 1k', 'Metastatic foci', (12, 17))
two_group('Fig. 1i', 'GFP+ cells per field', (4, 11), unit='field (8 random fields/group)')

# survival
for sheet, r0, r1 in [('Fig. 1c', 4, 23), ('Fig. 1l', 4, 41)]:
    ws = WB[sheet]
    veh, cre = [], []
    for r in range(r0, r1 + 1):
        t = ws[f'A{r}'].value
        if t is None:
            continue
        if ws[f'B{r}'].value == 1:
            veh.append(float(t))
        elif ws[f'C{r}'].value == 1:
            cre.append(float(t))
    OUT.setdefault(sheet, {})['Survival (d)'] = {'groups': {'Vehicle': veh, 'Creatine': cre}, 'unit': 'animal'}

# Fig 1f 2x2
ws = WB['Fig. 1f']
for name, r0 in [('Lung weight (g)', 4), ('SUV-BW', 13), ('Metastatic burden (%)', 22), ('Metastatic foci', 31)]:
    OUT.setdefault('Fig. 1f', {})[name] = {'groups': {
        'shScr-Vehicle': col(ws, 'B', r0, r0 + 5), 'shScr-Creatine': col(ws, 'C', r0, r0 + 5),
        'shSlc6a8-Vehicle': col(ws, 'D', r0, r0 + 5), 'shSlc6a8-Creatine': col(ws, 'E', r0, r0 + 5)}, 'unit': 'animal'}

# Fig 1h time course (rows 4-7, B-G vehicle, H-M creatine)
ws = WB['Fig. 1h']
tc = {}
for r in range(4, 8):
    t = ws[f'A{r}'].value
    tc[str(t)] = {'Vehicle': rowvals(ws, r, 'B', 'G'), 'Creatine': rowvals(ws, r, 'H', 'M')}
OUT['Fig. 1h'] = {'timecourse': tc}

# ---------------- Fig 2 ----------------
ws = WB['Fig. 2a']
for name, r0 in [('PLT', 4), ('PCT', 12), ('PDW', 19), ('MPV', 27)]:
    OUT.setdefault('Fig. 2a', {})[name] = {'groups': {'Vehicle': col(ws, 'B', r0, r0 + 2), 'Creatine': col(ws, 'C', r0, r0 + 2)}, 'unit': 'animal'}
ws = WB['Fig. 2b']
for r in (4, 5, 6):
    ag = ws[f'A{r}'].value
    OUT.setdefault('Fig. 2b', {})[f'Aggregation {ag} (%)'] = {'groups': {'Vehicle': rowvals(ws, r, 'B', 'D'), 'Creatine': rowvals(ws, r, 'E', 'G')}, 'unit': 'animal'}
two_group('Fig. 2c', 'alpha-granules', (4, 11), unit='field (8 random fields/group)')
ws = WB['Fig. 2d']
for name, r0 in [('TEG-R (min)', 4), ('TEG-K (min)', 12), ('TEG-alpha (deg)', 20), ('TEG-MA (mm)', 28)]:
    OUT.setdefault('Fig. 2d', {})[name] = {'groups': {'Vehicle': col(ws, 'B', r0, r0 + 4), 'Creatine': col(ws, 'C', r0, r0 + 4)}, 'unit': 'animal'}
two_group('Fig. 2j', 'PKH positive area (%)', (4, 11), unit='field (8 random fields/group)')

# ---------------- Fig 3 ----------------
ws = WB['Fig. 3b']
OUT['Fig. 3b'] = {'Serum creatine (uM)': {'groups': {
    'WT-Vehicle': rowvals(ws, 4, 'B', 'F'), 'WT-Creatine': rowvals(ws, 4, 'G', 'K'),
    'KO-Vehicle': rowvals(ws, 5, 'B', 'F'), 'KO-Creatine': rowvals(ws, 5, 'G', 'K')}, 'unit': 'animal'}}
ws = WB['Fig. 3c']
OUT['Fig. 3c'] = {'MK creatine': {'groups': {
    'WT-Vehicle': rowvals(ws, 4, 'B', 'D'), 'WT-Creatine': rowvals(ws, 4, 'E', 'G'),
    'KO-Vehicle': rowvals(ws, 5, 'B', 'D'), 'KO-Creatine': rowvals(ws, 5, 'E', 'G')}, 'unit': 'animal'}}
ws = WB['Fig. 3d']
for r in (4, 5, 6):
    ag = ws[f'A{r}'].value
    OUT.setdefault('Fig. 3d', {})[f'Aggregation {ag} (%)'] = {'groups': {
        'WT-Vehicle': rowvals(ws, r, 'B', 'D'), 'WT-Creatine': rowvals(ws, r, 'E', 'G'),
        'KO-Vehicle': rowvals(ws, r, 'H', 'J'), 'KO-Creatine': rowvals(ws, r, 'K', 'M')}, 'unit': 'animal'}
ws = WB['Fig. 3i']
for name, r0 in [('Lung weight (g)', 3), ('Metastatic burden (%)', 10), ('Metastatic foci', 17)]:
    OUT.setdefault('Fig. 3i', {})[name] = {'groups': {
        'WT-Vehicle': col(ws, 'B', r0, r0 + 3), 'WT-Creatine': col(ws, 'C', r0, r0 + 3),
        'KO-Vehicle': col(ws, 'D', r0, r0 + 3), 'KO-Creatine': col(ws, 'E', r0, r0 + 3)}, 'unit': 'animal'}

# ---------------- Fig 4 ----------------
ws = WB['Fig. 4a']
OUT['Fig. 4a'] = {'Creatine (umol/g)': {'groups': {'MK-Vehicle': col(ws, 'B', 4, 6), 'MK-Creatine': col(ws, 'C', 4, 6), 'Brain-Vehicle': col(ws, 'D', 4, 6), 'Brain-Creatine': col(ws, 'E', 4, 6)}, 'unit': 'animal'}}
ws = WB['Fig. 4c']
OUT['Fig. 4c'] = {'Phosphocreatine (ng/ug)': {'groups': {'MK-Vehicle': col(ws, 'B', 4, 6), 'MK-Creatine': col(ws, 'C', 4, 6), 'Brain-Vehicle': col(ws, 'D', 4, 6), 'Brain-Creatine': col(ws, 'E', 4, 6)}, 'unit': 'animal'}}
ws = WB['Fig. 4d']
OUT['Fig. 4d'] = {'MK in vitro "Creatinine" (umol/g) [label as in sheet]': {'groups': {'Control': col(ws, 'C', 4, 6), 'Creatine': col(ws, 'D', 4, 6)}, 'unit': 'culture'}}
ws = WB['Fig. 4f']
OUT['Fig. 4f'] = {'Phosphocreatine (ng/ug) MK in vitro': {'groups': {'Control': col(ws, 'B', 4, 6), 'Creatine': col(ws, 'C', 4, 6)}, 'unit': 'culture'}}

# ---------------- Fig 5 ----------------
for sheet in ('Fig. 5e', 'Fig. 5f'):
    ws = WB[sheet]
    OUT[sheet] = {'p-FLAG/FLAG': {'groups': {
        'Vehicle-WT': col(ws, 'N', 4, 6), 'Vehicle-S127A': col(ws, 'O', 4, 6), 'Vehicle-3A': col(ws, 'P', 4, 6), 'Vehicle-S127D': col(ws, 'Q', 4, 6),
        'Creatine-WT': col(ws, 'N', 17, 19), 'Creatine-S127A': col(ws, 'O', 17, 19), 'Creatine-3A': col(ws, 'P', 17, 19), 'Creatine-S127D': col(ws, 'Q', 17, 19)}, 'unit': 'blot replicate'}}
ws = WB['Fig. 5j']
chip = {}
for gene, r0 in (('P2ry12', 5), ('Gp6', 15)):
    for k in range(4):
        r = r0 + k
        region = ws[f'A{r}'].value
        chip[f'{gene} {region}'] = {'Vehicle': rowvals(ws, r, 'B', 'D'), 'Creatine': rowvals(ws, r, 'E', 'G')}
ws = WB['Supplementary Fig  6i']
for k in range(4):
    r = 7 + k
    region = ws[f'B{r}'].value
    chip[f'Rab4a {region}'] = {'Vehicle': rowvals(ws, r, 'C', 'E'), 'Creatine': rowvals(ws, r, 'F', 'H')}
OUT['ChIP (Fig 5j + Supp 6i)'] = chip

# ---------------- Fig 6 ----------------
ws = WB['Fig. 6b']
for name, r0 in [('Metastatic burden (%)', 4), ('Metastatic foci', 13)]:
    OUT.setdefault('Fig. 6b', {})[name] = {'groups': {
        'Vehicle': col(ws, 'B', r0, r0 + 4), 'Creatine': col(ws, 'C', r0, r0 + 4),
        'Vehicle+STAT5i': col(ws, 'D', r0, r0 + 4), 'Creatine+STAT5i': col(ws, 'E', r0, r0 + 4)}, 'unit': 'animal'}
ws = WB['Fig. 6e']
OUT['Fig. 6e'] = {'MK creatine (umol/g)': {'groups': {'WT-Vehicle': col(ws, 'C', 5, 7), 'WT-Creatine': col(ws, 'D', 5, 7), 'Stat5bKO-Creatine': col(ws, 'E', 5, 7)}, 'unit': 'animal'}}

# ---------------- Fig 7 ----------------
ws = WB['Fig. 7b']
OUT['Fig. 7b'] = {'Serum creatine (uM)': {'wide': [rowvals(ws, r, 'B', 'E') for r in range(4, 15)], 'times': [0, 3, 7, 14]}}
ws = WB['Fig. 7c']
hum = {}
blocks = [('collagen', 'max', 4), ('collagen', 'avg', 18), ('collagen', 'adhesion', 32),
          ('EPI', 'max', 46), ('EPI', 'avg', 60), ('EPI', 'adhesion', 74),
          ('AA', 'max', 88), ('AA', 'avg', 102), ('AA', 'adhesion', 116),
          ('ADP', 'max', 130), ('ADP', 'avg', 144), ('ADP', 'adhesion', 157)]
for ag, metric, r0 in blocks:
    hum[f'{ag} {metric}'] = [rowvals(ws, r, 'B', 'E') for r in range(r0, r0 + 11)]
OUT['Fig. 7c'] = {'fold_change_wide': hum, 'times': [0, 3, 7, 14]}
ws = WB['Fig. 7e']
OUT['Fig. 7e'] = {'GP6/ACTB': [rowvals(ws, r, 'B', 'E') for r in range(4, 8)], 'P2RY12/ACTB': [rowvals(ws, r, 'B', 'E') for r in range(12, 16)], 'times': [0, 3, 7, 14]}
ws = WB['Fig. 7g']
for name, r0 in [('Lung weight (g)', 4), ('Metastatic burden (%)', 12), ('Metastatic foci', 19)]:
    OUT.setdefault('Fig. 7g', {})[name] = {'groups': {'Day0 donor PLT': col(ws, 'B', r0, r0 + 4), 'Day7 donor PLT': col(ws, 'C', r0, r0 + 4)}, 'unit': 'recipient mouse'}

# ---------------- Supplementary ----------------
ws = WB['Supplementary Fig  1a']
OUT['Supp 1a'] = {'Body weight (g)': {'Vehicle': {'d0': rowvals(ws, 4, 'B', 'E'), 'd7': rowvals(ws, 5, 'B', 'E')}, 'Creatine': {'d0': rowvals(ws, 4, 'F', 'I'), 'd7': rowvals(ws, 5, 'F', 'I')}}}
two_group('Supplementary Fig  1b', 'Food intake (g/d)', (4, 9))
two_group('Supplementary Fig  1c', 'Water intake (g/d)', (4, 9))
two_group('Supplementary Fig  1d', 'Serum creatine (uM)', (4, 9))
two_group('Supplementary Fig  1e', 'Lung weight (g)', (4, 9))
two_group('Supplementary Fig  1e', 'Metastatic burden (%)', (13, 18))
two_group('Supplementary Fig  1e', 'Metastatic foci', (22, 27))
two_group('Supplementary Fig  1f', 'Lung weight (g)', (4, 7))
two_group('Supplementary Fig  1f', 'Metastatic burden (%)', (12, 15))
two_group('Supplementary Fig  1f', 'Metastatic foci', (20, 23))
two_group('Supplementary Fig  1g', 'Lung weight (g)', (3, 12))
two_group('Supplementary Fig  1g', 'Metastatic burden (%)', (15, 24))
two_group('Supplementary Fig  1g', 'Metastatic foci', (28, 37))
two_group('Supplementary Fig  1h', 'Serum creatine (uM)', (4, 7), cols=('C', 'D'), labels=('Control diet', 'Creatine diet'))
two_group('Supplementary Fig  1i', 'Lung weight (g)', (3, 6), labels=('Control diet', 'Creatine diet'))
two_group('Supplementary Fig  1i', 'Metastatic burden (%)', (11, 14), labels=('Control diet', 'Creatine diet'))
two_group('Supplementary Fig  1i', 'Metastatic foci', (18, 21), labels=('Control diet', 'Creatine diet'))
two_group('Supplementary Fig  1k', 'Lung weight (g)', (4, 13))
two_group('Supplementary Fig  1k', 'Metastatic burden (%)', (16, 25))
two_group('Supplementary Fig  1k', 'Metastatic foci', (29, 38))
ws = WB['Supplementary Fig  2d']
for name, r0 in [('Metastatic burden (%)', 5), ('Metastatic foci', 14)]:
    OUT.setdefault('Supp 2d', {})[name] = {'groups': {
        'Vehicle donor PLT': col(ws, 'C', r0, r0 + 5), 'Creatine donor PLT': col(ws, 'D', r0, r0 + 5), 'Creatine+aspirin donor PLT': col(ws, 'E', r0, r0 + 5)}, 'unit': 'recipient mouse'}
ws = WB['Supplementary Fig  3a']
for name, r0 in [('WBC', 4), ('Lymphocyte', 12), ('Monocyte', 20), ('RBC', 28)]:
    OUT.setdefault('Supp 3a', {})[name] = {'groups': {'Vehicle': col(ws, 'B', r0, r0 + 4), 'Creatine': col(ws, 'C', r0, r0 + 4)}, 'unit': 'animal'}
ws = WB['Supplementary Fig  4b']
OUT['Supp 4b'] = {'PLT': {'groups': {'WT-Vehicle': col(ws, 'C', 5, 7), 'WT-Creatine': col(ws, 'D', 5, 7), 'KO-Vehicle': col(ws, 'E', 5, 7), 'KO-Creatine': col(ws, 'F', 5, 7)}, 'unit': 'animal'}}
ws = WB['Supplementary Fig  4c']
OUT['Supp 4c'] = {'alpha-granules': {'groups': {'WT-Vehicle': col(ws, 'C', 6, 13), 'WT-Creatine': col(ws, 'D', 6, 13), 'KO-Vehicle': col(ws, 'E', 6, 13), 'KO-Creatine': col(ws, 'F', 6, 13)}, 'unit': 'field (8 random fields/group)'}}
ws = WB['Supplementary Fig  5c']
OUT['Supp 5c'] = {'MK creatine': {'groups': {'CKB-EV': col(ws, 'B', 5, 7), 'CKB-OE': col(ws, 'C', 5, 7)}}, 'MK PCr': {'groups': {'CKB-EV': col(ws, 'B', 13, 15), 'CKB-OE': col(ws, 'C', 13, 15)}}}
ws = WB['Supplementary Fig  7a']
for name, r0 in [('PLT', 4), ('PCT', 11), ('MPV', 17), ('PDW', 23)]:
    OUT.setdefault('Supp 7a', {})[name] = {'groups': {'Vehicle': col(ws, 'B', r0, r0 + 2), 'Creatine': col(ws, 'C', r0, r0 + 2), 'Vehicle+STAT5i': col(ws, 'D', r0, r0 + 2), 'Creatine+STAT5i': col(ws, 'E', r0, r0 + 2)}}
ws = WB['Supplementary Fig  7b']
for name, r0 in [('PLT', 4), ('PCT', 10), ('MPV', 16), ('PDW', 22)]:
    OUT.setdefault('Supp 7b', {})[name] = {'groups': {'WT-Vehicle': col(ws, 'B', r0, r0 + 2), 'WT-Creatine': col(ws, 'C', r0, r0 + 2), 'Stat5bKO-Creatine': col(ws, 'D', r0, r0 + 2)}}
ws = WB['Supplementary Fig  8a']
OUT['Supp 8a'] = {'BMI': {'d0': col(ws, 'C', 4, 14), 'd14': col(ws, 'D', 4, 14)}}
ws = WB['Supplementary Fig  8b']
for name, r0 in [('PLT', 4), ('PCT', 19), ('MPV', 33), ('PDW', 48)]:
    OUT.setdefault('Supp 8b', {})[name] = [rowvals(ws, r, 'B', 'E') for r in range(r0, r0 + 11)]


# ---------------- qPCR sheets ----------------
def qpcr_sheet(sheet, groups, first_row_gene_col='A'):
    """Parse blocks of: gene name row with dCT1 (G:I), dCT2.. in subsequent row. groups: list of (label, rowoffset, cols)"""
    ws = WB[sheet]
    res = {}
    for r in range(1, ws.max_row + 1):
        g = ws[f'{first_row_gene_col}{r}'].value
        if isinstance(g, str) and ws[f'F{r}'].value == 'ΔCT1':
            block = {}
            for lab, roff, cols in groups:
                block[lab] = [ws[f'{c}{r + roff}'].value for c in cols]
            res[g] = block
    return res

Q = {}
std2 = [('Vehicle', 0, 'GHI'), ('Creatine', 1, 'GHI')]
Q['Fig. 2f'] = qpcr_sheet('Fig. 2f', [('Vehicle', 0, 'GHI'), ('Creatine', 1, 'GHI')])
Q['Fig. 3f'] = qpcr_sheet('Fig. 3f', [('WT-Vehicle', 0, 'GHI'), ('WT-Creatine', 1, 'GHI'), ('KO-Vehicle', 1, 'KLM'), ('KO-Creatine', 1, 'OPQ')])
Q['Fig. 4h'] = qpcr_sheet('Fig. 4h', [('Control', 0, 'GHI'), ('Creatine', 1, 'GHI'), ('Phosphocreatine', 1, 'KLM')])
Q['Fig. 4j'] = qpcr_sheet('Fig. 4j', [('Control+siScr', 0, 'GHI'), ('Control+siCkb', 1, 'GHI'), ('Creatine+siScr', 1, 'KLM'), ('Creatine+siCkb', 1, 'OPQ')])
Q['Fig. 4l'] = qpcr_sheet('Fig. 4l', [('CKB-EV', 0, 'GHI'), ('CKB-OE', 1, 'GHI')])
Q['Fig. 6a'] = qpcr_sheet('Fig.6a', [('Vehicle', 0, 'GHI'), ('Creatine', 1, 'GHI'), ('Vehicle+STAT5i', 1, 'KLM'), ('Creatine+STAT5i', 1, 'OPQ')])
Q['Fig. 6g'] = qpcr_sheet('Fig. 6g', [('WT-Vehicle', 0, 'GHI'), ('WT-Creatine', 1, 'GHI'), ('Stat5bKO-Creatine', 1, 'KLM')])
Q['Supp 3c'] = qpcr_sheet('Supplementary Fig  3c', [('Vehicle', 0, 'GHI'), ('Creatine', 1, 'GHI')])
Q['Supp 4e'] = qpcr_sheet('Supplementary Fig  4e', [('KO Control', 0, 'GHI'), ('KO Creatine', 1, 'GHI'), ('KO Creatine@liposome', 1, 'KLM')])
# Fig 4e (Ckb) and Supp 2a (Slc6a8) and Supp 5a (Gatm/Gamt)
ws = WB['Fig. 4e']
Q['Fig. 4e'] = {'Ckb': {'Vehicle': [ws[f'{c}5'].value for c in 'IJK'], 'Creatine': [ws[f'{c}6'].value for c in 'IJK']}}
ws = WB['Supplementary Fig  2a']
Q['Supp 2a'] = {'Slc6a8 (tumour cells)': {'si/sh-scrambled': [ws[f'{c}4'].value for c in 'HIJ'], 'si/sh-Slc6a8': [ws[f'{c}5'].value for c in 'HIJ']}}
ws = WB['Supplementary Fig  5a']
Q['Supp 5a'] = {'Gatm': {'Vehicle': [ws[f'{c}5'].value for c in 'CDE'], 'Creatine': [ws[f'{c}5'].value for c in 'GHI']},
                'Gamt': {'Vehicle': [ws[f'{c}8'].value for c in 'CDE'], 'Creatine': [ws[f'{c}8'].value for c in 'GHI']}}
# human 7d: per gene per volunteer triplicate dCT at 0,3,7,14
ws = WB['Fig. 7d']
hq = {}
for r in range(1, ws.max_row + 1):
    for gcol, vcols in (('A', 'CDEF'), ('H', 'IJKL')):
        g = ws[f'{gcol}{r}'].value
        if isinstance(g, str) and ws[f'{vcols[0]}{r}'].value == 'Volunteer1':
            d = {}
            for vi, vc in enumerate(vcols):
                d[f'V{vi + 1}'] = {}
                for ti, t in enumerate(['0d', '3d', '7d', '14d']):
                    d[f'V{vi + 1}'][t] = [ws[f'{vc}{r + 1 + ti * 3 + k}'].value for k in range(3)]
                d[f'V{vi + 1}']['sheet_norm'] = [ws[f'{vc}{r + 13 + k}'].value for k in range(4)]
            hq[g] = d
Q['Fig. 7d'] = hq
OUT['qPCR'] = Q

json.dump(OUT, open('/tmp/work/tidy.json', 'w'), indent=1, default=str)
print('saved', len(OUT))
