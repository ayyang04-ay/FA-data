import json, numpy as np
D = json.load(open('/tmp/work/tidy.json'))
Q = D['qPCR']['Fig. 3f']
def near_f32(x, tol=1e-12):
    return abs(float(np.float32(x)) - x) < tol
for gene, g in Q.items():
    v, c = g['WT-Vehicle'], g['WT-Creatine']
    out = []
    for x1, x2 in zip(v, c):
        d = x2 - x1
        out.append(f"x2={x2!r} f32(x2)={near_f32(x2,0)} | d=x2-x1={d!r} d~f32:{near_f32(d)} (f32(d)={float(np.float32(d))!r})")
    print(gene); [print('    ', o) for o in out]
