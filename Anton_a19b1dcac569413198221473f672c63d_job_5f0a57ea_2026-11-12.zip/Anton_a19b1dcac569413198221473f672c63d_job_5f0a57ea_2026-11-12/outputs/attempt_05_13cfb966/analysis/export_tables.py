import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
import pandas as pd, pickle
from statsmodels.stats.multitest import multipletests
OUT = '/tmp/outputs/tables/'
# ---------- T1 two-group recomputation ----------
panels = [('Fig. 1a','Lung weight (g)'),('Fig. 1a','SUV-BW'),('Fig. 1b','Metastatic burden (%)'),('Fig. 1b','Metastatic foci'),
 ('Fig. 1j','Lung weight (g)'),('Fig. 1j','SUV-BW'),('Fig. 1k','Metastatic burden (%)'),('Fig. 1k','Metastatic foci'),('Fig. 1i','GFP+ cells per field'),
 ('Fig. 2a','PLT'),('Fig. 2a','PCT'),('Fig. 2a','PDW'),('Fig. 2a','MPV'),('Fig. 2b','Aggregation ADP (%)'),('Fig. 2b','Aggregation Collagen (%)'),('Fig. 2b','Aggregation Thrombin (%)'),
 ('Fig. 2c','alpha-granules'),('Fig. 2d','TEG-R (min)'),('Fig. 2d','TEG-K (min)'),('Fig. 2d','TEG-alpha (deg)'),('Fig. 2d','TEG-MA (mm)'),('Fig. 2j','PKH positive area (%)'),
 ('Fig. 4a',None),('Fig. 4c',None),('Fig. 4d',None),('Fig. 4f',None),('Fig. 7g','Lung weight (g)'),('Fig. 7g','Metastatic burden (%)'),('Fig. 7g','Metastatic foci'),
 ('Supplementary Fig  1b','Food intake (g/d)'),('Supplementary Fig  1c','Water intake (g/d)'),('Supplementary Fig  1d','Serum creatine (uM)'),('Supplementary Fig  1h','Serum creatine (uM)'),
 ('Supplementary Fig  1e','Lung weight (g)'),('Supplementary Fig  1e','Metastatic burden (%)'),('Supplementary Fig  1e','Metastatic foci'),
 ('Supplementary Fig  1f','Lung weight (g)'),('Supplementary Fig  1f','Metastatic burden (%)'),('Supplementary Fig  1f','Metastatic foci'),
 ('Supplementary Fig  1g','Lung weight (g)'),('Supplementary Fig  1g','Metastatic burden (%)'),('Supplementary Fig  1g','Metastatic foci'),
 ('Supplementary Fig  1i','Lung weight (g)'),('Supplementary Fig  1i','Metastatic burden (%)'),('Supplementary Fig  1i','Metastatic foci'),
 ('Supplementary Fig  1k','Lung weight (g)'),('Supplementary Fig  1k','Metastatic burden (%)'),('Supplementary Fig  1k','Metastatic foci'),
 ('Supp 3a','WBC'),('Supp 3a','Lymphocyte'),('Supp 3a','Monocyte'),('Supp 3a','RBC')]
rows = []
for sheet, name in panels:
    blk = D[sheet]; name = name or list(blk.keys())[0]; g = blk[name]['groups']; keys = list(g.keys())
    pairs = [(keys[0], keys[1])] if len(keys) == 2 else [(keys[0], keys[1]), (keys[2], keys[3])]
    for a, b in pairs:
        r = two_group_tests(g[a], g[b])
        gm = lo = hi = np.nan
        if min(g[a]) > 0 and min(g[b]) > 0:
            gm, lo, hi, *_ = ratio_ci(g[a], g[b])
        rows.append(dict(panel=sheet.replace('Supplementary Fig  ', 'Supp Fig '), endpoint=name, comparison=f'{b} vs {a}', unit_of_n=blk[name].get('unit', 'animal'),
                         n_ctrl=r['n'][0], n_trt=r['n'][1], mean_ctrl=r['mean'][0], mean_trt=r['mean'][1], GMR=gm, GMR_lo95=lo, GMR_hi95=hi,
                         hedges_g=r['g'], student_p_as_reported_method=r['student_p'], welch_p=r['welch_p'], mann_whitney_exact_p=r['mw_p']))
pd.DataFrame(rows).to_csv(OUT + 'T1_two_group_panels_recomputed.csv', index=False, float_format='%.4g')
# ---------- T2 factorial ----------
designs = [('Fig. 1f','Lung weight (g)','shScr-Vehicle','shScr-Creatine','shSlc6a8-Vehicle','shSlc6a8-Creatine'),
 ('Fig. 1f','SUV-BW','shScr-Vehicle','shScr-Creatine','shSlc6a8-Vehicle','shSlc6a8-Creatine'),
 ('Fig. 1f','Metastatic burden (%)','shScr-Vehicle','shScr-Creatine','shSlc6a8-Vehicle','shSlc6a8-Creatine'),
 ('Fig. 1f','Metastatic foci','shScr-Vehicle','shScr-Creatine','shSlc6a8-Vehicle','shSlc6a8-Creatine'),
 ('Fig. 3i','Lung weight (g)','WT-Vehicle','WT-Creatine','KO-Vehicle','KO-Creatine'),
 ('Fig. 3i','Metastatic burden (%)','WT-Vehicle','WT-Creatine','KO-Vehicle','KO-Creatine'),
 ('Fig. 3i','Metastatic foci','WT-Vehicle','WT-Creatine','KO-Vehicle','KO-Creatine'),
 ('Fig. 6b','Metastatic burden (%)','Vehicle','Creatine','Vehicle+STAT5i','Creatine+STAT5i'),
 ('Fig. 6b','Metastatic foci','Vehicle','Creatine','Vehicle+STAT5i','Creatine+STAT5i'),
 ('Fig. 3b','Serum creatine (uM)','WT-Vehicle','WT-Creatine','KO-Vehicle','KO-Creatine'),
 ('Fig. 3c','MK creatine','WT-Vehicle','WT-Creatine','KO-Vehicle','KO-Creatine'),
 ('Fig. 3d','Aggregation ADP (%)','WT-Vehicle','WT-Creatine','KO-Vehicle','KO-Creatine'),
 ('Fig. 3d','Aggregation Collagen (%)','WT-Vehicle','WT-Creatine','KO-Vehicle','KO-Creatine'),
 ('Fig. 3d','Aggregation Thrombin (%)','WT-Vehicle','WT-Creatine','KO-Vehicle','KO-Creatine'),
 ('Supp 4b','PLT','WT-Vehicle','WT-Creatine','KO-Vehicle','KO-Creatine'),
 ('Supp 4c','alpha-granules','WT-Vehicle','WT-Creatine','KO-Vehicle','KO-Creatine'),
 ('Fig. 5e','p-FLAG/FLAG','Vehicle-WT','Creatine-WT','Vehicle-S127A','Creatine-S127A'),
 ('Fig. 5f','p-FLAG/FLAG','Vehicle-WT','Creatine-WT','Vehicle-S127A','Creatine-S127A')]
rows = []
for sheet, name, a1, b1, a2, b2 in designs:
    g = D[sheet][name]['groups']; r = twoway_log(g, a1, b1, a2, b2)
    rows.append(dict(panel=sheet, endpoint=name, reference_arms=f'{a1} -> {b1}', perturbed_arms=f'{a2} -> {b2}',
                     n_per_cell=len(g[a1]), creatine_effect_ref=r['effect1'], ref_lo=r['effect1_ci'][0], ref_hi=r['effect1_ci'][1], ref_p=r['p1'],
                     creatine_effect_test=r['effect2'], test_lo=r['effect2_ci'][0], test_hi=r['effect2_ci'][1], test_p=r['p2'],
                     interaction_ratio=r['interaction'], inter_lo=r['inter_ci'][0], inter_hi=r['inter_ci'][1], inter_p=r['p_inter'], unit=D[sheet][name].get('unit', 'animal')))
pd.DataFrame(rows).to_csv(OUT + 'T2_factorial_interaction_tests.csv', index=False, float_format='%.4g')
# ---------- T4 human platelet function ----------
H = D['Fig. 7c']['fold_change_wide']; rows = []
for k, M in H.items():
    M = np.array(M, float)
    for j, t in enumerate([3, 7, 14], 1):
        x = M[:, j]; lx = np.log2(x[x > 0])
        rows.append(dict(readout=k, day=t, n=len(x), n_up=int((x > 1).sum()), median_fold=np.median(x), geomean_fold=2**lx.mean(),
                         p_wilcoxon=stats.wilcoxon(x - 1).pvalue, p_t_log2=stats.ttest_1samp(lx, 0).pvalue))
df = pd.DataFrame(rows); df['q_BH_wilcoxon'] = multipletests(df.p_wilcoxon, method='fdr_bh')[1]; df['q_BH_t'] = multipletests(df.p_t_log2, method='fdr_bh')[1]
df.to_csv(OUT + 'T4_human_platelet_function_reanalysis.csv', index=False, float_format='%.4g')
# ---------- T6 mouse qPCR ----------
rows = pickle.load(open('/tmp/work/qpcr_rows.pkl', 'rb'))
pd.DataFrame(rows, columns=['panel', 'contrast', 'gene', 'log2FC_sheet_convention', 'welch_p_on_dCT']).assign(fold=lambda d: 2**d.log2FC_sheet_convention).to_csv(OUT + 'T6_mouse_qPCR_contrasts.csv', index=False, float_format='%.4g')
print('ok')
