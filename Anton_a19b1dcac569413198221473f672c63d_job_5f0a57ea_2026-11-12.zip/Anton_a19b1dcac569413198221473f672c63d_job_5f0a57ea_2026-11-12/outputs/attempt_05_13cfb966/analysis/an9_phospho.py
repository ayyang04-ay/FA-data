import pandas as pd, numpy as np
from statsmodels.stats.multitest import multipletests
df = pd.read_excel('/tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx', sheet_name=0)
df.columns = ['gene','p','q','lfc']
n = len(df)
print('phosphopeptides:', n, 'unique gene names:', df.gene.nunique())
# p-value histogram
h, e = np.histogram(df.p, bins=20, range=(0,1))
print('p-value histogram (20 bins of 0.05):', h.tolist())
print('expected per bin under null:', n/20)
# Storey pi0 at lambda=0.5
for lam in [0.5, 0.6, 0.7]:
    pi0 = (df.p > lam).sum() / (n*(1-lam))
    print(f'Storey pi0 (lambda={lam}): {pi0:.2f}')
# artefact
art = df[np.isclose(df.p, 0.42265, atol=1e-5)]
print(f'peptides with identical p=0.42265: {len(art)} ({100*len(art)/n:.0f}%), |log2FC| median {art.lfc.abs().median():.2f}; others |log2FC| median {df.drop(art.index).lfc.abs().median():.2f}')
# BH
bh = multipletests(df.p, method='fdr_bh')[1]
print('BH q min:', bh.min().round(3), '; # BH q<0.05:', (bh<0.05).sum(), '; # BH q<0.2:', (bh<0.2).sum())
print('provided Q-values: min', df.q.min().round(3), 'max', df.q.max().round(3))
# DE criteria
fc = 2**df.lfc
sel = ((fc >= 1.2) | (fc <= 0.83)) & (df.p < 0.05)
print('"differential" by study criteria (FC>=1.2 or <=0.83, p<0.05; log2 assumed):', sel.sum(), 'of', n, f'({100*sel.mean():.1f}%)')
# expected false positives among these under global null
null_rate = ((fc >= 1.2) | (fc <= 0.83)).mean()*0.05
print(f'expected number passing by chance if no true effects: ~{null_rate*n:.0f} (= fraction with |FC| beyond threshold x 0.05 x n)')
# Stat5b
st = df[df.gene=='Stat5b']
print(st)
rank = (df.p < st.p.min()).sum() + 1
print('Stat5b best peptide rank by p:', rank, 'of', n)
# top hits with p<0.001
print(df.sort_values('p').head(12)[['gene','p','q','lfc']].to_string(index=False))
