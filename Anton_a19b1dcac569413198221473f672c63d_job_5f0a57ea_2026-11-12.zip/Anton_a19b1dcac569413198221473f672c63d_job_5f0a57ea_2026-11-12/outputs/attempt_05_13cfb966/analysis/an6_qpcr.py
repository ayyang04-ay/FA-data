import json, numpy as np
from scipy import stats
D = json.load(open('/tmp/work/tidy.json'))
Q = D['qPCR']
contrasts = {
 'Fig. 2f': [('Vehicle','Creatine')],
 'Fig. 3f': [('WT-Vehicle','WT-Creatine'), ('KO-Vehicle','KO-Creatine'), ('WT-Vehicle','KO-Vehicle')],
 'Fig. 4h': [('Control','Creatine'), ('Control','Phosphocreatine')],
 'Fig. 4j': [('Control+siScr','Creatine+siScr'), ('Control+siCkb','Creatine+siCkb'), ('Control+siScr','Control+siCkb')],
 'Fig. 4l': [('CKB-EV','CKB-OE')],
 'Fig. 6a': [('Vehicle','Creatine'), ('Vehicle+STAT5i','Creatine+STAT5i'), ('Vehicle','Vehicle+STAT5i')],
 'Fig. 6g': [('WT-Vehicle','WT-Creatine'), ('WT-Vehicle','Stat5bKO-Creatine')],
 'Supp 4e': [('KO Control','KO Creatine'), ('KO Control','KO Creatine@liposome')],
 'Supp 3c': [('Vehicle','Creatine')],
 'Fig. 4e': [('Vehicle','Creatine')],
 'Supp 2a': [('si/sh-scrambled','si/sh-Slc6a8')],
}
rows = []
for sheet, cons in contrasts.items():
    for a, b in cons:
        print(f'\n== {sheet}: {b} vs {a}   [log2FC = mean dCT({b}) - mean dCT({a}); sheet convention; Welch t on dCT; n=3 vs 3]')
        for gene, g in Q[sheet].items():
            if a not in g or b not in g: continue
            xa = np.array([float(x) for x in g[a]]); xb = np.array([float(x) for x in g[b]])
            lfc = xb.mean() - xa.mean()
            t = stats.ttest_ind(xb, xa, equal_var=False)
            ts = stats.ttest_ind(xb, xa, equal_var=True)
            rows.append((sheet, f'{b} vs {a}', gene, lfc, t.pvalue))
            print(f'   {gene:8s} FC={2**lfc:6.2f} (log2 {lfc:+.2f})  Welch p={t.pvalue:.4f}  Student p={ts.pvalue:.4f}')
import pickle; pickle.dump(rows, open('/tmp/work/qpcr_rows.pkl','wb'))
