import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

studies = [
 ('Fig 1b', 'Fig. 1b', 'Vehicle', 'Creatine'),
 ('Fig 1k', 'Fig. 1k', 'Vehicle', 'Creatine'),
 ('Fig 1f (sh-scr tumour)', 'Fig. 1f', 'shScr-Vehicle', 'shScr-Creatine'),
 ('Fig 3i (Pf4-Cre;Slc6a8+/+)', 'Fig. 3i', 'WT-Vehicle', 'WT-Creatine'),
 ('Fig 6b (no inhibitor)\u2020', 'Fig. 6b', 'Vehicle', 'Creatine'),
 ('Supp 1e', 'Supplementary Fig  1e', 'Vehicle', 'Creatine'),
 ('Supp 1f', 'Supplementary Fig  1f', 'Vehicle', 'Creatine'),
 ('Supp 1g', 'Supplementary Fig  1g', 'Vehicle', 'Creatine'),
 ('Supp 1i (5% diet)', 'Supplementary Fig  1i', 'Control diet', 'Creatine diet'),
 ('Supp 1k', 'Supplementary Fig  1k', 'Vehicle', 'Creatine'),
]
ys, ses, labs, cis, ns = [], [], [], [], []
for lab, sheet, a, b in studies:
    g = D[sheet]['Metastatic burden (%)']['groups']
    gm, lo, hi, p, diff, se, df = ratio_ci(g[a], g[b])
    ys.append(diff); ses.append(se); labs.append(lab); cis.append((lo, hi)); ns.append((len(g[a]), len(g[b])))
ys, ses = np.array(ys), np.array(ses)
w = 1/ses**2; yf = (w*ys).sum()/w.sum(); Q = (w*(ys-yf)**2).sum(); k = len(ys)
C = w.sum() - (w**2).sum()/w.sum(); tau2 = max(0, (Q-(k-1))/C); ws = 1/(ses**2+tau2)
yr = (ws*ys).sum()/ws.sum(); ser = (1/ws.sum())**0.5

# interaction panel
inter = [
 ('MK Slc6a8 KO (Fig 3i)', 'Fig. 3i', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
 ('Tumour shSlc6a8 (Fig 1f)', 'Fig. 1f', 'shScr-Vehicle', 'shScr-Creatine', 'shSlc6a8-Vehicle', 'shSlc6a8-Creatine'),
 ('STAT5 inhibitor (Fig 6b)\u2020', 'Fig. 6b', 'Vehicle', 'Creatine', 'Vehicle+STAT5i', 'Creatine+STAT5i'),
]
fig, axes = plt.subplots(1, 2, figsize=(13, 5.8), gridspec_kw={'width_ratios': [1.25, 1]})
ax = axes[0]
for i, (lab, (lo, hi), y, n) in enumerate(zip(labs, cis, ys, ns)):
    yy = k - i
    ax.plot([lo, hi], [yy, yy], color='k', lw=1.2)
    ax.plot(np.exp(y), yy, 's', color='#1f77b4', ms=6)
    ax.text(0.42, yy, f'{lab}  (n={n[0]}/{n[1]})', va='center', ha='left', fontsize=8.5)
    ax.text(14, yy, f'{np.exp(y):.2f} [{lo:.2f}, {hi:.2f}]', va='center', ha='left', fontsize=8)
ax.plot([np.exp(yr-1.96*ser), np.exp(yr+1.96*ser)], [0, 0], color='#d62728', lw=2)
ax.plot(np.exp(yr), 0, 'D', color='#d62728', ms=8)
ax.text(0.42, 0, 'Random-effects pooled', va='center', fontsize=8.5, weight='bold')
ax.text(14, 0, f'{np.exp(yr):.2f} [{np.exp(yr-1.96*ser):.2f}, {np.exp(yr+1.96*ser):.2f}]', va='center', fontsize=8, weight='bold')
ax.axvline(1, color='grey', ls='--', lw=0.8)
ax.set_xscale('log'); ax.set_xlim(0.4, 40); ax.set_ylim(-1, k+1)
ax.set_xticks([1, 2, 4, 8]); ax.set_xticklabels(['1', '2', '4', '8'])
ax.set_yticks([]); ax.set_xlabel('Creatine vs control: ratio of geometric means, lung metastatic burden (95% CI)')
ax.set_title(f'A. Creatine effect replicates across 10 experiments\n(I\u00b2={100*max(0,(Q-(k-1))/Q):.0f}%; all unblinded; \u2020 3 animals/arm duplicated in Supp 2d)', fontsize=10)

ax = axes[1]
yy = 0
for lab, sheet, a1, b1, a2, b2 in inter:
    g = D[sheet]['Metastatic burden (%)']['groups']
    r = twoway_log(g, a1, b1, a2, b2)
    for nm, e, ci, col in [('control arm', r['effect1'], r['effect1_ci'], '#1f77b4'), ('intervention arm', r['effect2'], r['effect2_ci'], '#ff7f0e')]:
        ax.plot(ci, [yy, yy], color=col, lw=1.5); ax.plot(e, yy, 'o', color=col, ms=6)
        ax.text(0.16, yy, f'{lab.split(" (")[0]}: {nm}', va='center', fontsize=8)
        yy -= 1
    ax.text(0.16, yy+0.35, f'   interaction ratio {r["interaction"]:.2f} [{r["inter_ci"][0]:.2f}, {r["inter_ci"][1]:.2f}], p={fmt_p(r["p_inter"])}', fontsize=8, color='#444', weight='bold')
    yy -= 1.2
ax.axvline(1, color='grey', ls='--', lw=0.8)
ax.set_xscale('log'); ax.set_xlim(0.15, 12); ax.set_yticks([])
ax.set_xticks([0.5, 1, 2, 4, 8]); ax.set_xticklabels(['0.5', '1', '2', '4', '8'])
ax.set_xlabel('Creatine effect on metastatic burden (GMR, 95% CI)')
ax.set_title('B. Which perturbations remove the creatine effect?\n(2\u00d72 interaction on log scale; \u2020 see duplication)', fontsize=10)
plt.tight_layout()
plt.savefig('/tmp/outputs/figures/Fig1_creatine_effect_forest.png', dpi=200)
print('pooled', np.exp(yr), np.exp(yr-1.96*ser), np.exp(yr+1.96*ser))
