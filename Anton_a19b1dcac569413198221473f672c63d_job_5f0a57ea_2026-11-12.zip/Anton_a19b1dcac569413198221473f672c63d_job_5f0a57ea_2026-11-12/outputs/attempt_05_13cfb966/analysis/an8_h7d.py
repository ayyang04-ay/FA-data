import json, numpy as np
from scipy import stats
D = json.load(open('/tmp/work/tidy.json'))
H = D['qPCR']['Fig. 7d']
print('Fig 7d human circulating CD41+ cells, 4 volunteers, technical triplicates; log2FC vs own day 0 (sheet convention: FC = 2^(dCT_t - dCT_0))')
print(f"{'gene':8s} {'day':>4s}  per-volunteer FC (mine)            sheet 'after normalization'          #up  geo-mean  paired t p")
summary = {}
for gene, vols in H.items():
    for t in ['3d', '7d', '14d']:
        mine, sheet = [], []
        for v in ['V1', 'V2', 'V3', 'V4']:
            d0 = np.mean([float(x) for x in vols[v]['0d']]); dt = np.mean([float(x) for x in vols[v][t]])
            mine.append(dt - d0)
            sheet.append(float(vols[v]['sheet_norm'][['0d','3d','7d','14d'].index(t)]))
        mine = np.array(mine)
        p = stats.ttest_1samp(mine, 0).pvalue
        summary[(gene, t)] = (mine, p)
        print(f"{gene:8s} {t:>4s}  " + ' '.join(f'{2**m:6.2f}' for m in mine) + '   |  ' + ' '.join(f'{s:6.2f}' for s in sheet) + f"   {int((mine>0).sum())}/4   {2**mine.mean():6.2f}   {p:.3f}")
# check V4 PITPNB raw values
print('\nPITPNB volunteer-4 recorded "dCT" values:', H['PITPNB']['V4'])
print('Other volunteers PITPNB day0 dCT:', [H['PITPNB'][v]['0d'] for v in ['V1','V2','V3']])
