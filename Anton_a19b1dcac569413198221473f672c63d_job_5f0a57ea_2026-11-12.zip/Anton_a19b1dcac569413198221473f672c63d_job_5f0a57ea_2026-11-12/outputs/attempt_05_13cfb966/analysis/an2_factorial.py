import sys
sys.path.insert(0, '/tmp/work')
from an_common import *
from statsmodels.stats.multicomp import pairwise_tukeyhsd
import pandas as pd

print('=' * 100)
print('B. FACTORIAL / MULTI-GROUP PANELS')
print('=' * 100)


def describe(groups):
    for k, v in groups.items():
        v = np.asarray(v, float)
        print(f'     {k:32s} n={len(v)} mean={v.mean():.4g} sd={v.std(ddof=1):.3g} values={np.round(v, 4).tolist()}')


def tukey(groups):
    vals, labs = [], []
    for k, v in groups.items():
        vals += list(v)
        labs += [k] * len(v)
    res = pairwise_tukeyhsd(np.asarray(vals), np.asarray(labs))
    print('     Tukey (linear scale, all pairs):')
    for line in str(res.summary()).split('\n')[4:-1]:
        print('      ', line)


def anova(groups):
    f, p = stats.f_oneway(*[np.asarray(v, float) for v in groups.values()])
    return f, p

# --- 2x2 designs: genotype/tumour-shRNA x creatine
designs = [
    ('Fig. 1f', 'Lung weight (g)', 'shScr-Vehicle', 'shScr-Creatine', 'shSlc6a8-Vehicle', 'shSlc6a8-Creatine'),
    ('Fig. 1f', 'SUV-BW', 'shScr-Vehicle', 'shScr-Creatine', 'shSlc6a8-Vehicle', 'shSlc6a8-Creatine'),
    ('Fig. 1f', 'Metastatic burden (%)', 'shScr-Vehicle', 'shScr-Creatine', 'shSlc6a8-Vehicle', 'shSlc6a8-Creatine'),
    ('Fig. 1f', 'Metastatic foci', 'shScr-Vehicle', 'shScr-Creatine', 'shSlc6a8-Vehicle', 'shSlc6a8-Creatine'),
    ('Fig. 3i', 'Lung weight (g)', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
    ('Fig. 3i', 'Metastatic burden (%)', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
    ('Fig. 3i', 'Metastatic foci', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
    ('Fig. 6b', 'Metastatic burden (%)', 'Vehicle', 'Creatine', 'Vehicle+STAT5i', 'Creatine+STAT5i'),
    ('Fig. 6b', 'Metastatic foci', 'Vehicle', 'Creatine', 'Vehicle+STAT5i', 'Creatine+STAT5i'),
    ('Fig. 3b', 'Serum creatine (uM)', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
    ('Fig. 3c', 'MK creatine', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
    ('Fig. 3d', 'Aggregation ADP (%)', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
    ('Fig. 3d', 'Aggregation Collagen (%)', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
    ('Fig. 3d', 'Aggregation Thrombin (%)', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
    ('Supp 4b', 'PLT', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
    ('Supp 4c', 'alpha-granules', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine'),
    ('Supp 7a', 'PLT', 'Vehicle', 'Creatine', 'Vehicle+STAT5i', 'Creatine+STAT5i'),
]
for sheet, name, a1, b1, a2, b2 in designs:
    g = D[sheet][name]['groups']
    print(f'\n--- {sheet} | {name} | unit: {D[sheet][name].get("unit", "animal")}')
    describe(g)
    f, p = anova(g)
    print(f'     one-way ANOVA F={f:.3f} p={fmt_p(p)}')
    if all(min(g[k]) > 0 for k in (a1, b1, a2, b2)):
        r = twoway_log(g, a1, b1, a2, b2)
        print(f'     [log scale] creatine effect in {a1.split("-")[0]}: x{r["effect1"]:.2f} [{r["effect1_ci"][0]:.2f},{r["effect1_ci"][1]:.2f}] p={fmt_p(r["p1"])}; '
              f'in {a2.split("-")[0]}: x{r["effect2"]:.2f} [{r["effect2_ci"][0]:.2f},{r["effect2_ci"][1]:.2f}] p={fmt_p(r["p2"])}')
        print(f'     [log scale] INTERACTION (ratio of creatine effects, {a2.split("-")[0]} / {a1.split("-")[0]}) = {r["interaction"]:.2f} '
              f'[{r["inter_ci"][0]:.2f},{r["inter_ci"][1]:.2f}] p={fmt_p(r["p_inter"])} df={r["df"]}; attenuation of log-effect = {100*r["attenuation"]:.0f}%')
    rl = twoway_lin(g, a1, b1, a2, b2)
    print(f'     [linear] creatine effect {rl["eff1"]:.4g} vs {rl["eff2"]:.4g}; interaction {rl["inter"]:.4g} [{rl["inter_ci"][0]:.4g},{rl["inter_ci"][1]:.4g}] p={fmt_p(rl["p_inter"])}')
    # genotype effect at baseline
    r0 = two_group_tests(g[a1], g[a2])
    print(f'     baseline (vehicle) {a2} vs {a1}: means {r0["mean"][0]:.4g} vs {r0["mean"][1]:.4g}, Welch p={fmt_p(r0["welch_p"])}')
    tukey(g)

# --- three-group designs
for sheet, name in [('Fig. 6e', 'MK creatine (umol/g)'), ('Supp 2d', 'Metastatic burden (%)'), ('Supp 2d', 'Metastatic foci'),
                    ('Supp 7b', 'PLT'), ('Supp 7b', 'PCT')]:
    g = D[sheet][name]['groups']
    print(f'\n--- {sheet} | {name}')
    describe(g)
    f, p = anova(g)
    print(f'     one-way ANOVA F={f:.3f} p={fmt_p(p)}')
    tukey(g)
    keys = list(g.keys())
    if min(min(v) for v in g.values()) > 0:
        for i in range(1, len(keys)):
            gm, lo, hi, pl, *_ = ratio_ci(g[keys[0]], g[keys[i]])
            print(f'     GMR {keys[i]} / {keys[0]} = {gm:.2f} [{lo:.2f},{hi:.2f}] p={fmt_p(pl)}')
