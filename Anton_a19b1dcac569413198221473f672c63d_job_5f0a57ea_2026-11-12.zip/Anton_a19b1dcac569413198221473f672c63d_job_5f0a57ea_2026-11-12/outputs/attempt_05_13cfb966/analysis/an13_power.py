import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
from scipy import stats
# pooled within-group SD of log burden across the factorial Fig 3i
g = D['Fig. 3i']['Metastatic burden (%)']['groups']
res = sum(((np.log(v) - np.log(v).mean())**2).sum() for v in map(np.array, g.values())); df = sum(len(v) for v in g.values()) - 4
print('Fig 3i residual SD(log burden) =', round(np.sqrt(res/df), 3))
g = D['Fig. 3i']['Metastatic foci']['groups']
res = sum(((np.log(v) - np.log(v).mean())**2).sum() for v in map(np.array, g.values())); df = sum(len(v) for v in g.values()) - 4
print('Fig 3i residual SD(log foci) =', round(np.sqrt(res/df), 3))
# all vehicle & creatine groups across experiments -> distribution of SD(log burden)
sds = []
for sheet in ['Fig. 1b','Fig. 1k','Fig. 1f','Fig. 3i','Fig. 6b','Supplementary Fig  1e','Supplementary Fig  1f','Supplementary Fig  1g','Supplementary Fig  1i','Supplementary Fig  1k','Fig. 7g','Supp 2d']:
    for k, v in D[sheet]['Metastatic burden (%)']['groups'].items():
        sds.append(np.std(np.log(v), ddof=1))
sds = np.array(sds)
print('group SD(log burden): n groups', len(sds), 'median', np.median(sds).round(3), 'IQR', np.percentile(sds, [25, 75]).round(3), 'max', sds.max().round(3))

def n_interaction(delta, sigma, alpha=0.05, power=0.9):
    # per-cell n for 2x2 interaction contrast on log scale, iterate with t quantiles
    n = 4
    while True:
        df = 4*n - 4
        se = sigma*np.sqrt(4/n)
        ncp = abs(delta)/se
        tc = stats.t.ppf(1-alpha/2, df)
        pw = stats.nct.sf(tc, df, ncp) + stats.nct.cdf(-tc, df, ncp)
        if pw >= power: return n, pw
        n += 1
def n_two(delta, sigma, alpha=0.05, power=0.9):
    n = 3
    while True:
        df = 2*n - 2; se = sigma*np.sqrt(2/n); ncp = abs(delta)/se; tc = stats.t.ppf(1-alpha/2, df)
        pw = stats.nct.sf(tc, df, ncp) + stats.nct.cdf(-tc, df, ncp)
        if pw >= power: return n, pw
        n += 1
print('\nMouse 2x2 (genotype x creatine), interaction on log(burden): per-cell n')
for gmr in [3.2, 2.0, 1.6]:
    for frac in [1.0, 0.75]:
        delta = frac*np.log(gmr)
        for sigma in [0.36, 0.45, 0.55]:
            for pw in [0.8, 0.9]:
                n, p = n_interaction(delta, sigma, power=pw)
                print(f'  WT creatine GMR {gmr}, KO abolishes {int(frac*100)}% of log-effect, sigma {sigma}, power {pw}: n/cell={n}')
print('\nMouse two-arm (e.g., creatine vs control in WT; or transfer arms): per-group n')
for gmr in [3.2, 2.0, 1.6]:
    for sigma in [0.36, 0.45, 0.55]:
        n, p = n_two(np.log(gmr), sigma, power=0.9)
        print(f'  GMR {gmr}, sigma {sigma}: n/group={n} (90% power)')

# Human: SD of log2 fold-change at day 14 for EPI and collagen
H = D['Fig. 7c']['fold_change_wide']
print('\nHuman platelet function: observed mean and SD of log2(day14/day0) and log2(day7/day0)')
hum = {}
for k in ['EPI max', 'EPI avg', 'collagen max', 'collagen avg', 'ADP max', 'AA max']:
    M = np.array(H[k], float)
    for j, t in [(2, 7), (3, 14)]:
        x = np.log2(M[:, j]); hum[(k, t)] = (x.mean(), x.std(ddof=1))
        print(f'  {k:14s} day {t:2d}: mean log2FC {x.mean():+.2f} (x{2**x.mean():.2f}), SD {x.std(ddof=1):.2f}')
print('\nHuman parallel-group placebo-controlled RCT, primary = log2 change in EPI max aggregation at day 14')
for k in ['EPI max', 'collagen max']:
    m, s = hum[(k, 14)]
    for frac in [1.0, 0.5]:
        for pw in [0.8, 0.9]:
            n, p = n_two(frac*m, s, power=pw)
            print(f'  {k}: detect {int(frac*100)}% of observed effect (log2 {frac*m:.2f}), SD {s:.2f}, power {pw}: n/arm={n}')
# crossover approx: SD of within-subject difference ~ SD*sqrt(2*(1-rho)) ; assume rho 0.5 -> same SD
print('  (A 2-period crossover with washout would need roughly half as many participants if within-subject correlation is ~0.5.)')
