import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fig_forest_base.py')).read().split("# interaction panel")[0].split("import matplotlib.pyplot as plt")[1])
inter = [
 ('MK Slc6a8 KO\n(Fig 3i, n=4/cell)', 'Fig. 3i', 'WT-Vehicle', 'WT-Creatine', 'KO-Vehicle', 'KO-Creatine', 'Pf4-Cre;Slc6a8+/+', 'Pf4-Cre;Slc6a8 fl'),
 ('Tumour shSlc6a8\n(Fig 1f, n=6/cell)', 'Fig. 1f', 'shScr-Vehicle', 'shScr-Creatine', 'shSlc6a8-Vehicle', 'shSlc6a8-Creatine', 'sh-scrambled tumour', 'shSlc6a8 tumour'),
 ('STAT5 inhibitor\n(Fig 6b\u2020, n=5/cell)', 'Fig. 6b', 'Vehicle', 'Creatine', 'Vehicle+STAT5i', 'Creatine+STAT5i', 'no inhibitor', '+ STAT5-IN-1'),
]
fig = plt.figure(figsize=(14, 6.2))
ax = fig.add_axes([0.03, 0.11, 0.50, 0.78])
for i, (lab, (lo, hi), y, n) in enumerate(zip(labs, cis, ys, ns)):
    yy = k - i
    ax.plot([lo, hi], [yy, yy], color='k', lw=1.2)
    ax.plot(np.exp(y), yy, 's', color='#1f77b4', ms=6)
    ax.text(0.30, yy, f'{lab}  (n={n[0]}/{n[1]})', va='center', ha='left', fontsize=8.5)
    ax.text(11, yy, f'{np.exp(y):.2f} [{lo:.2f}, {hi:.2f}]', va='center', ha='left', fontsize=8)
ax.plot([np.exp(yr-1.96*ser), np.exp(yr+1.96*ser)], [0, 0], color='#d62728', lw=2)
ax.plot(np.exp(yr), 0, 'D', color='#d62728', ms=8)
ax.text(0.30, 0, 'Random-effects pooled (k=10)', va='center', fontsize=8.5, weight='bold')
ax.text(11, 0, f'{np.exp(yr):.2f} [{np.exp(yr-1.96*ser):.2f}, {np.exp(yr+1.96*ser):.2f}]', va='center', fontsize=8, weight='bold')
ax.axvline(1, color='grey', ls='--', lw=0.8)
ax.set_xscale('log'); ax.set_xlim(0.28, 30); ax.set_ylim(-1, k+1)
ax.set_xticks([1, 2, 4, 8]); ax.set_xticklabels(['1', '2', '4', '8'])
ax.set_yticks([]); ax.set_xlabel('Creatine vs control: ratio of geometric means (GMR), lung metastatic burden, 95% CI')
ax.set_title(f'A. Creatine effect on metastatic burden, all experiments (I\u00b2={100*max(0,(Q-(k-1))/Q):.0f}%; all unblinded)\n\u2020 Fig 6b: 3 animals per arm are identical to animals in Supp Fig 2d', fontsize=9.5)

ax = fig.add_axes([0.60, 0.11, 0.385, 0.78])
yy = 0; yt, ylab = [], []
for lab, sheet, a1, b1, a2, b2, c1, c2 in inter:
    g = D[sheet]['Metastatic burden (%)']['groups']
    r = twoway_log(g, a1, b1, a2, b2)
    for nm, e, ci, col in [(c1, r['effect1'], r['effect1_ci'], '#1f77b4'), (c2, r['effect2'], r['effect2_ci'], '#ff7f0e')]:
        ax.plot(ci, [yy, yy], color=col, lw=1.8); ax.plot(e, yy, 'o', color=col, ms=6)
        yt.append(yy); ylab.append(nm)
        yy -= 1
    ax.text(0.33, yy + 1.5, lab, fontsize=8.5, weight='bold', va='center', ha='left')
    ax.text(9.5, yy + 1.5, f'interaction\n{r["interaction"]:.2f} [{r["inter_ci"][0]:.2f}, {r["inter_ci"][1]:.2f}]\np={fmt_p(r["p_inter"])}', fontsize=8, va='center', ha='left', color='#333')
    yy -= 1.3
ax.axvline(1, color='grey', ls='--', lw=0.8)
ax.set_xscale("log"); ax.set_xlim(0.3, 30); ax.set_ylim(yy + 0.6, 0.9)
ax.set_yticks(yt); ax.set_yticklabels(ylab, fontsize=8)
ax.yaxis.tick_right(); ax.tick_params(axis='y', length=0, pad=-2)
for t in ax.get_yticklabels(): t.set_horizontalalignment('left'); t.set_x(0.0)
ax.set_yticks([])
for y_, l_ in zip(yt, ylab):
    ax.text(2.2, y_ + 0.28, l_, fontsize=7.5, color='#555', ha='center')
ax.set_xticks([0.5, 1, 2, 4, 8]); ax.set_xticklabels(['0.5', '1', '2', '4', '8'])
ax.set_xlabel('Creatine effect within each background (GMR, 95% CI)')
ax.set_title('B. Which perturbations remove the creatine effect?\n(2\u00d72 designs; interaction = ratio of creatine effects, log scale)', fontsize=9.5)
plt.savefig('/tmp/outputs/figures/Fig1_creatine_effect_forest.png', dpi=200)
