import json, numpy as np
from lifelines.statistics import logrank_test
from lifelines import CoxPHFitter, KaplanMeierFitter
import pandas as pd
D = json.load(open('/tmp/work/tidy.json'))
for sheet in ['Fig. 1c', 'Fig. 1l']:
    g = D[sheet]['Survival (d)']['groups']
    v, c = np.array(g['Vehicle']), np.array(g['Creatine'])
    lr = logrank_test(v, c, event_observed_A=np.ones_like(v), event_observed_B=np.ones_like(c))
    df = pd.DataFrame({'T': np.r_[v, c], 'E': 1, 'cre': np.r_[np.zeros(len(v)), np.ones(len(c))]})
    cph = CoxPHFitter().fit(df, 'T', 'E')
    hr = np.exp(cph.params_['cre']); ci = np.exp(cph.confidence_intervals_.loc['cre'].values)
    km_v = KaplanMeierFitter().fit(v); km_c = KaplanMeierFitter().fit(c)
    print(f"{sheet}: n={len(v)} vs {len(c)}; median survival vehicle {km_v.median_survival_time_} d vs creatine {km_c.median_survival_time_} d; "
          f"mean {v.mean():.1f} vs {c.mean():.1f}; log-rank chi2={lr.test_statistic:.3f} p={lr.p_value:.4f}; Cox HR (creatine vs vehicle)={hr:.2f} [{ci[0]:.2f},{ci[1]:.2f}] p={cph.summary.loc['cre','p']:.4f}; censored: none")
