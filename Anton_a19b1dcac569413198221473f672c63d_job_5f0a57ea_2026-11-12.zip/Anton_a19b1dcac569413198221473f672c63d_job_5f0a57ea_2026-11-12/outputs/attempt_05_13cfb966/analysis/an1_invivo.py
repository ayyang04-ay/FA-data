import sys
sys.path.insert(0, '/tmp/work')
from an_common import *

print('=' * 100)
print('A. TWO-GROUP IN VIVO / EX VIVO PANELS: recomputation (Student as reported, Welch, Mann-Whitney), ratio of geometric means (95% CI), Hedges g')
print('=' * 100)
panels = [
    ('Fig. 1a', 'Lung weight (g)'), ('Fig. 1a', 'SUV-BW'), ('Fig. 1b', 'Metastatic burden (%)'), ('Fig. 1b', 'Metastatic foci'),
    ('Fig. 1j', 'Lung weight (g)'), ('Fig. 1j', 'SUV-BW'), ('Fig. 1k', 'Metastatic burden (%)'), ('Fig. 1k', 'Metastatic foci'),
    ('Fig. 1i', 'GFP+ cells per field'),
    ('Fig. 2c', 'alpha-granules'), ('Fig. 2j', 'PKH positive area (%)'),
    ('Fig. 2b', 'Aggregation ADP (%)'), ('Fig. 2b', 'Aggregation Collagen (%)'), ('Fig. 2b', 'Aggregation Thrombin (%)'),
    ('Fig. 2a', 'PLT'), ('Fig. 2a', 'PCT'), ('Fig. 2a', 'PDW'), ('Fig. 2a', 'MPV'),
    ('Fig. 2d', 'TEG-R (min)'), ('Fig. 2d', 'TEG-K (min)'), ('Fig. 2d', 'TEG-alpha (deg)'), ('Fig. 2d', 'TEG-MA (mm)'),
    ('Fig. 7g', 'Lung weight (g)'), ('Fig. 7g', 'Metastatic burden (%)'), ('Fig. 7g', 'Metastatic foci'),
    ('Supplementary Fig  1b', 'Food intake (g/d)'), ('Supplementary Fig  1c', 'Water intake (g/d)'),
    ('Supplementary Fig  1d', 'Serum creatine (uM)'), ('Supplementary Fig  1h', 'Serum creatine (uM)'),
    ('Supplementary Fig  1e', 'Lung weight (g)'), ('Supplementary Fig  1e', 'Metastatic burden (%)'), ('Supplementary Fig  1e', 'Metastatic foci'),
    ('Supplementary Fig  1f', 'Lung weight (g)'), ('Supplementary Fig  1f', 'Metastatic burden (%)'), ('Supplementary Fig  1f', 'Metastatic foci'),
    ('Supplementary Fig  1g', 'Lung weight (g)'), ('Supplementary Fig  1g', 'Metastatic burden (%)'), ('Supplementary Fig  1g', 'Metastatic foci'),
    ('Supplementary Fig  1i', 'Lung weight (g)'), ('Supplementary Fig  1i', 'Metastatic burden (%)'), ('Supplementary Fig  1i', 'Metastatic foci'),
    ('Supplementary Fig  1k', 'Lung weight (g)'), ('Supplementary Fig  1k', 'Metastatic burden (%)'), ('Supplementary Fig  1k', 'Metastatic foci'),
    ('Supp 3a', 'WBC'), ('Supp 3a', 'Lymphocyte'), ('Supp 3a', 'Monocyte'), ('Supp 3a', 'RBC'),
    ('Fig. 4a', None), ('Fig. 4c', None), ('Fig. 4d', None), ('Fig. 4f', None),
]
rows = []
for sheet, name in panels:
    block = D[sheet]
    if name is None:
        name = list(block.keys())[0]
    g = block[name]['groups']
    keys = list(g.keys())
    pairs = [(keys[0], keys[1])] if len(keys) == 2 else [(keys[0], keys[1]), (keys[2], keys[3])]
    for ka, kb in pairs:
        a, b = g[ka], g[kb]
        r = two_group_tests(a, b)
        if min(a) > 0 and min(b) > 0:
            gm, lo, hi, pl, *_ = ratio_ci(a, b)
        else:
            gm = lo = hi = pl = float('nan')
        unit = block[name].get('unit', '')
        print(f"{sheet:22s} | {name[:28]:28s} | {kb[:18]:>18s} vs {ka[:18]:<18s} | n={r['n']} | means {r['mean'][0]:.4g} -> {r['mean'][1]:.4g} | "
              f"GMR {gm:.2f} [{lo:.2f},{hi:.2f}] | g={r['g']:.2f} | Student p={fmt_p(r['student_p'])} (t={r['student_t']:.3f}) Welch p={fmt_p(r['welch_p'])} MW p={fmt_p(r['mw_p'])} | unit: {unit}")
