"""Minimal Markdown -> PDF renderer (reportlab) for the CRE-MK-01 proposal.
Run: mm chem python /tmp/outputs/analysis/md_to_pdf.py
"""
import re, os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak,
                                KeepTogether, HRFlowable, ListFlowable, ListItem)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping

FD = '/opt/conda/envs/chem/lib/python3.11/site-packages/matplotlib/mpl-data/fonts/ttf/'
pdfmetrics.registerFont(TTFont('DV', FD + 'DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DV-B', FD + 'DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DV-I', FD + 'DejaVuSans-Oblique.ttf'))
pdfmetrics.registerFont(TTFont('DV-BI', FD + 'DejaVuSans-BoldOblique.ttf'))
pdfmetrics.registerFont(TTFont('DVM', FD + 'DejaVuSansMono.ttf'))
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DV-B'); addMapping('DV', 0, 1, 'DV-I'); addMapping('DV', 1, 1, 'DV-BI')

BASE = '/tmp/outputs/'
SRC = BASE + 'CRE-MK-01_validation_proposal.md'
OUT = BASE + 'CRE-MK-01_validation_proposal.pdf'

body = ParagraphStyle('body', fontName='DV', fontSize=8.8, leading=11.6, spaceAfter=4, alignment=TA_LEFT)
small = ParagraphStyle('small', parent=body, fontSize=7.2, leading=8.8, spaceAfter=0)
smallb = ParagraphStyle('smallb', parent=small, fontName='DV-B')
cap = ParagraphStyle('cap', parent=body, fontName='DV-I', fontSize=7.6, leading=9.4, textColor=colors.HexColor('#333333'), spaceAfter=8)
h1 = ParagraphStyle('h1', parent=body, fontName='DV-B', fontSize=14, leading=17, spaceBefore=4, spaceAfter=6, textColor=colors.HexColor('#0b3d63'))
h2 = ParagraphStyle('h2', parent=body, fontName='DV-B', fontSize=11.5, leading=14, spaceBefore=8, spaceAfter=4, textColor=colors.HexColor('#0b3d63'))
h3 = ParagraphStyle('h3', parent=body, fontName='DV-B', fontSize=9.8, leading=12.5, spaceBefore=6, spaceAfter=3, textColor=colors.HexColor('#1f4e79'))
rec = ParagraphStyle('rec', parent=body, fontName='DV', fontSize=9.6, leading=12.6, textColor=colors.black, backColor=colors.HexColor('#e8f1fb'),
                     borderColor=colors.HexColor('#0b3d63'), borderWidth=1, borderPadding=6, spaceAfter=10)
bul = ParagraphStyle('bul', parent=body, spaceAfter=2, bulletFontName='DV')


def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'`([^`]+)`', r'<font face="DVM" size="7.6">\1</font>', t)
    t = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\w*])\*([^*\n]+?)\*(?![\w*])', r'<i>\1</i>', t)
    return t


def make_table(rows, width):
    header = [c.strip() for c in rows[0].strip().strip('|').split('|')]
    data = []
    for r in rows[2:]:
        cells = [c.strip() for c in r.strip().strip('|').split('|')]
        data.append(cells)
    ncol = len(header)
    fs = 7.2 if ncol < 6 else 6.6
    st_b = ParagraphStyle('tb', parent=smallb, fontSize=fs, leading=fs * 1.22)
    st_s = ParagraphStyle('ts', parent=small, fontSize=fs, leading=fs * 1.22)
    strip = lambda x: re.sub(r'[*`]', '', x)
    # column widths: total content length (damped) with a floor set by the longest unbreakable word
    lens = [max([len(strip(header[i]))] + [len(strip(d[i])) if i < len(d) else 0 for d in data]) for i in range(ncol)]
    words = [max([len(w_) for cell in [header[i]] + [d[i] if i < len(d) else '' for d in data] for w_ in strip(cell).split()] + [3]) for i in range(ncol)]
    minw = [wl * fs * 0.62 + 8 for wl in words]
    w = [max(4, l) ** 0.6 for l in lens]
    colw = [width * x / sum(w) for x in w]
    for _ in range(20):
        short = [i for i in range(ncol) if colw[i] < minw[i]]
        if not short:
            break
        for i in short:
            colw[i] = minw[i]
        fixed = sum(colw[i] for i in short)
        free = [i for i in range(ncol) if i not in short]
        rem = width - sum(colw[i] for i in short if i in short) - 0
        rem = width - sum(colw[i] for i in range(ncol) if i in short)
        tw = sum(w[i] for i in free)
        for i in free:
            colw[i] = rem * w[i] / tw
    tbl = [[Paragraph(inline(h), st_b) for h in header]]
    for d in data:
        d = d + [''] * (ncol - len(d))
        tbl.append([Paragraph(inline(c), st_s) for c in d])
    t = Table(tbl, colWidths=colw, repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#dbe7f3')),
        ('GRID', (0, 0), (-1, -1), 0.3, colors.HexColor('#9aa9b8')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
        ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f6f8fa')]),
    ]))
    return t


def build():
    lines = open(SRC, encoding='utf-8').read().split('\n')
    doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=1.7 * cm, rightMargin=1.7 * cm, topMargin=1.5 * cm, bottomMargin=1.5 * cm,
                            title='CRE-MK-01 validation proposal', author='CRE-MK-01 analysis')
    W = A4[0] - 3.4 * cm
    story = []
    i = 0
    first = True
    para = []

    def flush():
        nonlocal para
        if para:
            story.append(Paragraph(inline(' '.join(para)), body))
            para = []

    while i < len(lines):
        ln = lines[i]
        s = ln.rstrip()
        if first and s.strip():
            story.append(Paragraph(inline(s), rec))
            first = False
            i += 1
            continue
        if not s.strip():
            flush(); i += 1; continue
        if s.startswith('# '):
            flush(); story.append(Paragraph(inline(s[2:]), h1)); i += 1; continue
        if s.startswith('## '):
            flush(); story.append(Paragraph(inline(s[3:]), h2)); i += 1; continue
        if s.startswith('### '):
            flush(); story.append(Paragraph(inline(s[4:]), h3)); i += 1; continue
        if s.strip() == '---':
            flush(); story.append(HRFlowable(width='100%', thickness=0.6, color=colors.HexColor('#9aa9b8'), spaceBefore=4, spaceAfter=6)); i += 1; continue
        m = re.match(r'!\[(.*)\]\((.*)\)', s.strip())
        if m:
            flush()
            path = os.path.join(BASE, m.group(2))
            from PIL import Image as PILImage
            iw, ih = PILImage.open(path).size
            w = W; h = W * ih / iw
            if h > 15.5 * cm:
                h = 15.5 * cm; w = h * iw / ih
            story.append(KeepTogether([Image(path, width=w, height=h), Paragraph(inline(m.group(1)), cap)]))
            i += 1; continue
        if s.lstrip().startswith('|'):
            flush()
            rows = []
            while i < len(lines) and lines[i].lstrip().startswith('|'):
                rows.append(lines[i]); i += 1
            story.append(make_table(rows, W)); story.append(Spacer(1, 6))
            continue
        mb = re.match(r'^(\s*)([-*]|\d+\.)\s+(.*)', s)
        if mb:
            flush()
            items = []
            while i < len(lines):
                mm_ = re.match(r'^(\s*)([-*]|\d+\.)\s+(.*)', lines[i].rstrip())
                if not mm_:
                    # continuation line of previous item
                    if lines[i].strip() and not lines[i].lstrip().startswith(('|', '#', '!')) and items:
                        items[-1][2] += ' ' + lines[i].strip(); i += 1; continue
                    break
                level = len(mm_.group(1)) // 2
                items.append([level, mm_.group(2), mm_.group(3)])
                i += 1
            for level, marker, text in items:
                bullet = '•' if marker in '-*' else marker
                if level >= 1:
                    bullet = '–' if marker in '-*' else marker
                st = ParagraphStyle('b%d' % level, parent=bul, leftIndent=12 + 12 * level, bulletIndent=2 + 12 * level)
                story.append(Paragraph(inline(text), st, bulletText=bullet))
            story.append(Spacer(1, 3))
            continue
        para.append(s.strip())
        i += 1
    flush()

    def footer(canvas, doc_):
        canvas.saveState()
        canvas.setFont('DV', 7)
        canvas.setFillColor(colors.HexColor('#666666'))
        canvas.drawString(1.7 * cm, 0.9 * cm, 'CRE-MK-01 follow-up validation proposal - statistics re-derived from the source workbook')
        canvas.drawRightString(A4[0] - 1.7 * cm, 0.9 * cm, 'p. %d' % doc_.page)
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    print('wrote', OUT)


if __name__ == '__main__':
    build()
