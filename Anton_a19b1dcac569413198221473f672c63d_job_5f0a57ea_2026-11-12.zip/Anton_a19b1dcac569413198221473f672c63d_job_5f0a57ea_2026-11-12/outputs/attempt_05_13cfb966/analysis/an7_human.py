import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
from statsmodels.stats.multitest import multipletests
import warnings; warnings.filterwarnings('ignore')
print('=== Fig 7b serum creatine (n=11 volunteers, paired) ===')
W = np.array(D['Fig. 7b']['Serum creatine (uM)']['wide'])
print('means by day 0/3/7/14:', np.round(W.mean(0),1), 'SD', np.round(W.std(0,ddof=1),1))
for j,t in enumerate([3,7,14],1):
    r = np.log(W[:,j]/W[:,0])
    tt = stats.ttest_1samp(r,0)
    print(f'  day {t} vs 0: GMR {np.exp(r.mean()):.2f} [{np.exp(r.mean()-stats.t.ppf(.975,10)*r.std(ddof=1)/np.sqrt(11)):.2f},{np.exp(r.mean()+stats.t.ppf(.975,10)*r.std(ddof=1)/np.sqrt(11)):.2f}] paired p={tt.pvalue:.2e}; min fold {np.exp(r.min()):.2f}')

print('\n=== Fig 7c platelet function, fold-change vs day 0 (n=11), re-analysed on log2 scale with paired one-sample tests + BH-FDR over 36 tests ===')
H = D['Fig. 7c']['fold_change_wide']
rows = []
for k, M in H.items():
    M = np.array(M, float)
    for j, t in enumerate([3, 7, 14], 1):
        x = M[:, j]
        nz = x > 0
        lx = np.log2(x[nz])
        tt = stats.ttest_1samp(lx, 0)
        w = stats.wilcoxon(x - 1)
        up = (x > 1).sum()
        rows.append((k, t, np.median(x), 2**lx.mean(), tt.pvalue, w.pvalue, up, len(x), (~nz).sum()))
ps_t = np.array([r[4] for r in rows]); ps_w = np.array([r[5] for r in rows])
q_t = multipletests(ps_t, method='fdr_bh')[1]; q_w = multipletests(ps_w, method='fdr_bh')[1]
print(f"{'readout':22s} day  median  geomean  p(t,log)  q(BH)   p(Wilcoxon) q(BH)  #up/11  zeros")
for r, qt, qw in zip(rows, q_t, q_w):
    print(f'{r[0]:22s} {r[1]:3d}  {r[2]:6.2f}  {r[3]:7.2f}  {r[4]:8.4f}  {qt:6.3f}   {r[5]:8.4f}  {qw:6.3f}   {r[6]:2d}/{r[7]}   {r[8]}')
print('  Original analysis: ordinary one-way ANOVA + Dunnett on fold-changes (day-0 column fixed at 1, zero variance; repeated measures ignored)')

print('\n=== Fig 7e platelet protein (densitometry ratio to ACTB), n=4 volunteers, repeated measures ===')
for k in ['GP6/ACTB', 'P2RY12/ACTB']:
    M = np.array(D['Fig. 7e'][k], float)
    print(k, 'rows (volunteer x day0/3/7/14):', M.round(3).tolist())
    for j, t in enumerate([3, 7, 14], 1):
        r = np.log2(M[:, j] / M[:, 0])
        tt = stats.ttest_1samp(r, 0)
        print(f'   day {t}: fold per volunteer {np.round(2**r,2).tolist()} geo-mean {2**r.mean():.2f}, paired t p={tt.pvalue:.3f}, #up {(r>0).sum()}/4')
    # RM ANOVA
    import pandas as pd
    from statsmodels.stats.anova import AnovaRM
    df = pd.DataFrame([(i, t, np.log2(M[i, j])) for i in range(4) for j, t in enumerate([0, 3, 7, 14])], columns=['subj', 'day', 'y'])
    print('   RM-ANOVA (log2):', AnovaRM(df, 'y', 'subj', within=['day']).fit().anova_table.round(4).to_dict('records'))
    f, p = stats.f_oneway(*[M[:, j] for j in range(4)])
    print(f'   ordinary one-way ANOVA as in sheet (ignores pairing): F={f:.2f} p={p:.4f}')

print('\n=== Supp 8b human CBC (n=11), paired ===')
for k, M in D['Supp 8b'].items():
    M = np.array(M, float)
    print(f'  {k}: means {np.round(M.mean(0),3).tolist()}; day14-day0 paired p={stats.ttest_rel(M[:,3],M[:,0]).pvalue:.3f}')
print('\n=== Supp 8a BMI paired ===')
b = D['Supp 8a']['BMI']; print('  paired p=', stats.ttest_rel(b['d14'], b['d0']).pvalue, ' (sheet used unpaired t, df=20, p=0.93); mean', np.mean(b['d0']).round(2), '->', np.mean(b['d14']).round(2))
