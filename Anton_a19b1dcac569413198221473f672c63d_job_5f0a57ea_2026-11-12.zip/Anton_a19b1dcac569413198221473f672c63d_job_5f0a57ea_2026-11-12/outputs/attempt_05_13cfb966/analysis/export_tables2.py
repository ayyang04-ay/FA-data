import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
import pandas as pd
OUT = '/tmp/outputs/tables/'
# T3 meta
studies = [('Fig 1b','Fig. 1b','Vehicle','Creatine'),('Fig 1k','Fig. 1k','Vehicle','Creatine'),('Fig 1f sh-scr tumour arm','Fig. 1f','shScr-Vehicle','shScr-Creatine'),
 ('Fig 3i Pf4-Cre;Slc6a8+/+ arm','Fig. 3i','WT-Vehicle','WT-Creatine'),('Fig 6b no-inhibitor arm (3/5 animals per arm duplicated in Supp 2d)','Fig. 6b','Vehicle','Creatine'),
 ('Supp 1e','Supplementary Fig  1e','Vehicle','Creatine'),('Supp 1f','Supplementary Fig  1f','Vehicle','Creatine'),('Supp 1g','Supplementary Fig  1g','Vehicle','Creatine'),
 ('Supp 1i (5% creatine diet)','Supplementary Fig  1i','Control diet','Creatine diet'),('Supp 1k','Supplementary Fig  1k','Vehicle','Creatine')]
rows = []
for ep in ['Metastatic burden (%)', 'Metastatic foci', 'Lung weight (g)']:
    ys, vs = [], []
    for lab, sheet, a, b in studies:
        if ep not in D[sheet]: continue
        g = D[sheet][ep]['groups']; gm, lo, hi, p, diff, se, df = ratio_ci(g[a], g[b])
        ys.append(diff); vs.append(se**2)
        rows.append(dict(endpoint=ep, experiment=lab, n_ctrl=len(g[a]), n_creatine=len(g[b]), GMR=gm, lo95=lo, hi95=hi, welch_log_p=p))
    ys, vs = np.array(ys), np.array(vs); w = 1/vs; yf = (w*ys).sum()/w.sum(); Q = (w*(ys-yf)**2).sum(); k = len(ys)
    C = w.sum() - (w**2).sum()/w.sum(); tau2 = max(0, (Q-(k-1))/C); ws = 1/(vs+tau2); yr = (ws*ys).sum()/ws.sum(); se = (1/ws.sum())**0.5
    rows.append(dict(endpoint=ep, experiment=f'RANDOM-EFFECTS POOLED (k={k}); I2={100*max(0,(Q-(k-1))/Q):.0f}%', GMR=np.exp(yr), lo95=np.exp(yr-1.96*se), hi95=np.exp(yr+1.96*se)))
pd.DataFrame(rows).to_csv(OUT + 'T3_creatine_effect_meta_analysis.csv', index=False, float_format='%.4g')
# T5 human qPCR
H = D['qPCR']['Fig. 7d']; rows = []
for gene, vols in H.items():
    for t in ['3d', '7d', '14d']:
        lf = []
        for v in ['V1', 'V2', 'V3', 'V4']:
            d0 = np.mean([float(x) for x in vols[v]['0d']]); dt = np.mean([float(x) for x in vols[v][t]]); lf.append(dt - d0)
        lf = np.array(lf)
        rows.append(dict(gene=('ADRA2A (labelled ADAR2A in sheet)' if gene == 'ADAR2A' else gene), day=t, fold_V1=2**lf[0], fold_V2=2**lf[1], fold_V3=2**lf[2], fold_V4=2**lf[3],
                         n_up=int((lf > 0).sum()), geomean_fold=2**lf.mean(), paired_t_p_unadjusted=stats.ttest_1samp(lf, 0).pvalue,
                         note=('V4 values are raw-Ct-like (+26 to +28); not interpretable' if gene == 'PITPNB' else ('V4 sheet-plotted values not reproducible from recorded dCT' if gene == 'RAB27B' else ''))))
pd.DataFrame(rows).to_csv(OUT + 'T5_human_CD41_qPCR_reanalysis.csv', index=False, float_format='%.4g')
# T8 power
def n_inter(delta, sigma, alpha=0.05, power=0.9):
    n = 4
    while True:
        df = 4*n-4; ncp = abs(delta)/(sigma*np.sqrt(4/n)); tc = stats.t.ppf(1-alpha/2, df)
        if stats.nct.sf(tc, df, ncp) + stats.nct.cdf(-tc, df, ncp) >= power: return n
        n += 1
def power_inter(n, delta, sigma, alpha=0.05):
    df = 4*n-4; ncp = abs(delta)/(sigma*np.sqrt(4/n)); tc = stats.t.ppf(1-alpha/2, df)
    return stats.nct.sf(tc, df, ncp) + stats.nct.cdf(-tc, df, ncp)
rows = []
for gmr in [3.2, 2.0, 1.6]:
    for frac in [1.0, 0.75]:
        for sigma in [0.33, 0.45, 0.55]:
            rows.append(dict(design='2x2 genotype(or blocker) x creatine; interaction on log(burden)', true_WT_creatine_GMR=gmr, fraction_of_log_effect_removed=frac, sigma_log=sigma,
                             n_per_cell_80pct=n_inter(frac*np.log(gmr), sigma, power=0.8), n_per_cell_90pct=n_inter(frac*np.log(gmr), sigma, power=0.9),
                             power_at_15_per_cell=power_inter(15, frac*np.log(gmr), sigma), power_at_30_per_cell_two_models_pooled=power_inter(30, frac*np.log(gmr), sigma)))
pd.DataFrame(rows).to_csv(OUT + 'T8_power_in_vivo_slot.csv', index=False, float_format='%.3g')
print(pd.DataFrame(rows).round(2).to_string())
