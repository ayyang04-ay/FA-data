import sys; sys.path.insert(0,'/tmp/work')
from an_common import *
print('=== Fig 1h lung tumour-cell signal time course (n=6/6) ===')
tc = D['Fig. 1h']['timecourse']
for t, g in tc.items():
    r = two_group_tests(g['Vehicle'], g['Creatine'])
    gm, lo, hi, p, *_ = ratio_ci(g['Vehicle'], g['Creatine'])
    print(f'  {t:>5s} h: vehicle {np.mean(g["Vehicle"]):.2f}  creatine {np.mean(g["Creatine"]):.2f}  GMR {gm:.2f} [{lo:.2f},{hi:.2f}] Student p={fmt_p(r["student_p"])} Welch p={fmt_p(r["welch_p"])}')
# retention fraction relative to 0.25h per group
v0 = np.mean(tc['0.25']['Vehicle']); c0 = np.mean(tc['0.25']['Creatine'])
for t in ['6','12','24']:
    print(f'  retention at {t} h as % of 0.25 h: vehicle {100*np.mean(tc[t]["Vehicle"])/v0:.1f}%  creatine {100*np.mean(tc[t]["Creatine"])/c0:.1f}%')

print('\n=== Fig 2b / Fig 3d aggregation triplicates: structure check ===')
def midpoint_pattern(tri):
    a, b, c = tri
    return c == (a + b) / 2
for sheet in ['Fig. 2b', 'Fig. 3d']:
    for name, blk in D[sheet].items():
        for grp, vals in blk['groups'].items():
            vals = [int(x) for x in vals]
            mid3 = midpoint_pattern(vals)
            anymid = any(sorted(vals)[1] == (sorted(vals)[0] + sorted(vals)[2]) / 2 for _ in [0])
            print(f'  {sheet} {name:26s} {grp:12s} {vals}  3rd=mean(1st,2nd): {mid3}  median=mean(min,max): {anymid}  SD={np.std(vals, ddof=1):.2f}  CV={np.std(vals, ddof=1)/np.mean(vals)*100:.1f}%')
# simulation: probability that in 6 triplicates the third value equals the mean of the first two, for integer readings with realistic SD
rng = np.random.default_rng(1)
def sim(sd, mean=50, nsim=200000):
    x = np.rint(rng.normal(mean, sd, size=(nsim, 3)))
    return np.mean(x[:, 2] == (x[:, 0] + x[:, 1]) / 2), np.mean(np.sort(x, 1)[:, 1] == (np.sort(x, 1)[:, 0] + np.sort(x, 1)[:, 2]) / 2)
for sd in [1, 2, 3, 5]:
    p3, pm = sim(sd)
    print(f'  sim SD={sd}: P(3rd = mean of first two) per triplicate = {p3:.3f} -> all 6 = {p3**6:.1e}; P(median = midrange) = {pm:.3f} -> all 6 = {pm**6:.1e}')
