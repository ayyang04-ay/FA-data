import numpy as np, re, pandas as pd
from scipy import stats
from data import *
rows=[]
for sheet, ep, cr, tr, pref, tref in TWO_GROUP:
    a = rng(sheet, cr); b = rng(sheet, tr)
    rp = val(sheet, pref); rt = val(sheet, tref)
    t, p = stats.ttest_ind(b, a)  # Student (equal var) as in Prism default
    tw, pw = stats.ttest_ind(b, a, equal_var=False)
    # reported t, df
    m = re.search(r't=([\d.]+), df=(\d+)', str(rt)) if rt else None
    rep_t = float(m.group(1)) if m else np.nan; rep_df = int(m.group(2)) if m else np.nan
    # Hedges g
    n1,n2=len(a),len(b); sp=np.sqrt(((n1-1)*a.var(ddof=1)+(n2-1)*b.var(ddof=1))/(n1+n2-2))
    d=(b.mean()-a.mean())/sp if sp>0 else np.nan; g=d*(1-3/(4*(n1+n2)-9))
    # Mann-Whitney
    try: pmw = stats.mannwhitneyu(b,a,alternative='two-sided').pvalue
    except Exception: pmw=np.nan
    rows.append(dict(sheet=sheet, endpoint=ep, n_ctrl=n1, n_trt=n2, mean_ctrl=a.mean(), mean_trt=b.mean(),
                     ratio=b.mean()/a.mean() if a.mean()!=0 else np.nan, hedges_g=g,
                     t_recalc=abs(t), df_recalc=n1+n2-2, p_student=p, p_welch=pw, p_MW=pmw,
                     t_reported=rep_t, df_reported=rep_df, p_reported=rp))
df = pd.DataFrame(rows)
df['p_reported_num']=pd.to_numeric(df.p_reported, errors='coerce')
df['t_match'] = np.isclose(df.t_recalc, df.t_reported, rtol=0.01, atol=0.01)
df['df_match'] = df.df_recalc==df.df_reported
pd.set_option('display.width',250); pd.set_option('display.max_columns',30)
print(df[['sheet','endpoint','n_ctrl','n_trt','mean_ctrl','mean_trt','ratio','hedges_g','t_recalc','t_reported','df_recalc','df_reported','p_student','p_reported','p_welch','p_MW','t_match']].to_string(float_format=lambda x: f'{x:.4g}'))
df.to_csv('/tmp/work/analysis/two_group_recalc.csv', index=False)
print("\nMISMATCHES (t or df):")
print(df[~(df.t_match & df.df_match)][['sheet','endpoint','t_recalc','t_reported','df_recalc','df_reported','p_student','p_reported']].to_string())
