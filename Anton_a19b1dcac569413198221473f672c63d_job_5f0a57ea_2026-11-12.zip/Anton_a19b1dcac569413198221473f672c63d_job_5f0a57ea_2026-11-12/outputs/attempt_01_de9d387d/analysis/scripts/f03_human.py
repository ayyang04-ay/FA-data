import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from data import rng
from scipy import stats
from statsmodels.stats.multitest import multipletests
blocks = [('collagen','max agg',4),('collagen','avg agg',18),('collagen','adhesion',32),
          ('EPI','max agg',46),('EPI','avg agg',60),('EPI','adhesion',74),
          ('AA','max agg',88),('AA','avg agg',102),('AA','adhesion',116),
          ('ADP','max agg',130),('ADP','avg agg',144),('ADP','adhesion',157)]
fig, axes = plt.subplots(1,4, figsize=(15,5.2), sharey=True)
cols = {'d3':'#9ecae1','d7':'#4292c6','d14':'#08306b'}
pw = []
for ag,met,r0 in blocks:
    E = rng('Fig. 7c', f'E{r0}:E{r0+10}'); pw.append(stats.wilcoxon(E-1).pvalue)
ph = multipletests(pw, method='holm')[1]
k=0
for ai, ag in enumerate(['EPI','collagen','AA','ADP']):
    ax = axes[ai]
    sub = [(b, i) for i,b in enumerate(blocks) if b[0]==ag]
    for j,((a,met,r0),idx) in enumerate(sub):
        for t,(col,tp) in enumerate([('C','d3'),('D','d7'),('E','d14')]):
            x = rng('Fig. 7c', f'{col}{r0}:{col}{r0+10}'); lx = np.log2(np.clip(x, 0.05, None))
            xpos = j*4 + t + np.random.default_rng(j*10+t).uniform(-0.18,0.18,len(lx))
            ax.scatter(xpos, lx, s=14, color=cols[tp], alpha=0.85, label=tp if (j==0 and ai==0) else None)
            ax.plot([j*4+t-0.3, j*4+t+0.3],[np.median(lx)]*2, color='k', lw=1.5)
        ax.text(j*4+1, 4.3, f'd14 Holm\np={ph[idx]:.2g}', ha='center', fontsize=7.5, color='crimson' if ph[idx]<0.05 else 'dimgray')
    ax.axhline(0, color='grey', ls=':')
    ax.set_xticks([1,5,9]); ax.set_xticklabels(['max agg','avg agg','adhesion'], fontsize=9)
    ax.set_title({'EPI':'Epinephrine (α2A; ADRA2A)','collagen':'Collagen (GPVI; GP6)','AA':'Arachidonic acid (COX-1/TXA2)','ADP':'ADP (P2Y1/P2Y12)'}[ag], fontsize=10)
    ax.set_ylim(-4.8, 5.2); ax.set_xlim(-0.8, 10.8)
axes[0].set_ylabel('log2 fold-change vs day 0 (per volunteer)')
axes[0].legend(title='day', fontsize=8, loc='lower left')
fig.suptitle('Human cohort (Fig. 7c, n=11): platelet responses after 20 g/day creatine, re-analysed as paired data\nHolm-adjusted Wilcoxon signed-rank (day 14 vs baseline, 12 endpoints); bars = medians. Receptor labels are the conventional agonist mapping (no receptor-blockade controls in package)', fontsize=10)
plt.tight_layout(rect=[0,0,1,0.92]); plt.savefig('/tmp/outputs/figures/P3_human_platelet_function.png', dpi=200)
print('ok', np.round(ph,3))
