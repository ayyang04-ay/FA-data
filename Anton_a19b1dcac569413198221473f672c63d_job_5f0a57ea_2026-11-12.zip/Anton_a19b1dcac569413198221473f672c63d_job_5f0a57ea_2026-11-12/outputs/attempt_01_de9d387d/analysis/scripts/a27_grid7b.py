import numpy as np
from data import rng
for cols in ['B','CDE','BCDE']:
    x = np.sort(np.concatenate([rng('Fig. 7b', f'{c}4:{c}14') for c in cols]))
    best=None
    for step in np.linspace(0.34,0.37,30001):
        r = (x - x[0])/step; err = np.abs(r-np.round(r)).max()
        if best is None or err<best[1]: best=(step,err)
    print(cols, 'n=',len(x), 'best step %.5f'%best[0], 'max residual (fraction of step) %.3f'%best[1])
