import numpy as np, pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
from data import rng
# interaction table
def twoway(sheet, refs, label, f0, f1, log=True):
    rows=[]
    for (a,b), r in zip([(0,0),(0,1),(1,0),(1,1)], refs):
        for y in rng(sheet, r): rows.append(dict(A=a, cre=b, y=y))
    d = pd.DataFrame(rows); d['ly'] = np.log(d.y)
    m = smf.ols('ly ~ A*cre', data=d).fit()
    L = np.zeros(len(m.params)); L[list(m.params.index).index('cre')]=1; L[list(m.params.index).index('A:cre')]=1
    t = m.t_test(L)
    return dict(panel=label, stratum0=f0, stratum1=f1, n_per_group=len(rng(sheet, refs[0])),
                creatine_effect_stratum0=np.exp(m.params['cre']), ci0_lo=np.exp(m.conf_int().loc['cre'][0]), ci0_hi=np.exp(m.conf_int().loc['cre'][1]), p0=m.pvalues['cre'],
                creatine_effect_stratum1=np.exp(float(t.effect[0])), ci1_lo=np.exp(t.conf_int()[0][0]), ci1_hi=np.exp(t.conf_int()[0][1]), p1=float(t.pvalue),
                ratio_of_ratios=np.exp(m.params['A:cre']), rr_lo=np.exp(m.conf_int().loc['A:cre'][0]), rr_hi=np.exp(m.conf_int().loc['A:cre'][1]), p_interaction=m.pvalues['A:cre'], resid_sd_log=np.sqrt(m.scale))
rows = [
 twoway('Fig. 1f', ['B22:B27','C22:C27','D22:D27','E22:E27'], 'Fig.1f metastatic burden', 'tumour sh-scrambled','tumour sh-Slc6a8'),
 twoway('Fig. 1f', ['B31:B36','C31:C36','D31:D36','E31:E36'], 'Fig.1f foci', 'tumour sh-scrambled','tumour sh-Slc6a8'),
 twoway('Fig. 3i', ['B10:B13','C10:C13','D10:D13','E10:E13'], 'Fig.3i metastatic burden', 'Pf4-Cre;Slc6a8+/+','Pf4-Cre;Slc6a8fl/fl'),
 twoway('Fig. 3i', ['B17:B20','C17:C20','D17:D20','E17:E20'], 'Fig.3i foci', 'Pf4-Cre;Slc6a8+/+','Pf4-Cre;Slc6a8fl/fl'),
 twoway('Fig. 3i', ['B3:B6','C3:C6','D3:D6','E3:E6'], 'Fig.3i lung weight', 'Pf4-Cre;Slc6a8+/+','Pf4-Cre;Slc6a8fl/fl'),
 twoway('Fig. 3b', ['B4:F4','G4:K4','B5:F5','G5:K5'], 'Fig.3b serum creatine', 'Pf4-Cre;Slc6a8+/+','Pf4-Cre;Slc6a8fl/fl'),
 twoway('Fig. 3c', ['B4:D4','E4:G4','B5:D5','E5:G5'], 'Fig.3c MK creatine', 'Pf4-Cre;Slc6a8+/+','Pf4-Cre;Slc6a8fl/fl'),
 twoway('Fig. 3d', ['B4:D4','E4:G4','H4:J4','K4:M4'], 'Fig.3d ADP aggregation [integrity flag]', 'Pf4-Cre;Slc6a8+/+','Pf4-Cre;Slc6a8fl/fl'),
 twoway('Fig. 3d', ['B5:D5','E5:G5','H5:J5','K5:M5'], 'Fig.3d collagen aggregation [integrity flag]', 'Pf4-Cre;Slc6a8+/+','Pf4-Cre;Slc6a8fl/fl'),
 twoway('Fig. 3d', ['B6:D6','E6:G6','H6:J6','K6:M6'], 'Fig.3d thrombin aggregation [integrity flag]', 'Pf4-Cre;Slc6a8+/+','Pf4-Cre;Slc6a8fl/fl'),
 twoway('Fig. 6b', ['B4:B8','C4:C8','D4:D8','E4:E8'], 'Fig.6b metastatic burden [shares animals with S2d]', 'DMSO','STAT5-IN-1'),
 twoway('Fig. 6b', ['B13:B17','C13:C17','D13:D17','E13:E17'], 'Fig.6b foci [shares animals with S2d]', 'DMSO','STAT5-IN-1'),
]
pd.DataFrame(rows).to_csv('/tmp/outputs/analysis/T3_interaction_models.csv', index=False)
# phospho summary
df = pd.read_excel('/tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx', header=0); df.columns=['gene','p','q','lfc']
df['q_BH_recomputed'] = multipletests(df.p, method='fdr_bh')[1]
df['single_observation_artifact'] = np.isclose(df.p, 0.42265, atol=1e-5)
df['meets_study_criteria'] = (df.p<0.05) & ((2**df.lfc>=1.2)|(2**df.lfc<=0.83))
df.sort_values('p').head(60).to_csv('/tmp/outputs/analysis/T8_phosphoproteomics_top60.csv', index=False)
summ = pd.DataFrame([dict(n_phosphopeptides=len(df), n_genes=df.gene.nunique(), n_p_lt_0p05=(df.p<0.05).sum(), expected_by_chance=0.05*len(df),
   n_meeting_FC_and_p_criteria=df.meets_study_criteria.sum(), min_q_provided=df.q.min(), min_q_BH=df.q_BH_recomputed.min(), n_q_lt_0p05=(df.q<0.05).sum(),
   n_single_observation_p0p42265=df.single_observation_artifact.sum(), stat5b_rows=df[df.gene=='Stat5b'][['p','q','lfc']].to_dict('records'))])
summ.to_csv('/tmp/outputs/analysis/T8_phosphoproteomics_summary.csv', index=False)
print(pd.DataFrame(rows)[['panel','creatine_effect_stratum0','creatine_effect_stratum1','ratio_of_ratios','rr_lo','rr_hi','p_interaction']].round(4).to_string())
print(summ.T)
