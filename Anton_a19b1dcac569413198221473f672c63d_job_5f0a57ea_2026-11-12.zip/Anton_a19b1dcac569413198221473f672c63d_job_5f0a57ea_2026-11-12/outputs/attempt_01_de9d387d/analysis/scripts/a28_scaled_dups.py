import numpy as np, itertools, openpyxl
from data import WB
# collect all numeric column-vectors (contiguous runs >=3) across sheets
vecs=[]
for ws in WB.worksheets:
    for col in ws.iter_cols():
        run=[]; start=None
        for c in col:
            v=c.value
            if isinstance(v,(int,float)) and not isinstance(v,bool):
                if not run: start=c.coordinate
                run.append(float(v))
            else:
                if len(run)>=3: vecs.append((ws.title,start,np.array(run)))
                run=[]
        if len(run)>=3: vecs.append((ws.title,start,np.array(run)))
    for row in ws.iter_rows():
        run=[]; start=None
        for c in row:
            v=c.value
            if isinstance(v,(int,float)) and not isinstance(v,bool):
                if not run: start=c.coordinate
                run.append(float(v))
            else:
                if len(run)>=3: vecs.append((ws.title,start+'(row)',np.array(run)))
                run=[]
        if len(run)>=3: vecs.append((ws.title,start+'(row)',np.array(run)))
print(len(vecs),'vectors')
# check for any window of 3 consecutive values that reappears scaled by a constant (k != 1) or with an additive shift in another vector
def windows(v):
    for i in range(len(v)-2): yield i, v[i:i+3]
hits=[]
idx={}
for vi,(s,c,v) in enumerate(vecs):
    for i,w in windows(v):
        if np.any(w==0) or np.allclose(w, w[0]): continue
        if all(float(x).is_integer() for x in w): continue
        key = tuple(np.round(w/w[0], 6))
        idx.setdefault(key, []).append((vi,i,w))
for key, lst in idx.items():
    if len(lst)>1:
        sheets = set(vecs[vi][0]+vecs[vi][1] for vi,i,w in lst)
        if len(sheets)>1:
            ks = [w[0] for vi,i,w in lst]
            hits.append((key, [(vecs[vi][0], vecs[vi][1], i, np.round(w,4).tolist()) for vi,i,w in lst]))
for h in hits[:60]:
    print(h)
print(len(hits))
print("\n=== cross-sheet only ===")
n=0
for key, lst in idx.items():
    sh = set(vecs[vi][0] for vi,i,w in lst)
    if len(sh)>1:
        n+=1
        print([(vecs[vi][0], vecs[vi][1], i, np.round(w,4).tolist()) for vi,i,w in lst])
print(n)
