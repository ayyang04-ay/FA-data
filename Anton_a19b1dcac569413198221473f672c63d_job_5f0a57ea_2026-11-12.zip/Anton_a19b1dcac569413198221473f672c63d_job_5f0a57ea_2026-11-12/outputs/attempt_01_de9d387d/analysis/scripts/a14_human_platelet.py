import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
from data import rng, val
pd.set_option('display.width',250)
# Fig. 7c blocks: (agonist, metric, first data row) ; columns B(0d)=1, C(3d), D(7d), E(14d); 11 rows each
blocks = [('collagen','max agg',4),('collagen','avg agg',18),('collagen','adhesion',32),
          ('EPI','max agg',46),('EPI','avg agg',60),('EPI','adhesion',74),
          ('AA','max agg',88),('AA','avg agg',102),('AA','adhesion',116),
          ('ADP','max agg',130),('ADP','avg agg',144),('ADP','adhesion',157)]
# reported Dunnett 0 vs 14 p-values (from sheet)
rep14 = {('collagen','max agg'):0.0051, ('collagen','avg agg'):0.1242, ('collagen','adhesion'):0.0337,
         ('EPI','max agg'):0.0061, ('EPI','avg agg'):0.0023, ('EPI','adhesion'):0.0184,
         ('AA','max agg'):0.3316, ('AA','avg agg'):0.1612, ('AA','adhesion'):0.1451,
         ('ADP','max agg'):0.6821, ('ADP','avg agg'):0.5303, ('ADP','adhesion'):0.3202}
rows=[]
for ag, met, r0 in blocks:
    B = rng('Fig. 7c', f'B{r0}:B{r0+10}'); C = rng('Fig. 7c', f'C{r0}:C{r0+10}'); D = rng('Fig. 7c', f'D{r0}:D{r0+10}'); E = rng('Fig. 7c', f'E{r0}:E{r0+10}')
    assert len(B)==11 and np.all(B==1), (ag,met,B)
    for tp, X in [('d3',C),('d7',D),('d14',E)]:
        # zeros present? log undefined -> use Wilcoxon on raw FC-1 and sign test; log with small offset for t-test
        nz = np.sum(X<=0)
        lx = np.log2(np.where(X>0, X, np.nan))
        lxv = lx[~np.isnan(lx)]
        t_p = stats.ttest_1samp(lxv, 0).pvalue
        w_p = stats.wilcoxon(X-1).pvalue
        n_up = int(np.sum(X>1)); n_dn = int(np.sum(X<1))
        sign_p = stats.binomtest(n_up, n_up+n_dn, 0.5).pvalue
        gm = 2**np.nanmean(lx)
        rows.append(dict(agonist=ag, metric=met, time=tp, n=len(X), n_zero=nz, median_FC=np.median(X), geomean_FC=gm,
                         n_up=n_up, n_down=n_dn, p_logT=t_p, p_wilcoxon=w_p, p_sign=sign_p,
                         p_reported_Dunnett=rep14[(ag,met)] if tp=='d14' else np.nan))
df = pd.DataFrame(rows)
# Friedman across 0,3,7,14 per endpoint
fr=[]
for ag, met, r0 in blocks:
    M = np.column_stack([rng('Fig. 7c', f'{c}{r0}:{c}{r0+10}') for c in 'BCDE'])
    fr.append(dict(agonist=ag, metric=met, p_friedman=stats.friedmanchisquare(*M.T).pvalue))
fr = pd.DataFrame(fr)
d14 = df[df.time=='d14'].copy()
d14['p_wilcoxon_holm12'] = multipletests(d14.p_wilcoxon, method='holm')[1]
d14['p_wilcoxon_BH12'] = multipletests(d14.p_wilcoxon, method='fdr_bh')[1]
d14['p_logT_holm12'] = multipletests(d14.p_logT, method='holm')[1]
print(df.to_string(float_format=lambda x: f'{x:.3g}'))
print()
print(d14[['agonist','metric','median_FC','geomean_FC','n_up','n_down','p_logT','p_logT_holm12','p_wilcoxon','p_wilcoxon_holm12','p_wilcoxon_BH12','p_reported_Dunnett']].to_string(float_format=lambda x: f'{x:.3g}'))
print()
print(fr.to_string(float_format=lambda x: f'{x:.3g}'))
df.to_csv('human_platelet_function_reanalysis.csv', index=False)
