import numpy as np
from scipy import stats
from data import rng
blocks = {('collagen','max agg'):4,('collagen','avg agg'):18,('EPI','max agg'):46,('EPI','avg agg'):60,('EPI','adhesion'):74,('AA','adhesion'):116,('ADP','max agg'):130}
def pw(n, d, sd, alpha=0.05):
    se = sd/np.sqrt(n); df=n-1; nc=abs(d)/se; tc=stats.t.ppf(1-alpha/2,df)
    return 1-stats.nct.cdf(tc,df,nc)+stats.nct.cdf(-tc,df,nc)
for k,r0 in blocks.items():
    for col,tp in [('D','d7'),('E','d14')]:
        x = rng('Fig. 7c', f'{col}{r0}:{col}{r0+10}'); lx = np.log(x[x>0])
        m, s = lx.mean(), lx.std(ddof=1)
        # crossover vs placebo: difference of two log-FCs -> SD*sqrt(2) (assume placebo log-FC SD similar, mean 0)
        sdd = s*np.sqrt(2)
        n90 = next((n for n in range(4,400) if pw(n, m/2, sdd) >= 0.9), '>400')  # powered for half the observed effect
        print(f'{k[0]:8s} {k[1]:9s} {tp}: mean log FC={m:.2f} (x{np.exp(m):.2f}) SD={s:.2f}; crossover n (90% power, half of observed effect, a=0.05) = {n90}')
