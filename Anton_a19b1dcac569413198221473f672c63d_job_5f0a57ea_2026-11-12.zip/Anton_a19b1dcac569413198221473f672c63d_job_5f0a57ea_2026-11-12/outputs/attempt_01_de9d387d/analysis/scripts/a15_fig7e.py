import numpy as np, pandas as pd
from scipy import stats
from data import rng
import statsmodels.formula.api as smf
from statsmodels.stats.anova import AnovaRM
for name, rows in [('GP6', (4,7)), ('P2RY12', (12,15))]:
    M = np.column_stack([rng('Fig. 7e', f'{c}{rows[0]}:{c}{rows[1]}') for c in 'BCDE'])  # 4 volunteers x 4 tp
    print(name); print(pd.DataFrame(M, columns=['d0','d3','d7','d14'], index=[f'V{i+1}' for i in range(4)]).round(3))
    L = np.log2(M / M[:,[0]])
    for j,tp in enumerate(['d3','d7','d14'],1):
        t = stats.ttest_1samp(L[:,j],0)
        print(f'  {tp}: per-volunteer log2FC={np.round(L[:,j],2)}  mean FC={2**L[:,j].mean():.2f}  paired t p={t.pvalue:.3f}  (n up={np.sum(L[:,j]>0)}/4)')
    d = pd.DataFrame([(v,tp,np.log2(M[v,j])) for v in range(4) for j,tp in enumerate(['d0','d3','d7','d14'])], columns=['vol','tp','y'])
    a = AnovaRM(d, 'y', 'vol', within=['tp']).fit()
    print('  RM-ANOVA (log2):', a.anova_table.round(4).to_dict('records'))
    print('  Friedman p=', round(stats.friedmanchisquare(*M.T).pvalue,4))
