import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R = pd.read_csv('qpcr_reanalysis_long.csv')
G11 = ['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
order = [
 ('in vivo MK: creatine vs vehicle (Fig.2f)', 'Creatine vs vehicle, MK in vivo (2f)'),
 ('in vivo MK WT: creatine vs vehicle (Fig.3f)', 'Creatine vs vehicle, Pf4-Cre;Slc6a8+/+ MK (3f) †'),
 ('MK DMSO: creatine vs vehicle (Fig.6a)', 'Creatine vs vehicle, DMSO (6a)'),
 ('MK WT: creatine vs vehicle (Fig.6g)', 'Creatine vs vehicle, Pf4-iCre;Stat5b+/+ MK (6g)'),
 ('in vitro MK: creatine vs control (Fig.4h)', 'Creatine vs control, MK in vitro (4h)'),
 ('in vitro MK si-scr: creatine vs control (Fig.4j)', 'Creatine vs control, si-scrambled (4j)'),
 ('in vitro MK: CKB-OE vs EV (Fig.4l)', 'CKB over-expression vs EV, no creatine (4l)'),
 ('Slc6a8-cKO MK in vitro: liposomal creatine vs control (S4e)', 'Liposomal creatine, Slc6a8-cKO MK (S4e)'),
 ('in vitro MK: PCr vs control (Fig.4h)', 'Phosphocreatine vs control (4h)'),
 ('Slc6a8-cKO MK in vitro: creatine vs control (S4e)', 'Free creatine, Slc6a8-cKO MK in vitro (S4e)'),
 ('in vivo MK Slc6a8-cKO: creatine vs vehicle (Fig.3f)', 'Creatine vs vehicle, Slc6a8-cKO MK in vivo (3f) †'),
 ('in vitro MK si-Ckb: creatine vs control (Fig.4j)', 'Creatine vs control, si-Ckb (4j)'),
 ('MK STAT5i: creatine vs vehicle (Fig.6a)', 'Creatine vs vehicle, STAT5-IN-1 (6a)'),
 ('MK Stat5b-cKO+creatine vs WT vehicle (Fig.6g)', 'Stat5b-cKO+creatine vs WT vehicle (6g)‡'),
]
W = R.pivot_table(index='experiment', columns='gene', values='log2FC')[G11]
P = R.pivot_table(index='experiment', columns='gene', values='p')[G11]
M = np.array([W.loc[o[0]].values for o in order]); PP = np.array([P.loc[o[0]].values for o in order])
fig, ax = plt.subplots(figsize=(11,7.2))
im = ax.imshow(M, cmap='RdBu_r', vmin=-4, vmax=4, aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        s = f'{M[i,j]:.1f}' + ('*' if PP[i,j]<0.05 else '')
        ax.text(j,i,s,ha='center',va='center',fontsize=7, color='white' if abs(M[i,j])>2.6 else 'black')
ax.set_xticks(range(len(G11))); ax.set_xticklabels(G11, rotation=45, ha='right')
ax.set_yticks(range(len(order))); ax.set_yticklabels([o[1] for o in order], fontsize=8)
ax.axhline(7.5, color='k', lw=1.5)
cb = plt.colorbar(im, ax=ax, shrink=0.7); cb.set_label('log2 fold-change (from ΔCt; n=3/group)')
ax.set_title('MK "platelet-activation" transcript program: induction (top) and loss-of-function/controls (bottom)\n* p<0.05, t-test on ΔCt (unadjusted). † Fig. 3f provenance flags: WT-creatine ΔCt not instrument-native; duplicated values in cKO groups. ‡ no KO-vehicle group exists', fontsize=9)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/P2_MK_program_heatmap.png', dpi=200)
print('ok')
