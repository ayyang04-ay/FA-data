import numpy as np
from data import rng
import itertools
# integer triplets in the workbook
trip = {
 'Fig2b ADP veh': rng('Fig. 2b','B4:D4'), 'Fig2b ADP cre': rng('Fig. 2b','E4:G4'),
 'Fig2b Col veh': rng('Fig. 2b','B5:D5'), 'Fig2b Col cre': rng('Fig. 2b','E5:G5'),
 'Fig2b Thr veh': rng('Fig. 2b','B6:D6'), 'Fig2b Thr cre': rng('Fig. 2b','E6:G6'),
 'Fig3d ADP WTv': rng('Fig. 3d','B4:D4'), 'Fig3d ADP WTc': rng('Fig. 3d','E4:G4'), 'Fig3d ADP KOv': rng('Fig. 3d','H4:J4'), 'Fig3d ADP KOc': rng('Fig. 3d','K4:M4'),
 'Fig3d Col WTv': rng('Fig. 3d','B5:D5'), 'Fig3d Col WTc': rng('Fig. 3d','E5:G5'), 'Fig3d Col KOv': rng('Fig. 3d','H5:J5'), 'Fig3d Col KOc': rng('Fig. 3d','K5:M5'),
 'Fig3d Thr WTv': rng('Fig. 3d','B6:D6'), 'Fig3d Thr WTc': rng('Fig. 3d','E6:G6'), 'Fig3d Thr KOv': rng('Fig. 3d','H6:J6'), 'Fig3d Thr KOc': rng('Fig. 3d','K6:M6'),
 'Fig2a PLT veh': rng('Fig. 2a','B4:B6'), 'Fig2a PLT cre': rng('Fig. 2a','C4:C6'),
 'S4b PLT WTv': rng('Supplementary Fig  4b','C5:C7'), 'S4b PLT WTc': rng('Supplementary Fig  4b','D5:D7'), 'S4b PLT KOv': rng('Supplementary Fig  4b','E5:E7'), 'S4b PLT KOc': rng('Supplementary Fig  4b','F5:F7'),
 'S7a PLT vc': rng('Supplementary Fig  7a','B4:B6'), 'S7a PLT cc': rng('Supplementary Fig  7a','C4:C6'), 'S7a PLT vi': rng('Supplementary Fig  7a','D4:D6'), 'S7a PLT ci': rng('Supplementary Fig  7a','E4:E6'),
 'S7b PLT wv': rng('Supplementary Fig  7b','B4:B6'), 'S7b PLT wc': rng('Supplementary Fig  7b','C4:C6'), 'S7b PLT kc': rng('Supplementary Fig  7b','D4:D6'),
}
for k,v in trip.items():
    s = np.sort(v); ap = np.isclose(s[1]-s[0], s[2]-s[1]); 
    print(f'{k:16s} {v} sorted={s} AP={ap} sd={v.std(ddof=1):.2f} cv%={100*v.std(ddof=1)/v.mean():.1f}')
# Monte Carlo: probability that integer triplet drawn from N(mu, sd) rounded is an exact AP
rng_ = np.random.default_rng(0)
def p_ap(mu, sd, even=False, n=200000):
    x = rng_.normal(mu, sd, size=(n,3))
    x = np.round(x/2)*2 if even else np.round(x)
    s = np.sort(x, axis=1)
    return np.mean(s[:,1]-s[:,0] == s[:,2]-s[:,1])
print()
# Fig 2b: use each triplet's own sd (conservative: small sd increases AP chance)
ps=[]
for k in ['Fig2b ADP veh','Fig2b ADP cre','Fig2b Col veh','Fig2b Col cre','Fig2b Thr veh','Fig2b Thr cre']:
    v=trip[k]; p=p_ap(v.mean(), v.std(ddof=1)); ps.append(p); print(k, 'P(AP | own SD) =', round(p,3))
print('joint probability all six AP (independent):', np.prod(ps))
# using pooled CV typical for LTA ~10%
ps2=[p_ap(trip[k].mean(), 0.10*trip[k].mean()) for k in ['Fig2b ADP veh','Fig2b ADP cre','Fig2b Col veh','Fig2b Col cre','Fig2b Thr veh','Fig2b Thr cre']]
print('with 10% CV:', np.round(ps2,3), 'joint', np.prod(ps2))
