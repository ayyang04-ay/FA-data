import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import uniform_filter1d
im = Image.open('/tmp/work/src_unz/xl/media/image1.jpeg').convert('L')
A = 255 - np.asarray(im).astype(float)
# GP6 bands are slanted: integrate each lane over a y-window tracking the band: search per-lane max row
def lane_int(x_centers, y_lo, y_hi, half_w=22, h=9):
    vals=[]
    for c in x_centers:
        sub = A[y_lo:y_hi, c-half_w:c+half_w]
        rp = uniform_filter1d(sub.mean(1), 3); yb = y_lo + int(np.argmax(rp))
        band = A[yb-h:yb+h+1, c-half_w:c+half_w]
        bg = np.median(np.vstack([A[yb-h-12:yb-h-4, c-half_w:c+half_w], A[yb+h+4:yb+h+12, c-half_w:c+half_w]]))
        vals.append(max((band-bg).sum(),0))
    return np.array(vals)
gp6 = lane_int([65,118,170,222,275,322], 175, 230)
p2 = lane_int([880,932,985,1035,1088,1130], 205, 250)
act = lane_int([1437,1490,1540,1590,1643,1690], 200, 240)
for nm, v in [('GP6',gp6),('P2RY12',p2),('ACTB',act)]:
    print(nm, np.round(v/v[:3].mean(),2))
r1 = gp6/act; r2 = p2/act
print('GP6/ACTB veh->cre fold (mean cre/mean veh):', round(r1[3:].mean()/r1[:3].mean(),2), np.round(r1/r1[:3].mean(),2))
print('P2RY12/ACTB veh->cre fold:', round(r2[3:].mean()/r2[:3].mean(),2), np.round(r2/r2[:3].mean(),2))
