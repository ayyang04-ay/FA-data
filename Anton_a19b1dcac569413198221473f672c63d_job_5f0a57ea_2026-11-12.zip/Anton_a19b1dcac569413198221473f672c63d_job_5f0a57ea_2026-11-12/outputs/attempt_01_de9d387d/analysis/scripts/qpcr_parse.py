import openpyxl, numpy as np, re
from openpyxl.utils import get_column_letter, column_index_from_string
WB = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)
def parse_qpcr(sheet):
    ws = WB[sheet]
    # find gene labels: strings in col A (or C) that are gene-like, rows
    blocks = {}
    gene_rows = []
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, str) and c.column <= 3 and re.fullmatch(r'[A-Za-z][A-Za-z0-9]{1,9}', c.value.strip()) and c.value not in ('Control','Vehicle','Creatine'):
                gene_rows.append((c.row, c.value.strip()))
    gene_rows.sort()
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, str) and re.fullmatch(r'ΔCT\d', c.value.strip()):
                label = c.value.strip()
                vals = []
                for k in range(1,4):
                    v = ws.cell(row=c.row, column=c.column+k).value
                    vals.append(float(v) if isinstance(v,(int,float)) else np.nan)
                # gene = last gene row <= c.row
                g = [gname for r,gname in gene_rows if r <= c.row]
                gene = g[-1] if g else '?'
                blocks.setdefault(gene, {}).setdefault(label, []).append((c.column, np.array(vals)))
    return blocks
if __name__ == '__main__':
    for s in ['Fig. 2f','Fig. 3f','Fig. 4e','Fig. 4h','Fig. 4j','Fig. 4l','Fig.6a','Fig. 6g','Supplementary Fig  2a','Supplementary Fig  3c','Supplementary Fig  4e','Supplementary Fig  8c']:
        b = parse_qpcr(s)
        print('==', s, list(b.keys()))
        for g, d in b.items():
            print('   ', g, {k: [ (get_column_letter(col), np.round(v,3).tolist()) for col, v in lst] for k,lst in d.items()})
