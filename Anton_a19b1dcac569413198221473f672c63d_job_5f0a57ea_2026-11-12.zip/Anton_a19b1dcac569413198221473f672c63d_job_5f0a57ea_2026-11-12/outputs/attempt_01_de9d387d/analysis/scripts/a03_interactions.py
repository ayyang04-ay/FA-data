import numpy as np, pandas as pd
import statsmodels.formula.api as smf
import statsmodels.api as sm
from data import rng
pd.set_option('display.width',250)
def twoway(sheet, refs, factorA_name, levelsA, label, log=True):
    # refs order: A0B0, A0B1, A1B0, A1B1 where B = creatine (0 veh,1 cre)
    rows=[]
    for (a,b), r in zip([(0,0),(0,1),(1,0),(1,1)], refs):
        for y in rng(sheet, r):
            rows.append(dict(A=a, cre=b, y=y))
    d = pd.DataFrame(rows)
    d['ly'] = np.log(d.y) if log else d.y
    m = smf.ols('ly ~ A*cre', data=d).fit()
    est = m.params['A:cre']; ci = m.conf_int().loc['A:cre'].values; p = m.pvalues['A:cre']
    cre_eff_A0 = m.params['cre']; ci0 = m.conf_int().loc['cre'].values
    # creatine effect in A1 = cre + A:cre
    L = np.zeros(len(m.params)); L[list(m.params.index).index('cre')]=1; L[list(m.params.index).index('A:cre')]=1
    t = m.t_test(L); e1 = float(t.effect[0]); ci1 = t.conf_int()[0]; p1 = float(t.pvalue)
    f = np.exp if log else (lambda x: x)
    print(f"{label:45s} | creatine effect ({levelsA[0]}): x{f(cre_eff_A0):.2f} [{f(ci0[0]):.2f}-{f(ci0[1]):.2f}] p={m.pvalues['cre']:.2g}"
          f" | creatine effect ({levelsA[1]}): x{f(e1):.2f} [{f(ci1[0]):.2f}-{f(ci1[1]):.2f}] p={p1:.2g}"
          f" | interaction (ratio of ratios) x{f(est):.2f} [{f(ci[0]):.2f}-{f(ci[1]):.2f}] p={p:.2g} | resid SD(log)={np.sqrt(m.scale):.3f}")
    return m
print("Log-scale two-way models (y ~ factor * creatine); effects are fold-changes (ratio of geometric means)\n")
twoway('Fig. 1f', ['B22:B27','C22:C27','D22:D27','E22:E27'], 'tumour Slc6a8 KD', ['sh-scr','sh-Slc6a8'], 'Fig.1f burden: tumour sh-Slc6a8')
twoway('Fig. 1f', ['B31:B36','C31:C36','D31:D36','E31:E36'], 'tumour Slc6a8 KD', ['sh-scr','sh-Slc6a8'], 'Fig.1f foci: tumour sh-Slc6a8')
twoway('Fig. 1f', ['B4:B9','C4:C9','D4:D9','E4:E9'], 'tumour Slc6a8 KD', ['sh-scr','sh-Slc6a8'], 'Fig.1f lung wt: tumour sh-Slc6a8')
twoway('Fig. 3i', ['B10:B13','C10:C13','D10:D13','E10:E13'], 'MK Slc6a8 cKO', ['WT','cKO'], 'Fig.3i burden: Pf4-Cre Slc6a8 cKO')
twoway('Fig. 3i', ['B17:B20','C17:C20','D17:D20','E17:E20'], 'MK Slc6a8 cKO', ['WT','cKO'], 'Fig.3i foci: Pf4-Cre Slc6a8 cKO')
twoway('Fig. 3i', ['B3:B6','C3:C6','D3:D6','E3:E6'], 'MK Slc6a8 cKO', ['WT','cKO'], 'Fig.3i lung wt: Pf4-Cre Slc6a8 cKO')
twoway('Fig. 6b', ['B4:B8','C4:C8','D4:D8','E4:E8'], 'STAT5-IN-1', ['DMSO','STAT5i'], 'Fig.6b burden: STAT5 inhibitor')
twoway('Fig. 6b', ['B13:B17','C13:C17','D13:D17','E13:E17'], 'STAT5-IN-1', ['DMSO','STAT5i'], 'Fig.6b foci: STAT5 inhibitor')
twoway('Fig. 3d', ['B4:D4','E4:G4','H4:J4','K4:M4'], 'MK Slc6a8 cKO', ['WT','cKO'], 'Fig.3d ADP aggregation')
twoway('Fig. 3d', ['B5:D5','E5:G5','H5:J5','K5:M5'], 'MK Slc6a8 cKO', ['WT','cKO'], 'Fig.3d collagen aggregation')
twoway('Fig. 3d', ['B6:D6','E6:G6','H6:J6','K6:M6'], 'MK Slc6a8 cKO', ['WT','cKO'], 'Fig.3d thrombin aggregation')
twoway('Fig. 3c', ['B4:D4','E4:G4','B5:D5','E5:G5'], 'MK Slc6a8 cKO', ['WT','cKO'], 'Fig.3c MK intracellular creatine')
twoway('Fig. 3b', ['B4:F4','G4:K4','B5:F5','G5:K5'], 'MK Slc6a8 cKO', ['WT','cKO'], 'Fig.3b serum creatine')
twoway('Supplementary Fig  4c', ['C6:C13','D6:D13','E6:E13','F6:F13'], 'MK Slc6a8 cKO', ['WT','cKO'], 'Supp4c a-granules (fields, pseudo-rep)')
