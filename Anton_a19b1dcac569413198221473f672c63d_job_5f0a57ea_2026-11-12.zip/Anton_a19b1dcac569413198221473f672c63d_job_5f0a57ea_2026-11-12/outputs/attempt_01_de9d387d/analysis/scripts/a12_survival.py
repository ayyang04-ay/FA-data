import numpy as np
from lifelines.statistics import logrank_test
from lifelines import KaplanMeierFitter, CoxPHFitter
import pandas as pd
S = {
 'Fig.1c': ([17,17,20,20,21,23,27,29,30,30],[13,13,13,13,18,20,21,21,22,24]),
 'Fig.1l': ([14,14,14,15,15,15,15,16,16,16,16,18,18,18,18,19,19,20,20,20],[12,12,12,12,13,13,14,14,14,14,15,15,15,17,17,18,19,19]),
}
for k,(v,c) in S.items():
    r = logrank_test(v, c, event_observed_A=[1]*len(v), event_observed_B=[1]*len(c))
    kmv = KaplanMeierFitter().fit(v); kmc = KaplanMeierFitter().fit(c)
    df = pd.DataFrame({'T': v+c, 'E': 1, 'cre': [0]*len(v)+[1]*len(c)})
    cph = CoxPHFitter().fit(df, 'T', 'E')
    hr = np.exp(cph.params_['cre']); ci = np.exp(cph.confidence_intervals_.loc['cre'].values)
    print(f"{k}: n veh={len(v)} n cre={len(c)} median veh={kmv.median_survival_time_} cre={kmc.median_survival_time_}; log-rank chi2={r.test_statistic:.3f} p={r.p_value:.4f}; Cox HR={hr:.2f} [{ci[0]:.2f}-{ci[1]:.2f}]; all deaths observed (no censoring)")
