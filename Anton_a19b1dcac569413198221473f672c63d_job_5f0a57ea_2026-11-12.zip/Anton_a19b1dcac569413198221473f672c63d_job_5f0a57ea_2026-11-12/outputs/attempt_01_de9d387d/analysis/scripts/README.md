# Re-analysis scripts for the CRE-MK-01 validation proposal

Environment: `micromamba run -n singlecell python <script>` (pandas, scipy, statsmodels, openpyxl, matplotlib).
`a12_survival.py` uses lifelines (`micromamba run -n core python`).

## Inputs
Raw inputs are read from `/tmp/world/filesystem/`. `data.py` lists every cell range used. `qpcr_parse.py` parses every ΔCt block.

## Run order
Some scripts write intermediate files into the working directory. Run them in this order:

| Step | Script(s) | Purpose | Writes |
|---|---|---|---|
| 1 | `a01_recompute_ttests.py` | Two-group re-tests | `two_group_recalc.csv` (= T1) |
| 2 | `a02_anova_recalc.py` | Tukey reproduction | – |
| 2 | `a03_interactions.py` | Log-scale interaction models | – |
| 3 | `a04`–`a07` | qPCR provenance (float32 / dyadic) tests for Fig. 3f (`a06` is exploratory: a back-calculation search that found no simple offset) | – |
| 4 | `a08_fig7d.py` | Parse Fig. 7d; recompute normalised values | `fig7d.pkl` |
| 4 | `a09_fig7d_resid.py` | Residue and technical-replicate checks | – |
| 4 | `a23_fig7d_stats.py` | Per-volunteer statistics | T6 |
| 5 | `a10_ap_check.py`, `a11_fig3d_sim.py` | Aggregation pattern tests (Fig. 2b/3d) | – |
| 6 | `a12_survival.py` | Log-rank / Cox | – |
| 7 | `a13_meta.py` | Cross-experiment synthesis | `meta_inputs.csv` (= T2) |
| 8 | `a14_human_platelet.py` | Paired re-analysis of Fig. 7c | T5 |
| 8 | `a15_fig7e.py` | Paired / RM analysis of Fig. 7e | – |
| 9 | `a17_densito2.py` | Approximate densitometry of Supp. 8d | `densito2.pkl`, overlay PNG |
| 9 | `a18_fig2e.py` | Approximate densitometry of Fig. 2e | – |
| 10 | `a19_qpcr_reanalysis.py` | ΔCt re-analysis of all MK panels | `qpcr_reanalysis_long.csv` (= T4) |
| 11 | `a20_fig1h.py`, `a21_fig5.py`, `a22_chip.py` | Early retention, S127 mutants, ChIP | – |
| 12 | `a24_power.py`, `a25_human_power.py` | Sample-size calculations | – |
| 13 | `a26`–`a28` | Grid and duplicate scans | – |
| 13 | `a29_tables.py` | Summary tables | T3, T8 |
| 14 | `f01`–`f05` | Figures | `figures/P1`–`P5` |
