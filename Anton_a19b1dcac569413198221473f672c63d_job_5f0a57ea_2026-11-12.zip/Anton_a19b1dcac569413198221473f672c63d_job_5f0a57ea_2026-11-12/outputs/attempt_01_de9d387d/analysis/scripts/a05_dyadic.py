import numpy as np
from fractions import Fraction
from qpcr_parse import parse_qpcr
import openpyxl
def denom_exp(x):
    f = Fraction(float(x)); d = f.denominator
    k = d.bit_length()-1
    return k if d == 2**k else None
for s in ['Fig. 3f','Supplementary Fig  8c','Fig. 2f']:
    b = parse_qpcr(s)
    print('==', s)
    for g, d in b.items():
        for lab, lst in d.items():
            col, v = lst[0]
            ks = [denom_exp(x) for x in v]
            print(f'   {g:8s} {lab}: denominators 2^k, k={ks}')
