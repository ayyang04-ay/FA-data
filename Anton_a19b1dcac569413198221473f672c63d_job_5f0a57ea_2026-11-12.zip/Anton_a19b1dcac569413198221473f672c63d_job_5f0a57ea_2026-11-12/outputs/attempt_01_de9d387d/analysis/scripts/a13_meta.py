import numpy as np, pandas as pd
from scipy import stats
from data import rng
def lr(a,b):
    la, lb = np.log(a), np.log(b)
    d = lb.mean()-la.mean(); se = np.sqrt(la.var(ddof=1)/len(la)+lb.var(ddof=1)/len(lb))
    sdp = np.sqrt(((len(la)-1)*la.var(ddof=1)+(len(lb)-1)*lb.var(ddof=1))/(len(la)+len(lb)-2))
    return d, se, sdp
def dl(ds, ses):
    w = 1/ses**2; fe = np.sum(w*ds)/np.sum(w); Q = np.sum(w*(ds-fe)**2); k=len(ds)
    C = np.sum(w)-np.sum(w**2)/np.sum(w); tau2 = max(0,(Q-(k-1))/C)
    wr = 1/(ses**2+tau2); re = np.sum(wr*ds)/np.sum(wr); se = np.sqrt(1/np.sum(wr))
    I2 = max(0,(Q-(k-1))/Q) if Q>0 else 0
    # prediction interval
    tcrit = stats.t.ppf(0.975, k-2) if k>2 else np.nan
    pi = (re - tcrit*np.sqrt(tau2+se**2), re + tcrit*np.sqrt(tau2+se**2))
    return re, se, tau2, I2, Q, pi
sets = {
 'burden': [
   ('Fig.1b (model A)', 'Fig. 1b','B3:B8','C3:C8'),
   ('Fig.1f sh-scr melanoma', 'Fig. 1f','B22:B27','C22:C27'),
   ('Fig.1f sh-Slc6a8 melanoma', 'Fig. 1f','D22:D27','E22:E27'),
   ('Fig.1k (model B)', 'Fig. 1k','B4:B9','C4:C9'),
   ('Fig.3i Pf4-Cre;Slc6a8+/+', 'Fig. 3i','B10:B13','C10:C13'),
   ('Fig.6b DMSO arms [shared animals w/ S2d]', 'Fig. 6b','B4:B8','C4:C8'),
   ('Supp.1e', 'Supplementary Fig  1e','B13:B18','C13:C18'),
   ('Supp.1f', 'Supplementary Fig  1f','B12:B15','C12:C15'),
   ('Supp.1g', 'Supplementary Fig  1g','B15:B24','C15:C24'),
   ('Supp.1i (5% diet)', 'Supplementary Fig  1i','B11:B14','C11:C14'),
   ('Supp.1k', 'Supplementary Fig  1k','B16:B25','C16:C25'),
 ],
 'foci': [
   ('Fig.1b', 'Fig. 1b','B12:B17','C12:C17'),
   ('Fig.1f sh-scr', 'Fig. 1f','B31:B36','C31:C36'),
   ('Fig.1f sh-Slc6a8', 'Fig. 1f','D31:D36','E31:E36'),
   ('Fig.1k', 'Fig. 1k','B12:B17','C12:C17'),
   ('Fig.3i WT', 'Fig. 3i','B17:B20','C17:C20'),
   ('Fig.6b DMSO', 'Fig. 6b','B13:B17','C13:C17'),
   ('Supp.1e', 'Supplementary Fig  1e','B22:B27','C22:C27'),
   ('Supp.1f', 'Supplementary Fig  1f','B20:B23','C20:C23'),
   ('Supp.1g', 'Supplementary Fig  1g','B28:B37','C28:C37'),
   ('Supp.1i', 'Supplementary Fig  1i','B18:B21','C18:C21'),
   ('Supp.1k', 'Supplementary Fig  1k','B29:B38','C29:C38'),
 ],
 'transfer_burden': [
   ('Supp.2d mouse donor PLT (veh vs cre) [shared animals w/ 6b]', 'Supplementary Fig  2d','C5:C10','D5:D10'),
   ('Fig.7g human donor PLT (d0 vs d7)', 'Fig. 7g','B12:B16','C12:C16'),
 ]
}
out=[]
for key, lst in sets.items():
    print('=====', key)
    ds=[];ses=[];sds=[]
    for lab, sh, a, b in lst:
        A=rng(sh,a); B=rng(sh,b); d,se,sdp=lr(A,B)
        ds.append(d); ses.append(se); sds.append(sdp)
        print(f'  {lab:55s} nV={len(A):2d} nC={len(B):2d} ratio(GM)={np.exp(d):.2f} [{np.exp(d-1.96*se):.2f}-{np.exp(d+1.96*se):.2f}]  pooled SD(log)={sdp:.3f}')
        out.append(dict(endpoint=key, experiment=lab, n_veh=len(A), n_cre=len(B), ratio_GM=np.exp(d), lo=np.exp(d-1.96*se), hi=np.exp(d+1.96*se), sd_log=sdp))
    ds=np.array(ds); ses=np.array(ses)
    if len(ds)>2:
        re,se,tau2,I2,Q,pi = dl(ds,ses)
        print(f'  POOLED (DerSimonian-Laird): ratio={np.exp(re):.2f} [{np.exp(re-1.96*se):.2f}-{np.exp(re+1.96*se):.2f}] tau2={tau2:.3f} I2={100*I2:.0f}% Q={Q:.1f}; 95% prediction interval {np.exp(pi[0]):.2f}-{np.exp(pi[1]):.2f}')
        print(f'  median pooled SD(log) across experiments = {np.median(sds):.3f}; range {min(sds):.3f}-{max(sds):.3f}')
        # leave-out the 6b arms
        mask = np.array(['6b' not in l[0] for l in lst])
        re2,se2,tau22,I22,Q2,pi2 = dl(ds[mask],ses[mask])
        print(f'  POOLED excluding Fig.6b: ratio={np.exp(re2):.2f} [{np.exp(re2-1.96*se2):.2f}-{np.exp(re2+1.96*se2):.2f}] I2={100*I22:.0f}%')
pd.DataFrame(out).to_csv('meta_inputs.csv', index=False)
