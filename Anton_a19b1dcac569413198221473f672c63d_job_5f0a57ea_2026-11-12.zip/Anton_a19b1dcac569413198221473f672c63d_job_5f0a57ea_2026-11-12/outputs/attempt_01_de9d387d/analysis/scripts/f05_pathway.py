import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
fig, ax = plt.subplots(figsize=(16,7.2)); ax.set_xlim(0,16); ax.set_ylim(-0.9,6.6); ax.axis('off')
from matplotlib.patches import Rectangle
C = {'invivo':'#74c476','vitro':'#fed976','corr':'#fdae6b','comp':'#fb6a4a','human':'#9ecae1'}
nodes = [
 (0.15,3.7,'Oral creatine\n(gavage / 5% diet)','invivo','Fig.1, S1: metastasis x3.2\n(11 arms, all positive)'),
 (2.05,3.7,'Serum creatine\nx2.4-2.9','invivo','3b, S1d, S1h\n(human x3.4, 7b)'),
 (3.95,3.7,'MK uptake via\nSLC6A8','invivo','3i: MK cKO removes\neffect (x0.22, p<0.001)'),
 (5.85,3.7,'MK creatine/PCr\nx3-5','vitro','3c, 4a, 4c; cKO blocks\n(interaction p=0.065)'),
 (7.75,3.7,'CKB induced;\nCKB required','vitro','4b, 4e, 4j, 4l, S5c\n(in vitro only)'),
 (9.65,3.7,'STAT5B pS127,\nnuclear (non-pY)','vitro','MS q=0.25; 5e-5i; S6a;\nS6h; cKO blocks program\n(6g); in vivo 6b flagged (I1)'),
 (11.55,3.7,'Promoter occupancy\nP2ry12, Gp6, Rab4a','vitro','5j, S6i (no IgG ctrl)'),
 (13.45,3.7,'Platelet program\nGP6, P2Y12, a2A...','corr','2f/3f/4h/6a/6g: 11/11 up;\nhuman GP6, ADRA2A'),
]
for x,y,t,c,sub in nodes:
    red = 'STAT5B' in t
    ax.add_patch(FancyBboxPatch((x,y),1.75,1.1,boxstyle='round,pad=0.03',fc=C[c],ec='red' if red else 'k',lw=3 if red else 1))
    ax.text(x+0.875,y+0.55,t,ha='center',va='center',fontsize=8.5,weight='bold')
    ax.text(x+0.875,y-0.42,sub,ha='center',va='center',fontsize=7.0)
for i in range(len(nodes)-1):
    x=nodes[i][0]+1.75; ax.annotate('',xy=(x+0.15,4.25),xytext=(x,4.25),arrowprops=dict(arrowstyle='->',lw=1.3))
# lower row: phenotype
low = [
 (13.45,1.2,'Platelet priming\n(aggregation, TEG-MA,\nalpha-granules)','vitro','human ex vivo: EPI & collagen up,\nADP flat (7c, paired re-analysis);\nmouse 2b/3d flagged (I2, I3)'),
 (10.2,1.2,'Platelets carry the\npro-metastatic activity','invivo','7g: human d7 PLT x2.8 (n=5/5);\nS2d mouse PLT compromised (I1)'),
 (6.95,1.2,'CTC retention in lung\n6-24 h (not arrest)','invivo','1h: x1.5 (6h) to x2.8 (24h);\n15 min unchanged'),
 (3.7,1.2,'Lung metastasis,\nsurvival','invivo','burden x3.2, foci x2.0;\nHR 2.3-2.9 (1c, 1l)'),
]
for x,y,t,c,sub in low:
    ax.add_patch(FancyBboxPatch((x,y),2.1,1.15,boxstyle='round,pad=0.03',fc=C[c],ec='k',lw=1))
    ax.text(x+1.05,y+0.58,t,ha='center',va='center',fontsize=8.5,weight='bold')
    ax.text(x+1.05,y-0.45,sub,ha='center',va='center',fontsize=7.2)
ax.annotate('',xy=(15.35,2.4),xytext=(15.35,3.65),arrowprops=dict(arrowstyle='->',lw=1.3))
for xa,xb in [(13.45,12.3),(10.2,9.05),(6.95,5.8)]:
    ax.annotate('',xy=(xb,1.78),xytext=(xa,1.78),arrowprops=dict(arrowstyle='->',lw=1.3))
# proposed tests
tests = [(3.95+0.875,5.25,'Study C\n(anchor replication)'),(7.75+0.875,5.25,'Study D (later;\nneeds MK-Ckb line)'),(10.9,5.25,'STUDY A = the in vivo slot\nPf4-iCre;Stat5b KO x creatine'),(13.45+0.875,5.25,'Study B\n(GPVI blockade)')]
for x,y,t in tests:
    ax.text(x,y+0.2,t,ha='center',va='center',fontsize=8.2,color='navy',weight='bold',bbox=dict(boxstyle='round',fc='white',ec='navy'))
    xt = 9.65+0.875 if 'STUDY A' in t else x
    ax.annotate('',xy=(xt,4.85),xytext=(x if 'STUDY A' not in t else 10.3,y-0.15),arrowprops=dict(arrowstyle='->',color='navy',lw=1.2))
ax.text(0.2,6.35,'Creatine -> megakaryocyte -> platelet -> metastasis: what each link rests on (colour = strongest uncompromised evidence)',fontsize=11,weight='bold')
lx=0.2
for k,lab in [('invivo','in vivo causal (genetic / exposure)'),('vitro','ex vivo / in vitro mechanistic'),('corr','correlative (expression)'),('comp','red outline: the only in vivo test is compromised')]:
    ax.add_patch(Rectangle((lx,-0.75),0.3,0.22,fc=C[k] if k!='comp' else 'white',ec='red' if k=='comp' else 'k',lw=3 if k=='comp' else 1)); ax.text(lx+0.38,-0.64,lab,fontsize=8,va='center'); lx+=3.9
plt.savefig('/tmp/outputs/figures/P5_mechanism_evidence_map.png',dpi=200,bbox_inches='tight')
print('ok')
