import numpy as np, openpyxl
from fractions import Fraction
WB = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)
ws = WB['Fig. 7d']
def kden(x):
    f = Fraction(float(x)); d = f.denominator; k = d.bit_length()-1
    return k if d == 2**k else 99
# blocks: gene name rows 6,25,44,63,82,100 ; left genes cols C-F, right genes cols I-L
blocks = [(6,'C','ITGA2B','I','P2RY12'),(25,'C','GP6','I','GPIBA'),(44,'C','F2R','I','ADRA2A'),(63,'C','FCGR2A','I','RUNX1'),(82,'C','RAB4A','I','RAB27B'),(100,'C','PITPNB',None,None)]
from openpyxl.utils import column_index_from_string as ci
data = {}
for r0, cL, gL, cR, gR in blocks:
    for col, gene in [(cL,gL),(cR,gR)]:
        if gene is None: continue
        c0 = ci(col)
        d = {}
        for i, tp in enumerate(['0d','3d','7d','14d']):
            rows = range(r0+1+3*i, r0+4+3*i)
            d[tp] = np.array([[ws.cell(row=r, column=c0+v).value for v in range(4)] for r in rows], dtype=float)  # 3 tech reps x 4 volunteers
        # reported normalized
        rep = {}
        for i, tp in enumerate(['0d','3d','7d','14d']):
            rr = r0+13+i
            rep[tp] = np.array([ws.cell(row=rr, column=c0+v).value for v in range(4)], dtype=float)
        data[gene] = (d, rep)
import pickle; pickle.dump(data, open('fig7d.pkl','wb'))
for gene,(d,rep) in data.items():
    ks = {tp: [kden(x) for x in d[tp].ravel()] for tp in d}
    nonf32 = {tp: sum(1 for k in ks[tp] if k>24) for tp in ks}
    # recompute normalized: 2^(mean dCT_tp - mean dCT_0d) per volunteer
    calc = {tp: 2**(d[tp].mean(0) - d['0d'].mean(0)) for tp in d}
    calc2 = {tp: (2**d[tp]).mean(0) / (2**d['0d']).mean(0) for tp in d}
    print(f"{gene:7s} nonf32 per tp: {nonf32}")
    for tp in ['3d','7d','14d']:
        print(f"    {tp}: reported {np.round(rep[tp],3)} | 2^(mean dCT diff) {np.round(calc[tp],3)} | ratio of mean 2^dCT {np.round(calc2[tp],3)}")
