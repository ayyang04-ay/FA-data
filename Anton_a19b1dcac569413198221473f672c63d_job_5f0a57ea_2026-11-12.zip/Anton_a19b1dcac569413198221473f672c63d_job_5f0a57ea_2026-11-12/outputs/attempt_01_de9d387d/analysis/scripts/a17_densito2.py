import numpy as np, pickle
from PIL import Image, ImageDraw
from scipy.ndimage import uniform_filter1d
im = Image.open('/tmp/work/src_unz/xl/media/image26.jpeg').convert('L')
A = 255 - np.asarray(im).astype(float)
# (x0,x1) lane search region excluding ladders, expected band y, expected lane centres
P = {
 ('V1','GP6'):    (300,500,170,[331,376,426,474]),
 ('V1','P2RY12'): (700,930,172,[738,790,843,897]),
 ('V1','ACTB'):   (1140,1360,164,[1172,1228,1276,1327]),
 ('V2','GP6'):    (260,498,434,[292,351,417,471]),
 ('V2','P2RY12'): (690,880,421,[705,767,813,853]),
 ('V2','ACTB'):   (1170,1432,425,[1213,1258,1322,1383]),
 ('V3','GP6'):    (300,500,697,[324,370,421,471]),
 ('V3','P2RY12'): (700,942,700,[730,775,838,893]),
 ('V3','ACTB'):   (1140,1412,692,[1174,1265,1318,1381]),
 ('V4','GP6'):    (220,480,990,[250,330,385,440]),
 ('V4','P2RY12'): (720,962,988,[762,823,880,925]),
 ('V4','ACTB'):   (1180,1460,987,[1228,1276,1325,1388]),
}
res={}; info={}
ov = Image.open('/tmp/work/src_unz/xl/media/image26.jpeg').convert('RGB'); d = ImageDraw.Draw(ov)
for key,(x0,x1,yexp,lanes) in P.items():
    # refine band row within +-12 px of expected: maximize mean signal across the lane region
    rows = np.arange(yexp-12, yexp+13)
    rp = np.array([A[r, x0:x1].mean() for r in rows])
    yb = int(rows[np.argmax(uniform_filter1d(rp,5))])
    h = 8
    # background: median of strip 12-20 px above and below band across each column
    bg_col = np.median(np.vstack([A[yb-h-12:yb-h-4, :], A[yb+h+4:yb+h+12, :]]), axis=0)
    colprof = (A[yb-h:yb+h+1, :] - bg_col).sum(0)
    sm = uniform_filter1d(colprof, 5)
    vals=[]; cents=[]
    for c in lanes:
        lo, hi = c-14, c+15
        cc = lo + int(np.argmax(sm[lo:hi]))
        # lane extent: expand until signal drops below 20% of peak or 24 px half-width
        pk = sm[cc]; l=cc; r=cc
        while l>cc-24 and sm[l-1] > 0.2*pk: l-=1
        while r<cc+24 and sm[r+1] > 0.2*pk: r+=1
        vals.append(max(colprof[l:r+1].sum(),0)); cents.append((l,r))
        d.rectangle([l, yb-h, r, yb+h], outline=(255,0,0))
    res[key]=np.array(vals); info[key]=(yb,cents)
ov.save('densito_overlay2.png')
pickle.dump(res, open('densito2.pkl','wb'))
from data import rng
rep = {'GP6': np.column_stack([rng('Fig. 7e', f'{c}4:{c}7') for c in 'BCDE']), 'P2RY12': np.column_stack([rng('Fig. 7e', f'{c}12:{c}15') for c in 'BCDE'])}
print("target/ACTB relative to d0: image-derived vs reported (Fig. 7e)")
for prot in ['GP6','P2RY12']:
    for vi,v in enumerate(['V1','V2','V3','V4']):
        r = res[(v,prot)]/res[(v,'ACTB')]; rr = r/r[0]
        rp = rep[prot][vi]/rep[prot][vi][0]
        print(f"{prot:6s} {v}: image d0,d3,d7,d14 = {np.round(rr,2)} | reported = {np.round(rp,2)} | raw {prot}={np.round(res[(v,prot)]/res[(v,prot)][0],2)} raw ACTB={np.round(res[(v,'ACTB')]/res[(v,'ACTB')][0],2)}")
