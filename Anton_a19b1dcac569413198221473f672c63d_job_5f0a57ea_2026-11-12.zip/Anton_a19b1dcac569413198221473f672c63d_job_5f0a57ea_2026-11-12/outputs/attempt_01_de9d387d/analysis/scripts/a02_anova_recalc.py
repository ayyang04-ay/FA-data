import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from data import rng, val
pd.set_option('display.width',250)
def tukey(groups, names):
    y = np.concatenate(groups); g = np.concatenate([[n]*len(x) for n,x in zip(names,groups)])
    res = pairwise_tukeyhsd(y, g)
    df = pd.DataFrame(res._results_table.data[1:], columns=res._results_table.data[0])
    return df
panels = {
 'Fig. 1f lung weight': ('Fig. 1f', ['B4:B9','C4:C9','D4:D9','E4:E9'], ['scr-veh','scr-cre','sh-veh','sh-cre']),
 'Fig. 1f SUV': ('Fig. 1f', ['B13:B18','C13:C18','D13:D18','E13:E18'], ['scr-veh','scr-cre','sh-veh','sh-cre']),
 'Fig. 1f burden': ('Fig. 1f', ['B22:B27','C22:C27','D22:D27','E22:E27'], ['scr-veh','scr-cre','sh-veh','sh-cre']),
 'Fig. 1f foci': ('Fig. 1f', ['B31:B36','C31:C36','D31:D36','E31:E36'], ['scr-veh','scr-cre','sh-veh','sh-cre']),
 'Fig. 3d ADP': ('Fig. 3d', ['B4:D4','E4:G4','H4:J4','K4:M4'], ['WT-veh','WT-cre','cKO-veh','cKO-cre']),
 'Fig. 3d collagen': ('Fig. 3d', ['B5:D5','E5:G5','H5:J5','K5:M5'], ['WT-veh','WT-cre','cKO-veh','cKO-cre']),
 'Fig. 3d thrombin': ('Fig. 3d', ['B6:D6','E6:G6','H6:J6','K6:M6'], ['WT-veh','WT-cre','cKO-veh','cKO-cre']),
 'Fig. 3i lung weight': ('Fig. 3i', ['B3:B6','C3:C6','D3:D6','E3:E6'], ['WT-veh','WT-cre','cKO-veh','cKO-cre']),
 'Fig. 3i burden': ('Fig. 3i', ['B10:B13','C10:C13','D10:D13','E10:E13'], ['WT-veh','WT-cre','cKO-veh','cKO-cre']),
 'Fig. 3i foci': ('Fig. 3i', ['B17:B20','C17:C20','D17:D20','E17:E20'], ['WT-veh','WT-cre','cKO-veh','cKO-cre']),
 'Fig. 6b burden': ('Fig. 6b', ['B4:B8','C4:C8','D4:D8','E4:E8'], ['veh','cre','veh+i','cre+i']),
 'Fig. 6b foci': ('Fig. 6b', ['B13:B17','C13:C17','D13:D17','E13:E17'], ['veh','cre','veh+i','cre+i']),
 'Fig. 6e MK creatine': ('Fig. 6e', ['C5:C7','D5:D7','E5:E7'], ['WT-veh','WT-cre','Stat5bKO-cre']),
 'Supp 2d burden': ('Supplementary Fig  2d', ['C5:C10','D5:D10','E5:E10'], ['vehPLT','crePLT','cre+aspPLT']),
 'Supp 2d foci': ('Supplementary Fig  2d', ['C14:C19','D14:D19','E14:E19'], ['vehPLT','crePLT','cre+aspPLT']),
 'Supp 4c a-granules': ('Supplementary Fig  4c', ['C6:C13','D6:D13','E6:E13','F6:F13'], ['WT-veh','WT-cre','cKO-veh','cKO-cre']),
 'Supp 4b PLT': ('Supplementary Fig  4b', ['C5:C7','D5:D7','E5:E7','F5:F7'], ['WT-veh','WT-cre','cKO-veh','cKO-cre']),
 'Fig. 5e veh': ('Fig. 5e', ['N4:N6','O4:O6','P4:P6','Q4:Q6'], ['WT','S127A','3A','S127D']),
 'Fig. 5e cre': ('Fig. 5e', ['N17:N19','O17:O19','P17:P19','Q17:Q19'], ['WT','S127A','3A','S127D']),
 'Fig. 5f veh': ('Fig. 5f', ['N4:N6','O4:O6','P4:P6','Q4:Q6'], ['WT','S127A','3A','S127D']),
 'Fig. 5f cre': ('Fig. 5f', ['N17:N19','O17:O19','P17:P19','Q17:Q19'], ['WT','S127A','3A','S127D']),
 'Fig. 7e GP6': ('Fig. 7e', ['B4:B7','C4:C7','D4:D7','E4:E7'], ['d0','d3','d7','d14']),
 'Fig. 7e P2RY12': ('Fig. 7e', ['B12:B15','C12:C15','D12:D15','E12:E15'], ['d0','d3','d7','d14']),
 'Fig. 7b serum creatine': ('Fig. 7b', ['B4:B14','C4:C14','D4:D14','E4:E14'], ['d0','d3','d7','d14']),
}
for name,(sheet, refs, names) in panels.items():
    groups = [rng(sheet, r) for r in refs]
    print('====', name, ' n=', [len(g) for g in groups], ' means=', [round(g.mean(),4) for g in groups])
    print(tukey(groups, names).to_string())
