import numpy as np
from scipy import stats
def power_interaction(n, delta, sd, alpha=0.05):
    # 2x2 factorial, n per cell, interaction contrast on log scale; df = 4n-4 (more if sex block: minus 1)
    se = sd*np.sqrt(4/n); df = 4*n-5
    nc = abs(delta)/se; tcrit = stats.t.ppf(1-alpha/2, df)
    return 1 - stats.nct.cdf(tcrit, df, nc) + stats.nct.cdf(-tcrit, df, nc)
def power_two_group(n, delta, sd, alpha=0.05):
    se = sd*np.sqrt(2/n); df = 2*n-2; nc = abs(delta)/se; tcrit = stats.t.ppf(1-alpha/2, df)
    return 1 - stats.nct.cdf(tcrit, df, nc) + stats.nct.cdf(-tcrit, df, nc)
eff = np.log(3.0)   # pooled creatine effect ~3.16x (burden)
print("Interaction power (2x2, n per cell), WT creatine effect x3.0; attenuation = fraction of log-effect removed in KO")
for sd in [0.35, 0.45, 0.55]:
    for att in [1.0, 0.75, 0.5]:
        delta = eff*att
        ns = [n for n in range(4,61) if power_interaction(n, delta, sd) >= 0.9]
        ns8 = [n for n in range(4,61) if power_interaction(n, delta, sd) >= 0.8]
        print(f"  SD(log)={sd:.2f} attenuation={int(att*100)}% (interaction x{np.exp(-delta):.2f}): n/cell for 80% = {ns8[0] if ns8 else '>60'}, 90% = {ns[0] if ns else '>60'}; power at n=12: {power_interaction(12, delta, sd):.2f}")
print()
print("Two-group power: creatine vs vehicle (replication), effect x2.0 (lower prediction bound ~1.95)")
for sd in [0.35,0.45,0.55]:
    ns = [n for n in range(3,61) if power_two_group(n, np.log(2.0), sd) >= 0.9]
    print(f"  SD={sd}: n/group for 90% = {ns[0]}")
print()
print("Blocking effect: GPVI blockade removes 50% of log creatine effect -> contrast (cre+isotype vs cre+anti) delta = 0.5*log(3)")
for sd in [0.35,0.45,0.55]:
    ns = [n for n in range(3,80) if power_two_group(n, 0.5*np.log(3.0), sd) >= 0.9]
    print(f"  SD={sd}: n/group for 90% = {ns[0]}")
