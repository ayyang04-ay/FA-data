import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker
from data import rng
import statsmodels.formula.api as smf
meta = pd.read_csv('meta_inputs.csv')
b = meta[meta.endpoint=='burden'].copy()
# pooled (from a13): recompute DL
d = np.log(b.ratio_GM.values); se = (np.log(b.hi.values)-np.log(b.lo.values))/(2*1.96)
w=1/se**2; fe=(w*d).sum()/w.sum(); Q=(w*(d-fe)**2).sum(); k=len(d); C=w.sum()-(w**2).sum()/w.sum(); tau2=max(0,(Q-(k-1))/C)
wr=1/(se**2+tau2); re=(wr*d).sum()/wr.sum(); sre=np.sqrt(1/wr.sum())
fig, axes = plt.subplots(1,2, figsize=(13,6.2), gridspec_kw={'width_ratios':[1.25,1]})
ax=axes[0]
labels = list(b.experiment) + ['Pooled (random effects)']
vals = list(b.ratio_GM)+[np.exp(re)]; los=list(b.lo)+[np.exp(re-1.96*sre)]; his=list(b.hi)+[np.exp(re+1.96*sre)]
y = np.arange(len(labels))[::-1]
for i,(v,l,h) in enumerate(zip(vals,los,his)):
    col = 'crimson' if '6b' in labels[i] else ('black' if i<len(labels)-1 else 'navy')
    ax.plot([l,h],[y[i],y[i]],color=col,lw=1.5); ax.plot(v,y[i],'D' if i==len(labels)-1 else 's',color=col,ms=7 if i==len(labels)-1 else 5)
ax.axvline(1,color='grey',ls=':'); ax.set_xscale('log'); ax.set_xlim(0.8,9); ax.set_xticks([1,2,3,5,8]); ax.set_xticklabels(['1','2','3','5','8']); ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
ax.set_yticks(y); ax.set_yticklabels([l.replace(' [shared animals w/ S2d]',' *') for l in labels], fontsize=8.5)
ax.set_xlabel('Creatine / vehicle, ratio of geometric means (95% CI)')
ax.set_title('A. Creatine effect on lung metastatic burden, every vehicle-vs-creatine arm\n(I²=55%; 95% prediction interval 1.95–5.13; * arm shares animals with Supp. Fig. 2d)', fontsize=9.5)
# panel B: perturbation effects: creatine effect in control vs perturbed
ax=axes[1]
def two(sheet, refs):
    rows=[]
    for (a,bb), r in zip([(0,0),(0,1),(1,0),(1,1)], refs):
        for yv in rng(sheet, r): rows.append(dict(A=a,cre=bb,ly=np.log(yv)))
    dd=pd.DataFrame(rows); m=smf.ols('ly~A*cre',dd).fit()
    e0=m.params['cre']; c0=m.conf_int().loc['cre'].values
    L=np.zeros(len(m.params)); L[list(m.params.index).index('cre')]=1; L[list(m.params.index).index('A:cre')]=1
    t=m.t_test(L); e1=float(t.effect[0]); c1=t.conf_int()[0]
    return (e0,c0),(e1,c1),m.pvalues['A:cre']
items=[('Tumour Slc6a8 shRNA (Fig.1f)','Fig. 1f',['B22:B27','C22:C27','D22:D27','E22:E27'],'sh-scr','sh-Slc6a8'),
       ('MK Slc6a8 cKO, Pf4-Cre (Fig.3i)','Fig. 3i',['B10:B13','C10:C13','D10:D13','E10:E13'],'WT','cKO'),
       ('STAT5-IN-1, systemic (Fig.6b)*','Fig. 6b',['B4:B8','C4:C8','D4:D8','E4:E8'],'DMSO','STAT5i')]
yy=0; yt=[]; yl=[]
for lab,sh,refs,l0,l1 in items[::-1]:
    (e0,c0),(e1,c1),p = two(sh,refs)
    ax.plot(np.exp(c0),[yy+0.18]*2,color='black'); ax.plot(np.exp(e0),yy+0.18,'s',color='black')
    ax.plot(np.exp(c1),[yy-0.18]*2,color='darkorange'); ax.plot(np.exp(e1),yy-0.18,'o',color='darkorange')
    ax.text(1.05,yy,f'interaction p={p:.2g}',fontsize=8,va='center',color='dimgray')
    yt+= [yy+0.18,yy-0.18]; yl+=[f'{lab}: {l0}', f'{lab}: {l1}']; yy+=1
ax.axvline(1,color='grey',ls=':'); ax.set_xscale('log'); ax.set_xlim(0.3,10); ax.set_xticks([0.5,1,2,4,8]); ax.set_xticklabels(['0.5','1','2','4','8']); ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
ax.set_yticks(yt); ax.set_yticklabels(yl,fontsize=8)
ax.set_xlabel('Creatine effect within stratum (ratio, 95% CI)')
ax.set_title('B. Which perturbations remove the creatine effect?\n(log-scale two-way models; * data overlap with Supp. Fig. 2d)',fontsize=9.5)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/P1_metastasis_forest.png',dpi=200)
print('ok', np.exp(re), np.exp(re-1.96*sre), np.exp(re+1.96*sre))
