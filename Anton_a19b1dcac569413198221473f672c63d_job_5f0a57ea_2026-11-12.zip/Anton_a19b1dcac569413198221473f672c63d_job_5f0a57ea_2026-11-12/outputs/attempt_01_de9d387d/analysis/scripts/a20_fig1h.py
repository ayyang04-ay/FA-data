import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from data import rng
tps = [0.25, 6, 12, 24]
rows=[]
for i,tp in enumerate(tps):
    r = 4+i
    v = rng('Fig. 1h', f'B{r}:G{r}'); c = rng('Fig. 1h', f'H{r}:M{r}')
    t = stats.ttest_ind(c, v)
    lt = stats.ttest_ind(np.log(c), np.log(v))
    print(f't={tp:>5}h veh mean={v.mean():.3f} cre mean={c.mean():.3f} ratio={c.mean()/v.mean():.2f}  p={t.pvalue:.4f}  (log p={lt.pvalue:.4f})')
    # fraction retained relative to 0.25h group mean
    for x in v: rows.append(dict(t=tp, cre=0, y=x))
    for x in c: rows.append(dict(t=tp, cre=1, y=x))
d = pd.DataFrame(rows)
v0 = d[(d.t==0.25)&(d.cre==0)].y.mean(); c0 = d[(d.t==0.25)&(d.cre==1)].y.mean()
for tp in tps[1:]:
    print(f'  retained fraction at {tp}h: veh {d[(d.t==tp)&(d.cre==0)].y.mean()/v0*100:.1f}%  cre {d[(d.t==tp)&(d.cre==1)].y.mean()/c0*100:.1f}%')
print("NOTE: unit of the signal not labelled in the sheet; same 6 animals per group at every time point?  -> columns identical layout suggests repeated measures (longitudinal imaging) or separate cohorts; unknown.")
