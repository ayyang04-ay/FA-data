import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from qpcr_parse import parse_qpcr
pd.set_option('display.width',250); pd.set_option('display.max_columns',40)
G11 = ['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
def grp(b, g, lab):
    return b[g][lab][0][1]
def contrast(a, b):
    # log2FC = mean(b)-mean(a) in dCT units (higher dCT = higher expression here), Welch & Student p
    d = b.mean()-a.mean(); p = stats.ttest_ind(b, a).pvalue
    return d, p
rows=[]
# Two-group panels
for sheet, lab_c, lab_t, name in [('Fig. 2f','ΔCT1','ΔCT2','in vivo MK: creatine vs vehicle (Fig.2f)'),
                                  ('Fig. 4l','ΔCT1','ΔCT2','in vitro MK: CKB-OE vs EV (Fig.4l)')]:
    b = parse_qpcr(sheet)
    for g in G11:
        d,p = contrast(grp(b,g,lab_c), grp(b,g,lab_t)); rows.append(dict(experiment=name, gene=g, log2FC=d, p=p))
# Multi-group panels: define contrasts
b = parse_qpcr('Fig. 3f')
for g in G11:
    wv, wc, kv, kc = grp(b,g,'ΔCT1'), grp(b,g,'ΔCT2'), grp(b,g,'ΔCT3'), grp(b,g,'ΔCT4')
    d,p = contrast(wv,wc); rows.append(dict(experiment='in vivo MK WT: creatine vs vehicle (Fig.3f)', gene=g, log2FC=d, p=p))
    d,p = contrast(kv,kc); rows.append(dict(experiment='in vivo MK Slc6a8-cKO: creatine vs vehicle (Fig.3f)', gene=g, log2FC=d, p=p))
    df = pd.DataFrame({'y':np.r_[wv,wc,kv,kc], 'ko':[0]*6+[1]*6, 'cre':[0,0,0,1,1,1]*2})
    m = smf.ols('y~ko*cre', df).fit(); rows.append(dict(experiment='interaction cKO x creatine (Fig.3f)', gene=g, log2FC=m.params['ko:cre'], p=m.pvalues['ko:cre']))
b = parse_qpcr('Fig. 4h')
for g in G11:
    c, cr, pcr = grp(b,g,'ΔCT1'), grp(b,g,'ΔCT2'), grp(b,g,'ΔCT3')
    d,p = contrast(c,cr); rows.append(dict(experiment='in vitro MK: creatine vs control (Fig.4h)', gene=g, log2FC=d, p=p))
    d,p = contrast(c,pcr); rows.append(dict(experiment='in vitro MK: PCr vs control (Fig.4h)', gene=g, log2FC=d, p=p))
b = parse_qpcr('Fig. 4j')
for g in G11:
    cs, ck, crs, crk = grp(b,g,'ΔCT1'), grp(b,g,'ΔCT2'), grp(b,g,'ΔCT3'), grp(b,g,'ΔCT4')
    d,p = contrast(cs,crs); rows.append(dict(experiment='in vitro MK si-scr: creatine vs control (Fig.4j)', gene=g, log2FC=d, p=p))
    d,p = contrast(ck,crk); rows.append(dict(experiment='in vitro MK si-Ckb: creatine vs control (Fig.4j)', gene=g, log2FC=d, p=p))
    df = pd.DataFrame({'y':np.r_[cs,ck,crs,crk], 'si':[0,0,0,1,1,1,0,0,0,1,1,1], 'cre':[0]*6+[1]*6})
    m = smf.ols('y~si*cre', df).fit(); rows.append(dict(experiment='interaction si-Ckb x creatine (Fig.4j)', gene=g, log2FC=m.params['si:cre'], p=m.pvalues['si:cre']))
b = parse_qpcr('Fig.6a')
for g in G11:
    v, c, vi, ci = grp(b,g,'ΔCT1'), grp(b,g,'ΔCT2'), grp(b,g,'ΔCT3'), grp(b,g,'ΔCT4')
    d,p = contrast(v,c); rows.append(dict(experiment='MK DMSO: creatine vs vehicle (Fig.6a)', gene=g, log2FC=d, p=p))
    d,p = contrast(vi,ci); rows.append(dict(experiment='MK STAT5i: creatine vs vehicle (Fig.6a)', gene=g, log2FC=d, p=p))
    d,p = contrast(v,vi); rows.append(dict(experiment='MK vehicle: STAT5i vs DMSO (Fig.6a)', gene=g, log2FC=d, p=p))
    df = pd.DataFrame({'y':np.r_[v,c,vi,ci], 'inh':[0]*6+[1]*6, 'cre':[0,0,0,1,1,1]*2})
    m = smf.ols('y~inh*cre', df).fit(); rows.append(dict(experiment='interaction STAT5i x creatine (Fig.6a)', gene=g, log2FC=m.params['inh:cre'], p=m.pvalues['inh:cre']))
b = parse_qpcr('Fig. 6g')
for g in G11:
    wv, wc, kc = grp(b,g,'ΔCT1'), grp(b,g,'ΔCT2'), grp(b,g,'ΔCT3')
    d,p = contrast(wv,wc); rows.append(dict(experiment='MK WT: creatine vs vehicle (Fig.6g)', gene=g, log2FC=d, p=p))
    d,p = contrast(wv,kc); rows.append(dict(experiment='MK Stat5b-cKO+creatine vs WT vehicle (Fig.6g)', gene=g, log2FC=d, p=p))
    d,p = contrast(kc,wc); rows.append(dict(experiment='MK WT+creatine vs Stat5b-cKO+creatine (Fig.6g)', gene=g, log2FC=d, p=p))
b = parse_qpcr('Supplementary Fig  4e')
for g in G11:
    c, cr, lip = grp(b,g,'ΔCT1'), grp(b,g,'ΔCT2'), grp(b,g,'ΔCT3')
    d,p = contrast(c,cr); rows.append(dict(experiment='Slc6a8-cKO MK in vitro: creatine vs control (S4e)', gene=g, log2FC=d, p=p))
    d,p = contrast(c,lip); rows.append(dict(experiment='Slc6a8-cKO MK in vitro: liposomal creatine vs control (S4e)', gene=g, log2FC=d, p=p))
R = pd.DataFrame(rows)
R.to_csv('qpcr_reanalysis_long.csv', index=False)
W = R.pivot_table(index='experiment', columns='gene', values='log2FC', sort=False)[G11]
P = R.pivot_table(index='experiment', columns='gene', values='p', sort=False)[G11]
def fmt(x,p): 
    s = f'{x:+.2f}'; 
    return s + ('***' if p<0.001 else '**' if p<0.01 else '*' if p<0.05 else '')
T = W.copy().astype(object)
for i in W.index:
    for g in G11: T.loc[i,g] = fmt(W.loc[i,g], P.loc[i,g])
print("log2 fold-change from dCT (t-test on dCT, n=3/group; * p<0.05 ** <0.01 *** <0.001, unadjusted)")
print(T.to_string())
