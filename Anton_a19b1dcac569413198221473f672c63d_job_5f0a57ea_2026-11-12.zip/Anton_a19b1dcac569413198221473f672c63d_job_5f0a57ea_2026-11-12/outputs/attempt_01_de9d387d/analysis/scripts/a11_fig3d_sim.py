import numpy as np
rng_ = np.random.default_rng(1)
# Fig 3d: 11 of 12 triplets have pattern {x,x,x+-2}, one has {x-2,x,x+2}; all even integers.
def sim(mu, sd, n=200000):
    x = np.round(rng_.normal(mu, sd, size=(n,3))/2)*2
    s = np.sort(x,1); r = s[:,2]-s[:,0]
    return np.mean(r<=2), np.mean(r<=4)
for sd in [2,3,4,5]:
    p2,p4 = sim(60, sd)
    print(f"true SD={sd}: P(range<=2)={p2:.3f}  P(range<=4)={p4:.3f}  -> P(11 of 12 range<=2 & 1 range<=4) ~ {12*(p2**11)*(p4-p2) + p2**12:.2e}")
