"""Extraction of raw values from CRE-MK-01_source_data.xlsx (cell ranges verified by manual inspection)."""
import openpyxl, numpy as np
WB = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)

def rng(sheet, ref):
    ws = WB[sheet]
    cells = ws[ref]
    out = []
    if not isinstance(cells, tuple):
        cells = ((cells,),)
    for row in cells:
        if not isinstance(row, tuple): row = (row,)
        for c in row:
            if isinstance(c.value, (int, float)) and not isinstance(c.value, bool):
                out.append(float(c.value))
    return np.array(out)

def val(sheet, ref):
    return WB[sheet][ref].value

# ---------- Two-group in vivo / in vitro comparisons: (sheet, endpoint, ctrl range, trt range, reported P, reported t/df) -------
TWO_GROUP = [
 ('Fig. 1a','Lung weight (g)','B3:B8','C3:C8','F4','F8'),
 ('Fig. 1a','SUV-BW','B12:B17','C12:C17','F12','F16'),
 ('Fig. 1b','Metastatic burden (%)','B3:B8','C3:C8','F3','F7'),
 ('Fig. 1b','Metastatic foci','B12:B17','C12:C17','F12','F16'),
 ('Fig. 1i','GFP+ cells/field','B4:B11','C4:C11','F4','F8'),
 ('Fig. 1j','Lung weight (g)','B4:B9','C4:C9','F4','F8'),
 ('Fig. 1j','SUV-BW','B13:B18','C13:C18','F13','F17'),
 ('Fig. 1k','Metastatic burden (%)','B4:B9','C4:C9','F4','F8'),
 ('Fig. 1k','Metastatic foci','B12:B17','C12:C17','F12','F16'),
 ('Fig. 2a','PLT','B4:B6','C4:C6','F4','F8'),
 ('Fig. 2a','PCT','B12:B14','C12:C14','F12','F16'),
 ('Fig. 2a','PDW','B19:B21','C19:C21','F19','F23'),
 ('Fig. 2a','MPV','B27:B29','C27:C29','F27','F31'),
 ('Fig. 2b','Aggregation ADP (%)','B4:D4','E4:G4','B18','B22'),
 ('Fig. 2b','Aggregation collagen (%)','B5:D5','E5:G5','B32','B36'),
 ('Fig. 2b','Aggregation thrombin (%)','B6:D6','E6:G6','B45','B49'),
 ('Fig. 2c','alpha-granules/platelet (fields)','B4:B11','C4:C11','F5','F9'),
 ('Fig. 2d','TEG-R','B4:B8','C4:C8','F4','F8'),
 ('Fig. 2d','TEG-K','B12:B16','C12:C16','F12','F16'),
 ('Fig. 2d','TEG-alpha','B20:B24','C20:C24','F20','F24'),
 ('Fig. 2d','TEG-MA','B28:B32','C28:C32','F28','F32'),
 ('Fig. 2j','PKH+ area (%) (fields)','B4:B11','C4:C11','F4','F8'),
 ('Fig. 3b','Serum creatine WT','B4:F4','G4:K4','B17','B21'),
 ('Fig. 3b','Serum creatine cKO','B5:F5','G5:K5','B31','B35'),
 ('Fig. 3c','MK creatine WT','B4:D4','E4:G4','B15','B19'),
 ('Fig. 3c','MK creatine cKO','B5:D5','E5:G5','B30','B34'),
 ('Fig. 4a','MK creatine','B4:B6','C4:C6','H10','H14'),
 ('Fig. 4a','Brain creatine','D4:D6','E4:E6','H24','H28'),
 ('Fig. 4c','MK PCr','B4:B6','C4:C6','H10','H14'),
 ('Fig. 4c','Brain PCr','D4:D6','E4:E6','H24','H28'),
 ('Fig. 4d','MK in vitro "creatinine"','C4:C6','D4:D6','G10','G14'),
 ('Fig. 4f','MK in vitro PCr','B4:B6','C4:C6','F4','F8'),
 ('Fig. 7g','Lung weight (human PLT transfer)','B4:B8','C4:C8','F4','F8'),
 ('Fig. 7g','Metastatic burden (human PLT transfer)','B12:B16','C12:C16','F12','F16'),
 ('Fig. 7g','Foci (human PLT transfer)','B19:B23','C19:C23','F19','F23'),
 ('Supplementary Fig  1a','Body weight d0','B4:E4','F4:I4','M11','M15'),
 ('Supplementary Fig  1a','Body weight d7','B5:E5','F5:I5','M25','M29'),
 ('Supplementary Fig  1b','Food intake','B4:B9','C4:C9','F4','F8'),
 ('Supplementary Fig  1c','Water intake','B4:B9','C4:C9','F4','F8'),
 ('Supplementary Fig  1d','Serum creatine','B4:B9','C4:C9','F4','F8'),
 ('Supplementary Fig  1e','Lung weight','B4:B9','C4:C9','F4','F8'),
 ('Supplementary Fig  1e','Metastatic burden (%)','B13:B18','C13:C18','F13','F17'),
 ('Supplementary Fig  1e','Metastatic foci','B22:B27','C22:C27','F22','F26'),
 ('Supplementary Fig  1f','Lung weight','B4:B7','C4:C7','F4','F8'),
 ('Supplementary Fig  1f','Metastatic burden (%)','B12:B15','C12:C15','F12','F16'),
 ('Supplementary Fig  1f','Metastatic foci','B20:B23','C20:C23','F20','F24'),
 ('Supplementary Fig  1g','Lung weight','B3:B12','C3:C12','F3','F7'),
 ('Supplementary Fig  1g','Metastatic burden (%)','B15:B24','C15:C24','F15','F19'),
 ('Supplementary Fig  1g','Metastatic foci','B28:B37','C28:C37','F28','F32'),
 ('Supplementary Fig  1h','Serum creatine (diet)','C4:C7','D4:D7','F4','F8'),
 ('Supplementary Fig  1i','Lung weight (diet)','B3:B6','C3:C6','F3','F7'),
 ('Supplementary Fig  1i','Metastatic burden (%) (diet)','B11:B14','C11:C14','F11','F15'),
 ('Supplementary Fig  1i','Metastatic foci (diet)','B18:B21','C18:C21','F18','F22'),
 ('Supplementary Fig  1k','Lung weight','B4:B13','C4:C13','G4','G8'),
 ('Supplementary Fig  1k','Metastatic burden (%)','B16:B25','C16:C25','G16','G20'),
 ('Supplementary Fig  1k','Metastatic foci','B29:B38','C29:C38','G29','G33'),
 ('Supplementary Fig  3a','WBC','B4:B8','C4:C8','F4','F8'),
 ('Supplementary Fig  3a','Lymphocyte','B12:B16','C12:C16','F12','F16'),
 ('Supplementary Fig  3a','Monocyte','B20:B24','C20:C24','F20','F24'),
 ('Supplementary Fig  3a','RBC','B28:B32','C28:C32','F28','F32'),
 ('Supplementary Fig  5c','MK creatine CKB-OE','B5:B7','C5:C7','F5','F9'),
 ('Supplementary Fig  5c','MK PCr CKB-OE','B13:B15','C13:C15','F13','F17'),
 ('Supplementary Fig  8a','BMI d0 vs d14','C4:C14','D4:D14','G5','G9'),
]

# Metastatic burden series (vehicle vs creatine arms) for cross-experiment synthesis
BURDEN = [
 ('Fig. 1b','B3:B8','C3:C8','model A (Fig.1a-c)'),
 ('Fig. 1f','B22:B27','C22:C27','melanoma sh-scrambled (Fig.1f)'),
 ('Fig. 1f','D22:D27','E22:E27','melanoma sh-Slc6a8 (Fig.1f)'),
 ('Fig. 1k','B4:B9','C4:C9','model B (Fig.1j-l)'),
 ('Fig. 3i','B10:B13','C10:C13','Pf4-Cre;Slc6a8+/+ (Fig.3i)'),
 ('Fig. 6b','B4:B8','C4:C8','DMSO arms (Fig.6b)'),
 ('Supplementary Fig  1e','B13:B18','C13:C18','Supp.1e'),
 ('Supplementary Fig  1f','B12:B15','C12:C15','Supp.1f'),
 ('Supplementary Fig  1g','B15:B24','C15:C24','Supp.1g'),
 ('Supplementary Fig  1i','B11:B14','C11:C14','Supp.1i (5% diet)'),
 ('Supplementary Fig  1k','B16:B25','C16:C25','Supp.1k'),
 ('Supplementary Fig  2d','C5:C10','D5:D10','Supp.2d donor-PLT transfer (mouse donors)'),
 ('Fig. 7g','B12:B16','C12:C16','Fig.7g human donor PLT d0 vs d7'),
]
