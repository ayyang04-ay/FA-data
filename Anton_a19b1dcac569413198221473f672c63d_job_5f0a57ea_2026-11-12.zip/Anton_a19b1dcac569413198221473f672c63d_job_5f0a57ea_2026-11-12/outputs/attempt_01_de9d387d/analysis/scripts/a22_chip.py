import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from data import rng
sets = {'P2ry12 (Fig.5j)': ('Fig. 5j', 5), 'Gp6 (Fig.5j)': ('Fig. 5j', 15), 'Rab4a (S6i)': ('Supplementary Fig  6i', 7)}
for name,(sh,r0) in sets.items():
    print('==', name)
    rows=[]
    if sh=='Fig. 5j':
        regs = ['Exon','2K','1K','0.2K']; vcols=('B','D'); ccols=('E','G')
    else:
        regs = ['Exon','2K','1K','0.2K']; vcols=('C','E'); ccols=('F','H')
    for i,reg in enumerate(regs):
        r = r0+i
        v = rng(sh, f'{vcols[0]}{r}:{vcols[1]}{r}'); c = rng(sh, f'{ccols[0]}{r}:{ccols[1]}{r}')
        print(f'  {reg:5s} veh {np.round(v,2)} cre {np.round(c,2)}  diff {c.mean()-v.mean():+.2f}  ratio {c.mean()/v.mean():.2f}  t-test p={stats.ttest_ind(c,v).pvalue:.4f}')
        for x in v: rows.append(dict(reg=reg, cre=0, y=x))
        for x in c: rows.append(dict(reg=reg, cre=1, y=x))
    d = pd.DataFrame(rows)
    m = smf.ols('y ~ C(reg)*cre', d).fit()
    # Sidak-like: per-region contrasts using pooled residual
    for reg in regs:
        sub = d[d.reg==reg]
        diff = sub[sub.cre==1].y.mean()-sub[sub.cre==0].y.mean()
        se = np.sqrt(m.scale*(2/3)); t = diff/se; p = 2*stats.t.sf(abs(t), m.df_resid); ps = 1-(1-p)**4
        print(f'     pooled-variance contrast {reg}: diff={diff:+.2f} p={p:.2e} Sidak(4)={ps:.2e}')
