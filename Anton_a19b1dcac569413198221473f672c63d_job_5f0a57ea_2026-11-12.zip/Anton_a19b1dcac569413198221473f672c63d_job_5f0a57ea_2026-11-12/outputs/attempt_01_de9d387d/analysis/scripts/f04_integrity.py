import numpy as np, pandas as pd, matplotlib, pickle
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from data import rng
fig, axes = plt.subplots(1,3, figsize=(15,4.8))
# A: 6b vs S2d
ax=axes[0]
b6v = rng('Fig. 6b','B4:B8'); b6c = rng('Fig. 6b','C4:C8'); s2v = rng('Supplementary Fig  2d','C5:C10'); s2c = rng('Supplementary Fig  2d','D5:D10')
f6v = rng('Fig. 6b','B13:B17'); f6c = rng('Fig. 6b','C13:C17'); f2v = rng('Supplementary Fig  2d','C14:C19'); f2c = rng('Supplementary Fig  2d','D14:D19')
for arr, x0, lab, col in [(b6v,0,'6b vehicle','k'),(s2v,1,'S2d vehicle-donor PLT','k'),(b6c,2.5,'6b creatine','crimson'),(s2c,3.5,'S2d creatine-donor PLT','crimson')]:
    ax.scatter(np.full(len(arr),x0)+np.linspace(-0.15,0.15,len(arr)), arr, color=col, s=22, zorder=3)
# connect identical values
for v in b6v:
    if np.any(np.isclose(s2v,v)):
        i = list(b6v).index(v); j = int(np.where(np.isclose(s2v,v))[0][0])
        ax.plot([0+np.linspace(-0.15,0.15,5)[i], 1+np.linspace(-0.15,0.15,6)[j]],[v,v], color='orange', lw=1.5)
for v in b6c:
    if np.any(np.isclose(s2c,v)):
        i = list(b6c).index(v); j = int(np.where(np.isclose(s2c,v))[0][0])
        ax.plot([2.5+np.linspace(-0.15,0.15,5)[i], 3.5+np.linspace(-0.15,0.15,6)[j]],[v,v], color='orange', lw=1.5)
ax.set_xticks([0,1,2.5,3.5]); ax.set_xticklabels(['Fig.6b\nvehicle','Supp.2d\nveh-donor','Fig.6b\ncreatine','Supp.2d\ncre-donor'], fontsize=8)
ax.set_ylabel('Metastatic burden (%)')
ax.set_title('A. Two different experiments share 3+3 animals\n(identical burden to 6-7 digits AND identical foci counts; orange links)', fontsize=9)
# B: human blot reported vs image
ax=axes[1]
rep = {'GP6': np.column_stack([rng('Fig. 7e', f'{c}4:{c}7') for c in 'BCDE']), 'P2RY12': np.column_stack([rng('Fig. 7e', f'{c}12:{c}15') for c in 'BCDE'])}
res = pickle.load(open('densito2.pkl','rb'))
for prot, mk in [('GP6','o'),('P2RY12','s')]:
    for vi,v in enumerate(['V1','V2','V3','V4']):
        r = res[(v,prot)]/res[(v,'ACTB')]; rr = r/r[0]; rp = rep[prot][vi]/rep[prot][vi][0]
        for t,tp in enumerate(['d3','d7','d14']):
            ax.scatter(rp[t+1], rr[t+1], marker=mk, color=['#1b9e77','#d95f02','#7570b3','#e7298a'][vi], s=28)
        ax.annotate(f'{v} {prot} d14', (rp[3], rr[3]), fontsize=6.5, xytext=(3,3), textcoords='offset points')
lim=[0.3,6]; ax.plot(lim,lim,'k:'); ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(lim); ax.set_ylim(lim)
import matplotlib.ticker as mt
for axis in (ax.xaxis, ax.yaxis):
    axis.set_major_locator(mt.FixedLocator([0.5,1,2,4])); axis.set_major_formatter(mt.FixedFormatter(['0.5','1','2','4'])); axis.set_minor_formatter(mt.NullFormatter())
ax.set_xlabel('Reported fold vs d0 (Fig. 7e quantification)'); ax.set_ylabel('Fold vs d0 from displayed blot (Supp. 8d, approx. densitometry)')
ax.set_title('B. Human platelet blots: displayed images vs reported ratios\n(circles GP6, squares P2RY12; colours = volunteers)', fontsize=9)
# C: Fig 7d non-reproducible normalisations
ax=axes[2]
d7 = pickle.load(open('fig7d.pkl','rb'))
pts=[]
for gene,(d,repn) in d7.items():
    for tp in ['3d','7d','14d']:
        calc = (2**d[tp]).mean(0)/(2**d['0d']).mean(0)
        for vol in range(4):
            pts.append((gene,tp,vol,repn[tp][vol],calc[vol]))
P = pd.DataFrame(pts, columns=['gene','tp','vol','reported','recalc'])
ok = np.isclose(P.reported, P.recalc, rtol=0.02)
ax.scatter(P.reported[ok], P.recalc[ok], s=10, color='grey', label=f'reproduced (n={ok.sum()})')
ax.scatter(P.reported[~ok], P.recalc[~ok], s=30, color='crimson', label=f'not reproduced (n={(~ok).sum()})')
for _,r in P[~ok].iterrows(): ax.annotate(f"{r.gene} V{r.vol+1} {r.tp}", (r.reported, r.recalc), fontsize=6.5, xytext=(3,-8), textcoords='offset points')
lim=[0.02,50]; ax.plot(lim,lim,'k:'); ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(lim); ax.set_ylim(lim)
ax.set_xlabel('Reported "after normalization" (Fig. 7d)'); ax.set_ylabel('Recomputed from the sheet\'s own ΔCt')
ax.legend(fontsize=7, loc='upper left')
ax.set_title('C. Human CD41+ qPCR: 6/132 values cannot be reproduced\n(PITPNB V4 ΔCt are raw-Ct-like (+26–28); RAB27B V4)', fontsize=9)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/P4_integrity_checks.png', dpi=200)
print(P[~ok])
