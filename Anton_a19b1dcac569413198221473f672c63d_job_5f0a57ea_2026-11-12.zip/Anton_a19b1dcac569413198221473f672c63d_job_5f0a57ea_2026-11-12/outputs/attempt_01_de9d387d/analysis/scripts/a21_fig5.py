import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from data import rng
for sh in ['Fig. 5e','Fig. 5f']:
    print('==', sh)
    cols = {'WT':'N','S127A':'O','3A':'P','S127D':'Q'}
    rows=[]
    for m,c in cols.items():
        v = rng(sh, f'{c}4:{c}6'); cr = rng(sh, f'{c}17:{c}19')
        t = stats.ttest_ind(cr, v)
        print(f'  {m:6s} vehicle {np.round(v,3)} mean {v.mean():.3f} | creatine {np.round(cr,3)} mean {cr.mean():.3f} | ratio {cr.mean()/v.mean():.2f} p={t.pvalue:.3f}')
        for x in v: rows.append(dict(mut=m, cre=0, y=np.log(x)))
        for x in cr: rows.append(dict(mut=m, cre=1, y=np.log(x)))
    d = pd.DataFrame(rows)
    sub = d[d.mut.isin(['WT','S127A'])].copy(); sub['A'] = (sub.mut=='S127A').astype(int)
    m = smf.ols('y~A*cre', sub).fit()
    print(f'  interaction S127A x creatine (log ratio): {m.params["A:cre"]:.3f} p={m.pvalues["A:cre"]:.3f}')
