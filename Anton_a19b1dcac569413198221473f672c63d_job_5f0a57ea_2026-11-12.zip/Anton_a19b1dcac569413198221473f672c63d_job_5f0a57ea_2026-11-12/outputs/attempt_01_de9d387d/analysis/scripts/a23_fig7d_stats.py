import numpy as np, pickle, pandas as pd
from scipy import stats
data = pickle.load(open('fig7d.pkl','rb'))
rows=[]
for gene,(d,rep) in data.items():
    base = d['0d'].mean(0)
    for tp in ['3d','7d','14d']:
        l2 = d[tp].mean(0) - base   # log2FC per volunteer from the sheet's dCT (recomputed)
        flag = ''
        if gene=='PITPNB': flag='V4 raw-Ct entries (excluded)'
        if gene=='PITPNB': l2 = l2[:3]
        n_up = int(np.sum(l2>0)); n=len(l2)
        p = stats.ttest_1samp(l2,0).pvalue if n>2 else np.nan
        rows.append(dict(gene=gene, time=tp, per_volunteer_log2FC=np.round(l2,2).tolist(), n_up=f'{n_up}/{n}', geomean_FC=2**l2.mean(), p_paired=p, note=flag))
df = pd.DataFrame(rows)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',60)
print(df.to_string(float_format=lambda x: f'{x:.3g}'))
df.to_csv('human_CD41_qpcr_recalc.csv', index=False)
