import numpy as np, pickle
from fractions import Fraction
data = pickle.load(open('fig7d.pkl','rb'))
def kden(x):
    f = Fraction(float(x)); d = f.denominator; k = d.bit_length()-1
    return k if d == 2**k else 99
for gene,(d,rep) in data.items():
    for tp in d:
        for vol in range(4):
            for tr in range(3):
                x = d[tp][tr,vol]
                k = kden(x)
                if k>24:
                    print(gene, tp, f'V{vol+1}', f'tech{tr+1}', repr(x), 'k=',k, ' x-f32=', x-float(np.float32(x)))
# technical replicate spread (SD of dCT) per volunteer/timepoint; flag > 0.5
print("\nTechnical-replicate SD of dCT > 0.5 cycles:")
for gene,(d,rep) in data.items():
    for tp in d:
        sd = d[tp].std(0, ddof=1)
        for vol in range(4):
            if sd[vol] > 0.5:
                print(f'  {gene:7s} {tp:4s} V{vol+1}: dCTs={np.round(d[tp][:,vol],2)} SD={sd[vol]:.2f}')
