import numpy as np, openpyxl, re
from qpcr_parse import parse_qpcr
def is_f32(x):
    return float(np.float32(x)) == x
def is_2dec(x, tol=1e-9):
    return abs(x*100 - round(x*100)) < 1e-6 or abs(x*1000 - round(x*1000)) < 1e-6
for s in ['Fig. 2f','Fig. 3f','Fig. 4e','Fig. 4h','Fig. 4j','Fig. 4l','Fig.6a','Fig. 6g','Supplementary Fig  2a','Supplementary Fig  3c','Supplementary Fig  4e','Supplementary Fig  8c']:
    b = parse_qpcr(s)
    print('==', s)
    for g, d in b.items():
        for lab, lst in d.items():
            for col, v in lst[:1]:
                kinds = ['f32' if is_f32(x) else ('2dec' if is_2dec(x) else 'f64-other') for x in v]
                if any(k=='f64-other' for k in kinds) or s=='Fig. 3f':
                    print(f'   {g:8s} {lab}: {[repr(x) for x in v]} -> {kinds}')
