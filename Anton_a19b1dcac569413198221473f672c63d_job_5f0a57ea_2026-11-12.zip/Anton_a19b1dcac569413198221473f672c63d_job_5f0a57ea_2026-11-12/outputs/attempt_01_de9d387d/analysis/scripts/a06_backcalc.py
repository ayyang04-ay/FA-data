import numpy as np
from fractions import Fraction
from qpcr_parse import parse_qpcr
def kden(x):
    f = Fraction(float(x)); d = f.denominator; k = d.bit_length()-1
    return k if d == 2**k else 99
b = parse_qpcr('Fig. 3f')
genes = ['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Rab4a']
for g in genes:
    d1 = b[g]['ΔCT1'][0][1]; d2 = b[g]['ΔCT2'][0][1]
    for i in range(3):
        x = d2[i]
        found = []
        # additive decimal constants
        for c100 in range(-500, 501):
            c = c100/100
            y = x - c
            if kden(y) <= 24: found.append(('add', c, y))
        for c1000 in range(-5000, 5001):
            c = c1000/1000
            y = x - c
            if kden(y) <= 24 and not any(abs(f[1]-c)<1e-12 for f in found): found.append(('add3', c, y))
        # multiplicative
        for m100 in range(50, 301):
            m = m100/100
            y = x / m
            if kden(y) <= 24: found.append(('mul', m, y))
        print(g, i+1, repr(x), 'ddCT=', repr(x-d1[i]), 'k=', kden(x), '->', found[:6])
