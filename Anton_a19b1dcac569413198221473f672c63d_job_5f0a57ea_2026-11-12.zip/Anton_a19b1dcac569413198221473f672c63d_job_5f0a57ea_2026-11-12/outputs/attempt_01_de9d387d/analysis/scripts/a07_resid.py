import numpy as np
from qpcr_parse import parse_qpcr
b = parse_qpcr('Fig. 3f')
for g in ['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Rab4a']:
    d1 = b[g]['ΔCT1'][0][1]; d2 = b[g]['ΔCT2'][0][1]
    for i in range(3):
        x = d2[i]
        r32 = x - float(np.float32(x))
        grid = 2**-19
        rg = x - round(x/grid)*grid
        dd = x - d1[i]
        rdd32 = dd - float(np.float32(dd))
        print(f'{g:7s} r{i+1}: x={x!r:24s} x-f32(x)={r32:.3e}  x-grid(2^-19)={rg:.3e} | ddCT={dd!r} ddCT-f32={rdd32:.3e}')
