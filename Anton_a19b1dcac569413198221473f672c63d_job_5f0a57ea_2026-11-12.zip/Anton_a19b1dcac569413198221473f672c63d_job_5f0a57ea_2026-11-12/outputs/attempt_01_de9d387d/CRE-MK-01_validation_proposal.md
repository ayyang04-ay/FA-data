**Recommendation: our primary target is megakaryocyte STAT5B, the creatine-activated switch (SLC6A8 → CKB → STAT5B) that turns on a pro-metastatic "primed-platelet" program. Next quarter's in vivo slot should go to one decisive experiment: a blinded Pf4-iCre;Stat5b-knockout × creatine metastasis study. Platelet GPVI (GP6) is the lead backup and the one candidate we could drug. Megakaryocyte SLC6A8 is the mechanistic anchor. A short raw-data audit comes before the slot.**

**What we are asking the committee to approve:**
1. **Allocate the in vivo slot to Study A** (§4):
   - *Stat5b* MK-knockout × creatine, 2×2, 56 mice, blinded, both sexes;
   - plus the platelet-transfer module if capacity allows.
2. **A 4-week Gate 0 before dosing starts:**
   - reconcile the raw data behind the flagged panels;
   - validate a GPVI-blocking agent in-house;
   - expand the colony and pre-register the study.
3. **Start protocol development for a placebo-controlled human platelet-priming study** (Study H1) at maintenance doses. The slot is not needed for this.

---

# CRE-MK-01 follow-up: validation proposal to the portfolio committee

**Sources:** `CRE-MK-01_source_data.xlsx` (87 sheets, incl. 26 embedded blot images), `CRE-MK-01_phosphoproteomics.xlsx`, `study_conventions.pdf`.

**How the numbers were produced.** Every number below was re-derived from the raw cell values. Scripts and tables are in `analysis/`, figures in `figures/`.

**Scope of evidence.** External literature was not used as evidence. Two pieces of conventional pharmacology are used for interpretation only, and are labelled as assumptions:
- the usual agonist → receptor mapping in aggregometry;
- the existence of GPVI-blocking agents.

---

## 1. Decision summary

### 1.1 Why STAT5B, and why it gets the slot now

1. **The phenomenon itself is robust in our hands.**
   - All 11 vehicle-vs-creatine arms show more lung metastasis (10 experiments; gavage and diet; male C57BL/6J and female BALB/cJ).
   - Pooled effect: metastatic burden ×3.16 (95% CI 2.68–3.73); foci ×2.04 (1.77–2.36).
   - Survival hazard ratio 2.9 (Fig. 1c) and 2.3 (Fig. 1l).
2. **The effect runs through the host megakaryocyte (MK), not the tumour.**
   - MK-specific *Slc6a8* deletion removes it. Ratio-of-ratios 0.22 (0.11–0.47), p = 0.0009, even though serum creatine rises equally.
   - Tumour *Slc6a8* knockdown does not remove it (0.77, 0.39–1.53).
   - Platelets from volunteers after 7 days of creatine transfer the effect into mice (×2.8, n = 5/5).
3. **STAT5B is where the mechanism converges.**
   - Creatine induces an 11-gene platelet program in MKs, 2–5× up.
   - That induction needs CKB (siRNA), STAT5 (inhibitor) and *Stat5b* (MK knockout).
   - Creatine raises STAT5B occupancy at the *P2ry12*, *Gp6* and *Rab4a* promoters.
4. **There is no valid in vivo metastasis test of STAT5B yet.**
   - The only one (Fig. 6b, systemic STAT5-IN-1) has three vehicle and three creatine animals whose burden and foci values are identical to those in a different experiment (Supp. Fig. 2d); see §3, I1.
   - An MK-specific *Stat5b* line already exists (Fig. 6d–g), and *Stat5b* loss leaves MK creatine uptake intact (Fig. 6e).
   - So one 2×2 experiment isolates the transcriptional step and gives a clear go/no-go inside a quarter.
5. **The human data support platelet priming, but point to GPVI and α2A, not P2Y12.** Paired re-analysis of Fig. 7c, day 14 vs baseline, Holm-adjusted over 12 endpoints:
   - epinephrine responses ×1.6–2.1 (p ≤ 0.02; 10–11 of 11 volunteers up);
   - collagen max/average aggregation ×2.5–2.7 (p = 0.044);
   - ADP responses flat (×1.07–1.17, p = 0.96).
   - → This makes GPVI the effector to carry as backup and de-prioritises P2Y12.
6. **Why not the alternatives as primary:**
   - **SLC6A8** is the best-evidenced node, but it is not a drug target (systemic creatine transport), and its key experiment is already in hand. We replicate it rather than spend the slot on it.
   - **CKB** has no in vivo data and no MK model.
   - **Aspirin's** only support (Supp. Fig. 2d) is compromised by the same data-sharing issue as Fig. 6b.

### 1.2 Candidate ranking

| Rank | Candidate | Role | Strongest uncompromised evidence | Principal gap | Testable in vivo next quarter | Call |
|---|---|---|---|---|---|---|
| 1 | **MK STAT5B** | Transcriptional switch | *Stat5b* cKO: no creatine program (6g) with uptake intact (6e); STAT5i blocks program (6a; interaction significant 9/11 genes); promoter occupancy ↑ (5j, S6i); S127-dependent creatine phospho-signal (5e; interaction p = 0.036) | No valid in vivo metastasis test (6b flagged); no KO-vehicle arm; phosphoproteomic nomination not FDR-significant; S127 not site-verified | **Yes** (line exists) | **PRIMARY: the slot** |
| 2 | **Platelet GPVI (GP6)** | Effector receptor | Among the top-induced MK transcripts (×5.6 in 2f, ×11.6 in 4h, ×42 in 6a); STAT5B occupancy at *Gp6* promoter (×3.8, ×2.9); human collagen response ×2.5 and GP6 protein ×2.6 (n = 4) | No functional test; one of 11 co-induced genes; displayed human blots support direction but not magnitude (I6) | Yes, once a blocking agent is validated in-house | **LEAD BACKUP** (druggable, platelet-restricted) |
| 3 | **MK SLC6A8** | Entry gate | MK cKO removes metastasis effect (3i); liposomal bypass restores program in cKO MKs (S4e) | Not druggable for this purpose; n = 4/group, single experiment | Yes (replication) | **ANCHOR**: replicate; platelet/MK creatine as exposure biomarker |
| 4 | **CKB** | Upstream kinase | siRNA attenuates (interaction significant 10/11 genes); over-expression is sufficient without changing creatine/PCr (4l, S5c) | In vitro only; no MK model | No | LATER |
| – | P2Y12 | Effector | Mouse transcript ↑; STAT5B occupancy | Human ADP response flat at all time points; displayed blots inconsistent | – | De-prioritise |
| – | COX-1 / aspirin | Broad antiplatelet | S2d (flagged) | Human AA responses not significant after multiplicity; not mechanism-specific | – | Benchmark arm only |
| – | STAT5-IN-1 | Tool | 6a | Systemic, hits STAT5A+B; canonical pY694/699 not detectable in MKs (S6a) | – | Tool only |

![Proposal Fig. P5. Evidence map](figures/P5_mechanism_evidence_map.png)

---

## 2. What the data package establishes (re-derived)

### 2.1 Creatine increases lung metastasis: robust, replicated, host-level

**Method.** For each vehicle-vs-creatine arm, I computed the ratio of geometric means from per-animal log values with a Welch SE, then pooled arms with DerSimonian–Laird random effects (proposal Fig. P1A; table T2).

**Metastatic burden (11 arms).**
- Pooled ×3.16 (2.68–3.73); I² = 55%; 95% prediction interval for a new experiment 1.95–5.13.
- Every arm is individually positive, with ratios from ×2.14 (Supp. 1e) to ×4.26 (Supp. 1g).
- Excluding the flagged Fig. 6b arm changes nothing (×3.03).

**Foci.** ×2.04 (1.77–2.36).

**Lung weight and PET.** Consistent: lung weight ×1.2–1.65; PET SUV-BW ×1.3–2.1 (1a, 1f, 1j).

**Survival** (Cox model, no censoring):
- Fig. 1c: HR 2.93 (1.04–8.23), median 21 → 18 d, log-rank p = 0.032.
- Fig. 1l: HR 2.28 (1.16–4.46), median 16 → 14 d, p = 0.011.

**Routes.** Oral gavage and a 5% creatine diet (Supp. 1h–i: ×3.53) give the same effect.

**Timing.** The effect appears after tumour cells arrest, not at arrest.
- Lung signal at 15 min: ×0.86 (p = 0.31).
- 6 h: ×1.51 (p = 0.0002). 12 h: ×1.79 (p = 0.026). 24 h: ×2.76 (p = 0.004).
- This fits protection of arrested tumour cells, the phase in which platelets act.

**No haematological confounding.**
- Platelet count, MPV, PDW and PCT are unchanged in every mouse experiment (2a, S4b, S7a, S7b) and in humans (S8b).
- WBC/RBC, food and water intake, and body weight show no significant change (S1a–c, S3a; body weight at d7 ×1.06, p = 0.08).

**Arithmetic check.** All 63 reported two-group tests and all reported Tukey/Sidak/Dunnett comparisons reproduce exactly from the raw cells (T1). The issues in §3 concern data provenance and design, not arithmetic.

**Caveats from the conventions:**
- Allocation and readout were not masked.
- There was no formal sample-size calculation.
- Sex is confounded with strain (male B6, female BALB/c).
- The early-timepoint design implies experimental (intravenous-type) colonisation. Spontaneous metastasis from an orthotopic primary has not been tested.

![Proposal Fig. P1. Creatine effect across experiments (A) and which perturbations remove it (B)](figures/P1_metastasis_forest.png)

### 2.2 The effect is host- and megakaryocyte-dependent

All estimates here are log-scale two-way models; the key quantity is the ratio of creatine effects between strata (ratio-of-ratios; table T3).

| Perturbation (panel) | Creatine effect, control stratum | Creatine effect, perturbed stratum | Ratio-of-ratios (95% CI), p |
|---|---|---|---|
| MK *Slc6a8* cKO, Pf4-Cre (3i): burden | ×3.56 (2.10–6.01) | ×0.79 (0.47–1.34) | **0.22 (0.11–0.47), p = 0.0009** |
| Same: foci / lung weight | ×1.97 / ×1.21 | ×0.89 / ×1.01 | 0.45, p = 0.023 / 0.84, p = 0.0002 |
| Same: serum creatine (3b) | ×2.69 | ×2.45 | 0.91, p = 0.32 (exposure equal) |
| Same: MK creatine (3c; n = 3) | ×4.9 | ×1.7 | 0.34, p = 0.065 (under-powered) |
| Tumour *Slc6a8* shRNA (1f): burden | ×4.07 | ×3.16 | 0.77 (0.39–1.53), p = 0.44 |
| Systemic STAT5-IN-1 (6b): burden | ×4.08 | ×1.30 | 0.32 (0.19–0.54), p = 0.00035, **flagged (I1)** |

**Uptake is the necessary step.** In *Slc6a8*-cKO MKs, free creatine does not induce the program, but liposome-delivered creatine does (significant in 9 of 11 genes; S4e).

**Platelets carry the activity.**
- Day-7 vs day-0 volunteer platelets transferred into mice (7g): burden ×2.76 (1.73–4.39), foci ×1.81, lung weight ×1.27 (n = 5 recipients per group; donor structure not recorded).
- The equivalent mouse-donor experiment (S2d, including the aspirin arm) is flagged (I1).

**Caveats:**
- The 3i result is a single experiment with n = 4 per group.
- SLC6A8 protein loss in cKO MKs is partial on the blot (S4a).
- Tumour knockdown is convincing at mRNA level (11–30% remaining, S2a) but not visibly at protein level. The tumour-independence inference is therefore moderate.

### 2.3 What the MK does with creatine: one program, one switch

**Method.** For every qPCR panel I recomputed log2 fold-changes from ΔCt and ran t-tests on ΔCt (n = 3 per group), with interaction models where the design allows (T4, proposal Fig. P2). The sheets' own normalisation mixes two references: vehicle is normalised to its own mean, treatment to the paired vehicle replicate. ΔCt analysis avoids this.

**Induction.** Creatine induces all 11 platelet-activation genes:

| Gene | *Itga2b* | *P2ry12* | *Gp6* | *Gp1ba* | *F2r* | *Adra2a* | *Fcgr2a* | *Runx1* | *Rab4a* | *Rab27b* | *Pitpnb* |
|---|---|---|---|---|---|---|---|---|---|---|---|
| log2 FC, MK in vivo (2f) | 1.6 | 1.6 | 2.5 | 1.8 | 0.7 | 1.4 | 2.2 | 1.2 | 2.0 | 1.6 | 1.5 |

- The same induction reproduces in 3f, 4h, 4j, 6a and 6g.
- MK differentiation markers (*Gata1*, *Nfe2*, *Zfpm1*, *Itgb3*, *Tubb1*, *Lims1*) are unchanged (S3c). This argues against a simple maturation shift.

**Requirements and sufficiency:**

| Test | Result |
|---|---|
| *Slc6a8* cKO (3f) | Interaction significant for 7/11 genes |
| si-*Ckb* (4j) | Interaction significant for 10/11 genes (partial: residual induction 0–1.7 log2) |
| STAT5-IN-1 (6a) | Interaction significant for 9/11 genes; the inhibitor also lowers basal expression of several genes, so it is not creatine-specific |
| *Stat5b* cKO + creatine vs WT + creatine (6g) | 0.7–2.9 log2 lower, all 11 genes p < 0.05 |
| Phosphocreatine (4h) | Does not induce the program (several genes fall) |
| CKB over-expression (4l) | Induces all 11 genes (0.8–2.6 log2) without changing MK creatine (×0.97) or PCr (×1.25, ns; S5c) |

**Interpretation.** Creatine → CKB → STAT5B acts as a signalling switch, not as an energetic (PCr) effect.

![Proposal Fig. P2. MK transcript program, induction and loss-of-function](figures/P2_MK_program_heatmap.png)

### 2.4 STAT5B specifically: what is solid and what is not

**Phosphoproteomics (the nomination).**
- 5,812 phosphopeptides from 2,033 genes; none passes FDR (minimum q = 0.167; Benjamini–Hochberg 0.25).
- 238 peptides have p < 0.05, against ~290 expected by chance.
- 1,702 rows (29%) carry the identical p = 0.42265. This is the Welch result for t = 1, df = 2, i.e. a peptide seen in a single replicate and imputed elsewhere. It is not the "Student's t-test" stated in the header.
- The *Stat5b* peptide ranks 17/5,812 (p = 0.0012, q = 0.25, log2FC +5.7; a second *Stat5b* peptide is unchanged). No site is given, so S127 cannot be verified from the file.
- CKB, SLC6A8, GP6, P2Y12 and RAB4A were not detected.
- **Verdict:** hypothesis-generating only.

**S127 mutants (pan-phospho/FLAG).**
- Creatine raises wild-type STAT5B signal ×1.39 (p = 0.009; 5e) and ×1.28 (p = 0.086; 5f).
- It does not raise S127A (×1.06 / ×0.88); interaction p = 0.036 / 0.052.
- Caveats: effect sizes are modest; the readout is not site-specific; S127D is elevated at baseline (×1.46), which a phospho-serine readout cannot attribute to S127 itself.
- The direct WT-vehicle vs WT-creatine comparison was never tested in the sheets (separate ANOVAs).

**Canonical STAT5 activation absent.** STAT5 Y694/699 phosphorylation is undetectable in MKs with or without creatine, while the IL-2 Jurkat positive control works (S6a). How STAT5-IN-1 acts in MKs, where the canonical tyrosine-phosphorylated form is absent, is therefore unresolved; the package has no target-engagement readout for it.

**Nuclear STAT5B and promoter occupancy.**
- Nuclear STAT5B increases (S6h, n = 2).
- Promoter occupancy increases:
  - *P2ry12*: ×4.7–12 at −0.2/−1/−2 kb, Sidak p < 1×10⁻⁴;
  - *Gp6*: ×3.8 (−1 kb) and ×2.9 (−0.2 kb);
  - *Rab4a*: ×2.7 and ×5.5.
- Exon controls are unchanged. There is no IgG control, and exon background is 5–13% input.

**Genetics.**
- *Stat5b* cKO keeps MK creatine uptake (98 vs 95 µmol/g; 6e) but abolishes the program (6g).
- No KO-vehicle arm exists.
- No platelet-function or metastasis readout exists.
- KO-creatine mice trend to lower plateletcrit than WT-vehicle mice (0.26 vs 0.36%, p = 0.055; S7b), i.e. a possible basal phenotype.

### 2.5 Platelet phenotype (mouse)

**Aggregation.**
- Fig. 2b: ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56%.
- Fig. 3d: in WT, creatine raises aggregation ×1.12–1.22. In *Slc6a8*-cKO it *lowers* aggregation (ADP ×0.58); this is unexplained.
- Both datasets carry integrity flags (I2, I3).

**Thromboelastography.** Only maximum amplitude changes (39.7 → 54.0 mm, p = 0.049); R, K and α are unchanged.

**α-granules, platelet–tumour association and early seeding** are all higher:
- α-granules ~×2 (2c; also seen in WT but absent in *Slc6a8*-cKO, S4c);
- PKH⁺ area ×2.4 (2j);
- GFP⁺ cells/field ×2.2 (1i).

These use microscope fields as n (I9).

**In vivo platelet blot (2e)** is unquantified. Approximate densitometry of the displayed image suggests at most a modest GP6 change (~×1.4); P2RY12 and β-actin bands appear saturated. In vitro creatine does not change platelet GP6/P2RY12 (2i bottom), but does change MK levels (2i top). This fits an MK-level (inherited) rather than platelet-level effect.

### 2.6 Human cohort (11 healthy Asian volunteers, 20–25 y, 20 g/day × 14 d, no control arm)

**Exposure.**
- Serum creatine 45 → 153 / 156 / 159 µM at days 3 / 7 / 14 (×3.4–3.5; paired p = 4×10⁻⁸).
- Platelet indices and BMI unchanged (S8a–b).

**Platelet function (proposal Fig. P3; T5).**
- **Original analysis problem.** The sheet fixes day-0 at 1 with zero variance and applies ordinary ANOVA plus Dunnett's test to repeated measures.
- **Re-analysis method.** Paired analysis of day-14 fold-changes: Wilcoxon signed-rank, Holm over 12 endpoints.
- **Epinephrine:**
  - max ×1.63, p = 0.020;
  - average ×1.82, p = 0.012;
  - adhesion ×2.11, p = 0.012;
  - 10–11/11 volunteers up, already evident at day 7.
- **Collagen:**
  - max ×2.51, p = 0.044;
  - average ×2.72, p = 0.044;
  - adhesion ×1.68, p = 0.19.
- **Arachidonic acid:** ×1.3–1.8, p ≥ 0.13.
- **ADP:** ×1.07–1.17, p = 0.96 (flat at every time point).
- Friedman tests agree: EPI p ≤ 4×10⁻⁴; collagen p ≈ 0.05–0.07; ADP p ≥ 0.25.
- **Interpretation.** Under the conventional mapping (collagen → GPVI; EPI → α2A; ADP → P2Y12/P2Y1), the human signal points to GPVI and α2A, not P2Y12.

![Proposal Fig. P3. Human platelet function, paired re-analysis](figures/P3_human_platelet_function.png)

**Platelet proteins (7e, n = 4; paired re-analysis).**
- GP6 ×2.62 at d14 (p = 0.021; 4/4 up).
- P2RY12 ×1.72 (p = 0.044).
- Densitometry of the displayed blots (S8d) supports the GP6 direction in 4/4 (×1.4–3.0) but not its magnitude in V3 (×1.4 vs 4.98 reported). It does not support a consistent P2RY12 rise (V3 ×0.8, V2 ×1.15, V4 ×1.1) (I6).

**CD41⁺ transcripts (7d, n = 4, recomputed from ΔCt).**
- *ADRA2A*: 4/4 up at d7 (×20, p = 0.0005) and d14 (×4.0, p = 0.03).
- *GP6*: 4/4 up at d7 (×6.9).
- *P2RY12*: 3/4 up.
- *RAB4A*: down in 4/4 at d14 (×0.36, p = 0.002), opposite to the mouse.
- Volunteer 2 is largely a non-responder.
- Six values cannot be reproduced (I5).

**Human platelets → mouse metastasis (7g):** ×2.8 (above), n = 5/5. Donor structure is not recorded.

### 2.7 Exposure translation (for indication relevance)

**Doses per kg are similar.**
- Mouse gavage: 17 mg per dose three times weekly, ≈ 0.34 g/kg/day averaged (body weight ~21.5 g, S1a).
- Volunteers: 20 g/day ≈ 0.35 g/kg/day (mean weight 57.6 kg).

**Serum exposure is also similar.**
- Mouse ×2.4–2.9, reaching 178–239 µM (3b, S1d).
- Human ×3.4, reaching ~155 µM.

**Exposure appears to saturate.** The 5% diet (≈ 6–7 g/kg/day at ~2.9 g chow/day) gives the same serum rise (×2.9, S1h).

**Consequence.** Every dataset sits at loading-dose exposure. Whether typical maintenance intake (3–5 g/day) primes platelets is unknown, and this decides how broad any population/indication claim can be.

---

## 3. Data-integrity and analysis findings (audit of the raw cells)

These change what we can rely on and are built into the plan (full table: T7; proposal Fig. P4).

| ID | Panel(s) | Finding | Severity |
|---|---|---|---|
| **I1** | **6b vs S2d** | Three vehicle and three creatine animals have **identical metastatic burden (6–7 significant digits) and identical foci counts, in the same order**, in two different experiments (STAT5-IN-1 dosing vs donor-platelet transfer). This is the only cross-sheet match not explained by instrument rounding in an exhaustive duplicate/scaled-copy scan of all 87 sheets. | **High**: voids the in vivo STAT5 pharmacology and the aspirin/transfer result until reconciled |
| **I2** | 2b | All six aggregation triplets are exact arithmetic progressions (mean−d, mean, mean+d). Joint probability ≈ 3×10⁻⁵ (Monte Carlo using each triplet's own SD). | **High** for the mouse platelet-hyperreactivity claim |
| **I3** | 3d | 11 of 12 triplets share the identical SD (pattern x, x, x±2; all even numbers). This is implausible for independent animals (P < 10⁻³ even at a true SD of 2 points). | Medium-high |
| I4 | 3f | 22/24 WT-creatine ΔCt values are **not instrument-native**: they are float32 values carrying ~10⁻¹⁴ float64 residues, whereas every other group in the panel is instrument-native. Two within-group duplicates at instrument precision (*Gp6* ΔCt3, *Fcgr2a* ΔCt4). | Medium (provenance) |
| I5 | 7d | *PITPNB* volunteer-4 "ΔCt" values are +26 to +28 (raw-Ct-like). 6/132 normalised values cannot be reproduced from the sheet's own ΔCt (e.g. *RAB27B* V4 d14 reported 2.36×, recomputed 0.49×). V3-d14 values for three genes share one non-instrument residue. | Medium |
| I6 | 7e vs S8d | Displayed blots do not support some reported human ratios. Approximate check only (JPEG; quantified blots may be replicate gels). | Medium |
| I7 | 7b, 7c, 7e, S8a | Repeated measures analysed as independent groups; zero-variance baseline. Re-analysed in §2.6. | Analysis |
| I8 | Phosphoproteomics | FDR-null; 29% single-observation artefacts; test mislabelled; no site table. | Medium |
| I9 | 1i, 2c, 2j, S4c | Microscope fields used as n; animal count not stated. | Analysis |
| I10–I12 | 5j/S6i; S2a; labels | No IgG/high background; unconvincing tumour SLC6A8 protein knockdown; minor labelling issues:<br>• "Creatinine" in 4d;<br>• "ADAR2A";<br>• si- vs sh-*Slc6a8*;<br>• X-linked *Slc6a8* written fl/fl;<br>• tumour lines not named. | Low–medium |

**Checked and not a concern:** duplicate serum-creatine values in 7b (33 of 44 values lie on a 0.354 µM grid set by absorbance resolution) and duplicate ChIP/qPCR values arising from two-decimal instrument rounding.

**Unaffected by any flag:**
- the creatine → metastasis phenotype (10 experiments);
- the *Slc6a8*-cKO metastasis result (3i);
- human serum exposure;
- the human EPI/collagen function signal (after re-analysis);
- the human-platelet transfer (7g);
- the in vitro CKB/STAT5 gene-program data, except 3f.

![Proposal Fig. P4. Integrity checks](figures/P4_integrity_checks.png)

---

## 4. Proposed studies

### Gate 0 (weeks 0–4, no animals; precondition for the slot)

**1. Raw-data reconciliation** for I1–I6:
- animal IDs, necropsy and image files for 6b/S2d;
- aggregometer traces for 2b/3d;
- qPCR run files for 3f;
- raw Ct values and uncropped quantified blots for 7d/7e;
- a site-localised phosphopeptide table.

**Outcome rules:**
- If I1 is a disclosed shared-control design, correct the record.
- If it cannot be reconciled, 6b and S2d stay void. This plan already assumes that.
- If any finding indicates manipulation, escalate under institutional policy and re-establish the core phenotype in an independent team before further investment.

**2. Colony readiness:**
- Pf4-iCre;*Stat5b*^fl/fl^ and Pf4-iCre;*Stat5b*^+/+^ littermates, both sexes;
- deletion QC (MK STAT5B loss, as in 6d);
- record strain background and syngeneic tumour compatibility.

**3. In-house validation of a GPVI-blocking agent** (needed for Module A3 and Study B). Target engagement = loss of collagen-induced aggregation and of platelet GP6 surface signal. External tools are not assumed to work in our system.

**4. Pre-registration** of hypotheses, primary endpoint, analysis model and decision rules below.

### Study A: THE IN VIVO SLOT. Is MK STAT5B required for creatine-enhanced metastasis?

| Item | Specification |
|---|---|
| Question | Does MK-specific *Stat5b* loss abolish creatine-enhanced lung metastasis and platelet priming, with creatine uptake intact? |
| Design | Randomised, blinded 2×2 factorial: genotype (Pf4-iCre;*Stat5b*^fl/fl^ vs Cre⁺ *Stat5b*^+/+^ littermates) × treatment (vehicle vs creatine, regimen as in Fig. 1). Start of dosing relative to tumour challenge fixed and recorded (not in conventions). Allocation concealed; outcome assessors blinded to genotype and treatment; animal is the unit. |
| Population | Both sexes, 7 + 7 per group, stratified randomisation by sex and litter; age-matched. **Adds the KO-vehicle group missing from 6e–g and S7b.** |
| Model / indication | The melanoma lung-colonisation model used in Fig. 1f (confirm its host strain matches the *Stat5b* line's background). Optional second syngeneic model if the colony allows. |
| Comparators | Vehicle; Cre⁺ wild-type littermates (controls for Cre effects); WT-creatine serves as the replication arm for the phenotype. |
| Primary endpoint | Lung metastatic burden (% area), blinded, log-scale. Primary test: genotype × creatine interaction (ratio-of-ratios with 95% CI). |
| Key secondary | Foci count, lung weight, PET SUV-BW if used. |
| Mechanistic / PD readouts | Serum creatine (exposure); MK creatine (uptake must be intact); 11-gene MK program; platelet aggregation to collagen, ADP, thrombin **and epinephrine** (harmonised with human); platelet GP6/P2Y12 surface levels; platelet count/PCT (KO basal phenotype); optional satellite cohort (8/group) for 24-h lung retention (Fig. 1h showed ×2.8 at 24 h). |
| Sample size | 14 per group (56 mice). 90% power for ≥75% attenuation of a ×3 effect at SD(log) 0.45 (75th percentile of 11 historical arms; median 0.34). ≥92% power for complete abrogation even at SD 0.55. Not powered for 50% partial mediation; pre-declared as "inconclusive", not negative. |
| Analysis | Linear model on log burden: genotype × treatment + sex (block); litter/cage as random effect; exploratory genotype × treatment × sex term. |
| **Module A2** (second priority) | Platelet transfer, replacing compromised S2d. Donors: WT-vehicle, WT-creatine, KO-creatine (± KO-vehicle). Washed platelets go into naive WT recipients before tumour challenge, 10 recipients per donor group, donor-to-recipient mapping recorded (donor modelled as random effect). ≥92% power for ≥70% loss of the platelet-borne effect. Tests that the activity travels with platelets and needs MK STAT5B. |
| **Module A3** (only if Gate 0-3 passes) | WT-creatine + GPVI blockade vs WT-creatine + isotype (14 each); isotype given to all core groups. Gives a head-to-head read of primary and backup in one cohort. |

### Study B: lead backup, GPVI (next slot, or A3 if capacity allows)

| Item | Specification |
|---|---|
| Question | Is the creatine effect GPVI-dependent, and does blocking GPVI capture most of the benefit of removing STAT5B? |
| Design / population | WT mice, both sexes; 2×2: vehicle vs creatine × GPVI blockade vs isotype; 14 per group (90% power for ≥50% attenuation needs 10–23/group depending on SD; 14 is adequate if SD ≤ 0.40). Optional benchmark arm: creatine + aspirin (regimen in conventions), which also re-tests the compromised S2d. |
| Human translational arm | Fig. 7g design made rigorous: ≥8 volunteers as donors, day-0 vs day-7 platelets each into separate recipients (donor = unit), ± ex vivo GPVI blockade; blinded. |
| Endpoints | As Study A. Target engagement (collagen response, GP6 surface) verified in every treated animal cohort. |

### Study C: anchor, SLC6A8 replication and exposure–response

**C1. Blinded replication of Fig. 3i**
- Both sexes. *Slc6a8* is X-linked, so record males as fl/Y and females as fl/fl.
- Second tumour model; 14 per group.

**C2. Exposure–response in WT mice**
- Vehicle plus three creatine levels, spanning serum exposure from maintenance-equivalent up to loading-equivalent. Human anchor: 20 g/day → ~155 µM.
- Primary endpoint: metastatic burden. PD: serum and MK creatine, MK program, platelet function.
- This is the study that decides whether maintenance-level use is relevant.

**Spontaneous metastasis.** Add an orthotopic model with resection before any clinical claim. The existing data only test the colonisation phase.

### Study D: CKB (non-slot; for later elevation)

- Site-specific evidence of pS127 in MKs in vivo (targeted mass spectrometry or a site-specific reagent).
- Kinase-dead CKB rescue.
- Definition of the CKB–STAT5B interface.
- MK-specific *Ckb* loss-of-function in vivo when a line is available (none listed in the conventions).

### Study H: human (parallel; separate ethics and governance)

**H1. Randomised, double-blind, placebo-controlled crossover pharmacodynamic study in healthy adults.**

| Item | Specification |
|---|---|
| Population | 18–65 y, both sexes, more than one ancestry (current cohort: Asian, 20–25 y only); no antiplatelet/NSAID use. |
| Arms | Maintenance creatine (5 g/day) vs placebo; exploratory loading arm (20 g/day × 7 d). 14–28 days per period with verified return to baseline between periods. |
| Primary endpoint | Change in EPI-induced aggregation at day 14 vs placebo (the most sensitive, most consistent signal: 10–11/11 responders). |
| Key secondary | Collagen response; platelet GP6 surface density; ADP response (pre-specified negative control); AA response; *ADRA2A* and *GP6* platelet transcripts; serum and platelet creatine; d0/3/7/14/28 kinetics and washout reversibility. |
| Sample size | ~55 completers (45–73 depending on which EPI metric is primary): 90% power to detect half of the uncontrolled single-arm effect. Halving the effect is conservative against regression to the mean and placebo effects. |

**H2.** Human-platelet → mouse transfer replication (see Study B).

**H3. Patients: observational only.**
- Population: patients with melanoma (directly modelled) and the second indication.
- Readouts: creatine-supplement use vs platelet reactivity/GP6 and circulating tumour cell–platelet association; feasibility of a pharmacoepidemiological look at supplement use vs metastasis-free survival.
- **No interventional creatine exposure in cancer patients** given the preclinical signal.

### Indications and populations

**Tumour types.**
- The package directly supports melanoma (Fig. 1f) and at least one further model in female BALB/cJ mice.
- The tumour identities of the other panels are not recorded and must be confirmed before naming a second indication.

**Clinical framing.** Patients with solid tumours at risk of haematogenous, lung-dominant metastasis who are exposed to creatine. Two outputs are possible:
- (i) **exposure guidance**, if C2 and H1 show priming at maintenance doses;
- (ii) **a platelet-directed mitigation**, if GPVI proves necessary (B) and its human signal replicates (H1).

---

## 5. What would elevate one choice over another

| Evidence | Consequence |
|---|---|
| **A: strong abrogation.** Interaction ratio ≤ 0.44 (≥75% of the log-effect removed, CI excluding 1); coherent PD (program and priming lost, uptake intact); A2 shows STAT5B-dependent platelet-borne activity. | **STAT5B confirmed** as MK mediator. Start the pS127 biomarker and CKB–STAT5B interface work (D); run B to find the druggable effector. |
| **A: partial** (25–75%) or CI spanning both | STAT5B contributes but is not sole. Run B next; keep STAT5B as the mechanistic biomarker. |
| **A: null.** Creatine effect in KO ≥ ×2 or ratio-of-ratios ≥ 0.7 with CI excluding 0.44 | STAT5B de-prioritised. Elevate GPVI if human data hold. Run C1 to check whether the MK axis itself replicates. |
| **A: WT-creatine arm < ×1.5** (below the historical prediction interval) | Program-level problem (effect fragile under blinding). Pause target work; prioritise C1/C2. |
| **GPVI blockade** removes ≥50% of the creatine effect without affecting vehicle metastasis; ex vivo blockade abolishes the human-platelet effect; H1 confirms a placebo-controlled collagen/GP6 rise | **GPVI becomes the portfolio primary** (druggable, platelet-restricted). Elevated above STAT5B if it captures ≥75% of the KO effect. |
| GPVI blockade ineffective, or human collagen signal not replicated under placebo | GPVI dropped. Effector redundancy likely; consider α2A only as a biomarker (EPI signal). |
| **C2/H1:** effect present at maintenance-equivalent exposure | Exposure guidance becomes a deliverable. MK/platelet creatine used as stratification biomarker; SLC6A8 remains a mechanism node, not a drug target. |
| **CKB:** site-specific S127 phosphorylation by CKB in MKs plus a tractable interface, and MK-specific in vivo loss-of-function | CKB rises above STAT5B as the chemically tractable upstream node. |
| **Gate 0:** I1–I3 unresolvable or indicative of manipulation | Halt; independent re-establishment of the creatine → metastasis and *Slc6a8*-cKO results first. |

---

## 6. Risks and assumptions

- **Cre-driver specificity and deletion.**
  - Deletion efficiency differs: SLC6A8 loss is partial (S4a), while STAT5B loss is complete (6d).
  - Driver specificity beyond MKs is not shown in the package.
  - Include deletion QC and the Cre⁺ wild-type comparator.
- **KO basal phenotype.** The *Stat5b* KO may have a basal platelet phenotype (PCT trend, S7b). The interaction design and count covariates handle this.
- **Metastasis model scope.** Experimental colonisation models interrogate only the circulation/colonisation step; see Study C (spontaneous-metastasis model).
- **Optimistic effect sizes.** Historical effects come from unblinded work and may be inflated. Sample sizes therefore use a conservative SD and declare partial-mediation outcomes inconclusive.
- **Human data limitations.**
  - The cohort is single-arm, young and of one ancestry.
  - Mechanistic sub-studies have n = 4.
  - Xenogeneic platelet transfer is a proof-of-concept model only.
- **Conventional pharmacology used as assumption, not evidence:**
  - agonist → receptor mapping (collagen/GPVI, EPI/α2A, ADP/P2Y12, AA/COX-1);
  - availability of GPVI-blocking agents.
  - → Both are validated in-house before use (Gate 0-3).

---

## Appendix A. Derivations

| Analysis | Method | Output |
|---|---|---|
| Two-group re-tests | Student and Welch t, Mann–Whitney, Hedges g | T1 |
| ANOVA panels | Tukey HSD via statsmodels; reported values reproduced | a02 |
| Interactions | OLS on log(y) with factor × creatine; contrasts via t-tests on linear combinations | T3 |
| Cross-experiment synthesis | DerSimonian–Laird on log ratio of geometric means | T2 |
| Survival | Log-rank and Cox model (lifelines) | a12 |
| qPCR | Every ΔCt block parsed; log2FC = ΔΔCt; t-tests on ΔCt; OLS interactions | T4 |
| Human platelet function | Day-k/day-0 fold-changes as provided; one-sample log-t, Wilcoxon signed-rank, sign test, Friedman; Holm and BH over 12 endpoints | T5 |
| Human CD41⁺ qPCR | Per-volunteer recomputation from ΔCt; reported vs recomputed | T6 |
| Human blots | Paired log analysis and RM-ANOVA on 7e. Approximate densitometry of S8d and 2e JPEGs: inverted grey, local background subtraction, band integration; placement verified visually | a15, a17, a18 |
| Integrity checks | Exhaustive duplicate and scaled-window scans; arithmetic-progression and dispersion Monte Carlo; binary-fraction provenance test of every ΔCt (instrument float32 vs derived float64); full recomputation of normalised values | T7 |
| Phosphoproteomics | p-value histogram, BH recomputation, identification of the p = 0.42265 artefact (Welch t = 1, df = 2) | T8 |
| Power | Non-central t for 2×2 interaction and two-group contrasts; historical SD(log) from 11 arms | a24, a25 |

## Appendix B. Files

**Proposal:** `CRE-MK-01_validation_proposal.md` and `.docx`.

**Figures** (`figures/`; prefixed "P" to avoid confusion with study figure numbers):
- P1 metastasis forest plot
- P2 MK program heat map
- P3 human platelet function
- P4 integrity checks
- P5 evidence map

**Tables** (`analysis/`):
- T1 two-group re-tests
- T2 creatine effect by experiment
- T3 interaction models
- T4 MK qPCR (ΔCt)
- T5 human platelet function (paired)
- T6 human CD41⁺ qPCR
- T7 integrity findings
- T8 phosphoproteomics

**Scripts:** `analysis/scripts/` (`data.py` maps every cell range used).
