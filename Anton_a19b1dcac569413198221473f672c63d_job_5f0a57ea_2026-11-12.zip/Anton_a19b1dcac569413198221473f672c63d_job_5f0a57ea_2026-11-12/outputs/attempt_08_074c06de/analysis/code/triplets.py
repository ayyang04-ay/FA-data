import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np, itertools
# Define triplet groups (n=3 replicate sets) across non-qPCR sheets
trip = {
 'Fig. 2a PLT veh':('Fig. 2a','B4:B6'),'Fig. 2a PLT cre':('Fig. 2a','C4:C6'),
 'Fig. 2a PCT veh':('Fig. 2a','B12:B14'),'Fig. 2a PCT cre':('Fig. 2a','C12:C14'),
 'Fig. 2a PDW veh':('Fig. 2a','B19:B21'),'Fig. 2a PDW cre':('Fig. 2a','C19:C21'),
 'Fig. 2a MPV veh':('Fig. 2a','B27:B29'),'Fig. 2a MPV cre':('Fig. 2a','C27:C29'),
 'Fig. 2b ADP veh':('Fig. 2b','B4:D4'),'Fig. 2b ADP cre':('Fig. 2b','E4:G4'),
 'Fig. 2b Col veh':('Fig. 2b','B5:D5'),'Fig. 2b Col cre':('Fig. 2b','E5:G5'),
 'Fig. 2b Thr veh':('Fig. 2b','B6:D6'),'Fig. 2b Thr cre':('Fig. 2b','E6:G6'),
 'Fig. 3c WT veh':('Fig. 3c','B4:D4'),'Fig. 3c WT cre':('Fig. 3c','E4:G4'),'Fig. 3c KO veh':('Fig. 3c','B5:D5'),'Fig. 3c KO cre':('Fig. 3c','E5:G5'),
 **{f'Fig. 3d {ag} {g}':('Fig. 3d',f'{c0}{r}:{c1}{r}') for ag,r in [('ADP',4),('Col',5),('Thr',6)] for g,(c0,c1) in [('WTveh',('B','D')),('WTcre',('E','G')),('KOveh',('H','J')),('KOcre',('K','M'))]},
 'Fig. 4a MK veh':('Fig. 4a','B4:B6'),'Fig. 4a MK cre':('Fig. 4a','C4:C6'),'Fig. 4a Br veh':('Fig. 4a','D4:D6'),'Fig. 4a Br cre':('Fig. 4a','E4:E6'),
 'Fig. 4c MK veh':('Fig. 4c','B4:B6'),'Fig. 4c MK cre':('Fig. 4c','C4:C6'),'Fig. 4c Br veh':('Fig. 4c','D4:D6'),'Fig. 4c Br cre':('Fig. 4c','E4:E6'),
 'Fig. 4d ctl':('Fig. 4d','C4:C6'),'Fig. 4d cre':('Fig. 4d','D4:D6'),'Fig. 4f ctl':('Fig. 4f','B4:B6'),'Fig. 4f cre':('Fig. 4f','C4:C6'),
 **{f'Fig. 5e {t} {m}':('Fig. 5e',f'{c}{r0}:{c}{r0+2}') for t,r0 in [('veh',4),('cre',17)] for m,c in zip(['WT','S127A','3A','S127D'],'NOPQ')},
 **{f'Fig. 5f {t} {m}':('Fig. 5f',f'{c}{r0}:{c}{r0+2}') for t,r0 in [('veh',4),('cre',17)] for m,c in zip(['WT','S127A','3A','S127D'],'NOPQ')},
 'Fig. 6e WTveh':('Fig. 6e','C5:C7'),'Fig. 6e WTcre':('Fig. 6e','D5:D7'),'Fig. 6e KOcre':('Fig. 6e','E5:E7'),
 **{f'S4b PLT {g}':('Supplementary Fig  4b',f'{c}5:{c}7') for g,c in zip(['WTveh','WTcre','KOveh','KOcre'],'CDEF')},
 'S5c Cr EV':('Supplementary Fig  5c','B5:B7'),'S5c Cr OE':('Supplementary Fig  5c','C5:C7'),'S5c PCr EV':('Supplementary Fig  5c','B13:B15'),'S5c PCr OE':('Supplementary Fig  5c','C13:C15'),
 **{f'S7a {p} {g}':('Supplementary Fig  7a',f'{c}{r}:{c}{r+2}') for p,r in [('PLT',4),('PCT',11),('MPV',17),('PDW',23)] for g,c in zip(['veh','cre','veh+i','cre+i'],'BCDE')},
 **{f'S7b {p} {g}':('Supplementary Fig  7b',f'{c}{r}:{c}{r+2}') for p,r in [('PLT',4),('PCT',10),('MPV',16),('PDW',22)] for g,c in zip(['WTveh','WTcre','KOcre'],'BCD')},
 **{f'Fig. 5j {gene} {reg} {t}':('Fig. 5j',f'{c0}{r}:{c1}{r}') for gene,r0 in [('P2ry12',5),('Gp6',15)] for k,reg in enumerate(['Exon','2K','1K','0.2K']) for t,(c0,c1) in [('veh',('B','D')),('cre',('E','G'))] for r in [r0+k]},
 **{f'S6i Rab4a {reg} {t}':('Supplementary Fig  6i',f'{c0}{r}:{c1}{r}') for k,reg in enumerate(['Exon','2K','1K','0.2K']) for t,(c0,c1) in [('veh',('C','E')),('cre',('F','H'))] for r in [7+k]},
}
n_ap=0; n_tie=0; tot=0
for k,(sh,r) in trip.items():
    x = col(sh,r)
    if len(x)!=3: print('skip',k,len(x)); continue
    s = sorted(x); tot+=1
    ap = np.isclose(s[1]-s[0], s[2]-s[1], rtol=1e-6, atol=1e-9) and s[2]>s[0]
    tie = len(set(np.round(x,9)))<3
    n_ap+=ap; n_tie+=tie
    if ap or tie: print(f'{k:28s} {x}  {"ARITH-PROGRESSION" if ap else ""} {"TIE" if tie else ""}')
print('total triplets', tot, 'arith progressions', n_ap, 'with ties', n_tie)
