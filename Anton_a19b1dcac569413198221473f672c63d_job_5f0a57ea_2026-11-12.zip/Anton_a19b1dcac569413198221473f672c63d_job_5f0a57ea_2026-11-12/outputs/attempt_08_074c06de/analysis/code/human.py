import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
from scipy import stats
import numpy as np, pandas as pd
from statsmodels.stats.anova import AnovaRM
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250)
# Fig 7b serum creatine
sh='Fig. 7b'
S = np.column_stack([col(sh,f'{c}4:{c}14') for c in 'BCDE'])
print('Fig7b serum creatine (uM) mean+-sd by day 0,3,7,14:', S.mean(0).round(1), S.std(0,ddof=1).round(1))
print('  fold vs d0 (mean of ratios):', (S/S[:,[0]]).mean(0).round(2), ' min fold d3', (S[:,1]/S[:,0]).min().round(2))
df = pd.DataFrame([(i,d,S[i,j]) for i in range(11) for j,d in enumerate(['0','3','7','14'])], columns=['id','day','y'])
print('  RM-ANOVA:', AnovaRM(df,'y','id',within=['day']).fit().anova_table.to_string().replace('\n',' | '))
for j,d in enumerate(['3','7','14']):
    t,p = stats.ttest_rel(S[:,j+1],S[:,0]); print(f'  paired t d{d} vs d0: t={t:.2f} p={p:.2e}')
print('  d14 vs d3 paired:', stats.ttest_rel(S[:,3],S[:,1]))
# Fig 7c platelet function
sh='Fig. 7c'
blocks = [('collagen','max agg',4),('collagen','avg agg',18),('collagen','adhesion',32),
          ('EPI','max agg',46),('EPI','avg agg',60),('EPI','adhesion',74),
          ('AA','max agg',88),('AA','avg agg',102),('AA','adhesion',116),
          ('ADP','max agg',130),('ADP','avg agg',144),('ADP','adhesion',157)]
rows=[]
for ag,ep,r0 in blocks:
    M = np.column_stack([col(sh,f'{c}{r0}:{c}{r0+10}') for c in 'BCDE'])
    assert M.shape==(11,4), (ag,ep,M.shape)
    for j,d in enumerate(['3','7','14']):
        x = M[:,j+1]
        lx = np.log2(np.where(x>0,x,np.nan))
        nz = np.isfinite(lx)
        t,p = stats.ttest_1samp(lx[nz],0)
        try: w = stats.wilcoxon(np.log2(x[x>0])).pvalue
        except Exception: w=np.nan
        rows.append(dict(agonist=ag,endpoint=ep,day=d,n=int(nz.sum()),mean_fold=x.mean(),median_fold=np.median(x),geomean_fold=2**np.nanmean(lx),
                         n_up=int((x>1).sum()), p_log_t=p, p_wilcoxon=w, zeros=int((x==0).sum())))
R = pd.DataFrame(rows)
R['q_BH_all36'] = multipletests(R.p_log_t,method='fdr_bh')[1]
R['p_holm_all36'] = multipletests(R.p_log_t,method='holm')[1]
print(R.round(4).to_string())
R.to_csv('human_platelet_function_reanalysis.csv',index=False)
