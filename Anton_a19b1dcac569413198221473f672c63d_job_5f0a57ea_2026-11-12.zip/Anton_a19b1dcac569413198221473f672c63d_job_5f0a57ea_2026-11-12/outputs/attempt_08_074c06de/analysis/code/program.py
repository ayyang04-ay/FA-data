import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np, pandas as pd, re
pd.set_option('display.width',250)
def L(n):
    s=''
    while n: n,r=divmod(n-1,26); s=chr(65+r)+s
    return s
def letters(c):
    n=0
    for ch in c: n=n*26+ord(ch)-64
    return n
def blocks(sh):
    d=WB[sh]; out={}
    names = {int(re.match(r'A(\d+)$',k).group(1)):v for k,v in d.items() if re.match(r'A\d+$',k) and isinstance(v,str) and re.match(r'^[A-Za-z0-9]+$',v)}
    for r,g in names.items():
        blk={}
        for rr in (r,r+1):
            for k,v in d.items():
                m=re.match(r'([A-Z]+)(\d+)$',k)
                if m and int(m.group(2))==rr and isinstance(v,str) and v.startswith('ΔCT'):
                    c=letters(m.group(1)); blk.setdefault(v, np.array([d.get(f'{L(c+i)}{rr}') for i in (1,2,3)],float))
        out[g]=blk
    return out
genes=['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
res={}
# Slc6a8 KO Fig 3f: ctrl effect = ΔCT2-ΔCT1 ; KO effect = ΔCT4-ΔCT3
b=blocks('Fig. 3f'); res['MK Slc6a8 KO (Fig 3f)']={g:(b[g]['ΔCT2'].mean()-b[g]['ΔCT1'].mean(), b[g]['ΔCT4'].mean()-b[g]['ΔCT3'].mean()) for g in genes}
b=blocks('Fig. 4j'); res['si-Ckb (Fig 4j)']={g:(b[g]['ΔCT3'].mean()-b[g]['ΔCT1'].mean(), b[g]['ΔCT4'].mean()-b[g]['ΔCT2'].mean()) for g in genes}
b=blocks('Fig.6a'); res['STAT5-IN-1 (Fig 6a)']={g:(b[g]['ΔCT2'].mean()-b[g]['ΔCT1'].mean(), b[g]['ΔCT4'].mean()-b[g]['ΔCT3'].mean()) for g in genes}
b=blocks('Fig. 6g'); res['MK Stat5b KO* (Fig 6g)']={g:(b[g]['ΔCT2'].mean()-b[g]['ΔCT1'].mean(), b[g]['ΔCT3'].mean()-b[g]['ΔCT1'].mean()) for g in genes}
rows=[]
for pert,dd in res.items():
    for g,(ec,ep) in dd.items():
        rows.append(dict(perturbation=pert,gene=g,log2FC_ctrl=ec,log2FC_perturbed=ep,attenuation=1-ep/ec))
R=pd.DataFrame(rows)
piv=R.pivot(index='gene',columns='perturbation',values='attenuation').loc[genes]
print('Attenuation of creatine-induced log2 fold change (1.0 = full block; >1 = reversal below baseline)')
print((piv*100).round(0).to_string())
print('\nmedian attenuation:', (piv.median()*100).round(0).to_dict())
print('n genes with >=75% attenuation:', (piv>=0.75).sum().to_dict())
# baseline effect of perturbation itself (no creatine)
b4j=blocks('Fig. 4j'); b6a=blocks('Fig.6a'); b3f=blocks('Fig. 3f')
base = pd.DataFrame({
 'siCkb alone (4j)':{g:2**(b4j[g]['ΔCT2'].mean()-b4j[g]['ΔCT1'].mean()) for g in genes},
 'STAT5-IN-1 alone (6a)':{g:2**(b6a[g]['ΔCT3'].mean()-b6a[g]['ΔCT1'].mean()) for g in genes},
 'Slc6a8 KO alone (3f)':{g:2**(b3f[g]['ΔCT3'].mean()-b3f[g]['ΔCT1'].mean()) for g in genes}})
print('\nBaseline effect of perturbation without creatine (fold vs control):'); print(base.round(2).to_string())
R.to_csv('program_attenuation.csv',index=False)
# Bypass: S4e
b=blocks('Supplementary Fig  4e')
byp = pd.DataFrame({g:{'KO+creatine':2**(b[g]['ΔCT2'].mean()-b[g]['ΔCT1'].mean()),'KO+creatine@liposome':2**(b[g]['ΔCT3'].mean()-b[g]['ΔCT1'].mean())} for g in genes}).T
print('\nSlc6a8-KO MKs (S4e): fold vs KO control'); print(byp.round(2).to_string())
b=blocks('Fig. 4l'); print('\nCKB-OE (4l) fold:', {g:round(2**(b[g]['ΔCT2'].mean()-b[g]['ΔCT1'].mean()),2) for g in genes})
b=blocks('Fig. 4h'); print('PCr (4h) fold:', {g:round(2**(b[g]['ΔCT3'].mean()-b[g]['ΔCT1'].mean()),2) for g in genes})
