import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
fig=plt.figure(figsize=(11.5,7.8)); gs=fig.add_gridspec(2,3,hspace=0.5,wspace=0.38)
# A: 6b vs S2d
ax=fig.add_subplot(gs[0,0])
b6v=col('Fig. 6b','B4:B8'); b6c=col('Fig. 6b','C4:C8'); s2v=col('Supplementary Fig  2d','C5:C10'); s2c=col('Supplementary Fig  2d','D5:D10')
f6v=col('Fig. 6b','B13:B17'); f6c=col('Fig. 6b','C13:C17'); fsv=col('Supplementary Fig  2d','C14:C19'); fsc=col('Supplementary Fig  2d','D14:D19')
for arr,x,c,lab in [(b6v,0,'#4393c3','Fig 6b vehicle'),(s2v,1,'#4393c3','Supp 2d vehicle-donor'),(b6c,2.6,'#d6604d','Fig 6b creatine'),(s2c,3.6,'#d6604d','Supp 2d creatine-donor')]:
    shared=np.isin(np.round(arr,5),np.round(np.concatenate([b6v,b6c]) if 'Supp' in lab else np.concatenate([s2v,s2c]),5))
    ax.scatter(np.full(len(arr),x)+np.linspace(-0.15,0.15,len(arr)),arr,c=[('k' if s else c) for s in shared],s=28,zorder=3,edgecolor='k',linewidth=0.4)
ax.set_xticks([0,1,2.6,3.6]); ax.set_xticklabels(['6b\nveh','S2d\nveh','6b\ncre','S2d\ncre'],fontsize=8); ax.set_ylabel('Metastatic burden (%)')
ax.set_title('A. Same 3 animals/arm in two experiments\n(black = identical burden AND foci)',fontsize=9)
txt='6b veh #2-4 = S2d veh #4-6:\n 3.29136/37, 3.733544/25, 2.886353/33\n6b cre #2-4 = S2d cre #4-6:\n 11.13465/53, 13.22011/62, 14.12619/47'
ax.text(0.02,0.98,txt,transform=ax.transAxes,fontsize=6.2,va='top',family='monospace')
# B: Fig 2b triplets
ax=fig.add_subplot(gs[0,1])
names=['ADP','Collagen','Thrombin']
for i,r in enumerate((4,5,6)):
    for j,(a,b) in enumerate([('B','D'),('E','G')]):
        v=np.sort(col('Fig. 2b',f'{a}{r}:{b}{r}')); x=i*2.4+j
        ax.plot([x]*3,v,'o',color=['#4393c3','#d6604d'][j],ms=5); ax.text(x+0.12,v[1],f'{int(v[1])}\u00b1{int(v[2]-v[1])}',fontsize=6.5,va='center')
ax.set_xticks([0.5,2.9,5.3]); ax.set_xticklabels(names,fontsize=8); ax.set_ylabel('Aggregation (%)')
ax.set_title('B. Fig 2b: all 6 triplicates are exact\nmean \u00b1 integer SD (joint P \u2248 1e-5)',fontsize=9)
# C: Fig 3d all even, identical SD
ax=fig.add_subplot(gs[0,2])
V=np.array([col('Fig. 3d',f'B{r}:M{r}') for r in (4,5,6)])
for i in range(3):
    for g in range(4):
        v=V[i,g*3:(g+1)*3]; x=i*5+g
        ax.plot(x+np.array([-0.18,0,0.18]),v,'o',ms=4,color=['#4393c3','#d6604d','#92c5de','#f4a582'][g])
ax.set_xticks([1.5,6.5,11.5]); ax.set_xticklabels(['ADP','Collagen','Thrombin'],fontsize=8); ax.set_ylabel('Aggregation (%)')
ax.set_title('C. Fig 3d: 36/36 values even; 11/12 groups SD=1.155\n(pattern x,x,x\u00b12); KO+creatine falls below KO vehicle',fontsize=9)
ax.text(0.02,0.02,'order per agonist: WT-veh, WT-cre, KO-veh, KO-cre',transform=ax.transAxes,fontsize=6.5)
# D: phospho p histogram
ax=fig.add_subplot(gs[1,0]); P=pd.read_csv('phospho.csv'); P.columns=['gene','p','q','lfc']
ax.hist(P.p,bins=40,color='#bababa',edgecolor='k',linewidth=0.3)
ax.axhline(len(P)/40,color='r',ls='--',lw=1); ax.set_xlabel('P-value (t-test, n=3 vs 3)'); ax.set_ylabel('phosphopeptides')
ax.set_title('D. Phosphoproteomics: spikes at p=0.4226 (1,702 rows)\nand p≈0.18 (~240 rows) = peptides seen in 1-2 replicates\nof one group only; no site with q<0.05 (min q=0.17)',fontsize=9)
# E: baseline dCT ranges
ax=fig.add_subplot(gs[1,1]); D=pd.read_csv('mouse_qpcr_stats.csv')
genes=['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
sheets=['Fig. 2f','Fig. 3f','Fig. 4h','Fig. 4j','Fig. 4l','Fig.6a','Fig. 6g','Supplementary Fig  4e']
base=D.groupby(['gene','sheet']).dCT_ctrl.first().unstack().loc[genes,sheets]
for k,s in enumerate(sheets):
    ax.scatter(range(len(genes)),base[s].values,s=14,label=s.replace('Supplementary Fig  ','S').replace('Fig. ','').replace('Fig.',''),marker='o' if s!='Fig. 3f' else 'X',zorder=3)
ax.set_xticks(range(len(genes))); ax.set_xticklabels(genes,rotation=60,fontsize=7,style='italic'); ax.set_ylabel('control-group mean \u0394CT vs Actb')
ax.legend(fontsize=5.8,ncol=2,frameon=False,loc='lower left'); ax.axhline(0,color='k',lw=0.5)
ax.set_title('E. Same gene, same cell type: baseline \u0394CT\nspans 7\u201319 cycles across experiments',fontsize=9)
# F: human qPCR unreproducible cells
ax=fig.add_subplot(gs[1,2]); H=pd.read_csv('human_qpcr_recalc.csv')
ok=H[~((H.vol==4)&H.gene.isin(['RAB27B','PITPNB']))]; bad=H[(H.vol==4)&H.gene.isin(['RAB27B','PITPNB'])]
ax.scatter(ok.calc_linratio,ok.rep,s=10,color='grey',label='126 reproduced')
ax.scatter(bad.calc_linratio,bad.rep,s=30,color='r',label='6 not reproducible (V4 RAB27B, PITPNB)')
ax.plot([0.02,40],[0.02,40],'k--',lw=0.7); ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel('fold recomputed from \u0394CT'); ax.set_ylabel('fold reported in sheet'); ax.legend(fontsize=6.5,frameon=False)
ax.set_title('F. Fig 7d: reported vs recomputed fold;\nV4 PITPNB "\u0394CT" \u2248 +27 (raw Ct?)',fontsize=9)
plt.savefig('/tmp/outputs/figures/fig4_integrity.png',dpi=200,bbox_inches='tight'); print('ok')
