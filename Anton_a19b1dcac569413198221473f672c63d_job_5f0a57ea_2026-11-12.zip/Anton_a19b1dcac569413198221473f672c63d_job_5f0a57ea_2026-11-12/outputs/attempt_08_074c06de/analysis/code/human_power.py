import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np
from scipy import stats
sh='Fig. 7c'
blocks = {'collagen max':4,'collagen avg':18,'collagen adh':32,'EPI max':46,'EPI avg':60,'EPI adh':74,'AA max':88,'ADP max':130}
def n_per_arm(delta, sd, alpha=0.05, power=0.9):
    za=stats.norm.ppf(1-alpha/2); zb=stats.norm.ppf(power)
    return int(np.ceil(2*((za+zb)*sd/delta)**2))+1
for k,r0 in blocks.items():
    M=np.column_stack([col(sh,f'{c}{r0}:{c}{r0+10}') for c in 'BCDE'])
    for j,d in [(2,'7'),(3,'14')]:
        x=M[:,j]; x=x[x>0]; l=np.log2(x); m=l.mean(); s=l.std(ddof=1)
        n_full = n_per_arm(m,s) ; n_half=n_per_arm(m/2,s); n_half_a=n_per_arm(m/2,s,alpha=0.025)
        print(f'{k:13s} d{d}: mean log2 fold {m:+.2f} (x{2**m:.2f}), SD {s:.2f}; n/arm for 90% power: observed effect {n_full}, half effect {n_half} (alpha .05) / {n_half_a} (alpha .025)')
