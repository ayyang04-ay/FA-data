# Re-analysis code for the CRE-MK-01 validation proposal

Every number and figure in `../../CRE-MK-01_validation_proposal.md` can be regenerated from the two source workbooks.

1. `python extract_workbook.py CRE-MK-01_source_data.xlsx CRE-MK-01_phosphoproteomics.xlsx $CRE_WORKDIR`
   (needs openpyxl + pandas). This writes `wb.json` and `phospho.csv`.
2. `export CRE_WORKDIR=...`, then run the scripts with scipy, statsmodels, pandas, lifelines and matplotlib.
   The scripts were run from `/tmp/work/analysis`, so some output paths are absolute; edit them as needed.

| Script | Produces |
|---|---|
| verify_two_group2.py, verify_multi2.py, verify_chip_human.py, survival.py | Recomputation of every reported test (t, Tukey, Sidak, Dunnett, log-rank) |
| make_tables.py, blockade.py, meta_power.py, endpoints.py, cox.py | Creatine effect sizes, attenuation, random-effects pooling, endpoint SNR, hazard ratios |
| mouse_qpcr.py, program.py, mech.py | MK gene-program statistics on the ΔCT scale, attenuation per perturbation, S127 interaction, ChIP folds, baseline-ΔCT audit |
| human.py, human_qpcr.py, human_qpcr_stats.py, human_power.py | Human platelet function (within-subject, FDR), qPCR recomputation, RCT sizing |
| phospho.py | Degenerate p-values, π0, FDR, Stat5b rank |
| forensic.py, triplets.py | Integrity checks: triplet patterns, parity, digit tests, cross-sheet duplicates |
| power_table.py | Monte-Carlo power for the Study 1 interaction test and GO rule |
| fig_*.py | Figures 1–4 |
