import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
def chip(sh, r0, cv, cc, lab):
    rows=[]
    for i,reg in enumerate(['Exon','2K','1K','0.2K']):
        r=r0+i
        for v in col(sh,f'{cv[0]}{r}:{cv[1]}{r}'): rows.append(dict(reg=reg,trt='veh',y=v))
        for v in col(sh,f'{cc[0]}{r}:{cc[1]}{r}'): rows.append(dict(reg=reg,trt='cre',y=v))
    D=pd.DataFrame(rows); fit=smf.ols('y~C(reg)*C(trt)',data=D).fit(); mse=fit.mse_resid; dfr=fit.df_resid
    out=[]
    for reg in ['Exon','2K','1K','0.2K']:
        a=D[(D.reg==reg)&(D.trt=='veh')].y; b=D[(D.reg==reg)&(D.trt=='cre')].y
        diff=a.mean()-b.mean(); se=np.sqrt(mse*(1/3+1/3)); t=diff/se; p=2*stats.t.sf(abs(t),dfr); ps=1-(1-p)**4
        out.append(f'{reg}: diff {diff:.3f} sidak p {min(ps,1):.2e}')
    print(lab, '; '.join(out))
chip('Fig. 5j',5,('B','D'),('E','G'),'P2ry12')
chip('Fig. 5j',15,('B','D'),('E','G'),'Gp6')
chip('Supplementary Fig  6i',7,('C','E'),('F','H'),'Rab4a')
# human 7e as reported (ordinary one-way ANOVA + Tukey) vs RM
from statsmodels.stats.multicomp import pairwise_tukeyhsd
for lab,(r0,r1) in {'GP6':(4,7),'P2RY12':(12,15)}.items():
    M=np.column_stack([col('Fig. 7e',f'{c}{r0}:{c}{r1}') for c in 'BCDE'])
    res=pairwise_tukeyhsd(M.T.ravel(), np.repeat(['0','3','7','14'],4))
    print('7e',lab,[ (r[0],r[1],r[2],r[3]) for r in res.summary().data[1:] if r[0]=='0' or r[1]=='0'])
