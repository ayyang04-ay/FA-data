import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np
from scipy import stats
rng = np.random.default_rng(1)
# 1) Fig 2b: probability that integer-rounded triplets from N(mean, sd) form exact arithmetic progressions
obs = {'ADP veh':[44,40,42],'ADP cre':[56,58,57],'Col veh':[68,64,66],'Col cre':[80,78,79],'Thr veh':[20,30,25],'Thr cre':[52,60,56]}
ptot=1
for k,v in obs.items():
    v=np.array(v,float); m=v.mean(); s=v.std(ddof=1)
    sims = np.round(rng.normal(m,s,size=(200000,3)))
    ss = np.sort(sims,1)
    ap = np.isclose(ss[:,1]-ss[:,0], ss[:,2]-ss[:,1]) & (ss[:,2]>ss[:,0])
    p = ap.mean(); ptot*=p
    print(f'Fig2b {k}: P(exact AP | N({m:.1f},{s:.2f}) rounded) = {p:.3f}')
print('Fig 2b joint probability all 6 triplets are exact APs ~', f'{ptot:.2e}')
# 2) Fig 3d: parity
vals = np.concatenate([col('Fig. 3d',f'B{r}:M{r}') for r in (4,5,6)])
print('Fig 3d n values', len(vals), 'n even', int((vals%2==0).sum()), ' P(all even | random parity)=', 0.5**len(vals))
v2b = np.concatenate([col('Fig. 2b',f'B{r}:G{r}') for r in (4,5,6)])
print('Fig 2b n values', len(v2b), 'n even', int((v2b%2==0).sum()))
# identical SD pattern in 3d
sds=[col('Fig. 3d',f'{a}{r}:{b}{r}').std(ddof=1) for r in (4,5,6) for a,b in [('B','D'),('E','G'),('H','J'),('K','M')]]
print('Fig 3d group SDs:', np.round(sds,4))
# 3) terminal digit analysis of lung weights (4 dp) across all in vivo experiments
lw = []
for sh,rngs in [('Fig. 1a',['B3:C8']),('Fig. 1f',['B4:E9']),('Fig. 1j',['B4:C9']),('Supplementary Fig  1e',['B4:C9']),('Supplementary Fig  1f',['B4:C7']),
                ('Supplementary Fig  1g',['B3:C12']),('Supplementary Fig  1i',['B3:C6']),('Supplementary Fig  1k',['B4:C13']),('Fig. 3i',['B3:E6']),('Fig. 7g',['B4:C8'])]:
    for r in rngs: lw += list(col(sh,r))
lw=np.array(lw); last=(np.round(lw*10000)%10).astype(int)
cnt=np.bincount(last,minlength=10); print('lung weight last digit counts', cnt.tolist(), 'chi2 p=', round(stats.chisquare(cnt).pvalue,3), 'n=',len(lw))
# 4) within-group correlation between burden% and foci count (paired per animal) per experiment
pairs = {'Fig1b':('Fig. 1b',[('B3:B8','B12:B17'),('C3:C8','C12:C17')]),
         'Fig1f':('Fig. 1f',[(f'{c}22:{c}27',f'{c}31:{c}36') for c in 'BCDE']),
         'Fig1k':('Fig. 1k',[('B4:B9','B12:B17'),('C4:C9','C12:C17')]),
         'S1e':('Supplementary Fig  1e',[('B13:B18','B22:B27'),('C13:C18','C22:C27')]),
         'S1f':('Supplementary Fig  1f',[('B12:B15','B20:B23'),('C12:C15','C20:C23')]),
         'S1g':('Supplementary Fig  1g',[('B15:B24','B28:B37'),('C15:C24','C28:C37')]),
         'S1i':('Supplementary Fig  1i',[('B11:B14','B18:B21'),('C11:C14','C18:C21')]),
         'S1k':('Supplementary Fig  1k',[('B16:B25','B29:B38'),('C16:C25','C29:C38')]),
         'Fig3i':('Fig. 3i',[(f'{c}10:{c}13',f'{c}17:{c}20') for c in 'BCDE']),
         'Fig6b':('Fig. 6b',[(f'{c}4:{c}8',f'{c}13:{c}17') for c in 'BCDE']),
         'S2d':('Supplementary Fig  2d',[(f'{c}5:{c}10',f'{c}14:{c}19') for c in 'CDE']),
         'Fig7g':('Fig. 7g',[('B12:B16','B19:B23'),('C12:C16','C19:C23')])}
for k,(sh,pr) in pairs.items():
    xs=[];ys=[];tot_x=[];tot_y=[]
    for a,b in pr:
        x=col(sh,a); y=col(sh,b); xs+=list(x-x.mean()); ys+=list(y-y.mean()); tot_x+=list(x); tot_y+=list(y)
    r,p = stats.pearsonr(xs,ys); R,P=stats.pearsonr(tot_x,tot_y)
    print(f'{k:6s} within-group r(burden,foci)={r:+.2f} (p={p:.2f}, n={len(xs)}); overall r={R:+.2f}')
