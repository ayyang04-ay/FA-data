import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
rng=np.random.default_rng(3)
def ratio_ci(a,b,B=20000):
    ra=rng.choice(a,(B,len(a))).mean(1); rb=rng.choice(b,(B,len(b))).mean(1); r=rb/ra
    return b.mean()/a.mean(), *np.percentile(r,[2.5,97.5])
groups = [
 ('Creatine vs vehicle, wild-type hosts', [
   ('Fig 1b','Fig. 1b','B3:B8','C3:C8',''),
   ('Fig 1f (tumor sh-scrambled)','Fig. 1f','B22:B27','C22:C27',''),
   ('Fig 1k','Fig. 1k','B4:B9','C4:C9',''),
   ('Supp 1e','Supplementary Fig  1e','B13:B18','C13:C18',''),
   ('Supp 1f','Supplementary Fig  1f','B12:B15','C12:C15',''),
   ('Supp 1g','Supplementary Fig  1g','B15:B24','C15:C24',''),
   ('Supp 1i (5% creatine diet)','Supplementary Fig  1i','B11:B14','C11:C14',''),
   ('Supp 1k','Supplementary Fig  1k','B16:B25','C16:C25',''),
   ('Fig 3i (Pf4-Cre;Slc6a8+/+)','Fig. 3i','B10:B13','C10:C13',''),
   ('Fig 6b (DMSO arm)','Fig. 6b','B4:B8','C4:C8','dup')]),
 ('Creatine effect under perturbation', [
   ('Tumor-cell Slc6a8 knockdown (Fig 1f)','Fig. 1f','D22:D27','E22:E27',''),
   ('MK Slc6a8 deletion, Pf4-Cre (Fig 3i)','Fig. 3i','D10:D13','E10:E13',''),
   ('STAT5-IN-1, systemic (Fig 6b)','Fig. 6b','D4:D8','E4:E8','dup')]),
 ('Platelet transfer into tumor-bearing recipients', [
   ('Creatine- vs vehicle-donor mouse PLT (Supp 2d)','Supplementary Fig  2d','C5:C10','D5:D10','dup'),
   ('Creatine+aspirin vs vehicle donor PLT (Supp 2d)','Supplementary Fig  2d','C5:C10','E5:E10','dup'),
   ('Human day-7 vs day-0 donor PLT (Fig 7g)','Fig. 7g','B12:B16','C12:C16','')]),
]
fig,ax=plt.subplots(figsize=(8.6,7.2))
y=0; yt=[]; yl=[]
for gname,items in groups:
    y-=0.6; ax.text(0.29,y,gname,fontweight='bold',fontsize=9,va='center'); y-=0.9
    for lab,sh,a,b,flag in items:
        A=col(sh,a);B=col(sh,b); r,lo,hi=ratio_ci(A,B)
        c='#b2182b' if flag=='dup' else '#2166ac'
        ax.plot([lo,hi],[y,y],color=c,lw=2); ax.plot(r,y,'o',color=c,ms=6)
        ax.text(9.3,y,f'{r:.2f} ({lo:.2f}-{hi:.2f})  n={len(A)}/{len(B)}',fontsize=7.5,va='center')
        yt.append(y); yl.append(lab+(' \u2020' if flag=='dup' else '')); y-=0.9
# pooled RE estimate (computed separately): 3.02 [2.54-3.58]
ax.plot([2.54,3.58],[y,y],color='k',lw=3); ax.plot(3.02,y,'D',color='k',ms=7); ax.text(9.3,y,'3.02 (2.54-3.58)  k=10, I\u00b2=51%',fontsize=7.5,va='center')
yt.append(y); yl.append('Pooled, wild-type creatine vs vehicle (random effects)')
ax.axvline(1,color='grey',ls='--',lw=1)
ax.set_xscale('log'); ax.set_xlim(0.27,9)
from matplotlib.ticker import FixedLocator, FixedFormatter, NullFormatter, NullLocator
ax.xaxis.set_major_locator(FixedLocator([0.5,1,2,4,8])); ax.xaxis.set_major_formatter(FixedFormatter(['0.5','1','2','4','8'])); ax.xaxis.set_minor_locator(NullLocator()); ax.xaxis.set_minor_formatter(NullFormatter())
ax.set_yticks(yt); ax.set_yticklabels(yl,fontsize=8); ax.set_ylim(y-0.8,0.2)
ax.set_xlabel('Ratio of mean lung metastatic burden (% area), treated / comparator  [95% bootstrap CI, log scale]',fontsize=8)
ax.set_title('Creatine effect on lung metastatic burden across the data package',fontsize=10)
fig.text(0.01,0.01,'\u2020 red: Fig 6b and Supp 2d share 3 animals per vehicle/creatine arm (identical burden and foci values); treat as one non-independent dataset.\nRatios from raw per-animal values in CRE-MK-01_source_data.xlsx; pooled estimate = DerSimonian-Laird on log ratio of means.',fontsize=6.5)
plt.subplots_adjust(left=0.42,right=0.78,bottom=0.1,top=0.95)
plt.savefig('/tmp/outputs/figures/fig1_forest_metastasis.png',dpi=200)
print('ok')
