import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np, pandas as pd
rng=np.random.default_rng(5)
def boot(a,b,B=20000):
    ra=rng.choice(a,(B,len(a))).mean(1); rb=rng.choice(b,(B,len(b))).mean(1); r=rb/ra
    return b.mean()/a.mean(), *np.percentile(r,[2.5,97.5])
E = [
 ('Fig 1a/1b','Fig. 1b','B3:B8','C3:C8','Fig. 1b','B12:B17','C12:C17','Fig. 1a','B3:B8','C3:C8'),
 ('Fig 1f (tumor sh-scr)','Fig. 1f','B22:B27','C22:C27','Fig. 1f','B31:B36','C31:C36','Fig. 1f','B4:B9','C4:C9'),
 ('Fig 1j/1k','Fig. 1k','B4:B9','C4:C9','Fig. 1k','B12:B17','C12:C17','Fig. 1j','B4:B9','C4:C9'),
 ('Supp 1e','Supplementary Fig  1e','B13:B18','C13:C18','Supplementary Fig  1e','B22:B27','C22:C27','Supplementary Fig  1e','B4:B9','C4:C9'),
 ('Supp 1f','Supplementary Fig  1f','B12:B15','C12:C15','Supplementary Fig  1f','B20:B23','C20:C23','Supplementary Fig  1f','B4:B7','C4:C7'),
 ('Supp 1g','Supplementary Fig  1g','B15:B24','C15:C24','Supplementary Fig  1g','B28:B37','C28:C37','Supplementary Fig  1g','B3:B12','C3:C12'),
 ('Supp 1i (5% diet)','Supplementary Fig  1i','B11:B14','C11:C14','Supplementary Fig  1i','B18:B21','C18:C21','Supplementary Fig  1i','B3:B6','C3:C6'),
 ('Supp 1k','Supplementary Fig  1k','B16:B25','C16:C25','Supplementary Fig  1k','B29:B38','C29:C38','Supplementary Fig  1k','B4:B13','C4:C13'),
 ('Fig 3i (Pf4-Cre;Slc6a8+/+)','Fig. 3i','B10:B13','C10:C13','Fig. 3i','B17:B20','C17:C20','Fig. 3i','B3:B6','C3:C6'),
 ('Fig 6b (DMSO arm)†','Fig. 6b','B4:B8','C4:C8','Fig. 6b','B13:B17','C13:C17',None,None,None),
]
lines=['| Experiment | n (veh/cre) | Burden % veh → cre | Burden ratio [95% CI] | Foci veh → cre (ratio) | Lung wt g veh → cre (ratio) |','|---|---|---|---|---|---|']
for lab,s1,a1,b1,s2,a2,b2,s3,a3,b3 in E:
    A=col(s1,a1);B=col(s1,b1); r,lo,hi=boot(A,B)
    F0=col(s2,a2);F1=col(s2,b2)
    lw = f'{col(s3,a3).mean():.3f} → {col(s3,b3).mean():.3f} ({col(s3,b3).mean()/col(s3,a3).mean():.2f}×)' if s3 else '—'
    lines.append(f'| {lab} | {len(A)}/{len(B)} | {A.mean():.1f} → {B.mean():.1f} | {r:.2f} [{lo:.2f}–{hi:.2f}] | {F0.mean():.1f} → {F1.mean():.1f} ({F1.mean()/F0.mean():.2f}×) | {lw} |')
open('/tmp/work/analysis/table1.md','w').write('\n'.join(lines)); print('\n'.join(lines))
