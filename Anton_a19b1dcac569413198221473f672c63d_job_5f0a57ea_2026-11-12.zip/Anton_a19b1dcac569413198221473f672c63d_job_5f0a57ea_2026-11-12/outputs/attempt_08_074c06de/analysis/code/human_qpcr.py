import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
from scipy import stats
import numpy as np, pandas as pd
pd.set_option('display.width',250)
sh='Fig. 7d'
# gene blocks: (gene, first ΔCT row, cols for V1..V4, normalization rows start)
blocks = [('ITGA2B',7,'CDEF',19),('P2RY12',7,'IJKL',19),('GP6',26,'CDEF',38),('GP1BA',26,'IJKL',38),
          ('F2R',45,'CDEF',57),('ADRA2A',45,'IJKL',57),('FCGR2A',64,'CDEF',76),('RUNX1',64,'IJKL',76),
          ('RAB4A',83,'CDEF',95),('RAB27B',83,'IJKL',95),('PITPNB',101,'CDEF',113)]
rows=[]
for g,r0,cols,rn in blocks:
    for vi,c in enumerate(cols):
        d = {}
        for k,day in enumerate(['0','3','7','14']):
            d[day] = col(sh,f'{c}{r0+3*k}:{c}{r0+3*k+2}')
        rep = {day: cell(sh,f'{c}{rn+k}') for k,day in enumerate(['0','3','7','14'])}
        for day in ['3','7','14']:
            # candidate calculations
            f_meanct = 2**(d[day].mean()-d['0'].mean())            # 2^(mean ΔCT_t - mean ΔCT_0)
            f_meanlin = (2**d[day]).mean()/(2**d['0']).mean()      # ratio of mean linear
            f_neg = 2**(-(d[day].mean()-d['0'].mean()))
            rows.append(dict(gene=g,vol=vi+1,day=day,rep=rep[day],calc_2pow=f_meanct,calc_linratio=f_meanlin,calc_inverse=f_neg,
                             dCT0=d['0'].mean(), dCTt=d[day].mean(), sd_tech_t=d[day].std(ddof=1)))
R = pd.DataFrame(rows)
R['match'] = np.where(np.isclose(R.rep,R.calc_linratio,rtol=0.02),'linratio',np.where(np.isclose(R.rep,R.calc_2pow,rtol=0.02),'2pow',np.where(np.isclose(R.rep,R.calc_inverse,rtol=0.02),'INVERSE','NO MATCH')))
print(R.round(3).to_string())
print(R.match.value_counts())
R.to_csv('human_qpcr_recalc.csv',index=False)
