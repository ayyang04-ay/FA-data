import json, re, numpy as np
import os
WB = json.load(open(os.path.join(os.environ.get('CRE_WORKDIR','/tmp/work/analysis'),'wb.json')))
def _rc(coord):
    m = re.match(r'([A-Z]+)(\d+)', coord); s=m.group(1); n=0
    for ch in s: n = n*26 + ord(ch)-64
    return int(m.group(2)), n
def _coord(r,c):
    s=''
    while c: c,rem=divmod(c-1,26); s=chr(65+rem)+s
    return f'{s}{r}'
def cell(sh, coord): return WB[sh.strip()].get(coord)
def col(sh, rng):
    a,b = rng.split(':'); r0,c0=_rc(a); r1,c1=_rc(b); out=[]
    for r in range(r0,r1+1):
        for c in range(c0,c1+1):
            v = WB[sh.strip()].get(_coord(r,c))
            if isinstance(v,(int,float)) and not isinstance(v,bool): out.append(float(v))
    return np.array(out)
