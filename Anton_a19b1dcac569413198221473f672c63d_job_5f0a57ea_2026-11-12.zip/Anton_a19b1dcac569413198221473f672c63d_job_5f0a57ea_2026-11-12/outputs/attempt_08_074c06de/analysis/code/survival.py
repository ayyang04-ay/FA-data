import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
from lifelines.statistics import logrank_test
def getsurv(sh, r0, r1):
    veh=[];cre=[]
    for r in range(r0,r1+1):
        t=cell(sh,f'A{r}'); b=cell(sh,f'B{r}'); c=cell(sh,f'C{r}')
        if t is None: continue
        if b==1: veh.append(t)
        if c==1: cre.append(t)
    return np.array(veh,float), np.array(cre,float)
for sh,(r0,r1) in {'Fig. 1c':(4,23),'Fig. 1l':(4,41)}.items():
    v,c = getsurv(sh,r0,r1)
    res = logrank_test(v,c,event_observed_A=np.ones_like(v),event_observed_B=np.ones_like(c))
    print(sh, 'n veh',len(v),'n cre',len(c),'median veh',np.median(v),'median cre',np.median(c),'mean', round(v.mean(),2), round(c.mean(),2), 'chi2',round(res.test_statistic,3),'p',round(res.p_value,4))
    print('   veh', sorted(v)); print('   cre', sorted(c))
