import numpy as np, pandas as pd
from scipy import stats
R = pd.read_csv('creatine_effect_burden.csv')
import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
exps = [('Fig1b','Fig. 1b','B3:B8','C3:C8'),('Fig1f (sh-scr)','Fig. 1f','B22:B27','C22:C27'),('Fig1k','Fig. 1k','B4:B9','C4:C9'),
        ('S1e','Supplementary Fig  1e','B13:B18','C13:C18'),('S1f','Supplementary Fig  1f','B12:B15','C12:C15'),('S1g','Supplementary Fig  1g','B15:B24','C15:C24'),
        ('S1i (diet)','Supplementary Fig  1i','B11:B14','C11:C14'),('S1k','Supplementary Fig  1k','B16:B25','C16:C25'),('Fig3i (Cre ctrl)','Fig. 3i','B10:B13','C10:C13'),
        ('Fig6b (DMSO)','Fig. 6b','B4:B8','C4:C8')]
y=[];v=[];lab=[];sds=[]
for l,sh,a,b in exps:
    A=col(sh,a);B=col(sh,b)
    yi=np.log(B.mean()/A.mean()); vi=A.var(ddof=1)/(len(A)*A.mean()**2)+B.var(ddof=1)/(len(B)*B.mean()**2)
    y.append(yi);v.append(vi);lab.append(l)
    la,lb=np.log(A),np.log(B); sds.append(np.sqrt(((len(A)-1)*la.var(ddof=1)+(len(B)-1)*lb.var(ddof=1))/(len(A)+len(B)-2)))
y=np.array(y);v=np.array(v);w=1/v
fe=(w*y).sum()/w.sum(); Q=(w*(y-fe)**2).sum(); k=len(y); C=w.sum()-(w**2).sum()/w.sum(); tau2=max(0,(Q-(k-1))/C)
ws=1/(v+tau2); re=(ws*y).sum()/ws.sum(); se=np.sqrt(1/ws.sum())
I2=max(0,(Q-(k-1))/Q)*100
print(f'Random-effects pooled ratio of means (direct creatine vs vehicle, k={k}): {np.exp(re):.2f} [95% CI {np.exp(re-1.96*se):.2f}-{np.exp(re+1.96*se):.2f}]; Q={Q:.1f}, p_het={stats.chi2.sf(Q,k-1):.2f}, I2={I2:.0f}%, tau2={tau2:.3f}')
print('per-experiment ratios:', dict(zip(lab,np.round(np.exp(y),2))))
print('within-group SD of ln(burden): median %.2f, IQR %.2f-%.2f, max %.2f' % (np.median(sds),*np.percentile(sds,[25,75]),max(sds)))
# prediction interval
tcrit=stats.t.ppf(0.975,k-2); pi=(re-tcrit*np.sqrt(tau2+se**2), re+tcrit*np.sqrt(tau2+se**2)); print('95%% prediction interval: %.2f-%.2f' % tuple(np.exp(pi)))
# ---------- power simulation for 2x2 factorial (genotype x creatine) on ln(burden)
rng=np.random.default_rng(11)
def power_interaction(n, eff_wt, atten, sd, sims=4000, alpha=0.05):
    # effect in KO = (1-atten)*eff_wt ; test interaction in OLS on log scale
    hits=0; hits_go=0
    for _ in range(sims):
        g = {('wt',0):rng.normal(0,sd,n),('wt',1):rng.normal(eff_wt,sd,n),('ko',0):rng.normal(0,sd,n),('ko',1):rng.normal((1-atten)*eff_wt,sd,n)}
        m = {k:x.mean() for k,x in g.items()}
        inter = (m[('wt',1)]-m[('wt',0)])-(m[('ko',1)]-m[('ko',0)])
        s2 = np.mean([x.var(ddof=1) for x in g.values()]); se = np.sqrt(s2*4/n); df=4*(n-1)
        p = 2*stats.t.sf(abs(inter/se),df)
        hits += (p<alpha) and inter>0
        # GO rule: interaction significant AND estimated attenuation >= 60%
        e_wt = m[('wt',1)]-m[('wt',0)]; e_ko=m[('ko',1)]-m[('ko',0)]
        hits_go += (p<alpha) and e_wt>0 and (1-e_ko/e_wt)>=0.6
    return hits/sims, hits_go/sims
print('\nPower for genotype x creatine interaction (two-sided 0.05), ln-scale SD assumptions:')
for sd in [0.38,0.45,0.55]:
    for eff in [np.log(3.0),np.log(2.0)]:
        for atten in [1.0,0.75,0.5]:
            out=[]
            for n in [8,10,12,15,18,24]:
                p,pg=power_interaction(n,eff,atten,sd,sims=2000)
                out.append(f'n={n}:{p:.2f}/{pg:.2f}')
            print(f' sd={sd} creatine ratio={np.exp(eff):.1f} true attenuation={int(atten*100)}%  ->  '+'  '.join(out))
