import numpy as np, pandas as pd
from scipy import stats
rng=np.random.default_rng(11)
def sim(n,eff,att,sd,sims=3000):
    h=0;g=0
    for _ in range(sims):
        a=rng.normal(0,sd,n);b=rng.normal(eff,sd,n);c=rng.normal(0,sd,n);d=rng.normal((1-att)*eff,sd,n)
        ew=b.mean()-a.mean(); ek=d.mean()-c.mean(); inter=ew-ek
        s2=np.mean([x.var(ddof=1) for x in (a,b,c,d)]); se=np.sqrt(s2*4/n); p=2*stats.t.sf(abs(inter/se),4*(n-1))
        h+=(p<0.05 and inter>0); g+=(p<0.05 and ew>0 and (1-ek/ew)>=0.6)
    return h/sims,g/sims
rows=[]
for sd in [0.36,0.45,0.55]:
    for r in [2.0,3.0]:
        for att in [1.0,0.75,0.5]:
            for n in [8,12,15,18,24]:
                p,g=sim(n,np.log(r),att,sd); rows.append(dict(sd_ln_burden=sd,creatine_ratio=r,true_attenuation=att,n_per_arm=n,power_interaction=p,power_GO_rule=g))
pd.DataFrame(rows).to_csv('/tmp/work/analysis/power_table.csv',index=False); print('ok')
