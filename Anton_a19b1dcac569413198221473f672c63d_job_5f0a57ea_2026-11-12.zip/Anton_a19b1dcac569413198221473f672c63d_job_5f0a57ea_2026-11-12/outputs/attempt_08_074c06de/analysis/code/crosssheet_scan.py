"""Cross-sheet scan for shared runs (length>=3) of identical numeric values in non-qPCR sheets (finds the Fig 6b / Supp 2d overlap)."""
import sys, os, re, itertools, numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from load2 import WB, _rc
qpcr = {s for s,d in WB.items() if any(isinstance(v,str) and ('ΔCT' in v or 'Input' in v) for v in d.values())}
runs=[]
for s,d in WB.items():
    if s in qpcr: continue
    cols={}
    for k,v in d.items():
        if isinstance(v,(int,float)) and not isinstance(v,bool):
            r,c=_rc(k); cols.setdefault(c,{})[r]=float(v)
    for c,rv in cols.items():
        rows=sorted(rv); cur=[]
        for r in rows:
            if cur and r!=cur[-1][0]+1:
                if len(cur)>=3: runs.append((s,c,cur))
                cur=[]
            cur.append((r,rv[r]))
        if len(cur)>=3: runs.append((s,c,cur))
hits=[]
for (s1,c1,r1),(s2,c2,r2) in itertools.combinations(runs,2):
    if s1==s2 and c1==c2: continue
    v1=[round(v,8) for _,v in r1]; v2=[round(v,8) for _,v in r2]; best=(0,0,0)
    for i in range(len(v1)):
        for j in range(len(v2)):
            k=0
            while i+k<len(v1) and j+k<len(v2) and v1[i+k]==v2[j+k]: k+=1
            if k>best[0]: best=(k,i,j)
    if best[0]>=3 and len(set(v1[best[1]:best[1]+best[0]]))>1:
        hits.append((best[0],s1,r1[best[1]][0],s2,r2[best[2]][0],v1[best[1]:best[1]+best[0]]))
for h in sorted(hits,key=lambda x:-x[0]): print(h)
