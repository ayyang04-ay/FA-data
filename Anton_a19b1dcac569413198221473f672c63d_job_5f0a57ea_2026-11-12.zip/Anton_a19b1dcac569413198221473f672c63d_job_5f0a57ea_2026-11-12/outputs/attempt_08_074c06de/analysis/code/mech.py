import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
import statsmodels.api as sm
pd.set_option('display.width',220)
# S127 mutants: interaction WT vs S127A x vehicle vs creatine
for sh in ['Fig. 5e','Fig. 5f']:
    rows=[]
    for t,r0 in [('veh',4),('cre',17)]:
        for m,c in zip(['WT','S127A','3A','S127D'],'NOPQ'):
            for v in col(sh,f'{c}{r0}:{c}{r0+2}'): rows.append(dict(trt=t,mut=m,y=v))
    D=pd.DataFrame(rows)
    wt = D[D.mut=='WT']; print(sh,'WT veh->cre:', wt[wt.trt=='veh'].y.mean().round(3),'->',wt[wt.trt=='cre'].y.mean().round(3),
          ' t-test p=', round(stats.ttest_ind(wt[wt.trt=='cre'].y, wt[wt.trt=='veh'].y).pvalue,4))
    for m in ['S127A','3A','S127D']:
        s=D[D.mut==m]; print(f'    {m} veh->cre: {s[s.trt=="veh"].y.mean():.3f} -> {s[s.trt=="cre"].y.mean():.3f}')
    sub = D[D.mut.isin(['WT','S127A'])]
    fit = smf.ols('np.log(y) ~ C(trt,Treatment("veh"))*C(mut,Treatment("WT"))', data=sub).fit()
    print('    interaction (WT vs S127A x creatine), log scale: coef=%.3f p=%.4f' % (fit.params.iloc[3], fit.pvalues.iloc[3]))
# ChIP fold enrichment
print()
for lab,sh,regs in [('P2ry12','Fig. 5j',[(r,5+i) for i,r in enumerate(['Exon','2K','1K','0.2K'])]),('Gp6','Fig. 5j',[(r,15+i) for i,r in enumerate(['Exon','2K','1K','0.2K'])])]:
    for reg,r in regs:
        v=col(sh,f'B{r}:D{r}'); c=col(sh,f'E{r}:G{r}'); print(f'ChIP {lab} {reg}: input% veh {v.mean():.2f} -> cre {c.mean():.2f} (x{c.mean()/v.mean():.1f})')
for i,reg in enumerate(['Exon','2K','1K','0.2K']):
    r=7+i; v=col('Supplementary Fig  6i',f'C{r}:E{r}'); c=col('Supplementary Fig  6i',f'F{r}:H{r}'); print(f'ChIP Rab4a {reg}: input% veh {v.mean():.2f} -> cre {c.mean():.2f} (x{c.mean()/v.mean():.1f})')
# baseline dCT of the same gene across experiments (control group mean)
D=pd.read_csv('mouse_qpcr_stats.csv')
base = D.groupby(['gene','sheet']).dCT_ctrl.first().unstack()
cols = ['Fig. 2f','Fig. 3f','Fig. 4h','Fig. 4j','Fig. 4l','Fig.6a','Fig. 6g','Supplementary Fig  4e']
print('\nBaseline (control-group) mean ΔCT by experiment, mouse primary MKs:')
print(base[cols].round(1).to_string())
print('range across experiments (cycles):'); print((base[cols].max(1)-base[cols].min(1)).round(1).to_string())
# creatine effect sizes same gene across experiments
eff = D[D.comparison.str.contains(r'^(Creatine vs Vehicle|WT-cre vs WT-veh|Creatine vs Control|Cre\+siScr vs Ctrl\+siScr|Cre vs Veh)$')]
print('\nCreatine-induced fold (geometric) by experiment:')
print(eff.pivot_table(index='gene',columns='sheet',values='fold_geo').round(1).to_string())
