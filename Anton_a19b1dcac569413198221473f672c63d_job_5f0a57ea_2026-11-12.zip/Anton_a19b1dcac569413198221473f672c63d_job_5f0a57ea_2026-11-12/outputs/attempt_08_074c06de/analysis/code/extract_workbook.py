"""Step 0: flatten the source workbooks into wb.json / phospho.csv (run in an env with openpyxl + pandas).
Usage: python extract_workbook.py <source_data.xlsx> <phosphoproteomics.xlsx> <workdir>"""
import openpyxl, json, sys, os, pandas as pd
src, phos, wd = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(wd, exist_ok=True)
wb = openpyxl.load_workbook(src, data_only=True)
out = {ws.title.strip(): {c.coordinate: (c.value if isinstance(c.value,(int,float,str)) else str(c.value))
        for row in ws.iter_rows() for c in row if c.value is not None} for ws in wb.worksheets}
json.dump(out, open(os.path.join(wd,'wb.json'),'w'))
pd.read_excel(phos).to_csv(os.path.join(wd,'phospho.csv'), index=False)
print('wrote', wd)
