import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
df = pd.read_csv('phospho.csv'); df.columns=['gene','p','q','lfc']
N=len(df)
degen = np.isclose(df.p,0.42264973081)  # t=1, df=2 two-sided
print('rows',N,'unique genes',df.gene.nunique(),'missing gene names',df.gene.isna().sum())
print('degenerate rows (p = 0.42265, t=1 df=2 => quantified in a single replicate):',degen.sum(), f'({degen.mean()*100:.1f}%)')
print('   |lfc| of degenerate rows: median', np.median(np.abs(df.lfc[degen])).round(2), ' vs non-degenerate', np.median(np.abs(df.lfc[~degen])).round(2))
# check that p=0.42265 corresponds to t=1,df=2
print('   check two-sided p(t=1,df=2)=', 2*stats.t.sf(1,2))
nd = df[~degen]
print('non-degenerate rows', len(nd))
print('p<0.05 total',(df.p<0.05).sum(),'; expected under global null for non-degenerate', round(0.05*len(nd),1),'; observed non-degen p<0.05', (nd.p<0.05).sum())
print('p<0.001 observed',(nd.p<0.001).sum(),'expected',round(0.001*len(nd),1))
# Storey pi0 estimate on non-degenerate
lam=0.5; pi0 = ((nd.p>lam).sum()/len(nd))/(1-lam); print('Storey pi0 (lambda=0.5) =', round(pi0,3))
bh = multipletests(nd.p, method='fdr_bh')[1]; print('BH q<0.05 among non-degenerate:', (bh<0.05).sum(), ' min BH q', bh.min().round(3))
print('file q-values: min', df.q.min().round(3), 'n q<0.05', (df.q<0.05).sum(), 'n q<0.25', (df.q<0.25).sum())
thr = np.log2(1.2)
sel = (df.p<0.05)&((df.lfc>=thr)|(df.lfc<=np.log2(0.83)))
print('Convention screen (p<0.05 & FC>=1.2 or <=0.83, log2 assumed):', sel.sum(), ' up', ((df.p<0.05)&(df.lfc>=thr)).sum(), ' down', ((df.p<0.05)&(df.lfc<=np.log2(0.83))).sum())
print('lowest-p features:')
print(df.sort_values('p').head(15).to_string())
print('\nq<0.25 features:'); print(df[df.q<0.25].sort_values('q').to_string())
print('\nStat5 family rows:'); print(df[df.gene.astype(str).str.match(r'^Stat5')].to_string())
rank = df.p.rank().loc[df[(df.gene=='Stat5b')&(df.p<0.01)].index]; print('Stat5b site p-rank among', N, ':', rank.values)
