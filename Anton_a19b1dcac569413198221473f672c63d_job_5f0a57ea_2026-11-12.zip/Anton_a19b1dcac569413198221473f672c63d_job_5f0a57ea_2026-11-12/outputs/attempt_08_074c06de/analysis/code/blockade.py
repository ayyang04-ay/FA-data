import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np, pandas as pd
rng=np.random.default_rng(7)
def boot_ratio(a,b,B=20000):
    # ratio of means b/a with bootstrap CI
    ra = rng.choice(a,(B,len(a))).mean(1); rb=rng.choice(b,(B,len(b))).mean(1)
    r = rb/ra; return b.mean()/a.mean(), np.percentile(r,[2.5,97.5])
def attenuation(c0,c1,p0,p1,B=20000):
    # creatine effect (log ratio of means) in control background (c0 veh, c1 cre) vs perturbed (p0 veh, p1 cre)
    e_c = np.log(c1.mean()/c0.mean()); e_p = np.log(p1.mean()/p0.mean())
    bs=[]
    for _ in range(B):
        a=rng.choice(c0,len(c0)).mean(); b=rng.choice(c1,len(c1)).mean(); c=rng.choice(p0,len(p0)).mean(); d=rng.choice(p1,len(p1)).mean()
        ec=np.log(b/a); ep=np.log(d/c); bs.append(1-ep/ec if ec>0 else np.nan)
    bs=np.array(bs); return np.exp(e_c), np.exp(e_p), 1-e_p/e_c, np.nanpercentile(bs,[2.5,97.5])
print('=== Creatine effect on lung metastatic burden (% area), ratio of means [95% bootstrap CI]')
exps = [('Fig1b (melanoma? C57BL/6J)','Fig. 1b','B3:B8','C3:C8'),('Fig1f sh-scr tumor','Fig. 1f','B22:B27','C22:C27'),('Fig1f sh-Slc6a8 tumor','Fig. 1f','D22:D27','E22:E27'),
        ('Fig1k','Fig. 1k','B4:B9','C4:C9'),('S1e','Supplementary Fig  1e','B13:B18','C13:C18'),('S1f','Supplementary Fig  1f','B12:B15','C12:C15'),
        ('S1g','Supplementary Fig  1g','B15:B24','C15:C24'),('S1i (diet)','Supplementary Fig  1i','B11:B14','C11:C14'),('S1k','Supplementary Fig  1k','B16:B25','C16:C25'),
        ('Fig3i Pf4Cre;Slc6a8+/+','Fig. 3i','B10:B13','C10:C13'),('Fig3i Pf4Cre;Slc6a8fl/fl','Fig. 3i','D10:D13','E10:E13'),
        ('Fig6b DMSO','Fig. 6b','B4:B8','C4:C8'),('Fig6b STAT5-IN-1','Fig. 6b','D4:D8','E4:E8'),
        ('S2d donor PLT veh vs cre','Supplementary Fig  2d','C5:C10','D5:D10'),('S2d cre vs cre+aspirin donor','Supplementary Fig  2d','E5:E10','D5:D10'),
        ('Fig7g human d0 vs d7 PLT','Fig. 7g','B12:B16','C12:C16')]
rows=[]
for lab,sh,a,b in exps:
    A=col(sh,a); Bv=col(sh,b); r,ci=boot_ratio(A,Bv)
    la=np.log(A); lb=np.log(Bv); sdp=np.sqrt(((len(A)-1)*la.var(ddof=1)+(len(Bv)-1)*lb.var(ddof=1))/(len(A)+len(Bv)-2))
    rows.append(dict(exp=lab,n=f'{len(A)}/{len(Bv)}',mean_ctrl=A.mean(),mean_trt=Bv.mean(),ratio=r,lo=ci[0],hi=ci[1],sd_log_pooled=sdp))
R=pd.DataFrame(rows); print(R.round(3).to_string())
R.to_csv('creatine_effect_burden.csv',index=False)
print()
print('=== Attenuation of creatine effect (1 - logFC_perturbed/logFC_control); 1 = complete block')
for lab,(sh,c0,c1,p0,p1) in {
  'Slc6a8 MK-KO (Fig3i) burden':('Fig. 3i','B10:B13','C10:C13','D10:D13','E10:E13'),
  'Slc6a8 MK-KO (Fig3i) foci':('Fig. 3i','B17:B20','C17:C20','D17:D20','E17:E20'),
  'STAT5-IN-1 (Fig6b) burden':('Fig. 6b','B4:B8','C4:C8','D4:D8','E4:E8'),
  'STAT5-IN-1 (Fig6b) foci':('Fig. 6b','B13:B17','C13:C17','D13:D17','E13:E17'),
  'Tumor Slc6a8 KD (Fig1f) burden':('Fig. 1f','B22:B27','C22:C27','D22:D27','E22:E27'),
  'Tumor Slc6a8 KD (Fig1f) foci':('Fig. 1f','B31:B36','C31:C36','D31:D36','E31:E36'),
}.items():
    rc,rp,att,ci = attenuation(col(sh,c0),col(sh,c1),col(sh,p0),col(sh,p1))
    print(f'{lab:34s} creatine ratio ctrl={rc:.2f}, perturbed={rp:.2f}, attenuation={att*100:.0f}% [95% CI {ci[0]*100:.0f}% to {ci[1]*100:.0f}%]')
