import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
from scipy import stats
import numpy as np, pandas as pd
from statsmodels.stats.anova import AnovaRM
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250)
R = pd.read_csv('human_qpcr_recalc.csv')
R['ddct'] = R.dCTt - R.dCT0
out=[]
for (g,day),sub in R.groupby(['gene','day'],sort=False):
    x = sub.ddct.values
    ok = ~((sub.gene=='PITPNB')&(sub.vol==4))
    t,p = stats.ttest_1samp(x,0)
    t2,p2 = stats.ttest_1samp(x[ok.values],0) if (~ok).any() else (np.nan,np.nan)
    out.append(dict(gene=g,day=day,fold_per_vol=np.round(2**x,2).tolist(),geo_fold=2**x.mean(),n_up=int((x>0).sum()),p_paired=p,p_excl_V4=p2))
O = pd.DataFrame(out)
O['q_BH'] = multipletests(O.p_paired,method='fdr_bh')[1]
print(O.round(4).to_string())
# Fig 7e blots
sh='Fig. 7e'
for lab,r in [('GP6/ACTB',(4,7)),('P2RY12/ACTB',(12,15))]:
    M = np.column_stack([col(sh,f'{c}{r[0]}:{c}{r[1]}') for c in 'BCDE'])
    df = pd.DataFrame([(i,d,M[i,j]) for i in range(4) for j,d in enumerate(['0','3','7','14'])],columns=['id','day','y'])
    a = AnovaRM(df,'y','id',within=['day']).fit().anova_table
    F,pF = stats.f_oneway(*[M[:,j] for j in range(4)])
    print(f'\n{lab}: means {M.mean(0).round(3)}; fold vs d0 (per-vol) d7 {np.round(M[:,2]/M[:,0],2)} d14 {np.round(M[:,3]/M[:,0],2)}')
    print(f'   ordinary 1-way ANOVA F={F:.2f} p={pF:.4f}; RM-ANOVA F={a["F Value"].iloc[0]:.2f} p={a["Pr > F"].iloc[0]:.4f}')
    for j,d in enumerate(['3','7','14']):
        print(f'   paired t d{d} vs d0: p={stats.ttest_rel(M[:,j+1],M[:,0]).pvalue:.4f}; log-ratio paired p={stats.ttest_1samp(np.log2(M[:,j+1]/M[:,0]),0).pvalue:.4f}')
