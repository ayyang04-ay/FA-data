import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
from scipy import stats
import numpy as np, pandas as pd, re
from statsmodels.stats.multitest import multipletests
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
def letters(c):
    n=0
    for ch in c: n=n*26+ord(ch)-64
    return n
def L(n):
    s=''
    while n: n,r=divmod(n-1,26); s=chr(65+r)+s
    return s
def parse(sh, group_names):
    d = WB[sh]
    # find gene label cells in column A
    genes = {}
    for k,v in d.items():
        m = re.match(r'([A-Z]+)(\d+)$',k)
        if m and isinstance(v,str) and v.startswith('ΔCT'):
            colL, r = m.group(1), int(m.group(2))
            vals = [d.get(f'{L(letters(colL)+i)}{r}') for i in (1,2,3)]
            # evaluate formulas strings? values present as numbers
            genes.setdefault(r,{})[(colL,v)] = vals
    # gene names: col A rows
    names = {int(re.match(r'[A-Z]+(\d+)',k).group(1)):v for k,v in d.items() if k.startswith('A') and isinstance(v,str) and re.match(r'^[A-Za-z0-9]+$',v)}
    rows=[]
    # group rows into blocks by gene: gene name row r, ΔCT1 at row r (F col) and ΔCT2.. at r+1
    for r,nm in sorted(names.items()):
        blk = {}
        for rr in (r, r+1):
            for (cl,lab),vals in genes.get(rr,{}).items():
                blk.setdefault(lab, vals)
        if 'ΔCT1' not in blk: continue
        ctrl = np.array(blk['ΔCT1'],float)
        for i,lab in enumerate(['ΔCT2','ΔCT3','ΔCT4']):
            if lab not in blk: continue
            x = np.array(blk[lab],float)
            t,p = stats.ttest_ind(x,ctrl)
            rows.append(dict(sheet=sh,gene=nm,comparison=f'{group_names[i+1]} vs {group_names[0]}',dCT_ctrl=ctrl.mean(),dCT_trt=x.mean(),
                             fold_geo=2**(x.mean()-ctrl.mean()),p_t=p))
    return rows
designs = {
 'Fig. 2f':['Vehicle','Creatine'],
 'Fig. 3f':['WT-veh','WT-cre','KO-veh','KO-cre'],
 'Fig. 4h':['Control','Creatine','PCr'],
 'Fig. 4j':['Ctrl+siScr','Ctrl+siCkb','Cre+siScr','Cre+siCkb'],
 'Fig. 4l':['CKB-EV','CKB-OE'],
 'Fig.6a':['Veh','Cre','Veh+STAT5i','Cre+STAT5i'],
 'Fig. 6g':['WT-veh','WT-cre','Stat5bKO-cre'],
 'Supplementary Fig  4e':['KO Control','KO Creatine','KO Creatine@liposome'],
 'Supplementary Fig  3c':['Vehicle','Creatine'],
}
allrows=[]
for sh,g in designs.items():
    allrows += parse(sh,g)
D = pd.DataFrame(allrows)
print(D.round(4).to_string())
D.to_csv('mouse_qpcr_stats.csv',index=False)
