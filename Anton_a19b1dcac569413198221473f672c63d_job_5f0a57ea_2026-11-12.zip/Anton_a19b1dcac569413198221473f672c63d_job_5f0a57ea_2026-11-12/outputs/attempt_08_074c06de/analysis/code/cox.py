import sys; sys.path.insert(0,'.')
from load2 import *
import pandas as pd, numpy as np
from lifelines import CoxPHFitter
def getsurv(sh, r0, r1):
    rows=[]
    for r in range(r0,r1+1):
        t=cell(sh,f'A{r}'); b=cell(sh,f'B{r}'); c=cell(sh,f'C{r}')
        if t is None: continue
        rows.append(dict(T=float(t),E=1,cre=1 if c==1 else 0))
    return pd.DataFrame(rows)
for sh,(r0,r1) in {'Fig. 1c':(4,23),'Fig. 1l':(4,41)}.items():
    d=getsurv(sh,r0,r1); c=CoxPHFitter().fit(d,'T','E')
    s=c.summary.loc['cre']; print(sh, 'HR creatine', round(s['exp(coef)'],2), '95% CI', round(s['exp(coef) lower 95%'],2), '-', round(s['exp(coef) upper 95%'],2), 'p', round(s['p'],4), 'median', d[d.cre==0].T.median(), d[d.cre==1].T.median())
