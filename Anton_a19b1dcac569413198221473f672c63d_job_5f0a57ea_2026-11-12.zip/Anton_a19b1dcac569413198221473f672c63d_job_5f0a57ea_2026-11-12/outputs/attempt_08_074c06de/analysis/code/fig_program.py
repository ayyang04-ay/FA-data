import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
D=pd.read_csv('mouse_qpcr_stats.csv'); P=pd.read_csv('program_attenuation.csv')
genes=['Itga2b','P2ry12','Gp6','Gpiba','F2r','Adra2a','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
expmap={'Fig. 2f':('Creatine vs Vehicle','Fig 2f'),'Fig. 3f':('WT-cre vs WT-veh','Fig 3f*'),'Fig. 6g':('WT-cre vs WT-veh','Fig 6g'),
        'Fig. 4h':('Creatine vs Control','Fig 4h'),'Fig. 4j':('Cre+siScr vs Ctrl+siScr','Fig 4j'),'Fig.6a':('Cre vs Veh','Fig 6a')}
M=np.zeros((len(genes),len(expmap))); labs=[]
for j,(sh,(comp,lab)) in enumerate(expmap.items()):
    sub=D[(D.sheet==sh)&(D.comparison==comp)].set_index('gene')
    M[:,j]=np.log2(sub.loc[genes,'fold_geo'].values); labs.append(lab)
A=P.pivot(index='gene',columns='perturbation',values='attenuation').loc[genes]
order=['MK Slc6a8 KO (Fig 3f)','si-Ckb (Fig 4j)','STAT5-IN-1 (Fig 6a)','MK Stat5b KO* (Fig 6g)']
A=A[order]*100
fig,axs=plt.subplots(1,2,figsize=(10.5,5.2),gridspec_kw={'width_ratios':[6,4.3]})
im=axs[0].imshow(M,cmap='Reds',vmin=0,vmax=5.5,aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]): axs[0].text(j,i,f'{2**M[i,j]:.1f}\u00d7',ha='center',va='center',fontsize=7,color='white' if M[i,j]>3.5 else 'black')
axs[0].set_xticks(range(len(labs))); axs[0].set_xticklabels(labs,fontsize=7.5); axs[0].set_yticks(range(len(genes))); axs[0].set_yticklabels(genes,fontsize=8,style='italic')
axs[0].set_title('A. Creatine-induced fold change in primary MKs\n(geometric mean of 2^\u0394\u0394CT; all 66 cells >1)',fontsize=9)
plt.colorbar(im,ax=axs[0],fraction=0.04,label='log2 fold change')
im2=axs[1].imshow(np.clip(A.values,0,150),cmap='Blues',vmin=0,vmax=150,aspect='auto')
for i in range(A.shape[0]):
    for j in range(A.shape[1]): axs[1].text(j,i,f'{A.values[i,j]:.0f}%',ha='center',va='center',fontsize=7,color='white' if A.values[i,j]>100 else 'black')
axs[1].set_xticks(range(len(order))); axs[1].set_xticklabels(['MK Slc6a8\nKO (3f)','si-Ckb\n(4j)','STAT5-IN-1\n(6a)','MK Stat5b\nKO\u2020 (6g)'],fontsize=7.5)
axs[1].set_yticks(range(len(genes))); axs[1].set_yticklabels(genes,fontsize=8,style='italic')
med=A.median().values
axs[1].set_title('B. % attenuation of the creatine response\n(median: '+', '.join(f'{m:.0f}%' for m in med)+')',fontsize=9)
plt.colorbar(im2,ax=axs[1],fraction=0.05,label='% of creatine log2FC removed')
fig.text(0.01,0.01,'* Fig 3f \u0394CT values are on a different scale/sign convention from all other sheets (see integrity section); fold changes as reported by the sheet formula.\n\u2020 Fig 6g has no Stat5b-KO vehicle arm: attenuation computed against WT vehicle, so KO baseline shifts and creatine effects are confounded. >100% = below baseline.',fontsize=6.5)
plt.tight_layout(rect=(0,0.06,1,1)); plt.savefig('/tmp/outputs/figures/fig2_mk_program.png',dpi=200); print('ok')
