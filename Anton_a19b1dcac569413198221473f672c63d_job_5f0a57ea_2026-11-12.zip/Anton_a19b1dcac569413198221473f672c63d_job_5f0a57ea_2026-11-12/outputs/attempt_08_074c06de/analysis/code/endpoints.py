import sys; sys.path.insert(0,'.')
from load2 import *
import numpy as np, pandas as pd
E = {  # experiment: (sheet, lung wt (A,B), burden (A,B), foci (A,B))
 'Fig1a/b':('Fig. 1a','B3:B8','C3:C8','Fig. 1b','B3:B8','C3:C8','Fig. 1b','B12:B17','C12:C17'),
 'Fig1f scr':('Fig. 1f','B4:B9','C4:C9','Fig. 1f','B22:B27','C22:C27','Fig. 1f','B31:B36','C31:C36'),
 'Fig1j/k':('Fig. 1j','B4:B9','C4:C9','Fig. 1k','B4:B9','C4:C9','Fig. 1k','B12:B17','C12:C17'),
 'S1e':('Supplementary Fig  1e','B4:B9','C4:C9','Supplementary Fig  1e','B13:B18','C13:C18','Supplementary Fig  1e','B22:B27','C22:C27'),
 'S1f':('Supplementary Fig  1f','B4:B7','C4:C7','Supplementary Fig  1f','B12:B15','C12:C15','Supplementary Fig  1f','B20:B23','C20:C23'),
 'S1g':('Supplementary Fig  1g','B3:B12','C3:C12','Supplementary Fig  1g','B15:B24','C15:C24','Supplementary Fig  1g','B28:B37','C28:C37'),
 'S1i':('Supplementary Fig  1i','B3:B6','C3:C6','Supplementary Fig  1i','B11:B14','C11:C14','Supplementary Fig  1i','B18:B21','C18:C21'),
 'S1k':('Supplementary Fig  1k','B4:B13','C4:C13','Supplementary Fig  1k','B16:B25','C16:C25','Supplementary Fig  1k','B29:B38','C29:C38'),
 'Fig3i WT':('Fig. 3i','B3:B6','C3:C6','Fig. 3i','B10:B13','C10:C13','Fig. 3i','B17:B20','C17:C20'),
 'Fig6b DMSO':(None,None,None,'Fig. 6b','B4:B8','C4:C8','Fig. 6b','B13:B17','C13:C17'),
}
rows=[]
for k,v in E.items():
    r={'exp':k}
    for name,(sh,a,b) in zip(['lung_wt','burden','foci'],[v[0:3],v[3:6],v[6:9]]):
        if sh is None: continue
        A=np.log(col(sh,a)); B=np.log(col(sh,b))
        sd=np.sqrt(((len(A)-1)*A.var(ddof=1)+(len(B)-1)*B.var(ddof=1))/(len(A)+len(B)-2))
        r[name+'_ratio']=np.exp(B.mean()-A.mean()); r[name+'_d']=(B.mean()-A.mean())/sd
    rows.append(r)
D=pd.DataFrame(rows); print(D.round(2).to_string()); print('\nmedian standardized effect (log scale):', D[[c for c in D if c.endswith('_d')]].median().round(2).to_dict())
