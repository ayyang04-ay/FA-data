import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
from scipy import stats
import numpy as np, pandas as pd, warnings
from statsmodels.stats.multicomp import pairwise_tukeyhsd
warnings.filterwarnings('ignore')
# reported Tukey/Sidak comparisons: (set, groupA, groupB, reported mean diff, reported adj p)
sets = {
 'Fig1f lung wt': ('Fig. 1f',['B4:B9','C4:C9','D4:D9','E4:E9']),'Fig1f SUV': ('Fig. 1f',['B13:B18','C13:C18','D13:D18','E13:E18']),
 'Fig1f burden': ('Fig. 1f',['B22:B27','C22:C27','D22:D27','E22:E27']),'Fig1f foci': ('Fig. 1f',['B31:B36','C31:C36','D31:D36','E31:E36']),
 'Fig3d ADP': ('Fig. 3d',['B4:D4','E4:G4','H4:J4','K4:M4']),'Fig3d Collagen': ('Fig. 3d',['B5:D5','E5:G5','H5:J5','K5:M5']),'Fig3d Thrombin': ('Fig. 3d',['B6:D6','E6:G6','H6:J6','K6:M6']),
 'Fig3i lung wt': ('Fig. 3i',['B3:B6','C3:C6','D3:D6','E3:E6']),'Fig3i burden': ('Fig. 3i',['B10:B13','C10:C13','D10:D13','E10:E13']),'Fig3i foci': ('Fig. 3i',['B17:B20','C17:C20','D17:D20','E17:E20']),
 'Fig6b burden': ('Fig. 6b',['B4:B8','C4:C8','D4:D8','E4:E8']),'Fig6b foci': ('Fig. 6b',['B13:B17','C13:C17','D13:D17','E13:E17']),
 'Fig6e MK Cr': ('Fig. 6e',['C5:C7','D5:D7','E5:E7']),'S2d burden': ('Supplementary Fig  2d',['C5:C10','D5:D10','E5:E10']),'S2d foci': ('Supplementary Fig  2d',['C14:C19','D14:D19','E14:E19']),
 'S4b PLT': ('Supplementary Fig  4b',['C5:C7','D5:D7','E5:E7','F5:F7']),'S4c a-gran': ('Supplementary Fig  4c',['C6:C13','D6:D13','E6:E13','F6:F13']),
 'S7a PLT': ('Supplementary Fig  7a',['B4:B6','C4:C6','D4:D6','E4:E6']),'S7b PLT': ('Supplementary Fig  7b',['B4:B6','C4:C6','D4:D6']),
 'Fig5e veh': ('Fig. 5e',['N4:N6','O4:O6','P4:P6','Q4:Q6']),'Fig5e cre': ('Fig. 5e',['N17:N19','O17:O19','P17:P19','Q17:Q19']),
 'Fig5f veh': ('Fig. 5f',['N4:N6','O4:O6','P4:P6','Q4:Q6']),'Fig5f cre': ('Fig. 5f',['N17:N19','O17:O19','P17:P19','Q17:Q19']),
}
names = {'Fig1f':['scr-veh','scr-cre','sh-veh','sh-cre'],'Fig3d':['WT-veh','WT-cre','KO-veh','KO-cre'],'Fig3i':['WT-veh','WT-cre','KO-veh','KO-cre'],
 'Fig6b':['veh','cre','veh+inh','cre+inh'],'Fig6e':['WT-veh','WT-cre','KO-cre'],'S2d':['vehPLT','crePLT','cre+aspPLT'],'S4b':['WT-veh','WT-cre','KO-veh','KO-cre'],
 'S4c':['WT-veh','WT-cre','KO-veh','KO-cre'],'S7a':['veh','cre','veh+inh','cre+inh'],'S7b':['WT-veh','WT-cre','KO-cre'],'Fig5e':['WT','S127A','3A','S127D'],'Fig5f':['WT','S127A','3A','S127D']}
rows=[]
for k,(sh,rngs) in sets.items():
    groups=[col(sh,r) for r in rngs]; labs=names[k.split()[0]]
    data=np.concatenate(groups); lab=np.concatenate([[l]*len(g) for g,l in zip(groups,labs)])
    res=pairwise_tukeyhsd(data,lab); F,p=stats.f_oneway(*groups)
    for r in res.summary().data[1:]:
        rows.append(dict(set=k,group1=r[0],group2=r[1],meandiff=r[2],p_adj=r[3],lower=r[4],upper=r[5],reject=r[6],anova_F=F,anova_p=p))
pd.DataFrame(rows).to_csv('/tmp/work/analysis/verify_multi_tukey.csv',index=False); print(len(rows),'comparisons written')
