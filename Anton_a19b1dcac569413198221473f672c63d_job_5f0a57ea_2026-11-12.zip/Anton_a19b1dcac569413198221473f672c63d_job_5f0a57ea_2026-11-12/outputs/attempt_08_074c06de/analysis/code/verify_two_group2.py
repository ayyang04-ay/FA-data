import sys; sys.path.insert(0,"/tmp/work/analysis")
from load2 import *
from scipy import stats
import numpy as np
# (label, sheet, rangeA, rangeB, reported t, df, p)
tests = [
 ('Fig1a lung wt', 'Fig. 1a','B3:B8','C3:C8', 5.391,10,0.0003),
 ('Fig1a SUV', 'Fig. 1a','B12:B17','C12:C17',3.975,10,0.0026),
 ('Fig1b burden', 'Fig. 1b','B3:B8','C3:C8',5.025,10,0.0005),
 ('Fig1b foci', 'Fig. 1b','B12:B17','C12:C17',4.938,10,0.0006),
 ('Fig1i GFP cells/field', 'Fig. 1i','B4:B11','C4:C11',8.649,14,5.5e-7),
 ('Fig1j lung wt', 'Fig. 1j','B4:B9','C4:C9',4.503,10,0.0011),
 ('Fig1j SUV', 'Fig. 1j','B13:B18','C13:C18',4.693,10,0.0008),
 ('Fig1k burden', 'Fig. 1k','B4:B9','C4:C9',6.639,10,5.79e-5),
 ('Fig1k foci', 'Fig. 1k','B12:B17','C12:C17',6.652,10,5.70e-5),
 ('Fig2a PLT', 'Fig. 2a','B4:B6','C4:C6',0.005269,4,0.996),
 ('Fig2a PCT', 'Fig. 2a','B12:B14','C12:C14',0.03671,4,0.9725),
 ('Fig2a PDW', 'Fig. 2a','B19:B21','C19:C21',1.067,4,0.3459),
 ('Fig2a MPV', 'Fig. 2a','B27:B29','C27:C29',0.1195,4,0.9106),
 ('Fig2b ADP', 'Fig. 2b','B4:D4','E4:G4',11.62,4,0.0003),
 ('Fig2b Collagen', 'Fig. 2b','B5:D5','E5:G5',10.07,4,0.0005),
 ('Fig2b Thrombin', 'Fig. 2b','B6:D6','E6:G6',8.386,4,0.0011),
 ('Fig2c a-granules', 'Fig. 2c','B4:B11','C4:C11',3.071,14,0.0083),
 ('Fig2d TEG-R', 'Fig. 2d','B4:B8','C4:C8',0.1343,8,0.8965),
 ('Fig2d TEG-K', 'Fig. 2d','B12:B16','C12:C16',1.521,8,0.1667),
 ('Fig2d TEG-alpha', 'Fig. 2d','B20:B24','C20:C24',1.613,8,0.1454),
 ('Fig2d TEG-MA', 'Fig. 2d','B28:B32','C28:C32',2.321,8,0.0489),
 ('Fig2j PKH area', 'Fig. 2j','B4:B11','C4:C11',3.967,14,0.0014),
 ('Fig3b serum Cr WT', 'Fig. 3b','B4:F4','G4:K4',10.29,8,6.9e-6),
 ('Fig3b serum Cr KO', 'Fig. 3b','B5:F5','G5:K5',22.58,8,1.57e-8),
 ('Fig3c MK Cr WT', 'Fig. 3c','B4:D4','E4:G4',2.789,4,0.0493),
 ('Fig3c MK Cr KO', 'Fig. 3c','B5:D5','E5:G5',1.542,4,0.198),
 ('Fig4a MK Cr', 'Fig. 4a','B4:B6','C4:C6',10.91,4,0.0004),
 ('Fig4a brain Cr', 'Fig. 4a','D4:D6','E4:E6',3.421,4,0.0268),
 ('Fig4c MK PCr', 'Fig. 4c','B4:B6','C4:C6',9.840,4,0.0006),
 ('Fig4c brain PCr', 'Fig. 4c','D4:D6','E4:E6',3.267,4,0.0309),
 ('Fig4d MK in vitro "creatinine"', 'Fig. 4d','C4:C6','D4:D6',5.529,4,0.0052),
 ('Fig4f PCr in vitro', 'Fig. 4f','B4:B6','C4:C6',3.575,4,0.0233),
 ('Fig7g lung wt', 'Fig. 7g','B4:B8','C4:C8',2.896,8,0.02),
 ('Fig7g burden', 'Fig. 7g','B12:B16','C12:C16',3.126,8,0.0141),
 ('Fig7g foci', 'Fig. 7g','B19:B23','C19:C23',3.219,8,0.0123),
 ('S1a BW d0', 'Supplementary Fig  1a','B4:E4','F4:I4',0.1065,6,0.9186),
 ('S1a BW d7', 'Supplementary Fig  1a','B5:E5','F5:I5',2.069,6,0.0839),
 ('S1b food', 'Supplementary Fig  1b','B4:B9','C4:C9',0.006543,10,0.9949),
 ('S1c water', 'Supplementary Fig  1c','B4:B9','C4:C9',0.2215,10,0.8291),
 ('S1d serum Cr', 'Supplementary Fig  1d','B4:B9','C4:C9',23.86,10,3.8e-10),
 ('S1e lung wt', 'Supplementary Fig  1e','B4:B9','C4:C9',2.587,10,0.0271),
 ('S1e burden', 'Supplementary Fig  1e','B13:B18','C13:C18',4.535,10,0.0011),
 ('S1e foci', 'Supplementary Fig  1e','B22:B27','C22:C27',5.448,10,0.0003),
 ('S1f lung wt', 'Supplementary Fig  1f','B4:B7','C4:C7',3.030,6,0.0231),
 ('S1f burden', 'Supplementary Fig  1f','B12:B15','C12:C15',3.805,6,0.0089),
 ('S1f foci', 'Supplementary Fig  1f','B20:B23','C20:C23',5.472,6,0.0016),
 ('S1g lung wt', 'Supplementary Fig  1g','B3:B12','C3:C12',2.320,18,0.0323),
 ('S1g burden', 'Supplementary Fig  1g','B15:B24','C15:C24',7.993,18,2.48e-7),
 ('S1g foci', 'Supplementary Fig  1g','B28:B37','C28:C37',5.962,18,1.22e-5),
 ('S1h serum Cr diet', 'Supplementary Fig  1h','C4:C7','D4:D7',12.04,6,1.99e-5),
 ('S1i lung wt diet', 'Supplementary Fig  1i','B3:B6','C3:C6',5.081,6,0.0023),
 ('S1i burden diet', 'Supplementary Fig  1i','B11:B14','C11:C14',4.240,6,0.0054),
 ('S1i foci diet', 'Supplementary Fig  1i','B18:B21','C18:C21',4.841,6,0.0029),
 ('S1k lung wt', 'Supplementary Fig  1k','B4:B13','C4:C13',2.262,18,0.0363),
 ('S1k burden', 'Supplementary Fig  1k','B16:B25','C16:C25',4.046,18,0.0008),
 ('S1k foci', 'Supplementary Fig  1k','B29:B38','C29:C38',5.617,18,2.49e-5),
 ('S3a WBC', 'Supplementary Fig  3a','B4:B8','C4:C8',0.9604,8,0.365),
 ('S3a lymph', 'Supplementary Fig  3a','B12:B16','C12:C16',0.2118,8,0.8376),
 ('S3a mono', 'Supplementary Fig  3a','B20:B24','C20:C24',0.6325,8,0.5447),
 ('S3a RBC', 'Supplementary Fig  3a','B28:B32','C28:C32',1.805,8,0.1087),
 ('S5c MK Cr CKB-OE', 'Supplementary Fig  5c','B5:B7','C5:C7',0.5507,4,0.6112),
 ('S5c MK PCr CKB-OE', 'Supplementary Fig  5c','B13:B15','C13:C15',1.726,4,0.1595),
 ('S8a BMI', 'Supplementary Fig  8a','C4:C14','D4:D14',0.08538,20,0.9328),
]
rows=[]
print(f"{'test':32s} {'nA':>3s} {'nB':>3s} {'meanA':>9s} {'meanB':>9s} {'t_rep':>8s} {'t_calc':>8s} {'df':>3s} {'p_rep':>9s} {'p_calc':>9s} {'p_welch':>9s} {'g':>6s} flag")
for lab, sh, ra, rb, tr, dfr, pr in tests:
    a=col(sh,ra); b=col(sh,rb)
    t,p = stats.ttest_ind(b,a)
    tw,pw = stats.ttest_ind(b,a,equal_var=False)
    n1,n2=len(a),len(b)
    sp = np.sqrt(((n1-1)*a.var(ddof=1)+(n2-1)*b.var(ddof=1))/(n1+n2-2))
    d=(b.mean()-a.mean())/sp if sp>0 else np.nan
    g=d*(1-3/(4*(n1+n2)-9))
    flag=''
    if abs(abs(t)-abs(tr))>0.02*abs(tr)+0.01: flag+=' T-MISMATCH'
    if (p<0.05)!=(pr<0.05): flag+=' SIG-MISMATCH'
    if n1+n2-2!=dfr: flag+=' DF-MISMATCH'
    rows.append(dict(panel=lab,n_ctrl=n1,n_trt=n2,mean_ctrl=a.mean(),mean_trt=b.mean(),t_reported=tr,t_recomputed=t,df=dfr,p_reported=pr,p_recomputed_student=p,p_welch=pw,hedges_g=g,flag=flag.strip() or 'reproduced'))
    print(f"{lab:32s} {n1:3d} {n2:3d} {a.mean():9.4g} {b.mean():9.4g} {tr:8.4g} {t:8.4g} {dfr:3d} {pr:9.3g} {p:9.3g} {pw:9.3g} {g:6.2f}{flag}")

import pandas as pd; pd.DataFrame(rows).to_csv('/tmp/work/analysis/verify_two_group.csv',index=False)
