import sys; sys.path.insert(0,'/tmp/work/analysis')
from load2 import *
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
R=pd.read_csv('human_platelet_function_reanalysis.csv')
fig=plt.figure(figsize=(11,7.4))
gs=fig.add_gridspec(2,3,height_ratios=[1,1.05],hspace=0.45,wspace=0.35)
# A serum creatine
ax=fig.add_subplot(gs[0,0]); S=np.column_stack([col('Fig. 7b',f'{c}4:{c}14') for c in 'BCDE']); days=[0,3,7,14]
for r in S: ax.plot(days,r,color='grey',lw=0.8,alpha=0.7)
ax.plot(days,S.mean(0),'k-o',lw=2); ax.set_xticks(days); ax.set_xlabel('Day of creatine (20 g/d)'); ax.set_ylabel('Serum creatine (\u00b5M)')
ax.set_title('A. Exposure (Fig 7b, n=11)\nplateau by day 3: 45\u2192153 \u00b5M (3.6\u00d7)',fontsize=9)
# B heatmap of platelet function
ax=fig.add_subplot(gs[0,1:])
R['lab']=R.agonist+' '+R.endpoint
labs=list(dict.fromkeys(R.lab)); M=np.zeros((len(labs),3)); Q=np.zeros((len(labs),3)); U=np.zeros((len(labs),3))
for i,l in enumerate(labs):
    for j,d in enumerate([3,7,14]):
        row=R[(R.lab==l)&(R.day==d)].iloc[0]; M[i,j]=np.log2(row.geomean_fold); Q[i,j]=row.q_BH_all36; U[i,j]=row.n_up
im=ax.imshow(M.T,cmap='RdBu_r',vmin=-1.5,vmax=1.5,aspect='auto')
for i in range(len(labs)):
    for j in range(3):
        star='**' if Q[i,j]<0.05 else ('*' if Q[i,j]<0.1 else '')
        ax.text(i,j,f'{2**M[i,j]:.2f}{star}\n{int(U[i,j])}/11',ha='center',va='center',fontsize=6.3)
short={'collagen':'Col','EPI':'EPI','AA':'AA','ADP':'ADP'}; ep={'max agg':'max','avg agg':'avg','adhesion':'adh'}
ax.set_xticks(range(len(labs))); ax.set_xticklabels([short[l.split(' ',1)[0]]+'\n'+ep[l.split(' ',1)[1]] for l in labs],fontsize=7.5); ax.set_yticks(range(3)); ax.set_yticklabels(['day 3','day 7','day 14'],fontsize=8)
ax.set_title('B. Platelet function re-analysed as within-subject log fold vs day 0 (Fig 7c)\ncell: geometric-mean fold; ** BH q<0.05, * q<0.10 across 36 tests; k/11 = volunteers increased',fontsize=9)
plt.colorbar(im,ax=ax,fraction=0.02,label='log2 fold')
# C per-volunteer EPI adhesion vs ADP max
ax=fig.add_subplot(gs[1,0])
def mat(r0): return np.column_stack([col('Fig. 7c',f'{c}{r0}:{c}{r0+10}') for c in 'BCDE'])
for r0,c,l in [(74,'#d6604d','EPI adhesion'),(130,'#4393c3','ADP max aggregation')]:
    X=mat(r0)
    for r in X: ax.plot(days,np.log2(np.where(r>0,r,np.nan)),color=c,lw=0.7,alpha=0.5)
    ax.plot(days,np.nanmean(np.log2(np.where(X>0,X,np.nan)),0),'-o',color=c,lw=2.2,label=l)
ax.axhline(0,color='k',lw=0.6); ax.set_xticks(days); ax.set_xlabel('Day'); ax.set_ylabel('log2 fold vs day 0'); ax.legend(fontsize=7,frameon=False)
ax.set_title('C. EPI responses rise in 11/11;\nADP (P2Y12 pathway) does not',fontsize=9)
# D protein
ax=fig.add_subplot(gs[1,1])
for lab,rr,c in [('GP6/\u03b2-actin',(4,7),'#b2182b'),('P2RY12/\u03b2-actin',(12,15),'#2166ac')]:
    X=np.column_stack([col('Fig. 7e',f'{cc}{rr[0]}:{cc}{rr[1]}') for cc in 'BCDE'])
    for r in X: ax.plot(days,r/r[0],color=c,lw=0.8,alpha=0.6)
    ax.plot(days,(X/X[:,[0]]).mean(0),'-o',color=c,lw=2.2,label=lab)
ax.axhline(1,color='k',lw=0.6); ax.set_xticks(days); ax.set_xlabel('Day'); ax.set_ylabel('Fold vs day 0 (densitometry)'); ax.legend(fontsize=7,frameon=False)
ax.set_title('D. Platelet protein, n=4 (Fig 7e)\nGP6 d14 2.1\u20135.0\u00d7 (paired p=0.02)',fontsize=9)
# E CD41+ qPCR summary selected genes
ax=fig.add_subplot(gs[1,2]); H=pd.read_csv('human_qpcr_recalc.csv'); H['l2']=np.log2(H.calc_linratio)
genes=['ADRA2A','GP6','GP1BA','F2R','P2RY12','ITGA2B','RAB4A']
for k,g in enumerate(genes):
    for d,off,c in [(7,-0.17,'#fdae61'),(14,0.17,'#2b83ba')]:
        v=H[(H.gene==g)&(H.day==d)].l2.values
        ax.scatter(np.full(4,k+off),v,color=c,s=12,zorder=3,label=f'day {d}' if k==0 else None); ax.plot([k+off-0.12,k+off+0.12],[v.mean()]*2,color='k',lw=1.5)
ax.axhline(0,color='k',lw=0.6); ax.set_xticks(range(len(genes))); ax.set_xticklabels(genes,fontsize=7,rotation=45); ax.set_ylabel('log2 fold vs day 0 (\u0394\u0394CT)')
ax.legend(fontsize=7,frameon=False); ax.set_title('E. Circulating CD41+ cell transcripts, n=4\nonly ADRA2A\u2191 (d7) and RAB4A\u2193 (d14) q<0.05',fontsize=9)
plt.savefig('/tmp/outputs/figures/fig3_human_cohort.png',dpi=200,bbox_inches='tight'); print('ok')
