**Recommendation: take megakaryocyte STAT5B forward as the primary target. Use next quarter's in vivo slot for a go/no-go study: a blinded, megakaryocyte-specific Stat5b-knockout test of creatine-driven metastasis, plus an independent re-run of the STAT5-inhibitor experiment. Hold megakaryocyte creatine uptake (SLC6A8) and the platelet GPVI/GP6 arm as the two backups.**

*CRE-MK-01 (exogenous creatine, megakaryocytes and metastasis). Validation proposal to the portfolio committee for allocation of the next-quarter in vivo slot.*
*Sources: CRE-MK-01_source_data.xlsx (87 sheets), CRE-MK-01_phosphoproteomics.xlsx and study_conventions.pdf. I recomputed every number in this document from the raw per-animal, per-sample or per-volunteer values in those files. Methods are in Appendix A; code and tables are in `analysis/`. Panel references use the workbook's sheet names ("Fig 3i", "Supp 2d").*

---

## 1. The decision on one page

**What we ask for**

- The in vivo slot for **Study 1**: about 80 mice for the genetic core and about 55–65 for the pharmacology re-run.
- Approval to open the placebo-controlled human mechanistic study (**Study 4**) in parallel.

**Why STAT5B, and why now**

1. **The phenotype is robust.**
   - Creatine raised lung metastatic burden in all 10 wild-type creatine-vs-vehicle experiments in the package.
   - The pooled ratio is **3.0× (95% CI 2.5–3.6; prediction interval 1.9–4.9)**, with matching changes in foci, lung weight, PET signal and survival (HR 2.3–2.9).
   - The pro-metastatic serum exposure in mice (2.7–2.9× baseline) is *below* what our volunteers reached on 20 g/day (3.6×).
2. **It is a host megakaryocyte (MK) effect, and platelets carry it.**
   - Knocking down *Slc6a8* in tumour cells changes nothing (attenuation 8%, 95% CI −45% to 41%).
   - MK-specific *Slc6a8* deletion removes the effect (creatine ratio 3.35 → 0.85).
   - Day-7 platelets from supplemented volunteers transfer a 2.7× increase in metastasis into mice.
3. **STAT5B is the most actionable node between creatine uptake and the platelet program.**
   - Three independent perturbations each remove most of the creatine-induced 11-gene MK platelet program:
     - STAT5-IN-1: median attenuation 89%.
     - MK *Stat5b* knockout: about 82% (an upper-bound estimate).
     - MK *Slc6a8* knockout: 99%.
   - Creatine increases occupancy at the *P2ry12*, *Gp6* and *Rab4a* promoters in a ChIP assay (the ChIP target protein is not annotated in the sheets), up to 12×. It also increases nuclear STAT5B.
   - It does this **without** canonical Y694/699 phosphorylation, through a serine-127-dependent event.
   - A hub upstream of the whole effector set is a better target than any single effector. We already have both the genetic model and a tool compound that has been dosed in our mice.
4. **STAT5B is *not yet validated in vivo*, and one slot can settle it.**
   - The only in vivo STAT5–metastasis evidence is Fig 6b: a systemic, pan-STAT5A/B inhibitor.
   - **Three of the five animals in each of its vehicle and creatine arms reappear value-for-value as animals 4–6 of the aspirin platelet-transfer experiment (Supp 2d).** The burden values match to 6–7 significant digits, the foci counts match, and the order is the same. Until the raw records are reconciled, Fig 6b is not independent evidence.
   - The MK *Stat5b* knockout exists (Fig 6d–g, Supp 7b) but was never taken to a metastasis endpoint.

**Backups**

1. **MK creatine uptake (SLC6A8).** This has the cleanest causal evidence: an MK-specific genetic deletion tested in vivo, with 114% attenuation (95% CI 79–154%), and a liposomal-creatine bypass that restores the program. It is weak as a drug target in our data:
   - No blocker has been tested in our system.
   - Creatine handling extends beyond MKs (brain creatine and phosphocreatine also rose, Fig 4a/4c).
   - Knockout platelets behave paradoxically: creatine *lowers* their aggregation below knockout-vehicle levels.
2. **GPVI (GP6).** This is the effector with the best human concordance:
   - Platelet GP6 protein rose in 4/4 volunteers (2.1–5.0× by day 14).
   - Collagen responses rose 2.5× (9/11 volunteers; q = 0.03).
   - In mice, *Gp6* was induced in 6/6 MK experiments and its promoter responds in ChIP.
   - It has not yet been tested causally.

**What we are not taking forward**

- **P2Y12:** ADP responses in volunteers never moved (day-14 geometric mean 1.07×; all nine ADP tests p ≥ 0.18).
- **CKB:** the evidence is in vitro only and gives the weakest block (median 59%). Direct CKB→S127 phosphorylation rests on one pan-phospho blot without controls, and CKB is far more abundant in brain than in MKs.
- **COX-1/aspirin:** its only evidence sits in the dataset that overlaps Fig 6b.
- **Tumour-cell SLC6A8:** excluded by Fig 1f.
- **ADRA2A (the α2A-adrenergic receptor)** is an *exploratory* lead that emerges from our human data (see §2.6).

**Strategic caveat that should cap the valuation.**

- In every in vivo experiment, blocking the axis returned metastasis to vehicle level and **never below it**:
  - *Slc6a8*-cKO vehicle: 3.4% vs wild-type vehicle 2.4%.
  - STAT5-IN-1 alone: 3.6% vs 3.4%.
- The axis therefore *amplifies* metastasis under creatine exposure; it does not drive metastasis in general.
- Any drug on it would be positioned for creatine-exposed patients and would need an exposure/response biomarker.
- Simply avoiding exposure is a competing, no-cost intervention. Studies 4–5 are included to size this.

**Pre-specified go/no-go for the slot (Study 1)**

| Gate | Criterion | Consequence |
|---|---|---|
| 0. Assay validity | Creatine reproduces ≥1.5× burden (p < 0.05) in Cre-control mice **under blinding** | If not met: stop and re-examine the phenotype. All prior in vivo data were unblinded. |
| GO | Genotype × creatine interaction p < 0.05 **and** ≥60% attenuation in Pf4-iCre;*Stat5b*^fl/fl^. Platelet hyperreactivity normalised. No baseline platelet-count or bleeding defect beyond pre-set margins. STAT5-IN-1 re-run reproduces ≥60% block. | STAT5B is validated. Start selectivity/PK-PD work. |
| Partial | 30–60% attenuation, or genetics and pharmacology disagree | Targeted follow-up (STAT5A redundancy, cell of action) before any further investment |
| NO-GO | <30% attenuation | Drop STAT5B. GPVI goes to the next slot. SLC6A8 remains the validated node. |

**Four things to resolve before the meeting**

1. The raw animal records for Fig 6b and Supp 2d.
2. Raw aggregometry traces for Fig 2b and 3d, and raw (not fold) human values for Fig 7c.
3. Raw Ct exports for all qPCR, especially Fig 3f and volunteer 4 in Fig 7d.
4. Site-level phosphoproteomics output.

Details and rationale are in §7.

---

## 2. Evidence base (what the data show and how I derived it)

### 2.1 The phenotype: creatine raises lung metastasis, reproducibly

![Figure 1](figures/fig1_forest_metastasis.png)

*Figure 1. Ratio of mean lung metastatic burden (% area) for every comparison in the package, with bootstrap 95% CIs. Red marks the experiments that share animals (see §2.7).*

**Table 1. Creatine vs vehicle in wild-type hosts (all values recomputed from per-animal data).**

| Experiment | n (veh/cre) | Burden % veh → cre | Burden ratio [95% CI] | Foci veh → cre (ratio) | Lung wt g veh → cre (ratio) |
|---|---|---|---|---|---|
| Fig 1a/1b | 6/6 | 5.2 → 16.2 | 3.12 [2.16–4.82] | 27.7 → 53.2 (1.92×) | 0.227 → 0.324 (1.43×) |
| Fig 1f (tumour sh-scrambled) | 6/6 | 4.6 → 15.9 | 3.50 [2.25–6.29] | 10.7 → 27.3 (2.56×) | 0.187 → 0.309 (1.66×) |
| Fig 1j/1k | 6/6 | 7.2 → 16.4 | 2.27 [1.92–2.70] | 25.5 → 42.2 (1.65×) | 0.185 → 0.302 (1.63×) |
| Supp 1e | 6/6 | 16.2 → 33.6 | 2.07 [1.57–2.86] | 40.7 → 66.8 (1.64×) | 0.220 → 0.294 (1.34×) |
| Supp 1f | 4/4 | 3.9 → 10.8 | 2.77 [1.89–4.42] | 7.0 → 18.5 (2.64×) | 0.147 → 0.180 (1.22×) |
| Supp 1g | 10/10 | 7.6 → 26.2 | 3.45 [2.34–5.67] | 14.8 → 44.7 (3.02×) | 0.207 → 0.278 (1.34×) |
| Supp 1i (5% creatine diet) | 4/4 | 7.3 → 26.2 | 3.60 [2.50–5.05] | 17.0 → 25.5 (1.50×) | 0.253 → 0.362 (1.44×) |
| Supp 1k | 10/10 | 3.8 → 13.4 | 3.54 [2.29–5.49] | 3.4 → 8.3 (2.44×) | 0.153 → 0.199 (1.30×) |
| Fig 3i (Pf4-Cre;*Slc6a8*^+/+^) | 4/4 | 2.4 → 7.9 | 3.35 [2.36–5.42] | 29.8 → 56.5 (1.90×) | 0.206 → 0.249 (1.21×) |
| Fig 6b (DMSO arm)† | 5/5 | 3.4 → 13.9 | 4.02 [3.11–5.29] | 30.2 → 58.2 (1.93×) | — |
| **Pooled (random effects, k = 10)** | | | **3.02 [2.54–3.58]**, I² = 51% | | |

*† This arm shares three animals per group with Supp 2d (§2.7). Supp 2d is not included in the pooled estimate, so nothing is double-counted.*

**Supporting readouts**

- **PET signal (SUV-BW):** 418 → 894 (Fig 1a) and 615 → 1,032 (Fig 1j).
- **Survival:**
  - Fig 1c: median 22 → 19 days, HR 2.93 (95% CI 1.04–8.23), log-rank p = 0.032.
  - Fig 1l: median 16 → 14 days, HR 2.28 (1.16–4.46), p = 0.011.
- **Early lung retention (Fig 1h; units not annotated):**
  - Identical at 15 min (ratio 0.86, p = 0.31).
  - Diverges from 6 h onward: 1.5× at 6 h, 1.8× at 12 h and 2.8× at 24 h.
  - This pattern fits protection of arrested tumour cells, not increased initial seeding.
- **Controls:** body weight, food intake and water intake were unchanged (Supp 1a–c).
- **Endpoint choice:**
  - On the log scale, burden, foci and lung weight all have similar standardised effects (median d ≈ 2.8–2.9).
  - Burden carries the largest fold change, so it is the proposed primary endpoint.
  - Within-group SD of ln(burden) across the 10 experiments: median 0.36 (IQR 0.30–0.49). This drives the sample sizes in §4.
- **Scope:** all metastasis readouts are lung. Only one tumour type is named (melanoma, Fig 1f). The second syngeneic model, in female BALB/cJ mice, is not named in the conventions.

### 2.2 Exposure: the mouse regimens sit inside the human range

| | Regimen | Dose, g/kg/day | Serum creatine, baseline → exposed | Fold |
|---|---|---|---|---|
| Mouse, gavage (Supp 1d) | 17 mg/dose, 3×/week | ≈0.33 (body weight ≈22 g) | 66 → 179 µM | 2.7× |
| Mouse, gavage (Fig 3b, *Slc6a8*^+/+^) | same | ≈0.33 | 89 → 239 µM | 2.7× |
| Mouse, 5% diet (Supp 1h) | ad libitum | ≈6.5 (assumes food ≈2.9 g/day, as in Supp 1b) | 78 → 227 µM | 2.9× |
| Human (Fig 7b, n = 11) | 20 g/day for 14 days | ≈0.35 (57.6 kg) | 45 → 153 µM by day 3, plateau to day 14 | 3.6× (minimum 2.3×) |

- The per-kg gavage dose and the serum elevation are comparable to, or below, the human loading regimen. The mouse findings are therefore at human-relevant exposure.
- The human study tested only one (high) dose. The dose-response is unknown.

### 2.3 Where creatine acts: host megakaryocytes, with platelets as the carrier

**Not the tumour**

- Tumour-cell *Slc6a8* shRNA reduced the transcript to 0.19× (Supp 2a). The creatine effect was unchanged: 3.50× (scrambled) vs 3.15× (knockdown), attenuation 8% (95% CI −45% to 41%) (Fig 1f).
- The sheet's own Tukey test agrees: scrambled-creatine vs sh-creatine, adjusted p = 0.60 for burden.

**Megakaryocyte uptake is required (Fig 3; Pf4-Cre;*Slc6a8*^fl/fl^)**

- Serum creatine rises equally in both genotypes (89 → 239 µM in wild type vs 89 → 218 µM in cKO; Fig 3b).
- MK intracellular creatine:
  - Rises in wild type: 13.7 → 72.1 (5.3×; Student p = 0.049, Welch p = 0.105, n = 3).
  - Does not rise in cKO: 13.7 → 21.1 (p = 0.20) (Fig 3c).
- **Metastasis (Fig 3i):**
  - Wild type 2.36% → 7.91% (3.35×).
  - cKO 3.39% → 2.88% (0.85×).
  - Attenuation 114% (95% CI 79–154%) for burden and 111% for foci.
  - n = 4 per group.
- α-granules: 2.6 → 5.1 per field in wild type; 2.25 → 2.25 in cKO (Supp 4c; fields are the unit, see §2.7).
- Platelet counts and indices are unaffected by creatine in any genotype (Fig 2a, Supp 4b, 7a, 7b), and in humans (Supp 8b: platelet count 253 → 245, MPV 10.1 → 10.2). Creatine changes platelet *quality*, not number.

**Platelets carry the phenotype**

- Human day-7 platelets into mice: burden 4.65% → 12.66% (2.72×, 95% CI 1.70–4.39; p = 0.014; n = 5 mice per group; donor number not stated) (Fig 7g).
- Mouse creatine-donor platelets: 3.06× (Supp 2d, overlapping dataset).
- Creatine does not visibly change GP6/P2RY12 in *isolated platelets* in vitro (0–2 mM, Fig 2i blots), whereas MKs respond. The effect is on the platelet-producing cell.

**Timing in humans points to the same conclusion**

- Serum creatine plateaued by day 3.
- None of the 12 platelet-function endpoints had moved by day 3 (geometric-mean folds 0.73–1.08).
- Changes appear only at days 7–14. This lag is expected if *new* platelets from reprogrammed MKs carry the effect. A direct effect on circulating platelets would have shown up at day 3.

### 2.4 Signalling: SLC6A8 → CKB → STAT5B → platelet-activation program

![Figure 2](figures/fig2_mk_program.png)

*Figure 2. (A) Creatine-induced fold change of the 11-gene MK program across six experiments (all 66 gene × experiment cells > 1; range 1.6–42×). (B) Share of the creatine response removed by each perturbation. Attenuation = 1 − log2FC(perturbed)/log2FC(control), computed from the per-sample ΔCT values.*

**Table 2. Each node of the proposed pathway.**

| Node | Necessity | Sufficiency / bypass | In vivo | Caveats |
|---|---|---|---|---|
| **SLC6A8 (MK)** | cKO blocks MK creatine rise (Fig 3c), program (median 99%, Fig 3f), aggregation and α-granules (Fig 3d, Supp 4c) and metastasis (Fig 3i) | Liposomal creatine restores the program in cKO MKs: 9/11 genes 2.1–4.0×, vs plain creatine 0.18–1.50× (Supp 4e) | **Yes, genetic, MK-specific (n = 4/group)** | cKO + creatine *lowers* aggregation below cKO vehicle (ADP 54 → 31%) and lowers *F2r* (0.18×) and *Runx1* (0.56×) in cKO MKs: unexplained. Residual SLC6A8 band in cKO (Supp 4a). Fig 3f ΔCT scale anomalous. |
| **CKB** | si-*Ckb* attenuation median 59% (4/11 genes ≥75%; Fig 4j) | CKB overexpression induces all 11 genes 1.7–6.0× (Fig 4l) *without* changing MK creatine (33.7 vs 32.7) or phosphocreatine (0.17 vs 0.21) (Supp 5c). Exogenous phosphocreatine does *not* mimic (0.29–1.12×, Fig 4h). Creatine raises *Ckb* 1.8× (Fig 4e) and CKB protein (Fig 4b, 4e, 6f). | None | In vitro only. Knockdown partial. The in vitro kinase assay (Supp 6d) is one pan-phospho blot with no S127A or kinase-dead control. CKB protein is far higher in brain than in MKs (Fig 4b). |
| **STAT5B (MK)** | STAT5-IN-1: median 89% (9/11 genes ≥75%; Fig 6a). MK *Stat5b* KO: about 82% (6/11 ≥75%; Fig 6g), an upper bound because there is **no KO-vehicle arm**. KO does not affect MK creatine uptake (95 vs 98 µmol/g, Fig 6e), which places STAT5B downstream of uptake. | S127D raises baseline pan-phospho signal (1.05 vs 0.72, Fig 5e) | **Only STAT5-IN-1 (pan-STAT5A/B, systemic): attenuation 85% for burden and 113% for foci (Fig 6b).** Dataset overlaps Supp 2d. | STAT5-IN-1 *alone* suppresses baseline *Gp6* 0.39×, *Gp1ba* 0.37×, *Adra2a* 0.28×, *Rab4a* 0.21× (possible haemostatic liability). Residual induction in KO: *P2ry12* 1.9× (p = 0.04), *Adra2a* 1.9× (p = 0.012). |

**Evidence on how creatine reaches STAT5B**

- **Promoter occupancy (ChIP; target protein not annotated in the sheets):**
  - *P2ry12*: 2K 4.8×, 1K 4.6×, 0.2K 12.1×.
  - *Gp6*: 1K 3.8×, 0.2K 2.9× (2K unchanged).
  - *Rab4a*: 1K 2.7×, 0.2K 5.5×.
  - Exon control regions are unchanged (0.7–1.3×) (Fig 5j, Supp 6i; Sidak-adjusted p-values reproduce).
- **Nuclear STAT5B** is higher with creatine (Supp 6h). This is qualitative: two lanes per group, no densitometry.
- **Non-canonical activation:**
  - p-STAT5A/B (Y694/699) is undetectable in MKs with or without creatine, while the Jurkat + IL-2 positive control works (Supp 6a).
  - Pan-phospho/FLAG signal on STAT5B rises with creatine by 39% (Fig 5e, p = 0.009) and 28% (Fig 5f, p = 0.087).
  - S127A blunts this (WT vs S127A × creatine interaction: p = 0.036 in Fig 5e, p = 0.052 in Fig 5f).
  - Support is consistent but modest, and it relies on a *pan*-phospho antibody. Several blots are saturated or show shifting molecular-weight markers (Fig 5e/5f replicate 2).
- **Phosphoproteomics gives no FDR-level support:**
  - 5,812 phosphopeptides from 2,033 genes; the file contains **no residue positions**.
  - Minimum q = 0.167; 0 peptides with q < 0.05; π₀ ≈ 0.95.
  - About 1,940 rows (33%) sit at degenerate p-values (p = 0.4226, i.e. t = 1 with df = 2, and p ≈ 0.18, i.e. t = 2 with df = 2). These are peptides quantified in only one or two replicates of one group: presence/absence artefacts with large apparent fold changes (median |log2FC| 3.6 in the p = 0.4226 group vs 0.44 elsewhere).
  - One *Stat5b* phosphopeptide ranks 17th of 5,812 (p = 0.0012, log2FC +5.7, q = 0.25). The other *Stat5b* peptide and *Stat5a* are flat.
  - The file cannot confirm that the hit is S127.

### 2.5 Platelet phenotype in mice

- **Aggregation rises with creatine:**
  - Fig 2b: ADP 42 → 57%, collagen 66 → 79%, thrombin 25 → 56% (n = 3).
  - Fig 3d, wild type: ADP 63 → 71%, collagen 65 → 77%, thrombin 61 → 75%.
- **α-granules:** 2.0 → 3.9 per field (Fig 2c).
- **Platelet signal in lung:** PKH-positive area 1.9 → 4.5% (Fig 2j).
- **TEG:** maximal amplitude 39.7 → 54.0 mm (p = 0.049; Welch p = 0.052); R, K and α unchanged (Fig 2d). This is a weak clot-strength signal to monitor for safety.
- **Caveat:** the aggregation values in Fig 2b and 3d have structural anomalies (§2.7). These functional data carry less weight than the metastasis and expression data until the raw traces are seen.

### 2.6 Human cohort, re-analysed

![Figure 3](figures/fig3_human_cohort.png)

*Figure 3. Human study re-analysed within subject. Platelet function (Fig 7c) is reported only as fold vs day 0. I analysed log2 fold with one-sample t-tests (Wilcoxon as a sensitivity check), with Benjamini–Hochberg correction across all 36 agonist × endpoint × day tests. The original analysis treated the repeated measures as independent groups, with day 0 fixed at 1 and therefore zero variance.*

**Design limits**

- 11 young, healthy Asian volunteers (6 women, 5 men; age 20.9 years; BMI 20.9).
- Single arm with no placebo and a single baseline. Regression to the mean and time effects cannot be excluded.
- One dose (20 g/day).
- Mechanistic assays on a random 4 of the 11.
- Raw aggregation values and the coagulation tests (collected per the conventions) are not in the package.

**Platelet function (n = 11)**

- **Epinephrine (EPI) responses are the most consistent signal:**
  - Day 7: average aggregation 1.46× (10/11, q = 0.044); adhesion 1.78× (11/11, q = 0.033).
  - Day 14: maximum 1.63× (10/11, q = 0.033); average 1.82× (11/11, q = 0.032); adhesion 2.11× (11/11; the only test surviving Holm correction, p = 0.032).
- **Collagen (GPVI):**
  - Day-14 maximum aggregation 2.51× (9/11, q = 0.033); average aggregation 2.72× (q = 0.066). Skewed; one volunteer at 11.8×.
- **ADP (P2Y12): no change at any time.** Day-14 maximum 1.07× (6/11 up, p = 0.69). All nine ADP tests p ≥ 0.18.
- **Arachidonic acid (AA; COX-1):** borderline. Day-14 adhesion 1.78× (p = 0.033, q = 0.13).

**Platelet protein (Fig 7e, n = 4; immunoblot densitometry, not transcript)**

- **GP6:** up in 4/4 volunteers at day 7 (1.5–3.8×, paired p = 0.044) and day 14 (2.1–5.0×, p = 0.022).
- **P2RY12:** modestly up at day 14 (1.3–2.7×, p = 0.025).

**Circulating CD41+ cell transcripts (Fig 7d, n = 4; these are not megakaryocytes)**

- Only two results survive FDR:
  - *ADRA2A* up 20.5× at day 7 (4/4, q = 0.018); still 4.0× at day 14 (p = 0.03).
  - *RAB4A* **down** 0.36× at day 14 (4/4, q = 0.039). This is the opposite direction to the mouse, where *Rab4a* is a ChIP-responsive target that goes up.
- *GP6* is 6.9× at day 7 (p = 0.054). *P2RY12* is not significant.
- Nearly all genes, including the isolation marker *ITGA2B* (CD41) itself, shift together at day 7 (up to 10–28× in some volunteers). This suggests a change in the composition of the CD41+ fraction or in the ACTB reference, so single-gene human transcript calls are weak.

**What this means for target choice**

- In humans the creatine response maps to **collagen/GPVI** and **epinephrine/α2A** platelet pathways, not ADP/P2Y12.
- That is why GPVI is a backup, P2Y12 is deprioritised, and ADRA2A is flagged as exploratory. Mouse EPI responses were never measured.

### 2.7 Data integrity and quality audit (ranked by impact on this decision)

![Figure 4](figures/fig4_integrity.png)

*Figure 4. (A) Animals shared between Fig 6b and Supp 2d. (B–C) Regularity of the aggregation triplicates. (D) Phosphoproteomics p-value distribution. (E) Baseline ΔCT of the same gene across experiments. (F) Human qPCR folds as reported vs recomputed.*

| # | Finding | How detected | Impact on the decision |
|---|---|---|---|
| 1 | **Fig 6b (STAT5-IN-1 in vivo) and Supp 2d (aspirin-treated donor platelets) share three animals per vehicle and creatine arm.** Burden 3.29136/3.733544/2.886353 (vehicle) and 11.13465/13.22011/14.12619 (creatine), with paired foci 37/25/33 and 53/62/47, in the same order (6b animals #2–4 = 2d #4–6). | Cross-sheet scan of every numeric run of length ≥ 3 (non-qPCR sheets). This was the only non-trivial shared sequence. | **High.** It removes the independence of the *only* in vivo STAT5 evidence and the *only* antiplatelet (aspirin) evidence. This is why Study 1 re-runs the pharmacology. |
| 2 | **Aggregation values look reconstructed.** Fig 2b: all 6 triplicates are exact arithmetic progressions (mean ± integer SD; simulated joint P ≈ 1.3 × 10⁻⁵). Fig 3d: 36/36 values are even (P ≈ 1.5 × 10⁻¹¹ if parity were random; Fig 2b uses the same readout and has odd values), and 11/12 groups have the identical SD of 1.155. | Pattern tests against rounded-normal simulations | **Medium.** Mouse platelet-*function* evidence (and the *Slc6a8*-cKO paradox) is down-weighted until raw traces are provided. Expression and metastasis data are unaffected. |
| 3 | **qPCR ΔCT values are not on a common scale.** Baseline ΔCT for the same gene in the same cell type spans 7–19 cycles across experiments. Fig 3f has mostly positive ΔCT, so no single ΔCT convention makes its baselines plausible. Human volunteer 4 *PITPNB* "ΔCT" ≈ +27 (looks like raw Ct). 6 of 132 human fold values (volunteer 4 *RAB27B* and *PITPNB*) cannot be reproduced from the ΔCT values. The other 126 reproduce exactly. | Recalculation from ΔCT | **Low–medium.** The *direction* of the mouse program is robust (66/66 cells up). Traceability needs raw Ct. |
| 4 | **Phosphoproteomics:** no FDR-significant site; 33% missing-value artefacts; no residue information. | Re-analysis (§2.4) | **Medium.** The S127 mechanism rests on pan-phospho blots only. |
| 5 | **Design:** allocation not masked at any stage; no sample-size calculation; sex not analysed and confounded with strain/model (male C57BL/6J vs female BALB/cJ); no *Stat5b*-KO vehicle arm (Fig 6g); pseudo-replication (Fig 1i, 2c, 2j and Supp 4c use 8 microscope fields as n); donor number not stated for Fig 7g; human study single-arm. | Study conventions + sheet structure | **Medium.** Effect sizes may be inflated. The new work must be blinded, powered and include both sexes. |
| 6 | **Statistics:** every reported test statistic reproduces (all 63 two-group t-tests, all Tukey comparisons, the ChIP Sidak tests, all 48 human Dunnett comparisons, both log-rank tests). Student's t was used throughout; Welch changes Fig 3c (0.049 → 0.105), 4f (0.023 → 0.061) and 2d MA (0.049 → 0.052). Human repeated measures were analysed as independent groups, with no multiplicity control across 36 tests. | Recalculation | Low. My re-analysis keeps the human EPI/collagen signal and adds EPI at day 7. |
| 7 | **Labelling and blots:** Fig 1f Tukey row labelled "WT-creatine vs si-Slc6a8-creatine"; Fig 4d labelled "Creatinine"; "ADAR2A" for ADRA2A (Fig 7d). β-actin runs on separate gels (per the conventions). GP6 apparent molecular weight varies between blots (≈45–60 kDa). | Inspection | Low. Clean-up items. |

---

## 3. Target comparison

**Table 3. Scorecard** (evidence is from this package only; external literature is not used).

| Criterion | **STAT5B (MK)** | SLC6A8 (MK) | GPVI / GP6 | P2Y12 | CKB | COX-1 (aspirin) | ADRA2A |
|---|---|---|---|---|---|---|---|
| Causal in vivo, MK-specific genetics | Not tested; **line in hand** | **Yes** (Fig 3i; 114% block) | No | No | No | No | No |
| In vivo pharmacology | STAT5-IN-1 block (Fig 6b), **data overlap** | None | None | None | None | Supp 2d, **data overlap** | None |
| Ex vivo necessity/sufficiency | Strong (6a, 6g, ChIP, nuclear) | Strong (+ bypass) | Effector; induced 6/6 | Effector; induced 6/6 | Moderate (in vitro) | Not part of the induced program | Induced 6/6; least uptake-dependent |
| Human concordance (our cohort) | Not measured | Indirect (exposure, timing) | **GP6 protein ↑ 4/4; collagen ↑** | **ADP flat** | Not measured | AA not significant after correction | ***ADRA2A* ↑, EPI ↑ 11/11** |
| Liability signal in our data | STAT5-IN-1 lowers baseline *Gp6*/*Gp1ba*/*Rab4a* | cKO lowers baseline aggregation; creatine paradox | — | — | CKB brain ≫ MK | — | — |
| Tool dosed in our mice | **Yes** (5 mg/kg/day) | No | No | No | No | Yes (30 mg/kg/day) | No |
| Value of next quarter's slot | **Highest**: one experiment decides it | Low: already shown; tractability unresolved | Moderate: next slot | Low | Not feasible (no MK line) | Low | Not ready (no mouse function data) |

**Why this ranking**

- **STAT5B is primary** because it combines three things:
  - the strongest mechanistic convergence downstream of uptake;
  - a tool compound already dosed in our mice;
  - a decisive experiment that can run next quarter with mice we already have.
- Its one critical weakness, the compromised in vivo evidence, is exactly what the slot removes.
- SLC6A8 has the best causal evidence but the least to gain from another in vivo run.
- GPVI has the best human concordance but needs a causal test first; it is the natural next-slot candidate if STAT5B fails.

---

## 4. Proposed studies

**Indication hypothesis carried through all studies**

- **Indication:** prevention of creatine-amplified haematogenous metastasis in patients with solid tumours who are exposed to supplemental creatine. Melanoma comes first because it is the only tumour type named in the package.
- **Patient selection:** an exposure biomarker (serum creatine) plus a response biomarker (platelet EPI/collagen reactivity or platelet GP6), both to be qualified in Studies 4–5.
- **Benchmarks any drug must beat:** exposure avoidance (no drug) and standard antiplatelet therapy (aspirin is the comparator already used in our system).

### Study 1 (the in vivo slot): is MK STAT5B necessary for creatine-driven metastasis?

| Element | Specification |
|---|---|
| **Questions** | (1) Is MK STAT5B required for creatine-driven lung metastasis and platelet hyperreactivity? (2) Does pharmacological STAT5 inhibition reproduce the block, independently of the Fig 6b dataset, and at what haemostatic cost? |
| **Population** | **Core A:** Pf4-iCre;*Stat5b*^fl/fl^ and Cre-positive *Stat5b*^+/+^ littermates (the line used in Fig 6d–g), both sexes balanced, age-matched. **Core B:** wild-type C57BL/6J, both sexes. |
| **Model / indication** | The melanoma lung-metastasis protocol of Fig 1f (same cell line, route and timing), provided the line is syngeneic to the genetic lines' background. Confirm this first: the conventions name only C57BL/6J and BALB/cJ, and do not state which tumour line Fig 3i used. Indication modelled: haematogenous lung metastasis of melanoma under creatine exposure. |
| **Exposure** | Creatine monohydrate 42.5 mg/mL, 400 µL, oral, 3×/week vs water, with the package's lead-in. PD check: serum creatine ≥2.5× at endpoint. |
| **Arms and comparators** | **Core A, 2 × 2:** genotype (cKO vs Cre+ littermate) × creatine vs vehicle; **n = 18/arm** (9 female + 9 male). **Core B, 2 × 2:** creatine vs vehicle × STAT5-IN-1 (5 mg/kg/day oral) vs DMSO; **n = 12/arm**. Recommended fifth arm: creatine + aspirin 30 mg/kg/day (active comparator; re-tests Supp 2d cleanly). |
| **Randomisation and masking** | Computer-generated allocation stratified by sex, litter and cage. Dosing from coded preparations made up by a third party. Tumour injection and every readout blind to allocation. Coded slides with automated histomorphometry. Coded aggregometry. Independent statistician holds the key. |
| **Primary endpoint** | Lung metastatic burden (% lung area), blinded. ln(burden) analysed with a linear model: genotype × creatine interaction, with sex and litter/batch as covariates. |
| **Key secondary (hierarchical)** | Metastatic foci; lung weight; platelet aggregation to ADP, collagen, thrombin **and epinephrine** (to bridge to the human signal); platelet surface GPVI, P2Y12 and α2A. Survival in an optional separate cohort. |
| **Mechanistic / PD** | Serum and MK creatine. MK 11-gene program with **raw Ct exported** and a KO-vehicle arm (fixes the Fig 6g gap). Site-specific S127 and Y699 in MKs. Nuclear STAT5B. CKB. **Deletion efficiency and lineage specificity** (MKs vs leukocytes), because the package verifies deletion only in MKs. |
| **Safety** | Platelet count/MPV, tail bleeding time, TEG (MA), CBC, body weight. Critical for STAT5-IN-1 given its baseline suppression of *Gp6*/*Gp1ba*/*Rab4a*. |
| **Sample size (derived from the package)** | Assumed within-group SD of ln(burden): 0.36–0.45 (package median 0.36, IQR 0.30–0.49). Simulated power for the interaction test: **Core A, n = 18/arm: ≥90%** for a full block even if the blinded creatine effect shrinks to 2.0× (SD 0.45); ≈85% to meet the GO rule if the true block is 75% of a 3× effect. **Core B, n = 12/arm: ≥97%** for a full block of a 3× effect. Add 10% for attrition. **Totals:** Core A ≈ 80 mice; Core B ≈ 53 (+13 for the aspirin arm). Minimum decisive version if capacity is short: Core A alone. |
| **Decision rules** | Gates as in §1, pre-registered with the analysis plan. Exclusion criteria (e.g. failed injection, humane end-points before the read-out day) fixed before unblinding. All animals reported (ARRIVE). Raw images, instrument exports and Ct files locked at acquisition. |
| **Optional add-on C** | Platelet transfer from tumour-free donors (wild-type vehicle, wild-type creatine, cKO creatine) into wild-type tumour-bearing recipients, n = 10/arm, with the donor as the unit. Tests whether the STAT5B dependence travels with platelets, and replaces the compromised Supp 2d design. |
| **Logistics** | Start colony expansion now: about 80 sex-balanced cKO and Cre+ littermates are needed. If numbers fall short, run two blocks and include block in the model. |

### Study 2 (bench, runs in parallel, no slot needed): make the mechanism decision-grade

- **S127 readout:**
  - Use a site-specific readout (antibody or targeted MS) in primary MKs.
  - Test whether the creatine-induced S127 signal is *Slc6a8*- and *Ckb*-dependent (si-*Ckb* plus catalytically inactive CKB rescue).
  - Confirm Y699 is unchanged.
  - Repeat the in vitro kinase assay with S127A and kinase-dead controls.
- **Phosphoproteomics:** repeat at n ≥ 5 per group, with site localisation, missing-value handling and FDR.
- **ChIP:** use a defined antibody, with IgG and *Stat5b*-KO MK controls.
- **Raw data:** raw-Ct reprocessing of all qPCR, with a second reference gene.
- **Why it matters:** this decides whether a *selective* (non-canonical, S127/CKB-interface) intervention thesis is credible. It does not decide whether STAT5B is the hub; Study 1 does that.

### Study 3 (backup in vivo: triggered by a NO-GO, or the following slot)

- **GPVI arm:**
  - Wild-type mice, creatine vs vehicle × GPVI function-blocking/depleting antibody vs isotype.
  - Aspirin as the active comparator.
  - n = 12–15/arm; same primary endpoint.
  - Secondary endpoints: collagen aggregation and bleeding time.
  - Optionally add α2A antagonism if the mouse EPI data from Study 1 are positive.
- **If SLC6A8 is chosen instead:**
  - Blinded replication of Fig 3i in both sexes.
  - Resolve the cKO-plus-creatine paradox.
  - Add a **reversibility cohort** (creatine withdrawal, then time to normalisation of the platelet phenotype and of metastasis). This directly informs exposure-avoidance advice.

### Study 4 (human): randomised, placebo-controlled mechanistic study

| Element | Specification |
|---|---|
| **Population** | Healthy adults aged 18–60, both sexes (each ≥40%), at least two ancestries. No antiplatelet/NSAID use for ≥14 days; no creatine use for ≥3 months. Habitual diet (omnivore/vegetarian) recorded as a covariate. |
| **Design** | Double-blind, placebo-controlled, parallel groups. 28 days of dosing plus a 28-day washout (tests reversibility and MK-turnover timing). Two pre-dose baselines. |
| **Arms** | Placebo; creatine 20 g/day (replicates the package); optional lower maintenance-level dose to establish dose-response. |
| **Sample size** | 40 per arm gives 90% power (α = 0.05) to detect two-thirds of the uncontrolled day-14 effect on EPI-induced maximal aggregation (SD of log2 change 0.64, from Fig 7c). |
| **Primary endpoint** | Change to day 14 in EPI-induced maximal aggregation (log), vs placebo. |
| **Key secondary (hierarchical)** | Collagen-induced aggregation; platelet surface GPVI; **ADP aggregation as a pre-specified specificity check** (expected null; if positive, P2Y12 returns); AA and TRAP. |
| **Mechanistic** | Serum and platelet creatine; immature platelet fraction (tests the MK-timing prediction); platelet transcript program (*ADRA2A*, *GP6*, *RAB4A*, …); platelet pS127-STAT5B once the Study 2 assay exists. |
| **Safety** | CBC, PT/aPTT/fibrinogen, TEG, renal function. |
| **Translational bridge** | Day-0 and day-14 platelets from ≥6 donors per arm into the Fig 7g mouse transfer assay, with the donor as the unit. |

### Study 5 (indication scoping, observational)

- **Setting:** a cross-sectional cohort in melanoma clinics (the only named tumour type), extendable to other solid tumours.
- **Measures:**
  - Prevalence of creatine-supplement use.
  - Distribution of serum creatine.
  - Platelet EPI/collagen reactivity and GP6 by exposure.
- **Purpose:** sizes the creatine-exposed population that defines the indication for any drug on this axis. It also tells the committee how large the exposure-avoidance alternative is.

**Sequencing**

- **Now (before the slot opens):**
  - Resolve the data requests (§7).
  - Start colony expansion for Core A.
  - Pre-register the Study 1 analysis plan.
  - Start Study 2 and the Study 4 protocol and ethics.
- **Slot quarter:** run Study 1 (Core A, then Core B; add-on C only if capacity allows). Unblind only after the analysis plan is locked.
- **Next committee:** GO/NO-GO on STAT5B from Study 1. If NO-GO, Study 3 (GPVI) takes the following slot.
- **Study 4** reads out independently and feeds the effector and indication decisions.

---

## 5. What would elevate one choice over another

| If we learn… | Effect on the ranking |
|---|---|
| MK *Stat5b* KO blocks ≥60% of creatine-driven metastasis, normalises platelet reactivity and shows no baseline haemostatic defect | **STAT5B confirmed.** Proceed to selective pharmacology and PK/PD. SLC6A8 and GPVI stay as fallbacks. |
| KO blocks < 30% | **STAT5B dropped.** GPVI takes the next slot (Study 3). SLC6A8 remains the validated node; weigh exposure management against a drug. |
| KO blocks 30–60%, or STAT5-IN-1 blocks but the KO does not | STAT5A redundancy, or action outside MKs (tumour/immune). Test *Stat5a/b* or define the cell of action before investing. STAT5-IN-1 hits both isoforms. |
| KO blocks but the STAT5-IN-1 re-run does not | Biology valid but no usable chemistry. Longer, higher-risk program, so GPVI rises as the near-term option. |
| Raw records show Fig 6b and Supp 2d animals are genuinely distinct (transcription error) | Pharmacology and aspirin evidence restored; aspirin/COX-1 returns as a repurposing comparator. |
| Site-specific data confirm creatine → CKB-dependent S127 (Y699 unchanged) in primary MKs | Strengthens a selective intervention thesis, which favours STAT5B or the CKB–STAT5B interface over pan-STAT5 inhibition. |
| Human RCT: collagen response and platelet GPVI up vs placebo | Elevates GPVI as backup and as the human PD marker. |
| Human RCT: EPI/α2A up, collagen null | Elevates ADRA2A; Study 3 adds α2A antagonism. |
| Human RCT: ADP response up | P2Y12 re-enters. |
| Human RCT: no difference vs placebo | Human relevance not shown. Deprioritise the drug program; the exposure question stays open. |
| Study 5: creatine exposure is rare in patients | Caps the value of any drug on this axis, whichever target wins. |
| Raw aggregation traces do not match Fig 2b/3d | Mouse platelet-function evidence is discounted; effector choice rests on human data. |
| The committee's objective is risk mitigation (guidance on creatine use in cancer care) rather than a new drug | **SLC6A8 / exposure path elevated over STAT5B.** Study 3's reversibility cohort and Studies 4–5 become the priority, because the decisive questions become reversibility and prevalence, not druggability. |

---

## 6. Risks and assumptions

- **Blinding may shrink the effect.**
  - All 10 prior experiments were unblinded. Study 1 is powered for a creatine effect as low as 2.0×, the lower edge of the prediction interval.
  - A null result in the control arm is a valid, important outcome (Gate 0).
- **Cre specificity.** Deletion is verified only by MK blots (Fig 6d for STAT5B; Supp 4a for SLC6A8, which shows a residual band). Lineage checks are built into Study 1.
- **Pharmacology is not isoform-selective.** STAT5-IN-1 inhibits STAT5A and STAT5B and acts systemically (tumour and immune cells are exposed). The genetic arm is therefore the primary test.
- **Model scope.** One named tumour type, lung only, experimental metastasis.
  - If the genetic lines are on a C57BL/6 background (to be confirmed), the BALB/cJ model cannot be used without backcrossing.
  - A spontaneous-metastasis model belongs in the next phase, not in this slot.
- **Human translation.** Young, lean, single-ancestry cohort; one high dose; circulating CD41+ cells are not MKs. Study 4 addresses each point.
- **Low-weight observation.** The two vehicle groups in Fig 3c have near-identical means (13.691 vs 13.688) despite different values; by chance, P ≈ 5 × 10⁻⁴. Given the number of checks run, this is noted but not weighted.

---

## 7. Data requests before the meeting (and why each matters)

| # | Request | Why it matters for this decision |
|---|---|---|
| 1 | Raw animal records (IDs, dates, cage cards, histology images, burden/foci worksheets) for **Fig 6b** and **Supp 2d** | Decides whether the STAT5-inhibitor and aspirin in vivo results stand as independent evidence. If the overlap is a transcription error and both datasets are otherwise intact, the pharmacology evidence is restored; Study 1 Core B still replicates it under blinding. |
| 2 | Instrument exports or traces for the **aggregometry in Fig 2b and 3d**, and the raw (un-normalised) human values behind **Fig 7c** | The mouse platelet-function values show non-random regularity; the human data are available only as fold vs day 0. Both feed the effector ranking (GPVI vs P2Y12 vs α2A). |
| 3 | Raw Ct files (target and *Actb*) for every qPCR sheet, especially **Fig 3f** and **Fig 7d volunteer 4** (*PITPNB*, *RAB27B*) | Baseline ΔCT differs by 7–19 cycles between experiments. The Fig 3f sign convention cannot be determined, and 6 human values cannot be re-derived. The direction of the mouse program is not in doubt; traceability is. |
| 4 | Site-level phosphoproteomics export (residue, localisation probability, per-replicate intensities, missing-value handling) | Needed to check whether the lone *Stat5b* hit (p = 0.0012, q = 0.25) is S127. Without it, S127 rests on pan-phospho blots. |
| 5 | ChIP antibody identity and controls (IgG, KO); donor numbers behind Fig 7g; the human coagulation tests named in the conventions | Closes remaining interpretive gaps: what the ChIP measured, the true n of the human-platelet transfer, and a safety read-out that was collected but not supplied. |

---

## Appendix A. How the numbers were derived

1. **Extraction.**
   - All 87 sheets were parsed cell by cell, with formulas evaluated from the stored values.
   - The 26 embedded images (blots) were extracted and inspected.
   - The conventions PDF was used for units of n, cell types, dosing and design facts.
2. **Verification of reported statistics.**
   - Every reported t, df and p; every Tukey, Sidak and Dunnett comparison; and both log-rank tests were recomputed.
   - All reproduce (workbook sheets B6 and B7 in `analysis/CRE-MK-01_reanalysis_tables.xlsx`). Welch and repeated-measures alternatives were added.
3. **Effect sizes.**
   - Ratio of means with 20,000-sample bootstrap 95% CIs.
   - Standardised effects on ln scale.
   - Random-effects pooling (DerSimonian–Laird on log ratio of means).
   - Hazard ratios by Cox regression.
4. **Attenuation.** 1 − log FC(creatine | perturbation) / log FC(creatine | control), with bootstrap CIs. For qPCR, log2FC = mean ΔCT(treated) − mean ΔCT(control), with t-tests on the ΔCT scale.
5. **Human data.**
   - Platelet function: one-sample t-tests on log2 within-subject fold vs day 0; Wilcoxon as a sensitivity check; BH-FDR and Holm across 36 tests.
   - Blots: paired and repeated-measures ANOVA.
   - CD41+ qPCR: folds recomputed from ΔCT (126/132 reproduce the sheet; 6 do not), then paired tests on ΔΔCT with BH-FDR across 33 gene-day tests.
6. **Phosphoproteomics.**
   - Degenerate p-values identified analytically (t = 1 or 2, df = 2).
   - Storey π₀, BH-FDR, and the convention screen (FC ≥ 1.2 or ≤ 0.83, p < 0.05) reproduced: 209 peptides, most expected to be false positives.
7. **Integrity scans.**
   - Cross-sheet scan of exact numeric runs (length ≥ 3) across non-qPCR sheets.
   - Precise-value duplicates in qPCR sheets were expected from 2-decimal ΔCT rounding (as the sheets' own footnote states) and were discounted.
   - Triplet-pattern probabilities by simulation from rounded normals.
   - Parity test.
8. **Power.** Monte-Carlo simulation (2,000–4,000 runs per scenario) of the 2 × 2 log-scale interaction test and of the GO rule, using SDs and effect sizes estimated from the package. Human study: normal-approximation two-sample sizes on log2 change scores.

## Appendix B. Key supporting tables

Full tables are in `analysis/CRE-MK-01_reanalysis_tables.xlsx`:

- B1: creatine effect per experiment.
- B2: attenuation by perturbation, in vivo and per gene.
- B3: 36 human platelet-function tests.
- B4: human CD41+ qPCR, recomputed.
- B5: mouse qPCR statistics by sheet.
- B6: two-group verification.
- B7: Tukey verification.
- B8: phosphoproteomics summary.
- B9: power simulations.

Scripts to regenerate every number and figure are in `analysis/code/`.
