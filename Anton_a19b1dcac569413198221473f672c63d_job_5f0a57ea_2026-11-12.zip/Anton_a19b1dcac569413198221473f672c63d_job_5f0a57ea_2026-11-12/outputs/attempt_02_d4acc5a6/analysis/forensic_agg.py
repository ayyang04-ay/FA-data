import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np
rng=np.random.default_rng(1)
S='Fig. 2b'; trip2b=[row(S,r,2,4) for r in (4,5,6)]+[row(S,r,5,7) for r in (4,5,6)]
S='Fig. 3d'; trip3d=[row(S,r,c,c+2) for r in (4,5,6) for c in (2,5,8,11)]
def mid(t): # one value exactly equals mean of the other two (i.e. arithmetic progression)
    t=sorted(t); return np.isclose(t[1],(t[0]+t[2])/2)
print('Fig 2b triplets:',[list(map(int,t)) for t in trip2b])
print('  arithmetic-progression triplets: %d/6; third value = mean of first two in all: %s'%(sum(mid(t) for t in trip2b), all(np.isclose(t[2],(t[0]+t[1])/2) for t in trip2b)))
print('Fig 3d triplets:',[list(map(int,t)) for t in trip3d])
vals3d=np.concatenate(trip3d); print('  all 36 values even:',bool(np.all(vals3d%2==0)),'; within-group SDs:',sorted(set(np.round([np.std(t,ddof=1) for t in trip3d],2))))
pat=sum(1 for t in trip3d if len(set(t))==2 and (max(t)-min(t))==2); print('  triplets of form {x,x,x+-2}: %d/12'%pat)
# Monte Carlo: integer-rounded normal triplets with SD matched to each 2b group; P(third == mean of first two)
def p_mid_third(sd,n=200000):
    x=np.round(rng.normal(50,sd,(n,3))); return np.mean(x[:,2]==(x[:,0]+x[:,1])/2)
sds=[np.std(t,ddof=1) for t in trip2b]
ps=[p_mid_third(s) for s in sds]
print('  per-triplet P(third = exact mean of first two | integer data, SD as observed):',np.round(ps,3),' joint P for all 6 = %.1e'%np.prod(ps))
# Typical between-animal SD in the rest of the workbook for aggregation (human fold data not comparable). Use pooled SD of Fig 2b vs 3d
print('  pooled within-group SD: Fig 2b %.2f ; Fig 3d %.2f (aggregation %% units)'%(np.sqrt(np.mean([np.var(t,ddof=1) for t in trip2b])),np.sqrt(np.mean([np.var(t,ddof=1) for t in trip3d]))))
# How often does the AP pattern occur in other n=3 integer-ish groups in workbook? (e.g. CBC counts)
others={'2a PLT veh':col('Fig. 2a','B',4,6),'2a PLT cre':col('Fig. 2a','C',4,6),'S4b WT-veh':col('Supplementary Fig  4b','C',5,7),'S4b WT-cre':col('Supplementary Fig  4b','D',5,7),'S4b KO-veh':col('Supplementary Fig  4b','E',5,7),'S4b KO-cre':col('Supplementary Fig  4b','F',5,7),
        'S7a veh':col('Supplementary Fig  7a','B',4,6),'S7a cre':col('Supplementary Fig  7a','C',4,6),'S7a vehi':col('Supplementary Fig  7a','D',4,6),'S7a crei':col('Supplementary Fig  7a','E',4,6),
        'S7b a':col('Supplementary Fig  7b','B',4,6),'S7b b':col('Supplementary Fig  7b','C',4,6),'S7b c':col('Supplementary Fig  7b','D',4,6)}
print('  control: AP-pattern in other integer n=3 groups (platelet counts):',sum(mid(v) for v in others.values()),'/',len(others))
