import sys; sys.path.insert(0,'/tmp/work/analysis')
from densito import *
img=Image.open('/tmp/work/img/image17.jpeg').convert('L')
# SLC6A8 ~60 kDa band y~262-300, lanes sh-scr ~ x 225, sh-Slc6a8 ~ x 285 ; actin band y~230-252 lanes x~490, ~535
s=lanes(img,180,340,255,305,refine_centers(img,180,340,255,305,[225,285]),hw=28)
a=lanes(img,450,580,225,258,refine_centers(img,450,580,225,258,[492,535]),hw=22)
print('SLC6A8 raw',s.round(0),'ACT raw',a.round(0))
r=s/a; print('SLC6A8/ACT sh-Slc6a8 relative to sh-scrambled: %.2f'%(r[1]/r[0]))
