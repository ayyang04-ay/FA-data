import openpyxl, numpy as np
WB=openpyxl.load_workbook('/tmp/work/CRE-MK-01_source_data.xlsx', data_only=True)
def col(sheet, colletter, r0, r1):
    ws=WB[sheet]; out=[]
    for r in range(r0, r1+1):
        v=ws[f'{colletter}{r}'].value
        if isinstance(v,(int,float)) and not isinstance(v,bool): out.append(float(v))
    return np.array(out)
def row(sheet, r, c0, c1):
    ws=WB[sheet]; out=[]
    for c in range(c0, c1+1):
        v=ws.cell(r,c).value
        if isinstance(v,(int,float)) and not isinstance(v,bool): out.append(float(v))
    return np.array(out)
