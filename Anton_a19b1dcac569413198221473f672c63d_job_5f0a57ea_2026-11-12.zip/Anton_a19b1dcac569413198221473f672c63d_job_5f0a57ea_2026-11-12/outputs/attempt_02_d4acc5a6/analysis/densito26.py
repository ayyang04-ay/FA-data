import sys; sys.path.insert(0,'/tmp/work/analysis')
from densito import *
img=Image.open('/tmp/work/img/image26.jpeg').convert('L')
# (panel, y0,y1, x0,x1, approx centers)
P={
 'V1':{'GP6':(150,195,272,500,[335,383,430,478]),'P2RY12':(148,190,652,930,[742,792,843,893]),'ACT':(140,180,1112,1360,[1178,1225,1272,1322])},
 'V2':{'GP6':(420,455,222,498,[305,365,420,475]),'P2RY12':(405,440,657,930,[712,757,806,856]),'ACT':(410,445,1107,1433,[1195,1262,1322,1385])},
 'V3':{'GP6':(680,712,192,503,[330,372,421,476]),'P2RY12':(683,718,654,943,[725,775,833,890]),'ACT':(675,710,1097,1415,[1182,1247,1307,1372])},
 'V4':{'GP6':(970,1008,130,512,[258,318,377,442]),'P2RY12':(972,1008,655,963,[747,813,872,932]),'ACT':(970,1006,1112,1484,[1218,1280,1336,1396])},
}
import numpy as np
res={}
for v,d in P.items():
    vals={}
    for prot,(y0,y1,x0,x1,cent) in d.items():
        c=refine_centers(img,x0,x1,y0,y1,cent)
        vals[prot]=lanes(img,x0,x1,y0,y1,c,hw=20)
        vals[prot+'_c']=c
    res[v]=vals
    gp=vals['GP6']/vals['ACT']; p2=vals['P2RY12']/vals['ACT']
    print(v,'centers GP6',vals['GP6_c'],'P2',vals['P2RY12_c'],'ACT',vals['ACT_c'])
    print('   raw GP6',vals['GP6'].round(0),' P2RY12',vals['P2RY12'].round(0),' ACT',vals['ACT'].round(0))
    print('   GP6/ACT rel to d0',(gp/gp[0]).round(2),'   P2RY12/ACT rel to d0',(p2/p2[0]).round(2))
# reported Fig 7e rows
rep_gp6=np.array([[0.438392,0.406563,0.795446,0.951753],[0.417301,0.823525,0.618009,0.876533],[0.279484,0.551077,1.052902,1.393029],[0.539324,0.313478,0.871327,1.111208]])
rep_p2=np.array([[1.033134,1.444647,1.086538,1.374988],[0.518929,1.192388,0.821571,0.874541],[0.470438,1.006007,0.739907,1.285329],[0.89578,1.115118,1.101423,1.28611]])
print('\nReported Fig 7e (rows assumed = volunteers 1-4), relative to d0:')
for i in range(4):
    print(f'  row{i+1} GP6 {(rep_gp6[i]/rep_gp6[i,0]).round(2)}   P2RY12 {(rep_p2[i]/rep_p2[i,0]).round(2)}')
