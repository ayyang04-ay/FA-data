import sys; sys.path.insert(0,'/tmp/work/analysis')
import json, numpy as np, pandas as pd
from lifelines import KaplanMeierFitter, CoxPHFitter
from lifelines.statistics import logrank_test
d=json.load(open('/tmp/work/analysis/surv.json'))
for S,v in d.items():
    df=pd.DataFrame(v); df['e']=1; df['cre']=(df.g=='cre').astype(int)
    a=df[df.cre==0]; b=df[df.cre==1]; lr=logrank_test(a.t,b.t,a.e,b.e)
    km=KaplanMeierFitter(); med={}
    for name,sub in [('veh',a),('cre',b)]: km.fit(sub.t,sub.e); med[name]=km.median_survival_time_
    cph=CoxPHFitter().fit(df[['t','e','cre']],'t','e'); hr=np.exp(cph.params_['cre']); ci=np.exp(cph.confidence_intervals_.loc['cre'].values)
    print(f'{S}: n veh {len(a)}, n cre {len(b)}, no censoring; median {med["veh"]} vs {med["cre"]} d; log-rank chi2={lr.test_statistic:.3f} p={lr.p_value:.4f}; Cox HR={hr:.2f} (95% CI {ci[0]:.2f}-{ci[1]:.2f})')
