import sys; sys.path.insert(0,'/tmp/work/analysis')
from densito import *
img=Image.open('/tmp/work/img/image18.jpeg').convert('L')
c=refine_centers(img,200,420,252,290,[240,288,335,380]); s=lanes(img,200,420,252,290,c,hw=20)
ca=refine_centers(img,740,960,222,256,[770,830,885,935]); a=lanes(img,740,960,222,256,ca,hw=22)
print('SLC6A8 lanes (unlabeled, +/+, fl/fl, unlabeled):',s.round(0),' centers',c)
print('ACT lanes:',a.round(0),' centers',ca)
r=s/a; print('SLC6A8/ACT fl/fl relative to +/+ (boxed lanes): %.2f'%(r[2]/r[1]))
