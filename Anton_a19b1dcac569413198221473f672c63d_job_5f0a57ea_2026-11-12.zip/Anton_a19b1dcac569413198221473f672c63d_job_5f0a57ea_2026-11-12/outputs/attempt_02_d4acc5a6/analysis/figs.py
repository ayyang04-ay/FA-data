import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False})
OUT='/tmp/outputs/figures/'
# ---------- Fig 1 forest ----------
m=pd.read_csv('meta_burden.csv')
m['lo95']=np.exp(m.logd-1.96*m.se); m['hi95']=np.exp(m.logd+1.96*m.se)
def dl(df):
    w=1/df.se**2; fe=(w*df.logd).sum()/w.sum(); Q=(w*(df.logd-fe)**2).sum(); k=len(df)
    tau2=max(0,(Q-(k-1))/(w.sum()-(w**2).sum()/w.sum())); wr=1/(df.se**2+tau2)
    re=(wr*df.logd).sum()/wr.sum(); se=np.sqrt(1/wr.sum()); return np.exp(re),np.exp(re-1.96*se),np.exp(re+1.96*se)
fig,ax=plt.subplots(figsize=(8.2,4.4))
labels=[f"{r.cohort}  (n={int(r.n_veh)}+{int(r.n_cre)})" for r in m.itertuples()]
y=np.arange(len(m))[::-1]+2
for yi,r in zip(y,m.itertuples()):
    colr='#c0392b' if '6b' in r.cohort else '#2c3e50'
    ax.plot([r.lo95,r.hi95],[yi,yi],color=colr,lw=1.5); ax.plot(r.ratio,yi,'s',color=colr,ms=5)
sub=m[~m.cohort.str.contains('6b')]; p,lo,hi=dl(sub)
ax.fill([lo,p,hi,p],[0.6,0.9,0.6,0.3],color='#16a085'); 
ax.set_yticks(list(y)+[0.6]); ax.set_yticklabels(labels+[f'Pooled, random effects, excl. Fig 6b: {p:.2f}x ({lo:.2f}-{hi:.2f})'])
ax.axvline(1,color='grey',ls='--',lw=0.8); ax.set_xscale('log'); ax.set_xlim(0.7,10); ax.set_xticks([1,2,4,8]); ax.set_xticklabels(['1','2','4','8']); ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
ax.set_xlabel('Creatine / vehicle: ratio of geometric means, lung metastatic burden (95% CI)')
ax.set_title('Creatine raises lung metastatic burden in every cohort',fontsize=9.5,loc='left')
ax.text(0.0,-0.2,'red: Fig 6b arms share animals with Supp Fig 2d (excluded from the pooled estimate). I2=49%; 95% prediction interval 1.80-5.11.',transform=ax.transAxes,ha='left',va='top',fontsize=7,color='#c0392b')
plt.tight_layout(); plt.savefig(OUT+'fig1_phenotype_forest.png',dpi=200,bbox_inches='tight'); plt.close()
# ---------- Fig 2 node perturbations ----------
n=pd.read_csv('node_perturbations.csv'); n=n[n.endpoint=='burden']
fig,ax=plt.subplots(figsize=(8.4,3.6))
rows=[('Tumour-cell Slc6a8 shRNA (Fig 1f)','#2c3e50'),('MK Slc6a8 deletion, Pf4-Cre (Fig 3i)','#16a085'),('STAT5-IN-1, systemic (Fig 6b)','#c0392b'),('Aspirin-treated creatine donors, platelet transfer (Supp 2d)','#c0392b'),('Human day-7 vs day-0 platelets transferred to mice (Fig 7g)','#8e44ad')]
yy=len(rows)
for i,(lab,c) in enumerate(rows):
    r=n[n.perturbation==lab].iloc[0]; yb=yy-i
    ax.plot([r.ctrl_lo,r.ctrl_hi],[yb+0.15]*2,color='grey',lw=1.5); ax.plot(r.cre_effect_ctrl,yb+0.15,'o',color='grey',ms=5)
    if not np.isnan(r.cre_effect_perturbed):
        ax.plot([r.pert_lo,r.pert_hi],[yb-0.15]*2,color=c,lw=1.5); ax.plot(r.cre_effect_perturbed,yb-0.15,'D',color=c,ms=5)
ax.set_yticks([yy-i for i in range(len(rows))]); ax.set_yticklabels([r[0] for r in rows],fontsize=7.5)
ax.axvline(1,color='grey',ls='--',lw=0.8); ax.set_xscale('log'); ax.set_xlim(0.2,10); ax.set_xticks([0.25,0.5,1,2,4,8]); ax.set_xticklabels(['0.25','0.5','1','2','4','8']); ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
ax.set_xlabel('Creatine effect on metastatic burden (ratio vs matched vehicle arm, 95% CI)')
ax.legend(handles=[plt.Line2D([],[],marker='o',color='grey',ls='',label='control background'),plt.Line2D([],[],marker='D',color='#16a085',ls='',label='with perturbation'),Patch(color='#c0392b',label='integrity flag: shared animals')],fontsize=7,loc='upper left',bbox_to_anchor=(0.0,-0.22),ncol=3,frameon=False)
ax.set_title('Which perturbations remove the creatine effect in vivo?',fontsize=9.5,loc='left')
plt.tight_layout(); plt.savefig(OUT+'fig2_node_perturbations.png',dpi=200,bbox_inches='tight'); plt.close()
# ---------- Fig 3 gene program heatmap ----------
q=pd.read_csv('qpcr_summary.csv')
genes=['Gp6','P2ry12','Adra2a','F2r','Itga2b','Gpiba','Fcgr2a','Runx1','Rab4a','Rab27b','Pitpnb']
cols=[('Fig. 2f','Creatine vs veh','in vivo: creatine (2f)'),('Fig. 3f','WT-cre vs veh','in vivo: creatine, Slc6a8+/+ (3f)'),('Fig. 3f','KO-cre vs veh','in vivo: creatine, MK Slc6a8 KO (3f)'),
      ('Fig. 6g','WT-cre vs veh','in vivo: creatine, WT (6g)'),('Fig. 6g','Stat5bKO-cre vs veh','in vivo: creatine, MK Stat5b KO (6g)*'),
      ('Fig. 4h','Creatine vs veh','in vitro: creatine (4h)'),('Fig. 4h','PCr vs veh','in vitro: phosphocreatine (4h)'),
      ('Fig. 4j','cre+siScr vs veh','in vitro: creatine + si-scr (4j)'),('Fig. 4j','cre+siCkb vs veh','in vitro: creatine + si-Ckb (4j)'),('Fig. 4l','CKB-OE vs veh','in vitro: CKB overexpression (4l)'),
      ('Fig.6a','Creatine vs veh','in vitro: creatine (6a)'),('Fig.6a','cre+STAT5i vs veh','in vitro: creatine + STAT5-IN-1 (6a)'),('Fig.6a','veh+STAT5i vs veh','in vitro: STAT5-IN-1 alone (6a)'),
      ('Supplementary Fig  4e','KO MK creatine vs veh','in vitro: Slc6a8-KO MKs + creatine (S4e)'),('Supplementary Fig  4e','KO MK creatine@liposome vs veh','in vitro: Slc6a8-KO MKs + liposomal creatine (S4e)')]
M=np.full((len(genes),len(cols)),np.nan)
for j,(s,c,_) in enumerate(cols):
    for i,g in enumerate(genes):
        r=q[(q.sheet==s)&(q.contrast==c)&(q.gene==g)]
        if len(r): M[i,j]=r.log2FC.values[0]
fig,ax=plt.subplots(figsize=(7.6,5.2))
im=ax.imshow(M,cmap='RdBu_r',vmin=-4,vmax=4,aspect='auto')
ax.set_yticks(range(len(genes))); ax.set_yticklabels(genes,fontsize=8)
ax.set_xticks(range(len(cols))); ax.set_xticklabels([c[2] for c in cols],rotation=55,ha='right',fontsize=7)
for i in range(len(genes)):
    for j in range(len(cols)):
        if not np.isnan(M[i,j]): ax.text(j,i,f'{2**M[i,j]:.1f}',ha='center',va='center',fontsize=5.8,color='white' if abs(M[i,j])>2.2 else 'black')
cb=plt.colorbar(im,ax=ax,fraction=0.03); cb.set_label('log2 fold vs matched vehicle (numbers = fold)',fontsize=7)
ax.set_title('MK platelet-activation gene program: induction and its dependencies (mouse qPCR, n=3 each)',fontsize=9,loc='left')
fig.text(0.01,0.005,'*No Stat5b-KO vehicle arm exists; KO values are relative to WT vehicle. Values = fold change (mean of n=3); all 196 normalised values reconcile with their dCt inputs.',fontsize=6.5)
plt.tight_layout(); plt.savefig(OUT+'fig3_gene_program_heatmap.png',dpi=200,bbox_inches='tight'); plt.close()
# ---------- Fig 4 human platelet function (paired) ----------
S='Fig. 7c'
blocks=[('Collagen (GPVI)',4),('Epinephrine (alpha2A)',46),('Arachidonic acid (COX-1)',88),('ADP (P2Y12)',130)]
from scipy import stats
fig,axs=plt.subplots(1,4,figsize=(8.6,2.8),sharey=True)
for ax,(lab,r0) in zip(axs,blocks):
    M=np.array([row(S,r,2,5) for r in range(r0,r0+11)]); L=np.log2(M)
    for v in L: ax.plot([0,3,7,14],v,color='grey',alpha=0.45,lw=0.8,marker='o',ms=2)
    gm=L.mean(0); ax.plot([0,3,7,14],gm,color='#c0392b',lw=2,marker='o',ms=4)
    p=stats.wilcoxon(M[:,3]-1).pvalue; up=(M[:,3]>1).sum()
    ax.set_title(f'{lab}\nday 14: {2**gm[3]:.2f}x, {up}/11 up, p={p:.3f}',fontsize=7.5)
    ax.axhline(0,color='k',lw=0.6,ls='--'); ax.set_xticks([0,3,7,14]); ax.set_xlabel('day')
axs[0].set_ylabel('log2 max aggregation\n(fold vs own day 0)')
fig.suptitle('Healthy volunteers on creatine 20 g/day (Fig 7c), re-analysed as paired data (Wilcoxon signed-rank vs day 0)',fontsize=8.5,x=0.01,ha='left')
plt.tight_layout(); plt.savefig(OUT+'fig4_human_platelet_function.png',dpi=200,bbox_inches='tight'); plt.close()
# ---------- Fig 5 integrity ----------
fig,axs=plt.subplots(1,2,figsize=(8.4,3.0),gridspec_kw={'width_ratios':[1.25,1]})
ax=axs[0]
a6=[col('Fig. 6b','B',4,8),col('Fig. 6b','C',4,8)]; s2=[col('Supplementary Fig  2d','C',5,10),col('Supplementary Fig  2d','D',5,10)]
shared=set([3.29136,3.733544,2.886353,11.13465,13.22011,14.12619])
xs={'Fig 6b vehicle':0,'Fig 6b creatine':1,'Supp 2d vehicle-donor PLT':2.6,'Supp 2d creatine-donor PLT':3.6}
for (lab,x),vals in zip(xs.items(),[a6[0],a6[1],s2[0],s2[1]]):
    for k,v in enumerate(vals):
        c='#c0392b' if round(v,6) in shared else '#7f8c8d'
        ax.plot(x+(k-len(vals)/2)*0.06,v,'o',color=c,ms=5)
ax.set_xticks(list(xs.values())); ax.set_xticklabels(list(xs.keys()),rotation=20,ha='right',fontsize=7)
ax.set_ylabel('metastatic burden (%)'); ax.set_title('Same 6 animals (red; burden to 7 s.f. and foci counts)\nreported in two different experiments',fontsize=8,loc='left')
ax=axs[1]
trip=[('2b ADP veh',[44,40,42]),('2b ADP cre',[56,58,57]),('2b Col veh',[68,64,66]),('2b Col cre',[80,78,79]),('2b Thr veh',[20,30,25]),('2b Thr cre',[52,60,56])]
for i,(lab,t) in enumerate(trip):
    ax.plot([i]*3,t,'o',color='#2c3e50',ms=4); ax.plot([i-0.2,i+0.2],[np.mean(t[:2])]*2,color='#c0392b',lw=1.2)
ax.set_xticks(range(len(trip))); ax.set_xticklabels([t[0] for t in trip],rotation=35,ha='right',fontsize=7)
ax.set_ylabel('aggregation (%)'); ax.set_title('Fig 2b: in all 6 triplets the 3rd value equals\nthe mean of the first two (red bar); P~2e-7',fontsize=8,loc='left')
plt.tight_layout(); plt.savefig(OUT+'fig5_integrity_flags.png',dpi=200,bbox_inches='tight'); plt.close()
print('figures written')
# ---------- Fig 6 human protein: reported vs image re-quant ----------
rep_gp6=np.array([[0.438392,0.406563,0.795446,0.951753],[0.417301,0.823525,0.618009,0.876533],[0.279484,0.551077,1.052902,1.393029],[0.539324,0.313478,0.871327,1.111208]])
rep_p2=np.array([[1.033134,1.444647,1.086538,1.374988],[0.518929,1.192388,0.821571,0.874541],[0.470438,1.006007,0.739907,1.285329],[0.89578,1.115118,1.101423,1.28611]])
req_gp6=np.array([[1,1.64,0.97,1.76],[1,1.81,2.09,2.58],[1,0.81,1.41,1.64],[1,0.51,1.46,1.70]])
req_p2=np.array([[1,1.54,0.78,1.07],[1,1.27,0.93,1.21],[1,1.56,0.80,0.94],[1,0.79,1.03,0.85]])
fig,axs=plt.subplots(1,2,figsize=(7.6,2.8),sharey=True)
for ax,(lab,rep,req) in zip(axs,[('GP6 / beta-actin',rep_gp6,req_gp6),('P2RY12 / beta-actin',rep_p2,req_p2)]):
    x=np.arange(4)
    for v in range(4):
        ax.plot(x-0.08,np.log2(rep[v]/rep[v,0]),'o-',color='#2c3e50',alpha=0.7,ms=3,lw=0.8)
        ax.plot(x+0.08,np.log2(req[v]),'s--',color='#e67e22',alpha=0.8,ms=3,lw=0.8)
    ax.axhline(0,color='k',lw=0.6); ax.set_xticks(x); ax.set_xticklabels(['d0','d3','d7','d14']); ax.set_title(lab,fontsize=8.5)
axs[0].set_ylabel('log2 change vs own day 0')
axs[1].legend(handles=[plt.Line2D([],[],marker='o',color='#2c3e50',label='reported (Fig 7e)'),plt.Line2D([],[],marker='s',ls='--',color='#e67e22',label='approx. re-quant of Supp 8d images')],fontsize=7,frameon=False,loc='upper left')
fig.suptitle('Human platelet immunoblots (4 volunteers): GP6 rise is visible on the blots; the P2RY12 rise is not',fontsize=8.5,x=0.01,ha='left')
plt.tight_layout(); plt.savefig(OUT+'fig6_human_blot_requant.png',dpi=200,bbox_inches='tight'); plt.close()
print('fig6 written')
