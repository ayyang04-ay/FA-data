import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
S='Fig. 7c'; ws=WB[S]
blocks=[('collagen','max agg',4),('collagen','avg agg',18),('collagen','adhesion',32),
        ('EPI','max agg',46),('EPI','avg agg',60),('EPI','adhesion',74),
        ('AA','max agg',88),('AA','avg agg',102),('AA','adhesion',116),
        ('ADP','max agg',130),('ADP','avg agg',144),('ADP','adhesion',157)]
rows=[]
for ag,meas,r0 in blocks:
    M=np.array([row(S,r,2,5) for r in range(r0,r0+11)])
    assert M.shape==(11,4), (ag,meas,M.shape)
    assert np.allclose(M[:,0],1)
    L=np.log2(np.where(M[:,1:]>0,M[:,1:],np.nan))
    res={'agonist':ag,'measure':meas}
    for j,d in enumerate(['d3','d7','d14']):
        x=M[:,j+1]; lx=L[:,j]; lxv=lx[~np.isnan(lx)]
        res[f'{d}_median_fold']=np.median(x)
        res[f'{d}_geomean_fold']=2**np.nanmean(lx)
        res[f'{d}_n_up']=int((x>1).sum())
        res[f'{d}_wilcoxon_p']=stats.wilcoxon(x-1).pvalue
        res[f'{d}_t_log_p']=stats.ttest_1samp(lxv,0).pvalue
        res[f'{d}_nzero']=int((x==0).sum())
    # Friedman on raw fold (day0 = 1)
    res['friedman_p']=stats.friedmanchisquare(*M.T).pvalue
    # reported (ordinary one-way ANOVA + Dunnett) p for 0 vs 14
    rows.append(res)
df=pd.DataFrame(rows)
pd.set_option('display.width',250); pd.set_option('display.max_columns',40)
print(df[['agonist','measure','d3_geomean_fold','d7_geomean_fold','d14_geomean_fold','d14_median_fold','d3_n_up','d7_n_up','d14_n_up','d14_wilcoxon_p','d14_t_log_p','d7_wilcoxon_p','friedman_p','d3_nzero','d7_nzero']].round(4).to_string())
allp=np.concatenate([df[f'{d}_wilcoxon_p'].values for d in ['d3','d7','d14']])
rej,padj,_,_=multipletests(allp,method='fdr_bh')
print('\nBH-FDR over all 36 agonist x measure x day Wilcoxon tests:')
k=0
for d in ['d3','d7','d14']:
    for i,r in df.iterrows():
        if padj[k]<0.1: print(f'  {r.agonist} {r.measure} {d}: raw p={allp[k]:.4f} q={padj[k]:.3f}')
        k+=1
print('min q:',padj.min().round(3))
# day-14 only family (12 tests)
p14=df['d14_wilcoxon_p'].values; r14,q14,_,_=multipletests(p14,method='fdr_bh')
print('\nDay-14 family (12 tests) BH q:'); print(pd.DataFrame({'ag':df.agonist,'meas':df.measure,'p':p14.round(4),'q':q14.round(3)}).to_string())
# primary max-aggregation only per agonist (4 tests), holm
pmax=df[df.measure=='max agg']['d14_wilcoxon_p'].values
print('\nmax-agg d14 Holm:',dict(zip(df[df.measure=='max agg'].agonist, multipletests(pmax,method='holm')[1].round(4))))
