import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np
from scipy import stats
S='Fig. 7c'
for ag,r0 in [('collagen max',4),('EPI max',46),('ADP max',130),('AA max',88)]:
    M=np.array([row(S,r,2,5) for r in range(r0,r0+11)]); L=np.log2(M[:,3])
    print(f'{ag}: d14 log2 fold mean {L.mean():.2f} SD {L.std(ddof=1):.2f}; geomean {2**L.mean():.2f}')
# parallel placebo-controlled: n per arm to detect 1.5x and 2x geometric-mean change, SD of log2 change as observed (collagen ~1.1)
for sd in [0.8,1.0,1.2]:
    for fx in [1.5,2.0]:
        d=np.log2(fx); n=2*(stats.norm.ppf(0.975)+stats.norm.ppf(0.9))**2*sd**2/d**2
        print(f'  parallel design, SD(log2 change)={sd}, effect {fx}x: n/arm (90% power) = {np.ceil(n):.0f}')
