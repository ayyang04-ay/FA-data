import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
S='Fig. 1h'
ps=[]
for r,t in zip(range(4,8),[0.25,6,12,24]):
    v=row(S,r,2,7); c=row(S,r,8,13); tt=stats.ttest_ind(c,v); ps.append(tt.pvalue)
    print(f'1h t={t}h veh {v.mean():.3f}±{v.std(ddof=1):.3f} cre {c.mean():.3f}±{c.std(ddof=1):.3f} ratio {c.mean()/v.mean():.2f} p={tt.pvalue:.4f}')
print('  Holm-adjusted:',multipletests(ps,method='holm')[1].round(4))
# retention relative to 0.25h (normalizing per group mean)
v=np.array([row(S,r,2,7) for r in range(4,8)]); c=np.array([row(S,r,8,13) for r in range(4,8)])
print('  % of 0.25h signal remaining (group means): veh',(100*v.mean(1)/v[0].mean()).round(1),' cre',(100*c.mean(1)/c[0].mean()).round(1))
# ChIP 5j: 2-way ANOVA region x treatment + Sidak
for S,blocks in [('Fig. 5j',[('P2ry12',5),('Gp6',15)]),('Supplementary Fig  6i',[('Rab4a',7)])]:
    ws=WB[S]
    for g,r0 in blocks:
        recs=[]
        for i,reg in enumerate(['Exon','2K','1K','0.2K']):
            if S=='Fig. 5j':
                v=row(S,r0+i,2,4); c=row(S,r0+i,5,7)
            else:
                v=row(S,r0+i,3,5); c=row(S,r0+i,6,8)
            for x in v: recs.append(dict(reg=reg,trt='veh',y=x))
            for x in c: recs.append(dict(reg=reg,trt='cre',y=x))
            print(f'  ChIP {g} {reg}: veh {np.mean(v):.2f} cre {np.mean(c):.2f} ratio {np.mean(c)/np.mean(v):.2f} ' )
        df=pd.DataFrame(recs); m=smf.ols('y~C(reg)*C(trt)',df).fit()
        import statsmodels.api as sm
        print('   2-way ANOVA:',sm.stats.anova_lm(m,typ=2)[['F','PR(>F)']].round(4).to_dict())
