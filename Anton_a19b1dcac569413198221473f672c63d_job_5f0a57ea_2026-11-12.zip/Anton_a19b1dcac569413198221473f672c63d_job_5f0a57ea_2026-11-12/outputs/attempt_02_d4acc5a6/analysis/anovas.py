import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np, itertools
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
def anova(name, groups, labels, factorial=False):
    f,p=stats.f_oneway(*groups)
    data=np.concatenate(groups); lab=np.concatenate([[l]*len(g) for g,l in zip(groups,labels)])
    print(f'--- {name}: one-way ANOVA F={f:.3f} p={p:.3g}; means: '+', '.join(f'{l}={g.mean():.4g}±{g.std(ddof=1):.3g}(n={len(g)})' for g,l in zip(groups,labels)))
    res=pairwise_tukeyhsd(data,lab)
    for r in res.summary().data[1:]:
        print('     ',r)
    # 2x2 factorial interaction if 4 groups
    if factorial and len(groups)==4:
        import statsmodels.formula.api as smf, pandas as pd
        a=np.concatenate([[0]*len(groups[0]),[1]*len(groups[1]),[0]*len(groups[2]),[1]*len(groups[3])])
        b=np.concatenate([[0]*len(groups[0]),[0]*len(groups[1]),[1]*len(groups[2]),[1]*len(groups[3])])
        df=pd.DataFrame(dict(y=data,cre=a,fac=b))
        m=smf.ols('y~cre*fac',df).fit()
        print(f'      2x2 interaction (creatine x factor): coef={m.params["cre:fac"]:.4g} p={m.pvalues["cre:fac"]:.3g};  log-scale interaction p=',end='')
        if (data>0).all():
            df['ly']=np.log(df.y); m2=smf.ols('ly~cre*fac',df).fit(); print(f'{m2.pvalues["cre:fac"]:.3g} (ratio-of-ratios={np.exp(m2.params["cre:fac"]):.2f})')
        else: print('NA')
S='Fig. 1f'
for lab,r0 in [('lung wt',4),('SUV',13),('burden',22),('foci',31)]:
    anova('1f '+lab,[col(S,c,r0,r0+5) for c in 'BCDE'],['scr-veh','scr-cre','shS-veh','shS-cre'],factorial=True)
S='Fig. 3d'
for lab,r in [('ADP',4),('Collagen',5),('Thrombin',6)]:
    anova('3d aggregation '+lab,[row(S,r,2,4),row(S,r,5,7),row(S,r,8,10),row(S,r,11,13)],['WT-veh','WT-cre','KO-veh','KO-cre'],factorial=True)
S='Fig. 3i'
for lab,r0 in [('lung wt',3),('burden',10),('foci',17)]:
    anova('3i '+lab,[col(S,c,r0,r0+3) for c in 'BCDE'],['WT-veh','WT-cre','KO-veh','KO-cre'],factorial=True)
S='Fig. 6b'
for lab,r0 in [('burden',4),('foci',13)]:
    anova('6b '+lab,[col(S,c,r0,r0+4) for c in 'BCDE'],['veh','cre','veh+STAT5i','cre+STAT5i'],factorial=True)
S='Fig. 6e'
anova('6e MK creatine',[col(S,c,5,7) for c in 'CDE'],['WT-veh','WT-cre','Stat5bKO-cre'])
S='Supplementary Fig  2d'
for lab,r0 in [('burden',5),('foci',14)]:
    anova('S2d '+lab,[col(S,c,r0,r0+5) for c in 'CDE'],['vehPLT','crePLT','cre+aspPLT'])
S='Supplementary Fig  4b'; anova('S4b PLT',[col(S,c,5,7) for c in 'CDEF'],['WT-veh','WT-cre','KO-veh','KO-cre'],factorial=True)
S='Supplementary Fig  4c'; anova('S4c a-granules (fields)',[col(S,c,6,13) for c in 'CDEF'],['WT-veh','WT-cre','KO-veh','KO-cre'],factorial=True)
S='Supplementary Fig  7a'
for lab,r0 in [('PLT',4),('PCT',11),('MPV',17),('PDW',23)]:
    anova('S7a '+lab,[col(S,c,r0,r0+2) for c in 'BCDE'],['veh','cre','veh+STAT5i','cre+STAT5i'],factorial=True)
S='Supplementary Fig  7b'
for lab,r0 in [('PLT',4),('PCT',10),('MPV',16),('PDW',22)]:
    anova('S7b '+lab,[col(S,c,r0,r0+2) for c in 'BCD'],['WT-veh','WT-cre','Stat5bKO-cre'])
S='Fig. 5e'
anova('5e pFLAG/FLAG vehicle',[col(S,c,4,6) for c in 'NOPQ'],['WT','S127A','3A','S127D'])
anova('5e pFLAG/FLAG creatine',[col(S,c,17,19) for c in 'NOPQ'],['WT','S127A','3A','S127D'])
S='Fig. 5f'
anova('5f pFLAG/FLAG vehicle',[col(S,c,4,6) for c in 'NOPQ'],['WT','S127A','3A','S127D'])
anova('5f pFLAG/FLAG creatine',[col(S,c,17,19) for c in 'NOPQ'],['WT','S127A','3A','S127D'])
