import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np, pandas as pd
from scipy import stats
def lr(a,b):
    la,lb=np.log(a),np.log(b); d=lb.mean()-la.mean(); se=np.sqrt(la.var(ddof=1)/len(la)+lb.var(ddof=1)/len(lb))
    df=len(a)+len(b)-2; t=stats.t.ppf(0.975,df); return np.exp(d),np.exp(d-t*se),np.exp(d+t*se),d,se
def rr(v0,c0,v1,c1):
    # ratio of ratios (creatine effect in perturbed / creatine effect in control), on log scale, pooled-variance
    g=[np.log(x) for x in (v0,c0,v1,c1)]
    dfree=sum(len(x)-1 for x in g); s2=sum((len(x)-1)*x.var(ddof=1) for x in g)/dfree
    est=(g[3].mean()-g[2].mean())-(g[1].mean()-g[0].mean()); se=np.sqrt(s2*sum(1/len(x) for x in g))
    t=stats.t.ppf(0.975,dfree); p=2*stats.t.sf(abs(est/se),dfree)
    return np.exp(est),np.exp(est-t*se),np.exp(est+t*se),p
rows=[]
for lab,S,cols,r0,r1,flag in [
  ('Tumour-cell Slc6a8 shRNA (Fig 1f)','Fig. 1f','BCDE',22,27,''),
  ('MK Slc6a8 deletion, Pf4-Cre (Fig 3i)','Fig. 3i','BCDE',10,13,''),
  ('STAT5-IN-1, systemic (Fig 6b)','Fig. 6b','BCDE',4,8,'duplicated animals (Supp 2d)')]:
    v0,c0,v1,c1=[col(S,c,r0,r1) for c in cols]
    e0=lr(v0,c0); e1=lr(v1,c1); i=rr(v0,c0,v1,c1)
    rows.append(dict(perturbation=lab,endpoint='burden',cre_effect_ctrl=e0[0],ctrl_lo=e0[1],ctrl_hi=e0[2],cre_effect_perturbed=e1[0],pert_lo=e1[1],pert_hi=e1[2],ratio_of_ratios=i[0],rr_lo=i[1],rr_hi=i[2],p_interaction=i[3],flag=flag))
# foci versions
for lab,S,cols,r0,r1,flag in [
  ('Tumour-cell Slc6a8 shRNA (Fig 1f)','Fig. 1f','BCDE',31,36,''),
  ('MK Slc6a8 deletion, Pf4-Cre (Fig 3i)','Fig. 3i','BCDE',17,20,''),
  ('STAT5-IN-1, systemic (Fig 6b)','Fig. 6b','BCDE',13,17,'duplicated animals (Supp 2d)')]:
    v0,c0,v1,c1=[col(S,c,r0,r1) for c in cols]
    e0=lr(v0,c0); e1=lr(v1,c1); i=rr(v0,c0,v1,c1)
    rows.append(dict(perturbation=lab,endpoint='foci',cre_effect_ctrl=e0[0],ctrl_lo=e0[1],ctrl_hi=e0[2],cre_effect_perturbed=e1[0],pert_lo=e1[1],pert_hi=e1[2],ratio_of_ratios=i[0],rr_lo=i[1],rr_hi=i[2],p_interaction=i[3],flag=flag))
# aspirin donor platelets (Supp 2d): no vehicle+aspirin arm -> report cre-donor vs veh-donor and cre+asp-donor vs veh-donor
S='Supplementary Fig  2d'
for ep,(r0,r1) in [('burden',(5,10)),('foci',(14,19))]:
    v=col(S,'C',r0,r1); c=col(S,'D',r0,r1); a=col(S,'E',r0,r1)
    e0=lr(v,c); e1=lr(v,a)
    rows.append(dict(perturbation='Aspirin-treated creatine donors, platelet transfer (Supp 2d)',endpoint=ep,cre_effect_ctrl=e0[0],ctrl_lo=e0[1],ctrl_hi=e0[2],cre_effect_perturbed=e1[0],pert_lo=e1[1],pert_hi=e1[2],ratio_of_ratios=np.nan,rr_lo=np.nan,rr_hi=np.nan,p_interaction=np.nan,flag='duplicated animals (Fig 6b); no vehicle+aspirin arm'))
# human platelet transfer 7g
S='Fig. 7g'; e=lr(col(S,'B',12,16),col(S,'C',12,16))
rows.append(dict(perturbation='Human day-7 vs day-0 platelets transferred to mice (Fig 7g)',endpoint='burden',cre_effect_ctrl=e[0],ctrl_lo=e[1],ctrl_hi=e[2],cre_effect_perturbed=np.nan,pert_lo=np.nan,pert_hi=np.nan,ratio_of_ratios=np.nan,rr_lo=np.nan,rr_hi=np.nan,p_interaction=np.nan,flag='donor number not recorded'))
df=pd.DataFrame(rows); pd.set_option('display.width',250)
print(df.round(3).to_string()); df.to_csv('node_perturbations.csv',index=False)
# sensitivity: Fig 6b and S2d excluding the 3 shared animals per arm
v=col('Fig. 6b','B',4,8); c=col('Fig. 6b','C',4,8)
print('\nFig 6b w/o shared animals: veh',v[[0,4]],'cre',c[[0,4]], 'ratio %.2f'%(np.exp(np.log(c[[0,4]]).mean()-np.log(v[[0,4]]).mean())))
v=col(S:='Supplementary Fig  2d','C',5,10); c=col(S,'D',5,10); a=col(S,'E',5,10)
print('S2d w/o shared animals: vehPLT',v[:3],'crePLT',c[:3],'ratio cre/veh %.2f'%np.exp(np.log(c[:3]).mean()-np.log(v[:3]).mean()),' cre+asp/veh %.2f'%np.exp(np.log(a).mean()-np.log(v[:3]).mean()))
