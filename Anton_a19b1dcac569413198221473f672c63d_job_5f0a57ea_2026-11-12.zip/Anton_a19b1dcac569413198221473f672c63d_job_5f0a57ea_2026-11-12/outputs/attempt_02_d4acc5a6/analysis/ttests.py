import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
from scipy import stats
import numpy as np
def hedges_g(a,b):
    na,nb=len(a),len(b); sp=np.sqrt(((na-1)*a.var(ddof=1)+(nb-1)*b.var(ddof=1))/(na+nb-2))
    d=(b.mean()-a.mean())/sp; J=1-3/(4*(na+nb)-9); return d*J
def tt(name, a, b, reported_p=None, reported_t=None):
    t,p=stats.ttest_ind(b,a)             # Student (equal var), creatine - vehicle
    tw,pw=stats.ttest_ind(b,a,equal_var=False)
    mw=stats.mannwhitneyu(b,a,alternative='two-sided')
    df=len(a)+len(b)-2
    diff=b.mean()-a.mean(); se=np.sqrt(a.var(ddof=1)/len(a)+b.var(ddof=1)/len(b))
    sp=np.sqrt(((len(a)-1)*a.var(ddof=1)+(len(b)-1)*b.var(ddof=1))/df); se_p=sp*np.sqrt(1/len(a)+1/len(b))
    tc=stats.t.ppf(0.975,df); lo,hi=diff-tc*se_p, diff+tc*se_p
    ratio=b.mean()/a.mean()
    flag=''
    if reported_p is not None and not np.isclose(p,reported_p,rtol=0.15,atol=2e-4): flag+=f'  <-- P MISMATCH (reported {reported_p})'
    if reported_t is not None and not np.isclose(abs(t),reported_t,rtol=0.02): flag+=f'  <-- t MISMATCH (reported {reported_t})'
    print(f'{name:55s} nA={len(a)} nB={len(b)} meanA={a.mean():.4g}±{a.std(ddof=1):.3g} meanB={b.mean():.4g}±{b.std(ddof=1):.3g} ratio={ratio:.2f} diff={diff:.4g} [{lo:.4g},{hi:.4g}] t={t:.3f} df={df} p={p:.2e} welch_p={pw:.2e} MW_p={mw.pvalue:.3g} g={hedges_g(a,b):.2f}{flag}')
S='Fig. 1a'; tt('1a lung weight', col(S,'B',3,8), col(S,'C',3,8), 0.0003, 5.391)
tt('1a SUV-BW', col(S,'B',12,17), col(S,'C',12,17), 0.0026, 3.975)
S='Fig. 1b'; tt('1b met burden', col(S,'B',3,8), col(S,'C',3,8), 0.0005, 5.025)
tt('1b foci', col(S,'B',12,17), col(S,'C',12,17), 0.0006, 4.938)
S='Fig. 1i'; tt('1i GFP+ cells/field (fields as n)', col(S,'B',4,11), col(S,'C',4,11), 5.5e-07, 8.649)
S='Fig. 1j'; tt('1j lung weight', col(S,'B',4,9), col(S,'C',4,9), 0.0011, 4.503)
tt('1j SUV-BW', col(S,'B',13,18), col(S,'C',13,18), 0.0008, 4.693)
S='Fig. 1k'; tt('1k met burden', col(S,'B',4,9), col(S,'C',4,9), 5.79e-05, 6.639)
tt('1k foci', col(S,'B',12,17), col(S,'C',12,17), 5.70e-05, 6.652)
S='Fig. 2a'
for lab,r0 in [('PLT',4),('PCT',12),('PDW',19),('MPV',27)]:
    tt('2a '+lab, col(S,'B',r0,r0+2), col(S,'C',r0,r0+2))
S='Fig. 2b'
for lab,r,rp,rt in [('ADP',4,0.0003,11.62),('Collagen',5,0.0005,10.07),('Thrombin',6,0.0011,8.386)]:
    tt('2b aggregation '+lab, row(S,r,2,4), row(S,r,5,7), rp, rt)
S='Fig. 2c'; tt('2c a-granules (fields as n)', col(S,'B',4,11), col(S,'C',4,11), 0.0083, 3.071)
S='Fig. 2d'
for lab,r0,rp,rt in [('TEG-R',4,0.8965,0.1343),('TEG-K',12,0.1667,1.521),('TEG-alpha',20,0.1454,1.613),('TEG-MA',28,0.0489,2.321)]:
    tt('2d '+lab, col(S,'B',r0,r0+4), col(S,'C',r0,r0+4), rp, rt)
S='Fig. 2j'; tt('2j PKH+ area (fields as n)', col(S,'B',4,11), col(S,'C',4,11), 0.0014, 3.967)
S='Fig. 3b'; tt('3b serum creatine WT', row(S,4,2,6), row(S,4,7,11), 6.876e-06, 10.29)
tt('3b serum creatine KO', row(S,5,2,6), row(S,5,7,11), 1.5697e-08, 22.58)
S='Fig. 3c'; tt('3c MK creatine WT', row(S,4,2,4), row(S,4,5,7), 0.0493, 2.789)
tt('3c MK creatine KO', row(S,5,2,4), row(S,5,5,7), 0.198, 1.542)
S='Fig. 4a'; tt('4a MK creatine', col(S,'B',4,6), col(S,'C',4,6), 0.0004, 10.91)
tt('4a brain creatine', col(S,'D',4,6), col(S,'E',4,6), 0.0268, 3.421)
S='Fig. 4c'; tt('4c MK PCr', col(S,'B',4,6), col(S,'C',4,6), 0.0006, 9.840)
tt('4c brain PCr', col(S,'D',4,6), col(S,'E',4,6), 0.0309, 3.267)
S='Fig. 4d'; tt('4d MK in vitro "creatinine"', col(S,'C',4,6), col(S,'D',4,6), 0.0052, 5.529)
S='Fig. 4f'; tt('4f MK in vitro PCr', col(S,'B',4,6), col(S,'C',4,6), 0.0233, 3.575)
S='Fig. 7g'; tt('7g human PLT transfer lung wt', col(S,'B',4,8), col(S,'C',4,8), 0.02, 2.896)
tt('7g met burden', col(S,'B',12,16), col(S,'C',12,16), 0.0141, 3.126)
tt('7g foci', col(S,'B',19,23), col(S,'C',19,23), 0.0123, 3.219)
S='Supplementary Fig  1a'; tt('S1a body wt d0', row(S,4,2,5), row(S,4,6,9), 0.9186, 0.1065)
tt('S1a body wt d7', row(S,5,2,5), row(S,5,6,9), 0.0839, 2.069)
S='Supplementary Fig  1b'; tt('S1b food', col(S,'B',4,9), col(S,'C',4,9), 0.9949, 0.006543)
S='Supplementary Fig  1c'; tt('S1c water', col(S,'B',4,9), col(S,'C',4,9), 0.8291, 0.2215)
S='Supplementary Fig  1d'; tt('S1d serum creatine', col(S,'B',4,9), col(S,'C',4,9), 3.8e-10, 23.86)
S='Supplementary Fig  1e'; tt('S1e lung wt', col(S,'B',4,9), col(S,'C',4,9), 0.0271, 2.587)
tt('S1e met burden', col(S,'B',13,18), col(S,'C',13,18), 0.0011, 4.535)
tt('S1e foci', col(S,'B',22,27), col(S,'C',22,27), 0.0003, 5.448)
S='Supplementary Fig  1f'; tt('S1f lung wt', col(S,'B',4,7), col(S,'C',4,7), 0.0231, 3.030)
tt('S1f met burden', col(S,'B',12,15), col(S,'C',12,15), 0.0089, 3.805)
tt('S1f foci', col(S,'B',20,23), col(S,'C',20,23), 0.0016, 5.472)
S='Supplementary Fig  1g'; tt('S1g lung wt', col(S,'B',3,12), col(S,'C',3,12), 0.0323, 2.320)
tt('S1g met burden', col(S,'B',15,24), col(S,'C',15,24), 2.48e-07, 7.993)
tt('S1g foci', col(S,'B',28,37), col(S,'C',28,37), 1.22e-05, 5.962)
S='Supplementary Fig  1h'; tt('S1h serum creatine diet', col(S,'C',4,7), col(S,'D',4,7), 1.99e-05, 12.04)
S='Supplementary Fig  1i'; tt('S1i lung wt diet', col(S,'B',3,6), col(S,'C',3,6), 0.0023, 5.081)
tt('S1i met burden diet', col(S,'B',11,14), col(S,'C',11,14), 0.0054, 4.240)
tt('S1i foci diet', col(S,'B',18,21), col(S,'C',18,21), 0.0029, 4.841)
S='Supplementary Fig  1k'; tt('S1k lung wt', col(S,'B',4,13), col(S,'C',4,13), 0.0363, 2.262)
tt('S1k met burden', col(S,'B',16,25), col(S,'C',16,25), 0.0008, 4.046)
tt('S1k foci', col(S,'B',29,38), col(S,'C',29,38), 2.49e-05, 5.617)
S='Supplementary Fig  3a'
for lab,r0,rp in [('WBC',4,0.365),('lymph',12,0.8376),('mono',20,0.5447),('RBC',28,0.1087)]:
    tt('S3a '+lab, col(S,'B',r0,r0+4), col(S,'C',r0,r0+4), rp)
S='Supplementary Fig  5c'; tt('S5c MK creatine CKB-OE', col(S,'B',5,7), col(S,'C',5,7), 0.6112, 0.5507)
tt('S5c MK PCr CKB-OE', col(S,'B',13,15), col(S,'C',13,15), 0.1595, 1.726)
S='Supplementary Fig  8a'; tt('S8a BMI (reported unpaired)', col(S,'C',4,14), col(S,'D',4,14), 0.9328, 0.08538)
