import openpyxl, collections, re
wb=openpyxl.load_workbook('/tmp/work/CRE-MK-01_source_data.xlsx', data_only=True)
occ=collections.defaultdict(list)
for ws in wb.worksheets:
    isq='ΔCT' in ' '.join(str(c.value) for row in ws.iter_rows() for c in row if c.value is not None)
    for row in ws.iter_rows():
        for c in row:
            v=c.value
            if isinstance(v,(int,float)) and not isinstance(v,bool):
                digits=('%.15g'%abs(v)).replace('.','').lstrip('0').split('e')[0]
                if len(digits.rstrip('0'))>=5: occ[round(float(v),10)].append((ws.title,c.coordinate,isq))
dups={k:v for k,v in occ.items() if len(set(s for s,_,_ in v))>1}
nonq={k:v for k,v in dups.items() if not all(q for _,_,q in v)}
print('values with >=5 significant digits appearing in >1 sheet:',len(dups))
print('  of which involve only qPCR (dCt) sheets (explained by 2-decimal dCt rounding, per workbook note):',len(dups)-len(nonq))
print('  involving non-qPCR sheets:',len(nonq))
for k,v in nonq.items(): print('   ',k,[(s,c) for s,c,_ in v])
