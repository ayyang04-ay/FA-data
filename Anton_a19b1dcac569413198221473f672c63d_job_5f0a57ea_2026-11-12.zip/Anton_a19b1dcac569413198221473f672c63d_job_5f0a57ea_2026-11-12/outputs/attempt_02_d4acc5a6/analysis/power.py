import numpy as np
import statsmodels.api as sm
rng=np.random.default_rng(7)
def sim(n_per_arm, cre_fx, abrog, sd=0.5, reps=3000, alpha=0.05, base_fx=0.0, sex_fx=0.2):
    # arms: VC (veh+ctl), CC (cre+ctl), VG (veh+GPVI), CG (cre+GPVI); n_per_arm split evenly by sex
    lc=np.log(cre_fx); hits_primary=0; hits_gate=0; hits_inter=0; frac_est=[]
    for _ in range(reps):
        ys=[];X=[]
        for arm,(c,g) in {'VC':(0,0),'CC':(1,0),'VG':(0,1),'CG':(1,1)}.items():
            sex=np.r_[np.zeros(n_per_arm//2),np.ones(n_per_arm-n_per_arm//2)]
            mu=c*lc + g*base_fx + c*g*(-abrog*lc) + sex*sex_fx
            y=mu+rng.normal(0,sd,n_per_arm); ys.append(y); X.append(np.c_[np.full(n_per_arm,c),np.full(n_per_arm,g),np.full(n_per_arm,c*g),sex])
        y=np.concatenate(ys); X=sm.add_constant(np.vstack(X)); m=sm.OLS(y,X).fit()
        b=m.params; V=m.cov_params()
        # gatekeeper: CC vs VC -> coef c
        gate=m.pvalues[1]<alpha
        # primary: CG vs CC -> g + cg
        L=np.array([0,0,1,1,0]); est=L@b; se=np.sqrt(L@V@L); from scipy import stats
        p=2*stats.t.sf(abs(est/se),m.df_resid)
        prim=(p<alpha) and est<0
        inter=(m.pvalues[3]<alpha) and b[3]<0
        hits_gate+=gate; hits_primary+=gate and prim; hits_inter+=inter
    return hits_gate/reps, hits_primary/reps, hits_inter/reps
print('n/arm | true creatine fx | abrogation | P(replication) | P(replication & CG<CC) | P(interaction)')
for n in [8,10,12,14,16]:
    for fx in [2.0,3.0]:
        for ab in [1.0,0.5]:
            g,p,i=sim(n,fx,ab)
            print(f'{n:5d} | {fx:4.1f}x | {ab:4.0%} | {g:.2f} | {p:.2f} | {i:.2f}')
