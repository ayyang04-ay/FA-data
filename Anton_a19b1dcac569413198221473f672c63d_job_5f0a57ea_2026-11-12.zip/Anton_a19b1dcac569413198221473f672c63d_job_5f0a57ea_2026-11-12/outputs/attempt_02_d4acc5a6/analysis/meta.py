import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np, pandas as pd
from scipy import stats
# metastatic burden (%) vehicle vs creatine, independent cohorts
C={
 'Fig 1b':(col('Fig. 1b','B',3,8),col('Fig. 1b','C',3,8)),
 'Fig 1k':(col('Fig. 1k','B',4,9),col('Fig. 1k','C',4,9)),
 'Fig 1f (melanoma, sh-scr arms)':(col('Fig. 1f','B',22,27),col('Fig. 1f','C',22,27)),
 'Fig 3i (Pf4-Cre;Slc6a8+/+ arms)':(col('Fig. 3i','B',10,13),col('Fig. 3i','C',10,13)),
 'Fig 6b (no-inhibitor arms)*':(col('Fig. 6b','B',4,8),col('Fig. 6b','C',4,8)),
 'Supp 1e':(col('Supplementary Fig  1e','B',13,18),col('Supplementary Fig  1e','C',13,18)),
 'Supp 1f':(col('Supplementary Fig  1f','B',12,15),col('Supplementary Fig  1f','C',12,15)),
 'Supp 1g':(col('Supplementary Fig  1g','B',15,24),col('Supplementary Fig  1g','C',15,24)),
 'Supp 1i (5% creatine diet)':(col('Supplementary Fig  1i','B',11,14),col('Supplementary Fig  1i','C',11,14)),
 'Supp 1k':(col('Supplementary Fig  1k','B',16,25),col('Supplementary Fig  1k','C',16,25)),
}
rows=[]
for k,(v,c) in C.items():
    lv,lc=np.log(v),np.log(c)
    d=lc.mean()-lv.mean(); se=np.sqrt(lv.var(ddof=1)/len(lv)+lc.var(ddof=1)/len(lc))
    rows.append(dict(cohort=k,n_veh=len(v),n_cre=len(c),ratio=np.exp(d),lo=np.exp(d-1.96*se),hi=np.exp(d+1.96*se),logd=d,se=se,sd_log_veh=lv.std(ddof=1),sd_log_cre=lc.std(ddof=1)))
df=pd.DataFrame(rows)
def dersimonian(df):
    w=1/df.se**2; fe=(w*df.logd).sum()/w.sum(); Q=(w*(df.logd-fe)**2).sum(); k=len(df)
    tau2=max(0,(Q-(k-1))/(w.sum()-(w**2).sum()/w.sum())); wr=1/(df.se**2+tau2)
    re=(wr*df.logd).sum()/wr.sum(); sere=np.sqrt(1/wr.sum()); I2=max(0,(Q-(k-1))/Q) if Q>0 else 0
    # 95% prediction interval
    tcrit=stats.t.ppf(0.975,k-2); pi=(np.exp(re-tcrit*np.sqrt(tau2+sere**2)),np.exp(re+tcrit*np.sqrt(tau2+sere**2)))
    return np.exp(re),np.exp(re-1.96*sere),np.exp(re+1.96*sere),I2,tau2,Q,pi
pd.set_option('display.width',200)
print(df[['cohort','n_veh','n_cre','ratio','lo','hi','sd_log_veh','sd_log_cre']].round(2).to_string())
for lab,sub in [('all 10 cohorts',df),('excluding Fig 6b (duplication)',df[~df.cohort.str.contains('6b')])]:
    r,lo,hi,I2,tau2,Q,pi=dersimonian(sub)
    print(f'{lab}: pooled ratio of geometric means = {r:.2f} (95% CI {lo:.2f}-{hi:.2f}); I2={I2:.0%}; tau2={tau2:.3f}; 95% prediction interval {pi[0]:.2f}-{pi[1]:.2f}; total animals {int(sub.n_veh.sum()+sub.n_cre.sum())}')
pooled_sd=np.sqrt(np.average(np.r_[df.sd_log_veh**2,df.sd_log_cre**2],weights=np.r_[df.n_veh-1,df.n_cre-1]))
print('pooled within-group SD of log(burden): %.3f ; vehicle-only %.3f ; creatine-only %.3f'%(pooled_sd,np.sqrt(np.average(df.sd_log_veh**2,weights=df.n_veh-1)),np.sqrt(np.average(df.sd_log_cre**2,weights=df.n_cre-1))))
# smallest cohorts effect vs n (small-study effect check)
print('Egger-type check: correlation of log ratio with SE: r=%.2f p=%.3f'%stats.pearsonr(df.logd,df.se))
df.to_csv('meta_burden.csv',index=False)
