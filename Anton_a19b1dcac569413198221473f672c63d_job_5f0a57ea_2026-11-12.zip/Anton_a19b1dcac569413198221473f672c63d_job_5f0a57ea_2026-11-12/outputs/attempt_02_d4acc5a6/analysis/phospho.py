import pandas as pd, numpy as np
from statsmodels.stats.multitest import multipletests
df=pd.read_excel('/tmp/work/CRE-MK-01_phosphoproteomics.xlsx'); df.columns=['gene','p','q','lfc']
N=len(df); art=np.isclose(df.p,1-1/np.sqrt(3),atol=1e-9)
print('Phosphoproteomics diagnostics (CRE-MK-01_phosphoproteomics.xlsx, sheet "Volcano ")')
print('entries',N,'; unique gene names',df.gene.nunique(),'; blank gene names',int(df.gene.isna().sum()))
print('entries with p exactly = 1-1/sqrt(3) = 0.422650 (two-sided t-test p for t=1, df=2; single-replicate detection artefact):',int(art.sum()),f'({art.mean():.1%}); median |log-ratio| in these {np.median(abs(df.lfc[art])):.2f} vs {np.median(abs(df.lfc[~art])):.2f} in others')
for thr in [0.05,0.01,0.001]:
    print(f'p<{thr}: observed {int((df.p<thr).sum())}; expected under a uniform null over all rows {N*thr:.0f}; among non-artefact rows observed {int((df.p[~art]<thr).sum())} vs expected {int((~art).sum()*thr)}')
print('Storey pi0 (lambda=0.5):',round((df.p>0.5).mean()/0.5,3))
print('p-value decile histogram (non-artefact rows):',np.histogram(df.p[~art],bins=np.linspace(0,1,11))[0].tolist())
q=multipletests(df.p,method='fdr_bh')[1]
print('BH FDR recomputed: min q = %.3f; n q<0.05 = %d; n q<0.10 = %d. Provided Q-VALUE column min = %.3f'%(q.min(),(q<0.05).sum(),(q<0.1).sum(),df.q.min()))
fc=2**df.lfc; sig=(df.p<0.05)&((fc>=1.2)|(fc<=0.83))
print('rows meeting the study screening rule (p<0.05 and FC>=1.2 or <=0.83, log2 assumed):',int(sig.sum()))
df['rank_by_p']=df.p.rank(method='min').astype(int)
print('\nSTAT5 entries:'); print(df[df.gene.isin(['Stat5a','Stat5b'])].to_string())
print('\nTop 25 entries by p:'); print(df.sort_values('p').head(25).to_string())
print('\nNote: no phosphosite positions are reported in the file; Ckb and Slc6a8 are absent.')
