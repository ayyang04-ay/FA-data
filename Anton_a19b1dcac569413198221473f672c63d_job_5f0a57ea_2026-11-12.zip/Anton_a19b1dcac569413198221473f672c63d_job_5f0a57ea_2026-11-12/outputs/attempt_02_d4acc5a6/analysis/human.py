import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.anova import AnovaRM
from statsmodels.stats.multitest import multipletests
np.set_printoptions(precision=3, suppress=True)
print('=== Fig 7b serum creatine (uM), 11 volunteers x 4 days')
S='Fig. 7b'; M=np.array([row(S,r,2,5) for r in range(4,15)])
print(M)
print('means by day',M.mean(0).round(1),'sd',M.std(0,ddof=1).round(1))
df=pd.DataFrame(M,columns=['d0','d3','d7','d14']).reset_index().melt(id_vars='index',var_name='day',value_name='y')
print(AnovaRM(df,'y','index',within=['day']).fit())
print('Friedman',stats.friedmanchisquare(*M.T))
for j,d in enumerate(['d3','d7','d14'],1):
    t=stats.ttest_rel(M[:,j],M[:,0]); w=stats.wilcoxon(M[:,j],M[:,0]); print(d,'paired t p=%.2e'%t.pvalue,'wilcoxon p=%.4g'%w.pvalue,'fold=%.2f'%(M[:,j].mean()/M[:,0].mean()), 'n increased',(M[:,j]>M[:,0]).sum())
print()
print('=== Supp 8a BMI paired'); S='Supplementary Fig  8a'; a=col(S,'C',4,14); b=col(S,'D',4,14)
print('paired t',stats.ttest_rel(b,a),'mean diff',(b-a).mean())
print()
print('=== Supp 8b CBC (paired / RM)')
S='Supplementary Fig  8b'
for lab,r0 in [('PLT',4),('PCT',19),('MPV',33),('PDW',48)]:
    M=np.array([row(S,r,2,5) for r in range(r0,r0+11)])
    fr=stats.friedmanchisquare(*M.T)
    d14=stats.ttest_rel(M[:,3],M[:,0])
    print(f'{lab}: means {M.mean(0).round(3)} Friedman p={fr.pvalue:.3f} paired t d14 vs d0 p={d14.pvalue:.3f}')
