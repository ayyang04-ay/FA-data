import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np, pandas as pd
from scipy import stats
S='Fig. 7d'; ws=WB[S]
# gene blocks: (gene, start_row, col_offset) ; left block cols C-F (3-6), right block cols I-L (9-12)
blocks=[('ITGA2B',7,3),('P2RY12',7,9),('GP6',26,3),('GP1BA',26,9),('F2R',45,3),('ADRA2A',45,9),('FCGR2A',64,3),('RUNX1',64,9),('RAB4A',83,3),('RAB27B',83,9),('PITPNB',101,3)]
res=[]
for g,r0,c0 in blocks:
    dct=np.array([[ws.cell(r,c).value for c in range(c0,c0+4)] for r in range(r0,r0+12)],dtype=float)  # 12 rows: 0d x3,3d x3,7d x3,14d x3 ; 4 volunteers
    rep_norm=np.array([[ws.cell(r,c).value for c in range(c0,c0+4)] for r in range(r0+12,r0+16)],dtype=float) # After normalization 0,3,7,14
    days=['0','3','7','14']
    m=np.array([dct[3*i:3*i+3].mean(0) for i in range(4)])  # mean dCT per day x volunteer (dCT = Ct_ref - Ct_target convention)
    ddct=m[1:]-m[0]   # log2 fold vs day0 (3 x 4)
    # alt: ratio of mean 2^dCT
    alt=np.array([ (2**dct[3*i:3*i+3]).mean(0)/(2**dct[0:3]).mean(0) for i in range(1,4)])
    rec={'gene':g}
    for j,d in enumerate(['3','7','14']):
        rec[f'd{d}_log2FC_by_vol']=np.round(ddct[j],2).tolist()
        rec[f'd{d}_mean_log2FC']=ddct[j].mean()
        rec[f'd{d}_n_up']=int((ddct[j]>0).sum())
        rec[f'd{d}_p_1samp']=stats.ttest_1samp(ddct[j],0).pvalue
    rec['reported_norm_d14']=np.round(rep_norm[3],2).tolist()
    rec['recomputed_ratio_of_means_d14']=np.round(alt[2],2).tolist()
    rec['recomputed_2^ddct_d14']=np.round(2**ddct[2],2).tolist()
    rec['dCT_range']=(np.nanmin(dct),np.nanmax(dct))
    res.append(rec)
df=pd.DataFrame(res)
pd.set_option('display.width',300); pd.set_option('display.max_columns',40); pd.set_option('display.max_colwidth',60)
print(df[['gene','d3_log2FC_by_vol','d7_log2FC_by_vol','d14_log2FC_by_vol','d7_n_up','d14_n_up','d7_p_1samp','d14_p_1samp']].to_string())
print()
print(df[['gene','reported_norm_d14','recomputed_ratio_of_means_d14','recomputed_2^ddct_d14','dCT_range']].to_string())
