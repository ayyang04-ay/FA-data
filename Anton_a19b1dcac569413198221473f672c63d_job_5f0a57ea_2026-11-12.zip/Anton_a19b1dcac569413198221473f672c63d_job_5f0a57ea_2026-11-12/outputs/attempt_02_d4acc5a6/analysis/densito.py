from PIL import Image
import numpy as np
def band_profile(img, x0,x1,y0,y1, bgrows=4):
    a=255-np.asarray(img.crop((x0,y0,x1,y1)),dtype=float)
    bg=np.median(np.vstack([a[:bgrows],a[-bgrows:]]),axis=0)
    sig=np.clip(a-bg,0,None).sum(axis=0)
    return sig
def lanes(img,x0,x1,y0,y1,centers,hw=18):
    s=band_profile(img,x0,x1,y0,y1)
    out=[]
    for c in centers:
        lo=max(0,c-hw-x0); hi=min(len(s),c+hw-x0)
        out.append(s[lo:hi].sum())
    return np.array(out)
def refine_centers(img,x0,x1,y0,y1,approx,hw=14):
    s=band_profile(img,x0,x1,y0,y1)
    k=np.ones(9)/9; ss=np.convolve(s,k,mode='same')
    out=[]
    for c in approx:
        lo=max(0,c-hw-x0); hi=min(len(ss),c+hw-x0)
        out.append(x0+lo+int(np.argmax(ss[lo:hi])))
    return out
