import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np
S='Fig. 7d'; ws=WB[S]
blocks=[('ITGA2B',7,3),('P2RY12',7,9),('GP6',26,3),('GP1BA',26,9),('F2R',45,3),('ADRA2A',45,9),('FCGR2A',64,3),('RUNX1',64,9),('RAB4A',83,3),('RAB27B',83,9),('PITPNB',101,3)]
n=0; bad=0
for g,r0,c0 in blocks:
    dct=np.array([[ws.cell(r,c).value for c in range(c0,c0+4)] for r in range(r0,r0+12)],dtype=float)
    rep=np.array([[ws.cell(r,c).value for c in range(c0,c0+4)] for r in range(r0+12,r0+16)],dtype=float)
    for i,d in enumerate(['0','3','7','14']):
        rc=(2**dct[3*i:3*i+3]).mean(0)/(2**dct[0:3]).mean(0)
        for v in range(4):
            n+=1
            if not np.isclose(rc[v],rep[i,v],rtol=0.03):
                bad+=1; print(f'MISMATCH {g} volunteer{v+1} day{d}: reported {rep[i,v]:.3f} vs recomputed {rc[v]:.3f}')
print('checked',n,'cells; mismatches',bad)
