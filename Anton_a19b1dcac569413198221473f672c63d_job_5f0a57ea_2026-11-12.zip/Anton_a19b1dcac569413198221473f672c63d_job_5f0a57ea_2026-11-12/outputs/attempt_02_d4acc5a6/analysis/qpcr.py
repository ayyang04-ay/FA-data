import sys; sys.path.insert(0,'/tmp/work/analysis')
from load import *
import numpy as np, pandas as pd, re
from scipy import stats
from statsmodels.stats.multitest import multipletests
# Generic parser: find gene label rows in col A; within block, rows with 'ΔCT1','ΔCT2','ΔCT3','ΔCT4' labels in cols F,J,N
def parse(sheet):
    ws=WB[sheet]; out={}
    maxr=ws.max_row
    for r in range(1,maxr+1):
        a=ws.cell(r,1).value
        if isinstance(a,str) and a.strip() and ws.cell(r,6).value in ('ΔCT1',) :
            gene=a.strip(); blk={}
            # columns: labels at F(6),J(10),N(14); values at G-I, K-M, O-Q
            for lc,vc in [(6,7),(10,11),(14,15)]:
                lab1=ws.cell(r,lc).value; lab2=ws.cell(r+1,lc).value
                if lab1 is None: continue
                v1=[ws.cell(r,c).value for c in range(vc,vc+3)]
                v2=[ws.cell(r+1,c).value for c in range(vc,vc+3)]
                norm=[ws.cell(r+3,c).value for c in range(vc,vc+3)]
                blk[lab2]=dict(base=np.array(v1,float),trt=np.array(v2,float),reported=np.array(norm,float))
            vehnorm=np.array([ws.cell(r+3,c).value for c in range(3,6)],float)
            out[gene]=dict(blk=blk,vehnorm=vehnorm)
    return out
sheets={'Fig. 2f':['Creatine'],'Fig. 3f':['WT-cre','KO-veh','KO-cre'],'Fig. 4h':['Creatine','PCr'],'Fig. 4j':['ctl+siCkb','cre+siScr','cre+siCkb'],
        'Fig. 4l':['CKB-OE'],'Fig.6a':['Creatine','veh+STAT5i','cre+STAT5i'],'Fig. 6g':['WT-cre','Stat5bKO-cre'],'Supplementary Fig  4e':['KO MK creatine','KO MK creatine@liposome'],
        'Supplementary Fig  3c':['Creatine']}
allrows=[]
for s,labs in sheets.items():
    P=parse(s)
    for gene,d in P.items():
        base=None
        for (k,b),lab in zip(d['blk'].items(),labs):
            ddct=b['trt']-b['base']; rec=2**ddct
            mism=~np.isclose(rec,b['reported'],rtol=0.02)
            if mism.any(): print(f'  MISMATCH {s} {gene} {lab}: reported {b["reported"].round(3)} recomputed {rec.round(3)}')
            base=b['base']
            # log2FC vs vehicle group: compare trt dCT vs base dCT (unpaired t on dCT, equal var)
            t,p=stats.ttest_ind(b['trt'],b['base'])
            allrows.append(dict(sheet=s,gene=gene,contrast=lab+' vs veh',log2FC=ddct.mean(),FC=2**ddct.mean(),p_unpaired=p,
                                n_up=int((ddct>0).sum()),min_fc=rec.min(),max_fc=rec.max()))
        # check vehicle normalization
        vn=2**base/np.mean(2**base)
        if not np.allclose(vn,d['vehnorm'],rtol=0.02): print(f'  VEHNORM MISMATCH {s} {gene}: reported {d["vehnorm"].round(3)} recomputed {vn.round(3)}')
df=pd.DataFrame(allrows)
df['q_within_sheet_contrast']=np.nan
for (s,c),sub in df.groupby(['sheet','contrast']):
    df.loc[sub.index,'q_within_sheet_contrast']=multipletests(sub.p_unpaired,method='fdr_bh')[1]
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
print(df.round(4).to_string())
df.to_csv('/tmp/work/analysis/qpcr_summary.csv',index=False)
