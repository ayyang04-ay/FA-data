"""Minimal Markdown -> PDF renderer (reportlab) for the proposal document.
Supports: headings (#, ##, ###), paragraphs, **bold**, *italic*, `code`, bullet lists (- , nested by 2 spaces),
numbered lists (1. ), pipe tables, images ![alt](path), horizontal rules (---).
"""
import re, os, sys
import matplotlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak,
                                ListFlowable, ListItem, KeepTogether, HRFlowable)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping

FD = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
pdfmetrics.registerFont(TTFont('DV', os.path.join(FD, 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B', os.path.join(FD, 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DV-I', os.path.join(FD, 'DejaVuSans-Oblique.ttf')))
pdfmetrics.registerFont(TTFont('DV-BI', os.path.join(FD, 'DejaVuSans-BoldOblique.ttf')))
pdfmetrics.registerFont(TTFont('DVM', os.path.join(FD, 'DejaVuSansMono.ttf')))
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DV-B'); addMapping('DV', 0, 1, 'DV-I'); addMapping('DV', 1, 1, 'DV-BI')

BASE = 8.6
sty = {
    'body': ParagraphStyle('body', fontName='DV', fontSize=BASE, leading=BASE * 1.38, spaceAfter=3.5),
    'lead': ParagraphStyle('lead', fontName='DV', fontSize=BASE + 1.6, leading=(BASE + 1.6) * 1.35, spaceAfter=6,
                           backColor=colors.HexColor('#eef6f3'), borderColor=colors.HexColor('#16a085'),
                           borderWidth=0.8, borderPadding=6, textColor=colors.HexColor('#0b3d33')),
    'h1': ParagraphStyle('h1', fontName='DV-B', fontSize=14, leading=18, spaceBefore=8, spaceAfter=4, textColor=colors.HexColor('#1f2d3a')),
    'h2': ParagraphStyle('h2', fontName='DV-B', fontSize=11.5, leading=15, spaceBefore=9, spaceAfter=3, textColor=colors.HexColor('#1f2d3a')),
    'h3': ParagraphStyle('h3', fontName='DV-B', fontSize=9.8, leading=13, spaceBefore=6, spaceAfter=2, textColor=colors.HexColor('#2c3e50')),
    'cell': ParagraphStyle('cell', fontName='DV', fontSize=6.9, leading=8.6),
    'cellh': ParagraphStyle('cellh', fontName='DV-B', fontSize=6.9, leading=8.6, textColor=colors.white),
    'small': ParagraphStyle('small', fontName='DV-I', fontSize=7.5, leading=10, textColor=colors.HexColor('#555555')),
}

def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'`([^`]+)`', r'<font face="DVM" size="7.5">\1</font>', t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'<i>\1</i>', t)
    return t

def build(md_path, pdf_path):
    base_dir = os.path.dirname(md_path)
    lines = open(md_path, encoding='utf-8').read().split('\n')
    story = []
    W = A4[0] - 30 * mm
    i = 0
    first = True
    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        if not s:
            i += 1; continue
        if first:
            story.append(Paragraph(inline(s), sty['lead'])); story.append(Spacer(1, 4)); first = False; i += 1; continue
        if s == '---':
            story.append(HRFlowable(width='100%', thickness=0.6, color=colors.HexColor('#bbbbbb'), spaceBefore=4, spaceAfter=4)); i += 1; continue
        m = re.match(r'^(#{1,3})\s+(.*)', s)
        if m:
            lvl = len(m.group(1)); story.append(Paragraph(inline(m.group(2)), sty['h%d' % lvl])); i += 1; continue
        m = re.match(r'^!\[(.*?)\]\((.*?)\)', s)
        if m:
            p = os.path.join(base_dir, m.group(2))
            from PIL import Image as PImage
            w, h = PImage.open(p).size
            iw = W * 0.98; ih = iw * h / w
            if ih > 120 * mm:
                ih = 120 * mm; iw = ih * w / h
            story.append(Spacer(1, 3)); story.append(Image(p, width=iw, height=ih)); story.append(Spacer(1, 4)); i += 1; continue
        if s.startswith('|'):
            rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                r = [c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.match(r'^:?-{2,}:?$', c) for c in r):
                    rows.append(r)
                i += 1
            ncol = max(len(r) for r in rows)
            rows = [r + [''] * (ncol - len(r)) for r in rows]
            # column widths proportional to sqrt of max text length
            import math
            lens = [max(len(re.sub(r'\*', '', rows[k][j])) for k in range(len(rows))) for j in range(ncol)]
            wts = [max(6, min(60, L)) ** 0.75 for L in lens]
            tot = sum(wts); cw = [W * w_ / tot for w_ in wts]
            data = []
            for k, r in enumerate(rows):
                data.append([Paragraph(inline(c), sty['cellh'] if k == 0 else sty['cell']) for c in r])
            t = Table(data, colWidths=cw, repeatRows=1)
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c3e50')),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('GRID', (0, 0), (-1, -1), 0.3, colors.HexColor('#b0b7bf')),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f4f6f8')]),
                ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
                ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]))
            story.append(Spacer(1, 2)); story.append(t); story.append(Spacer(1, 5)); continue
        if re.match(r'^\s*([-*]|\d+\.)\s+', ln):
            items = []  # (level, ordered, text)
            while i < len(lines) and re.match(r'^\s*([-*]|\d+\.)\s+', lines[i]):
                raw = lines[i]
                indent = len(raw) - len(raw.lstrip(' '))
                mm_ = re.match(r'^\s*([-*]|\d+\.)\s+(.*)', raw)
                txt = mm_.group(2)
                # continuation lines (indented, non-list)
                j = i + 1
                while j < len(lines) and lines[j].strip() and not re.match(r'^\s*([-*]|\d+\.)\s+', lines[j]) and lines[j].startswith('   '):
                    txt += ' ' + lines[j].strip(); j += 1
                items.append((indent // 2, mm_.group(1)[0].isdigit(), txt))
                i = j
            def mk(level_items, start_level):
                flow = []; k = 0
                ordered = level_items[0][1] if level_items else False
                while k < len(level_items):
                    lvl, od, txt = level_items[k]
                    sub = []
                    k2 = k + 1
                    while k2 < len(level_items) and level_items[k2][0] > lvl:
                        sub.append(level_items[k2]); k2 += 1
                    content = [Paragraph(inline(txt), sty['body'])]
                    if sub:
                        content.append(mk(sub, lvl + 1))
                    flow.append(ListItem(content, leftIndent=12 + 10 * start_level))
                    k = k2
                if ordered:
                    return ListFlowable(flow, bulletType='1', bulletFontName='DV', bulletFontSize=BASE, leftIndent=12 + 10 * start_level)
                return ListFlowable(flow, bulletType='bullet', start='•', bulletFontName='DV', bulletFontSize=BASE, leftIndent=12 + 10 * start_level)
            story.append(mk(items, 0)); continue
        # paragraph (merge following non-empty plain lines)
        para = s; i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r'^(#|\||!\[|---|\s*([-*]|\d+\.)\s+)', lines[i].strip()):
            para += ' ' + lines[i].strip(); i += 1
        st = sty['small'] if para.startswith('*') and para.endswith('*') and not para.startswith('**') else sty['body']
        story.append(Paragraph(inline(para), st))

    def footer(canvas, doc):
        canvas.saveState(); canvas.setFont('DV', 7); canvas.setFillColor(colors.HexColor('#777777'))
        canvas.drawString(15 * mm, 9 * mm, 'CRE-MK-01 follow-up: validation proposal (prepared from the CRE-MK-01 data package)')
        canvas.drawRightString(A4[0] - 15 * mm, 9 * mm, 'p. %d' % doc.page)
        canvas.restoreState()
    doc = SimpleDocTemplate(pdf_path, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm, bottomMargin=16 * mm,
                            title='CRE-MK-01 validation proposal', author='Prepared from CRE-MK-01 data package')
    doc.build(story, onFirstPage=footer, onLaterPages=footer)

if __name__ == '__main__':
    build(sys.argv[1], sys.argv[2])
    print('wrote', sys.argv[2])
