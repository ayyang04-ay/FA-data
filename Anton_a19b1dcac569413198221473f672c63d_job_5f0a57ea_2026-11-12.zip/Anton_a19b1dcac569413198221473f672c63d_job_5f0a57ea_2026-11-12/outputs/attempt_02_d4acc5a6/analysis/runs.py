import openpyxl, numpy as np, itertools
WB=openpyxl.load_workbook('/tmp/work/CRE-MK-01_source_data.xlsx', data_only=True)
# collect vertical and horizontal runs of numeric cells (len>=2) from non-qPCR sheets
seqs=[]
for ws in WB.worksheets:
    txt=' '.join(str(c.value) for row in ws.iter_rows() for c in row if c.value is not None)
    if 'ΔCT' in txt: continue
    grid={}
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value,(int,float)) and not isinstance(c.value,bool): grid[(c.row,c.column)]=float(c.value)
    # vertical runs
    for (r,cidx),v in grid.items():
        if (r-1,cidx) in grid: continue
        run=[];rr=r
        while (rr,cidx) in grid: run.append(grid[(rr,cidx)]); rr+=1
        if len(run)>=2: seqs.append((ws.title,f'col{cidx}@r{r}',run))
    for (r,cidx),v in grid.items():
        if (r,cidx-1) in grid: continue
        run=[];cc=cidx
        while (r,cc) in grid: run.append(grid[(r,cc)]); cc+=1
        if len(run)>=2: seqs.append((ws.title,f'row{r}@c{cidx}',run))
def sig(v): 
    s=('%.12g'%abs(v)).replace('.','').lstrip('0'); return len(s.rstrip('0'))
found=set()
for (s1,l1,a),(s2,l2,b) in itertools.combinations(seqs,2):
    if s1==s2 and l1==l2: continue
    for i in range(len(a)-1):
        for j in range(len(b)-1):
            if np.isclose(a[i],b[j],rtol=0,atol=1e-9) and np.isclose(a[i+1],b[j+1],rtol=0,atol=1e-9):
                if sig(a[i])>=3 or sig(a[i+1])>=3:
                    # skip trivially small integers like 1,1
                    if abs(a[i])==1 and abs(a[i+1])==1: continue
                    key=(s1,l1,s2,l2,i,j)
                    if key not in found:
                        found.add(key); print(f'{s1} {l1}[{i}:{i+2}] == {s2} {l2}[{j}:{j+2}] : {a[i]}, {a[i+1]}')
print('done')
