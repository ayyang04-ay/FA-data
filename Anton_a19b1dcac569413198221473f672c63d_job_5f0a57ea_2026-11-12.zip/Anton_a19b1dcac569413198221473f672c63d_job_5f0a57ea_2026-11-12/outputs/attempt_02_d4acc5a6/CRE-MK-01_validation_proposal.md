**Recommendation: we take forward platelet GPVI (the GP6 gene product) as the primary target. It is the receptor through which creatine-loaded megakaryocytes hand a pro-metastatic state to their platelets. Megakaryocyte STAT5B is backup 1 and approved-antiplatelet repurposing (aspirin first) is backup 2.**

# CRE-MK-01 follow-up: validation proposal for the next-quarter in vivo slot

*Source: the CRE-MK-01 data package only. That is the source-data workbook (87 sheets, including 26 embedded blot images), the phosphoproteomics workbook (5,812 phosphopeptides) and the study-conventions PDF. Every number below was recomputed from the raw values rather than taken from the Prism summaries. Derivations are in Appendix A and the scripts are in `analysis/`. Figures are in `figures/`. Points that rest on general knowledge rather than on this package are marked "(outside the package)".*

---

## 1. Decision in brief

**The ask: one in vivo slot for study CRE-MK-02.** This is a masked, randomised, both-sex study in the C57BL/6 melanoma lung-metastasis setting. The core is 5 arms × 16 mice = 80 mice; with the add-ons it is 104–144 mice.

- It first re-tests the creatine effect under unbiased conditions. This is a gate: if the effect does not reproduce, the programme stops.
- It then tests whether GPVI blockade removes the creatine-driven excess metastasis.
- Aspirin is benchmarked in the same run as the approved-drug comparator; a P2Y12 antagonist is optional.
- The megakaryocyte (MK) Slc6a8 deletion is re-run as the positive control for "pathway fully removed".

**Why GPVI is the primary target:**

1. **Strongest and most consistent output of the creatine programme.** Across the six independent creatine-vs-vehicle MK experiments, *Gp6* has the highest median induction of the 11 genes measured: 4.9× (range 2.8–42×), significant in 6/6.
   - The induction needs SLC6A8, CKB and STAT5: it is 0.9× in Slc6a8-deleted MKs, 1.4× with si-Ckb, 0.6× with STAT5-IN-1 and 1.4× in Stat5b-deleted MKs.
   - Liposomal creatine in Slc6a8-null MKs restores it (2.8×).
   - ChIP in the STAT5B figure shows 2.9–3.8× promoter enrichment at *Gp6* (Fig 5j). The workbook does not record which protein was immunoprecipitated.
2. **The only effector that moves in supplemented humans at both protein and function level.** I re-analysed the human data as paired data.
   - Platelet GP6 protein rose by day 14 in 4/4 volunteers (Fig 7e). My own approximate re-quantification of the blot images (Supp 8d) agrees.
   - Collagen-induced aggregation (a GPVI-dependent response) rose 2.5× in 9/11 volunteers (Wilcoxon p = 0.005; FDR q = 0.012).
   - By contrast, the ADP/P2Y12 response did not move (1.07×, 6/11, p = 0.46). The reported rise in P2RY12 protein is not visible on the blot images.
3. **It is the right point to intervene for this indication.**
   - The creatine effect changes what platelets do, not how many there are: platelet counts are unchanged in mice and humans (Figs 2a, S4b, S7a/b, S8b).
   - Freshly isolated platelets do not respond to creatine in vitro; megakaryocytes do (Fig 2i).
   - Platelets from supplemented volunteers transfer the effect to mice: 2.76× burden (95% CI 1.60–4.76; Fig 7g).
   - A platelet-lineage receptor (GPVI's lineage restriction is outside the package) is the one place to block the pro-metastatic consequence without undoing creatine uptake in muscle and brain. The package itself shows brain creatine and phosphocreatine rising with supplementation and CKB being abundant in brain (Figs 4a–c).

**Why not STAT5B first:**

- The only in vivo efficacy evidence for STAT5 is Fig 6b. Three of its vehicle animals and three of its creatine animals also appear in Supp Fig 2d, a different experiment (the aspirin platelet-transfer study). The burden values match to 7 significant figures and the foci counts match, in the same order (Section 3.4).
- Until source records resolve this, neither Fig 6b nor Supp 2d can support a decision.
- Further gaps:
  - No metastasis data exist for the Pf4-iCre;Stat5b knockout.
  - The only STAT5 inhibitor used blocks STAT5A and STAT5B alike, and it lowers basal MK expression of the gene programme even without creatine.
  - Canonical STAT5 tyrosine phosphorylation is undetectable in MKs with or without creatine (Supp 6a).
  - The proposed non-canonical site (STAT5B S127) is not supported at FDR: the Stat5b phosphopeptide has q = 0.25 and its site is not reported.

**Why not SLC6A8 or CKB as targets:**

- MK SLC6A8 has the cleanest genetic evidence in the package. Deleting it removes the creatine effect (ratio of effects 0.22, 95% CI 0.11–0.47; Fig 3i). But blocking it is pharmacologically the same as withdrawing the supplement, and the knockout has no benefit in unsupplemented mice. It stays in the study as the mechanism anchor.
- Tumour-cell SLC6A8 knockdown leaves the effect intact (ratio 0.78, 0.39–1.53; Fig 1f).
- CKB evidence is in vitro only.

**Stop rule.** If the masked replication arms show less than a 1.5× creatine effect, the programme stops regardless of target.

**Indication reality check.**
- No intervention in the package lowers metastasis below the vehicle level. The Slc6a8-KO and STAT5-IN-1 vehicle arms sit at baseline (3.39% vs 2.37% and 3.63% vs 3.45% burden). Creatine + aspirin donor platelets return to the vehicle-donor level, not below it; there is no vehicle + aspirin arm.
- As the data stand, the indication is therefore narrow: patients with cancer who are exposed to supplemental creatine.
- Arm C (vehicle + GPVI blockade) is built in to test whether GPVI offers more than that. If it does not, the likely value of the programme is a risk-mitigation position plus a platelet biomarker, rather than a broad anti-metastatic drug.

**Before the slot (no animals, 2–4 weeks): a source-data audit.** It covers the Fig 6b/Supp 2d duplication, the raw aggregometer traces for Figs 2b and 3d, the human qPCR and blot discrepancies, and site localisation in the phosphoproteomics (Section 7).

**Safety signal to pass to clinical colleagues now.** This does not depend on which target we choose, and it is not yet validated.
- The human regimen (20 g/day ≈ 347 mg/kg/day) matches the mouse regimen per kg (≈315–354 mg/kg/day).
- It raises serum creatine at least as much (3.5× in humans vs 2.7–2.9× in mice).
- Platelets from supplemented volunteers increase metastasis when transferred into mice.

---

## 2. Candidate ranking

Evidence grades are mine, derived in Section 3. "RoR" is the ratio of ratios: the creatine effect with the perturbation divided by the creatine effect without it. RoR = 1 means the perturbation leaves the creatine effect intact. RoR ≈ 1/(creatine effect), about 0.25–0.35 here, means it removes the effect completely.

| Candidate | In vivo causal evidence on metastasis | Mechanistic evidence | Human bridge | Integrity / robustness issues | Fit for this indication | Verdict |
|---|---|---|---|---|---|---|
| **Platelet GPVI (GP6)** | Not yet tested (what the slot is for) | Top-induced MK gene (median 4.9×, 6/6 experiments). Needs SLC6A8, CKB and STAT5; restored by liposomal creatine. ChIP enrichment at promoter (antibody not recorded). | GP6 protein up in 4/4 volunteers; collagen response 2.5×, 9/11, q = 0.012 | Mouse aggregation data (Figs 2b, 3d) have anomalous number patterns. The human cohort had no placebo arm. | Platelet-lineage receptor (outside the package); does not touch creatine handling in muscle or brain | **Primary** |
| **MK STAT5B** | Compromised: Fig 6b shares animals with Supp 2d. Inhibitor hits STAT5A and B. No knockout metastasis test. | Inhibitor and knockout blunt the programme (Figs 6a, 6g). ChIP (Figs 5j, S6i). Nuclear STAT5B up (S6h, unquantified). | None measured | Duplicated animals; S127 evidence weak; phosphosite q = 0.25; no knockout-vehicle arm; "WT" control's Cre status unclear | Transcription factor; the only tool also suppresses the basal MK programme | **Backup 1** (genetic test) |
| **Approved antiplatelets (COX-1/aspirin; P2Y12 antagonists)** | Compromised: Supp 2d shares animals with Fig 6b, and it has no vehicle+aspirin arm | *P2ry12* induced 4.2× and ChIP-bound | ADP response flat (1.07×, p = 0.46); P2RY12 protein rise not visible on blots; arachidonic-acid response modest (1.32×, p = 0.04, q = 0.06) | Duplicated animals | Approved, cheap, fastest route to patients | **Backup 2** (active comparators inside the slot) |
| **MK SLC6A8** | Strong: Pf4-Cre deletion removes the effect (RoR 0.22, 0.11–0.47; interaction p = 0.001) | MK creatine rise lost (3c); programme lost (3f); liposome bypass restores it (S4e) | None | n = 4 per group, unmasked. Deletion looks partial on the blot (~0.73 of control). Fig 3c p = 0.049 (Welch 0.105). Fig 3d number pattern. | Blocking it = withdrawing the supplement; no baseline benefit | **Mechanism anchor** (positive control), not a drug target |
| **Tumour-cell SLC6A8** | Negative: knockdown leaves the effect (RoR 0.78, 0.39–1.53) | n/a | n/a | Knockdown weakly shown (protein ~0.8 of control on blot; "si"/"sh" labels mixed) | n/a | **Drop** for this indication |
| **CKB** | None | si-Ckb blocks, overexpression is sufficient (Figs 4j, 4l); overexpression does not change creatine or phosphocreatine (S5c); kinase assay is n = 1 without controls | None | In vitro only | Brain-type creatine kinase; brain creatine/PCr respond to supplementation (4a–c) | **Park** |

---

## 3. Evidence, analysed

### 3.1 The phenotype is large and consistent, but every cohort was unmasked

![Forest plot](figures/fig1_phenotype_forest.png)

**Pooled effect on lung metastatic burden.**
- Ten vehicle-vs-creatine comparisons are available in the package. I excluded Fig 6b (shared animals), leaving 9 independent cohorts and 112 mice.
- Random-effects pooling of log ratios of geometric means gives **3.04× (95% CI 2.51–3.68)**.
- Heterogeneity is moderate (I² = 49%); the 95% prediction interval is 1.80–5.11. Every cohort is individually positive.
- Cohorts: Figs 1b, 1k, 1f (sh-scrambled arms), 3i (Pf4-Cre;Slc6a8+/+ arms); Supp 1e, 1f, 1g, 1i (5% creatine diet), 1k.
- Foci counts and lung weight move in the same direction in every cohort. Lung PET uptake (SUV) rises 2.1× and 1.7× (Figs 1a, 1j).

**Survival.** Both log-rank results reproduce exactly. All animals died, so there is no censoring.
- Fig 1c: median 18 vs 21 days; HR 2.93 (1.04–8.23); log-rank p = 0.032.
- Fig 1l: median 14 vs 16 days; HR 2.28 (1.16–4.46); p = 0.011.
- Fig 1l has 20 vehicle vs 18 creatine animals, and the missing two are unexplained.

**Timing points to early seeding.** In Fig 1h, lung tumour-cell signal is unchanged 15 minutes after injection (0.86×, p = 0.31). It is higher at 6 h (1.5×, p = 0.0002), 12 h (1.8×, p = 0.026) and 24 h (2.8×, p = 0.004); Holm-adjusted p = 0.0006, 0.052 and 0.012. Arrest in the lung is the same; what changes is retention or survival over the first day, which is a platelet-dependent step.

**No systemic confounders detected.**
- Food and water intake are unchanged (S1b/c).
- Body weight shows a non-significant +1.4 g at day 7 (S1a, p = 0.08).
- WBC, lymphocytes, monocytes and RBC are unchanged (S3a).
- Platelet count, PCT, MPV and PDW are unchanged (Fig 2a).

**Exposure bridge to humans.**
- Mouse gavage: 17 mg, three times a week ≈ 315–354 mg/kg/day (time-averaged, at the body weights in S1a).
- Human regimen: 20 g/day ≈ 347 mg/kg/day at the cohort's mean weight of 57.6 kg.
- Serum creatine rises 2.7× (S1d), 2.9× (diet, S1h) and 2.4–2.7× (Fig 3b) in mice. In humans it rises 3.5× by day 14 (45 → 159 µM), in 11/11 volunteers; repeated-measures ANOVA F = 132, p < 10⁻⁴.
- **Only one human dose was tested.** Lower, maintenance-type doses are untested.

**Caveats that lower confidence in the size (not the direction) of the effect** (from the conventions):
- Allocation and read-out were not masked, and group sizes were not justified by a power calculation.
- Sex was not analysed, and sex is confounded with strain: all males were C57BL/6J and all females BALB/cJ.
- The small-study pattern (r = 0.48 between log ratio and SE, p = 0.16) suggests the noisier cohorts report larger effects.
- CRE-MK-02 is therefore powered on a conservative 2.0× planning effect, not on 3.0×.

### 3.2 The causal chain, link by link

![Node perturbations](figures/fig2_node_perturbations.png)

| Link | Evidence for (recomputed) | Gaps / against |
|---|---|---|
| Oral creatine → serum creatine | 2.4–2.9× in mice; 3.5× in humans (above) | None |
| Serum → MK intracellular creatine via MK SLC6A8 | Serum creatine rises equally in both genotypes: 2.7× in Pf4-Cre;Slc6a8+/+ and 2.4× in fl/fl (3b). MK creatine: 5.3× in +/+ (p = 0.049; Welch 0.105) vs 1.5× in fl/fl (p = 0.20) (3c). In vivo MK creatine 3.0× (4a) and PCr 3.9× (4c). | Fig 3c has n = 3 and a fragile p. On the Supp 4a image, SLC6A8 protein in fl/fl MKs is ~0.73 of control (my approximate re-quantification), so deletion efficiency is unquantified. The blot is a crop from a larger membrane with unlabelled lanes. |
| The tumour cell is *not* the creatine target | Tumour *Slc6a8* shRNA leaves the creatine effect intact: 4.07× → 3.16×, RoR 0.78 (0.39–1.53), p = 0.44 (1f) | Knockdown: mRNA 0.19× with an **si**RNA (S2a), but protein ~0.80 on the **sh**RNA blot (S2a image, my re-quantification). Fig 1f's own comparison label mixes "si" and "WT". Tumour creatine uptake was never measured. |
| MK creatine → transcriptional platelet-activation programme | 11-gene programme induced 2–5× (median) in 6/6 experiments; MK differentiation genes unchanged (S3c); phosphocreatine does not mimic creatine (4h); liposomal creatine bypasses Slc6a8 loss (S4e) | None major. The in vitro effect in Fig 6a is far larger than elsewhere (Gp6 42×, Adra2a 18×). |
| Programme → CKB | *Ckb* mRNA 1.8× in MKs after creatine (4e, p = 0.011). si-Ckb blunts induction (4j). CKB overexpression is sufficient (4l) without changing creatine or PCr (S5c). | Causal evidence in vitro only. Knockdown is partial on the blot (S5b). |
| → STAT5B (proposed: CKB phosphorylates S127) | STAT5-IN-1 blocks induction (6a). Stat5b-deleted MKs keep creatine uptake (6e) but induction is blunted (6g). ChIP enrichment at *P2ry12* (up to 12×), *Gp6* (3–4×) and *Rab4a* (up to 5.5×) promoters; exon controls flat (5j, S6i). The antibody and IgG controls are not recorded. | **pY694/699 absent** in MKs (S6a). STAT5-IN-1 alone lowers basal expression (*Rab4a* 0.21×, *Gp6* 0.39×, *Gpiba* 0.37×, *Itga2b* 0.51×). **No Stat5b-KO vehicle arm**, and residual induction in the KO (*P2ry12* 1.9×, *Adra2a* 1.9×). S127 evidence is discussed in Section 3.4. |
| Programme → platelet phenotype | GP6/P2RY12 protein up in MKs and platelets (blots 2e, 2g, 3g, 6f: n = 1–3 lanes, unquantified). α-granules 1.9× (2c; fields as n). Aggregation up (2b, 3d; flagged). TEG-MA 1.36× (p = 0.049; R, K, α unchanged). | Functional data carry integrity flags (Section 3.4) |
| Platelets → metastasis | Human day-7 platelets → 2.76× burden (1.60–4.76) in recipient mice (7g). Lung PKH+ (labelled) area 2.4× (2j; fields as n). | Number of donors in 7g not recorded. The mouse donor-platelet experiment (S2d) is compromised. |

### 3.3 Why the intervention point is GPVI: gene programme plus human bridge

![Gene programme](figures/fig3_gene_program_heatmap.png)

**Mouse: *Gp6* is the most consistent output.**

- *Gp6* ranks first of 11 genes across the six creatine-vs-vehicle MK contrasts (Figs 2f, 3f, 4h, 4j, 6a, 6g): median 4.9×, geometric mean 7.0×, minimum 2.8×, significant in 6/6.
- Its dependencies are complete:
  - It is lost with Slc6a8 deletion (0.91×), si-Ckb (1.38×), STAT5-IN-1 (0.61×) and Stat5b deletion (1.44×).
  - It is not induced by phosphocreatine (0.51×).
  - It is restored by liposomal creatine in Slc6a8-null MKs (2.76×) and induced by CKB overexpression (2.79×).
- *P2ry12* ranks second (median 4.2×; strongest ChIP signal), but it fails the human test below.
- Every mouse qPCR normalisation (196 contrasts, every replicate) reconciles with its ΔCt inputs. The repeated ΔΔCt values that recur across sheets come from 2-decimal rounding, as the sheets themselves note; they are not duplication.

![Human platelet function](figures/fig4_human_platelet_function.png)

**Human: the reported statistics were not appropriate, and a correct re-analysis separates GPVI from P2Y12.**

- Fig 7c normalises every volunteer to 1 at day 0 and then runs an ordinary one-way ANOVA with Dunnett's test. I confirmed this: the reported CIs reproduce only with the ordinary-ANOVA error term on 40 df. That treats four time points from the same 11 people as independent groups and gives the day-0 group zero variance.
- I re-analysed each agonist and read-out as paired data: Wilcoxon signed-rank on fold vs day 0, one-sample t-test on the log scale, and Friedman test across days. Benjamini–Hochberg FDR was applied across all 36 agonist × read-out × day tests.
- Results at day 14:

| Agonist (receptor) | Day-14 maximal aggregation, geometric mean | Volunteers up | Wilcoxon p | FDR q (12-test day-14 family) | Earlier signal |
|---|---|---|---|---|---|
| Collagen (GPVI) | **2.51×** | 9/11 | 0.005 | 0.012 | — |
| Epinephrine (α2A) | **1.63×** | 10/11 | 0.002 | 0.008 | Day 7 adhesion 11/11, p = 0.001 |
| Arachidonic acid (COX-1) | 1.32× | 9/11 | 0.042 | 0.056 | — |
| **ADP (P2Y12)** | **1.07×** | 6/11 | 0.46 | 0.47 | None at any day |

- *Agonist-to-receptor mapping* (collagen → GPVI, epinephrine → α2A, arachidonic acid → COX-1/thromboxane, ADP → P2Y12) is standard platelet pharmacology (outside the package). It is used here only to interpret the package's own agonist panel.
- **Protein (Fig 7e; β-actin loading control run on separate gels, per the conventions).**
  - GP6/β-actin rose at day 14 in 4/4 volunteers: reported 2.1–5.0×; 1.6–2.6× in my approximate re-quantification of the Supp 8d images.
  - P2RY12 was reported as 1.3–2.7×, but the displayed blots give 0.85–1.21× (volunteer 3's band visibly fades over time).
  - The human data therefore support the GPVI arm and not the P2Y12 arm.

![Human blots](figures/fig6_human_blot_requant.png)

- **CD41⁺-cell mRNA (Fig 7d; n = 4 volunteers, technical triplicates averaged).**
  - *GP6* is up in 4/4 at day 7 (p = 0.054) and at day 14 (p = 0.13).
  - *ADRA2A* is up in 4/4 at day 7 (p = 0.0005) and day 14 (p = 0.03).
  - *RAB4A* falls in 4/4 at day 14 (0.28–0.53×, p = 0.002). That is the opposite direction to mouse, where *Rab4a* is a ChIP-bound target induced 3.5×.
  - *ITGA2B*, the CD41 selection marker itself, swings 6–10× at day 7 in 3/4 volunteers. This signals variable composition of the CD41⁺ isolates, so these mRNA changes cannot be read as per-cell induction.
- **Design limits of the human pilot.**
  - Single arm, no placebo, unblinded. Day 0 is a single baseline, so regression to the mean and assay drift cannot be excluded.
  - Eleven healthy Asian adults aged 20–25; molecular work on a random 4.
  - Coagulation tests are listed in the conventions but are not in the workbook.
- **α2A signal.** The epinephrine/α2A change is the most robust human signal. α2A is not a lineage-restricted intervention point (outside the package), so I carry the epinephrine response forward as a co-primary biomarker, not as a target.

### 3.4 Data-integrity and robustness audit (what changes the decision)

**Arithmetic is sound.**
- Every reported t-test, ANOVA/Tukey comparison and log-rank result reproduces from the raw values (Appendix B).
- All 196 mouse qPCR normalisations reconcile with their inputs; 170 of 176 human ones do.

The problems are in provenance, design and analysis:

![Integrity flags](figures/fig5_integrity_flags.png)

| # | Finding (location) | What I found | Consequence for the decision |
|---|---|---|---|
| 1 | **Shared animals across two experiments** (Fig 6b rows 5–7 vs Supp 2d rows 8–10; foci rows 14–16 vs 17–19) | Burden values 3.29136, 3.733544, 2.886353 (vehicle) and 11.13465, 13.22011, 14.12619 (creatine), and their foci counts (37, 25, 33; 53, 62, 47), are identical and in the same order. One experiment is STAT5-IN-1 in creatine-gavaged mice; the other is recipients of donor platelets. A cell-by-cell scan of all 87 sheets found no other unexplained duplicates (the qPCR/ChIP coincidences follow from 2-decimal Ct rounding). Dropping the shared animals leaves n = 2 per arm in Fig 6b and n = 3 in Supp 2d; the direction persists, but neither can carry a decision. | Both the only in vivo STAT5 efficacy result and the only in vivo aspirin result are unusable until source records resolve which experiment the animals belong to. This is the main reason STAT5B is not primary. |
| 2 | **Non-random structure in platelet aggregation** (Figs 2b, 3d) | Fig 2b: in all 6 triplets the third value equals the exact mean of the first two (e.g. 44/40/42; 20/30/25). Monte-Carlo joint P ≈ 2 × 10⁻⁷; 0/13 comparable integer triplets elsewhere in the workbook show this. Fig 3d: all 36 values are even, 11/12 triplets have the form {x, x, x±2}, and the pooled SD is 1.25 % units. Fig 3d also shows creatine *lowering* aggregation in Slc6a8-null platelets (ADP 54 → 31%), which is unexplained. | The mouse platelet-function link needs the raw aggregometer traces before we rely on it. GPVI's case rests mainly on the transcript, ChIP and human protein/function data, so it survives this flag; the flag is why the human bridge matters. |
| 3 | **Human repeated measures analysed as independent groups** (Figs 7b, 7c, 7e, S8a–b) | The reported Dunnett CIs match an *ordinary* one-way ANOVA error term (df = 40, critical value 2.44), not a repeated-measures one. The paired re-analysis (3.3) confirms the collagen and epinephrine rises. It also makes collagen *average* aggregation significant (q = 0.012, vs reported p = 0.12), and it leaves ADP null. Supp 8a BMI was analysed unpaired as well (paired p = 0.24). | Changes which effector is supported in humans |
| 4 | **Human qPCR values that don't reconcile** (Fig 7d) | Volunteer 4: RAB27B days 3/7/14 reported 2.52/4.44/2.36 vs 3.96/5.70/0.49 recomputed. PITPNB days 3/7/14 reported 1.90/6.84/6.26 vs 0.79/1.92/0.59. Volunteer 4's PITPNB "ΔCt" column holds values of about +27, which look like raw Ct. | Correct before any external use. These genes are not decision-critical. |
| 5 | **Human blot quantification vs images** (Fig 7e vs Supp 8d) | P2RY12 rise not reproduced from the images; GP6 rise reproduced (3.3) | Demotes P2Y12 |
| 6 | **Phosphoproteomics has no multiplicity control** | 0 of 5,812 phosphopeptides pass FDR 0.05 (minimum BH q = 0.25). 1,702 (29%) have p = 1 − 1/√3 exactly, a t-test artefact of one-replicate detection. Only 238 have p < 0.05, against ~291 expected by chance over all rows. Stat5b phosphopeptide: p = 0.0012, log-ratio +5.7 (an on/off pattern), q = 0.25, rank 17; **the site is not reported**. | The phosphoproteomics does not independently support the STAT5B-S127 mechanism |
| 7 | **STAT5B-S127 read-outs** (Figs 5e–i, S6d images) | Pan-phospho/FLAG ratios: creatine raises WT vs S127A by only 0.17–0.33. The phosphomimetic S127D has the *highest* pan-phospho signal in vehicle (1.05 vs WT 0.72), which is inconsistent with S127 being the site the antibody reads. Molecular weights differ between "duplicate" blots (FLAG band ~78 vs ~95 kDa); bands are saturated and there are blotches; the cell type is not recorded. The kinase assay is n = 1 with no S127A substrate and no kinase-dead CKB. | STAT5B stays a hypothesis-level mechanism |
| 8 | **Missing controls in genetic experiments** | No Stat5b-KO vehicle arm (6e, 6g, S7b). Stat5b "WT" controls have unstated Cre status. Deletion efficiency is unquantified for both lines. | Built into the backup design |
| 9 | **Pseudo-replication** (Figs 1i, 2c, 2j, S4c) | n is 8 microscope fields per group, not animals | Those p-values overstate certainty; supportive only |
| 10 | **Design biases** (conventions) | Allocation and read-out unmasked; no power calculation; sex not analysed; sex confounded with strain | Size of effect probably inflated; CRE-MK-02 fixes all four |
| 11 | **Labels / missing items** | Fig 4d is labelled "Creatinine" (the assay is for creatine). The Fig 1f comparison label is inconsistent. Human coagulation data are absent. Fig 7g donors and recipient strain are not recorded. Fig 1l attrition (18 vs 20) is unexplained. | Audit list (Section 7) |

---

## 4. The in vivo study for the slot: CRE-MK-02

**Question.** In creatine-exposed mice, does blocking GPVI remove the creatine-driven excess of lung metastasis? How does it compare with an approved antiplatelet and with full removal of the pathway (MK Slc6a8 deletion)?

**Population and model.**
- Both sexes in equal numbers, C57BL/6 background: C57BL/6J for arms A–E and H, and Cre-carrying littermates for the genetic anchor (F/G).
- The in-house C57BL/6-syngeneic melanoma lung-metastasis model (Fig 1f) is used because it is the only model with a disease label in the package and it runs on the background of the Pf4-Cre lines (to verify).
- Parental tumour cells, not the shRNA lines.

**Exposure.** Creatine monohydrate 17 mg by gavage three times a week, as in the package. This matches 20 g/day in humans per kg and reproducibly raises serum creatine about 2.7×. The pre-exposure period matches the original protocol. Serum creatine is measured in every animal to confirm exposure.

**Arms (randomised within sex; every batch contains every arm).**

| Priority | Arm | Purpose | n enrolled (analysable) |
|---|---|---|---|
| Core | A. Vehicle + control (isotype or vehicle matched to the GPVI tool) | Baseline | 16 (14: 7F/7M) |
| Core | B. Creatine + control | **Replication gate** (B vs A) | 16 (14) |
| Core | C. Vehicle + GPVI blockade | Does GPVI matter without creatine? (indication breadth) | 16 (14) |
| Core | D. Creatine + GPVI blockade | **Primary test** (D vs B) | 16 (14) |
| Core | E. Creatine + aspirin (30 mg/kg/day, as in the package) | Approved-drug comparator (backup 2) | 16 (14) |
| Add-on 1 (recommended) | F/G. Pf4-Cre;Slc6a8 fl/fl vs Pf4-Cre;Slc6a8 +/+ littermates, both on creatine | Mechanism anchor: "pathway fully removed" benchmark; masked replication of Fig 3i | 12 + 12 (10 + 10) |
| Add-on 2 (optional) | H. Creatine + P2Y12 antagonist | Tests the effector the human ADP data argue against | 16 (14) |
| Add-on 3 (optional) | Satellite: A, B, C, D for 24-h lung tumour-cell retention (the Fig 1h read-out) | Shows whether GPVI acts at early seeding | 4 × 6 |

**GPVI tool.**
- Either an antibody-based GPVI blocking/depleting tool or GPVI-deficient mice; the choice is operational (outside the package).
- Before randomisation, a non-tumour pilot (about 4 per group) must show target engagement. The required result is: the collagen/GPVI-agonist aggregation response is abolished, while ADP and thrombin responses, platelet count and tail bleeding stay within prespecified limits.

**Masking and randomisation.**
- Allocation is concealed by a third party using coded dosing solutions and vials.
- Block randomisation is stratified by sex and batch, and arms are spread across cages.
- Histology scorers and aggregometry operators are masked, and raw traces and images are archived.
- Exclusion criteria (failed injection, deaths unrelated to tumour) and the statistical analysis plan (SAP) are registered before the first injection.

**Endpoints.**

| Type | Endpoint | Purpose |
|---|---|---|
| Primary | Lung metastatic burden (% of lung area with metastases, standardised step sections, masked reader); log-transformed | Outcome |
| Key secondary | Foci count (negative-binomial model) | Outcome |
| Key secondary | Lung weight | Outcome |
| Key secondary | Fraction of the creatine increment removed, on the log scale with bootstrap 95% CI. GPVI: 1 − (D − C)/(B − A), using the full 2×2. E, H and the anchor (no matching vehicle arm): (B − X)/(B − A), which assumes no effect at baseline. | Outcome |
| Key secondary | Both sexes reported separately | Outcome |
| Exposure | Serum creatine | Pharmacodynamics / mechanism |
| Axis engagement | MK creatine (subset) | Pharmacodynamics / mechanism |
| Programme | MK *Gp6*, *P2ry12*, *Adra2a*, *F2r* transcripts (subset) | Pharmacodynamics / mechanism |
| Programme output | Platelet surface GPVI density | Pharmacodynamics / mechanism |
| Platelet function | Ex vivo aggregation to a GPVI agonist, collagen, ADP and thrombin (masked; traces archived) | Pharmacodynamics / mechanism |
| Safety | Platelet count and indices; tail bleeding; body weight | Safety |

**Analysis.**
- Linear model on log burden with arm, sex and batch as terms.
- Fixed-sequence testing controls type-I error in this order:
  1. B vs A (replication gate)
  2. D vs B (GPVI; primary)
  3. E vs B (aspirin)
  4. H vs B (P2Y12)
  5. F vs G (anchor)
- C vs A (baseline effect) and the sex interaction are estimated, not tested for decisions.
- Every effect is reported with its 95% CI.

**Sample size.**
- Inputs from the package: the pooled within-group SD of log burden is 0.43 (vehicle 0.52), and I planned on 0.50. The planning creatine effect is 2.0×, the lower end of the prediction interval, because unmasked estimates are probably inflated.
- Simulation of the full model (3,000 runs per scenario), with n = 14 analysable per arm:
  - about 0.95 power for the replication gate;
  - about 0.91 to pass the gate *and* detect full removal of the effect (D vs B);
  - for only 50% removal, power falls to 0.42 if the true creatine effect is 2× and 0.81 if it is 3×.
- So the study is built to detect a strong, decision-grade effect; partial effects are estimated with CIs and trigger follow-up.
- I allowed about 12% attrition. The core is 80 mice; the recommended total is 104, and up to 144 with all add-ons.
- Two staggered batches fit in one quarter, after a 2–3-week tool pilot.

**Prespecified decision rules.**

| Outcome | Decision |
|---|---|
| B vs A < 1.5× or not significant | **Stop.** The phenotype did not reproduce under masking. Report it and close target work. |
| D vs B significant; ≥50% of the increment removed; GPVI engagement confirmed; same direction in both sexes; no excess bleeding or thrombocytopenia | **Go on GPVI.** Run the human studies (Section 8) and start a tool/lead strategy. |
| D removes 25–50% | GPVI contributes but is not sufficient. Run the STAT5B genetic study next; test GPVI + aspirin. |
| D removes < 25% (upper CI < 50%) while the anchor F vs G removes ≥ 50% | Effector redundancy. **Switch primary to MK STAT5B** (backup 1). |
| E (or H) removes at least as much as D | **Repurposing becomes the lead for patients.** A new GPVI programme would then need a safety-based case for differentiation. |
| C < A (GPVI lowers metastasis without creatine) | Take forward a broader anti-metastatic indication, independent of creatine |

---

## 5. Backups, and what triggers them

**Backup 1: MK STAT5B (the transcriptional hub).**
- *Triggers:*
  - GPVI removes less than 50% of the increment while the Slc6a8 anchor works (the effect is carried by several effectors at once);
  - or the audit shows Fig 6b is authentic and Supp 2d is the mislabelled panel.
- *Study (ready for the following slot; start expanding the colony now):*
  - Pf4-iCre;Stat5b fl/fl vs Pf4-iCre;Stat5b +/+ littermates (Cre matched) × vehicle/creatine. This is the 2×2 design the package lacks, including the KO-vehicle arm.
  - Both sexes, masked, n = 14 analysable per arm, same endpoints as CRE-MK-02.
  - Deletion efficiency documented in sorted MKs.
- *What would elevate it:*
  - site-resolved evidence, from primary MKs exposed to creatine, that the induced STAT5B phosphorylation is S127 (targeted mass spectrometry with FDR control);
  - S127A blocking the programme in MKs;
  - any MK-selective way to modulate STAT5B.
- *What would demote it:* the knockout not protecting (STAT5A compensation is plausible, given residual induction in Fig 6g and a pan-STAT5A/B tool in Figs 6a/6b).

**Backup 2: approved-antiplatelet repurposing (aspirin first).**
- *Triggers:* arm E (or H) removes at least as much of the increment as GPVI.
- *Status:* already inside CRE-MK-02, so it costs no extra slot.
- *Ordering:* aspirin ahead of P2Y12. The human arachidonic-acid response moved a little (1.32×, q = 0.06), while ADP did not move at all.

**Not taken forward.**
- CKB: in vitro only; brain-type creatine kinase.
- SLC6A8 as a drug target, whether tumour or systemic.
- Pan-STAT5 inhibition: it suppresses the basal MK programme in vitro (Fig 6a) and cannot be attributed to STAT5B.

---

## 6. What would elevate one choice over another

| If we learn… | Moves up | Moves down |
|---|---|---|
| GPVI blockade removes ≥ 50% of the creatine increment (CRE-MK-02), *and* the human-platelet transfer effect is GPVI-dependent, *and* a placebo-controlled human study shows a GPVI-specific rise | GPVI (clinical path with a ready-made human biomarker) | — |
| Aspirin or a P2Y12 antagonist ≥ GPVI in CRE-MK-02 | Repurposing (fast and cheap; patient benefit) | A new GPVI programme |
| GPVI partial or null, but the MK-Slc6a8 anchor is complete | STAT5B (hub) | GPVI |
| Audit: Fig 6b authentic / Supp 2d mislabelled | STAT5B (pharmacology evidence restored) | — |
| Audit: Supp 2d authentic / Fig 6b mislabelled | Aspirin and the platelet-transfer evidence | STAT5B |
| Site-resolved STAT5B-S127 phosphorylation in primary MKs; S127A blocks the programme | STAT5B mechanism | — |
| Raw aggregometry does not support the Fig 2b/3d values | — | Every mouse platelet-function argument (GPVI leans on the human data; STAT5B and aspirin lose their functional link) |
| Placebo-controlled human study: no GPVI-specific change | — | Translational case for GPVI |
| GPVI lowers metastasis without creatine (arm C) | GPVI, broader indication | — |
| Masked replication < 1.5× | — | The whole programme (stop) |

---

## 7. Before the slot: no-animal actions (2–4 weeks; gate to randomisation)

1. **Source-data audit of Fig 6b vs Supp 2d.** Check animal IDs, dates, cage cards and histology images, and decide which experiment the six shared animals belong to.
2. **Raw aggregometer traces** for Figs 2b and 3d; confirm the reporting resolution; masked re-read. Obtain the raw day-0 aggregation values for Fig 7c.
3. **Human data corrections.**
   - Reconcile Fig 7d volunteer-4 RAB27B and PITPNB.
   - Re-quantify full-exposure scans for Fig 7e, masked, with the loading control on the same membrane. The conventions state that β-actin was run on separate gels, which makes per-lane normalisation invalid.
   - Provide the coagulation results.
   - Identify the Fig 7g donors (donor, not pooled platelets, should be the unit of analysis).
4. **Phosphoproteomics.** Site localisation and intensities for the Stat5b phosphopeptide; FDR at site level; handling of missing values.
5. **Genetic tool documentation.**
   - Deletion efficiency for Pf4-Cre;Slc6a8 and Pf4-iCre;Stat5b.
   - Cre status of the "WT" controls.
   - Tumour-line shRNA knockdown at protein level and at the level of creatine uptake; resolve the si/sh labelling.
6. **Corrections.** Fig 4d label; Fig 1f contrast label. Record the tumour model and sex behind each figure.
7. **Register the CRE-MK-02 SAP** and run the GPVI-tool target-engagement pilot.

---

## 8. Subsequent studies (after the slot)

| Study | Population | Indication served | Comparators | Primary endpoint | Key read-outs |
|---|---|---|---|---|---|
| **H1. Randomised, double-blind, placebo-controlled human platelet study** | Healthy adults 18–70, both sexes, more than one ancestry (the pilot was 11 Asian adults aged 20–25) | Establishes that the human platelet phenotype is real and GPVI-specific | Placebo; creatine 5 g/day; creatine 20 g/day (parallel groups; 14–28 days, then 4-week washout follow-up) | Change in GPVI-specific aggregation (GPVI agonist/collagen) at day 14 vs placebo. n ≈ 35–40 per arm: 90% power for a 2× change given the pilot SD of 1.17 log2 units; about 85–90 per arm for 1.5×. | GPVI surface density; epinephrine (co-primary biomarker), ADP (specificity control), arachidonic acid; serum and platelet creatine; platelet count and coagulation; reversal after washout |
| **H2. Human-platelet → mouse transfer with ex vivo GPVI blockade** | Donors from H1 (donor as the unit, ≥ 6 per arm; no pooling); randomised recipient mice | Shows that the human-platelet pro-metastatic effect (Fig 7g) needs GPVI | Placebo-donor vs creatine-donor platelets, ± GPVI blockade; aspirin ex vivo as comparator | Lung metastatic burden in recipients | Foci; platelet GPVI occupancy at transfer |
| **M2. Spontaneous-metastasis model** | Both sexes; second background (e.g. BALB/c) | Perioperative/adjuvant prevention of haematogenous seeding | Vehicle, creatine, creatine + GPVI blockade (± aspirin) | Lung metastasis at a fixed time after resection of the primary | Metastasis-free survival; primary-tumour growth (should be unaffected) |
| **M3. Dose–exposure–response and reversibility** | Mice at creatine doses spanning the human serum range | Patient guidance (dose, timing, how long to stop supplements before surgery) | Several creatine doses; washout | Serum/MK creatine vs platelet GPVI and metastasis | Time for platelet priming to reverse after withdrawal |
| **M4. Backup 1 genetic study** | Pf4-iCre;Stat5b (Section 5) | Mechanism / hub target | Cre-matched littermates × vehicle/creatine | Lung metastatic burden | Programme, GPVI, function |
| **S1. Safety of GPVI blockade in tumour-bearing, creatine-exposed mice** | Both sexes | Benefit–risk | Vehicle, GPVI blockade | Bleeding and haemostasis | Platelet count; TEG |

**Indications.**
- **Lead hypothesis:** preventing haematogenous metastatic seeding in patients with solid tumours (melanoma first, matching the model) who take supplemental creatine, either by choice or for muscle or neurological indications. The target window is perioperative/adjuvant, because the mouse effect appears during early seeding (Fig 1h).
- **Broader positioning:** only if GPVI blockade lowers metastasis without creatine (arm C). No node in the package changes baseline metastasis: Slc6a8 KO vehicle arm 3.39% vs 2.37%; STAT5-IN-1 vehicle arm 3.63% vs 3.45%.
- **Non-drug deliverable:** a risk position on creatine supplementation in patients with cancer, to be informed by H1/H2.

---

## Appendix A: How each number was derived

- **Re-computation.** All values were read cell by cell from the workbook (openpyxl). I re-ran every reported test: Student's t-test (equal variance), Welch, Mann–Whitney, one-way ANOVA with Tukey HSD, log-rank, and Cox proportional hazards (lifelines), then compared each against the Prism output in the sheet. All matched to rounding (`analysis/ttests.py`, `anovas.py`).
- **Meta-analysis (3.1).** For each cohort, the log ratio of geometric means and its SE (Welch form) were computed; these were pooled by DerSimonian–Laird random effects, with a prediction interval on k − 2 df (`meta.py`).
- **Node effects (3.2, Fig 2).** The creatine effect within each background was computed as a ratio of geometric means with a t-based CI. The ratio of ratios is the interaction on the log scale, using the pooled within-group variance across the four arms (`nodes.py`).
- **qPCR (3.3).** 2^ΔCt, vehicle normalisation and 2^(ΔCt₂ − ΔCt₁) were recomputed for every replicate in every sheet. Log2 fold change is the mean ΔΔCt per contrast; groups were compared with t-tests on ΔCt, with BH FDR within each contrast (`qpcr.py`).
- **Human cohort (3.3).** Serum creatine was analysed by repeated-measures ANOVA and Friedman. Aggregation was analysed per volunteer: Wilcoxon signed-rank on fold − 1, one-sample t on log2 fold, Friedman across days, and BH FDR over 36 and over 12 tests. CD41⁺ qPCR: per-volunteer mean ΔCt per day, then ΔΔCt vs day 0, a one-sample t-test across the 4 volunteers, and a check of every reported normalised cell against its inputs (`human.py`, `human7c.py`, `human7d.py`, `human7d_check.py`).
- **Blot re-quantification.** This is approximate by design: JPEG images, unknown exposure and possible saturation. For each lane, background-subtracted, inverted intensity was integrated over a band window (per-column median background from the window edges); lane centres were refined from the intensity profile. It is used only to check *direction* against reported values (`densito*.py`).
- **Phosphoproteomics.** p-value histogram; count of entries with p = 1 − 1/√3, which is the two-sided t-test p for t = 1 on 2 df (a single-replicate-detection artefact); Storey π₀; BH recomputation; rank of each Stat5b entry.
- **Forensics.** Exact-value matching of all numeric cells across sheets (≥ 5 significant figures), then matching of runs of consecutive values. The large set of qPCR coincidences (2-decimal ΔCt rounding) is explained by the workbook's own note and excluded. The arithmetic-progression test used a Monte-Carlo null of integer-rounded normal triplets with the observed SDs (`forensic_agg.py`, `runs.py`).
- **Power.** Simulation of the four-arm factorial with a sex term, log-normal burden with SD 0.50, creatine effect 2.0× or 3.0×, and 100% or 50% removal of the effect; 3,000 replicates per cell (`power.py`). Human sample sizes use the observed SD of the day-14 log2 fold in collagen response (1.17) (`humanpower.py`).
- **Dose bridge.** Mouse: 42.5 mg/mL × 0.4 mL × 3 per week, divided by 7 days and by body weight (S1a). Human: 20 g/day ÷ 57.64 kg (conventions).

## Appendix B: Supporting tables (files in `analysis/`)

- `recomputed_tests.txt`: every reported test re-run, with effect sizes (ratio, difference with 95% CI, Hedges g, Welch and Mann–Whitney p).
- `meta_burden.csv`: cohort-level effects for the meta-analysis.
- `node_perturbations.csv`: creatine effects within each perturbation, and the ratios of ratios.
- `qpcr_summary.csv`: all 196 MK qPCR contrasts with fold change, p and FDR.
- `human_platelet_function_paired.txt`, `human_cd41_qpcr.txt`: human re-analyses.
- `phospho_summary.txt`: phosphoproteomics diagnostics.
- `integrity_findings.csv`: the audit table with cell references.
- `forensic_checks.txt`: duplication scan, matching runs of values, and the aggregation-pattern tests.
- `blot_requantification.txt`: approximate densitometry of the embedded blot images (Supp 8d, Supp 2a, Supp 4a).
- `power.txt`: power simulations for CRE-MK-02 and sample-size estimates for H1.
- `timecourse_chip.txt`: Fig 1h time course (per time point, Holm-adjusted) and two-way ANOVAs of the ChIP panels.
