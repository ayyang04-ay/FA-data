# CRE-MK-01 follow-up: outputs

- `CRE-MK-01_validation_proposal.pdf` / `.md`: the proposal for the portfolio committee. The recommendation is on the first line.
- `figures/`
  - `fig1_phenotype_forest.png`: creatine → lung metastatic burden across 10 cohorts, with the random-effects pooled estimate.
  - `fig2_node_perturbations.png`: creatine effect with and without each in vivo perturbation (tumour Slc6a8, MK Slc6a8, STAT5-IN-1, aspirin donors, human platelets).
  - `fig3_gene_program_heatmap.png`: the MK platelet-activation gene programme across all 15 mouse conditions.
  - `fig4_human_platelet_function.png`: human aggregation by agonist, re-analysed as paired data.
  - `fig5_integrity_flags.png`: animals shared between Fig 6b and Supp 2d; the arithmetic-progression pattern in Fig 2b.
  - `fig6_human_blot_requant.png`: reported vs re-quantified GP6 and P2RY12 human immunoblots.
- `analysis/`: every script used, and its outputs.
  - `recomputed_tests.txt`: all reported tests re-run, with effect sizes and CIs.
  - `meta_burden.csv`, `node_perturbations.csv`, `qpcr_summary.csv`: cohort-level and contrast-level tables.
  - `human_platelet_function_paired.txt`, `human_cd41_qpcr.txt`: human re-analyses.
  - `phospho_summary.txt`: phosphoproteomics diagnostics.
  - `forensic_checks.txt`, `integrity_findings.csv`: duplication scan, aggregation pattern tests, audit table.
  - `blot_requantification.txt`: approximate densitometry of the embedded blot images (direction check only).
  - `power.txt`: sample-size simulations for CRE-MK-02 and the human study.
  - `timecourse_chip.txt`: Fig 1h time course and ChIP two-way ANOVAs.

Scripts read the workbook from `/tmp/work/CRE-MK-01_source_data.xlsx`, a copy of `/tmp/world/filesystem/CRE-MK-01_source_data.xlsx`. Change the path in `load.py` to re-run elsewhere. The environments used were `singlecell` (pandas, scipy, statsmodels), `core` (lifelines) and `chem` (openpyxl, PIL, reportlab).
