"""Re-analysis of in vivo metastasis / tumour endpoints (two-group and factorial panels)."""
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
import statsmodels.api as sm
import xl

pd.set_option('display.width', 250)
pd.set_option('display.max_columns', 40)
pd.set_option('display.max_rows', 400)


def hedges_g(a, b):
    a, b = np.asarray(a), np.asarray(b)
    na, nb = len(a), len(b)
    sp = np.sqrt(((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2))
    d = (b.mean() - a.mean()) / sp
    J = 1 - 3 / (4 * (na + nb) - 9)
    return d * J


def ratio_ci(a, b):
    """ratio of geometric means b/a with 95% CI on log scale (Welch)."""
    la, lb = np.log(a), np.log(b)
    diff = lb.mean() - la.mean()
    va, vb = la.var(ddof=1) / len(la), lb.var(ddof=1) / len(lb)
    se = np.sqrt(va + vb)
    dfw = (va + vb) ** 2 / (va ** 2 / (len(la) - 1) + vb ** 2 / (len(lb) - 1))
    tq = stats.t.ppf(0.975, dfw)
    return np.exp(diff), np.exp(diff - tq * se), np.exp(diff + tq * se)


def two_group(panel, endpoint, a, b, reported_p=None, reported_t=None, unit='mouse', ctx=''):
    a, b = np.asarray(a, float), np.asarray(b, float)
    t_s = stats.ttest_ind(b, a)
    t_w = stats.ttest_ind(b, a, equal_var=False)
    mw = stats.mannwhitneyu(b, a, alternative='two-sided')
    r = dict(panel=panel, context=ctx, endpoint=endpoint, unit_of_n=unit, n_ctrl=len(a), n_trt=len(b),
             mean_ctrl=a.mean(), sd_ctrl=a.std(ddof=1), mean_trt=b.mean(), sd_trt=b.std(ddof=1),
             ratio_means=b.mean() / a.mean(), hedges_g=hedges_g(a, b),
             t_student=t_s.statistic, p_student=t_s.pvalue, p_welch=t_w.pvalue, p_mannwhitney=mw.pvalue,
             reported_t=reported_t, reported_p=reported_p)
    if (a > 0).all() and (b > 0).all():
        gm, lo, hi = ratio_ci(a, b)
        r.update(geo_ratio=gm, geo_ratio_lo=lo, geo_ratio_hi=hi,
                 p_log_welch=stats.ttest_ind(np.log(b), np.log(a), equal_var=False).pvalue)
    return r


def reported(sheet, label='P value'):
    """Collect reported P values and t strings in a sheet in order."""
    w = xl.ws(sheet)
    ps, ts = [], []
    for row in w.iter_rows():
        for c in row:
            if c.value == 'P value':
                ps.append(w.cell(row=c.row, column=c.column + 1).value)
            if c.value == 't, df':
                ts.append(w.cell(row=c.row, column=c.column + 1).value)
    return ps, ts


rows = []
# ---------- simple two-group in vivo panels ----------
simple = [
    ('Fig. 1a', ['Lung weight', 'SUV'], 'primary model, creatine gavage'),
    ('Fig. 1b', ['Metastatic burden', 'The number of metastatic foci'], 'primary model, creatine gavage'),
    ('Fig. 1i', ['The number of GFP+'], 'lung GFP+ tumour cells'),
    ('Fig. 1j', ['Lung weight', 'SUV'], 'second model'),
    ('Fig. 1k', ['Metastatic burden', 'The number of metastatic foci'], 'second model'),
    ('Fig. 7g', ['Lung weight', 'Metastatic burden', 'The number of metastatic foci'], 'human d0 vs d7 donor platelets -> mice'),
    ('Supplementary Fig  1e', ['Lung weight', 'Metastatic burden', 'The number of metastatic foci'], 'supp model 1e'),
    ('Supplementary Fig  1f', ['Lung weight', 'Metastatic burden', 'The number of metastatic foci'], 'supp model 1f'),
    ('Supplementary Fig  1g', ['Lung weight', 'Metastatic burden', 'The number of metastatic foci'], 'supp model 1g'),
    ('Supplementary Fig  1i', ['Lung weight', 'Metastatic burden', 'The number of metastatic foci'], 'creatine diet 5% w/w'),
    ('Supplementary Fig  1k', ['Lung weight', 'Metastatic burden', 'The number of metastatic foci'], 'supp model 1k'),
]
for sheet, labels, ctx in simple:
    ps, ts = reported(sheet)
    for i, lab in enumerate(labels):
        hc = xl.find(sheet, lab)[0]
        d = xl.block(sheet, hc, 2)
        k = list(d.keys())
        unit = 'field (8 random fields/group)' if sheet == 'Fig. 1i' else 'mouse'
        rows.append(two_group(sheet, lab, d[k[0]], d[k[1]], ps[i] if i < len(ps) else None,
                              ts[i] if i < len(ts) else None, unit, ctx))

# ---------- Fig 1h time course (tumour-cell signal in lung) ----------
w = 'Fig. 1h'
ps, ts = reported(w)
for j, r in enumerate(range(4, 8)):
    vals = xl.rows(w, f'A{r}:M{r}')[0]
    tpt, veh, cre = vals[0], vals[1:7], vals[7:13]
    rows.append(two_group(w, f'lung tumour-cell signal {tpt} h', veh, cre, ps[j], ts[j], 'mouse', 'early seeding'))

inv = pd.DataFrame(rows)
inv['p_match'] = np.where(inv.reported_p.notna(), np.isclose(inv.p_student, inv.reported_p.astype(float), rtol=0.06, atol=5e-5), np.nan)

# ---------- factorial panels: interaction tests ----------
fact_rows = []


def factorial(sheet, label, names, fa_name, fb_name, levels):
    """levels: list of (A,B) for each column."""
    hc = xl.find(sheet, label)[0]
    d = xl.block(sheet, hc, 4)
    recs = []
    for (k, v), (la, lb) in zip(d.items(), levels):
        for x in v:
            recs.append(dict(y=x, A=la, B=lb))
    df = pd.DataFrame(recs)
    out = dict(panel=sheet, endpoint=label, factorA=fa_name, factorB=fb_name)
    for scale in ['raw', 'log']:
        dd = df.copy()
        if scale == 'log':
            if (dd.y <= 0).any():
                continue
            dd['y'] = np.log(dd.y)
        m = smf.ols('y ~ C(A) * C(B)', data=dd).fit()
        an = sm.stats.anova_lm(m, typ=2)
        key = [i for i in an.index if ':' in i][0]
        out[f'p_interaction_{scale}'] = an.loc[key, 'PR(>F)']
    # creatine effect within each level of factor B
    for lb in df.B.unique():
        a = df[(df.B == lb) & (df.A == 'vehicle')].y.values
        b = df[(df.B == lb) & (df.A == 'creatine')].y.values
        out[f'ratio_cre_vs_veh[{lb}]'] = b.mean() / a.mean()
        out[f'diff_cre_minus_veh[{lb}]'] = b.mean() - a.mean()
        out[f'n[{lb}]'] = f'{len(a)}/{len(b)}'
    return out


# Fig 1f: tumour-intrinsic Slc6a8 knockdown
for lab in ['Lung weight', 'SUV', 'Metastatic burden', 'The number of metastatic foci']:
    fact_rows.append(factorial('Fig. 1f', lab, None, 'creatine', 'tumour shRNA',
                               [('vehicle', 'sh-scr'), ('creatine', 'sh-scr'), ('vehicle', 'sh-Slc6a8'), ('creatine', 'sh-Slc6a8')]))
# Fig 3i: MK Slc6a8 deletion
for lab in ['Lung weight', 'Metastatic burden', 'The number of metastatic foci']:
    fact_rows.append(factorial('Fig. 3i', lab, None, 'creatine', 'genotype',
                               [('vehicle', 'Slc6a8+/+'), ('creatine', 'Slc6a8+/+'), ('vehicle', 'Slc6a8fl/fl'), ('creatine', 'Slc6a8fl/fl')]))
# Fig 6b: STAT5 inhibitor
for lab in ['Metastatic burden', 'The number of metastatic foci']:
    fact_rows.append(factorial('Fig. 6b', lab, None, 'creatine', 'STAT5-IN-1',
                               [('vehicle', 'DMSO'), ('creatine', 'DMSO'), ('vehicle', 'STAT5i'), ('creatine', 'STAT5i')]))
fact = pd.DataFrame(fact_rows)

# Tukey-reported values and within-level t-tests for factorial panels
within = []
for sheet, labels, levels in [
    ('Fig. 1f', ['Lung weight', 'SUV', 'Metastatic burden', 'The number of metastatic foci'], ['sh-scr', 'sh-Slc6a8']),
    ('Fig. 3i', ['Lung weight', 'Metastatic burden', 'The number of metastatic foci'], ['Slc6a8+/+', 'Slc6a8fl/fl']),
    ('Fig. 6b', ['Metastatic burden', 'The number of metastatic foci'], ['DMSO', 'STAT5i'])]:
    for lab in labels:
        hc = xl.find(sheet, lab)[0]
        d = xl.block(sheet, hc, 4)
        v = list(d.values())
        within.append(two_group(sheet, lab + f' [{levels[0]}]', v[0], v[1], None, None, 'mouse', levels[0]))
        within.append(two_group(sheet, lab + f' [{levels[1]}]', v[2], v[3], None, None, 'mouse', levels[1]))
within = pd.DataFrame(within)

# Supp Fig 2d: platelet transfer +/- aspirin (3 groups)
sd = []
for lab in ['Metastatic burden', 'The number of metastatic foci']:
    hc = xl.find('Supplementary Fig  2d', lab)[0]
    d = xl.block('Supplementary Fig  2d', hc, 3)
    v = list(d.values())
    sd.append(two_group('Supplementary Fig  2d', lab + ' [creatine donor vs vehicle donor PLT]', v[0], v[1]))
    sd.append(two_group('Supplementary Fig  2d', lab + ' [creatine+aspirin donor vs creatine donor PLT]', v[1], v[2]))
    sd.append(two_group('Supplementary Fig  2d', lab + ' [creatine+aspirin donor vs vehicle donor PLT]', v[0], v[2]))
sd = pd.DataFrame(sd)

if __name__ == '__main__':
    cols_show = ['panel', 'endpoint', 'unit_of_n', 'n_ctrl', 'n_trt', 'mean_ctrl', 'mean_trt', 'ratio_means', 'geo_ratio',
                 'geo_ratio_lo', 'geo_ratio_hi', 'hedges_g', 'p_student', 'reported_p', 'p_match', 'p_welch', 'p_mannwhitney']
    print(inv[cols_show].to_string())
    print()
    print(fact.to_string())
    print()
    print(within[['panel', 'endpoint', 'n_ctrl', 'n_trt', 'mean_ctrl', 'mean_trt', 'ratio_means', 'hedges_g', 'p_student', 'p_welch', 'p_mannwhitney']].to_string())
    print()
    print(sd[['panel', 'endpoint', 'n_ctrl', 'n_trt', 'mean_ctrl', 'mean_trt', 'ratio_means', 'hedges_g', 'p_student', 'p_welch', 'p_mannwhitney']].to_string())
    inv.to_csv(xl.OUT + 'out_invivo_twogroup.csv', index=False)
    fact.to_csv(xl.OUT + 'out_invivo_interaction.csv', index=False)
    within.to_csv(xl.OUT + 'out_invivo_within.csv', index=False)
    sd.to_csv(xl.OUT + 'out_supp2d.csv', index=False)
