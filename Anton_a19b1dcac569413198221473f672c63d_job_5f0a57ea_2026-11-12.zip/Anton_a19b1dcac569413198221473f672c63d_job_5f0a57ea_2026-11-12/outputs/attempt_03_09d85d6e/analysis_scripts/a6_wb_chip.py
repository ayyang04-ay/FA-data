"""STAT5B mutant phospho-quantification (Fig 5e/5f) and ChIP (Fig 5j, Supp 6i)."""
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
import statsmodels.api as sm
import xl

pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
res = []
for sheet in ['Fig. 5e', 'Fig. 5f']:
    hv = xl.find(sheet, 'Vehicle-WT')[0]
    hc = xl.find(sheet, 'Creatine-WT')[0]
    dv = xl.block(sheet, hv, 4, start_col_offset=0)
    dc = xl.block(sheet, hc, 4, start_col_offset=0)
    # block() reads header row names starting at header cell; adjust: header cell is the first group name
    recs = []
    for d, trt in [(dv, 'vehicle'), (dc, 'creatine')]:
        for k, v in d.items():
            mut = k.split('-', 1)[1]
            for x in v:
                recs.append(dict(y=x, trt=trt, mut=mut))
    df = pd.DataFrame(recs)
    print(sheet, df.groupby(['trt', 'mut']).y.agg(['mean', 'std', 'count']).round(3).to_string())
    # creatine effect per mutant (t-test)
    for mut in ['WT', 'S127A', '3A', 'S127D']:
        a = df[(df.trt == 'vehicle') & (df.mut == mut)].y
        b = df[(df.trt == 'creatine') & (df.mut == mut)].y
        t = stats.ttest_ind(b, a)
        res.append(dict(panel=sheet, contrast=f'creatine vs vehicle within {mut}', diff=b.mean() - a.mean(), ratio=b.mean() / a.mean(), p=t.pvalue))
    # interaction WT vs S127A, WT vs 3A
    for mut in ['S127A', '3A', 'S127D']:
        d2 = df[df.mut.isin(['WT', mut])]
        m = smf.ols('y ~ C(trt)*C(mut)', d2).fit()
        an = sm.stats.anova_lm(m, typ=2)
        res.append(dict(panel=sheet, contrast=f'interaction creatine x (WT vs {mut})', diff=np.nan, ratio=np.nan, p=an.loc['C(trt):C(mut)', 'PR(>F)']))
    m = smf.ols('y ~ C(trt)*C(mut)', df).fit()
    an = sm.stats.anova_lm(m, typ=2)
    res.append(dict(panel=sheet, contrast='global interaction creatine x mutant (4 levels)', diff=np.nan, ratio=np.nan, p=an.loc['C(trt):C(mut)', 'PR(>F)']))
wb = pd.DataFrame(res)
print(wb.round(4).to_string())
wb.to_csv(xl.OUT + 'out_stat5b_mutants.csv', index=False)

# ---------------- ChIP ----------------
chip = []
grid = []
for sheet, lab in [('Fig. 5j', 'Input (%) of P2ry12'), ('Fig. 5j', 'Input (%) of Gp6'), ('Supplementary Fig  6i', 'Input of Rab4a')]:
    hc = xl.find(sheet, lab)[0]
    from openpyxl.utils.cell import coordinate_from_string, column_index_from_string
    cl, r0 = coordinate_from_string(hc)
    c0 = column_index_from_string(cl)
    w = xl.ws(sheet)
    # in Fig 5j the label is in col A and region names in col A rows below; in Supp 6i label in col B, region names in col B
    recs = []
    for r in range(r0 + 1, r0 + 5):
        region = w.cell(row=r, column=c0).value
        vals = [w.cell(row=r, column=c0 + k).value for k in range(1, 7)]
        vals = [float(v) for v in vals]
        for i, v in enumerate(vals):
            recs.append(dict(region=region, trt='vehicle' if i < 3 else 'creatine', y=v))
            grid.append(dict(sheet=sheet, locus=lab, region=region, value=v, log2_frac=np.log2(v / 100)))
    df = pd.DataFrame(recs)
    for reg in df.region.unique():
        a = df[(df.region == reg) & (df.trt == 'vehicle')].y
        b = df[(df.region == reg) & (df.trt == 'creatine')].y
        chip.append(dict(panel=sheet, locus=lab, region=reg, mean_veh=a.mean(), mean_cre=b.mean(), ratio=b.mean() / a.mean(),
                         p_t=stats.ttest_ind(b, a).pvalue, p_welch=stats.ttest_ind(b, a, equal_var=False).pvalue))
    # region x treatment interaction (promoter vs exon specificity) on log scale
    df['ly'] = np.log(df.y)
    for reg in [r for r in df.region.unique() if r != 'Exon']:
        d2 = df[df.region.isin(['Exon', reg])]
        m = smf.ols('ly ~ C(trt)*C(region)', d2).fit()
        an = sm.stats.anova_lm(m, typ=2)
        chip.append(dict(panel=sheet, locus=lab, region=f'{reg} vs Exon (interaction, log)', mean_veh=np.nan, mean_cre=np.nan, ratio=np.nan,
                         p_t=an.loc['C(trt):C(region)', 'PR(>F)'], p_welch=np.nan))
chip = pd.DataFrame(chip)
print(chip.round(4).to_string())
chip.to_csv(xl.OUT + 'out_chip.csv', index=False)
grid = pd.DataFrame(grid)
# are log2 fractions on a 0.005 grid (two-decimal Ct with averaging)?
for step in [0.01, 0.005, 0.0025]:
    on = np.isclose((grid.log2_frac / step).round() * step, grid.log2_frac, atol=2e-5)
    print('ChIP log2(%input/100) on grid step', step, ':', on.sum(), 'of', len(grid))
grid.to_csv(xl.OUT + 'out_chip_values.csv', index=False)
