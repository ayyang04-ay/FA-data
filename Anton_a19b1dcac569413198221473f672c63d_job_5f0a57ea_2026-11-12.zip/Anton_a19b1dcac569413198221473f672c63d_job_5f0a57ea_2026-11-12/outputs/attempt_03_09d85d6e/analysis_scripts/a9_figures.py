import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker
from matplotlib.patches import Patch
import xl
import os

OUT = os.environ.get('CRE_FIG_DIR', xl.OUT + 'figures')
import os
os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({'font.size': 9, 'font.family': 'DejaVu Sans', 'axes.spines.top': False, 'axes.spines.right': False})

# ---------- Figure 1: forest plot of creatine effect ----------
meta = pd.read_csv(xl.OUT + 'out_meta_creatine_effect.csv')
label_map = {
    'Fig. 1b': 'Fig 1b  model A, gavage (6/6)',
    'Fig. 1f': 'Fig 1f  melanoma sh-scr, gavage (6/6)',
    'Fig. 1k': 'Fig 1k  model B, gavage (6/6)',
    'Fig. 3i': 'Fig 3i  Pf4-Cre;Slc6a8+/+ (4/4)',
    'Fig. 6b': 'Fig 6b  DMSO arms (5/5)',
    'Supplementary Fig  1e': 'Supp 1e (6/6)',
    'Supplementary Fig  1f': 'Supp 1f (4/4)',
    'Supplementary Fig  1g': 'Supp 1g (10/10)',
    'Supplementary Fig  1i': 'Supp 1i  5% creatine diet (4/4)',
    'Supplementary Fig  1k': 'Supp 1k (10/10)',
    'Supplementary Fig  2d': 'Supp 2d  donor-platelet transfer (6/6)',
    'Fig. 7g': 'Fig 7g  human d7 vs d0 platelets -> mice (5/5)',
}
meta['lab'] = meta.panel.map(label_map)
from scipy import stats
fig, ax = plt.subplots(figsize=(7.6, 5.0))
y = np.arange(len(meta))[::-1]
for yi, (_, r) in zip(y, meta.iterrows()):
    dfree = r.n_veh + r.n_cre - 2
    q = stats.t.ppf(0.975, dfree)
    lo, hi = np.exp(r.log_ratio - q * r.se), np.exp(r.log_ratio + q * r.se)
    col = '#c0392b' if isinstance(r.flag, str) and r.flag else ('#2c7fb8' if r.panel != 'Fig. 7g' else '#41ab5d')
    ax.plot([lo, hi], [yi, yi], color=col, lw=1.6)
    ax.plot(r.ratio, yi, 'o', color=col, ms=5)
clean = meta[(meta.flag.isna() | (meta.flag == '')) & (meta.panel != 'Fig. 7g')]
w = 1 / clean.se ** 2
pooled = (w * clean.log_ratio).sum() / w.sum(); pse = np.sqrt(1 / w.sum())
ax.axvline(1, color='grey', lw=0.8, ls=':')
ax.axvline(np.exp(pooled), color='#2c7fb8', lw=0.8, ls='--')
ax.set_yticks(y); ax.set_yticklabels(meta.lab)
ax.set_xscale('log'); ax.set_xticks([1, 2, 3, 5, 8]); ax.set_xticklabels(['1', '2', '3', '5', '8']); ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter()); ax.set_xlim(0.8, 12)
ax.set_xlabel('Creatine / vehicle ratio, metastatic burden (geometric means, 95% CI)')
ax.set_title(f'Creatine increases lung metastatic burden in every experiment\npooled (9 clean mouse experiments) = {np.exp(pooled):.2f}x '
             f'(95% CI {np.exp(pooled - 1.96 * pse):.2f}-{np.exp(pooled + 1.96 * pse):.2f})', fontsize=9)
ax.legend(handles=[Patch(color='#2c7fb8', label='mouse, no integrity flag'), Patch(color='#c0392b', label='shares 6 animals with the other red panel'),
                   Patch(color='#41ab5d', label='human donor platelets')], loc='upper center', bbox_to_anchor=(0.35, -0.13), ncol=3, fontsize=7, frameon=False)
plt.tight_layout(); plt.savefig(f'{OUT}/fig1_forest_creatine_effect.png', dpi=200); plt.close()

# ---------- Figure 2: node blockade ----------
bl = pd.read_csv(xl.OUT + 'out_qpcr_blockade_by_gene.csv')
inv = pd.read_csv(xl.OUT + 'out_invivo_interaction.csv')
order = ['Fig. 3f', 'Fig. 6g', 'Fig.6a', 'Fig. 4j']
names = {'Fig. 3f': 'MK Slc6a8 deletion\n(in vivo, Fig 3f)', 'Fig. 6g': 'MK Stat5b deletion\n(in vivo, Fig 6g;\nno KO-vehicle arm)',
         'Fig.6a': 'STAT5-IN-1\n(in vitro, Fig 6a)', 'Fig. 4j': 'si-Ckb\n(in vitro, Fig 4j)'}
fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.6), gridspec_kw={'width_ratios': [1.5, 1]})
ax = axes[0]
for i, p in enumerate(order):
    d = bl[bl.panel == p]
    vals = d.pct_of_response_remaining.clip(-100, 150)
    jitter = np.random.default_rng(1).uniform(-0.15, 0.15, len(vals))
    hl = d.gene.isin(['Gp6', 'P2ry12', 'Adra2a'])
    ax.scatter(np.full(len(vals), i) + jitter, vals, s=14, color=np.where(hl, '#d95f0e', '#636363'), zorder=3)
    ax.plot([i - 0.25, i + 0.25], [np.median(d.pct_of_response_remaining)] * 2, color='k', lw=2)
    for g, v, jj in zip(d.gene, vals, jitter):
        if g == 'Gp6':
            ax.annotate(g, (i + jj, v), fontsize=6, xytext=(4, -2), textcoords='offset points', color='#d95f0e')
ax.axhline(0, color='grey', lw=0.8, ls=':'); ax.axhline(100, color='grey', lw=0.8, ls=':')
ax.set_xticks(range(len(order))); ax.set_xticklabels([names[p] for p in order], fontsize=7)
ax.set_ylabel('% of creatine transcriptional response\nremaining after perturbation (log2 scale)')
ax.set_title('Transcriptional program (11 genes; bar = median;\norange = Gp6, P2ry12, Adra2a)', fontsize=8.5)
ax = axes[1]
rows = []
for p, lab in [('Fig. 3i', 'Slc6a8 MK-KO\n(Fig 3i, n=4/cell)'), ('Fig. 6b', 'STAT5-IN-1\n(Fig 6b, n=5/cell)\nDUPLICATION FLAG')]:
    r = inv[(inv.panel == p) & (inv.endpoint == 'Metastatic burden')].iloc[0]
    k_int = [c for c in inv.columns if c.startswith('ratio_cre_vs_veh[') and not pd.isna(r[c])]
    rows.append((lab, r[k_int[0]], r[k_int[1]], r['p_interaction_log']))
x = np.arange(len(rows))
ax.bar(x - 0.18, [r[1] for r in rows], 0.36, color='#2c7fb8', label='creatine effect, intact')
ax.bar(x + 0.18, [r[2] for r in rows], 0.36, color='#9ecae1', label='creatine effect, perturbed')
for xi, r in zip(x, rows):
    ax.text(xi, max(r[1], r[2]) + 0.15, f'interaction p={r[3]:.1g}', ha='center', fontsize=7)
ax.axhline(1, color='grey', lw=0.8, ls=':')
ax.set_xticks(x); ax.set_xticklabels([r[0] for r in rows], fontsize=7)
ax.set_ylabel('Creatine / vehicle ratio, metastatic burden')
ax.set_ylim(0, 5.8)
ax.legend(fontsize=7, frameon=False, loc='upper left')
ax.set_title('Metastasis endpoint', fontsize=9)
plt.tight_layout(); plt.savefig(f'{OUT}/fig2_node_blockade.png', dpi=200); plt.close()

# ---------- Figure 3: human platelet function heatmap ----------
pf = pd.read_csv(xl.OUT + 'out_human_platelet_function.csv')
pf['row'] = pf.agonist + ' - ' + pf.metric.str.replace(' rate', '')
rows_order = [f'{a} - {m}' for a in ['collagen', 'EPI', 'AA', 'ADP'] for m in ['maximum aggregation', 'average aggregation', 'platelet adhesion']]
mat = pf.pivot_table(index='row', columns='day', values='geomean_FC').loc[rows_order]
qm = pf.pivot_table(index='row', columns='day', values='q_BH_all36').loc[rows_order]
nup = pf.pivot_table(index='row', columns='day', values='n_up').loc[rows_order]
fig, ax = plt.subplots(figsize=(5.6, 4.6))
im = ax.imshow(np.log2(mat.values), cmap='RdBu_r', vmin=-1.6, vmax=1.6, aspect='auto')
for i in range(mat.shape[0]):
    for j in range(mat.shape[1]):
        star = '*' if qm.values[i, j] < 0.05 else ''
        ax.text(j, i, f'{mat.values[i, j]:.2f}{star}\n{int(nup.values[i, j])}/11 up', ha='center', va='center', fontsize=6.5)
ax.set_xticks(range(3)); ax.set_xticklabels(['day 3', 'day 7', 'day 14'])
ax.set_yticks(range(len(rows_order))); ax.set_yticklabels(rows_order, fontsize=7)
cb = plt.colorbar(im, ax=ax, fraction=0.04); cb.set_label('log2 fold change vs own day 0 (geometric mean)')
ax.set_title('Human platelets, 20 g/day creatine (n=11; paired, log-scale)\n* BH q<0.05 across all 36 tests', fontsize=9)
plt.tight_layout(); plt.savefig(f'{OUT}/fig3_human_platelet_function.png', dpi=200); plt.close()

# ---------- Figure 4: human GP6/P2RY12 protein and CD41+ transcripts ----------
fig, axes = plt.subplots(1, 3, figsize=(9.2, 3.0))
for ax, lab in zip(axes[:2], ['GP6/β-ACTIN', 'P2RY12/β-ACTIN']):
    hc = xl.find('Fig. 7e', lab)[0]
    d = xl.block('Fig. 7e', hc, 4)
    m = np.array(list(d.values()), float).T
    for i in range(m.shape[0]):
        ax.plot([0, 3, 7, 14], m[i], '-o', ms=3, lw=1, color='#525252')
    ax.set_xticks([0, 3, 7, 14]); ax.set_xlabel('day of creatine'); ax.set_ylabel(lab.replace('/β-ACTIN', ' / β-actin (densitometry)'))
    ax.set_title(f'{lab.split("/")[0]} protein, platelets (Fig 7e, n=4)', fontsize=8)
hq = pd.read_csv(xl.OUT + 'out_human_qpcr.csv')
d7 = hq[hq.day == 7].copy()
d7['gene'] = d7.gene.replace({'ADAR2A': 'ADRA2A*'})
d7 = d7.sort_values('geomean_FC_excl')
ax = axes[2]
ax.barh(d7.gene, np.log2(d7.geomean_FC_excl), color=['#d95f0e' if g in ('GP6', 'ADRA2A*', 'P2RY12') else '#969696' for g in d7.gene])
ax.axvline(0, color='k', lw=0.6)
ax.set_xlabel('log2 FC, day 7 vs day 0 (n=4)')
ax.set_title('CD41+ cell transcripts (Fig 7d)', fontsize=8)
ax.tick_params(axis='y', labelsize=7)
plt.tight_layout(); plt.savefig(f'{OUT}/fig4_human_molecular.png', dpi=200); plt.close()

# ---------- Figure 5: phosphoproteomics diagnostics ----------
ph = pd.read_excel(xl.PHOSPHO)
ph.columns = ['gene', 'p', 'q', 'lfc']
art = np.isclose(ph.p, 0.42265, atol=1e-5)
fig, axes = plt.subplots(1, 2, figsize=(8.4, 3.2))
ax = axes[0]
ax.hist(ph.p[~art], bins=20, range=(0, 1), color='#6baed6', label=f'quantified in >1 sample (n={int((~art).sum())})')
ax.hist(ph.p[art], bins=20, range=(0, 1), color='#fb6a4a', alpha=0.8, label=f'p = 0.42265 exactly (n={int(art.sum())}):\nWelch t=1, df=2 => single-sample detection')
ax.axhline((~art).sum() / 20, color='k', ls=':', lw=0.8)
ax.set_xlabel('nominal p-value'); ax.set_ylabel('phosphopeptides'); ax.legend(fontsize=6.5, frameon=False)
ax.set_title('p-value distribution (dotted = uniform expectation)', fontsize=8)
ax = axes[1]
ax.scatter(ph.lfc[~art], -np.log10(ph.p[~art]), s=3, color='#9ecae1')
ax.scatter(ph.lfc[art], -np.log10(ph.p[art]), s=3, color='#fcbba1')
s = ph[(ph.gene == 'Stat5b')]
ax.scatter(s.lfc, -np.log10(s.p), s=30, color='#d95f0e', zorder=4)
for _, r in s.iterrows():
    if r.p < 0.01:
        ax.annotate(f'Stat5b  p={r.p:.4f}\nreported q={r.q:.2f} (BH 0.27-0.37)', (r.lfc, -np.log10(r.p)), xytext=(-120, 10), textcoords='offset points', fontsize=7,
                    arrowprops=dict(arrowstyle='-', lw=0.6))
ax.axhline(-np.log10(0.05), color='grey', ls=':', lw=0.8)
ax.set_xlabel('log2 fold change (creatine / vehicle)'); ax.set_ylabel('-log10 p')
ax.set_title('No phosphopeptide reaches q<0.05 (min reported q = 0.17)', fontsize=8)
plt.tight_layout(); plt.savefig(f'{OUT}/fig5_phosphoproteomics.png', dpi=200); plt.close()

# ---------- Figure 6: duplication between Fig 6b and Supp 2d ----------
b6 = list(xl.block('Fig. 6b', xl.find('Fig. 6b', 'Metastatic burden')[0], 4).values())
s2 = list(xl.block('Supplementary Fig  2d', xl.find('Supplementary Fig  2d', 'Metastatic burden')[0], 3).values())
f6 = list(xl.block('Fig. 6b', xl.find('Fig. 6b', 'The number of metastatic foci')[0], 4).values())
f2 = list(xl.block('Supplementary Fig  2d', xl.find('Supplementary Fig  2d', 'The number of metastatic foci')[0], 3).values())
fig, ax = plt.subplots(figsize=(7.6, 2.9))
ax.axis('off')
cells = []
for grp, a, b, fa, fb in [('Vehicle', b6[0], s2[0], f6[0], f2[0]), ('Creatine', b6[1], s2[1], f6[1], f2[1])]:
    cells.append([f'Fig 6b {grp}: burden'] + [f'{v:.4f}' for v in a] + [''])
    cells.append([f'Supp 2d {grp} donor PLT: burden'] + [f'{v:.4f}' for v in b])
    cells.append([f'Fig 6b {grp}: foci'] + [f'{int(v)}' for v in fa] + [''])
    cells.append([f'Supp 2d {grp} donor PLT: foci'] + [f'{int(v)}' for v in fb])
tab = ax.table(cellText=cells, colLabels=['panel / arm', 'm1', 'm2', 'm3', 'm4', 'm5', 'm6'], loc='center', cellLoc='center')
tab.auto_set_font_size(False); tab.set_fontsize(7); tab.scale(1, 1.15)
for (r, c), cell in tab.get_celld().items():
    if r == 0:
        cell.set_text_props(weight='bold')
    if c == 0:
        cell.set_width(0.32)
    if r >= 1:
        lab = cells[r - 1][0]
        if lab.startswith('Fig 6b') and c in (2, 3, 4):
            cell.set_facecolor('#fcbba1')
        if lab.startswith('Supp 2d') and c in (4, 5, 6):
            cell.set_facecolor('#fcbba1')
ax.set_title('Six animals (3 vehicle + 3 creatine; burden and foci, same order) appear in two different experiments', fontsize=8.5)
plt.tight_layout(); plt.savefig(f'{OUT}/fig6_duplication_6b_vs_S2d.png', dpi=200); plt.close()
print('figures written')
