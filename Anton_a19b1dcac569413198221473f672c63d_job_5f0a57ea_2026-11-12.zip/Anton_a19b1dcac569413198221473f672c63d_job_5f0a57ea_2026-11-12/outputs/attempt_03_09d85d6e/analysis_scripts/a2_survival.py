import numpy as np, pandas as pd
from statsmodels.duration.survfunc import survdiff, SurvfuncRight
import statsmodels.api as sm
import xl

out = []
for sheet in ['Fig. 1c', 'Fig. 1l']:
    w = xl.ws(sheet)
    t, g = [], []
    for r in range(2, 60):
        a = w.cell(row=r, column=1).value
        b = w.cell(row=r, column=2).value
        c = w.cell(row=r, column=3).value
        if isinstance(a, (int, float)):
            t.append(a); g.append('vehicle' if b == 1 else 'creatine')
    t = np.array(t, float); g = np.array(g)
    ev = np.ones_like(t)  # no censoring column provided: all deaths
    stat, p = survdiff(t, ev, g)
    med = {k: np.median(t[g == k]) for k in ['vehicle', 'creatine']}
    # Cox PH
    X = (g == 'creatine').astype(float)
    m = sm.PHReg(t, X[:, None], status=ev).fit()
    hr = np.exp(m.params[0]); ci = np.exp(m.conf_int()[0])
    # reported
    rep = {}
    for row in w.iter_rows():
        for c in row:
            if c.value in ('Chi square', 'P value'):
                rep[c.value] = w.cell(row=c.row, column=c.column + 1).value
    out.append(dict(panel=sheet, n_vehicle=(g == 'vehicle').sum(), n_creatine=(g == 'creatine').sum(),
                    median_vehicle=med['vehicle'], median_creatine=med['creatine'],
                    logrank_chi2=stat, logrank_p=p, reported_chi2=rep.get('Chi square'), reported_p=rep.get('P value'),
                    cox_HR_creatine=hr, HR_lo=ci[0], HR_hi=ci[1], censoring='none recorded (all events)'))
df = pd.DataFrame(out)
pd.set_option('display.width', 250)
print(df.to_string())
df.to_csv(xl.OUT + 'out_survival.csv', index=False)
