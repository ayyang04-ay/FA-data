"""Node-by-node blockade of the creatine transcriptional response (2x2 designs on the dCT scale)."""
import xl
import numpy as np, pandas as pd
import statsmodels.formula.api as smf
import statsmodels.api as sm
from a4_qpcr import raw

pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)

designs = {
    # sheet: (ctrl_label_group, {group_header: (creatine?, perturbed?)})
    'Fig. 3f': {'CTRL': (0, 0), 'PF4 cre; Slc6a8+/+-creatine': (1, 0), 'PF4 cre; Slc6a8flox/flox-vehicle': (0, 1), 'PF4 cre; Slc6a8flox/flox-creatine': (1, 1)},
    'Fig. 4j': {'CTRL': (0, 0), 'Creatine+si-scrambled': (1, 0), 'Control+si-Ckb': (0, 1), 'Creatine+si-Ckb': (1, 1)},
    'Fig.6a': {'CTRL': (0, 0), 'Creatine': (1, 0), 'Vehicle+stat5 inhibitor': (0, 1), 'Creatine+stat5 inhibitor': (1, 1)},
}
node = {'Fig. 3f': 'MK Slc6a8 deletion (in vivo)', 'Fig. 4j': 'si-Ckb (in vitro MKs)', 'Fig.6a': 'STAT5-IN-1 (in vitro MKs)'}
out = []
for s, des in designs.items():
    sub = raw[raw.sheet == s]
    for g, gs in sub.groupby('gene', sort=False):
        recs = []
        ctrl = gs[gs.label == 'ΔCT1'].iloc[0]['values']
        for v in ctrl:
            recs.append(dict(y=v, cre=0, pert=0))
        for _, r in gs[gs.label != 'ΔCT1'].iterrows():
            c, p = des[r['group']]
            for v in r['values']:
                recs.append(dict(y=v, cre=c, pert=p))
        d = pd.DataFrame(recs)
        m = smf.ols('y ~ C(cre)*C(pert)', d).fit()
        an = sm.stats.anova_lm(m, typ=2)
        pint = an.loc['C(cre):C(pert)', 'PR(>F)']
        mu = d.groupby(['cre', 'pert']).y.mean()
        eff_intact = mu[(1, 0)] - mu[(0, 0)]
        eff_pert = mu[(1, 1)] - mu[(0, 1)]
        out.append(dict(panel=s, node=node[s], gene=g, log2FC_creatine_intact=eff_intact, log2FC_creatine_perturbed=eff_pert,
                        pct_of_response_remaining=100 * eff_pert / eff_intact if eff_intact != 0 else np.nan,
                        p_interaction=pint, baseline_shift_log2=mu[(0, 1)] - mu[(0, 0)]))
out = pd.DataFrame(out)

# Stat5b KO (no KO-vehicle arm): compare (KO cre - WT veh) to (WT cre - WT veh)
sub = raw[raw.sheet == 'Fig. 6g']
st = []
for g, gs in sub.groupby('gene', sort=False):
    ctrl = np.mean(gs[gs.label == 'ΔCT1'].iloc[0]['values'])
    wt = np.mean(gs[gs.group == 'WT-Creatine'][gs.label != 'ΔCT1'].iloc[0]['values'])
    ko = np.mean(gs[gs.group == 'PF4-cre;Stat5bflox/flox-creatine'][gs.label != 'ΔCT1'].iloc[0]['values'])
    st.append(dict(panel='Fig. 6g', node='MK Stat5b deletion (in vivo; no KO-vehicle arm)', gene=g, log2FC_creatine_intact=wt - ctrl,
                   log2FC_creatine_perturbed=ko - ctrl, pct_of_response_remaining=100 * (ko - ctrl) / (wt - ctrl),
                   p_interaction=np.nan, baseline_shift_log2=np.nan))
st = pd.DataFrame(st)
allb = pd.concat([out, st], ignore_index=True)

summ = allb.groupby(['panel', 'node']).agg(genes=('gene', 'count'),
                                             median_log2FC_intact=('log2FC_creatine_intact', 'median'),
                                             median_log2FC_perturbed=('log2FC_creatine_perturbed', 'median'),
                                             median_pct_remaining=('pct_of_response_remaining', 'median'),
                                             n_genes_p_int_lt_0_05=('p_interaction', lambda x: int((x < 0.05).sum()))).reset_index()

if __name__ == '__main__':
    print(allb.round(3).to_string())
    print()
    print(summ.round(2).to_string())
    allb.to_csv(xl.OUT + 'out_qpcr_blockade_by_gene.csv', index=False)
    summ.to_csv(xl.OUT + 'out_qpcr_blockade_summary.csv', index=False)
