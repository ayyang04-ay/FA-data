# CRE-MK-01 re-analysis scripts

These scripts regenerate every number in `CRE-MK-01_validation_proposal` from the two source workbooks.

**Requirements:** Python 3.11 with pandas, numpy, scipy, statsmodels, openpyxl and matplotlib.

**Inputs:** `CRE-MK-01_source_data.xlsx` and `CRE-MK-01_phosphoproteomics.xlsx`, read from `$CRE_DATA_DIR` (default `/tmp/world/filesystem`).

**Outputs:** CSV tables go to `$CRE_OUT_DIR` (default `./results`). Figures go to `$CRE_FIG_DIR` (default `./results/figures`).

Run the scripts in this order. Later scripts read earlier outputs, and `a9_figures.py` reads everything, so it runs last.

| Script | Content |
|---|---|
| `xl.py` | Cell-range readers for the workbook |
| `a1_invivo.py` | Two-group in vivo endpoints; creatine x factor interactions (Fig 1f, 3i, 6b); Supp 2d |
| `a2_survival.py` | Log-rank and Cox models (Fig 1c, 1l) |
| `a3_platelet_levels.py` | Platelet indices and function, TEG, creatine/PCr levels; factorial tests (Fig 3b-d, Supp 4b/4c) |
| `a4_qpcr.py` | Mouse qPCR on the dCT scale; cross-panel control dCT comparison |
| `a5_qpcr_interaction.py` | Residual creatine response per perturbation (Slc6a8-KO, si-Ckb, STAT5i, Stat5b-KO) |
| `a6_wb_chip.py` | STAT5B-FLAG mutant quantification (Fig 5e/5f) and ChIP (Fig 5j, Supp 6i) |
| `a7_human.py` | Human cohort: paired analyses of Fig 7b-7e and Supp 8a/8b; Fig 7d reproducibility check |
| `a8_meta_power.py` | Cross-experiment meta-analysis; power for follow-up designs |
| `a10_phospho.py` | Phosphoproteome diagnostics and FDR |
| `a11_integrity.py` | Duplicate-value scans, shared runs across panels, float32 provenance of dCT values |
| `a9_figures.py` | Figures 1-6 |
