"""Phosphoproteomics diagnostics: single-detection artefact rows, p-value calibration, FDR, Stat5b."""
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
import xl

ph = pd.read_excel(xl.PHOSPHO)
ph.columns = ['gene', 'p', 'q_reported', 'log2FC']
m = len(ph)
art = np.isclose(ph.p, 2 * stats.t.sf(1, 2), atol=1e-5)  # Welch t=1, df=2 -> p=0.42265
ph['single_detection_artefact'] = art
ph['q_BH_all'] = multipletests(ph.p, method='fdr_bh')[1]
ph['q_BH_excl_artefacts'] = np.nan
ph.loc[~art, 'q_BH_excl_artefacts'] = multipletests(ph.p[~art], method='fdr_bh')[1]
ph['rank_p'] = ph.p.rank(method='min')

summary = {
    'phosphopeptides': m,
    'genes': ph.gene.nunique(),
    'rows with p = 0.42265 (Welch t=1, df=2; single-sample detection)': int(art.sum()),
    'fraction artefact rows': round(art.mean(), 3),
    'Student t=1, df=4 would give p': round(2 * stats.t.sf(1, 4), 4),
    'non-artefact rows': int((~art).sum()),
    'non-artefact rows with p<0.05': int((ph.p[~art] < 0.05).sum()),
    'expected by chance (0.05 x non-artefact rows)': round(0.05 * (~art).sum(), 1),
    'Storey pi0 (lambda=0.5), all rows': round((ph.p > 0.5).mean() / 0.5, 3),
    'Storey pi0 (lambda=0.5), excluding artefacts': round((ph.p[~art] > 0.5).mean() / 0.5, 3),
    'min reported q': round(ph.q_reported.min(), 4),
    'min BH q (all rows)': round(ph.q_BH_all.min(), 4),
    'min BH q (excluding artefacts)': round(ph.q_BH_excl_artefacts.min(), 4),
    'peptides with reported q<0.05': int((ph.q_reported < 0.05).sum()),
    "nominal screen hits (p<0.05 and FC>=1.2 or <=0.83)": int(((ph.p < 0.05) & ((ph.log2FC >= np.log2(1.2)) | (ph.log2FC <= np.log2(0.83)))).sum()),
}
s5 = ph[ph.gene == 'Stat5b']
summ = pd.DataFrame(list(summary.items()), columns=['metric', 'value'])
if __name__ == '__main__':
    print(summ.to_string(index=False))
    print(s5.to_string())
    summ.to_csv(xl.OUT + 'out_phospho_summary.csv', index=False)
    ph.sort_values('p').to_csv(xl.OUT + 'out_phospho_annotated.csv', index=False)
