"""Integrity scans: duplicated values within/across sheets, shared runs of foci counts, float32 provenance of dCT values."""
import collections, itertools
import numpy as np, pandas as pd
import openpyxl
import xl

wb = openpyxl.load_workbook(xl.SRC, data_only=True)
wbf = openpyxl.load_workbook(xl.SRC, data_only=False)


def sigdigits(v):
    s = ('%.10g' % abs(v)).replace('.', '').lstrip('0').rstrip('0')
    return len(s)


cells = []
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            v = c.value
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                f = wbf[ws.title][c.coordinate].value
                cells.append(dict(sheet=ws.title, cell=c.coordinate, value=float(v),
                                  is_formula=isinstance(f, str) and str(f).startswith('='), sig=sigdigits(v)))
cells = pd.DataFrame(cells)
cells['key'] = cells.value.map(lambda v: float('%.9g' % v))
dups = cells[cells.sig >= 5].groupby('key').filter(lambda g: len(g) > 1)
dup_groups = dups.groupby('key').agg(n=('cell', 'size'), sheets=('sheet', lambda x: ' | '.join(sorted(set(x)))),
                                     cells=('cell', lambda x: ' '.join(x))).reset_index()
dup_groups['cross_sheet'] = dup_groups.sheets.str.contains(r'\|')

# Shared runs of >=3 consecutive foci counts between in vivo panels
panels = {
    'Fig. 1b': 2, 'Fig. 1f': 4, 'Fig. 1k': 2, 'Fig. 3i': 4, 'Fig. 6b': 4, 'Fig. 7g': 2, 'Supplementary Fig  1e': 2, 'Supplementary Fig  1f': 2,
    'Supplementary Fig  1g': 2, 'Supplementary Fig  1i': 2, 'Supplementary Fig  1k': 2, 'Supplementary Fig  2d': 3}
colsf = []
for s, n in panels.items():
    for lab in ['The number of metastatic foci', 'Metastatic burden']:
        d = xl.block(s, xl.find(s, lab)[0], n)
        for k, v in d.items():
            colsf.append((s, lab, k, [round(x, 6) for x in v]))
runs = []
for (s1, l1, k1, v1), (s2, l2, k2, v2) in itertools.combinations(colsf, 2):
    if l1 != l2 or s1 == s2:
        continue
    sub1 = {tuple(v1[i:i + 3]): i for i in range(len(v1) - 2)}
    for j in range(len(v2) - 2):
        t = tuple(v2[j:j + 3])
        if t in sub1:
            runs.append(dict(endpoint=l1, panel_1=s1, arm_1=k1, position_1=sub1[t] + 1, panel_2=s2, arm_2=k2, position_2=j + 1, values=str(t)))
runs = pd.DataFrame(runs)

# float32 provenance of full-precision dCT values (Fig 3f)
from a4_qpcr import raw
f32 = []
for _, r in raw[raw.sheet.isin(['Fig. 2f', 'Fig. 3f', 'Supplementary Fig  3c', 'Supplementary Fig  8c'])].iterrows():
    devs = [abs(v - float(np.float32(v))) for v in r['values']]
    twodec = all(abs(v * 100 - round(v * 100)) < 1e-6 for v in r['values'])
    f32.append(dict(sheet=r['sheet'], gene=r['gene'], label=r['label'], group=r['group'], values=r['values'], two_decimal_style=twodec,
                    max_abs_dev_from_float32=max(devs), exactly_float32=all(d == 0 for d in devs)))
f32 = pd.DataFrame(f32)

# Within-group variability of lung weight and log-burden per in vivo panel (variance plausibility check)
var_rows = []
for s_, n_ in {'Fig. 1a': 2, 'Fig. 1b': 2, 'Fig. 1f': 4, 'Fig. 1j': 2, 'Fig. 1k': 2, 'Fig. 3i': 4, 'Fig. 6b': 4, 'Fig. 7g': 2,
               'Supplementary Fig  1e': 2, 'Supplementary Fig  1f': 2, 'Supplementary Fig  1g': 2, 'Supplementary Fig  1i': 2,
               'Supplementary Fig  1k': 2, 'Supplementary Fig  2d': 3}.items():
    for lab, kind in [('Lung weight', 'CV'), ('Metastatic burden', 'log-SD')]:
        hits = xl.find(s_, lab)
        if not hits:
            continue
        d = xl.block(s_, hits[0], n_)
        for k, v in d.items():
            v = np.asarray(v, float)
            val = v.std(ddof=1) / v.mean() if kind == 'CV' else np.log(v).std(ddof=1)
            var_rows.append(dict(panel=s_, endpoint=lab, group=k, n=len(v), statistic=kind, value=val))
variability = pd.DataFrame(var_rows)

findings = pd.DataFrame([
    dict(id=1, severity='critical', panels='Fig. 6b vs Supp. Fig. 2d', finding='Vehicle mice 2-4 and creatine mice 2-4 of Fig 6b are identical (values and order; burden to 6-7 significant figures and foci counts) to vehicle-donor and creatine-donor mice 4-6 of Supp 2d, two different experiments.', consequence='No usable in vivo evidence for STAT5 inhibition or aspirin until traced to source.'),
    dict(id=2, severity='major', panels='Phosphoproteomics', finding='29% of rows have p=0.42265 (Welch t=1, df=2 => single-sample detection); non-artefact p-values ~uniform (pi0~0.95); no peptide q<0.05; Stat5b p=0.0012, BH q 0.27-0.37; site not recorded.', consequence='STAT5B nomination is hypothesis-level.'),
    dict(id=3, severity='major', panels='Supp. Fig. 6a', finding='p-STAT5 Y694/699 undetectable in MKs with or without creatine (positive control works).', consequence='No canonical STAT5 activation; target engagement of any STAT5 tool must be shown.'),
    dict(id=4, severity='moderate', panels='Fig. 3f', finding='Duplicated unrounded dCT replicates (Gp6 KO-veh; Fcgr2a KO-cre); control dCT scale 13-19 cycles off other in vivo MK panels; WT-creatine dCTs not float32-exact unlike all other groups.', consequence='Supporting SLC6A8 transcript panel needs raw Ct; metastasis result (3i) unaffected.'),
    dict(id=5, severity='moderate', panels='Fig. 7d', finding='Volunteer 4 PITPNB dCT values are raw-Ct magnitude (+26 to +28); V4 PITPNB and RAB27B normalised values not reproducible (RAB27B d14 direction reversed); V2 day-0 dCTs 3-4 cycles off for 6 genes.', consequence='Exclude; human transcript evidence rests on n=3-4.'),
    dict(id=6, severity='moderate', panels='Fig. 2b, 3d, 2d', finding='Aggregation triplicates implausibly regular (all 2b triplets exact arithmetic progressions; all 3d values even, SD ~1-2 points); paradoxical creatine-induced fall in KO (3d); TEG only MA p=0.049.', consequence='Mouse platelet-function evidence weak; human data carry functional case.'),
    dict(id=7, severity='moderate', panels='Fig. 1i, 2c, 2j, Supp 4c', finding='n = 8 random fields per group (pseudo-replication).', consequence='Qualitative use only.'),
    dict(id=8, severity='moderate', panels='Fig. 7b, 7c, 7e, Supp 8a', finding='Paired data analysed as independent groups; normalised day-0 (zero variance) included in Dunnett ANOVA.', consequence='Replaced with paired analyses.'),
    dict(id=9, severity='design', panels='All in vivo', finding='Unmasked allocation/readout; no power calculation; sex not analysed and confounded with strain/model.', consequence='Effect inflation likely; addressed in Study A.'),
    dict(id=9.5, severity='moderate', panels='Fig. 3i', finding='Lung-weight group CVs 2.7-4.3% vs 6.4-34% in all other in vivo panels (burden/foci variance typical).', consequence='Lung-weight interaction p not relied on; provenance check G0-7.'),
    dict(id=10, severity='minor', panels='Fig. 4d, 7d, 1f', finding="'Creatinine' axis label for creatine assay; 'ADAR2A' for ADRA2A; 'si-Slc6a8' row label in shRNA experiment.", consequence='Record correction.'),
    dict(id=11, severity='checked - no issue', panels='Fig. 5j, Supp 6i, Fig. 7b', finding='Duplicated ChIP and serum-creatine values explained by measurement-grid discretisation (ChIP: all 72 values on 0.005-log2 grid).', consequence='None.'),
])

if __name__ == '__main__':
    print('duplicate groups (>=5 sig digits):', len(dup_groups), ' cross-sheet:', int(dup_groups.cross_sheet.sum()))
    print(runs.to_string())
    print(f32[f32.sheet == 'Fig. 3f'][['gene', 'label', 'group', 'exactly_float32', 'max_abs_dev_from_float32', 'two_decimal_style']].to_string())
    dup_groups.to_csv(xl.OUT + 'out_integrity_duplicate_values.csv', index=False)
    runs.to_csv(xl.OUT + 'out_integrity_shared_runs.csv', index=False)
    f32.to_csv(xl.OUT + 'out_integrity_float32_provenance.csv', index=False)
    findings.to_csv(xl.OUT + 'out_integrity_findings.csv', index=False)
    variability.to_csv(xl.OUT + 'out_integrity_variability.csv', index=False)
    print(variability[variability.endpoint == 'Lung weight'].groupby('panel').value.agg(['min', 'max']).round(3))
