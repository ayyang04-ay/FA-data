"""Re-analysis of mouse qPCR panels from the recorded dCT values.
Convention in the workbook: relative expression = 2^dCT (i.e. dCT = Ct_ref - Ct_target for most panels)."""
import re
import numpy as np, pandas as pd
from scipy import stats
import xl

pd.set_option('display.width', 250); pd.set_option('display.max_columns', 40); pd.set_option('display.max_rows', 500)

SHEETS = {
    'Fig. 2f': 'primary MKs, creatine vs vehicle (in vivo)',
    'Fig. 3f': 'MKs Pf4-Cre Slc6a8 (in vivo)',
    'Fig. 4e': 'MKs in vitro Ckb',
    'Fig. 4h': 'MKs in vitro: creatine / phosphocreatine',
    'Fig. 4j': 'MKs in vitro: si-Ckb x creatine',
    'Fig. 4l': 'MKs in vitro: CKB-OE',
    'Fig.6a': 'MKs in vitro: STAT5 inhibitor x creatine',
    'Fig. 6g': 'MKs Pf4-iCre Stat5b (in vivo)',
    'Supplementary Fig  2a': 'tumour cells sh-Slc6a8',
    'Supplementary Fig  3c': 'MK maturation genes (in vivo)',
    'Supplementary Fig  4e': 'Slc6a8-KO MKs: creatine vs liposomal creatine',
    'Supplementary Fig  5a': 'Gatm/Gamt',
    'Supplementary Fig  8c': 'CD41 in human CD41+ cells / monocytes / MEG-01',
}
lab_re = re.compile(r'^ΔCT(\d)$')


def is_f32(v):
    return float(np.float32(v)) == float(v)


def parse(sheet):
    w = xl.ws(sheet)
    # header row: find row containing group names for columns
    recs = []
    last_gene = None
    for row in w.iter_rows():
        labs = [(c.column, c.value) for c in row if isinstance(c.value, str) and lab_re.match(c.value.strip())]
        if not labs:
            continue
        r = row[0].row
        # gene name: string cells left of first label in this row that are not labels
        first_col = min(c for c, _ in labs)
        cand = [w.cell(row=r, column=cc).value for cc in range(1, first_col)]
        cand = [x for x in cand if isinstance(x, str) and x.strip() and not lab_re.match(x.strip())
                and 'normalization' not in x and '2^' not in x]
        if cand:
            last_gene = cand[-1].strip()
        for col, lab in labs:
            vals = [w.cell(row=r, column=col + k).value for k in (1, 2, 3)]
            vals = [float(v) for v in vals if isinstance(v, (int, float))]
            # group header: search upward for a string in column col+1
            grp = None
            for rr in range(r - 1, 0, -1):
                v = w.cell(row=rr, column=col + 1).value
                if isinstance(v, str) and not lab_re.match(v.strip()) and not v.startswith('(') and '2^' not in v:
                    grp = v.strip(); break
            recs.append(dict(sheet=sheet, gene=last_gene, label=lab.strip(), col=col, row=r, group=grp, values=vals))
    return recs


all_recs = []
for s in SHEETS:
    all_recs += parse(s)
raw = pd.DataFrame(all_recs)

# Determine control group per sheet: the ΔCT1 label's group in the *leftmost* position is labelled with the
# treated-group header (layout puts ΔCT1 under treated header), so control name = first header (col C/D/E).
CTRL_NAME = {}
for s in SHEETS:
    w = xl.ws(s)
    for row in w.iter_rows(min_row=1, max_row=8):
        for c in row:
            if isinstance(c.value, str) and c.value.strip() in ('Vehicle', 'Control', 'CKB-EV', 'Si-scrambled', 'Control+si-scrambled',
                                                                   'PF4 cre; Slc6a8+/+-vehicle', 'WT-Vehicle', 'CD41+ cells'):
                CTRL_NAME.setdefault(s, c.value.strip())

res = []
for (s, g), sub in raw.groupby(['sheet', 'gene'], sort=False):
    ctrl = sub[sub.label == 'ΔCT1'].iloc[0]['values']
    for _, rr in sub[sub.label != 'ΔCT1'].iterrows():
        t = rr['values']
        a, b = np.array(ctrl), np.array(t)
        if len(a) < 2 or len(b) < 2:
            continue
        dd = b.mean() - a.mean()
        st = stats.ttest_ind(b, a)
        wt = stats.ttest_ind(b, a, equal_var=False)
        se = np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
        q = stats.t.ppf(0.975, len(a) + len(b) - 2)
        # authors' per-pair normalisation: 2^(dCT_trt_i - dCT_ctrl_i)
        pair = 2 ** (b - a) if len(a) == len(b) else np.full(len(b), np.nan)
        res.append(dict(sheet=s, context=SHEETS[s], gene=g, group=rr['group'], n_ctrl=len(a), n_trt=len(b),
                        mean_dCT_ctrl=a.mean(), mean_dCT_trt=b.mean(), ddCT=dd,
                        FC=2 ** dd, FC_lo=2 ** (dd - q * se), FC_hi=2 ** (dd + q * se),
                        p_student_dCT=st.pvalue, p_welch_dCT=wt.pvalue,
                        authors_pairwise_mean=np.nanmean(pair),
                        f32_ctrl=all(is_f32(x) for x in a), f32_trt=all(is_f32(x) for x in b),
                        dup_within_trt=len(set(np.round(b, 12))) < len(b), dup_within_ctrl=len(set(np.round(a, 12))) < len(a)))
res = pd.DataFrame(res)

# Benjamini-Hochberg within each sheet x group
from statsmodels.stats.multitest import multipletests
res['q_BH_within_panel'] = np.nan
for (s, grp), idx in res.groupby(['sheet', 'group']).groups.items():
    p = res.loc[idx, 'p_student_dCT'].values
    res.loc[idx, 'q_BH_within_panel'] = multipletests(p, method='fdr_bh')[1]

# Cross-panel consistency: control-group mean dCT per gene per panel
ctrl_tab = raw[raw.label == 'ΔCT1'].copy()
ctrl_tab['mean_dCT_ctrl'] = ctrl_tab['values'].apply(np.mean)
ctrl_tab = ctrl_tab.drop_duplicates(['sheet', 'gene'])
piv = ctrl_tab.pivot_table(index='gene', columns='sheet', values='mean_dCT_ctrl')

if __name__ == '__main__':
    print(res[['sheet', 'gene', 'group', 'n_ctrl', 'n_trt', 'ddCT', 'FC', 'FC_lo', 'FC_hi', 'p_student_dCT', 'p_welch_dCT', 'q_BH_within_panel',
               'authors_pairwise_mean', 'f32_ctrl', 'f32_trt', 'dup_within_trt', 'dup_within_ctrl']].round(4).to_string())
    print()
    print(piv.round(2).to_string())
    res.to_csv(xl.OUT + 'out_qpcr_mouse.csv', index=False)
    piv.to_csv(xl.OUT + 'out_qpcr_ctrl_dCT_by_panel.csv')
