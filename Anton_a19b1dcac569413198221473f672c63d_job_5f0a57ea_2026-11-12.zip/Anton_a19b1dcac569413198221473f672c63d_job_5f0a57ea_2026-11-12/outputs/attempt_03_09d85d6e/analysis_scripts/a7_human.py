"""Human healthy-volunteer cohort re-analysis (Fig 7b, 7c, 7d, 7e; Supp 8a, 8b)."""
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
import statsmodels.formula.api as smf
import xl

pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_columns', 40)
DAYS = [0, 3, 7, 14]


# ---------------- Fig 7b serum creatine ----------------
def matrix_rows(sheet, r0, r1, c0='B', c1='E'):
    return np.array(xl.rows(sheet, f'{c0}{r0}:{c1}{r1}'), float)


cr = matrix_rows('Fig. 7b', 4, 14)
print('Fig 7b serum creatine (uM), n=', cr.shape[0])
print('  means by day', cr.mean(0).round(1), 'sd', cr.std(0, ddof=1).round(1))
fr = stats.friedmanchisquare(*cr.T)
print('  Friedman p', fr.pvalue)
for j, d in enumerate(DAYS[1:], 1):
    t = stats.ttest_rel(cr[:, j], cr[:, 0])
    w = stats.wilcoxon(cr[:, j], cr[:, 0])
    print(f'  d{d} vs d0: mean ratio {np.mean(cr[:, j] / cr[:, 0]):.2f}, geo-mean ratio {np.exp(np.mean(np.log(cr[:, j] / cr[:, 0]))):.2f}, paired t p={t.pvalue:.2e}, Wilcoxon p={w.pvalue:.4f}; n increased {(cr[:, j] > cr[:, 0]).sum()}/11')
# value-grid check (colorimetric standard curve discretisation)
vals = np.sort(np.unique(cr.round(3)))
d = np.diff(vals)
step = np.min(d[d > 0.05]) if (d > 0.05).any() else None
print('  smallest spacing between distinct serum values:', np.round(np.sort(d)[:8], 4))
g = 0.35383
resid = ((cr - cr.min()) / g) - np.round((cr - cr.min()) / g)
print('  fraction of values on a ~0.354 uM grid (|resid|<0.02):', np.mean(np.abs(resid) < 0.02).round(2))

# ---------------- Fig 7c platelet function ----------------
w = xl.ws('Fig. 7c')
blocks = []
agonist = None
r = 1
maxr = w.max_row
while r <= maxr:
    a = w.cell(row=r, column=1).value
    if isinstance(a, str) and a.strip() in ('collagen', 'EPI', 'AA', 'ADP'):
        agonist = a.strip()
    if isinstance(a, str) and a.startswith('Relative'):
        metric = a.split('(')[0].replace('Relative', '').strip()
        data = []
        rr = r if isinstance(w.cell(row=r, column=2).value, (int, float)) else r + 1
        while rr <= maxr and isinstance(w.cell(row=rr, column=2).value, (int, float)):
            data.append([w.cell(row=rr, column=c).value for c in range(2, 6)])
            rr += 1
        blocks.append((agonist, metric, np.array(data, float)))
        r = rr
        continue
    r += 1
rows = []
for ag, met, m in blocks:
    assert m.shape == (11, 4), (ag, met, m.shape)
    assert np.allclose(m[:, 0], 1)
    for j, dday in enumerate(DAYS[1:], 1):
        x = m[:, j]
        pos = x > 0
        lx = np.log2(x[pos])
        t = stats.ttest_1samp(lx, 0)
        try:
            wx = stats.wilcoxon(lx).pvalue
        except ValueError:
            wx = np.nan
        rows.append(dict(agonist=ag, metric=met, day=dday, n=int(pos.sum()), n_zero=int((~pos).sum()),
                         mean_FC=x.mean(), median_FC=np.median(x), geomean_FC=2 ** lx.mean(),
                         n_up=int((x > 1).sum()), p_logFC_ttest=t.pvalue, p_wilcoxon=wx))
pf = pd.DataFrame(rows)
# reported Dunnett p values
rep = []
r = 1
while r <= maxr:
    a = w.cell(row=r, column=7).value
    if isinstance(a, str) and a.startswith('0 vs.'):
        rep.append(w.cell(row=r, column=12).value)
    r += 1
pf['reported_dunnett_p'] = rep if len(rep) == len(pf) else np.nan
pf['q_BH_all36'] = multipletests(pf.p_logFC_ttest, method='fdr_bh')[1]
pf['p_holm_all36'] = multipletests(pf.p_logFC_ttest, method='holm')[1]
d14 = pf[pf.day == 14].copy()
d14['q_BH_d14_12tests'] = multipletests(d14.p_logFC_ttest, method='fdr_bh')[1]
print('\nFig 7c platelet function (fold change vs own day 0, n=11):')
print(pf.round(4).to_string())
print('\nDay-14 only, BH over 12 tests:')
print(d14[['agonist', 'metric', 'geomean_FC', 'n_up', 'p_logFC_ttest', 'p_wilcoxon', 'q_BH_d14_12tests', 'reported_dunnett_p']].round(4).to_string())
pf.to_csv(xl.OUT + 'out_human_platelet_function.csv', index=False)

# ---------------- Fig 7d CD41+ qPCR ----------------
w = xl.ws('Fig. 7d')
genes = {}
for row in w.iter_rows():
    for c in row:
        if isinstance(c.value, str) and c.value.strip() in ('ITGA2B', 'P2RY12', 'GP6', 'GPIBA', 'F2R', 'ADAR2A', 'FCGR2A', 'RUNX1', 'RAB4A', 'RAB27B', 'PITPNB'):
            genes[c.value.strip()] = (c.row, c.column)
hq = []
norm_check = []
for gname, (r0, c0) in genes.items():
    vcols = [cc for cc in range(c0, c0 + 8) if isinstance(w.cell(row=r0, column=cc).value, str) and w.cell(row=r0, column=cc).value.startswith('Volunteer')]
    vols = [w.cell(row=r0, column=cc).value for cc in vcols]
    dct = np.array([[w.cell(row=r0 + 1 + i, column=cc).value for cc in vcols] for i in range(12)], float)
    rep_norm = np.array([[w.cell(row=r0 + 13 + i, column=cc).value for cc in vcols] for i in range(4)], float)
    mean_by_day = np.array([dct[3 * i:3 * i + 3].mean(0) for i in range(4)])  # 4 days x 4 volunteers
    ddct = mean_by_day - mean_by_day[0]
    fc = 2 ** ddct
    # exclude volunteer-4 PITPNB / RAB27B (recorded values not reproducible; PITPNB 'dCT' are raw-Ct magnitude)
    excl = np.zeros(4, bool)
    if gname in ('PITPNB', 'RAB27B'):
        excl[3] = True
    for k in range(4):
        for i, dday in enumerate(DAYS):
            norm_check.append(dict(gene=gname, volunteer=vols[k], day=dday, recomputed_FC=fc[i, k], reported_FC=rep_norm[i, k],
                                   mean_dCT=mean_by_day[i, k]))
    for i, dday in enumerate(DAYS[1:], 1):
        x = ddct[i]
        t = stats.ttest_1samp(x, 0)
        xe = x[~excl]
        te = stats.ttest_1samp(xe, 0)
        hq.append(dict(gene=gname, day=dday, FC_volunteers=np.round(fc[i], 2).tolist(), geomean_FC=2 ** x.mean(), n_up=int((x > 0).sum()),
                       p_paired_t=t.pvalue, geomean_FC_excl=2 ** xe.mean(), n_used_excl=int((~excl).sum()), p_paired_t_excl=te.pvalue))
hq = pd.DataFrame(hq)
nc = pd.DataFrame(norm_check)
nc['ratio_rep_to_recomp'] = nc.reported_FC / nc.recomputed_FC
print('\nFig 7d recomputed (mean of technical triplicates; ddCT vs own day 0):')
print(hq.round(4).to_string())
bad = nc[(np.abs(np.log2(nc.ratio_rep_to_recomp)) > 0.1)]
print('\nNormalised values in workbook that differ >7% from recomputation:')
print(bad.round(3).to_string())
print('\nMean dCT at day 0 by volunteer (all genes):')
print(nc[nc.day == 0].pivot_table(index='gene', columns='volunteer', values='mean_dCT').round(2).to_string())
hq.to_csv(xl.OUT + 'out_human_qpcr.csv', index=False)
nc.to_csv(xl.OUT + 'out_human_qpcr_normcheck.csv', index=False)

# ---------------- Fig 7e GP6 / P2RY12 protein ----------------
pe = []
for lab in ['GP6/β-ACTIN', 'P2RY12/β-ACTIN']:
    hc = xl.find('Fig. 7e', lab)[0]
    d = xl.block('Fig. 7e', hc, 4)
    m = np.array(list(d.values()), float).T  # 4 volunteers x 4 days (assuming row = volunteer)
    fr = stats.friedmanchisquare(*m.T)
    # RM ANOVA via mixed model (random intercept per volunteer)
    recs = [dict(y=m[i, j], vol=i, day=str(DAYS[j])) for i in range(m.shape[0]) for j in range(4)]
    dfm = pd.DataFrame(recs)
    for j, dday in enumerate(DAYS[1:], 1):
        t = stats.ttest_rel(m[:, j], m[:, 0])
        pe.append(dict(protein=lab, day=dday, mean_d0=m[:, 0].mean(), mean_day=m[:, j].mean(), ratio=m[:, j].mean() / m[:, 0].mean(),
                       n_up=int((m[:, j] > m[:, 0]).sum()), p_paired_t=t.pvalue, friedman_p=fr.pvalue,
                       p_unpaired_t=stats.ttest_ind(m[:, j], m[:, 0]).pvalue))
pe = pd.DataFrame(pe)
pe['p_holm_within_protein'] = pe.groupby('protein').p_paired_t.transform(lambda p: multipletests(p, method='holm')[1])
print('\nFig 7e platelet protein (n=4 volunteers, paired):')
print(pe.round(4).to_string())
pe.to_csv(xl.OUT + 'out_human_protein.csv', index=False)

# ---------------- Supp 8a BMI, 8b CBC ----------------
bmi = np.array(xl.rows('Supplementary Fig  8a', 'C4:D14'), float)
print('\nSupp 8a BMI paired t p =', stats.ttest_rel(bmi[:, 1], bmi[:, 0]).pvalue, 'mean change', (bmi[:, 1] - bmi[:, 0]).mean())
print('   baseline BMI mean/sd', bmi[:, 0].mean().round(2), bmi[:, 0].std(ddof=1).round(2))
for lab in ['PLT', 'PCT', 'MPV', 'PDW']:
    hc = xl.find('Supplementary Fig  8b', lab)[0]
    # header row is the row with 0 3 7 14 (same row for PLT, next row for others)
    from openpyxl.utils.cell import coordinate_from_string
    cl, r0 = coordinate_from_string(hc)
    ws8 = xl.ws('Supplementary Fig  8b')
    start = r0 + 1 if isinstance(ws8.cell(row=r0 + 1, column=2).value, (int, float)) else r0 + 2
    m = np.array(xl.rows('Supplementary Fig  8b', f'B{start}:E{start + 10}'), float)
    ps = [stats.ttest_rel(m[:, j], m[:, 0]).pvalue for j in (1, 2, 3)]
    print(f'   Supp 8b {lab}: means {m.mean(0).round(2)}, paired p vs d0 {np.round(ps, 3)}')
