"""Cross-experiment synthesis of the creatine effect on metastasis and power calculations for follow-up designs."""
import numpy as np, pandas as pd
from scipy import stats
import xl

pd.set_option('display.width', 250)

exps = [  # sheet, label, vehicle col index, creatine col index, n cols, description, integrity flag
    ('Fig. 1b', 'Metastatic burden', 0, 1, 2, 'gavage, model A (Fig 1a-c)', ''),
    ('Fig. 1f', 'Metastatic burden', 0, 1, 4, 'gavage, melanoma sh-scrambled', ''),
    ('Fig. 1k', 'Metastatic burden', 0, 1, 2, 'gavage, model B (Fig 1j-l)', ''),
    ('Fig. 3i', 'Metastatic burden', 0, 1, 4, 'gavage, Pf4-Cre;Slc6a8+/+ controls', ''),
    ('Fig. 6b', 'Metastatic burden', 0, 1, 4, 'gavage, DMSO arms of STAT5i study', 'DUPLICATED with Supp 2d'),
    ('Supplementary Fig  1e', 'Metastatic burden', 0, 1, 2, 'Supp 1e', ''),
    ('Supplementary Fig  1f', 'Metastatic burden', 0, 1, 2, 'Supp 1f', ''),
    ('Supplementary Fig  1g', 'Metastatic burden', 0, 1, 2, 'Supp 1g', ''),
    ('Supplementary Fig  1i', 'Metastatic burden', 0, 1, 2, '5% creatine diet', ''),
    ('Supplementary Fig  1k', 'Metastatic burden', 0, 1, 2, 'Supp 1k', ''),
    ('Supplementary Fig  2d', 'Metastatic burden', 0, 1, 3, 'platelet transfer (donor creatine)', 'DUPLICATED with Fig 6b'),
    ('Fig. 7g', 'Metastatic burden', 0, 1, 2, 'human d0 vs d7 platelets -> mice', ''),
]
rows = []
sds = []
for sheet, lab, iv, ic, n, desc, flag in exps:
    hc = xl.find(sheet, lab)[0]
    d = list(xl.block(sheet, hc, n).values())
    a, b = np.log(d[iv]), np.log(d[ic])
    diff = b.mean() - a.mean()
    sp2 = ((len(a) - 1) * a.var(ddof=1) + (len(b) - 1) * b.var(ddof=1)) / (len(a) + len(b) - 2)
    se = np.sqrt(sp2 * (1 / len(a) + 1 / len(b)))
    rows.append(dict(panel=sheet, description=desc, n_veh=len(a), n_cre=len(b), log_ratio=diff, ratio=np.exp(diff), se=se,
                     pooled_sd_log=np.sqrt(sp2), flag=flag))
    if not flag:
        for k, v in enumerate(d):
            if len(v) > 1:
                sds.append((np.log(v).std(ddof=1), len(v)))
meta = pd.DataFrame(rows)
clean = meta[meta.flag == '']
mouse_only = clean[clean.panel != 'Fig. 7g']
w = 1 / mouse_only.se ** 2
pooled = (w * mouse_only.log_ratio).sum() / w.sum()
pse = np.sqrt(1 / w.sum())
Q = (w * (mouse_only.log_ratio - pooled) ** 2).sum()
dfq = len(mouse_only) - 1
I2 = max(0, (Q - dfq) / Q)
print(meta.round(3).to_string())
print(f'\nFixed-effect pooled creatine/vehicle ratio (metastatic burden, {len(mouse_only)} clean mouse experiments): '
      f'{np.exp(pooled):.2f} (95% CI {np.exp(pooled - 1.96 * pse):.2f}-{np.exp(pooled + 1.96 * pse):.2f}); Q={Q:.1f}, df={dfq}, I2={I2:.2f}')
# pooled within-group SD on log scale
num = sum((n - 1) * s ** 2 for s, n in sds)
den = sum(n - 1 for s, n in sds)
sd_pool = np.sqrt(num / den)
print(f'Pooled within-group SD of log(metastatic burden) across clean experiments: {sd_pool:.3f}')
sd_list = np.array([s for s, n in sds])
print('   range of group SDs (log):', sd_list.min().round(3), '-', sd_list.max().round(3), ' 75th pct:', np.percentile(sd_list, 75).round(3))
meta.to_csv(xl.OUT + 'out_meta_creatine_effect.csv', index=False)


# -------- power for 2x2 factorial interaction (log scale) --------
def n_per_group_interaction(effect_log, frac_block, sd, alpha=0.05, power=0.9):
    """n per cell so that the interaction contrast (frac_block * effect_log) is detected; contrast var = 4 sd^2 / n."""
    delta = frac_block * effect_log
    z = stats.norm.ppf(1 - alpha / 2) + stats.norm.ppf(power)
    n = 4 * sd ** 2 * z ** 2 / delta ** 2
    # t-correction iteration
    for _ in range(20):
        dfree = 4 * (np.ceil(n) - 1)
        z2 = stats.t.ppf(1 - alpha / 2, dfree) + stats.t.ppf(power, dfree)
        n = 4 * sd ** 2 * z2 ** 2 / delta ** 2
    return int(np.ceil(n))


def n_per_group_main(effect_log, sd, alpha=0.05, power=0.9):
    z = stats.norm.ppf(1 - alpha / 2) + stats.norm.ppf(power)
    n = 2 * sd ** 2 * z ** 2 / effect_log ** 2
    for _ in range(20):
        dfree = 2 * (np.ceil(n) - 1)
        z2 = stats.t.ppf(1 - alpha / 2, dfree) + stats.t.ppf(power, dfree)
        n = 2 * sd ** 2 * z2 ** 2 / effect_log ** 2
    return int(np.ceil(n))


pw = []
for sd in [sd_pool, np.percentile(sd_list, 75), 0.6]:
    for ratio in [2.0, 2.5, 3.0]:
        for frac in [1.0, 0.75, 0.5]:
            pw.append(dict(sd_log=round(sd, 3), creatine_ratio=ratio, fraction_of_effect_blocked=frac,
                           n_per_cell_interaction_90pct=n_per_group_interaction(np.log(ratio), frac, sd),
                           n_per_cell_interaction_80pct=n_per_group_interaction(np.log(ratio), frac, sd, power=0.8)))
        pw.append(dict(sd_log=round(sd, 3), creatine_ratio=ratio, fraction_of_effect_blocked='main effect only (2 arms)',
                       n_per_cell_interaction_90pct=n_per_group_main(np.log(ratio), sd), n_per_cell_interaction_80pct=n_per_group_main(np.log(ratio), sd, power=0.8)))
pw = pd.DataFrame(pw)
print(pw.to_string())
pw.to_csv(xl.OUT + 'out_power.csv', index=False)

# Power of the existing Fig 3i design (n=4/cell) to detect 50% / 100% blockade, using pooled SD
for frac in [1.0, 0.5]:
    delta = frac * np.log(3.0)
    se = np.sqrt(4 * sd_pool ** 2 / 4)
    dfree = 12
    ncp = delta / se
    tcrit = stats.t.ppf(0.975, dfree)
    power = 1 - stats.nct.cdf(tcrit, dfree, ncp) + stats.nct.cdf(-tcrit, dfree, ncp)
    print(f'Existing n=4/cell design: power to detect {int(frac * 100)}% blockade of a 3-fold effect = {power:.2f}')
