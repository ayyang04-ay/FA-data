"""Platelet function / counts / creatine-level panels."""
import numpy as np, pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
import statsmodels.api as sm
import xl
from a1_invivo import two_group, reported

pd.set_option('display.width', 250); pd.set_option('display.max_columns', 40)
rows = []


def add_simple(sheet, labels, ctx, unit='mouse', ncols=2, pairs=None):
    ps, ts = reported(sheet)
    for i, lab in enumerate(labels):
        hc = xl.find(sheet, lab)[0]
        d = xl.block(sheet, hc, ncols)
        k = list(d.keys())
        rows.append(two_group(sheet, lab, d[k[0]], d[k[1]], ps[i] if i < len(ps) else None,
                              ts[i] if i < len(ts) else None, unit, ctx))


add_simple('Fig. 2a', ['PLT', 'PCT', 'PDW', 'MPV'], 'platelet indices, creatine vs vehicle')
add_simple('Fig. 2c', ['The number of a-granules'], 'platelet alpha-granules (TEM)', unit='field (8 random fields/group)')
add_simple('Fig. 2d', ['TEG-R', 'TEG-K', 'TEG-α', 'TEG-MA'], 'thromboelastography')
add_simple('Fig. 2j', ['PKH postive'], 'PKH+ platelet area in lung', unit='field (8 random fields/group)')
add_simple('Supplementary Fig  1b', ['Average daily food'], 'food intake')
add_simple('Supplementary Fig  1c', ['Average daily water'], 'water intake')
add_simple('Supplementary Fig  1d', ['Creatine concentration of serum'], 'mouse serum creatine (uM)')
add_simple('Supplementary Fig  3a', ['WBC', 'lymphocyte', 'Monocyte', 'RBC'], 'blood counts')
add_simple('Supplementary Fig  5c', ['Creatine concentration', 'Phosphocreatine'], 'CKB-OE vs EV in MKs')

# Fig 2b aggregation: rows ADP/Collagen/Thrombin, cols B-D vehicle, E-G creatine
ps, ts = reported('Fig. 2b')
for i, r in enumerate([4, 5, 6]):
    v = xl.rows('Fig. 2b', f'A{r}:G{r}')[0]
    rows.append(two_group('Fig. 2b', f'aggregation {xl.cell("Fig. 2b", f"A{r}")}', v[0:3], v[3:6], ps[i], ts[i], 'mouse (n=3)', 'platelet aggregation %'))

# Supp 1h (diet): block header is in col B
hc = xl.find('Supplementary Fig  1h', 'Creatine concentration of serum')[0]
d = xl.block('Supplementary Fig  1h', hc, 2)
k = list(d)
ps, ts = reported('Supplementary Fig  1h')
rows.append(two_group('Supplementary Fig  1h', 'serum creatine (diet)', d[k[0]], d[k[1]], ps[0], ts[0], 'mouse', '5% creatine diet'))

# Fig 4a/4c: MKs and brain
for sheet, lab in [('Fig. 4a', 'Creatine concentration'), ('Fig. 4c', 'Phosphocreatine')]:
    hc = xl.find(sheet, lab)[0]
    d = xl.block(sheet, hc, 4)
    v = list(d.values())
    ps, ts = reported(sheet)
    rows.append(two_group(sheet, lab + ' [MKs]', v[0], v[1], ps[0], ts[0], 'mouse', 'in vivo MK'))
    rows.append(two_group(sheet, lab + ' [brain]', v[2], v[3], ps[1], ts[1], 'mouse', 'in vivo brain'))
# Fig 4d, 4f: in vitro MKs
for sheet, lab in [('Fig. 4d', 'Creatinine'), ('Fig. 4f', 'Phosphocreatine')]:
    hc = xl.find(sheet, lab)[0]
    off = 2 if sheet == 'Fig. 4d' else 1
    d = xl.block(sheet, hc, 2, start_col_offset=off)
    v = list(d.values())
    ps, ts = reported(sheet)
    rows.append(two_group(sheet, lab + ' (label as recorded)', v[0], v[1], ps[0], ts[0], 'culture', 'in vitro MK'))

# Fig 3b/3c: serum and MK creatine in Slc6a8 model (rows)
for sheet, lab, unit in [('Fig. 3b', 'serum creatine (uM)', 'mouse'), ('Fig. 3c', 'MK intracellular creatine', 'mouse')]:
    ps, ts = reported(sheet)
    r1 = xl.rows(sheet, 'B4:K4')[0]; r2 = xl.rows(sheet, 'B5:K5')[0]
    h = len(r1) // 2
    rows.append(two_group(sheet, lab + ' [Slc6a8+/+]', r1[:h], r1[h:], ps[0], ts[0], unit, 'Pf4-Cre Slc6a8'))
    h2 = len(r2) // 2
    rows.append(two_group(sheet, lab + ' [Slc6a8fl/fl]', r2[:h2], r2[h2:], ps[1], ts[1], unit, 'Pf4-Cre Slc6a8'))

df = pd.DataFrame(rows)
df['p_match'] = np.where(df.reported_p.notna(), np.isclose(df.p_student, pd.to_numeric(df.reported_p, errors='coerce'), rtol=0.06, atol=5e-5), np.nan)

# ---- Factorial: Fig 3c interaction, Fig 3d aggregation, Supp 4c granules, Supp 4b PLT
fac = []


def inter(name, groups, levels, log=False):
    recs = []
    for vals, (a, b) in zip(groups, levels):
        for x in vals:
            recs.append(dict(y=np.log(x) if log else x, A=a, B=b))
    d = pd.DataFrame(recs)
    m = smf.ols('y ~ C(A)*C(B)', d).fit()
    an = sm.stats.anova_lm(m, typ=2)
    key = [i for i in an.index if ':' in i][0]
    return an.loc[key, 'PR(>F)']


r1 = xl.rows('Fig. 3c', 'B4:G4')[0]; r2 = xl.rows('Fig. 3c', 'B5:G5')[0]
lv = [('veh', 'WT'), ('cre', 'WT'), ('veh', 'KO'), ('cre', 'KO')]
fac.append(dict(panel='Fig. 3c', endpoint='MK creatine', p_int_raw=inter('', [r1[:3], r1[3:], r2[:3], r2[3:]], lv),
                p_int_log=inter('', [r1[:3], r1[3:], r2[:3], r2[3:]], lv, log=True),
                ratio_WT=np.mean(r1[3:]) / np.mean(r1[:3]), ratio_KO=np.mean(r2[3:]) / np.mean(r2[:3])))
r1 = xl.rows('Fig. 3b', 'B4:K4')[0]; r2 = xl.rows('Fig. 3b', 'B5:K5')[0]
fac.append(dict(panel='Fig. 3b', endpoint='serum creatine', p_int_raw=inter('', [r1[:5], r1[5:], r2[:5], r2[5:]], lv),
                p_int_log=inter('', [r1[:5], r1[5:], r2[:5], r2[5:]], lv, log=True),
                ratio_WT=np.mean(r1[5:]) / np.mean(r1[:5]), ratio_KO=np.mean(r2[5:]) / np.mean(r2[:5])))
for r in [4, 5, 6]:
    v = xl.rows('Fig. 3d', f'B{r}:M{r}')[0]
    g = [v[0:3], v[3:6], v[6:9], v[9:12]]
    fac.append(dict(panel='Fig. 3d', endpoint='aggregation ' + xl.cell('Fig. 3d', f'A{r}'),
                    p_int_raw=inter('', g, lv), p_int_log=inter('', g, lv, log=True),
                    ratio_WT=np.mean(g[1]) / np.mean(g[0]), ratio_KO=np.mean(g[3]) / np.mean(g[2]),
                    mean_WTveh=np.mean(g[0]), mean_WTcre=np.mean(g[1]), mean_KOveh=np.mean(g[2]), mean_KOcre=np.mean(g[3]),
                    p_KO_cre_vs_veh=stats.ttest_ind(g[3], g[2]).pvalue, p_KOveh_vs_WTveh=stats.ttest_ind(g[2], g[0]).pvalue))
hc = xl.find('Supplementary Fig  4c', 'The number of a-granules')[0]
d = xl.block('Supplementary Fig  4c', hc, 4)
g = list(d.values())
fac.append(dict(panel='Supp 4c', endpoint='alpha-granules (fields)', p_int_raw=inter('', g, lv), p_int_log=np.nan,
                ratio_WT=np.mean(g[1]) / np.mean(g[0]), ratio_KO=np.mean(g[3]) / np.mean(g[2])))
hc = xl.find('Supplementary Fig  4b', 'PLT')[0]
d = xl.block('Supplementary Fig  4b', hc, 4)
g = list(d.values())
fac.append(dict(panel='Supp 4b', endpoint='platelet count', p_int_raw=inter('', g, lv), p_int_log=inter('', g, lv, log=True),
                ratio_WT=np.mean(g[1]) / np.mean(g[0]), ratio_KO=np.mean(g[3]) / np.mean(g[2])))
fac = pd.DataFrame(fac)

# Fig 6e Stat5b creatine uptake (3 groups)
hc = xl.find('Fig. 6e', 'Creatine concentration of MKs')[0]
d = xl.block('Fig. 6e', hc, 3)
g = list(d.values())
six = [two_group('Fig. 6e', 'MK creatine WT cre vs WT veh', g[0], g[1]),
       two_group('Fig. 6e', 'MK creatine Stat5b-KO cre vs WT veh', g[0], g[2]),
       two_group('Fig. 6e', 'MK creatine Stat5b-KO cre vs WT cre', g[1], g[2])]
six = pd.DataFrame(six)

if __name__ == '__main__':
    print(df[['panel', 'endpoint', 'unit_of_n', 'n_ctrl', 'n_trt', 'mean_ctrl', 'sd_ctrl', 'mean_trt', 'sd_trt', 'ratio_means', 'hedges_g', 'p_student', 'reported_p', 'p_match', 'p_welch', 'p_mannwhitney']].to_string())
    print()
    print(fac.to_string())
    print()
    print(six[['panel', 'endpoint', 'mean_ctrl', 'mean_trt', 'ratio_means', 'p_student', 'p_welch']].to_string())
    df.to_csv(xl.OUT + 'out_platelet_levels.csv', index=False)
    fac.to_csv(xl.OUT + 'out_platelet_factorial.csv', index=False)
