"""Helpers to read the CRE-MK-01 source-data workbook by explicit cell ranges."""
import openpyxl
from openpyxl.utils import range_boundaries

import os
DATA_DIR = os.environ.get('CRE_DATA_DIR', '/tmp/world/filesystem')
SRC = os.path.join(DATA_DIR, 'CRE-MK-01_source_data.xlsx')
PHOSPHO = os.path.join(DATA_DIR, 'CRE-MK-01_phosphoproteomics.xlsx')
OUT = os.environ.get('CRE_OUT_DIR', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results')) + os.sep
os.makedirs(OUT, exist_ok=True)
_wb = openpyxl.load_workbook(SRC, data_only=True)
_wbf = openpyxl.load_workbook(SRC, data_only=False)


def ws(name):
    return _wb[name]


def cols(sheet, rng, drop_none=True):
    """Return list of columns (lists) for rectangular range like 'B4:E9'."""
    w = _wb[sheet]
    c1, r1, c2, r2 = range_boundaries(rng)
    out = []
    for c in range(c1, c2 + 1):
        col = [w.cell(row=r, column=c).value for r in range(r1, r2 + 1)]
        if drop_none:
            col = [v for v in col if isinstance(v, (int, float))]
        out.append(col)
    return out


def rows(sheet, rng, drop_none=True):
    w = _wb[sheet]
    c1, r1, c2, r2 = range_boundaries(rng)
    out = []
    for r in range(r1, r2 + 1):
        row = [w.cell(row=r, column=c).value for c in range(c1, c2 + 1)]
        if drop_none:
            row = [v for v in row if isinstance(v, (int, float))]
        out.append(row)
    return out


def cell(sheet, coord):
    return _wb[sheet][coord].value


def formula(sheet, coord):
    return _wbf[sheet][coord].value


def find(sheet, text):
    """Find coordinates of cells whose string value contains text."""
    w = _wb[sheet]
    hits = []
    for row in w.iter_rows():
        for c in row:
            if isinstance(c.value, str) and text in c.value:
                hits.append(c.coordinate)
    return hits


def block(sheet, header_coord, ncols, start_col_offset=1, max_rows=60):
    """Read a data block: header cell (label) at header_coord; group names are in the
    same row in the next `ncols` columns (offset start_col_offset); data rows below until a
    row with no numeric values across those columns. Returns dict name->list."""
    w = _wb[sheet]
    from openpyxl.utils.cell import coordinate_from_string, column_index_from_string
    col_letter, r0 = coordinate_from_string(header_coord)
    c0 = column_index_from_string(col_letter)
    names = [w.cell(row=r0, column=c0 + start_col_offset + i).value for i in range(ncols)]
    data = {str(n) + ('' if names.count(n) == 1 else f'#{i}'): [] for i, n in enumerate(names)}
    keys = list(data.keys())
    r = r0 + 1
    while r < r0 + max_rows:
        vals = [w.cell(row=r, column=c0 + start_col_offset + i).value for i in range(ncols)]
        if not any(isinstance(v, (int, float)) for v in vals):
            break
        for k, v in zip(keys, vals):
            if isinstance(v, (int, float)):
                data[k].append(float(v))
        r += 1
    return data
