**Recommendation: take megakaryocyte SLC6A8 — the transporter through which supplemental creatine enters megakaryocytes — forward as the primary target for the in vivo slot, with platelet GPVI as the lead backup and STAT5B as a conditional backup.**

The in vivo slot should run a blinded, adequately powered confirmation of the megakaryocyte-SLC6A8 result. The same study should test GPVI head-to-head and ask whether stopping creatine reverses the effect. Until the six animals that appear in both Fig. 6b and Supp. Fig. 2d are traced to their source records, no in vivo resource should go to STAT5 inhibition or to aspirin.

*CRE-MK-01 follow-up: validation proposal for the portfolio committee. Basis: CRE-MK-01_source_data.xlsx (86 panels), CRE-MK-01_phosphoproteomics.xlsx and study_conventions.pdf. These files are treated as ground truth. No external data were used. Every number below was re-computed from the raw values in the workbook; Appendix A gives the methods, and the scripts and output tables are in the accompanying bundle.*

---

## 1. The decision on one page

**What we take forward, and why**

| Rank | Target | Why it earns the rank | What is still missing |
|---|---|---|---|
| **Primary** | **Megakaryocyte (MK) SLC6A8**, i.e. MK creatine uptake | This is the only node with a **lineage-restricted, genetic, in vivo test on the metastasis endpoint whose provenance is clean**. In Pf4-Cre;Slc6a8^fl/fl^ mice, creatine's pro-metastatic effect is lost. The creatine × genotype interaction is p = 0.0003 for burden and 0.004 for foci (Fig. 3i); lung weight gives 0.0002, but its variance is atypically low (§3). The rest of the mechanistic chain is lost in the same mice: MK creatine loading, the platelet-gene programme and α-granule gain. Bypassing the transporter with liposomal creatine restores the programme (Supp. 4e). | Evidence is one experiment at n = 4 per cell, unblinded, with 67 % power for full blockade. There is no SLC6A8 pharmacology. Brain also loads creatine (Fig. 4a/4c), so any strategy must be MK-selective. Deleting SLC6A8 does not lower baseline metastasis. |
| **Backup 1** | **Platelet GPVI (Gp6)** | This is the most consistent downstream effector across species. In mice, Gp6 mRNA rises 2.8–42× in all six creatine-treated wild-type MK qPCR panels, and STAT5 occupancy at the Gp6 promoter increases. In humans, GP6 protein rises 2.6× by day 14 (4/4 volunteers) and collagen-induced aggregation rises 2.5× (9/11; q = 0.03). GPVI is platelet-restricted and is the natural pharmacological handle. | It has **no causal test**. Its rise is correlative. |
| **Backup 2 (conditional)** | **STAT5B (MK)** | It has the richest mechanistic detail: the S127A mutant blunts creatine-induced phosphorylation, creatine increases promoter occupancy, and an inhibitor and a knockout both blunt the programme. A mouse line and a tool compound already exist. | Its only in vivo efficacy panel (Fig. 6b) shares 6 animals with Supp. 2d. The phosphoproteomic nomination is not FDR-significant (q = 0.25–0.37). Canonical pY694/699 is undetectable in MKs. The Stat5b knockout has no metastasis endpoint and no knockout-vehicle arm. |

**What we do not take forward now**

- **CKB.** All functional evidence is in vitro. Brain CKB greatly exceeds MK CKB (Fig. 4b).
- **P2Y12.** Humans show no ADP hyper-reactivity on any of 3 metrics at any time point.
- **COX-1/aspirin.** The only supporting panel is Supp. 2d, which is compromised. The human arachidonic-acid (AA) response is not significant after correction.
- **Tumour-cell SLC6A8.** Knocking it down does not change the creatine effect (Fig. 1f, interaction p = 0.44).

**What the slot buys.** One study (Study A, §4.1) delivers four answers:

1. Whether the MK-SLC6A8 result holds up under blinding, in both sexes and in two tumour models.
2. Whether the platelet carries the SLC6A8-dependent phenotype.
3. Whether GPVI loss-of-function removes the creatine increment. This decides whether GPVI is promoted.
4. Whether stopping creatine reverses the risk. This decides whether a drug is needed at all.

The core study uses about 130 tumour-bearing mice; optional modules bring the total to about 215.

**Gate 0 (before the slot, no animals, 2–4 weeks).** This is source-data reconciliation (§4.0). It determines whether *any* in vivo evidence exists for STAT5 inhibition or for aspirin.

---

## 2. Evidence base, and how it was derived

**How the numbers were re-derived**

- Every two-group P value reported in the workbook reproduced exactly with an unpaired Student's t-test. The arithmetic is therefore sound; the disagreements below come from *choice of analysis*.
- "Effect abolished" claims were re-tested as **creatine × perturbation interactions** (two-way ANOVA on log scale, plus a negative-binomial model for foci). The workbook uses separate pairwise Tukey tests, which cannot establish abolition.
- qPCR was re-analysed on the ΔCT scale.
- Human data were re-analysed as **paired, repeated measures** on log fold-change with Benjamini–Hochberg (BH) control. The workbook analysed them as independent groups.
- The phosphoproteome was re-analysed with FDR.

### 2.1 The phenotype is real, large and reproducible

![Fig. 1 — creatine/vehicle ratio of lung metastatic burden in every experiment.](figures/fig1_forest_creatine_effect.png)

- **Every one of 12 experiments is individually positive** (Fig. 1b, 1f, 1k, 3i, 6b; Supp. 1e, 1f, 1g, 1i, 1k, 2d; 7g).
- Across the 9 mouse experiments with clean provenance, the fixed-effect pooled creatine/vehicle ratio for metastatic burden is **2.75× (95 % CI 2.44–3.11)**, with I² = 0.49. Individual experiments range from 2.1× to 4.3×.
- Lung weight (1.2–1.6×), foci (1.5–3.0×) and lung SUV on PET (1.7–2.1×) move in the same direction.
- Oral gavage and a 5 % creatine diet both work (Supp. 1i: 3.5×).
- **Survival.** The shift is modest: median 22 vs 19 days, HR 2.8 (0.98–7.8), log-rank p = 0.032 (Fig. 1c). In the second model it is 16 vs 14 days, HR 2.1 (1.1–4.1), p = 0.011 (Fig. 1l). No censoring is recorded.
- **Mechanistic clue.** Creatine does not change initial tumour-cell arrest in the lung (0.25 h: 0.85×, p = 0.31). It increases retention at 6, 12 and 24 h (1.5×, 1.8×, 2.8×; p = 0.0002–0.03; Fig. 1h). The effect therefore acts on early post-arrest seeding, which is where the lung platelet signal also rises (PKH⁺ platelet area 2.4×, Fig. 2j; field-level data).
- **Systemic confounders were checked.** Food and water intake (Supp. 1b/1c), body weight (Supp. 1a; p = 0.08 at day 7, n = 4), blood counts (Supp. 3a), platelet count and indices (Fig. 2a) and MK maturation transcripts (Supp. 3c) are unchanged.
- **Exposure parity with humans.** In mice, creatine raises serum creatine from 66–89 µM to 179–239 µM (Supp. 1d, 1h; Fig. 3b). In volunteers taking 20 g/day, it rises from 45 µM to 153–159 µM (Fig. 7b; 11/11 volunteers; paired p < 10⁻⁷). The mouse regimen is therefore at, or modestly above, human loading-dose exposure.

**Caveats.**

- Allocation and readout were unmasked, and there was no sample-size calculation.
- Sex and strain are confounded with model: male C57BL/6J versus female BALB/cJ.
- All models appear to be experimental (intravenous) metastasis models.
- Effect sizes from unblinded small studies tend to shrink. Power calculations below therefore assume 2.5×, not 2.75×.

### 2.2 The locus is the megakaryocyte: SLC6A8-dependent creatine uptake

| Test | Result (re-analysed) | Panel |
|---|---|---|
| Does the tumour need its own SLC6A8? | **No.** The creatine effect is 3.5× with sh-scrambled tumours and 3.2× with sh-Slc6a8 tumours. Interaction: p = 0.44 for burden, 0.60 for foci (NB p = 0.57). *Caveat:* knockdown is shown at mRNA (18 % residual, Supp. 2a) but the protein blot shows no clear loss. | Fig. 1f, Supp. 2a |
| Does MK deletion change systemic exposure? | **No.** Serum creatine rises 2.7× in WT and 2.4× in KO (interaction p = 0.18). | Fig. 3b |
| Does MK deletion stop MKs loading creatine? | **Yes.** MK creatine rises 5.3× in WT (13.7→72.1 µmol/g) but only 1.5× in KO (13.7→21.1). Interaction p = 0.045; n = 3. | Fig. 3c |
| **Does MK deletion stop creatine-driven metastasis?** | **Yes.** Burden: 3.35× in WT (p = 0.001) vs 0.85× in KO (p = 0.53); **interaction p = 0.0003** (log scale 0.0009). Foci: 1.90× vs 0.93×; **interaction p = 0.004** (NB 0.002). Lung weight: 1.21× vs 1.01×; interaction p = 0.0002, but see the variance caveat below. | **Fig. 3i** |
| Does it stop the MK transcriptional programme? | **Yes.** The median residual is about 1 % of the log-scale creatine response across 11 genes; 7/11 genes have interaction p < 0.05. See the caveats in §3. | Fig. 3f |
| Is the KO simply unable to respond? | **No.** Liposomal creatine, which bypasses the transporter, induces 9/11 programme genes 2.1–4.0× in KO MKs. Free creatine does not; only Itga2b and Adra2a move, and by ≤ 1.5×. The trigger is intracellular creatine. | Supp. 4e |
| Platelet-level readouts | The α-granule gain is lost (interaction p = 0.006, but the unit is microscope fields). Platelet count is unaffected (Supp. 4b). The aggregation gain is lost (Fig. 3d), but see §3: there is paradoxical *lowering* in the KO and implausibly low variance. | Supp. 4c, 4b; Fig. 3d |

**Limits of the SLC6A8 case.**

- **One small experiment.** Fig. 3i is a single experiment at n = 4 per cell. With the pooled between-mouse SD (0.42 log units), it had 67 % power to detect complete blockade and 23 % to detect 50 % blockade. The small p-values reflect a large effect, not a precise estimate.
- **No effect on baseline.** Deletion lowers baseline platelet reactivity (Fig. 3d) but **not baseline metastasis**: KO-vehicle burden is 3.39 vs 2.36 in WT-vehicle, and foci are 26.5 vs 29.75. The axis governs the creatine *increment* only.
- **Off-target tissue loading.** Creatine loading also raises brain creatine by 19 % and brain phosphocreatine by 95 % (Fig. 4a/4c). Any intervention at this node must be MK-selective, or must be shown to be tolerable; this package cannot judge which.
- **Incomplete deletion and unconfirmed Cre specificity.** SLC6A8 protein deletion in KO MKs looks partial (Supp. 4a). Pf4-Cre lineage specificity in our colony is not documented.
- **Atypically tight lung weights.** In Fig. 3i, lung-weight CVs are 2.7–4.3 % per group, against 6–34 % in every other in vivo experiment. The burden and foci endpoints have typical variance (log-SD 0.18–0.45), so the case rests on them. The lung-weight p-value should not be leaned on, and the provenance of the panel is checked in G0-7.

### 2.3 Downstream nodes: how much of the creatine response each one carries

![Fig. 2 — residual creatine response after each perturbation (left); metastasis interaction (right).](figures/fig2_node_blockade.png)

| Node and perturbation | Transcriptional programme: median % of log response remaining (genes with interaction p < 0.05) | Metastasis endpoint | Strength |
|---|---|---|---|
| SLC6A8, MK deletion in vivo (Fig. 3f/3i) | **~1 %** (7/11) | **Abolished, interaction p = 0.0003** | Tier 1 |
| STAT5, inhibitor in vitro (Fig. 6a) | 11 % (9/11). However, the inhibitor also *lowers baseline* expression of 8/11 genes by 0.5–2.2 log₂ units (e.g. Rab4a 0.21×, Gp6 0.39×), consistent with non-specific effects | Fig. 6b shows abolition (interaction p = 7×10⁻⁶) but **6/10 control-arm animals are duplicated** (§3) | Flagged |
| STAT5B, MK deletion in vivo (Fig. 6g) | 18 %, with **33–49 % remaining for P2ry12, Gp6, Gpiba, F2r and Adra2a**. No KO-vehicle arm, so genotype baseline is confounded | **Not tested** | Tier 2 |
| CKB, siRNA in vitro (Fig. 4j) | 41 % (10/11); knockdown is partial (Supp. 5b) | Not tested | Tier 2 |
| CKB, overexpression in vitro (Fig. 4l) | Induces the programme 1.7–6.0× (11/11) **without changing MK creatine or phosphocreatine** (Supp. 5c), which implies a non-metabolic role | Not tested | Tier 2 |

**Supporting mechanism around STAT5B**

- **Mutant phosphorylation.** Creatine raises the pan-phospho signal on WT STAT5B-FLAG 1.39× (p = 0.009, Fig. 5e) and 1.28× (p = 0.087, Fig. 5f), but not on S127A or on the triple-alanine (3A) mutant. The creatine × (WT vs S127A) interaction is p = 0.024 and 0.043.
  - The readout is a pan-phospho antibody, not a site-specific one.
  - S127D, a phosphomimetic that a pan-phospho antibody should not read, scores highest at baseline. This implies the signal reports *other* sites.
  - One FLAG blot is saturated.
- **Single blots.** Figs. 5g–5i add CKB-overexpression and si-CKB effects on WT versus S127A. They are unquantified single blots.
- **Promoter occupancy (ChIP).** Creatine increases STAT5 occupancy at promoters but not exons (region × creatine interaction p = 0.0005–0.024 for the responsive regions):
  - P2ry12: −0.2 kb 12×, −1 kb 4.6×, −2 kb 4.8×
  - Gp6: −1 kb 3.8×, −0.2 kb 2.9×, with −2 kb unchanged
  - Rab4a: −0.2 kb 5.5×, −1 kb 2.7× (Fig. 5j, Supp. 6i)
  - The cell type used for ChIP is not recorded in the conventions. Duplicated ChIP values were checked: all 72 values lie on the 0.005-log₂ grid produced by 2-decimal Ct values, so coincidences are expected. This is **not** an integrity flag.
- **Canonical activation is absent.** STAT5A/B pY694/699 is **undetectable** in MKs with or without creatine, while the Jurkat + IL-2 positive control works (Supp. 6a). As far as these data show, creatine does not act on STAT5B through canonical tyrosine phosphorylation. Any STAT5 pharmacology must therefore be shown to act on the creatine-induced activity.
- **Uptake is intact without STAT5B.** Stat5b-KO MKs take up creatine normally (95 vs 98 µmol/g; Fig. 6e) and still induce CKB (Fig. 6f). STAT5B therefore sits downstream of uptake.

### 2.4 Human concordance: which effector translates

Cohort: 11 healthy volunteers (6 F, 5 M, aged 20–25, single ancestry), open-label, 20 g/day for 14 days, no placebo arm. Four volunteers were used for the molecular readouts.

![Fig. 3 — human platelet function, fold change versus each volunteer's own day 0 (paired, log scale; BH over 36 tests).](figures/fig3_human_platelet_function.png)

**Platelet function at day 14 (Fig. 7c; paired log-FC; BH q across all 36 tests)**

| Agonist | Result | Adjusted significance |
|---|---|---|
| **Collagen** (GPVI pathway) | Maximal aggregation **2.5×** (9/11 up), average aggregation 2.7×, adhesion 1.7× | q = 0.033, 0.066 and 0.16 |
| **Epinephrine** (α2A pathway) | Adhesion **2.1× (11/11)**, average aggregation 1.8× (11/11), maximal aggregation 1.6× (10/11). Already partly present at day 7 (1.3–1.8×). | q = 0.032–0.033 |
| AA (COX-1 pathway) | 1.3–1.8× | q ≥ 0.13 |
| **ADP (P2Y12 pathway)** | **1.07–1.17×, with only 5–6/11 up** | q ≥ 0.70 |

**Platelet protein (Fig. 7e, n = 4, paired)**

- **GP6:** 2.0× at day 7 (4/4 up, p = 0.044) and **2.6× at day 14 (4/4, p = 0.022)**.
- **P2RY12:** a smaller but uniform rise, 1.3–1.65×, 4/4 up at every time point (p = 0.018–0.033). It has no functional ADP correlate.

**CD41⁺ cell transcripts (Fig. 7d, n = 4; fold change at day 7)**

- ADRA2A 20.5× (4/4, p = 0.0005)
- GPIBA 10.6× (4/4, p = 0.016)
- **GP6 6.9× (4/4, p = 0.054)**
- F2R 6.3× (4/4, p = 0.03)
- P2RY12 3.0× (3/4)
- Most genes fall back toward baseline by day 14. **RAB4A falls to 0.36× by day 14 (4/4, p = 0.002)**, opposite to the mouse, where it is a claimed STAT5 target. Cross-species concordance is therefore partial.

**Transfer to mice (Fig. 7g).** Day-7 human platelets raise mouse metastatic burden 2.8× compared with day-0 platelets (p = 0.014; n = 5 recipients per group). The number of donors and the recipient strain are not recorded, so the unit of inference is recipient mice, not donors.

![Fig. 4 — GP6 and P2RY12 platelet protein per volunteer, and CD41⁺ transcripts at day 7.](figures/fig4_human_molecular.png)

**Reading.** The human phenotype centres on **GPVI/collagen** and **α2A/epinephrine**, not P2Y12/ADP or COX-1/AA. This is why GPVI, not P2Y12, is the backup effector. α2A is the strongest human signal. However, in mice its dependence on the axis is inconsistent:

- 68 % of its response remains after SLC6A8 deletion;
- 77 % remains after si-Ckb;
- liposomal creatine does not induce it.

Epinephrine reactivity is therefore carried as a biomarker, not as a target.

### 2.5 Candidate scorecard

Tier 1 = causal, in vivo, metastasis endpoint, clean provenance. Tier 2 = causal mechanistic evidence without a metastasis endpoint. Tier 3 = correlative.

| Criterion | MK SLC6A8 | GPVI | STAT5B | CKB | P2Y12 | COX-1 (aspirin) | Tumour SLC6A8 |
|---|---|---|---|---|---|---|---|
| Causal in vivo, metastasis endpoint | **Yes, Tier 1** (Fig. 3i) | None | Flagged (Fig. 6b) | None | None | Flagged (Supp. 2d) | **Negative** (Fig. 1f) |
| Genetic loss-of-function in vivo | Yes (MK-restricted) | No | Yes, but no metastasis endpoint and no KO-vehicle arm | No | No | No | shRNA (protein loss unclear) |
| Mechanistic coherence | Uptake → programme → platelet; liposomal bypass | Downstream read-out of every node | S127 mutants, ChIP; pY absent | Necessary and sufficient in vitro | Induced; ChIP | — | — |
| Human concordance | Exposure reproduced; human platelets transfer the phenotype | **Strong** (protein, function) | None measured | None measured | **Discordant** (no ADP effect) | Weak (AA, q ≥ 0.13) | — |
| Data-integrity flags | Supporting panels (3f, 3d) | Minor (3f) | **Critical** (6b) | None | — | **Critical** (Supp. 2d) | KD blot |
| Tools in hand | Floxed line | None in package | Line + inhibitor | None in vivo | — | Aspirin | — |
| Liability visible in package | Brain loads creatine | None measured | None measured | Brain CKB ≫ MK CKB | — | — | — |

**Why this ranking**

- **STAT5B is not primary.** Its case rests on in vitro mechanism and one in vivo panel that cannot currently be trusted. Canonical activation is absent and the screen that nominated it is null at FDR. Choosing it would commit the slot to a target whose key in vivo evidence may not exist.
- **GPVI is not primary.** It is the most tractable and human-anchored candidate, but the package never tests it causally. Its rise could be one of many co-induced receptors rather than the mediator.
- **SLC6A8 is primary.** It is the only node where a clean in vivo loss-of-function on the metastasis endpoint exists. The slot can confirm it rigorously *and*, in the same animals, generate the causal GPVI result that would promote the backup.

---

## 3. Data-integrity and analysis findings that change the weighting

| # | Finding | Where | Impact on decision | Action |
|---|---|---|---|---|
| **1** | **Six animals appear in two different experiments.** In Fig. 6b (STAT5 inhibitor), vehicle mice 2–4 and creatine mice 2–4 are identical, value for value and in the same order, to Supp. 2d (platelet transfer ± aspirin) vehicle-donor and creatine-donor mice 4–6. This covers both burden (6–7 significant figures) and foci counts. No other in vivo panel shares a run of ≥ 3 values. Numerically, the STAT5i interaction survives excluding these animals (p = 0.014 with n = 2 per control arm), but the problem is *provenance*, not n. | Fig. 6b ↔ Supp. 2d | **Removes the only in vivo evidence for STAT5 inhibition and for aspirin** until it is resolved. This is the main reason STAT5B is not primary. | Gate 0 |
| 2 | The phosphoproteome does not nominate STAT5B at FDR. There are 5,812 phosphopeptides, n = 3 per group. **1,702 (29 %) have p = 0.42265 exactly**, which is Welch t = 1 with df = 2: a peptide detected in a single sample (also inconsistent with the stated Student's test). Among the rest, 238 have p < 0.05 against 205 expected by chance (π₀ ≈ 0.95). **No peptide reaches q < 0.05.** The Stat5b peptide ranks 17th (p = 0.0012, log₂FC 5.7). Its reported q is 0.25, deflated by the artefact rows; BH gives 0.27–0.37. A ~52-fold change suggests on/off detection. The phosphosite is not recorded in the file, so the link to S127 cannot be verified. | Phospho file | STAT5B is a hypothesis, not a screen hit. | Gate 0 |
| 3 | Canonical STAT5 activation (pY694/699) is undetectable in MKs ± creatine. | Supp. 6a | There is no evidence of canonical activation, so any STAT5 tool pharmacology needs proof of target engagement. | Study C design |
| 4 | **Fig. 3f qPCR anomalies.** (a) Two within-group replicate pairs carry identical *unrounded* ΔCT values: Gp6 KO-vehicle 0.9206886291503906 and Fcgr2a KO-creatine 12.345218658447266. (b) The control ΔCT scale is 13–19 cycles off the other in vivo MK panels for the same genes (e.g. Gp6 +1.5 vs −15.4 and −12.9; Fcgr2a +10.3 vs −8.9). Under the workbook's 2^ΔCT convention, this implies targets up to ~1,000× more abundant than Actb. (c) Of the eight genes exported at full precision, only the WT-creatine ΔCT values deviate (by ~10⁻¹⁴) from the float32 values an instrument export produces. This suggests they came through a different calculation path. | Fig. 3f | Weakens one *supporting* SLC6A8 panel. The SLC6A8 metastasis result (3i) is unaffected. | Raw Ct export |
| 5 | Human CD41⁺ qPCR: volunteer 4's PITPNB "ΔCT" values are +26 to +28, i.e. raw-Ct magnitude. Volunteer 4's PITPNB and RAB27B normalised values cannot be reproduced from the recorded ΔCTs; RAB27B at day 14 is reported as 2.36× against 0.49–0.59× recomputed, so the direction flips. All other cells reproduce. Volunteer 2's day-0 ΔCTs differ from the other three volunteers by 3–4 cycles for 6 genes. | Fig. 7d | Exclude these cells; human transcript evidence rests on n = 3–4. | Gate 0 |
| 6 | Aggregometry is implausibly regular. All 6 Fig. 2b triplicates are exact arithmetic progressions centred on their means. All 36 Fig. 3d values are even integers, with within-group SD ≈ 1–2 percentage points across animals. In Fig. 3d, creatine *lowers* aggregation below vehicle in the Slc6a8 KO (ADP 54→31 %, p < 0.001), which is not explained. TEG shows only MA at p = 0.049 (Mann–Whitney p = 0.095). | Fig. 2b, 3d, 2d | Mouse platelet-function evidence is weak. The human aggregation data carry the functional case. | Raw traces |
| 7 | **Pseudo-replication.** n is "8 random fields per group", so p-values are overstated and the number of mice is unknown. | Fig. 1i, 2c, 2j, Supp. 4c | These are used qualitatively only. | Re-analyse per mouse |
| 8 | Human analyses treated paired data as independent groups, and Fig. 7c included the day-0 column (all 1.0, zero variance) in a Dunnett ANOVA. | Fig. 7b, 7c, 7e, Supp. 8a | Replaced by paired analyses (§2.4). Conclusions hold for collagen and epinephrine, fail for ADP, and are weaker for AA. | Done here |
| 9 | Study design: allocation and readout unmasked; no sample-size calculation; sex not analysed and confounded with strain and model; creatine timing relative to tumour challenge not recorded. | Conventions | Expect effect-size inflation; Study A fixes all of these. | Study A |
| 9b | **Fig. 3i lung weights are unusually tight:** group CVs are 2.7–4.3 %, against 6.4–34 % in all other in vivo panels. Burden and foci variance are typical. | Fig. 3i | Rely on burden and foci; lung weight is supportive only. | G0-7 |
| 10 | Minor labelling issues: the Fig. 4d axis reads "Creatinine" although the assay is a creatine kit; "ADAR2A" should be ADRA2A (Fig. 7d); a Fig. 1f Tukey row reads "si-Slc6a8" in an shRNA experiment. | — | None | Correct in record |

Two further checks found **no problem**. Duplicated ChIP values and duplicated human serum creatine values (155.923 and 160.168 µM) are both explained by measurement discretisation. No other cross-panel duplication exists among values with ≥ 5 significant figures or among runs of ≥ 3 foci counts.

![Fig. 5 — phosphoproteome diagnostics.](figures/fig5_phosphoproteomics.png)

![Fig. 6 — the Fig. 6b / Supp. 2d overlap.](figures/fig6_duplication_6b_vs_S2d.png)

---

## 4. Proposed studies

**Indication logic.** Every model in the package reads out lung metastasis. The 15-minute lung signal in Fig. 1h indicates intravenous (experimental) seeding, and the creatine effect acts at the early-seeding step. The clinical hypothesis is therefore prevention of haematogenous metastasis in patients with high-risk primary tumours who are exposed to supplemental creatine. No perturbation lowers baseline metastasis, so creatine exposure defines the population. Melanoma is the first indication because it is the model used for the tumour-SLC6A8 test (Fig. 1f). The studies below progress from mouse confirmation (A–C), to human mechanism (H1), to patient scoping (H2).

### 4.0 Gate 0: source-data reconciliation (weeks 0–4, no animals)

| Item | Deliverable | Decision it controls |
|---|---|---|
| G0-1 | Trace the six shared animals (IDs, cage cards, dosing and imaging files) for Fig. 6b and Supp. 2d, and re-issue both panels from source. | Whether STAT5i or aspirin has *any* in vivo evidence; the Study C trigger |
| G0-2 | Raw Ct exports for all qPCR panels, especially Fig. 3f: the duplicated replicates, the ΔCT sign convention and reference gene, and the provenance of the WT-creatine values. Also Fig. 7d volunteers 4 and 2. | Weight of the transcriptional evidence |
| G0-3 | Peptide-level phosphoproteomics with site localisation for the Stat5b peptide (is it S127?), per-sample intensities and missingness; re-analysis with missing-value-aware statistics. | Whether STAT5B S127 is a real hit |
| G0-4 | Raw aggregometry and TEG traces (Fig. 2b, 2d, 3d); image files with mouse IDs for Fig. 1i, 2c, 2j and Supp. 4c, re-analysed per mouse. | Mouse platelet-function evidence |
| G0-5 | Records: tumour line for each panel; creatine start relative to challenge; sex per panel; genetic background and Cre specificity of both floxed lines; Fig. 7g donor count and recipient strain. | Feasibility and design of Study A |
| G0-6 | Colony check: enough Pf4-Cre;Slc6a8 littermates of both sexes by week 4. Slc6a8 is X-linked, so males are fl/Y; align nomenclature and dosage with the records. | Slot start date |
| G0-7 | Provenance check of the cornerstone panel, Fig. 3i: animal IDs, genotyping, littermate status, tumour line and image files. This gets the same scrutiny as G0-1. | Whether the primary recommendation stands as written |

### 4.1 Study A (the slot): confirm MK-SLC6A8, test GPVI head-to-head, test reversibility

**Objectives**

1. Confirm that MK creatine uptake is required for creatine-driven metastasis, under blinding, in both sexes and in two models.
2. Establish whether the platelet carries the SLC6A8-dependent phenotype.
3. Test GPVI loss-of-function against the same shared controls.
4. Test whether stopping creatine reverses the risk.

**Populations**

- Adult (8–12 weeks) Pf4-Cre;Slc6a8^fl/fl^ (fl/Y) mice and littermate Pf4-Cre;Slc6a8^+/+^ controls, both sexes, balanced.
- Background must be confirmed (G0-5). Syngeneic tumour models must match it, so the BALB/cJ model cannot be used unless the line is on that background.

**Indications and models**

- **Model 1:** the melanoma lung-metastasis model used in Fig. 1f.
- **Model 2:** a second, non-melanoma histology syngeneic to the line's background. This is replication only.
- Experimental (intravenous) metastasis is primary, because it matches the existing data and the early-seeding mechanism (Fig. 1h).
- A spontaneous metastasis model (orthotopic primary with resection), which is closer to the adjuvant clinical setting, is Stage 2.

**Exposure and comparators**

- A short exposure-bridging pilot (vehicle plus 3 dose levels, n = 4 each) selects a gavage dose that reproduces **human loading-dose serum creatine (~155 µM, Fig. 7b)**. The current regimen gives 179–239 µM.
- All arms are challenged on day 21.

| Arm | Model 1 | Model 2 | Purpose |
|---|---|---|---|
| A1 WT + vehicle (water gavage) | 12 | 12 | Reference |
| A2 WT + creatine, days 0–endpoint | 12 | 12 | Replicate the creatine effect |
| A3 KO + vehicle | 12 | 12 | Genotype baseline |
| A4 KO + creatine | 12 | 12 | **Primary contrast, via the interaction** |
| A5 WT + creatine days 0–14, vehicle from day 14 (**cessation**) | 12 | — | Reversibility (7 days off creatine before challenge) |
| B1 WT + vehicle + GPVI loss-of-function | 12 | — | GPVI baseline |
| B2 WT + creatine + GPVI loss-of-function | 12 | — | **GPVI head-to-head, via the interaction with A1/A2** |

- Each cell is 6 females and 6 males, randomised within litter and sex.
- Dosing solutions are coded by a third party, and all readouts are blinded.
- Core total: 132 tumour-bearing mice.
- In model 1, arms A1 and A2 also receive the module-B control reagent (e.g. isotype or vehicle), so that B1/B2 are compared against matched controls.
- GPVI tool requirement: it must remove surface GPVI and collagen responsiveness *without* changing platelet count. Count is a mandatory covariate. If no qualified tool is ready by week 4, arms B1/B2 move to Study B, and the core is 108 mice.

**Modules (recommended if capacity allows)**

- **Platelet transfer (48 mice).** Donors: WT-vehicle, WT-creatine and KO-creatine, 6 donors each. Recipients: 10 per donor group, each receiving platelets from a single donor. The **donor** is the unit of inference, which avoids the donor-versus-recipient unit problem in Fig. 7g and Supp. 2d.
- **Pharmacodynamic (PD) satellite without tumour (20 mice; A1–A4 × 5).**
  - MK creatine and phosphocreatine, and MK CKB;
  - platelet surface GPVI, P2Y12 and α2A;
  - aggregation panel: collagen, epinephrine, ADP, thrombin, AA;
  - α-granules per platelet, scored per mouse;
  - **brain and muscle creatine and phosphocreatine**, to document that MK-restricted blockade spares them.
- **Exposure bridging (16 mice).**
- **Alternative configuration.** If G0-1 and G0-3 clear STAT5B before week 4, Study C (48 mice) can replace module B inside the same slot. GPVI would then move to the next slot.

**Endpoints**

- **Primary:** lung metastatic burden (% area), by blinded automated image analysis, per mouse.
- **Estimand:** the fraction of the log-scale creatine effect that remains in the perturbed genotype or treatment (KO/WT; GPVI-LoF/control; cessation/continuous).
- **Key secondary:** metastatic foci (negative-binomial model), lung weight, and early lung retention at 6–24 h (optional satellite).
- **Mechanistic:** serum creatine; platelet GPVI and P2Y12 density; collagen and epinephrine reactivity (the human-concordant readouts), with ADP as a negative control.
- **Safety:** platelet count and indices, TEG or bleeding readout, body weight, and food and water intake.

**Sample size**

- Pooled between-mouse SD is 0.42 natural-log units (9 clean experiments); the assumed effect is 2.5× (a deflated version of 2.75×).
- **SLC6A8 interaction, pooled across models (n = 24 per cell):** ≥ 98 % power for 75 % attenuation and 75 % power for 50 % attenuation. If SD is 0.50, power for 75 % attenuation is 91 %.
- **Per-model and module contrasts (n = 12 per cell):** 96 % power for complete abolition, 92 % for 90 % attenuation and 79 % for 75 %.
- For comparison, the original Fig. 3i (n = 4) had 67 % power for complete abolition.

**Analysis plan (pre-registered)**

- Linear mixed model on log(burden) with creatine × genotype (or × GPVI-LoF), plus sex and model as fixed effects and litter or batch as a random effect.
- Negative-binomial mixed model for foci.
- Hierarchical testing: burden first, then foci, then lung weight.
- Sex × creatine interaction reported as exploratory.
- Exclusion rules fixed in advance; all randomised animals reported.

**Timeline (13 weeks)**

| Weeks | Activity |
|---|---|
| 0–4 | Gate 0; exposure-bridging pilot; GPVI tool qualification; cohort assembly |
| 4–7 | Creatine or vehicle from day 0; arm A5 switches to vehicle on day 14; tumour challenge on day 21 |
| 7–10 | Metastasis endpoint; PD satellite and transfer module run in parallel |
| 10–12 | Blinded image and PD analysis |
| 13 | Unblinding, pre-specified analysis, committee read-out |

**Go / no-go for the primary target (pre-specified)**

| Outcome | Criteria | Consequence |
|---|---|---|
| **GO: MK-SLC6A8 confirmed** | (i) WT creatine effect ≥ 1.8× with 95 % CI excluding 1, same direction in both sexes and both models; (ii) residual in KO ≤ 25 %, interaction p < 0.05, upper 95 % bound ≤ 60 %; (iii) MK creatine loading abolished, with brain and muscle creatine unaffected by genotype; (iv) KO-creatine donor platelets transfer ≤ 25 % of the WT-creatine donor effect. | Next: MK-selective or pharmacological SLC6A8 feasibility, and a therapeutic-timing study. |
| **HOLD** | Residual 25–60 %. | Look for other lineages (Cre specificity) or host cells. |
| **NO-GO, program pause** | WT creatine effect < 1.5× or CI including 1 under blinding. | The premise fails. |
| **NO-GO, SLC6A8 demoted** | Residual ≥ 60 %. | SLC6A8 is not the primary route. |

### 4.2 Study B: GPVI, if not run inside Study A

- **Population and indication:** wild-type adult mice of both sexes; model 1 (melanoma, experimental lung metastasis), then model 2.
- **Comparators:** a 2 × 2 of creatine/vehicle × GPVI loss-of-function/matched control (isotype or wild-type), n = 12 per cell, randomised and blinded. If G0-1 clears Supp. 2d, add aspirin as an active comparator arm.
- **Primary endpoint:** lung metastatic burden; estimand as in Study A (fraction of the creatine effect remaining under GPVI loss-of-function).
- **Readouts:** foci, lung weight; collagen-response ablation and surface GPVI loss (target engagement); platelet count (mandatory covariate); epinephrine and ADP reactivity; bleeding and TEG safety.
- **Promotion rule:** see §5.

### 4.3 Study C: STAT5B (triggered by Gate 0 or by a Study A GO)

- **Population and indication:** adult Pf4-iCre;Stat5b^fl/fl^ mice and littermate Pf4-iCre;Stat5b^+/+^ controls, both sexes; model 1.
- **Comparators:** genotype × creatine/vehicle, n = 12 per cell. This adds the **missing KO-vehicle arm**.
- **Primary endpoint:** lung metastatic burden, with the same estimand and analysis as Study A.
- **In-vivo PD in MKs:**
  - orthogonal, site-specific quantification of creatine-induced STAT5B S127 phosphorylation, n ≥ 5 per group;
  - promoter occupancy at Gp6 and P2ry12;
  - baseline expression effects.
- **Pharmacology arm:** STAT5-IN-1 at the Fig. 6b dose (5 mg/kg daily, oral) with target-engagement readouts. The in vitro data show substantial baseline suppression (Fig. 6a), so on-target specificity must be demonstrated.

### 4.4 Human H1: randomised, double-blind, placebo-controlled mechanistic study

- **Population:** healthy adults aged 18–65, both sexes balanced, mixed ancestry (stratified). The existing cohort was 20–25-year-olds of one ancestry. Exclusions: antiplatelet, NSAID and anticoagulant use.
- **Arms (n = 30 each):**
  - placebo, taste-matched;
  - loading plus maintenance: 20 g/day for 7 days, then 5 g/day to day 28;
  - maintenance only: 5 g/day for 28 days, a lower maintenance-type dose that this package has not tested.
- **Washout:** 28 days, to test reversibility.
- **Primary endpoint:** change in collagen-induced maximal aggregation at day 14, creatine versus placebo (log ratio to own baseline).
- **Key secondary endpoints:**
  - platelet surface GPVI density;
  - epinephrine aggregation and adhesion;
  - **ADP response as a pre-specified negative control**, expected to be null;
  - serum creatine (exposure–response);
  - platelet transcript panel (GP6, ADRA2A, P2RY12, RAB4A);
  - time to normalisation after washout.
- **Power:** 30 per arm gives 90 % power to detect a 2-fold collagen difference (observed SD 1.17 log₂), and ≥ 99 % for 2-fold and 82 % for 1.5-fold on epinephrine adhesion (SD 0.77).
- **Analysis:** paired and mixed models on log scale; no normalise-to-1 ANOVA.

### 4.5 Human H2 (later, if A and H1 are positive): indication scoping

- **Design:** an observational cohort of patients with resected, high-risk tumours prone to haematogenous spread, starting with melanoma to match model 1.
- **Measures:** creatine-supplement use, serum creatine, and platelet GPVI and collagen/epinephrine reactivity.
- **Outcome:** distant-metastasis-free survival (long horizon).
- **Purpose:** defines the population in whom any intervention, or simple exposure advice, would matter.

### 4.6 Deprioritised, with reasons

- **CKB.** Evidence is in vitro only. Brain CKB ≫ MK CKB. The overexpression data imply a non-catalytic mechanism that would need a different modality. Revisit only through MK-restricted deletion after Study A.
- **P2Y12.** It is induced in mice, but human ADP reactivity is unchanged, so targeting it would not address the human phenotype.
- **COX-1/aspirin.** The single supporting panel (Supp. 2d) is compromised, and the human AA signal is not significant after correction. Reconsider only if G0-1 clears Supp. 2d; if so, include aspirin as an active comparator in Study B.
- **Tumour SLC6A8.** Fig. 1f shows no interaction.

---

## 5. What would elevate one choice over another

| Candidate | Elevates it | Demotes it | Source |
|---|---|---|---|
| **MK SLC6A8** (primary) | Study A GO criteria met; PD shows MK-restricted deletion spares brain and muscle creatine; KO-donor platelets do not transfer the phenotype | Residual ≥ 60 %; WT effect not replicated blinded; Cre found active outside the MK lineage; effect present only in one sex or one model | Study A, G0-5 |
| **GPVI** (backup 1) | GPVI loss-of-function leaves ≤ 25 % of the creatine increment (interaction p < 0.05) with platelet count unchanged; H1 shows collagen hyper-reactivity versus placebo at the **maintenance** dose. → **GPVI becomes the drug-program lead**, being tractable and linked to a biomarker, with SLC6A8 as the mechanistic anchor and patient-selection logic. | No attenuation. Or GPVI-LoF lowers metastasis equally with and without creatine (a general platelet target, not this mechanism). Or H1 shows no collagen effect versus placebo. | Study A module B or Study B; H1 |
| **STAT5B** (backup 2) | G0-1 clears Fig. 6b; G0-3 localises the phosphopeptide to S127 and it replicates at FDR; Study C gives ≥ 75 % attenuation with no baseline effect in KO-vehicle; pharmacology engages S127 in vivo → **co-primary**, as the most proximal transcriptional node | G0-1 fails; the KO leaves ≥ 50 % residual (already hinted for P2ry12, Gp6 and Adra2a in Fig. 6g: possible STAT5A redundancy, or a genotype baseline effect, since there is no KO-vehicle arm); the inhibitor's effects track baseline suppression | G0, Study C |
| **CKB** | An MK-restricted Ckb deletion abolishes the in vivo effect and a non-catalytic mechanism is defined | Brain-exposure liability cannot be designed out | Future |
| **Whole program** | Cessation arm A5 retains most of the risk, so the programming persists and a drug has value beyond exposure advice; H1 positive at the maintenance dose | **A5 shows ≤ 25 % residual:** stopping creatine suffices, and portfolio value shifts to patient guidance and a platelet biomarker rather than a drug | Study A, H1 |

---

## 6. Risks and open questions

- **Effect inflation.** All existing in vivo data are unblinded and small. Study A's criteria are set against a deflated effect, and a failure to replicate is an informative outcome.
- **Narrow indication.** No perturbation lowers *baseline* metastasis: not SLC6A8 deletion (Fig. 3i), not STAT5i alone (Fig. 6b, a flagged panel: 1.05×), and aspirin alone was not tested. The therapeutic proposition is currently limited to creatine-exposed patients. For them, the cessation arm and H1 decide whether a drug is needed at all.
- **Tractability of SLC6A8.** The package contains no SLC6A8 pharmacology, and brain creatine responds to loading. If Study A is positive but MK-selective intervention looks infeasible, GPVI becomes the practical target on the strength of the module B result.
- **Model generality.** Experimental metastasis bypasses intravasation, and the survival gains are a matter of days. Spontaneous-metastasis and survival cohorts are Stage 2.
- **Human generalisability.** The cohort was young, single-ancestry and open-label, with n = 4 for the molecular readouts. H1 addresses all of these.

---

## Appendix A. How the numbers were derived

- **Source.** Values were read cell by cell from the workbook (formula cells taken as cached values). Every reported two-group P value and t statistic reproduced with an unpaired Student's t-test. Welch and Mann–Whitney tests are given alongside in the tables.
- **In vivo factorials** (Fig. 1f, 3i, 6b; Fig. 3b, 3c, 3d; Supp. 4b, 4c):
  - OLS two-way ANOVA (type II) with a creatine × factor interaction, on raw and on log scale;
  - negative-binomial (NB2) regression for foci;
  - within-level creatine effects as ratios of means with t-tests.
- **Meta-analysis.** Log ratio of geometric means per experiment, with inverse-variance fixed-effect pooling over the 9 clean mouse experiments (Fig. 6b and Supp. 2d excluded as flagged; Fig. 7g excluded as human donors). Heterogeneity is reported as Cochran Q and I². The pooled within-group SD of log burden (0.418) feeds the power calculations: non-central t for the 2 × 2 interaction contrast, variance 4σ²/n.
- **Survival.** Log-rank test and Cox model; all animals treated as events because no censoring is recorded.
- **Mouse qPCR.**
  - The workbook's convention is used (expression ∝ 2^ΔCT).
  - t-tests are on ΔCT, fold change = 2^(mean ΔCT_trt − mean ΔCT_ctrl) with a 95 % CI, and BH correction within each panel and contrast.
  - Residual response = (creatine effect under perturbation) / (creatine effect intact) on the log₂ scale, with the interaction from a two-way ANOVA on ΔCT.
  - The authors' per-pair normalisation (each treated replicate divided by the same-index control) was compared and gives similar means.
- **Human data.**
  - Serum creatine: paired t and Wilcoxon tests, Friedman test.
  - Platelet function: one-sample t and Wilcoxon on log₂ fold change versus own day 0, with BH over all 36 agonist × metric × day tests (and separately over the 12 day-14 tests).
  - Protein: paired t and Friedman tests.
  - CD41⁺ qPCR: technical triplicates averaged per volunteer and day; ΔΔCT against own day 0; one-sample t across volunteers. The workbook's normalised values were checked against three computation routes; the "mean of linear 2^ΔCT" route reproduces every cell except volunteer 4's PITPNB and RAB27B.
- **Phosphoproteomics.** Rows with p = 0.42265 were identified as Welch t = 1, df = 2 (single-sample detections). Storey π₀ at λ = 0.5 was computed with and without those rows, and BH q-values were computed over all rows and over the remaining rows.
- **Integrity scans.**
  - All numeric cells with ≥ 5 significant figures were compared within and across sheets.
  - Runs of ≥ 3 consecutive foci counts were compared across all in vivo panels.
  - ΔCT values were tested for float32 representability, since instrument exports are float32.
  - ChIP and serum values were tested for measurement-grid discretisation.

## Appendix B. Panel ledger (what each panel contributes after re-analysis)

| Panel | What it shows | n / unit | Re-analysed result | Reliability |
|---|---|---|---|---|
| 1a–1c | Model A: lung weight, SUV, burden, foci, survival | 6/6 mice; survival 10/10 | Burden 3.3× (p = 0.0005); HR 2.8 | Unblinded |
| 1f | Tumour sh-Slc6a8 × creatine | 6 per cell | No interaction (p = 0.44) | Knockdown protein unclear |
| 1h | Early lung retention | 6/6 | 0.25 h n.s.; 6–24 h 1.5–2.8× | Unit of signal not recorded |
| 1i | GFP⁺ cells per field | 8 fields | 2.2× | Pseudo-replicated |
| 1j–1l | Model B | 6/6; survival 20/18 | Burden 2.25× (p < 0.001); HR 2.1 | Unequal survival n unexplained |
| 2a | Platelet count and indices | 3/3 | Unchanged | n = 3 |
| 2b | Aggregation (ADP, collagen, thrombin) | 3/3 | 1.2–2.2× | Implausibly regular |
| 2c | α-granules | 8 fields | 1.9× | Pseudo-replicated |
| 2d | TEG | 5/5 | Only MA p = 0.049 (Mann–Whitney 0.095) | Weak |
| 2e, 2g, 2i | GP6 and P2RY12 blots (platelets, MKs, in vitro) | Lanes | Up in MKs; not in platelets exposed in vitro | Qualitative; GP6 apparent MW varies between blots |
| 2f | MK programme in vivo | 3/3 | Gp6 5.6×; 10/11 genes p < 0.05 | OK |
| 2j | PKH⁺ platelet area in lung | 8 fields | 2.4× | Pseudo-replicated |
| 3b, 3c | Serum and MK creatine, Slc6a8 model | 5/5; 3/3 | Equal serum rise; MK loading lost in KO (interaction p = 0.045) | OK, n = 3 |
| 3d | Aggregation, Slc6a8 model | 3 per cell | Gain lost; paradoxical fall in KO | Implausibly regular |
| 3f, 3g | MK programme and blots, Slc6a8 model | 3 per cell | Programme lost (median residual ~1 %) | Anomalies (§3 #4) |
| **3i** | **Metastasis, Slc6a8 model** | **4 per cell** | **Interaction p = 0.0003 (burden), 0.004 (foci)** | **No duplication found; small n; lung weights atypically tight** |
| 4a–4c | MK and brain creatine, phosphocreatine, CKB | 3/3 | MK 3.0× and 3.9×; brain 1.19× and 1.95×; brain CKB ≫ MK CKB | OK |
| 4d–4f | In vitro MK creatine, Ckb mRNA, phosphocreatine | 3/3 | 3.6×, 1.8×, 5.4× | Label "creatinine" |
| 4g, 4h | Creatine vs exogenous phosphocreatine | 3/3 | Creatine induces the programme; phosphocreatine does not (lowers it) | OK |
| 4i, 4j | si-Ckb | 3 per cell | 41 % residual; 10/11 interaction | Partial knockdown |
| 4k, 4l; S5c | CKB overexpression | 3/3 | Programme 1.7–6×, with creatine and phosphocreatine unchanged | OK |
| 5e, 5f | STAT5B-FLAG mutants | 3 per cell | WT vs S127A interaction p = 0.024 and 0.043 | Pan-phospho readout; saturation |
| 5g–5i | CKB, S127A, nuclear STAT5B | Single blots | Qualitative | Unquantified |
| 5j; S6i | ChIP at P2ry12, Gp6, Rab4a | 3/3 | Promoter-specific gain | Cell type not recorded |
| 6a | STAT5i in vitro | 3 per cell | 11 % residual; baseline suppression | Specificity concern |
| **6b** | **STAT5i in vivo** | **5 per cell** | **Interaction p = 7×10⁻⁶** | **6 animals shared with S2d** |
| 6d–6g | Stat5b KO: deletion, uptake, protein, programme | 3 per cell | Uptake intact; programme 18 % residual | No KO-vehicle; no metastasis |
| 7b | Human serum creatine | 11 paired | 3.5× (11/11) | OK |
| 7c | Human platelet function | 11 paired | Collagen and epinephrine up at day 14 (q ≈ 0.03); ADP null | No placebo |
| 7d | Human CD41⁺ transcripts | 4 paired | ADRA2A, GPIBA, GP6, F2R up at day 7; RAB4A down at day 14 | Volunteer-4 cells invalid |
| 7e | Human GP6 and P2RY12 protein | 4 paired | GP6 2.6×; P2RY12 1.3–1.65× | n = 4 |
| 7g | Human platelets → mice | 5/5 recipients | 2.8× | Donors unrecorded |
| S1a–S1k | Intake, weight, serum creatine, extra models, diet | 4–10 | All positive | Unblinded |
| S2a | sh-Slc6a8 knockdown | 3/3 | mRNA 0.18× | Blot shows no clear loss |
| **S2d** | **Donor-platelet transfer ± aspirin** | **6 per arm** | **3.1×; aspirin abolishes** | **6 animals shared with 6b** |
| S3a, S3c | Blood counts; MK maturation genes | 5/5; 3/3 | Unchanged | OK |
| S4a–S4c | Slc6a8 deletion, platelet count, α-granules | — | Partial deletion; count unchanged; α-granule gain lost | Fields |
| S4e | Liposomal creatine bypass in KO MKs | 3/3 | Programme restored, 9/11 genes 2.1–4.0× | OK |
| S5a, S5b | Gatm/Gamt; CKB knockdown and overexpression blots | 3/3 | Endogenous synthesis unchanged | OK |
| S6a | pSTAT5 Y694/699 | Lanes | Undetectable in MKs; positive control works | Key negative |
| S7a, S7b | Platelet count under STAT5i and in Stat5b KO | 3/3 | Unchanged | OK |
| S8a–S8c | Human BMI and CBC; CD41 enrichment | 11; 3 | Unchanged; CD41⁺ fraction is MK/platelet-like | OK |

## Appendix C. Files in this bundle

- `CRE-MK-01_validation_proposal.md`, `.docx` and `.html`: this document.
- `figures/`: Figs. 1–6 above.
- `CRE-MK-01_reanalysis_tables.xlsx`: every re-analysis table (in vivo, factorial interactions, survival, platelet, qPCR by gene, node blockade, human function, protein and transcripts, phosphoproteomics, meta-analysis, power, integrity findings).
- `analysis_scripts/`: Python scripts that regenerate every number from the two source workbooks.
