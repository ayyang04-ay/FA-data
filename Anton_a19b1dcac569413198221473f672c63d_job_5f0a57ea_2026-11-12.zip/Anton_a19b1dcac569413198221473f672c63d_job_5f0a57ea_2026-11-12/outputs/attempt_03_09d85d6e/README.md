# CRE-MK-01 follow-up: validation proposal bundle

| File | What it is |
|---|---|
| `CRE-MK-01_validation_proposal.pdf` / `.docx` / `.html` / `.md` | The proposal for the portfolio committee. All four are the same content in different formats. |
| `figures/` | Figures 1–6 used in the proposal |
| `CRE-MK-01_reanalysis_tables.xlsx` | Every re-analysis table. The README sheet indexes the 26 tables. |
| `analysis_scripts/` | Python scripts that regenerate every number and figure from the two source workbooks. See `analysis_scripts/README.md`. |

**Recommendation:**

- **Primary target:** megakaryocyte SLC6A8.
- **Lead backup:** platelet GPVI.
- **Conditional backup:** STAT5B.

**Gate before the slot:** Fig. 6b and Supp. Fig. 2d share six animals. These must be traced to source records.
