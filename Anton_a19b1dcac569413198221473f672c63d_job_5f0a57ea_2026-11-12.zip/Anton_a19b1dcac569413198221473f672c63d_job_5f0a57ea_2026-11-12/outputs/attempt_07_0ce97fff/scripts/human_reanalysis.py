"""Human cohort re-analysis: Fig. 7b (serum creatine), 7c (platelet function, paired log-scale + BH), 7e (platelet protein, paired), S8b (CBC)."""
import sys; import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from load import col, wb
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
out=[]
# 7b
A=np.array([[float(x) for x in col('Fig. 7b',f'B{r}:E{r}')] for r in range(4,15)])
for j,d in [(1,3),(2,7),(3,14)]:
    out.append(dict(panel='7b serum creatine (uM)',endpoint='serum creatine',day=d,n=11,mean_day0=A[:,0].mean(),mean_day=A[:,j].mean(),ratio=A[:,j].mean()/A[:,0].mean(),paired_t_p=stats.ttest_rel(A[:,j],A[:,0]).pvalue))
# 7e
ws=wb['Fig. 7e']
for nm,r0 in [('GP6/beta-actin',4),('P2RY12/beta-actin',12)]:
    B=np.array([[float(ws.cell(row=r,column=c).value) for c in range(2,6)] for r in range(r0,r0+4)])
    for j,d in [(1,3),(2,7),(3,14)]:
        lr=np.log2(B[:,j]/B[:,0])
        out.append(dict(panel='7e human platelet protein',endpoint=nm,day=d,n=4,mean_day0=B[:,0].mean(),mean_day=B[:,j].mean(),ratio=np.mean(B[:,j]/B[:,0]),paired_t_p=stats.ttest_rel(B[:,j],B[:,0]).pvalue,log2_one_sample_p=stats.ttest_1samp(lr,0).pvalue,n_up=int(np.sum(lr>0))))
# S8b
for nm,r0 in [('PLT',4),('PCT',19),('MPV',33),('PDW',48)]:
    C=np.array([[float(x) for x in col('Supplementary Fig  8b',f'B{r}:E{r}')] for r in range(r0,r0+11)])
    out.append(dict(panel='S8b human CBC',endpoint=nm,day=14,n=11,mean_day0=C[:,0].mean(),mean_day=C[:,3].mean(),ratio=C[:,3].mean()/C[:,0].mean(),paired_t_p=stats.ttest_rel(C[:,3],C[:,0]).pvalue))
df=pd.DataFrame(out); df.to_csv('/tmp/outputs/analysis_tables/human_serum_protein_cbc_reanalysis.csv',index=False)
pd.set_option('display.width',220); print(df.round(4).to_string())
# 7c is produced by figs.py -> human_platelet_function_reanalysis.csv
