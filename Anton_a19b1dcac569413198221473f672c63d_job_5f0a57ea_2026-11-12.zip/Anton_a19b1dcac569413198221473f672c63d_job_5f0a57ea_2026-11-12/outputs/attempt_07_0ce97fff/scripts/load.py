import openpyxl
wb = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)
def col(sheet, rng):
    ws = wb[sheet]
    out=[]
    for row in ws[rng]:
        for c in row:
            if isinstance(c.value,(int,float)): out.append(float(c.value))
    return out
def rowvals(sheet, rng):
    return col(sheet, rng)
