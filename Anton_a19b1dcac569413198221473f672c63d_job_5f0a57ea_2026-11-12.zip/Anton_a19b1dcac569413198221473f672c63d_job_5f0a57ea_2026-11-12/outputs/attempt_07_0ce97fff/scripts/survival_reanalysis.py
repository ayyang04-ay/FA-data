"""Survival re-analysis (Fig. 1c, 1l): log-rank and Cox HR. Values transcribed from the source sheets."""
import numpy as np, pandas as pd
# survival
from lifelines.statistics import logrank_test
from lifelines import CoxPHFitter
S=[]
for nm,veh,cr in [('1c',[17,17,20,20,21,23,27,29,30,30],[13,13,13,13,18,20,21,21,22,24]),
                  ('1l',[14,14,14,15,15,15,15,16,16,16,16,18,18,18,18,19,19,20,20,20],[12,12,12,12,13,13,14,14,14,14,15,15,15,17,17,18,19,19])]:
    lr=logrank_test(veh,cr)
    c=CoxPHFitter().fit(pd.DataFrame({'T':veh+cr,'E':1,'cr':[0]*len(veh)+[1]*len(cr)}),'T','E').summary
    S.append(dict(panel=nm,n_vehicle=len(veh),n_creatine=len(cr),median_vehicle=np.median(veh),median_creatine=np.median(cr),logrank_chi2=lr.test_statistic,logrank_p=lr.p_value,HR=c['exp(coef)'].iloc[0],HR_lo95=c['exp(coef) lower 95%'].iloc[0],HR_hi95=c['exp(coef) upper 95%'].iloc[0]))
pd.DataFrame(S).to_csv('/tmp/outputs/analysis_tables/survival_reanalysis.csv',index=False); print(pd.DataFrame(S).round(4).to_string())
