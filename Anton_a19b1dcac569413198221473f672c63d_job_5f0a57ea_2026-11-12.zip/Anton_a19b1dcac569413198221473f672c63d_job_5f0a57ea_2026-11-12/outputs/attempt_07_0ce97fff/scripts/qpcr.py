import openpyxl, numpy as np, pandas as pd, re
from scipy import stats
wb = openpyxl.load_workbook('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx', data_only=True)
def parse_sheet(name):
    ws = wb[name]
    out = {}  # gene -> {label: [vals]}
    cur = None
    for row in ws.iter_rows():
        cells = [(c.column, c.value) for c in row if c.value is not None]
        if not cells: continue
        first = [v for col,v in cells if col<=2 and isinstance(v,str)]
        if first and re.match(r'^[A-Za-z][A-Za-z0-9]+$', first[0].strip()) and first[0].strip() not in ('Graphs',):
            cur = first[0].strip(); out.setdefault(cur,{})
        if cur is None: continue
        # find ΔCT labels followed by 3 numeric values
        for i,(col,v) in enumerate(cells):
            if isinstance(v,str) and re.match(r'^ΔCT\d$', v.strip()):
                vals=[]
                for col2,v2 in cells[i+1:]:
                    if isinstance(v2,(int,float)): vals.append(float(v2))
                    else: break
                    if len(vals)==3: break
                out[cur].setdefault(v.strip(), vals)
    return out
panels = {
 'Fig. 2f': {'ΔCT1':'Vehicle (in vivo MK)','ΔCT2':'Creatine'},
 'Fig. 3f': {'ΔCT1':'Cre;Slc6a8+/+ veh','ΔCT2':'+/+ creatine','ΔCT3':'fl/fl veh','ΔCT4':'fl/fl creatine'},
 'Fig. 4h': {'ΔCT1':'Control (in vitro MK)','ΔCT2':'Creatine','ΔCT3':'Phosphocreatine'},
 'Fig. 4j': {'ΔCT1':'Ctrl+si-scr','ΔCT2':'Ctrl+si-Ckb','ΔCT3':'Cr+si-scr','ΔCT4':'Cr+si-Ckb'},
 'Fig. 4l': {'ΔCT1':'CKB-EV','ΔCT2':'CKB-OE'},
 'Fig.6a': {'ΔCT1':'Vehicle','ΔCT2':'Creatine','ΔCT3':'Veh+STAT5i','ΔCT4':'Cr+STAT5i'},
 'Fig. 6g': {'ΔCT1':'WT veh','ΔCT2':'WT creatine','ΔCT3':'Stat5b cKO creatine'},
 'Supplementary Fig  4e': {'ΔCT1':'Slc6a8 KO MK ctrl','ΔCT2':'KO + creatine','ΔCT3':'KO + creatine@liposome'},
 'Supplementary Fig  3c': {'ΔCT1':'Vehicle','ΔCT2':'Creatine'},
}
rows=[]
for sheet,labs in panels.items():
    d = parse_sheet(sheet)
    for gene, dd in d.items():
        if 'ΔCT1' not in dd: continue
        ref = np.array(dd['ΔCT1'])
        for k,lab in labs.items():
            if k=='ΔCT1' or k not in dd: continue
            x = np.array(dd[k])
            ddct = x.mean()-ref.mean()
            t = stats.ttest_ind(x, ref, equal_var=False)
            t2 = stats.ttest_ind(x, ref)
            rows.append((sheet, gene, labs['ΔCT1'], lab, ref.mean(), x.mean(), 2**ddct, t2.pvalue, t.pvalue))
df = pd.DataFrame(rows, columns=['panel','gene','reference','group','refmean_dCt','grpmean_dCt','fold_vs_ref(2^ddCt, mean-based)','p_student_dCt','p_welch_dCt'])
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
print(df.round(4).to_string())
df.to_csv('/tmp/outputs/analysis_tables/qpcr_reanalysis.csv', index=False)
