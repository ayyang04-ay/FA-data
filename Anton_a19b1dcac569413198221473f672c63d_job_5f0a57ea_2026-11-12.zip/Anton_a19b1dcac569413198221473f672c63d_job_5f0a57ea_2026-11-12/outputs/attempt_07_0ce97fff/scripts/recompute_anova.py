import sys; import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from load import col, wb
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
out=[]
def tukey(panel, endpoint, groups, labels, reported):  # reported: list of (g1,g2,p)
    data=np.concatenate(groups); lab=np.concatenate([[l]*len(g) for l,g in zip(labels,groups)])
    r=pairwise_tukeyhsd(data,lab); tab=pd.DataFrame(r._results_table.data[1:],columns=r._results_table.data[0])
    for g1,g2,rp in reported:
        s=tab[((tab.group1==g1)&(tab.group2==g2))|((tab.group1==g2)&(tab.group2==g1))].iloc[0]
        out.append(dict(panel=panel,endpoint=endpoint,comparison=f'{g1} vs {g2}',mean_1=np.mean(groups[labels.index(g1)]),mean_2=np.mean(groups[labels.index(g2)]),reported_adj_p=rp,recomputed_adj_p=float(s['p-adj']),reproduced='yes' if abs(float(s['p-adj'])-rp)<=max(0.001,0.1*rp) else 'CHECK'))
L=['WT-veh','WT-cr','KO-veh','KO-cr']
S='Fig. 1f'; L1=['scr-veh','scr-cr','sh-veh','sh-cr']
for ep,r0 in [('lung weight',4),('SUV',13),('burden',22),('foci',31)]:
    g=[col(S,f'{c}{r0}:{c}{r0+5}') for c in 'BCDE']
    rep={'lung weight':[('scr-veh','scr-cr',0.0002),('scr-cr','sh-cr',1.0),('sh-veh','sh-cr',0.0114)],'SUV':[('scr-veh','scr-cr',0.0006),('scr-cr','sh-cr',0.935),('sh-veh','sh-cr',0.0001)],
         'burden':[('scr-veh','scr-cr',3.51e-5),('scr-cr','sh-cr',0.6025),('sh-veh','sh-cr',1.01e-5)],'foci':[('scr-veh','scr-cr',0.0014),('scr-cr','sh-cr',0.7911),('sh-veh','sh-cr',0.0012)]}[ep]
    tukey(S,ep,g,L1,rep)
S='Fig. 3d'
for ep,r,rep in [('ADP',4,[('WT-veh','WT-cr',0.001),('KO-veh','KO-cr',1.93e-7)]),('Collagen',5,[('WT-veh','WT-cr',6.46e-6),('KO-veh','KO-cr',2.55e-5)]),('Thrombin',6,[('WT-veh','WT-cr',2.92e-6),('KO-veh','KO-cr',2.55e-5)])]:
    g=[col(S,f'B{r}:D{r}'),col(S,f'E{r}:G{r}'),col(S,f'H{r}:J{r}'),col(S,f'K{r}:M{r}')]
    tukey(S,ep+' aggregation',g,L,rep)
S='Fig. 3i'
for ep,r0,rep in [('lung weight',3,[('WT-veh','WT-cr',1.99e-5),('WT-cr','KO-cr',0.0037),('KO-veh','KO-cr',0.9322)]),('burden',10,[('WT-veh','WT-cr',0.0002),('WT-cr','KO-cr',0.0004),('KO-veh','KO-cr',0.9307)]),('foci',17,[('WT-veh','WT-cr',0.0026),('WT-cr','KO-cr',0.0006),('KO-veh','KO-cr',0.9895)])]:
    g=[col(S,f'{c}{r0}:{c}{r0+3}') for c in 'BCDE']; tukey(S,ep,g,L,rep)
S='Fig. 6b'; L6=['veh','cr','veh+STAT5i','cr+STAT5i']
for ep,r0,rep in [('burden',4,[('veh','cr',1.34e-7),('veh','veh+STAT5i',0.9979),('cr','cr+STAT5i',5.72e-7),('veh+STAT5i','cr+STAT5i',0.8381)]),('foci',13,[('veh','cr',0.0003),('veh','veh+STAT5i',0.9994),('cr','cr+STAT5i',0.0001),('veh+STAT5i','cr+STAT5i',0.9658)])]:
    g=[col(S,f'{c}{r0}:{c}{r0+4}') for c in 'BCDE']; tukey(S,ep,g,L6,rep)
S='Supplementary Fig  2d'; L2=['veh PLT','cr PLT','cr+ASA PLT']
for ep,r0,rep in [('burden',5,[('veh PLT','cr PLT',0.0004),('veh PLT','cr+ASA PLT',0.8098),('cr PLT','cr+ASA PLT',0.0001)]),('foci',14,[('veh PLT','cr PLT',0.0005),('veh PLT','cr+ASA PLT',0.5114),('cr PLT','cr+ASA PLT',6.26e-5)])]:
    g=[col(S,f'{c}{r0}:{c}{r0+5}') for c in 'CDE']; tukey(S,ep,g,L2,rep)
S='Fig. 6e'; g=[col(S,'C5:C7'),col(S,'D5:D7'),col(S,'E5:E7')]; tukey(S,'MK creatine',g,['WT-veh','WT-cr','Stat5b-cKO-cr'],[('WT-veh','WT-cr',0.0077),('WT-veh','Stat5b-cKO-cr',0.0064),('WT-cr','Stat5b-cKO-cr',0.9803)])
S='Supplementary Fig  4c'; g=[col(S,f'{c}6:{c}13') for c in 'CDEF']; tukey(S,'alpha-granules (fields)',g,L,[('WT-veh','WT-cr',0.0013),('WT-cr','KO-cr',0.0002),('KO-veh','KO-cr',1.0)])
S='Supplementary Fig  4b'; g=[col(S,f'{c}5:{c}7') for c in 'CDEF']; tukey(S,'platelet count',g,L,[('WT-veh','WT-cr',0.9989),('WT-veh','KO-veh',0.6837),('WT-cr','KO-cr',0.9233),('KO-veh','KO-cr',0.9817)])
df=pd.DataFrame(out); df.to_csv('/tmp/outputs/analysis_tables/anova_tukey_reported_vs_recomputed.csv',index=False)
pd.set_option('display.width',250); print(df.round(5).to_string())
