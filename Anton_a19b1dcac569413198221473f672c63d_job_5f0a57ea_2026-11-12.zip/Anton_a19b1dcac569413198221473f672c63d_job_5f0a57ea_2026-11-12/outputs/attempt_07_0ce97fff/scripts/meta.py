import sys; import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from load import col
import numpy as np, pandas as pd
from scipy import stats
def rom(a,b):
    a=np.array(a); b=np.array(b)
    lr = np.log(b.mean()/a.mean())
    se = np.sqrt(a.var(ddof=1)/(len(a)*a.mean()**2) + b.var(ddof=1)/(len(b)*b.mean()**2))
    return lr, se
burden = {
 '1b (model A, n=6/6)': (col('Fig. 1b','B3:B8'), col('Fig. 1b','C3:C8')),
 '1f sh-scr (melanoma, n=6/6)': (col('Fig. 1f','B22:B27'), col('Fig. 1f','C22:C27')),
 '1f sh-Slc6a8 tumor (n=6/6)': (col('Fig. 1f','D22:D27'), col('Fig. 1f','E22:E27')),
 '1k (model B, n=6/6)': (col('Fig. 1k','B4:B9'), col('Fig. 1k','C4:C9')),
 '3i Pf4-Cre;Slc6a8+/+ (n=4/4)': (col('Fig. 3i','B10:B13'), col('Fig. 3i','C10:C13')),
 '6b (n=5/5)*dup': (col('Fig. 6b','B4:B8'), col('Fig. 6b','C4:C8')),
 'S1e (n=6/6)': (col('Supplementary Fig  1e','B13:B18'), col('Supplementary Fig  1e','C13:C18')),
 'S1f (n=4/4)': (col('Supplementary Fig  1f','B12:B15'), col('Supplementary Fig  1f','C12:C15')),
 'S1g (n=10/10)': (col('Supplementary Fig  1g','B15:B24'), col('Supplementary Fig  1g','C15:C24')),
 'S1i diet (n=4/4)': (col('Supplementary Fig  1i','B11:B14'), col('Supplementary Fig  1i','C11:C14')),
 'S1k (n=10/10)': (col('Supplementary Fig  1k','B16:B25'), col('Supplementary Fig  1k','C16:C25')),
 'S2d donor-PLT transfer (n=6/6)*dup': (col('Supplementary Fig  2d','C5:C10'), col('Supplementary Fig  2d','D5:D10')),
 '7g human PLT d0 vs d7 (n=5/5)': (col('Fig. 7g','B12:B16'), col('Fig. 7g','C12:C16')),
}
foci = {
 '1b': (col('Fig. 1b','B12:B17'), col('Fig. 1b','C12:C17')),
 '1f sh-scr': (col('Fig. 1f','B31:B36'), col('Fig. 1f','C31:C36')),
 '1f sh-Slc6a8': (col('Fig. 1f','D31:D36'), col('Fig. 1f','E31:E36')),
 '1k': (col('Fig. 1k','B12:B17'), col('Fig. 1k','C12:C17')),
 '3i WT': (col('Fig. 3i','B17:B20'), col('Fig. 3i','C17:C20')),
 '6b*dup': (col('Fig. 6b','B13:B17'), col('Fig. 6b','C13:C17')),
 'S1e': (col('Supplementary Fig  1e','B22:B27'), col('Supplementary Fig  1e','C22:C27')),
 'S1f': (col('Supplementary Fig  1f','B20:B23'), col('Supplementary Fig  1f','C20:C23')),
 'S1g': (col('Supplementary Fig  1g','B28:B37'), col('Supplementary Fig  1g','C28:C37')),
 'S1i diet': (col('Supplementary Fig  1i','B18:B21'), col('Supplementary Fig  1i','C18:C21')),
 'S1k': (col('Supplementary Fig  1k','B29:B38'), col('Supplementary Fig  1k','C29:C38')),
 'S2d*dup': (col('Supplementary Fig  2d','C14:C19'), col('Supplementary Fig  2d','D14:D19')),
 '7g human': (col('Fig. 7g','B19:B23'), col('Fig. 7g','C19:C23')),
}
def meta(d, label, exclude=()):
    rows=[]
    for k,(a,b) in d.items():
        lr,se = rom(a,b)
        # also log-scale t-test & CV
        la, lb = np.log(a), np.log(b)
        sd_log = np.sqrt(((len(la)-1)*la.var(ddof=1)+(len(lb)-1)*lb.var(ddof=1))/(len(la)+len(lb)-2))
        rows.append((k,len(a),len(b),np.mean(a),np.mean(b),np.exp(lr),np.exp(lr-1.96*se),np.exp(lr+1.96*se),lr,se,sd_log))
    df = pd.DataFrame(rows, columns=['expt','nV','nC','meanV','meanC','ratio','lo95','hi95','lr','se','pooledSD_log'])
    use = df[~df.expt.isin(exclude)]
    w = 1/use.se**2
    fe = (w*use.lr).sum()/w.sum()
    Q = (w*(use.lr-fe)**2).sum(); k=len(use)
    C = w.sum()-(w**2).sum()/w.sum()
    tau2 = max(0,(Q-(k-1))/C)
    wr = 1/(use.se**2+tau2)
    re = (wr*use.lr).sum()/wr.sum(); sere = np.sqrt(1/wr.sum())
    I2 = max(0,(Q-(k-1))/Q) if Q>0 else 0
    print(f'--- {label}: k={k} RE pooled ratio={np.exp(re):.2f} (95% CI {np.exp(re-1.96*sere):.2f}-{np.exp(re+1.96*sere):.2f}); FE={np.exp(fe):.2f}; I2={I2:.2f}; tau={np.sqrt(tau2):.3f}; Q p={1-stats.chi2.cdf(Q,k-1):.3g}')
    return df
pd.set_option('display.width',250)
d1 = meta(burden,'metastatic burden, all')
print(d1.drop(columns=['lr','se']).round(3).to_string())
meta(burden,'burden excl. duplicated (6b,S2d) and human (7g) and tumor-KD', exclude=('6b (n=5/5)*dup','S2d donor-PLT transfer (n=6/6)*dup','7g human PLT d0 vs d7 (n=5/5)','1f sh-Slc6a8 tumor (n=6/6)'))
d2 = meta(foci,'foci, all')
print(d2.drop(columns=['lr','se']).round(3).to_string())
meta(foci,'foci excl dup/human/KD', exclude=('6b*dup','S2d*dup','7g human','1f sh-Slc6a8'))
d1.to_csv('/tmp/outputs/analysis_tables/meta_burden.csv', index=False); d2.to_csv('/tmp/outputs/analysis_tables/meta_foci.csv', index=False)
