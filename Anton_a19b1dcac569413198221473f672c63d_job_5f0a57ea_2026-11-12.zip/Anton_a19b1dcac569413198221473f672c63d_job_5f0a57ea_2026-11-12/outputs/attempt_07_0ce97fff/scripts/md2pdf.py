"""Minimal Markdown -> PDF renderer (reportlab) for the proposal document.
Handles: headings (#, ##, ###), paragraphs, bullet lists (-), numbered lists (1.),
nested bullets (3 spaces), pipe tables, horizontal rules, images ![cap](path), inline **bold** and `code`.
"""
import re, sys, os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image,
                                HRFlowable, KeepTogether, ListFlowable, ListItem, PageBreak)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping

FD = '/opt/conda/envs/chem/lib/python3.11/site-packages/matplotlib/mpl-data/fonts/ttf'
pdfmetrics.registerFont(TTFont('DV', os.path.join(FD, 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DV-B', os.path.join(FD, 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('DV-I', os.path.join(FD, 'DejaVuSans-Oblique.ttf')))
pdfmetrics.registerFont(TTFont('DV-BI', os.path.join(FD, 'DejaVuSans-BoldOblique.ttf')))
pdfmetrics.registerFont(TTFont('DVM', os.path.join(FD, 'DejaVuSansMono.ttf')))
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DV-B'); addMapping('DV', 0, 1, 'DV-I'); addMapping('DV', 1, 1, 'DV-BI')

ss = getSampleStyleSheet()
BASE = ParagraphStyle('base', parent=ss['Normal'], fontName='DV', fontSize=8.6, leading=11.2, spaceAfter=3)
H1 = ParagraphStyle('h1', parent=BASE, fontName='DV-B', fontSize=13.5, leading=17, spaceBefore=6, spaceAfter=6, textColor=colors.HexColor('#1a1a1a'))
H2 = ParagraphStyle('h2', parent=BASE, fontName='DV-B', fontSize=11, leading=14, spaceBefore=9, spaceAfter=4, textColor=colors.HexColor('#1f3b63'))
H3 = ParagraphStyle('h3', parent=BASE, fontName='DV-B', fontSize=9.6, leading=12.5, spaceBefore=6, spaceAfter=3, textColor=colors.HexColor('#1f3b63'))
LEAD = ParagraphStyle('lead', parent=BASE, fontName='DV', fontSize=10, leading=13.5, spaceAfter=6,
                      backColor=colors.HexColor('#eef3fa'), borderColor=colors.HexColor('#1f3b63'), borderWidth=0.8, borderPadding=6)
CELL = ParagraphStyle('cell', parent=BASE, fontSize=7.1, leading=8.8, spaceAfter=0)
CELLH = ParagraphStyle('cellh', parent=CELL, fontName='DV-B', textColor=colors.white)
CAP = ParagraphStyle('cap', parent=BASE, fontSize=7.4, leading=9.2, textColor=colors.HexColor('#333333'), spaceAfter=8)
BUL = ParagraphStyle('bul', parent=BASE, spaceAfter=1.5)

def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'`(.+?)`', r'<font face="DVM" size="7.4">\1</font>', t)
    t = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'<i>\1</i>', t)
    return t

def build(md_path, pdf_path, base_dir):
    lines = open(md_path, encoding='utf-8').read().split('\n')
    story = []
    i = 0
    first_para_done = False
    W = A4[0] - 30 * mm
    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        if not s:
            i += 1; continue
        if s == '---':
            story.append(HRFlowable(width='100%', thickness=0.5, color=colors.HexColor('#999999'), spaceBefore=4, spaceAfter=4)); i += 1; continue
        m = re.match(r'^!\[(.*)\]\((.*)\)$', s)
        if m:
            cap, path = m.group(1), m.group(2)
            from PIL import Image as PILImage
            full = os.path.join(base_dir, path)
            w, h = PILImage.open(full).size
            iw = W * 0.98; ih = iw * h / w
            if ih > 120 * mm:
                ih = 120 * mm; iw = ih * w / h
            story.append(KeepTogether([Image(full, width=iw, height=ih), Paragraph(inline(cap), CAP)]))
            i += 1; continue
        if s.startswith('# '):
            story.append(Paragraph(inline(s[2:]), H1)); i += 1; continue
        if s.startswith('## '):
            story.append(Paragraph(inline(s[3:]), H2)); i += 1; continue
        if s.startswith('### '):
            story.append(Paragraph(inline(s[4:]), H3)); i += 1; continue
        if s.startswith('|'):
            rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                r = lines[i].strip().strip('|')
                cells = [c.strip() for c in r.split('|')]
                if not all(re.match(r'^:?-{2,}:?$', c) for c in cells if c):
                    rows.append(cells)
                i += 1
            ncol = max(len(r) for r in rows)
            rows = [r + [''] * (ncol - len(r)) for r in rows]
            # column widths proportional to content length (capped)
            clean = lambda x: re.sub(r'\*\*|`', '', x)
            lens = [max(min(len(clean(r[c])), 70) for r in rows) + 4 for c in range(ncol)]
            # minimum width so the longest single word never breaks (approx 4.3 pt per char at 7.1 pt, bold header wider)
            minw = []
            for c in range(ncol):
                longest = max((len(w) for r in rows for w in re.split(r'[\s/]+', clean(r[c])) if w), default=4)
                hdr = max((len(w) for w in re.split(r'\s+', clean(rows[0][c])) if w), default=4)
                minw.append(max(longest * 4.3, hdr * 4.9) + 8)
            tot = sum(lens)
            cw = [W * l / tot for l in lens]
            # enforce minimums, take width from columns above their minimum proportionally
            for _ in range(10):
                deficit = sum(max(0, minw[c] - cw[c]) for c in range(ncol))
                if deficit <= 0.5: break
                for c in range(ncol):
                    if cw[c] < minw[c]: cw[c] = minw[c]
                spare = [max(0, cw[c] - minw[c]) for c in range(ncol)]
                ssum = sum(spare)
                if ssum <= 0: break
                over = sum(cw) - W
                cw = [cw[c] - over * spare[c] / ssum for c in range(ncol)]
            data = []
            for ri, r in enumerate(rows):
                data.append([Paragraph(inline(c), CELLH if ri == 0 else CELL) for c in r])
            t = Table(data, colWidths=cw, repeatRows=1)
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1f3b63')),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('GRID', (0, 0), (-1, -1), 0.3, colors.HexColor('#b0b7c3')),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f4f6f9')]),
                ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
                ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
            ]))
            story.append(t); story.append(Spacer(1, 5))
            continue
        # lists (bullets / numbered, with one nesting level)
        if re.match(r'^(\s*)(-|\d+\.)\s+', ln):
            items = []  # (level, text, numbered)
            while i < len(lines) and (re.match(r'^(\s*)(-|\d+\.)\s+', lines[i]) or (lines[i].startswith('   ') and lines[i].strip() and items)):
                mm_ = re.match(r'^(\s*)(-|\d+\.)\s+(.*)$', lines[i])
                if mm_:
                    lvl = 1 if len(mm_.group(1)) >= 2 else 0
                    items.append([lvl, mm_.group(3), mm_.group(2) != '-'])
                else:
                    items[-1][1] += ' ' + lines[i].strip()
                i += 1
            # build flowables
            top = []
            cur = None
            for lvl, txt, num in items:
                if lvl == 0:
                    cur = [Paragraph(inline(txt), BUL), []]
                    top.append((cur, num))
                else:
                    if cur is None:
                        cur = [Paragraph('', BUL), []]; top.append((cur, False))
                    cur[1].append(Paragraph(inline(txt), BUL))
            numbered = any(n for _, n in top)
            lis = []
            for (para, subs), num in top:
                content = [para]
                if subs:
                    content.append(ListFlowable([ListItem(sp, leftIndent=10, value='circle') for sp in subs], bulletType='bullet', start='–', leftIndent=10, bulletFontName='DV', bulletFontSize=7))
                lis.append(ListItem(content, leftIndent=12))
            if numbered:
                story.append(ListFlowable(lis, bulletType='1', leftIndent=12, bulletFontName='DV', bulletFontSize=8.4))
            else:
                story.append(ListFlowable(lis, bulletType='bullet', start='•', leftIndent=12, bulletFontName='DV', bulletFontSize=8))
            story.append(Spacer(1, 3))
            continue
        # paragraph (merge consecutive lines)
        para = [s]
        i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r'^(#|\||---|!\[|\s*-\s|\s*\d+\.\s)', lines[i].strip()):
            para.append(lines[i].strip()); i += 1
        txt = ' '.join(para)
        if not first_para_done:
            story.append(Paragraph(inline(txt), LEAD)); first_para_done = True
        else:
            story.append(Paragraph(inline(txt), BASE))

    def footer(canv, doc):
        canv.saveState()
        canv.setFont('DV', 7)
        canv.setFillColor(colors.HexColor('#666666'))
        canv.drawString(15 * mm, 9 * mm, 'CRE-MK-01 follow-up - validation proposal for the in vivo slot')
        canv.drawRightString(A4[0] - 15 * mm, 9 * mm, 'page %d' % doc.page)
        canv.restoreState()
    doc = SimpleDocTemplate(pdf_path, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm, bottomMargin=15 * mm,
                            title='CRE-MK-01 validation proposal', author='Translational analysis')
    doc.build(story, onFirstPage=footer, onLaterPages=footer)

if __name__ == '__main__':
    build(sys.argv[1], sys.argv[2], os.path.dirname(os.path.abspath(sys.argv[1])))
    print('written', sys.argv[2])
