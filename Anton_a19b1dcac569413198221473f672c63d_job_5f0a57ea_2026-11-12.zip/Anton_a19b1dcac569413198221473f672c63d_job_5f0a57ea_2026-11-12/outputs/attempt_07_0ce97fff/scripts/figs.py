import sys; import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from load import col, wb
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({'font.size':9, 'font.family':'DejaVu Sans'})
# ---------- Fig A forest plot
d = pd.read_csv('/tmp/outputs/analysis_tables/meta_burden.csv')
labels = {
 '1b (model A, n=6/6)':'Fig 1b  (n=6/6)',
 '1f sh-scr (melanoma, n=6/6)':'Fig 1f  melanoma, sh-scr (6/6)',
 '1f sh-Slc6a8 tumor (n=6/6)':'Fig 1f  melanoma, tumour sh-Slc6a8 (6/6)',
 '1k (model B, n=6/6)':'Fig 1k  (6/6)',
 '3i Pf4-Cre;Slc6a8+/+ (n=4/4)':'Fig 3i  Pf4-Cre;Slc6a8+/+ (4/4)',
 '6b (n=5/5)*dup':'Fig 6b  (5/5)  [DUPLICATED ANIMALS]',
 'S1e (n=6/6)':'Supp 1e (6/6)',
 'S1f (n=4/4)':'Supp 1f (4/4)',
 'S1g (n=10/10)':'Supp 1g (10/10)',
 'S1i diet (n=4/4)':'Supp 1i  5% creatine diet (4/4)',
 'S1k (n=10/10)':'Supp 1k (10/10)',
 'S2d donor-PLT transfer (n=6/6)*dup':'Supp 2d  donor-platelet transfer (6/6) [DUPLICATED]',
 '7g human PLT d0 vs d7 (n=5/5)':'Fig 7g  human day-7 vs day-0 platelets (5/5)',
}
fig, ax = plt.subplots(figsize=(9.0,4.8))
y = np.arange(len(d))[::-1]
for yi,(i,r) in zip(y,d.iterrows()):
    dup = 'dup' in r.expt
    c = '#b2182b' if dup else ('#2166ac' if '7g' not in r.expt else '#1b7837')
    ax.plot([r.lo95, r.hi95],[yi,yi], color=c, lw=1.6)
    ax.plot(r.ratio, yi, 's', color=c, ms=5)
# pooled excluding dup/human/tumour-KD
ex = d[~d.expt.str.contains('dup') & ~d.expt.str.contains('7g') & ~d.expt.str.contains('sh-Slc6a8')]
w = 1/ex.se**2; fe=(w*ex.lr).sum()/w.sum(); Q=(w*(ex.lr-fe)**2).sum(); k=len(ex); C=w.sum()-(w**2).sum()/w.sum(); tau2=max(0,(Q-(k-1))/C)
wr=1/(ex.se**2+tau2); re=(wr*ex.lr).sum()/wr.sum(); se=np.sqrt(1/wr.sum())
ax.plot([np.exp(re-1.96*se), np.exp(re+1.96*se)],[-1.2,-1.2], color='k', lw=2.5)
ax.plot(np.exp(re), -1.2, 'D', color='k', ms=7)
ax.set_yticks(list(y)+[-1.2]); ax.set_yticklabels([labels[e] for e in d.expt]+[f'Pooled, random effects (k={k}; excl. duplicated, human, tumour-KD)'])
ax.axvline(1, color='grey', ls='--', lw=0.8)
ax.set_xscale('log'); from matplotlib.ticker import NullFormatter, FixedLocator; ax.xaxis.set_minor_formatter(NullFormatter()); ax.set_xticks([0.5,1,2,3,5,8]); ax.set_xticklabels(['0.5','1','2','3','5','8']); ax.set_xlim(0.7,9)
ax.set_xlabel('creatine / vehicle ratio of means (95% CI); red = duplicated animals')
ax.set_title(f'Creatine vs vehicle, lung metastatic burden: pooled ratio {np.exp(re):.2f} (95% CI {np.exp(re-1.96*se):.2f}-{np.exp(re+1.96*se):.2f})', fontsize=9, loc='right')
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/figA_forest_creatine_metastasis.png', dpi=200); plt.close()

# ---------- Fig B: 3i 2x2 + power
g = {'Cre ctrl\nvehicle':col('Fig. 3i','B10:B13'),'Cre ctrl\ncreatine':col('Fig. 3i','C10:C13'),'MK-Slc6a8 cKO\nvehicle':col('Fig. 3i','D10:D13'),'MK-Slc6a8 cKO\ncreatine':col('Fig. 3i','E10:E13')}
fig, axs = plt.subplots(1,2, figsize=(7.2,3.0))
ax=axs[0]
for i,(k,v) in enumerate(g.items()):
    ax.scatter(np.full(len(v),i)+np.random.uniform(-0.08,0.08,len(v)), v, color=['#999999','#b2182b','#999999','#2166ac'][i], s=18, zorder=3)
    ax.plot([i-0.2,i+0.2],[np.mean(v)]*2, color='k', lw=1.5)
ax.set_xticks(range(4)); ax.set_xticklabels(list(g.keys()), fontsize=7)
ax.set_ylabel('Lung metastatic burden (%)'); ax.set_title('Fig 3i (n=4/group): interaction ratio 0.22\n(95% CI 0.11-0.47), p=0.0009', fontsize=8)
ax=axs[1]
def pw(n, sd, e1, e0=1.0):
    delta=np.log(e1)-np.log(e0); se=sd*np.sqrt(4/n); df=4*n-4; ncp=delta/se; tc=stats.t.ppf(0.975,df)
    return 1-stats.nct.cdf(tc,df,ncp)+stats.nct.cdf(-tc,df,ncp)
ns=np.arange(3,31)
for sd,e,ls in [(0.35,2.85,'-'),(0.45,2.0,'-'),(0.45,2.0,'--')]:
    pass
for sd,e,c,lab in [(0.35,2.85,'#b2182b','observed effect (2.85x), SD$_{log}$ 0.35'),(0.45,2.0,'#2166ac','conservative (2.0x), SD$_{log}$ 0.45'),(0.55,2.0,'#67a9cf','conservative (2.0x), SD$_{log}$ 0.55')]:
    ax.plot(ns,[pw(n,sd,e) for n in ns], color=c, label=lab)
ax.axvline(4, color='grey', ls=':', lw=1); ax.text(4.3,0.05,'current n=4', fontsize=7, color='grey')
ax.axvline(16, color='k', ls=':', lw=1); ax.text(16.3,0.05,'proposed n=16', fontsize=7)
ax.axhline(0.8, color='grey', lw=0.6)
ax.set_xlabel('mice per genotype x treatment cell'); ax.set_ylabel('power (interaction, alpha 0.05)')
ax.set_title('Power to detect full abrogation', fontsize=8); ax.legend(fontsize=6, loc='lower right'); ax.set_ylim(0,1.02)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/figB_Slc6a8_cKO_and_power.png', dpi=200); plt.close()

# ---------- Fig C: human platelet function re-analysis
ws=wb['Fig. 7c']
def block(r0): return np.array([[float(ws.cell(row=r,column=c).value) for c in range(2,6)] for r in range(r0,r0+11)])
blocks = {('Collagen','max'):4, ('Collagen','avg'):18, ('Collagen','adh'):32,('Epinephrine','max'):46, ('Epinephrine','avg'):60, ('Epinephrine','adh'):74,('Arachidonic acid','max'):88, ('Arachidonic acid','avg'):102, ('Arachidonic acid','adh'):116,('ADP','max'):130, ('ADP','avg'):144, ('ADP','adh'):157}
rows=[]
for (ag,m),r0 in blocks.items():
    A=block(r0)
    for j,tp in [(1,3),(2,7),(3,14)]:
        x=A[:,j]; x=x[x>0]; l=np.log(x)
        mu=l.mean(); se=l.std(ddof=1)/np.sqrt(len(l)); tcrit=stats.t.ppf(0.975,len(l)-1)
        w=stats.wilcoxon(A[:,j]-1).pvalue
        rows.append((ag,m,tp,np.exp(mu),np.exp(mu-tcrit*se),np.exp(mu+tcrit*se),w,int(np.sum(A[:,j]>1))))
h=pd.DataFrame(rows,columns=['agonist','metric','day','geoFC','lo','hi','p_wilcoxon','n_up'])
from statsmodels.stats.multitest import multipletests
h['q_BH36']=multipletests(h.p_wilcoxon,method='fdr_bh')[1]
h.to_csv('/tmp/outputs/analysis_tables/human_platelet_function_reanalysis.csv',index=False)
fig, axs = plt.subplots(1,4, figsize=(7.4,2.8), sharey=True)
mlab={'max':'max aggregation','avg':'avg aggregation','adh':'adhesion'}
cols={'max':'#2166ac','avg':'#67a9cf','adh':'#b2182b'}
for ax,ag in zip(axs,['Epinephrine','Collagen','Arachidonic acid','ADP']):
    sub=h[h.agonist==ag]
    for k,(m,off) in enumerate([('max',-0.8),('avg',0),('adh',0.8)]):
        s=sub[sub.metric==m]
        xs=np.array([3,7,14])+off
        ax.errorbar(xs, s.geoFC, yerr=[s.geoFC-s.lo, s.hi-s.geoFC], fmt='o', ms=3.5, color=cols[m], lw=1, label=mlab[m])
        for xx,(q,yy) in zip(xs, zip(s.q_BH36, s.hi)):
            if q<0.05: ax.text(xx, yy*1.05, '*', ha='center', fontsize=10)
    ax.axhline(1,color='grey',ls='--',lw=0.8); ax.set_yscale('log'); ax.set_xticks([3,7,14]); ax.set_title(ag, fontsize=8); ax.set_xlabel('day')
axs[0].set_ylabel('fold change vs day 0\n(geometric mean, 95% CI)'); axs[0].legend(fontsize=6, loc='upper left')
fig.suptitle('Healthy volunteers, 20 g/day creatine (n=11, no placebo): * = BH q<0.05 across 36 paired tests', fontsize=8)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/figC_human_platelet_function.png', dpi=200); plt.close()

# ---------- Fig D: phosphoproteomics
df = pd.read_excel('/tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx'); df.columns=['gene','p','q','lfc']
deg = (df.p.round(6)==0.42265) | ((df.lfc.abs()>2) & (df.p>0.16) & (df.p<0.2))
fig, axs = plt.subplots(1,2, figsize=(7.2,2.9))
ax=axs[0]
ax.scatter(df.lfc[~deg], -np.log10(df.p[~deg]), s=3, color='#999999', alpha=0.5, label='peptides')
ax.scatter(df.lfc[deg], -np.log10(df.p[deg]), s=3, color='#f4a582', alpha=0.5, label=f'imputation-type clusters (n={int(deg.sum()):,})')
s=df[df.gene=='Stat5b']
ax.scatter(s.lfc, -np.log10(s.p), s=30, color='#b2182b', zorder=5, label='Stat5b peptides')
ax.axhline(-np.log10(0.05), color='k', lw=0.6, ls='--')
ax.set_xlabel('log fold change (creatine vs vehicle MKs)'); ax.set_ylabel('-log10 p'); ax.legend(fontsize=6, loc='upper left')
ax.set_title('No peptide reaches FDR<0.05 (min q = 0.167)', fontsize=8)
ax=axs[1]
ax.hist(df.p[~deg], bins=20, range=(0,1), color='#999999', edgecolor='white')
ax.axhline(len(df[~deg])/20, color='k', ls='--', lw=0.8)
ax.set_xlabel(f'p-value, peptides outside clusters (n={int((~deg).sum()):,})'); ax.set_ylabel('count')
ax.set_title('238 peptides p<0.05 vs ~193 expected by chance', fontsize=8)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/figD_phosphoproteomics.png', dpi=200); plt.close()
print('done')
