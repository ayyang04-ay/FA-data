"""Integrity scan of the CRE-MK-01 source-data workbook.
1) high-precision numeric values that recur across different sheets (excluding values quantised by 2-decimal Ct rounding)
2) triplicates in which one value equals the exact mean of the other two
3) parity of directly measured aggregation values (Fig. 2b, 3d)
4) phosphoproteomics summary (FDR, degenerate p-value clusters, Stat5b rank)
"""
import openpyxl, collections, math, numpy as np, pandas as pd
SRC='/tmp/world/filesystem/CRE-MK-01_source_data.xlsx'
wb = openpyxl.load_workbook(SRC, data_only=True)
def quantized(x):
    if abs(x*100-round(x*100))<1e-6: return True
    if x>0:
        for scale in (1,100):
            l=math.log2(x/scale)
            if abs(l*1000-round(l*1000))<1e-3: return True
    return False
occ=collections.defaultdict(list)
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value,(int,float)) and not isinstance(c.value,bool):
                occ[round(float(c.value),9)].append((ws.title,c.coordinate))
print('== 1) non-quantised values recurring in >1 sheet')
for k,v in sorted(occ.items()):
    if len(set(x[0] for x in v))>1 and not quantized(k) and abs(k)>=1 and len(repr(k).replace('.','').replace('-','').strip('0'))>=6:
        print(k, v)
print('\n== 2) triplicates with one value = exact mean of the other two (Fig. 2b groups; Fig. 7d technical triplicates)')
ws=wb['Fig. 2b']
for r in (4,5,6):
    for c0 in (2,5):
        v=[float(ws.cell(row=r,column=c0+k).value) for k in range(3)]
        if abs(v[2]-(v[0]+v[1])/2)<1e-9: print('Fig. 2b row',r,'cols',c0,'-',c0+2, v, '-> 3rd = mean(1st,2nd)')
ws=wb['Fig. 7d']
for row in ws.iter_rows():
    for c in row:
        if isinstance(c.value,str) and c.value.isupper() and c.column in (1,8) and len(c.value)<10:
            gene,r0,c0=c.value,c.row,c.column; off=2 if c0==1 else 1
            for vi in range(4):
                for tp,ra in zip(['0d','3d','7d','14d'],[r0+1,r0+4,r0+7,r0+10]):
                    v=[ws.cell(row=ra+k,column=c0+off+vi).value for k in range(3)]
                    if None in v: continue
                    v=[float(x) for x in v]
                    for i in range(3):
                        o=[v[j] for j in range(3) if j!=i]
                        if abs(v[i]-(o[0]+o[1])/2)<1e-9: print('Fig. 7d',gene,'volunteer',vi+1,tp,v)
print('\n== 3) parity of aggregation values')
for sh,rng in [('Fig. 2b','B4:G6'),('Fig. 3d','B4:M6')]:
    vals=[float(c.value) for row in wb[sh][rng] for c in row if isinstance(c.value,(int,float))]
    print(sh, 'n=',len(vals),'even integers=',sum(1 for v in vals if v==int(v) and int(v)%2==0))
print('\n== 4) phosphoproteomics')
df=pd.read_excel('/tmp/world/filesystem/CRE-MK-01_phosphoproteomics.xlsx'); df.columns=['gene','p','q','lfc']
clus=(df.p.round(6)==0.42265)|((df.lfc.abs()>2)&(df.p>0.16)&(df.p<0.2))
print('peptides',len(df),'genes',df.gene.nunique(),'q<0.05:',(df.q<0.05).sum(),'min q',round(df.q.min(),3))
print('p==0.42265:',(df.p.round(6)==0.42265).sum(),' in imputation-type clusters:',clus.sum(),' |log2FC|>3:',(df.lfc.abs()>3).sum())
nd=df[~clus]; print('outside clusters: n',len(nd),' p<0.05:',(nd.p<0.05).sum(),' expected:',round(0.05*len(nd)))
df['rank']=df.p.rank(method='min'); print(df[df.gene=='Stat5b'])
