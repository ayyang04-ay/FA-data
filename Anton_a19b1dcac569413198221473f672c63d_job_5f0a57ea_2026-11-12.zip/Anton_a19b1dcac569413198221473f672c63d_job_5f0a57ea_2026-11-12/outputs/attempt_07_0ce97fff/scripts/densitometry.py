"""Approximate densitometry of supplied blot images (JPEG composites embedded in the workbook).
Images are extracted from the xlsx (xl/media/imageN.jpeg). Mapping: image1 = Fig. 2e, image17 = Supp. Fig. 2a, image26 = Supp. Fig. 8d.
Method: inverted grey level, band window around manually located lane centres, local background = median of flanking rows.
Indicative only (compression, saturation, composite panels)."""
import zipfile, io, numpy as np
from PIL import Image
z = zipfile.ZipFile('/tmp/world/filesystem/CRE-MK-01_source_data.xlsx')
def img(n): return 255-np.array(Image.open(io.BytesIO(z.read(f'xl/media/image{n}.jpeg'))).convert('L')).astype(float)
def lane(a,cx,cy,w=18,h=12,pad=(4,14),search=10):
    best=max(((a[cy+d-h:cy+d+h+1,cx-w:cx+w+1].mean(),cy+d) for d in range(-search,search+1)))
    yc=best[1]; band=a[yc-h:yc+h+1,cx-w:cx+w+1]
    bg=np.median(np.concatenate([a[yc-h-pad[1]:yc-h-pad[0],cx-w:cx+w+1].ravel(),a[yc+h+pad[0]:yc+h+pad[1],cx-w:cx+w+1].ravel()]))
    return float(np.clip(band-bg,0,None).sum())
# Supp. Fig. 8d (human platelets, volunteers 1-4; lanes d0, d3, d7, d14)
a=img(26)
P={('V1','GP6'):([325,375,430,470],176),('V1','P2RY12'):([738,785,845,885],175),('V1','ACTB'):([1170,1222,1275,1325],162),
   ('V2','GP6'):([290,362,418,472],433),('V2','P2RY12'):([710,762,810,858],422),('V2','ACTB'):([1200,1265,1330,1400],425),
   ('V3','GP6'):([330,370,422,475],697),('V3','P2RY12'):([725,770,832,892],702),('V3','ACTB'):([1178,1244,1308,1372],690),
   ('V4','GP6'):([258,318,372,437],990),('V4','P2RY12'):([745,817,872,932],990),('V4','ACTB'):([1220,1280,1334,1387],988)}
R={k:np.array([lane(a,x,cy) for x in xs]) for k,(xs,cy) in P.items()}
print('Supp. Fig. 8d: ratio to beta-actin, relative to day 0 (d0, d3, d7, d14)')
for v in ['V1','V2','V3','V4']:
    g=R[(v,'GP6')]/R[(v,'ACTB')]; p=R[(v,'P2RY12')]/R[(v,'ACTB')]
    print(' ',v,'GP6',np.round(g/g[0],2),' P2RY12',np.round(p/p[0],2))
# Fig. 2e (mouse platelets; 3 vehicle then 3 creatine lanes)
a=img(1)
pan={'GP6':([62,115,168,220,270,320],200,20),'P2RY12':([867,913,960,1010,1057,1103],228,20),'ACTB':([1443,1493,1542,1592,1642,1691],222,20)}
r={k:np.array([lane(a,x,cy,w=w,search=12) for x in xs]) for k,(xs,cy,w) in pan.items()}
for k in ['GP6','P2RY12']:
    q=r[k]/r['ACTB']; print('Fig. 2e',k,'/ACTB creatine/vehicle =',round(q[3:].mean()/q[:3].mean(),2))
# Supp. Fig. 2a (tumour-cell SLC6A8, sh-scrambled vs sh-Slc6a8)
a=img(17)
for cy in (280,285,290):
    s_,k_=lane(a,225,cy,w=22,h=12,pad=(6,18),search=0),lane(a,282,cy,w=22,h=12,pad=(6,18),search=0)
    print('Supp. Fig. 2a SLC6A8 sh/scr at row',cy,'=',round(k_/s_,2))

# ---- sensitivity over window parameters, written to CSV
import pandas as pd
rows=[]
for (w,h,search) in [(18,12,8),(18,12,10),(22,10,10),(15,14,10)]:
    a=img(26)
    R={k:np.array([lane(a,x,cy,w=w,h=h,search=search) for x in xs]) for k,(xs,cy) in P.items()}
    for v in ['V1','V2','V3','V4']:
        g=R[(v,'GP6')]/R[(v,'ACTB')]; p=R[(v,'P2RY12')]/R[(v,'ACTB')]
        rows.append(dict(image='Supp. Fig. 8d (human platelets)',sample=v,quantity='GP6/ACTB day14 vs day0',window=f'w{w}h{h}s{search}',value=g[3]/g[0]))
        rows.append(dict(image='Supp. Fig. 8d (human platelets)',sample=v,quantity='P2RY12/ACTB day14 vs day0',window=f'w{w}h{h}s{search}',value=p[3]/p[0]))
    a2=img(1)
    r={k:np.array([lane(a2,x,cy,w=min(w,20),h=h,search=12) for x in xs]) for k,(xs,cy,_) in pan.items()}
    for k in ['GP6','P2RY12']:
        q=r[k]/r['ACTB']; rows.append(dict(image='Fig. 2e (mouse platelets)',sample='3 vs 3 lanes',quantity=f'{k}/ACTB creatine vs vehicle',window=f'w{w}h{h}',value=q[3:].mean()/q[:3].mean()))
    a3=img(17)
    s_,k_=lane(a3,225,285,w=w+4,h=h,pad=(6,18),search=0),lane(a3,282,285,w=w+4,h=h,pad=(6,18),search=0)
    rows.append(dict(image='Supp. Fig. 2a (tumour cells)',sample='1 vs 1 lane',quantity='SLC6A8 sh-Slc6a8 vs sh-scrambled',window=f'w{w+4}h{h}',value=k_/s_))
df=pd.DataFrame(rows)
summ=df.groupby(['image','sample','quantity']).value.agg(['min','max','median']).reset_index()
rep={('Supp. Fig. 8d (human platelets)','GP6/ACTB day14 vs day0'):'reported 7e row ratios (volunteer order undocumented): 2.17, 2.10, 4.98, 2.06',
     ('Supp. Fig. 8d (human platelets)','P2RY12/ACTB day14 vs day0'):'reported 7e row ratios (volunteer order undocumented): 1.33, 1.69, 2.73, 1.44'}
summ['reported_in_sheet']=[rep.get((a,b),'not quantified in package' if 'Fig. 2e' in a else ('mRNA 0.19 (qPCR, S2a sheet)' if '2a' in a else '')) for a,b in zip(summ.image,summ.quantity)]
summ.round(2).to_csv('/tmp/outputs/analysis_tables/blot_densitometry_crosscheck.csv',index=False)
print(summ.round(2).to_string())
