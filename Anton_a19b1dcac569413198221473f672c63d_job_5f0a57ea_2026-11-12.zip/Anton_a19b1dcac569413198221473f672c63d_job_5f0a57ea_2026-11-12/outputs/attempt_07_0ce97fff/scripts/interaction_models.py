"""Genotype/intervention x creatine interaction on log scale (Fig. 3i, 1f, 6b) and survival re-analysis (Fig. 1c, 1l)."""
import sys; import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from load import col
import numpy as np, pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
def inter(name, g00,g01,g10,g11):
    rows=[(f1,f2,np.log(v)) for (f1,f2),g in {(0,0):g00,(0,1):g01,(1,0):g10,(1,1):g11}.items() for v in g]
    df=pd.DataFrame(rows,columns=['factor','creatine','y'])
    m=smf.ols('y ~ C(factor)*C(creatine)',data=df).fit(); a=anova_lm(m,typ=2)
    k='C(factor)[T.1]:C(creatine)[T.1]'; b=m.params[k]; ci=m.conf_int().loc[k]
    e0=np.mean(np.log(g01))-np.mean(np.log(g00)); e1=np.mean(np.log(g11))-np.mean(np.log(g10))
    return dict(panel=name, creatine_effect_reference=np.exp(e0), creatine_effect_in_factor=np.exp(e1), ratio_of_ratios=np.exp(b), lo95=np.exp(ci[0]), hi95=np.exp(ci[1]), p_interaction=a.loc['C(factor):C(creatine)','PR(>F)'], residual_SD_log=np.sqrt(m.scale))
R=[]
R.append(inter('3i burden (MK Slc6a8 cKO)', col('Fig. 3i','B10:B13'), col('Fig. 3i','C10:C13'), col('Fig. 3i','D10:D13'), col('Fig. 3i','E10:E13')))
R.append(inter('3i foci', col('Fig. 3i','B17:B20'), col('Fig. 3i','C17:C20'), col('Fig. 3i','D17:D20'), col('Fig. 3i','E17:E20')))
R.append(inter('3i lung weight', col('Fig. 3i','B3:B6'), col('Fig. 3i','C3:C6'), col('Fig. 3i','D3:D6'), col('Fig. 3i','E3:E6')))
R.append(inter('1f burden (tumour sh-Slc6a8)', col('Fig. 1f','B22:B27'), col('Fig. 1f','C22:C27'), col('Fig. 1f','D22:D27'), col('Fig. 1f','E22:E27')))
R.append(inter('1f foci', col('Fig. 1f','B31:B36'), col('Fig. 1f','C31:C36'), col('Fig. 1f','D31:D36'), col('Fig. 1f','E31:E36')))
R.append(inter('6b burden (STAT5-IN-1) [duplicated animals]', col('Fig. 6b','B4:B8'), col('Fig. 6b','C4:C8'), col('Fig. 6b','D4:D8'), col('Fig. 6b','E4:E8')))
R.append(inter('6b foci [duplicated animals]', col('Fig. 6b','B13:B17'), col('Fig. 6b','C13:C17'), col('Fig. 6b','D13:D17'), col('Fig. 6b','E13:E17')))
out=pd.DataFrame(R); out.to_csv('/tmp/outputs/analysis_tables/interaction_models.csv',index=False)
pd.set_option('display.width',200); print(out.round(4).to_string())
