import sys; import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from load import col, wb
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
rows=[]
def tt(panel, comp, a, b, rep_t=None, rep_p=None, unit='animals', note=''):
    t,p = stats.ttest_ind(b,a); w = stats.ttest_ind(b,a,equal_var=False).pvalue
    try: mw = stats.mannwhitneyu(b,a,alternative='two-sided').pvalue
    except: mw=np.nan
    ratio = np.mean(b)/np.mean(a) if np.mean(a)!=0 else np.nan
    match = '' if rep_p is None else ('yes' if abs(p-rep_p) <= max(0.0005, 0.05*rep_p) else 'NO')
    rows.append(dict(panel=panel, comparison=comp, n=f'{len(a)}/{len(b)}', unit_of_n=unit, mean_ctrl=np.mean(a), mean_trt=np.mean(b), ratio=ratio,
                     reported_t=rep_t, reported_p=rep_p, recomputed_t=t, recomputed_p=p, welch_p=w, mannwhitney_p=mw, reproduced=match, note=note))
S='Fig. 1a'; tt(S,'lung weight',col(S,'B3:B8'),col(S,'C3:C8'),5.391,0.0003); tt(S,'SUV-BW',col(S,'B12:B17'),col(S,'C12:C17'),3.975,0.0026)
S='Fig. 1b'; tt(S,'metastatic burden',col(S,'B3:B8'),col(S,'C3:C8'),5.025,0.0005); tt(S,'foci',col(S,'B12:B17'),col(S,'C12:C17'),4.938,0.0006)
S='Fig. 1h'
for r,tp,rp in [(4,'0.25h',0.3132),(5,'6h',0.0002),(6,'12h',0.0262),(7,'24h',0.0039)]:
    tt(S,f'lung retention (unlabelled units) {tp}',col(S,f'B{r}:G{r}'),col(S,f'H{r}:M{r}'),None,rp, note='y-axis quantity/units not labelled in source')
S='Fig. 1i'; tt(S,'GFP+ cells/field',col(S,'B4:B11'),col(S,'C4:C11'),8.649,5.5e-7,unit='fields (pseudoreplicate)')
S='Fig. 1j'; tt(S,'lung weight',col(S,'B4:B9'),col(S,'C4:C9'),4.503,0.0011); tt(S,'SUV-BW',col(S,'B13:B18'),col(S,'C13:C18'),4.693,0.0008)
S='Fig. 1k'; tt(S,'metastatic burden',col(S,'B4:B9'),col(S,'C4:C9'),6.639,5.79e-5); tt(S,'foci',col(S,'B12:B17'),col(S,'C12:C17'),6.652,5.70e-5)
S='Fig. 2a'
for nm,a,b,rp in [('PLT',4,6,0.996),('PCT',12,14,0.9725),('PDW',19,21,0.3459),('MPV',27,29,0.9106)]:
    tt(S,nm,col(S,f'B{a}:B{b}'),col(S,f'C{a}:C{b}'),None,rp)
S='Fig. 2b'
for nm,r,rp in [('ADP aggregation',4,0.0003),('collagen aggregation',5,0.0005),('thrombin aggregation',6,0.0011)]:
    tt(S,nm,col(S,f'B{r}:D{r}'),col(S,f'E{r}:G{r}'),None,rp, note='3rd replicate = mean of first two in every group')
S='Fig. 2c'; tt(S,'alpha-granules',col(S,'B4:B11'),col(S,'C4:C11'),3.071,0.0083,unit='fields (pseudoreplicate)')
S='Fig. 2d'
for nm,a,b,rp in [('TEG R',4,8,0.8965),('TEG K',12,16,0.1667),('TEG alpha',20,24,0.1454),('TEG MA',28,32,0.0489)]:
    tt(S,nm,col(S,f'B{a}:B{b}'),col(S,f'C{a}:C{b}'),None,rp)
S='Fig. 2j'; tt(S,'PKH+ area',col(S,'B4:B11'),col(S,'C4:C11'),3.967,0.0014,unit='fields (pseudoreplicate)')
S='Fig. 3b'; tt(S,'serum creatine, Pf4-Cre;Slc6a8+/+',col(S,'B4:F4'),col(S,'G4:K4'),10.29,6.875732e-06); tt(S,'serum creatine, Pf4-Cre;Slc6a8 fl/fl',col(S,'B5:F5'),col(S,'G5:K5'),22.58,1.5697e-08)
S='Fig. 3c'; tt(S,'MK creatine, Slc6a8+/+',col(S,'B4:D4'),col(S,'E4:G4'),2.789,0.0493, note='SDs 4.2 vs 36; Welch not significant'); tt(S,'MK creatine, Slc6a8 fl/fl',col(S,'B5:D5'),col(S,'E5:G5'),1.542,0.198)
S='Fig. 4a'; tt(S,'MK creatine',col(S,'B4:B6'),col(S,'C4:C6'),10.91,0.0004); tt(S,'brain creatine',col(S,'D4:D6'),col(S,'E4:E6'),3.421,0.0268)
S='Fig. 4c'; tt(S,'MK phosphocreatine',col(S,'B4:B6'),col(S,'C4:C6'),9.84,0.0006); tt(S,'brain phosphocreatine',col(S,'D4:D6'),col(S,'E4:E6'),3.267,0.0309)
S='Fig. 4d'; tt(S,'MK creatine in vitro (labelled "Creatinine")',col(S,'C4:C6'),col(S,'D4:D6'),5.529,0.0052)
S='Fig. 4f'; tt(S,'MK phosphocreatine in vitro',col(S,'B4:B6'),col(S,'C4:C6'),3.575,0.0233)
S='Fig. 7g'; tt(S,'lung weight (human d0 vs d7 platelets)',col(S,'B4:B8'),col(S,'C4:C8'),2.896,0.02); tt(S,'metastatic burden',col(S,'B12:B16'),col(S,'C12:C16'),3.126,0.0141); tt(S,'foci',col(S,'B19:B23'),col(S,'C19:C23'),3.219,0.0123)
S='Supplementary Fig  1a'; tt(S,'body weight d0',col(S,'B4:E4'),col(S,'F4:I4'),0.1065,0.9186); tt(S,'body weight d7',col(S,'B5:E5'),col(S,'F5:I5'),2.069,0.0839)
S='Supplementary Fig  1b'; tt(S,'food intake',col(S,'B4:B9'),col(S,'C4:C9'),0.006543,0.9949)
S='Supplementary Fig  1c'; tt(S,'water intake',col(S,'B4:B9'),col(S,'C4:C9'),0.2215,0.8291)
S='Supplementary Fig  1d'; tt(S,'serum creatine',col(S,'B4:B9'),col(S,'C4:C9'),23.86,3.8e-10)
S='Supplementary Fig  1e'; tt(S,'lung weight',col(S,'B4:B9'),col(S,'C4:C9'),2.587,0.0271); tt(S,'burden',col(S,'B13:B18'),col(S,'C13:C18'),4.535,0.0011); tt(S,'foci',col(S,'B22:B27'),col(S,'C22:C27'),5.448,0.0003)
S='Supplementary Fig  1f'; tt(S,'lung weight',col(S,'B4:B7'),col(S,'C4:C7'),3.03,0.0231); tt(S,'burden',col(S,'B12:B15'),col(S,'C12:C15'),3.805,0.0089); tt(S,'foci',col(S,'B20:B23'),col(S,'C20:C23'),5.472,0.0016)
S='Supplementary Fig  1g'; tt(S,'lung weight',col(S,'B3:B12'),col(S,'C3:C12'),2.32,0.0323); tt(S,'burden',col(S,'B15:B24'),col(S,'C15:C24'),7.993,2.48112e-07); tt(S,'foci',col(S,'B28:B37'),col(S,'C28:C37'),5.962,1.2186304e-05)
S='Supplementary Fig  1h'; tt(S,'serum creatine (diet)',col(S,'C4:C7'),col(S,'D4:D7'),12.04,1.9876233e-05)
S='Supplementary Fig  1i'; tt(S,'lung weight (diet)',col(S,'B3:B6'),col(S,'C3:C6'),5.081,0.0023); tt(S,'burden (diet)',col(S,'B11:B14'),col(S,'C11:C14'),4.24,0.0054); tt(S,'foci (diet)',col(S,'B18:B21'),col(S,'C18:C21'),4.841,0.0029)
S='Supplementary Fig  1k'; tt(S,'lung weight',col(S,'B4:B13'),col(S,'C4:C13'),2.262,0.0363); tt(S,'burden',col(S,'B16:B25'),col(S,'C16:C25'),4.046,0.0008); tt(S,'foci',col(S,'B29:B38'),col(S,'C29:C38'),5.617,2.4946056e-05)
S='Supplementary Fig  3a'
for nm,a,b,rp in [('WBC',4,8,0.365),('lymphocytes',12,16,0.8376),('monocytes',20,24,0.5447),('RBC',28,32,0.1087)]:
    tt(S,nm,col(S,f'B{a}:B{b}'),col(S,f'C{a}:C{b}'),None,rp)
S='Supplementary Fig  5c'; tt(S,'MK creatine CKB-OE vs EV',col(S,'B5:B7'),col(S,'C5:C7'),0.5507,0.6112); tt(S,'MK PCr CKB-OE vs EV',col(S,'B13:B15'),col(S,'C13:C15'),1.726,0.1595)
df=pd.DataFrame(rows)
df.to_csv('/tmp/outputs/analysis_tables/ttests_reported_vs_recomputed.csv', index=False)
pd.set_option('display.width',250)
print(df[['panel','comparison','n','ratio','reported_p','recomputed_p','welch_p','mannwhitney_p','reproduced']].round(4).to_string())
