# CRE-MK-01 follow-up: deliverables

- `CRE-MK_validation_proposal.pdf` / `.md`: the committee proposal. The first line states the recommendation.
- `figures/`: Fig. A (creatine effect across experiments), B (Slc6a8-cKO data and power), C (human platelet function re-analysis), D (phosphoproteomics re-analysis).
- `analysis_tables/`: every number quoted in the proposal, in machine-readable form.
  - `ttests_reported_vs_recomputed.csv`, `anova_tukey_reported_vs_recomputed.csv`: all reported tests recomputed from source values, with Welch and Mann-Whitney sensitivity.
  - `interaction_models.csv`: genotype/intervention x creatine interactions on log scale (Fig. 3i, 1f, 6b).
  - `survival_reanalysis.csv`: Fig. 1c, 1l (log-rank, Cox HR).
  - `meta_burden.csv`, `meta_foci.csv`: creatine effect in each experiment (ratio of means, 95% CI).
  - `qpcr_reanalysis.csv`: mean-based delta-delta-Ct with Student and Welch tests for every gene and group contrast.
  - `human_platelet_function_reanalysis.csv`: Fig. 7c as within-volunteer geometric fold change, Wilcoxon, BH across 36 tests.
  - `human_serum_protein_cbc_reanalysis.csv`: Fig. 7b, 7e (paired), S8b.
  - `power_interaction_design.csv`: power and sample size for the 2x2 interaction design, using the package's own variance.
  - `blot_densitometry_crosscheck.csv`: approximate densitometry of supplied blot images, as a range over analysis windows.
  - `data_integrity_findings.csv`: severity-ranked integrity and design findings.
- `scripts/`: Python used to generate all of the above. The scripts read `/tmp/world/filesystem/*`; `load.py` is the cell-range helper.
  - Environment: scipy/statsmodels/openpyxl (the chem env); lifelines for survival (the core env).
