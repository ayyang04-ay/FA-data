**Recommendation: our primary target is SLC6A8, the transporter that brings creatine into megakaryocytes. Platelet GPVI is the lead backup and megakaryocyte STAT5B is the second backup. Next quarter's in vivo slot should run a blinded, adequately powered confirmation that megakaryocyte SLC6A8 is required for creatine-driven metastasis, with a GPVI-blockade arm built into the same study.**

---

# CRE-MK-01 follow-up: validation proposal for the in vivo slot

Prepared for: Portfolio Committee. Basis: the CRE-MK-01 package (source-data workbook, 87 sheets; phosphoproteomics volcano table; study-conventions PDF), which was treated as ground truth. No external data were used as evidence. All statistics below were recomputed by us from the source values. The approach is in Section 2; files are listed in Section 10, with scripts and tables in `scripts/` and `analysis_tables/`.

## 1. Decision summary

**What we take forward, and why**

1. **Primary target: SLC6A8 in megakaryocytes (MKs).** This is the only node where a cell-type-restricted perturbation removes creatine-driven metastasis in vivo in data that pass our integrity checks (Fig. 3i).
   - Pf4-Cre;Slc6a8 cKO: the creatine effect on lung metastatic burden falls from 3.6x to 0.8x. Ratio of ratios 0.22 (95% CI 0.11-0.47), p = 0.0009.
   - This happens although serum creatine still rises normally (Fig. 3b).
   - Baseline metastasis and platelet counts are unchanged.
   - Bypassing the transporter with liposomal creatine restores the MK gene programme in Slc6a8-null MKs (Supp. Fig. 4e). So SLC6A8 is the gate, and intracellular creatine is enough to trigger the programme.
   - SLC6A8 is also the candidate creatine entry point in tumour cells (the package's own tumour-knockdown experiment). That contribution has not been ruled out, because the knockdown was only partial (Section 4.1). A blocker of SLC6A8 would therefore cover both compartments.
   - The weakness is that the keystone experiment used n = 4 per group without blinding. Under realistic effect sizes it had only 29-57% power. It needs a rigorous replication before any further spend.
2. **Backup 1: GPVI (Gp6), the platelet effector.** It is the only downstream effector with concordant evidence at three levels (mouse MK transcript, human platelet protein, human platelet function):
   - induced in all 7 mouse MK qPCR datasets (creatine in vivo or in vitro, or CKB over-expression; 2.8-42x);
   - platelet GP6 protein up in all 4 volunteers tested (2.2x at day 7, 2.8x at day 14);
   - collagen-induced (GPVI-dependent) aggregation up 2.5x at day 14 in the 11-volunteer cohort (our paired, multiplicity-corrected analysis).
   - It is a platelet/MK-restricted receptor, and its effect can be measured in human blood.
   - However, no experiment in the package tests whether GPVI is causally required. The in vivo slot adds that test.
3. **Backup 2: STAT5B in MKs.** Megakaryocyte-specific Stat5b deletion largely abolishes the creatine-induced gene programme (Fig. 6g) without affecting creatine uptake (Fig. 6e). But:
   - it has never been tested against metastasis;
   - the only metastasis data (systemic STAT5A/B inhibitor, Fig. 6b) share animals with another experiment;
   - the phosphoproteomic discovery signal does not survive FDR;
   - S127 phosphorylation is not directly demonstrated.
   - It is a strong mechanism node but a poor drug target.

**What we do not take forward**
- **CKB.** All evidence is in vitro. The claim that CKB acts as a protein kinase rests on one pan-phospho blot. Brain is the dominant CKB/creatine tissue in the package (Fig. 4a-c).
- **P2Y12.** The ADP response was flat in volunteers (6/11 up; 1.07x at day 14), and the P2RY12 protein change is not visible in the displayed human blots.
- **COX-1/aspirin as a target.** Its only in vivo evidence (Supp. Fig. 2d) shares animals with Fig. 6b, and the arachidonic-acid response was not significant after correction. Aspirin is kept as an active comparator arm only.

**What the slot buys (details in Section 7.1)**
- **Core study (Study 1A): 64 mice.** 2x2 design (MK-Slc6a8 cKO vs Cre-control x creatine vs vehicle), melanoma lung-metastasis model, both sexes, n = 16 per cell. Randomised, blinded, pre-registered, with exposure verification and pharmacodynamic (PD) readouts that link to humans.
- **GPVI module (Study 1B): +36 mice.** Adds creatine + anti-GPVI, vehicle + anti-GPVI and creatine + aspirin. It shares the core control arms and is gated on GPVI reagent qualification.
- **Optional add-ons: +48 and +24 mice.** A second tumour type (1C) and PD qualification of an SLC6A8 tool compound (1D).
- **The decision it enables:** keep SLC6A8 as primary, promote GPVI, or stop (Section 8).

**Committee asks**
1. Allocate next quarter's in vivo slot to Study 1: core 1A (64 mice) plus the GPVI/aspirin module 1B (36 mice). Add 1C and 1D if capacity allows.
2. Make reconciliation of the Section 5 integrity findings a precondition for any future use of Fig. 6b, Supp. Fig. 2d, Fig. 2b/3d and Fig. 7d.
3. Approve protocol and ethics preparation for the placebo-controlled volunteer study H1 now. Enrolment starts after the 1A/1B readout, so that its PD panel reflects the result.

**Before the committee meeting (no slot needed)**
- Ask the study team to reconcile the duplicated animals between Fig. 6b and Supp. Fig. 2d.
- Ask for raw data behind Fig. 2b, 3d and 7d, and the phosphosite identity (Section 5).
- These answers change how much weight STAT5B, aspirin and the mouse platelet-function data deserve, but they do not change the primary recommendation.

---

## 2. How the package was assessed

- **Recomputed every reported test from the source values:** 66 t-tests and 51 Tukey comparisons. All reproduce, so the arithmetic is sound.
- **Re-analysed with models that fit the designs:**
  - Welch and Mann-Whitney sensitivity tests;
  - genotype x treatment interaction models on log scale;
  - random-effects pooling of the creatine effect;
  - paired log-scale tests with Benjamini-Hochberg correction for the human cohort;
  - mean-based delta-delta-Ct re-derivation for qPCR.
- **Scanned all numeric cells for integrity problems:** duplicated values across sheets (ignoring values that coincide only because of 2-decimal Ct rounding), derived replicate values, and implausible digit patterns.
- **Re-analysed the phosphoproteomics table.**
- **Ran approximate densitometry** on the supplied blot images (JPEG composites, so this is indicative only).
- **Graded evidence** in this order: in vivo, cell-type-restricted, metastasis endpoint > in vivo, systemic > in vivo, molecular endpoint > in vitro > correlative human.

---

## 3. The phenotype is robust and human-relevant in exposure

| Readout | Source | Result (our re-analysis) |
|---|---|---|
| Lung metastatic burden, creatine vs vehicle | 1b, 1f (x2), 1k, 3i, S1e, S1f, S1g, S1i (diet), S1k | Increased in all 10 clean comparisons (2.1-3.6x). Random-effects pooled 2.85x (95% CI 2.43-3.35; k = 9; I² = 35%). Foci 1.95x (1.68-2.26) (Fig. A) |
| Survival | 1c (10 v 10), 1l (20 v 18) | HR 2.93 (1.04-8.23) and 2.28 (1.16-4.46). Median survival shortened by 3 d and 2 d |
| Early seeding, lung retention of tumour cells | 1h (6 v 6) | 0.86x at 15 min (ns); 1.51x at 6 h; 1.79x at 12 h; 2.76x at 24 h. Effect is on early intravascular survival, not initial arrest, consistent with a platelet mechanism |
| Exposure | S1d, 3b, S1h (mouse); 7b (human) | Serum creatine 2.4-2.9x in mice (~180-240 µM); 3.4-3.5x in volunteers on 20 g/day (45 to ~155 µM, plateau by day 3). Mouse exposure is of the same order as human exposure on this regimen |
| Off-target systemic effects | S1a-c, 2a, S3a, S3c, 2d; S8b (human) | No change in weight, food or water intake, CBC, platelet count or indices, or most MK maturation genes. TEG: only MA borderline (p = 0.049; Welch 0.052). Human CBC unchanged |

Two panels were excluded from pooling because of duplicated animals (6b, S2d; Section 5). Including them does not change the estimate (3.00x).

![Fig. A. Creatine effect on lung metastatic burden across all vehicle-vs-creatine comparisons in the package (ratio of means, 95% CI). Red: panels sharing duplicated animals; green: human platelets transferred into mice.](figures/figA_forest_creatine_metastasis.png)

---

## 4. Node-by-node evidence for the proposed causal chain

Proposed chain: creatine → SLC6A8 on MK → intracellular creatine → CKB → STAT5B (S127) → nuclear STAT5B → platelet-activation gene programme (Gp6, P2ry12, Rab4a, Adra2a…) → primed platelets → metastatic seeding.

### 4.1 Megakaryocyte SLC6A8 (primary)

**Necessity for metastasis (Fig. 3i, n = 4 per group)**
- Creatine effect: 3.56x in Cre-controls vs 0.79x in cKO.
- Interaction (ratio of ratios):
  - burden: 0.22 (0.11-0.47), p = 0.0009;
  - foci: 0.45 (0.23-0.88), p = 0.023;
  - lung weight: 0.84 (0.78-0.90).
- cKO vehicle is no different from control vehicle (Tukey p = 0.64), so there is no baseline effect (Fig. B).

**Exposure is not the explanation (3b).** Serum creatine rises 2.70x in controls and 2.44x in cKO.

**MK uptake**
- 3c: 5.3x in controls (Student p = 0.049; Welch p = 0.105, because SDs were 4.2 vs 36) vs 1.54x in cKO (p = 0.20).
- The uptake itself is corroborated in wild-type mice by 4a (3.05x, p = 0.0004) and 6e (4.7x).

**Gene programme (3f)**
- Induced in controls: Gp6 3.6x, P2ry12 2.0x, Rab4a 3.5x, Gp1ba 5.5x, Rab27b 4.8x, Pitpnb 4.8x.
- Absent in cKO (0.4-1.5x). Fcgr2a is the exception (3.3x).

**Sufficiency of intracellular creatine (S4e, Slc6a8-null MKs)**
- Free creatine does not induce (Gp6 1.25x, p = 0.11; P2ry12 1.04x).
- Liposomal creatine does: Gp6 2.8x, P2ry12 2.2x, Rab4a 3.2x, Rab27b 4.0x (all p ≤ 0.001).

**Other supporting data**
- Priming happens at the MK stage. In vitro, creatine raises GP6 and P2RY12 protein in MKs but not in mature platelets (2i; single blots), and MK protein rises in vivo (2g).
- α-granules increase in controls only (S4c; field-level n).
- Platelet counts are unaffected (S4b).
- SLC6A8 protein is reduced but still present in cKO MKs (S4a).

**Caveats**
- n = 4, unblinded; model and sex of animals not documented; single Cre line.
- Power of the interaction test at n = 4 was 0.29 if the true creatine effect is 2.0x (SD of log burden 0.45), and 0.78 only if the observed 2.85x and SD 0.35 hold.
- Fig. 3d shows lower baseline aggregation in cKO platelets and a paradoxical creatine-induced fall. The data themselves look anomalous (Section 5).
- **Tumour-cell SLC6A8 is not excluded.** The Fig. 1f knockdown is partial at protein level (our densitometry: about 55-70% of scrambled protein remains; mRNA 19%). The knockdown x creatine interaction is 0.77 (0.39-1.53).

**Verdict:** the best-supported causal node; needs a confirmatory replication.

![Fig. B. Left: Fig. 3i data (n = 4 per group). Right: power of the genotype x creatine interaction test against mice per cell, under the observed and conservative effect sizes, using the package's own variance range.](figures/figB_Slc6a8_cKO_and_power.png)

### 4.2 CKB (not taken forward)

**Supporting data (all in vitro except the first point)**
- CKB protein rises in MKs in vivo (4b; single lanes). Ckb mRNA rises 1.8x in vitro (4e; p = 0.011). Phosphocreatine (PCr) rises (4c, 4f).
- PCr itself does not induce the programme (4h: Gp6 0.51x, Rab4a 0.29x), so the effect is not bioenergetic.
- si-Ckb blocks induction in vitro (4j: Gp6 4.3x → 1.4x; P2ry12 5.2x → 1.3x).
- CKB over-expression induces the programme modestly (4l: 1.7-6.0x) without changing creatine or PCr (S5c).

**Weaknesses**
- The protein-kinase claim rests on one in vitro kinase blot read with pan-phospho detection (S6d).
- There is no in vivo perturbation.
- Brain has far more CKB than MKs (4b), and brain creatine and PCr rise with supplementation (1.19x and 1.95x; 4a, 4c). Systemic CKB modulation would therefore engage the CNS.

### 4.3 STAT5B (Backup 2)

**Discovery signal (phosphoproteomics; Fig. D)**
- 0 of 5,812 phosphopeptides reach q < 0.05 (minimum q = 0.167).
- About 1,960 peptides fall in two degenerate p-value clusters (1,702 at exactly p = 0.42265), typically with log2FC magnitudes above 3. This is the signature of missing-value imputation.
- Outside these clusters, 238 peptides have p < 0.05 against roughly 193 expected by chance.
- The Stat5b peptide ranks 17th (p = 0.0012, q = 0.25, log2FC 5.7, an on/off profile). The second Stat5b peptide is unchanged (p = 0.47).
- Phosphosite positions are not provided, so the link to S127 cannot be checked.

**Site-level data (5e, 5f; FLAG-tagged STAT5B mutants)**
- Creatine raises pan-phospho/FLAG in wild-type STAT5B (1.39x, p = 0.009; 1.28x, p = 0.087) but not in S127A. The mutant x treatment interaction is p = 0.024 and 0.043.
- Per the conventions, pan-phospho and FLAG were run on different gels.
- S127D, which cannot be phosphorylated at that position, shows the highest baseline pan-phospho signal (1.46x wild type). So the readout is not specific to S127.
- Canonical pY694/699 is absent in MKs (S6a).

**Nuclear localisation and promoter binding**
- Nuclear STAT5B rises (5h, S6h; single blots).
- ChIP at promoters (5j, S6i): P2ry12 -0.2 kb 12x and -1 kb 4.7x; Gp6 -1 kb 3.8x and -0.2 kb 2.9x; Rab4a -0.2 kb 5.5x (Welch p = 0.06). Exon controls are unchanged.
- No IgG control is reported, and background is high (Gp6 -2 kb shows 16% input in vehicle).

**Genetics (Pf4-iCre;Stat5b cKO)**
- MK creatine uptake is intact (6e: 4.8x).
- The programme is largely abolished (6g): Itga2b 3.99x → 1.03x; Rab4a 4.32x → 1.31x; Gp6 2.78x → 1.44x.
- Some genes keep a residual 1.6-1.9x induction (P2ry12, Gp1ba, F2r, Adra2a; 2.7-4.4x in wild type).
- CBC is normal (S7b).
- **There is no metastasis endpoint.**

**Pharmacology (6a, 6b)**
- STAT5-IN-1 inhibits both STAT5A and STAT5B and was given systemically, so it also acts on tumour and immune cells.
- It blocks the programme and metastasis (interaction 0.32, 0.19-0.54). But three animals per group are duplicated in Supp. Fig. 2d.

**Verdict:** plausible transcriptional node; unvalidated at the metastasis level.

![Fig. D. Phosphoproteomics re-analysis. Left: volcano, with imputation-type clusters in orange and the two Stat5b phosphopeptides in red. Right: p-value histogram outside the clusters; the dashed line is the uniform (null) expectation.](figures/figD_phosphoproteomics.png)

### 4.4 Effectors and platelet function (GPVI = Backup 1)

**Mouse MKs**
- A broad programme is induced in every dataset: Gp6 2.8-42x, P2ry12 2.0-5.2x, Rab4a 2.6-4.3x, Adra2a 2.2-17.7x, Itga2b 2.1-4.8x.
- Direction is consistent, but magnitudes vary widely between experiments (Section 5).

**Mouse platelets (the effector cells)**
- Protein was not quantified in the package.
- Our densitometry of Fig. 2e: GP6 about 1.2x, P2RY12 about 1.0x.
- Mouse aggregation data (2b, 3d) are unreliable (Section 5).

**Human platelet function (Fig. 7c, n = 11; Fig. C)** — our paired log-scale tests with BH correction across all 36 agonist x metric x day tests:

| Agonist (receptor) | Day 7 | Day 14 | Volunteers up (day 14) |
|---|---|---|---|
| Epinephrine (α2A, ADRA2A) | adhesion 1.78x, q = 0.012; avg 1.46x, q = 0.022 | adhesion 2.11x; avg 1.82x; max 1.63x (q ≤ 0.018) | 10-11 / 11 |
| Collagen (GPVI) | max 1.25x, ns | max 2.51x, q = 0.022; avg 2.72x, q = 0.022; adhesion 1.68x, ns | 9 / 11 |
| Arachidonic acid (COX-1) | ns | max 1.32x; adhesion 1.78x (q = 0.07-0.13) | 9 / 11 |
| ADP (P2Y1/P2Y12) | 1.03x, ns | 1.07x, ns | 6 / 11 |

![Fig. C. Human platelet function, re-analysed: within-volunteer fold change vs day 0 (geometric mean, 95% CI); * = BH q < 0.05 across 36 paired tests.](figures/figC_human_platelet_function.png)

**Human platelet protein (7e, n = 4, paired)**
- GP6 up 2.2x at day 7 (p = 0.044) and 2.8x at day 14 (p = 0.022), in 4/4 volunteers. Our densitometry of the displayed blots agrees: 1.5-2.9x.
- P2RY12 is reported as 1.4-1.8x, but the displayed blots do not show it (0.6-1.4x across analysis settings; no increase in 2 of 4 volunteers).

**Human platelets in mice (7g, n = 5 v 5)**
- Day-7 platelets raise metastatic burden 2.7x (p = 0.014).
- Recipient strain, immune status and number of donors are not documented.

**Interpretation**
- GPVI is the single effector supported in both species and at protein plus function level.
- The strongest human functional signal is the epinephrine/α2A axis. Adra2a is induced in mouse MKs, but this axis has not been tested in vivo. It is tracked as a readout, not as a target.

---

## 5. Data-integrity and design findings that change the weighting

Full list: `analysis_tables/data_integrity_findings.csv`.

| Severity | Panel(s) | Finding | Consequence |
|---|---|---|---|
| **High** | Fig. 6b vs Supp. Fig. 2d | Three animals per group are identical in both panels, for burden (to 7 significant figures) and foci: vehicle 3.29136 / 3.733544 / 2.886353 (foci 37/25/33); creatine 11.13465 / 13.22011 / 14.12619 (foci 53/62/47). The panels are different experiments (systemic STAT5 inhibitor vs donor-platelet transfer ± aspirin) | Both quarantined. STAT5-inhibitor and aspirin efficacy unverified |
| **High** | Fig. 2b | In all six triplicates the third value equals the exact mean of the first two (44/40/42, 80/78/79, 20/30/25, …). All measured values are even integers | Mouse aggregation result unverified (effectively n ≤ 2) |
| **High** | Fig. 7d (human CD41+ qPCR) | PITPNB volunteer 4 is entered as raw Ct (about 27) instead of ΔCt. Four technical triplicates contain a value equal to the exact mean of the other two. Volunteer 2 does not respond for most genes | Human transcript data not used |
| **High** | Phosphoproteomics | No FDR-significant peptides; imputation-dominated; no site localisation | STAT5B/S127 discovery is hypothesis-level |
| Medium | Fig. 3d | All 36 values are even integers; 11/12 groups share the identical spread (x, x, x±2) | Request raw traces |
| Medium | Blots (5e/5f, 7e; conventions) | Loading control or FLAG run on separate gels from the target. S127D paradox. Human P2RY12 blots disagree with the quantification | Ratios not lane-normalised; P2RY12 protein claim not supported |
| Medium | Mouse qPCR | Baseline ΔCt for the same gene and cell type differs by up to ~17 cycles between experiments (Gp6 -15.4 to +1.5). The same in vivo contrast ranges 2.8-42x. Replicate-paired fold changes used. Unit of n undocumented | Only direction is interpretable; MK purity must be documented |
| Medium | Fig. 1f / S2a | Tumour SLC6A8 knockdown is partial at protein level | Tumour compartment unresolved |
| Medium | Design (conventions) | No blinding, no power calculation, sex not analysed. Sex confounded with strain (male C57BL/6J, female BALB/cJ). Models unnamed. Fields used as n (1i, 2c, 2j, S4c). n = 3 in most molecular panels, where Mann-Whitney cannot reach p < 0.1 | Built into the new designs |
| Low | 3c; ChIP; labels | Fragile p (Welch 0.105). No IgG control in ChIP. Label errors ("si-"/"sh-", "Creatinine", "ADAR2A", unlabelled y-axis in 1h) | Corrections requested |

**What survives:**
- the phenotype (Section 3);
- Fig. 3i and S4e;
- the Stat5b-cKO molecular data (6e, 6g);
- the CKB in vitro data;
- human serum creatine;
- human GP6 protein;
- human collagen and epinephrine responses (re-analysed).

---

## 6. Target scorecard

| | MK-SLC6A8 | GPVI | MK-STAT5B | CKB | P2Y12 | COX-1 |
|---|---|---|---|---|---|---|
| Clean in vivo causal evidence (metastasis) | **Yes** (3i; n = 4) | None | No (6b compromised; cKO has no metastasis readout) | None | None | No (S2d compromised) |
| Cell specificity of the evidence | MK-restricted genetics | Platelet/MK receptor | MK-restricted (molecular only) | Brain-dominant | Platelet | Systemic |
| Mechanistic coherence | Uptake, programme, bypass rescue, granules | Induced in 7/7 MK datasets; ChIP | Programme abolished in cKO | si/OE in vitro | Induced; ChIP | None |
| Human support in our cohort | Exposure only | **Protein 4/4; collagen response 9/11** | None | None | ADP response flat | AA response not significant |
| Integrity of supporting data | Good (3d caveat) | Moderate | Low | Moderate | Moderate | Low |
| Tractability / translation | Transporter; benefit limited to creatine-exposed; needs peripheral restriction (brain uptake in 4a) | Surface receptor; PD readable in blood | Transcription factor, site-specific: poor | Enzyme; kinase role unproven | High | High |
| **Call** | **Primary** | **Backup 1** | **Backup 2** | Stop | Stop | Comparator only |

**Ordering of backups.** GPVI ranks above STAT5B. If the primary holds, GPVI is the only node that is both druggable and measurable in people. STAT5B would mainly add mechanistic depth.

**How the backups depend on the primary.** Both backups sit downstream in the same MK/platelet axis, so they depend on Study 1A confirming the MK compartment. If 1A fails, the alternative is tumour-intrinsic SLC6A8, not the backups.

**Why the slot does not go to the untested Stat5b-cKO metastasis experiment.** That study is cheap and informative (Study 2). But a positive result would not produce a tractable target, and it rests on the same unconfirmed MK-compartment premise. Confirming the premise first, while testing the tractable effector (GPVI) in the same cohort, carries more decision value per animal.

---

## 7. Proposed studies

### 7.1 In vivo slot: Study 1 "CRE-MK-02" (primary target, with embedded Backup 1)

**Question.** Does MK-restricted loss of SLC6A8 prevent creatine-driven lung metastasis, across sexes and in a second tumour type, under blinded assessment with adequate power? In the same animals, does GPVI blockade reproduce that protection?

**Populations (animals)**
- Pf4-Cre;Slc6a8 cKO vs Pf4-Cre;Slc6a8 wild-type-allele littermates (the Cre-control used in 3i). Age 8-12 weeks; 1:1 female:male.
- Slc6a8 is X-linked, so the genotype nomenclature for males (floxed/Y) must be specified. The package's "flox/flox" label does not resolve this.
- Randomise within litter and sex blocks.

**Indications (tumour models)**
- **Model A (core):** the melanoma line of Fig. 1f, C57BL/6 background, intravenous (i.v.) experimental lung metastasis. The i.v. route is inferred from the 15-minute time point in Fig. 1h. This is intended as a direct replication of 3i; the model used in 3i must be confirmed.
- **Model B (add-on 1C):** a second C57BL/6-syngeneic carcinoma line. Breast is preferred, to mirror the package's female BALB/cJ arm; that model's identity is not documented.
- BALB/c-syngeneic tumours cannot be used in the cKO colonies, assuming they are on a C57BL/6 background (to be confirmed).
- A spontaneous-metastasis (orthotopic + resection) version is reserved for the next slot together with pharmacology.

**Exposure**
- Model A: the package's oral regimen (42.5 mg/mL, 400 µL, three times weekly), for fidelity.
- Model B: 5% w/w creatine diet, which gave comparable exposure and effect in S1h/S1i.
- Pre-treat for at least 14 days before inoculation (several platelet-turnover cycles; matches the timing of the human day-14 changes) and continue to endpoint.
- **Exposure acceptance:** serum creatine in creatine arms at least 2x the vehicle mean at pre-inoculation and at endpoint (package range 2.4-2.9x).

**Arms and comparators**

| Arm | Genotype | Treatment | n (Model A) | Purpose |
|---|---|---|---|---|
| 1 | Cre-control | vehicle + isotype | 16 | reference |
| 2 | Cre-control | creatine + isotype | 16 | positive control; comparator for arms 5 and 7 |
| 3 | cKO | vehicle + isotype | 16 | baseline (no-creatine) effect of target loss |
| 4 | cKO | creatine + isotype | 16 | **primary test (interaction)** |
| 5 (1B) | Cre-control | creatine + anti-GPVI | 12 | Backup 1: is GPVI required? |
| 6 (1B) | Cre-control | vehicle + anti-GPVI | 12 | Backup 1: creatine-independent (baseline) benefit? |
| 7 (1B) | Cre-control | creatine + aspirin 30 mg/kg/day | 12 | active comparator; replaces the compromised S2d |

- Model B (1C): arms 1-4 only, n = 12 per arm.
- Module 1B is gated on a short qualification of the GPVI reagent in our own system: loss of collagen/CRP response at least 80%, platelet count within ±20%. External reagent performance is not assumed.
- If colony output limits 1B, it runs in wild-type mice with its own arm-1/arm-2 controls.

**Endpoints**

*Primary*
- Lung metastatic burden (% lung area; whole-lung step sections; automated quantification by an analyst blinded to group) at a fixed endpoint.
- The endpoint is set before the earliest expected humane endpoint; package vehicle median survival was 16-22 days.

*Key secondary*
- Surface foci (blinded count) and lung weight.
- Early seeding: 24-h lung retention of labelled cells in a satellite cohort (n = 6 per arm), replicating 1h.

*PD, which links to backups and humans*
- Serum creatine; MK creatine and PCr.
- **Platelet creatine and PCr.** This is new, and it is the human-accessible surrogate of MK uptake.
- MK programme panel (Gp6, P2ry12, Rab4a, Adra2a, Itga2b, F2r, Fcgr2a, Rab27b, Pitpnb, Runx1), with MK purity documented.
- Per-platelet surface GPVI and P2Y12.
- Platelet responses to collagen/CRP, thrombin, ADP and epinephrine, with raw traces archived.
- MK nuclear STAT5B, as a bridge to Backup 2.

*Safety*
- CBC; tail bleeding time; TEG; body weight; food and water intake. These matter because of the 3d signal in cKO platelets and because of GPVI/aspirin arms.

**Analysis**
- Linear model on log(burden): genotype x treatment plus sex plus injection batch. Primary estimand: the ratio of ratios.
- The analysis plan is pre-registered before first dose. Outcome assessment and image analysis are blinded, with allocation concealed. Coded diet and syringes are used where feasible.
- All raw images and instrument exports are archived against animal IDs. This directly answers the Section 5 issues.

**Sample size (from package variance; `analysis_tables/power_interaction_design.csv`)**
- The SD of log burden across experiments is 0.16-0.57 (median about 0.37).
- Assumptions: the true creatine effect is 2.0x rather than the pooled 2.85x, to allow for inflation from small unblinded studies; abrogation is full; SD is 0.45.
- Under these assumptions, n = 16 per cell gives 86% power (two-sided α 0.05). The original n = 4 had 29%.
- Module arms at n = 12 vs shared arm 2 (n = 16) give about 97% power to detect full abrogation by GPVI blockade or aspirin, and about 50% to detect half-abrogation (half of the log-scale effect).

**Pre-registered success criteria (Model A)**
- **S0, assay validity:** creatine effect in Cre-controls at least 1.5x with CI excluding 1. If S0 fails, the study is uninformative, not negative.
- **S1:** interaction at most 0.5, with upper 95% CI below 1.
- **S2:** creatine effect in cKO at most 1.25x, with upper CI at most 1.6x.
- **S3:** concordant direction in both sexes and in Model B (interaction point estimate below 0.7).

**Size and timing**
- Core 1A: 64 mice, plus 36 for 1B; 1C adds 48 and 1D about 24 (up to about 172).
- Weeks 0-2: pre-registration, genotyping, GPVI reagent qualification and 1D start.
- Weeks 2-4: creatine pre-treatment.
- Weeks 4-7: inoculation to endpoint.
- Weeks 8-11: blinded quantification and PD.
- Week 12: unblinding and decision memo.

**Add-on 1D (tractability, no tumours)**
- PD qualification of an SLC6A8 tool inhibitor in creatine-fed mice, characterised in our system.
- Gate to the next slot's pharmacological efficacy study:
  - at least 50% reduction of creatine-induced MK and platelet creatine accumulation and of Gp6 induction, at tolerated exposure;
  - brain creatine not lowered. If it is lowered, this shows that a peripherally restricted agent is required.

### 7.2 Study 2 (Backup 2, next slot or swap-in): MK-STAT5B

- **Design:** Pf4-iCre;Stat5b cKO vs iCre wild-type littermates x vehicle/creatine; Model A; n = 16 per cell; endpoints and bias controls as in Study 1.
- **Added readout:** site-resolved STAT5B phosphorylation (targeted, pre-specified sites including S127; at least 5 mice per group; FDR-controlled). Groups: wild-type vehicle vs creatine MKs, and Slc6a8-cKO + creatine MKs, to place the event downstream of uptake in vivo.
- **Note:** the two cKO lines use different Cre drivers (Pf4-Cre vs Pf4-P2A-iCre). Recombination efficiency should be documented for both.

### 7.3 Human translational studies

**H1: randomised, double-blind, placebo-controlled healthy-volunteer study (replaces the single-arm design)**
- **Population:** adults 18-65, both sexes, more than one ancestry. Exclusions: NSAID/antiplatelet/anticoagulant use, bleeding disorders, renal impairment, pregnancy.
- **Arms:** placebo; creatine at a lower maintenance-type dose (5 g/day, 28 d); 20 g/day for 7 d then 5 g/day for 21 d.
- **Size:** about 40 per arm. From our re-analysis the SD of log2 change is about 0.7-0.8 for epinephrine responses, which gives at least 90% power for a 1.5-fold between-arm difference. Collagen responses are noisier (SD 1.2-1.6), giving 80-96% power for a 2-fold difference.
- **Primary endpoint:** change from baseline to day 14 in collagen-induced aggregation versus placebo.
- **Co-primary:** platelet surface GPVI density.
- **Testing order:** the epinephrine response is the first key secondary and is tested hierarchically after the primaries. It was the most consistent signal in the original cohort (11/11 volunteers).
- **Secondary endpoints:**
  - epinephrine-, ADP- and arachidonic-acid-induced responses;
  - platelet GP6/P2RY12 protein with same-membrane normalisation;
  - platelet creatine/PCr (SLC6A8 PD surrogate) and serum creatine;
  - platelet RNA programme;
  - reversibility 4 weeks after stopping;
  - CBC and coagulation.
- **Exploratory:** per-donor platelet-transfer assay (day 0 vs day 14) with documented recipients.

**H2: indication-level observational cohort**
- **Population:** patients with resected high-risk melanoma or early breast cancer, the two tumour types modelled.
- **Measures:** creatine-supplement use (questionnaire plus serum creatine) and the platelet priming signature (GPVI density, collagen/epinephrine responses), at enrolment and at 3 months.
- **Outcomes:**
  - near term: prevalence of exposure, and whether exposed patients carry the signature;
  - long term: distant-metastasis-free survival.
- **Why it matters:** this sizes the population an SLC6A8-directed strategy could serve.
- **Natural comparator:** stopping creatine. A drug would have to beat cessation, or serve patients who cannot stop creatine.

### 7.4 Indication positioning (what each target would be developed for)

| Target | Intended setting | Population | Clinical comparator | Human PD readout |
|---|---|---|---|---|
| SLC6A8 (primary) | Preventing creatine-associated metastatic seeding in solid tumours that spread through the blood to the lung. Melanoma and breast first (the modelled types); peri-operative/adjuvant window | Cancer patients exposed to supplemental creatine who cannot or will not stop (for example, creatine used for muscle support) | Creatine cessation; placebo | Platelet creatine/PCr, platelet GPVI, collagen and epinephrine responses |
| GPVI (Backup 1) | Same setting. It widens to all peri-operative patients, whatever their creatine use, only if arm 6 shows a baseline benefit | As above, or all-comers if a baseline benefit is shown | Placebo; low-dose aspirin as active comparator | Surface GPVI occupancy/density; collagen/CRP response |
| STAT5B (Backup 2) | No near-term clinical indication; mechanism and biomarker node | - | - | Not accessible in blood (MK-intrinsic) |

---

## 8. What would elevate one choice over another

| Outcome | Effect on ranking |
|---|---|
| 1A meets S0-S3 | SLC6A8 confirmed as primary. Next slot: pharmacological SLC6A8 efficacy (if 1D passes) plus a spontaneous-metastasis/resection model |
| 1A partial (interaction 0.5-0.8) or sex/model-specific | MK is not the sole compartment. Re-test tumour SLC6A8 with verified protein loss. SLC6A8 stays the molecule (systemic blockade covers both compartments); effector work gains priority |
| 1A null with S0 intact | MK-priming hypothesis fails. Backups (downstream) fall with it. Pivot to tumour-cell SLC6A8 or stop |
| 1A S0 fails | Phenotype in question. Pause the programme and audit |
| Anti-GPVI (PD confirmed) removes at least 75% of the creatine effect | GPVI becomes co-primary and the preferred drug target (tractable, human-readable) |
| Anti-GPVI also lowers baseline metastasis (arm 6 vs 1) | GPVI moves above SLC6A8 for development, because the indication widens beyond creatine users |
| Anti-GPVI ineffective despite PD | GPVI dropped (effector redundancy). Upstream SLC6A8 or programme-level STAT5B favoured |
| Aspirin abolishes the effect | COX-1 re-enters as a repurposing comparator, replacing the S2d evidence |
| Study 2: Stat5b cKO abolishes metastasis and S127 phosphorylation is confirmed in vivo (absent in Slc6a8 cKO) | STAT5B rises above GPVI as a mechanism/biomarker node (not as a drug target) |
| H1 confirms collagen/GPVI (± epinephrine) priming vs placebo, including at maintenance dose | Human relevance of GPVI and of the whole axis established; supports patient guidance on creatine |
| H1 null vs placebo | Platelet priming not human-relevant at tested doses; programme deprioritised |
| Epinephrine/α2A priming replicates vs placebo, and mouse platelets from arm 2 show α2A-dependent hyper-reactivity | α2A (Adra2a) joins the effector shortlist alongside GPVI. Today it has function-only human support and no in vivo test |
| 6b/S2d, 2b, 7d reconciled with raw records | Restores (or permanently removes) weight for STAT5 inhibitor, aspirin, mouse aggregation and human transcript data |

---

## 9. Key risks

- **The effect requires exogenous creatine.** Target loss or STAT5 inhibition did not change baseline metastasis (3i, 6b), so an SLC6A8 drug only helps creatine-exposed patients. H2 and arm 6 address this directly.
- **CNS creatine handling.** Brain creatine and PCr respond to supplementation (4a, 4c), so any SLC6A8 agent needs peripheral restriction (1D).
- **Haemostasis.** Watch the 3d signal in cKO platelets and the GPVI/aspirin arms; bleeding readouts are included.
- **Generalisability.** Only lung metastasis and largely i.v. models have been tested; spontaneous-metastasis work is planned for the next slot. The human cohort was young Asian adults on a loading dose only.

---

## 10. Methods and files

- **Re-analysis:** Python (scipy, statsmodels, lifelines). Scripts are in `scripts/`.
- **Key tables:**
  - `ttests_reported_vs_recomputed.csv`
  - `anova_tukey_reported_vs_recomputed.csv`
  - `interaction_models.csv`
  - `survival_reanalysis.csv`
  - `meta_burden.csv` / `meta_foci.csv`
  - `qpcr_reanalysis.csv`
  - `human_platelet_function_reanalysis.csv`
  - `human_serum_protein_cbc_reanalysis.csv`
  - `power_interaction_design.csv`
  - `blot_densitometry_crosscheck.csv`
  - `data_integrity_findings.csv`
- **Figures:**
  - `figA_forest_creatine_metastasis.png`
  - `figB_Slc6a8_cKO_and_power.png`
  - `figC_human_platelet_function.png`
  - `figD_phosphoproteomics.png`
- **Method conventions:**
  - ratios are ratios of means unless stated;
  - interaction ratios come from log-scale two-way models;
  - human fold changes are geometric means of within-volunteer ratios;
  - q = Benjamini-Hochberg across 36 tests;
  - densitometry is approximate (JPEG composites, local background subtraction).
